import logging
from typing import Dict

from botocore.client import BaseClient
from pydantic import BaseModel

from chatrd.core.document import Document, OrderedSet
from chatrd.core.thread_utils import submit_to_shared_thread_pool
from chatrd.core.vectorstore import OpenSearch
from chatrd.engine.components.query_analyzer.entity_extractor.utils import Entities
from chatrd.engine.components.query_analyzer.translator.utils import (
    Get_translation_result,
)
from chatrd.engine.components.query_processor.query_retriever.uc_retrievers.base import (
    UCRetriever,
)
from chatrd.engine.components.query_processor.query_retriever.uc_retrievers.common_research import (
    CommonResearchRetriever,
)
from chatrd.engine.components.query_processor.query_retriever.uc_retrievers.ratings import (
    RatingsRetriever,
)
from chatrd.engine.components.query_processor.query_retriever.utils import (
    get_sorted_docs_by_date,
)
from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.ratings_api import RatingsAPI

logger = logging.getLogger(__name__)

config_machinery = get_config_machinery()


class CreditMemoRetriever(UCRetriever):
    def __init__(self, vector_stores_dict: Dict[str, OpenSearch], reranker_client: BaseClient):
        self.ratings_retriever = RatingsRetriever(
            vector_stores_dict=vector_stores_dict, reranker_client=reranker_client
        )
        self.common_research_retriever = CommonResearchRetriever(
            vector_stores_dict=vector_stores_dict, reranker_client=reranker_client
        )

    def retrieve(
        self,
        query: str,
        entities: Entities,
        model_name_for_data_service: str,
        temperature_for_data_service: float,
        entity_type: str,
        sectors: BaseModel,
        original_language: str,
        original_query: str,
        multi_uc_type: bool = False,
    ):

        all_documents = OrderedSet()
        retrieved_documents = OrderedSet()
        recency_bias = True
        final_top_k_per_query = 5
        if entity_type.value in ["Company", "Sovereign"]:
            name = entities.companies[0].name if entities.companies else None
            mi_id = entities.companies[0].mi_id if entities.companies else None
            base_url = config_machinery.get_config_value(Constants.SourceGeneration.BASE_URL)
            entity_url = "/web/client#" + entities.companies[0].url
            future_is_credit_memo_present = submit_to_shared_thread_pool(
                RatingsAPI().check_creditmemo, mi_id, entity_type.value
            )
            is_credit_memo_present = False
            ratings_query = f"What are the ratings for {name}?"
            peers_query = f"How does {name} compare to its peers?"
            financial_query = f"What are the financial highlights/trends of {name}?"
            swot_query = f"what are the strengths and weaknesses for {name}"

            if future_is_credit_memo_present.done():
                is_credit_memo_present, _, _ = future_is_credit_memo_present.result()

            content = f'In addition to the chat response below, the pre-formatted RatingsDirect Credit Memo PDF can be accessed by navigating to the <a href="{base_url}{entity_url}" target="_blank">Corporate Profile page</a>, clicking on the "Export" dropdown and selecting "Export RatingsDirect Credit Memo".'
            content = Get_translation_result(content, original_language)
            content = content.result()

            if is_credit_memo_present:
                all_documents.add(
                    Document(
                        content=content,  # noqa: E501
                        synthesize=False,
                    )
                )
            futures = {
                "ratings": submit_to_shared_thread_pool(
                    self.ratings_retriever.retrieve,
                    ratings_query,
                    "ratings",
                    entities,
                    model_name_for_data_service,
                    temperature_for_data_service,
                    sectors,
                    original_language,
                    original_query,
                ),
                "peers": submit_to_shared_thread_pool(
                    self.common_research_retriever.retrieve,
                    peers_query,
                    entities,
                    "peers",
                    model_name_for_data_service,
                    temperature_for_data_service,
                    sectors,
                    original_language,
                    original_query,
                    recency_bias,
                ),
                "financials": submit_to_shared_thread_pool(
                    self.common_research_retriever.retrieve,
                    financial_query,
                    entities,
                    "financials",
                    model_name_for_data_service,
                    temperature_for_data_service,
                    sectors,
                    original_language,
                    original_query,
                    recency_bias,
                ),
                "swot": submit_to_shared_thread_pool(
                    self.common_research_retriever.retrieve,
                    swot_query,
                    entities,
                    "swot",
                    model_name_for_data_service,
                    temperature_for_data_service,
                    sectors,
                    original_language,
                    original_query,
                    recency_bias,
                ),
            }

            for query_type, future in futures.items():
                try:
                    documents = future.result()
                    structured_docs = [doc for doc in documents if doc.source == "structured"]
                    unstructured_docs = [doc for doc in documents if (doc.source == "unstructured" and doc.metadata)][
                        :final_top_k_per_query
                    ]
                    if query_type == "ratings":
                        # what to do for multiple entities?
                        all_documents.add(Document(content="**Ratings**", synthesize=False))
                    retrieved_documents.extend(structured_docs + unstructured_docs)
                except Exception as e:
                    logger.error(f"{query_type} retrieval generated an exception: {e}")
            # Sorting all documents:
            structured_docs = [doc for doc in retrieved_documents if doc.source == "structured"]
            unstructured_docs = [doc for doc in retrieved_documents if (doc.source == "unstructured" and doc.metadata)]
            unstructured_docs = get_sorted_docs_by_date(unstructured_docs, len(unstructured_docs))
            all_documents.extend(structured_docs + unstructured_docs)

        else:
            entity_name = ""
            if entities.revenue_sources:
                entity_name = entities.revenue_sources[0].name
            else:
                entity_name = entities.companies[0].name
            query = f"What are the ratings for {entity_name}?"
            all_documents = self.common_research_retriever.retrieve(
                query=query,
                entities=entities,
                model_name_for_data_service=model_name_for_data_service,
                temperature_for_data_service=temperature_for_data_service,
                uc_type="ratings",
                sectors=sectors,
                original_language=original_language,
                original_query=original_query,
                recency_bias=recency_bias,
            )
        logger.info(f"Total number of documents: {len(all_documents)}")
        return all_documents

    def vector_db_retrieval(
        self,
    ):
        pass
