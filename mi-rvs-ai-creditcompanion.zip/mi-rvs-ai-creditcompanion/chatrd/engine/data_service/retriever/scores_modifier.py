import logging

from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.data_service.retriever.base import BaseRetriever
from chatrd.engine.data_service.retriever.utils import _retrieve, get_keyinstn_id
from chatrd.engine.data_service.schema import Analyzer, ProcessorInput, Retriever

logger = logging.getLogger(__name__)
config_machinery = get_config_machinery()


class ScoresModifierRetriever(BaseRetriever):
    def retrieve(self, processor: ProcessorInput = None, analyzer: Analyzer = None):
        if not processor.entities or len(processor.entities["companies"]) == 0:
            return Retriever()

        endpoint_path = Constants.RatingsAPI.RATINGS_API_RATING_SCORES_MODIFIER_ENDPOINT_PATH
        parameter = get_keyinstn_id(processor.entities)
        return _retrieve(endpoint_path, parameter)
