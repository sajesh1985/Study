from datetime import date

TODAY = date.today()
CURRENT_QUARTER = (TODAY.month - 1) // 3 + 1

EXAMPLES = [
    [
        "What is the predicted inflation rate in the US next year?",
        f"What is the predicted inflation rate in the US in {TODAY.year+1}?",
    ],
    [
        "What are the Global Credit Conditions for Q1?",
        f"What are the Global Credit Conditions for Q1 {TODAY.year}?",
    ],
    [
        "What is the predicted inflation rate in the US this quarter?",
        f"What is the predicted inflation rate in the US in in Q{CURRENT_QUARTER} {TODAY.year}?",
    ],
    [
        "Can you provide insights into the inflation trends reported in this month?",
        "Can you provide insights into the inflation trends?",
    ],
    [
        "Provide an outlook for XYZ company using articles published last year",
        "Provide an outlook for XYZ company",
    ],
    ["Show me all German companies whose rating was downgraded inside the previous half-year", ""],
]

TIME_REPHRASER_EXAMPLES = "\n______\n".join(
    [
        f"""question: {question} \nrephrased_question: {rephrased_question}"""
        for question, rephrased_question in EXAMPLES
    ]
)

TIME_REPHRASER_PROMPT = f"""
Your task is to rephrase questions referencing time relative to the current date, making the timeframe explicit (i.e., specifying the exact year or quarter) in some special cases. Follow these rules:
 
1. If the question mentions phrases like "last year/quarter," "this year/quarter," "next year/quarter," etc. by means of calendar periods, use the current date ({TODAY}) to determine the mentioned year or quarter.
2. If a month or quarter is mentioned without specifying a year, assume it refers to the current year.
3. If in the question the time reference applies only to publication dates (e.g., "show documents on topic XYZ published this year," "use only documents from 2025," etc.), remove this reference.
4. If timeframe other than the whole year, quarter, or month is mentioned, do not rephrase the question.
5. If no rephrasing is needed, return an empty string.

Examples containing pairs of question and rephrased_question:
<examples>
{{examples}}
</examples>

<question>
{{question}}
</question>
Return ONLY a JSON object which should contain following properties:
* "rephrased_question"
"""
