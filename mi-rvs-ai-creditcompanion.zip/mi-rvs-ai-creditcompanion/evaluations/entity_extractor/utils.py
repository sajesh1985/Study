import copy
import json
import logging
import os
import random
import re
import time
from itertools import permutations
from typing import Dict, List, Optional, Set, Tuple

import pandas as pd
from tqdm import tqdm
import pathlib

from chatrd.engine.components.query_analyzer.entity_extractor import EntityExtractor
from chatrd.engine.components.query_analyzer.entity_extractor.utils import (
    Companies,
    Entities,
    RevenueSource,
    Securities,
)

GENERATOR_SEED = 12

entity_extractor = EntityExtractor(model_name="haiku", temperature=0.0001)

def setup_logging():
    import logging

    logging.basicConfig(
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        level=logging.INFO,
    )
    logger = logging.getLogger(__name__)
    return logger


logger = setup_logging()


# Used for making question templates less verbose
subject_types = {
    "company_entity": {
        "Arts Institution",
        "Educational Institution",
        "Foundation or Charitable Institution",
        "Government Institution",
        "Private Company",
        "Private Fund",
        "Public Company",
        "Public Fund",
        "Revenue Source",
        "Structured Finance",
    },
    "company_sf_entity": {
        "Structured Finance"
    },
    "country_entity": {
        "Country name",
        "Continent name",
    },
    "city_entity": {
        "City name",
        "County name",
    },
    "geography_adjective_entity": {
        "Country name adjective",
        "Continent name adjective",
    },
    "industry_entity": {
        "Industry name",
    },
}

# Given the first entity is the key of the dictionary, what entity types can it be compared to
multi_entity_rules = {
    "Arts Institution": {"Arts Institution"},
    "Educational Institution": {"Educational Institution"},
    "Foundation or Charitable Institution": {"Foundation or Charitable Institution"},
    "Government Institution": {"Government Institution"},
    "Private Company": {"Private Company"},
    "Private Fund": {"Private Fund"},
    "Public Company": {"Public Company"},
    "Public Fund": {"Public Fund"},
    "Revenue Source": {"Revenue Source"},
    "Structured Finance": {"Structured Finance"},
}


# evaluation

def split_entities(entities: Entities, error_code: str = '') -> dict:
    """
    This function splits the entities into different types

    Entities example
    Entities(companies=[Companies(name='City of Lanesboro, Minnesota',
    type='Government Institution', mi_id=8980482,
    id=None, rating_entity_id='492042', url='company/profile?id=8980482')],
    securities=[],
    revenue_sources=[])

    Args:
        entities: Entities object
    Returns:
        extraction: dictionary of entity properties
    """

    extraction = {"companies": [], "entity_id": [], "cusip": [], "isin": [], "error_code": []}

    if entities.companies:
        for entity in entities.companies:
            extraction["companies"].append(entity.name)
            extraction["entity_id"].append(entity.mi_id)

    if entities.securities:
        for entity in entities.securities:
            if entity.cusip:
                extraction["cusip"].append(entity.cusip)
            else:
                extraction["isin"].append(entity.isin)

    if entities.revenue_sources:
        for entity in entities.revenue_sources:
            extraction["companies"].append(entity.name)
            extraction["entity_id"].append(entity.asid)

    if error_code:
        extraction["error_code"].append(error_code)

    return extraction


def run_entity_extractor(query: str, model_name_for_analyzer: str, temperature_value_for_analyzer: float):
    """*This function queries the NER pipeline and returns the results*

    Args:
        query: query to be passed to the model
        model_name_for_analyzer: model name for the entity extractor
        temperature_value_for_analyzer: temperature value for the entity extractor
    Returns:
        extraction: dictionary of entity properties

    """
    st = time.time()
    try:
        entity_extractor_result, _, raw_entities = entity_extractor.run(query=query, list_of_tagged_entities=[])
    except Exception as e:
        logger.error(e)
        extraction = split_entities(Entities(companies=[], securities=[], revenue_sources=[]), e)
        return extraction, raw_entities, time.time() - st

    extraction = split_entities(entity_extractor_result)
    return extraction, raw_entities, time.time() - st


def query_n_times(n: int, query: str, model_name_for_analyzer: str = "haiku", temperature_value_for_analyzer: float = 0.0):
    """
    This function queries the entity extractor n times and returns the results

    Args:
        n: number of times to query the model
        query: query to be passed to the model
        model_name_for_analyzer: model name for the entity extractor
        temperature_value_for_analyzer: temperature value for the entity extractor

    Returns:
        results: the list of results
    """
    results = []
    raw_ent = []
    exec_times = []

    sleep_seconds = 1
    if os.environ["SEARCH_API_ENV"] == "prod":
        sleep_seconds = 5

    if os.environ["SEARCH_API_ENV"] == "staging":
        sleep_seconds = 1

    for i in range(0, n):
        extraction, raw_entities, run_time = run_entity_extractor(
            query=query,
            model_name_for_analyzer=model_name_for_analyzer,
            temperature_value_for_analyzer=temperature_value_for_analyzer,
        )
        results.append(extraction)
        raw_ent.append(raw_entities)
        exec_times.append(run_time)
        time.sleep(sleep_seconds)

    return results, raw_ent, exec_times


def evaluate(question_set: list, number_of_experiments: int = 2, model_name_for_analyzer: str = "haiku", temperature_value_for_analyzer: float = 0.0001) -> (list, list):
    """This function evaluates the NER pipeline results from the model

    Args:
        question_set: list of questions to evaluate
        number_of_experiments: number of experiments to run
        model_name_for_analyzer: model name for the entity extractor
        temperature_value_for_analyzer: temperature value for the entity extractor
    Returns:
        match_list: list of questions with the results
        results_dict: list of results

    """
    entity_extractor = load_model(model_name_for_analyzer, temperature_value_for_analyzer)
    
    match_list = []
    results_dict = []
    for question_dict in tqdm(question_set):
        question_dict["number_of_experiments"] = number_of_experiments
        question_dict["model_name_for_analyzer"] = model_name_for_analyzer
        question_dict["temperature"] = temperature_value_for_analyzer
        n_results, n_raw_ent, n_times = query_n_times(
            n=number_of_experiments,
            query=question_dict["question"],
            model_name_for_analyzer=model_name_for_analyzer,
            temperature_value_for_analyzer=temperature_value_for_analyzer,
        )
        question_dict["time_per_sample_sec"] = round(sum(n_times) / len(n_times), 2)
        question_dict["count_correct_entities"] = 0
        question_dict["count_total_entities"] = 0
        question_dict["raw_entities"] = n_raw_ent

        for result in n_results:
            question_dict["count_correct_entities"] += sum([1 for entity_id in result["entity_id"] if entity_id in question_dict["entity_id"]])
            question_dict["count_total_entities"] += len(question_dict["entity_id"])
            result["question"] = question_dict["question"]
            result["ground_truth"] = question_dict["entity_id"]
            result["raw_entities"] = question_dict["raw_entities"]

        match_list.append(question_dict)
        results_dict.extend(n_results)

    return match_list, results_dict


def compare_entities(gt_list, pred_list):
    if len(gt_list) == 0 and len(pred_list) == 0:
        return 1.0
    else:
        count_missing_gt = 0
        count_missing_pred = 0
        # how many of the ground truth entities are missing in the extracted entities
        for entity in gt_list:
            if entity not in pred_list:
                count_missing_gt += 1
        # how many of the extracted entities are missing in the ground truth entities
        for entity in pred_list:
            if entity not in gt_list:
                count_missing_pred += 1
        
        # hallucination
        if count_missing_pred > 0:
            return 0.0

        # partial match
        if count_missing_gt > 0:
            return 1 - (count_missing_gt / len(gt_list))

        return 1.0


def print_results(results_df, results_detailed_df, model_id, prompt_id, number_of_experiments, output_path):
    time_per_sample = results_df['time_per_sample_sec'].mean()
    accuracy_list = []
    for idx, row in results_detailed_df.iterrows():
        accuracy_list.append(compare_entities(row['ground_truth'], row['entity_id']))
    results_detailed_df['accuracy'] = accuracy_list
    final_accuracy = results_detailed_df['accuracy'].mean()

    out_1 = pathlib.Path(f"{output_path}/{model_id}/eval_{prompt_id}_{str(number_of_experiments)}_res.csv").resolve()
    out_2 = pathlib.Path(f"{output_path}/{model_id}/eval_{prompt_id}_{str(number_of_experiments)}_det.csv").resolve()
    out_3 = pathlib.Path(f"{output_path}/{model_id}/eval_{prompt_id}_{str(number_of_experiments)}_sim.txt").resolve()

    results_df.to_csv(out_1, index=None)
    results_detailed_df.to_csv(out_2, index=None)
    
    results_detailed_df = results_detailed_df[["question", "ground_truth", "raw_entities", "companies", "entity_id", "cusip", "isin", "error_code", "accuracy"]]
    
    print(f"\nModel: {model_id}")
    print(f"Latency: {round(time_per_sample, 2)} sec")
    print(f"Accuracy: {round(final_accuracy, 2)}")

    print(f"\nResults saved in:\n{out_1}\n{out_2}\n{out_3}\n")
    with open(out_3, "w") as f:
        f.write(f"Model: {model_id}\n")
        f.write(f"Prompt: {prompt_id}\n")
        f.write(f"Latency: {round(time_per_sample, 2)} sec\n")
        f.write(f"Accuracy: {round(final_accuracy, 2)}\n")
    

def load_model(model_id, temperature):
    return EntityExtractor(model_name=model_id, temperature=temperature)


def load_data(data_path, samples_count, seed=12):
    with open(data_path, "r") as f:
        data = json.load(f)
    if samples_count > 0:
        random.seed(seed)
        data = random.sample(data, samples_count)
    return data


# generate data

def custom_zip_selected_entities(selected_entities: list, entity_placeholder: dict) -> list:
    """
    This function curates the selected entities based on the entity placeholder

    Args:
        selected_entities: list of selected entities
        entity_placeholder: entity placeholder dictionary
    Returns:
        curated_entities: list of curated entities
    """

    curated_entities = []
    for entity_tup in selected_entities:
        entity_dict = {}
        for i, ph_entity in enumerate(entity_placeholder.keys()):
            entity_dict[ph_entity] = entity_tup[i]
        curated_entities.append(entity_dict)
    return curated_entities


def make_permutations_and_select(entityset: pd.DataFrame, num_selection: int, entity_placeholder: dict) -> list:
    """
    This function makes permutations of entities and selects a few of them
    Args:
        entityset: entityset to make permutations
        num_selection: number of permutations to select
        entity_placeholder: entity placeholder dictionary
    Returns:
        selected_permutations: list of selected permutations
    """

    r = len(entity_placeholder)
    npr_unique_permutations = list(permutations(entityset.to_dict(orient="records"), r))
    logger.info(f"Total permutations: {len(npr_unique_permutations)}")

    subset_permutations = []
    for permut in npr_unique_permutations:
        flag = True
        for i, (entity_k, entity_type) in enumerate(entity_placeholder.items()):
            if permut[i]["entity_type"] not in [element.strip() for element in entity_type.split("|")]:
                flag = False
                break
        if flag:
            subset_permutations.append(permut)

    logger.info(f"Available permutations: {len(subset_permutations)}")

    if num_selection >= len(subset_permutations):
        logger.warning(f"num_selection is greater than available permutations. Selecting all available permutations")
        return subset_permutations

    num_selection = min(num_selection, len(subset_permutations))
    selected_permutations = random.sample(subset_permutations, num_selection)

    return selected_permutations


def curate_question_with_entities(entities: list) -> list:
    """
    This function curates the question with the selected entities
    Args:
        entities: list of entities
    Returns:
        entity_filler_list: list of entity fillers
    """

    entity_filler_list = []
    for entity_dict in entities:
        entity_filler = {}
        for ph_entity, entity in entity_dict.items():
            entity_filler[ph_entity] = entity["entity"]
        entity_filler_list.append(entity_filler)

    return entity_filler_list


def sample_question_subject(subject_type_choices: Set[str], subjects: pd.DataFrame, exclude_ids: List[int]) -> Tuple[str, str, int]:
    """
    This function samples a subject for a question
    Args:
        subject_type_choices: set of subject types to choose from
        subjects: dataframe of subjects
        exclude_ids: list of entity ids to exclude
    Returns:
        subject: a tuple of entity, entity type and entity id
    """
    global GENERATOR_SEED
    choices = subjects[subjects.entity_type.isin(subject_type_choices) & ~(subjects.entity_id.isin(exclude_ids))]
    if len(choices) == 0:
        raise ValueError("No valid subjects to choose from")
    subject = choices.sample(1, random_state=GENERATOR_SEED)
    return subject.entity.values[0], subject.entity_type.values[0], subject.entity_id.values[0]


def tokenize_text(text):
    """Tokenizes the input text into a list of tokens."""
    # return re.findall(r"[\w']+|[.,!?;:\/\\-]", text)
    return re.findall(r'\w+(?:[-_]\w+)*|\S', text)


def convert_entity_type_to_class(entity_type: str) -> str:
    if entity_type in subject_types["company_entity"] | subject_types["company_sf_entity"]:
        entity_class = "company"
    elif entity_type in subject_types["country_entity"] | subject_types["city_entity"] | subject_types["geography_adjective_entity"]:
        entity_class = "geography"
    elif entity_type in subject_types["industry_entity"]:
        entity_class = "industry"
    return entity_class


def gen_question(template: str, subject_types: dict, subjects: pd.DataFrame, exclude_ids: List[int]) -> Tuple[str, List[int], List[str]]:
    """
    This function generates a single question based on the template
    Args:
        template: question template
        subject_types: dictionary of subject types
        subjects: dataframe of subjects
        exclude_ids: list of entity ids to exclude
    Returns:
        question: a tuple of question, entity ids and entity types
    """
    # Get the first formatted string in the question template
    question = copy.copy(template)
    fstring = re.search(r"\{(\w+)\}", question)
    prev = None
    used_ids = []
    used_subject_types = []
    entity_spans = []
    original_entities = []

    # Loop through the {formatted entities} in the question template
    while fstring is not None:
        # Check if the subject type is valid
        if fstring.group(1) not in subject_types:
            raise ValueError(
                f"Subject type {fstring.group(1)} not found in subject_types, not a valid subject for the question"
            )

        # get the valid subjects for the current subject type given the previous subject - if the subject type is company_entity or company_sf_entity
        if fstring.group(1) == "company_entity" or fstring.group(1) == "company_sf_entity":
            # check if the previous entity can be paired to the current one
            if (prev is not None) and (len(subject_types[fstring.group(1)] & multi_entity_rules[prev]) == 0):
                raise ValueError(f"Cannot compare {prev} to {fstring.group(1)}")
            subject_type_choices = subject_types[fstring.group(1)] if prev is None else multi_entity_rules[prev]
        # for geography and industry, the subject type is choosen from entity placeholder, not from the previous entity
        else:
            subject_type_choices = subject_types[fstring.group(1)]

        # Should be made more generic for subjects that are not entities in the future
        entity, entity_type, entity_id = sample_question_subject(subject_type_choices, subjects, exclude_ids + used_ids)
        used_ids.append(entity_id)
        used_subject_types.append(entity_type)

        # question is changed with each entity insertion, so we need to find the index of the current entity in the tokenized question
        tokenized_text = tokenize_text(question)
        # index of first placeholder entity
        for i in range(len(tokenized_text)):
            if fstring.group(0) == tokenized_text[i] + tokenized_text[i+1] + tokenized_text[i+2]:
                start_word_index = i
                break
        # replace the placeholder entity with the chosen subject and get the next placeholder entity
        question = question.replace(fstring.group(0), entity, 1)
        # end index of inserted entity
        end_word_index = start_word_index + len(tokenize_text(entity)) - 1
        entity_spans.append([start_word_index, end_word_index, convert_entity_type_to_class(entity_type)])
        original_entities.append(entity)

        fstring = re.search(r"\{(\w+)\}", question)
        prev = entity_type
    
    tokenized_question = tokenize_text(question)
    return question, used_ids, used_subject_types, entity_spans, tokenized_question, original_entities


def generate_for_template(template: str, subject_types: Dict[str, Set[str]], subjects: pd.DataFrame, num_combinations: int = 3) -> List[Tuple[str, List[int], List[str]]]:
    """
    This function generates questions for a given template
    Args:
        template: question template
        subject_types: dictionary of subject types
        subjects: dataframe of subjects
        num_combinations: number of combinations of entities per question to generate
    Returns:
        questions: list of tuples of questions, entity ids and entity types
    """
    questions = []
    exclude_ids = []

    question = copy.copy(template)
    fstring = re.search(r"\{(\w+)\}", question)
    if fstring is None:
        num_combinations = 1

    for _ in range(num_combinations):
        try:
            question, used_ids, used_subject_types, entity_spans, tokenized_question, original_entities = gen_question(template, subject_types, subjects, exclude_ids)
            exclude_ids.extend(used_ids)
            questions.append((question, used_ids, used_subject_types, entity_spans, tokenized_question, original_entities))
        except ValueError as e:
            logger.error(e)
            logger.debug(
                f"""
                For Generating question for template: {template}
                Question: {template}
                Entity IDs: {exclude_ids}
                """
            )
    return questions


def question_generator(question_template: dict, entityset: pd.DataFrame, num_combinations: int, seed: int) -> list:
    """
    This function generates questions based on the question template and entity data provided
    Args:
        question_template: dictionary of question templates
        entityset: entityset to draw entities from
        num_combinations: number of combinations of entities per question to generate
    Returns:
        curated_question_set: list of dictionaries of curated questions (question, entity_id, question_type, entity_type)
    """
    global GENERATOR_SEED
    GENERATOR_SEED = seed
    curated_question_set = []
    for q_type in tqdm(question_template.keys()):
        for template in question_template[q_type]:
            questions = filter(
                lambda x: x is not None, generate_for_template(template, subject_types, entityset, num_combinations)
            )
            for q_string, ids, types, entity_spans, tokenized_question, original_entities in questions:
                curated_question_set.append(
                    {
                        "question": q_string,
                        "entity_id": list(map(int, ids)),
                        "question_type": q_type,
                        "ner": entity_spans,
                        "tokenized_text": tokenized_question,
                        "input_entities": original_entities,
                    }
                )
    return curated_question_set
