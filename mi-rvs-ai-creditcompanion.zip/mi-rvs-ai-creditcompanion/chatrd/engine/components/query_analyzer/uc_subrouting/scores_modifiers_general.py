import logging
from typing import Optional, Union

from chatrd.core.llm import LCLLMFactory
from chatrd.engine.components.query_analyzer.faulttolerantexecutor import (
    FaultTolerantExecutor,
)
from chatrd.engine.components.query_analyzer.uc_subrouting.prompt_templates import (
    SCORES_MODIFIERS_TRIGGERS_PROMPT,
    add_company_name_to_prompt,
    parser_scores_modifiers_subrouting,
)

logger = logging.getLogger(__name__)


class ScoresModifiersSubrouter(FaultTolerantExecutor):
    def __init__(self, model_name: str, temperature: Optional[float] = 0.0):
        self.model = LCLLMFactory().get_llm(
            deployment_name_or_model_id=model_name,
            temperature=temperature,
        )

        self.output_parser = parser_scores_modifiers_subrouting
        self.prompt_template = SCORES_MODIFIERS_TRIGGERS_PROMPT

    def run(self, query: str, entities_input: Optional[str] = "") -> Union[str, None]:
        # constants and parameters
        METRICS_REMAIN_SM = [
            "BICRA",
            "CICRA",
            "IICRA",
            "SACP",
            "Stand Alone Credit Profile",
            "Anchor",
            "Comparable Rating Analysis",
            "Comparable Ratings Analysis",
        ]
        new_uc_type = None
        UC_GENERAL = "general"
        UC_S_AND_M = "scores&modifiers"
        # retriever: Metric, Triggers, and Impact identifiers
        question_prompt = self.prompt_template.format(question=query, entities_input=entities_input)
        output = self.model.invoke(question_prompt)
        retriever_result = self.output_parser.invoke(output)
        retriever_result_dict = retriever_result.model_dump(exclude="ChainOfThought")
        logger.info(f"ScoresModifiersSubrouter output: {retriever_result_dict}")
        # print(retriever_result_dict)
        # subrouting logic input
        subrouting_input = (
            retriever_result_dict["Impact"] is not None,
            retriever_result_dict["Trigger"] is not None,
            retriever_result_dict["AnyMetric"] is not None,
            retriever_result_dict["Metric"] is not None,
            retriever_result_dict["Metric"] in METRICS_REMAIN_SM,
        )
        # use case subrouting
        match subrouting_input:
            case True, _, _, _, _:
                new_uc_type = UC_GENERAL
            case False, False, _, _, False:
                new_uc_type = UC_GENERAL
            case False, False, _, _, True:
                new_uc_type = UC_S_AND_M
            case False, True, False, _, _:
                new_uc_type = UC_S_AND_M
            case False, True, True, True, _:
                new_uc_type = UC_S_AND_M
            case False, True, True, False, _:
                new_uc_type = UC_GENERAL
        return new_uc_type
