from dotenv import load_dotenv
load_dotenv()


from chatrd.engine.components.query_analyzer.translator.translator import InputModerationTranslator
from tqdm import tqdm 
import numpy as np
from chatrd.core.embedding import embedding_factory
import json 
import nltk
from nltk.translate import meteor_score
from bert_score import score
import bert_score



models = {
        "BEDROCK": [
            "us.anthropic.claude-3-5-sonnet-20241022-v2:0",
            # "anthropic.claude-3-sonnet-20240229-v1:0",
            # "anthropic.claude-3-haiku-20240307-v1:0",
        ]
    }



English_lines = []
with open('eevaluations/data/translation_data/English.txt', 'r') as file:
    lines = file.read()
    English_lines = lines.split('\n')
    # print('English_lines', len(English_lines))


French_lines = []
with open('evaluations/data/translation_data/French.txt', 'r') as file:
    lines = file.read()
    French_lines = lines.split('\n')
    # print('French_lines', len(French_lines))

Japanese_lines = []
with open('evaluations/data/translation_data/Japanese.txt', 'r') as file:
    lines = file.read()
    Japanese_lines = lines.split('\n')
    # print('Japanese_lines', len(Japanese_lines))

Korean_lines = []
with open('evaluations/data/translation_data/Korean.txt', 'r') as file:
    lines = file.read()
    Korean_lines = lines.split('\n')
    # print('Korean_lines', len(Korean_lines))


Mandarin_lines = []
with open('evaluations/data/translation_data/data/Mandarin.txt', 'r') as file:
    lines = file.read()
    Mandarin_lines = lines.split('\n')
    # print('Mandarin_lines', len(Mandarin_lines))

Spanish_lines = []
with open('evaluations/data/translation_data/data/Spanish.txt', 'r') as file:
    lines = file.read()
    Spanish_lines = lines.split('\n')
    # print('Spanish_lines', len(Spanish_lines))

import pandas as pd 
# make dataframe from lines: 
data = pd.DataFrame({
    'english':English_lines,
    'french':French_lines,
    'japanese': Japanese_lines,
    'korean': Korean_lines,
    'mandarin': Mandarin_lines,
    'spanish': Spanish_lines,
    
})

similarity_model = embedding_factory(model_name='titan-v2')
# data = data.head(2)
data['targets'] = data['english']
data = data.drop('english', axis=1)


def cosine_similarity(pred_vector, target_vector):
    similarity = np.dot(pred_vector, target_vector) / (np.linalg.norm(pred_vector) * np.linalg.norm(target_vector))
    return similarity


embedding_model = embedding_factory(model_name='titan-v2')



def calculate_bleu_score(predicted_text,original_text):
    reference = nltk.word_tokenize(original_text)
    candidate = nltk.word_tokenize(predicted_text)
    return nltk.translate.bleu_score.sentence_bleu([reference], candidate)

def calculate_meteor_score(predicted_text, original_text):
    # Implement the METEOR score calculation here
    predicted_tokens = nltk.word_tokenize(predicted_text)
    original_tokens = nltk.word_tokenize(original_text)
    return meteor_score.single_meteor_score(original_tokens, predicted_tokens)

def calculate_bertscore(predicted_text, original_text):
    P, R, F1 = score([predicted_text], [original_text], lang="en", verbose=False)
    return F1.item()

translation_dict = {}
for mod, model_name in tqdm(enumerate(models['BEDROCK'])):
    translator = InputModerationTranslator(model_name=model_name)
    for col in tqdm(data.columns):
        # chech if col is contained from  "translate" 
        if col=='targets' or ( '_' in col):
            continue
        translations =  data[col].apply(lambda x:  translator.run(x) )
        similarities = [cosine_similarity(embedding_model.embed_query( translate['translated_text'] ),embedding_model.embed_query(original)) for translate,original in zip(translations, data['targets'].values)]
        data[col+'_similarities_' + str(mod) ] = similarities
        bleu_scores =  [calculate_bleu_score(translate['translated_text'] ,original) for translate,original in zip(translations, data['targets'].values)]
        data[col+'_bleu_' + str(mod) ] = bleu_scores
        meteor_scores = [calculate_meteor_score(translate['translated_text'], original) for translate, original in zip(translations, data['targets'].values)]
        data[col+'_meteor_' + str(mod)] = meteor_scores
        bertscore_values = [calculate_bertscore(translate['translated_text'], original) for translate, original in zip(translations, data['targets'].values)]
        data[col+'_bertscore_' + str(mod)] = bertscore_values

metrics = ['similarities','bleu','meteor','bertscore']
for mod, model in enumerate(models['BEDROCK']):

    for metric in metrics:
        selected_cols = [col for col in data.columns if metric in col and col[-1]==str(mod)]
        dt = data[selected_cols]
        # calculate average of cols 
        data[str(mod)+'_absalute_' + metric] = dt.mean(axis=1)


    
data.to_excel('result.xlsx')