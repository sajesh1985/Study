import pandas as pd


class ColumnInfo:
    def __init__(self, name, dtype, description, aliases=None, special_handling=None):
        self.name = name
        self.dtype = dtype
        self.description = description
        self.aliases = aliases if aliases else []
        self.special_handling = special_handling

    def to_dict(self):
        return {
            "Column Name": self.name,
            "Data Type": self.dtype,
            "Description": self.description,
            "Aliases": ", ".join(self.aliases) if self.aliases else "",
            "Special Handling": self.special_handling if self.special_handling else "",
        }

    def __repr__(self):
        return (
            f"ColumnInfo(name={self.name}, dtype={self.dtype}, description={self.description}, "
            f"aliases={self.aliases}, special_handling={self.special_handling})"
        )


class DataFrame:
    def __init__(
        self,
        df,
        name,
        description,
        column_info,
        special_instructions,
        table_key_text: str = "",
        sample_data_number: int = 50,
    ):
        self.df = df
        self.name = name
        self.description = description
        self.column_info = {}
        self.special_instructions = special_instructions
        self.sample_data_number = sample_data_number
        self.table_key_text = table_key_text
        # self.table_key_values = table_key_values
        self.column_info_df = pd.DataFrame(
            columns=[
                "Column Name",
                "Data Type",
                "Description",
                "Aliases",
                "Special Handling",
            ]
        )

        for col_name, info in column_info.items():
            self.add_column_info(col_name, **info)

    def add_column_info(self, column_name, dtype, description, aliases=None, special_handling=None):
        if column_name in self.df.columns:
            column_info = ColumnInfo(column_name, dtype, description, aliases, special_handling)
            self.column_info[column_name] = column_info

            new_row = pd.DataFrame([column_info.to_dict()])
            self.column_info_df = pd.concat([self.column_info_df, new_row], ignore_index=True)
        else:
            raise ValueError(f"Column '{column_name}' does not exist in the DataFrame.")

    def get_schema(self):
        schema = {
            "Name": self.name,
            "Table Description": self.description,
            "Columns": self.column_info_df.to_markdown(index=False),
            "Sample Data": self.df.head(self.sample_data_number).to_markdown(index=False),
            "Table Key Text": self.table_key_text,
            # "Table Key Values": self.table_key_values.to_markdown(index=False),
            "Special Instructions": self.special_instructions,
        }
        return schema
