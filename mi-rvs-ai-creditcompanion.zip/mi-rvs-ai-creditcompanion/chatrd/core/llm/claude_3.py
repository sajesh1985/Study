import json
import logging
from typing import Dict, Generator, List, Optional, Union

from botocore.client import BaseClient

from chatrd.core.llm.base import LLM
from chatrd.core.llm.bedrock_anthropic import get_num_tokens_bedrock_anthropic
from chatrd.core.llm.components.message import AIMessage, AIMessageChunk
from chatrd.core.llm.tools.schema import ToolChoice, ToolRequestQutput, ToolSchema
from chatrd.core.utils import GuardrailOutput

logger = logging.getLogger(__name__)


class Claude3(LLM):
    def __init__(
        self,
        client: BaseClient,
        model_id: str,
        temperature: Optional[float] = 0.0,
        max_tokens: Optional[int] = 1024,
        model_kwargs: Optional[Dict] = {},
    ):
        self.client = client
        self.temperature = model_kwargs["temperature"] if "temperature" in model_kwargs else temperature
        self.model_id = model_id
        self.anthropic_version = "bedrock-2023-05-31"
        self.max_tokens = model_kwargs["max_tokens_to_sample"] if "max_tokens_to_sample" in model_kwargs else max_tokens
        self.guardrail_identifier = (
            model_kwargs["guardrail_identifier"] if "guardrail_identifier" in model_kwargs else None
        )
        self.guardrail_version = model_kwargs["guardrail_version"] if "guardrail_version" in model_kwargs else None
        self.reasoning_config = model_kwargs["reasoning_config"] if "reasoning_config" in model_kwargs else None

    def invoke(self, inputs: str) -> AIMessage:
        logger.info(f"invoke mode called for claude 3 with model id : {self.model_id}")
        input_data = json.dumps(
            {
                "messages": [{"role": "user", "content": inputs}],
                "anthropic_version": self.anthropic_version,
                "max_tokens": self.max_tokens,
                "temperature": self.temperature,
            }
        )
        if self.guardrail_identifier and self.guardrail_version:
            response = self.client.invoke_model(
                contentType="application/json",
                body=input_data,
                modelId=self.model_id,
                guardrailIdentifier=self.guardrail_identifier,
                guardrailVersion=self.guardrail_version,
                trace="ENABLED",
            )
            decoded_response = json.loads(response["body"].read().decode("utf-8"))
            return GuardrailOutput(
                message=decoded_response["content"][0]["text"],
                action=decoded_response["amazon-bedrock-guardrailAction"],
            )
        else:
            response = self.client.invoke_model(contentType="application/json", body=input_data, modelId=self.model_id)
            decoded_response = json.loads(response["body"].read().decode("utf-8"))
            return AIMessage(content=decoded_response["content"][0]["text"])

    def stream(self, inputs: str) -> Generator[AIMessageChunk, None, None]:
        logger.info(f"streaming mode called for claude 3 with model id : {self.model_id}")
        input_data = json.dumps(
            {
                "messages": [{"role": "user", "content": [{"type": "text", "text": inputs}]}],
                "anthropic_version": self.anthropic_version,
                "max_tokens": self.max_tokens,
                "temperature": self.temperature,
            }
        )
        if self.reasoning_config:
            stream = self.converse_with_stream(inputs, "", None, None, self.reasoning_config)
            for chunk in stream:
                yield chunk
        else:
            response = self.client.invoke_model_with_response_stream(
                contentType="application/json", body=input_data, modelId=self.model_id
            )
            stream = response.get("body")
            if stream:
                for event in stream:
                    chunk = event.get("chunk")
                    if chunk:
                        chunk_dict = json.loads(chunk.get("bytes").decode())
                        if "delta" in chunk_dict:
                            if "text" in chunk_dict["delta"]:
                                yield AIMessageChunk(content=chunk_dict["delta"]["text"])

    def converse(
        self,
        prompt: str,
        system_message: Optional[str] = "",
        tools: Optional[List[ToolSchema]] = None,
        tool_choice: Optional[ToolChoice] = None,
        reasoning_config: Optional[Dict] = None,
    ) -> Union[AIMessage, ToolRequestQutput]:
        system_prompt = [{"text": system_message}]
        messages = [{"role": "user", "content": [{"text": prompt}]}]
        kwargs = {
            "temperature": self.temperature,
            "maxTokens": self.max_tokens,
            "topP": 0,
        }
        if tools:
            tools_config = {
                "tools": [],
                "toolChoice": tool_choice.schema if tool_choice else ToolChoice(choice="auto").schema,
            }
            for tool in tools:
                tools_config["tools"].append(tool.get_schema())
            response = self.client.converse(
                modelId=self.model_id,
                messages=messages,
                system=system_prompt if system_message else [],
                toolConfig=tools_config,
                inferenceConfig=kwargs,
                additionalModelRequestFields=reasoning_config if reasoning_config else self.reasoning_config,
            )
            output_message = response.get("output", {}).get("message", {})
            stop_reason = response.get("stopReason")

            if stop_reason == "tool_use":
                tools_requested = output_message.get("content", {})[0]["toolUse"]
                if tools_requested:
                    return ToolRequestQutput(
                        id=tools_requested["toolUseId"],
                        name=tools_requested["name"],
                        parameters=tools_requested["input"],
                    )
                raise Exception("No tool use found in response")
            elif stop_reason == "end_turn":
                return AIMessage(content=output_message["content"][0]["text"])
            else:
                return output_message
        else:
            response = self.client.converse(
                modelId=self.model_id,
                messages=messages,
                system=system_prompt if system_message else [],
                inferenceConfig=kwargs,
                additionalModelRequestFields=reasoning_config if reasoning_config else self.reasoning_config,
            )
            return AIMessage(content=response.get("output", {}).get("message", {})["content"][0]["text"])

    def converse_with_stream(
        self,
        prompt: str,
        system_message: Optional[str] = "",
        tools: Optional[List[ToolSchema]] = None,
        tool_choice: Optional[ToolChoice] = None,
        reasoning_config: Optional[Dict] = None,
    ) -> Union[AIMessage, ToolRequestQutput]:
        system_prompt = [{"text": system_message}]
        messages = [{"role": "user", "content": [{"text": prompt}]}]
        kwargs = {
            "temperature": self.temperature if not self.reasoning_config else 1.0,
            "maxTokens": self.max_tokens,
            "topP": 0 if not self.reasoning_config else 0.95,
        }
        response = self.client.converse_stream(
            modelId=self.model_id,
            messages=messages,
            system=system_prompt if system_message else [],
            inferenceConfig=kwargs,
            additionalModelRequestFields=reasoning_config if reasoning_config else self.reasoning_config,
        )
        stream = response.get("stream")
        if stream:
            for event in stream:
                chunk_dict = event.get("contentBlockDelta")
                if chunk_dict:
                    if "delta" in chunk_dict:
                        if "text" in chunk_dict["delta"]:
                            yield AIMessageChunk(content=chunk_dict["delta"]["text"])

    def get_num_tokens(self, text: str) -> int:
        return get_num_tokens_bedrock_anthropic(text)
