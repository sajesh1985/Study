// import { config } from '@spglobal/spa';
import { InfoFeedbackWindow } from '../../_common/InfoFeedbackWindow/InfoFeedbackWindow';
import { defaultSelectFiltersOptions } from './ColumnCheckboxSelector.model';

export const koiColumnDefs =  [
  {field: 'feedbackSentiment',headerName:'FEEDBACK SENTIMENT', sortable: true, autoHeight: true, minWidth: 138, maxWidth: 140, wrapText: true, cellStyle: {lineHeight: '15px',}},
  {field: 'feedbackText',headerName:'FEEDBACK TEXT', sortable: true, autoHeight: true, wrapText: true, cellStyle: {lineHeight: '15px', 'white-space': 'normal',}},
  {
    field: 'feedbackTags', 
    headerName: 'FEEDBACK TAGS',
    sortable: true,
    autoHeight: true,
    minWidth: 240,
    wrapText: true,
    cellStyle: {
      lineHeight: '15px'
    },
  },
  {
    field: 'userInputValue', 
    headerName: 'USER INPUT VALUE',
    sortable: true,
    resizable: true,
    autoHeight: true,
    cellStyle: {
      color: 'red',
      lineHeight: '15px',
      'white-space': 'normal', 
    },
    cellRendererFramework: InfoFeedbackWindow,
    cellRendererParams: (params: any) => ({
      linkText: params?.data?.userInputValue,
      sessionId: params?.data?.sessionId,
      interactionId: params?.data?.interactionId
    })
  },
  {field: 'requestTimeStamp', headerName: 'REQUEST TIME STAMP', sortable: true, autoHeight: true, minWidth: 148, maxWidth: 150, cellStyle: {lineHeight: '15px',}},
  {field: 'responseTimeStamp', headerName: 'RESPONSE TIME STAMP',sortable: true, autoHeight: true, minWidth: 148, maxWidth: 150, cellStyle: {lineHeight: '15px',}},
  {field: 'userInputType', headerName:'USER INPUT TYPE',sortable: true, autoHeight: true, minWidth: 106, maxWidth: 108, wrapText: true, cellStyle: {lineHeight: '15px',}},
  {field: 'sessionId', headerName:'SESSION ID',
    sortable: true, autoHeight: true, wrapText: true, minWidth: 128, maxWidth: 130, 
    cellStyle: {lineHeight: '15px',}
  },
  {field: 'interactionId', headerName:'INTERACTION ID',
    sortable: true, autoHeight: true, wrapText: true, minWidth: 128, maxWidth: 130,
    cellStyle: {lineHeight: '15px',}
  },
  {field: 'previousInteractionId', headerName:'PREVIOUS INTERACTION ID',
    sortable: true, autoHeight: true, wrapText: true, minWidth: 128, maxWidth: 130,
    cellStyle: {lineHeight: '15px',}
  }
]

export const chooseDefaultValues = koiColumnDefs.filter((el) =>
  defaultSelectFiltersOptions.filter1.some(
    (item) => item.value === el.field
  )
);
