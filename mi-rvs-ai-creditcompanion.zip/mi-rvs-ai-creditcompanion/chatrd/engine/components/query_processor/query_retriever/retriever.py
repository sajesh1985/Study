import logging
from typing import List

from chatrd.core.aws_utils.sagemaker import get_assumed_sagemaker_llm_client
from chatrd.core.document import Document
from chatrd.core.embedding import embedding_factory
from chatrd.core.vectorstore import OpenSearch
from chatrd.engine.components.query_processor.query_retriever.uc_retrievers import (  # BackupRetriever,
    CommonResearchRetriever,
    CreditMemoRetriever,
    CriteriaRetriever,
    DefinitionRetriever,
    GeneralRetriever,
    InfoCoverageUCRetriever,
    MacroRetriever,
    OutlookRetriever,
    PeersRetriever,
    QueryUCRetriever,
    RatingActionRetriever,
    RatingsRetriever,
    ResearchRetriever,
)
from chatrd.engine.components.query_processor.query_retriever.uc_retrievers.financial import (
    FinancialRetriever,
)
from chatrd.engine.components.query_processor.query_retriever.uc_retrievers.scores_modifiers import (
    ScoresModifierRetriever,
)
from chatrd.engine.components.query_processor.query_retriever.uc_retrievers.selected_article import (
    SelectedArticlesRetriever,
)
from chatrd.engine.components.query_processor.query_retriever.uc_retrievers.utils import (
    UCRetrieverType,
)
from chatrd.engine.components.schema import QueryAnalyzerOutput
from chatrd.engine.components.state_machine import StateMachine
from chatrd.engine.configuration import Constants, get_config_machinery

logger = logging.getLogger(__name__)

config_machinery = get_config_machinery()


def _get_vector_stores():
    host = config_machinery.get_config_value(Constants.OpenSearch.OPENSEARCH_HOST)
    port = config_machinery.get_config_value(Constants.OpenSearch.OPENSEARCH_PORT)
    user_name = config_machinery.get_config_value(Constants.OpenSearch.OPENSEARCH_USER_NAME)
    password = config_machinery.get_config_value(Constants.OpenSearch.OPENSEARCH_PASSWORD)
    criteria_index_name = config_machinery.get_config_value(Constants.GeneralConstants.CRITERIA_INDEX_NAME)
    research_index_name = config_machinery.get_config_value(Constants.GeneralConstants.RESEARCH_INDEX_NAME)
    definition_index_name = config_machinery.get_config_value(Constants.GeneralConstants.DEFINITION_INDEX_NAME)
    commentary_index_name = config_machinery.get_config_value(Constants.GeneralConstants.COMMENTARY_INDEX_NAME)
    embedding_model = embedding_factory(model_name="cohere-multi")
    criteria_vector_store = OpenSearch(host, port, user_name, password, criteria_index_name, embedding_model)
    research_vector_store = OpenSearch(host, port, user_name, password, research_index_name, embedding_model)
    definition_vector_store = OpenSearch(host, port, user_name, password, definition_index_name, embedding_model)
    commentary_vector_store = OpenSearch(host, port, user_name, password, commentary_index_name, embedding_model)
    vector_stores_dict = {
        "criteria": criteria_vector_store,
        "research": research_vector_store,
        "definition": definition_vector_store,
        "commentary": commentary_vector_store,
    }
    return vector_stores_dict


class QueryRetriever(StateMachine):
    def __init__(self):
        super().__init__(
            machine_role="QueryRetriever",
            failure_response="Query Retriever Failed.",
            success_response="Query Retriever Success.",
        )
        self._vector_stores_dict = _get_vector_stores()
        self.reranker_client = get_assumed_sagemaker_llm_client(
            role_arn=config_machinery.get_config_value(Constants.SageMaker.SAGEMAKER_ROLE_ARN),
            region_name=config_machinery.get_config_value(Constants.SageMaker.SAGEMAKER_REGION_NAME),
        )["sagemaker-runtime"]

    def _execute_internal(
        self,
        model_name_for_tool_classifier: str,
        temperature_for_tool_classfifer: float,
        model_name_for_data_service: str,
        temperature_for_data_service: float,
        analyzer_output: QueryAnalyzerOutput,
    ) -> List[Document]:
        retriever_query = analyzer_output.rephrased_query if analyzer_output.rephrased_query else analyzer_output.query
        if analyzer_output.uc_type == UCRetrieverType.CRITERIA.value:
            tool = CriteriaRetriever(vector_stores_dict=self._vector_stores_dict, reranker_client=self.reranker_client)
            documents = tool.retrieve(
                query=retriever_query, entities=analyzer_output.entities, sectors=analyzer_output.sectors
            )
        elif analyzer_output.uc_type in [
            UCRetrieverType.DEALS_TRANCHE.value,
            UCRetrieverType.RATINGS.value,
            UCRetrieverType.SECURITIES.value,
        ]:
            tool = RatingsRetriever(vector_stores_dict=self._vector_stores_dict, reranker_client=self.reranker_client)
            documents = tool.retrieve(
                query=retriever_query,
                uc_type=analyzer_output.uc_type,
                entities=analyzer_output.entities,
                model_name_for_data_service=model_name_for_data_service,
                temperature_for_data_service=temperature_for_data_service,
                sectors=analyzer_output.sectors,
                original_language=analyzer_output.original_language,
                original_query=analyzer_output.original_query,
                multi_uc_type=analyzer_output.multi_uc_type,
            )
        elif analyzer_output.uc_type == UCRetrieverType.OUTLOOK.value:
            logger.info(f"Geography : {analyzer_output.is_geo_or_region}")
            tool = OutlookRetriever(vector_stores_dict=self._vector_stores_dict, reranker_client=self.reranker_client)
            documents = tool.retrieve(
                query=retriever_query,
                entities=analyzer_output.entities,
                model_name_for_tool_classifier=model_name_for_tool_classifier,
                temperature_for_tool_classfifer=temperature_for_tool_classfifer,
                model_name_for_data_service=model_name_for_data_service,
                temperature_for_data_service=temperature_for_data_service,
                sectors=analyzer_output.sectors,
                subrouting_result=analyzer_output.subrouting_result,
                original_language=analyzer_output.original_language,
                original_query=analyzer_output.original_query,
                multi_uc_type=analyzer_output.multi_uc_type,
                is_geo_or_region=analyzer_output.is_geo_or_region,
            )
        elif analyzer_output.uc_type == UCRetrieverType.RATING_ACTION.value:
            tool = RatingActionRetriever(
                vector_stores_dict=self._vector_stores_dict, reranker_client=self.reranker_client
            )
            documents = tool.retrieve(
                query=retriever_query,
                entities=analyzer_output.entities,
                model_name_for_tool_classifier=model_name_for_tool_classifier,
                temperature_for_tool_classfifer=temperature_for_tool_classfifer,
                model_name_for_data_service=model_name_for_data_service,
                temperature_for_data_service=temperature_for_data_service,
                sectors=analyzer_output.sectors,
                original_language=analyzer_output.original_language,
                original_query=analyzer_output.original_query,
                multi_uc_type=analyzer_output.multi_uc_type,
            )

        elif analyzer_output.uc_type == UCRetrieverType.FINANCIALS.value:
            tool = FinancialRetriever(vector_stores_dict=self._vector_stores_dict, reranker_client=self.reranker_client)
            documents = tool.retrieve(
                query=analyzer_output.query,
                entities=analyzer_output.entities,
                model_name_for_tool_classifier=model_name_for_tool_classifier,
                temperature_for_tool_classfifer=temperature_for_tool_classfifer,
                model_name_for_data_service=model_name_for_data_service,
                temperature_for_data_service=temperature_for_data_service,
                sectors=analyzer_output.sectors,
                original_language=analyzer_output.original_language,
                original_query=analyzer_output.original_query,
                multi_uc_type=analyzer_output.multi_uc_type,
            )
        elif analyzer_output.uc_type == UCRetrieverType.RESEARCH.value:
            tool = ResearchRetriever(vector_stores_dict=self._vector_stores_dict, reranker_client=self.reranker_client)
            documents = tool.retrieve(
                query=retriever_query,
                entities=analyzer_output.entities,
                uc_type=analyzer_output.uc_type,
                model_name_for_tool_classifier=model_name_for_tool_classifier,
                temperature_for_tool_classififer=temperature_for_tool_classfifer,
                original_language=analyzer_output.original_language,
                original_query=analyzer_output.original_query,
            )

        elif analyzer_output.uc_type in [
            UCRetrieverType.ESG.value,
            UCRetrieverType.SWOT.value,
        ]:
            tool = CommonResearchRetriever(
                vector_stores_dict=self._vector_stores_dict, reranker_client=self.reranker_client
            )
            documents = tool.retrieve(
                query=retriever_query,
                entities=analyzer_output.entities,
                uc_type=analyzer_output.uc_type,
                model_name_for_data_service=model_name_for_data_service,
                temperature_for_data_service=temperature_for_data_service,
                sectors=analyzer_output.sectors,
                original_language=analyzer_output.original_language,
                original_query=analyzer_output.original_query,
            )
        elif analyzer_output.uc_type == UCRetrieverType.PEERS.value:
            tool = PeersRetriever(vector_stores_dict=self._vector_stores_dict, reranker_client=self.reranker_client)
            documents = tool.retrieve(
                query=retriever_query,
                entities=analyzer_output.entities,
                uc_type=analyzer_output.uc_type,
                model_name_for_data_service=model_name_for_data_service,
                temperature_for_data_service=temperature_for_data_service,
                sectors=analyzer_output.sectors,
                original_language=analyzer_output.original_language,
                original_query=analyzer_output.original_query,
                multi_uc_type=analyzer_output.multi_uc_type,
            )
        elif analyzer_output.uc_type == UCRetrieverType.SCORES_MODIFIER.value:
            tool = ScoresModifierRetriever(
                vector_stores_dict=self._vector_stores_dict, reranker_client=self.reranker_client
            )
            documents = tool.retrieve(
                query=retriever_query,
                entities=analyzer_output.entities,
                model_name_for_data_service=model_name_for_data_service,
                temperature_for_data_service=temperature_for_data_service,
                sectors=analyzer_output.sectors,
                original_language=analyzer_output.original_language,
                original_query=analyzer_output.original_query,
                multi_uc_type=analyzer_output.multi_uc_type,
            )
        elif analyzer_output.uc_type == UCRetrieverType.DEFINITION.value:
            tool = DefinitionRetriever(vector_stores_dict=self._vector_stores_dict)
            documents = tool.retrieve(query=retriever_query, sectors=analyzer_output.sectors)
        elif (
            analyzer_output.uc_type == UCRetrieverType.GENERAL.value
            or analyzer_output.uc_type == UCRetrieverType.MACRO.value
        ):
            logger.info(f"Geography : {analyzer_output.is_geo_or_region}")
            tool = GeneralRetriever(vector_stores_dict=self._vector_stores_dict, reranker_client=self.reranker_client)
            documents = tool.retrieve(
                query=retriever_query,
                entities=analyzer_output.entities,
                uc_type=analyzer_output.uc_type,
                model_name_for_data_service=model_name_for_data_service,
                temperature_for_data_service=temperature_for_data_service,
                sectors=analyzer_output.sectors,
                extracted_timeframe=analyzer_output.extracted_timeframe,
                tagged_routes=analyzer_output.tagged_routes,
                is_geo_or_region=analyzer_output.is_geo_or_region,
            )
        elif analyzer_output.uc_type == UCRetrieverType.MACRO.value:
            tool = MacroRetriever(vector_stores_dict=self._vector_stores_dict, reranker_client=self.reranker_client)
            documents = tool.retrieve(
                query=analyzer_output.query,
                entities=analyzer_output.entities,
                model_name_for_data_service=model_name_for_data_service,
                temperature_for_data_service=temperature_for_data_service,
                uc_type=analyzer_output.uc_type,
                sectors=analyzer_output.sectors,
            )
        elif analyzer_output.uc_type == UCRetrieverType.QUERY.value:
            tool = QueryUCRetriever()
            documents = tool.retrieve(
                query=retriever_query,
                uc_type=analyzer_output.uc_type,
                entities=analyzer_output.entities,
                model_name_for_data_service=model_name_for_data_service,
                temperature_for_data_service=temperature_for_data_service,
                sectors=analyzer_output.sectors,
                original_language=analyzer_output.original_language,
                original_query=analyzer_output.original_query,
                multi_uc_type=analyzer_output.multi_uc_type,
            )
        elif analyzer_output.uc_type == UCRetrieverType.INFO_COVERAGE.value:
            tool = InfoCoverageUCRetriever()
            documents = tool.retrieve(
                query=retriever_query,
                uc_type=analyzer_output.uc_type,
                entities=analyzer_output.entities,
                model_name_for_data_service=model_name_for_data_service,
                temperature_for_data_service=temperature_for_data_service,
                sectors=analyzer_output.sectors,
                original_language=analyzer_output.original_language,
                original_query=analyzer_output.original_query,
                multi_uc_type=analyzer_output.multi_uc_type,
            )
        elif analyzer_output.uc_type == UCRetrieverType.CREDIT_MEMO.value:
            tool = CreditMemoRetriever(
                vector_stores_dict=self._vector_stores_dict, reranker_client=self.reranker_client
            )
            documents = tool.retrieve(
                query=retriever_query,
                entities=analyzer_output.entities,
                model_name_for_data_service=model_name_for_data_service,
                temperature_for_data_service=temperature_for_data_service,
                entity_type=analyzer_output.entity_type,
                sectors=analyzer_output.sectors,
                original_language=analyzer_output.original_language,
                original_query=analyzer_output.original_query,
            )
        elif analyzer_output.uc_type == UCRetrieverType.SELECTED_ARTICLE.value:
            tool = SelectedArticlesRetriever(
                vector_stores_dict=self._vector_stores_dict, reranker_client=self.reranker_client
            )
            documents = tool.retrieve(
                query=retriever_query,
                uc_type=analyzer_output.uc_type,
                list_of_tagged_entities=analyzer_output.list_of_tagged_entities,
            )
        else:
            logger.error(f"Unhandled use case type: {analyzer_output.uc_type}")
            raise Exception("No tool implemented for this use case type.")

        documents = tool.add_additional_metadata_to_documents(
            uc_type=analyzer_output.uc_type, user_query=None, entity=None, documents=documents
        )
        return documents
