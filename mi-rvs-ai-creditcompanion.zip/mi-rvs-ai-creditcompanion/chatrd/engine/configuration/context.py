"""Collection of ContextVars holding basic configurations"""

from contextvars import ContextVar
from typing import Optional

from chatrd.engine.configuration import Constants, get_config_machinery

config_machinery = get_config_machinery()


def get_config(config_key: str, default: Optional[any] = None) -> str:
    return config_machinery.get_config_value(config_key, default)


# API contexts
DEFAULT_ENV = "dev"
DEFAULT_TOKEN_DURATION = 7000

ratings_api_ctx = ContextVar(
    "ratings_api_ctx",
    default={
        "service_username": get_config(Constants.RatingsAPI.RATINGS_API_USER),
        "service_password": get_config(Constants.RatingsAPI.RATINGS_API_PASS),
        "api_env": get_config(Constants.RatingsAPI.RATINGS_API_ENV, DEFAULT_ENV),
        "token_duration": get_config(Constants.RatingsAPI.RATINGS_API_TOKEN_DURATION, DEFAULT_TOKEN_DURATION),
    },
)

search_api_ctx = ContextVar(
    "search_api_ctx",
    default={
        "service_username": get_config(Constants.SearchAPI.SEARCH_API_USER),
        "service_password": get_config(Constants.SearchAPI.SEARCH_API_PASS),
        "api_env": get_config(Constants.SearchAPI.SEARCH_API_ENV, DEFAULT_ENV),
        "token_duration": get_config(Constants.SearchAPI.SEARCH_API_TOKEN_DURATION, DEFAULT_TOKEN_DURATION),
    },
)

sc_cfg = Constants.ScreenerAPI
screener_env = get_config(sc_cfg.SCREENER_API_ENV, DEFAULT_ENV).lower()
password_key = sc_cfg.SCREENER_API_PASS_PROD if screener_env == "prod" else sc_cfg.SCREENER_API_PASS
screener_api_ctx = ContextVar(
    "screener_api_ctx",
    default={
        "service_username": get_config(sc_cfg.SCREENER_API_USER),
        "service_password": get_config(password_key),
        "api_env": screener_env,
        "token_duration": get_config(sc_cfg.SCREENER_API_TOKEN_DURATION, DEFAULT_TOKEN_DURATION),
    },
)
