#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Copyright (C) S&P Global. All Rights Reserved.
NOTICE: All information contained herein is, and remains the  property of S&P Global and its suppliers,
if any. The intellectual and technical concepts contained herein are  proprietary to S&P Global and its suppliers and
may be covered by U.S. and Foreign Patents, patents in process,  and are protected by trade secret or copyright law.
Dissemination of this information or reproduction of this  material is strictly forbidden unless prior written
permission is obtained from S&P Global.
"""

import json
import logging
import os
from concurrent.futures import as_completed
from dataclasses import dataclass
from typing import List, Optional, Set

from numpy.typing import NDArray
from pandas import DataFrame

from chatrd.core.thread_utils import submit_to_shared_thread_pool
from chatrd.engine.configuration import get_config_machinery
from chatrd.engine.data_service.locator import main_directory
from chatrd.engine.data_service.vector_database.vector_database import (
    load_and_format_KPQI_data,
)

logger = logging.getLogger(__name__)

config_machinery = get_config_machinery()


@dataclass
class Perspective:
    name: str
    examples: List[str]
    operators: Optional[Set[str]] = None
    connectors: Optional[Set[str]] = None
    embeddings: Optional[NDArray] = None
    kpqi_data: Optional[DataFrame] = None

    def __init__(
        self,
        name: str,
        examples: List[str],
        operators: Optional[List[str]] = None,
        connectors: Optional[List[str]] = None,
        vectors_path: Optional[str] = None,
    ):
        self.name = name
        self.examples = []

        for example_fp in examples:
            with open(main_directory(example_fp), "rt") as f:
                logger.info(f"Loading llm prompts examples for <{name}> perspective from {example_fp}")
                self.examples.extend(json.load(f))

        self.operators = operators
        self.connectors = connectors
        # if vectors_path:
        #     self.load_vectors(vectors_path)

    def examples_to_few_shot_format(self) -> str:
        """
        Function to generate few shot examples string generated from examples list
            examples - list of dictionary where is element has a keys: prompt and payload
        Returns:
            Multiline string where each line has the following format:
            "prompt from user" -> {payload}
        """
        return "\n".join([e["prompt"] + " -> " + json.dumps(e["payload"]) for e in self.examples])

    def load_vectors(self, vectors_path: str) -> None:
        """
        Function to load necessary vector objects
        Args:
            vectors_path: The path to the folder containing the embedding data for each perspective
        """
        if vectors_path:
            logger.info(f"Loading KPQI data for <{self.name}> perspective...")
            data_path = os.path.join(vectors_path, f"{self.name}_embedding_data.parquet")
            self.kpqi_data = load_and_format_KPQI_data(data_path=data_path)
            logger.info(f"Loaded KPQI data for <{self.name}> perspective...")


DEFAULT_PERSPECTIVES = None


def default_perspectives(vectors_path: str = None) -> List[Perspective]:
    """
    Get the object for each Screener perspective.

    If there are none, create defaults one. Otherwise, reuse the existing ones.
    Args:
        vectors_path (str): the path to the in-memory data store.
    Returns: A list of Perspective objects.
    """
    if vectors_path is None:
        vectors_path = os.getenv("DATASERVICE_VECTOR_PATH")
    global DEFAULT_PERSPECTIVES
    if not DEFAULT_PERSPECTIVES:
        DEFAULT_PERSPECTIVES = [
            Perspective(
                name="company",
                examples=[
                    "config/perspectives/company.json",
                    "config/perspectives/company_ratings.json",
                ],
                vectors_path=vectors_path,
            ),
            Perspective(
                name="securities",
                examples=["config/perspectives/security_summary.json"],
                vectors_path=vectors_path,
            ),
            Perspective(
                name="revenue_sources",
                examples=["config/perspectives/revenue_source.json"],
                vectors_path=vectors_path,
            ),
        ]

        futures = {
            submit_to_shared_thread_pool(p.load_vectors, vectors_path=vectors_path): p.name
            for p in DEFAULT_PERSPECTIVES
        }

        for future in as_completed(futures):
            future.result()
    return DEFAULT_PERSPECTIVES
