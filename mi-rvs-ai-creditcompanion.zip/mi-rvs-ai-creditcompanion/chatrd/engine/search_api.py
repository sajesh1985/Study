import json
import logging
from typing import Dict, List, Tuple
from urllib.parse import parse_qs, urlparse

from requests import Session

from chatrd.core.contextvar_utils import user_ctx_var
from chatrd.core.utils import safe_get
from chatrd.engine.auth_api import AuthAPI
from chatrd.engine.configuration import Constants, search_api_ctx

logger = logging.getLogger(__name__)


class SearchAPI(AuthAPI):

    def __init__(self):
        super().__init__(api_name="SearchAPI", api_ctx=search_api_ctx)
        self.DEFAULT_MAX_RESULTS = self.get_config(Constants.SearchAPI.SEARCH_API_MAX_RESULTS)

    def get_url(self):
        base_url = self.get_config(Constants.APIServiceURL.BASE_URL)
        search_api_url = self.get_config(Constants.APIServiceURL.SEARCH_API_URL_SLUG)
        return base_url + search_api_url

    def _get_headers(self, cookie_authentication: bool = False) -> Dict[str, str]:
        if cookie_authentication:
            ctx_value: dict = user_ctx_var.get()
            cookie = ctx_value.get("cookie", None)
            if cookie:
                return {
                    "Content-Type": "application/json",
                    "Cookie": cookie,
                }
            else:
                logger.info("No cookie found in context, fetching token from service account")

        return {
            "Content-Type": "application/json",
            "Authorization": self.get_service_token(),
        }

    def get_entity(self, query: str, security_indicator: bool, max_results: int = None):
        """Get an entity and related context from the search API based on the provided query and security indicator.
        Args:
            query (str): The search query string.
            security_indicator (bool): Indicates if the search is for a security.
            max_results (int, optional): Maximum number of results to return. Defaults to SEARCH_API_MAX_RESULTS.
        """
        if not max_results:
            max_results = self.get_config(Constants.SearchAPI.SEARCH_API_MAX_RESULTS)
        url = self.get_url()
        headers = self._get_headers(cookie_authentication=True)

        if security_indicator:
            typeahead_card_names = ["fixed_income_rd-gss-typeahead"]
        else:
            typeahead_card_names = [
                "countries-gss-typeahead",
                "combined_companies_mi-gss-typeahead",
                "revenue_source-gss-typeahead",
                "fixed_income_rd-gss-typeahead",
            ]

        data = json.dumps(
            {
                "query": query,
                "max_results": max_results,
                "typeahead_card_names": typeahead_card_names,
            }
        )

        logger.info(f"Calling SearchAPI on {self._env.upper()} with the URL: {url}")
        with Session() as s:
            logger.debug("Calling Search API.")
            response = s.post(url, headers=headers, data=data)

        if response.status_code == 200:
            search_response = response.json()
            destinations = safe_get(search_response, ["destinations"], default=[])
            if not destinations:
                logger.warning(
                    f"Warning, not found any destination in SearchAPI response.\n"
                    f"Data payload: {data}\n  Response: {search_response}"
                )
                return None, None, None

            top_match, suggested_matches = self._get_top_matches(search_response)
            top_match_entity_context = self._get_entity_context(top_match)
            suggested_entities_context = []
            for suggested_match in suggested_matches:
                suggested_entities_context.append(self._get_entity_context(suggested_match))
            filtered_entities_context = self._filter_suggested_entities(
                suggested_entities_context, top_match_entity_context["EntityType"]
            )

            return top_match_entity_context, url, filtered_entities_context
        else:
            logger.error(f"Some error occurred with querying on search api, status code : {response.status_code}")
            response.raise_for_status()

    @staticmethod
    def _filter_suggested_entities(suggested_entities: List[dict], top_match_entity_type: str) -> List[dict]:
        """"""
        filtered_entities = []
        for item in suggested_entities:
            is_rd_entity = item["RD"] if "RD" in item else False
            # filter out RD entities, but skip the security suggestions if top match is not security, and keep the security type if top match is security
            if is_rd_entity and (top_match_entity_type == "Security" or item["EntityType"] != "Security"):
                filtered_entities.append(item)
        # sort in desc order by calculated score
        filtered_entities.sort(key=lambda x: x["calculated_score"], reverse=True)
        # set max results to 5
        if len(filtered_entities) > 5:
            filtered_entities = filtered_entities[:5]

        return filtered_entities

    def _get_top_matches(self, search_response: Dict) -> Tuple[Dict, List[dict]]:
        """Extracts the top match and suggested matches from the search API response."""
        # top match may be at index 0 or 1
        try:
            top_match = None
            top_match_idx = None

            destinations = safe_get(search_response, ["destinations"], default=[])
            top_match1 = safe_get(destinations, [0])
            if len(destinations) > 1:
                top_match2 = destinations[1]
                if top_match1.get("name") == top_match2.get("name"):
                    for comment in safe_get(top_match1, ["comments"], default=[]):
                        if (comment["contentType"] == "card_type") and (comment["text"] == "REVENUE SOURCE"):
                            for field in safe_get(top_match1, ["additionalFields"], default=[]):
                                field_name = field.get("fieldName", "")
                                field_value = field.get("fieldValue", "")
                                if (field_name == "ASIDRatingType") and (field_value == "Local Currency LT"):
                                    top_match = top_match1
                                    top_match_idx = 0
                            if not top_match:
                                top_match = top_match2
                                top_match_idx = 1
            if not top_match:
                top_match = top_match1
                top_match_idx = 0
        except (IndexError, KeyError) as e:
            print(f"Some error occurred in Search API top match result: {e}\nResponse: {search_response}")
            raise e

        # suggested matches
        suggested_matches = []
        for idx, suggested_match in enumerate(destinations):
            try:
                # skip the top match for suggested matches
                if idx == top_match_idx:
                    continue
                suggested_matches.append(suggested_match)
            except IndexError as e:
                print(
                    f"Index error found, some error occurred in Search API suggested entities: {e}\n"
                    f"Response: {search_response}"
                )
                raise e

        return top_match, suggested_matches

    def _get_entity_context(self, input_entity: Dict) -> Dict:
        """Converts the response from the search API to a dictionary and extracts necessary information
        based on its type (company, revenue sources, etc.).

        Args:
            input_entity (Dict): An entity returned from the search API.

        Returns:
            Dict: A dictionary containing the entity context information.

        Raises:
            IndexError: If an index error occurs while processing the search API results (probably due to search api's endpoint issue).

        """

        input_entity_comments = input_entity["comments"]
        input_entity_fields = input_entity["additionalFields"]
        entity_context_base = {
            "Name": input_entity["name"],
            "URL": input_entity["url"],
        }

        for item in input_entity_comments:
            if item["contentType"] == "badge_rd":
                entity_context_base["RD"] = True
            elif item["contentType"] == "badge_csd":
                entity_context_base["CSD"] = True
            elif item["contentType"] == "card_type":
                entity_context_base["Type"] = item["text"]

        score, mi_entity_score, calculated_score = self._get_entity_scores(input_entity_fields)
        entity_context_base["score"] = score
        entity_context_base["mi_entity_score"] = mi_entity_score
        entity_context_base["calculated_score"] = calculated_score

        # check other type of entity as well for company context
        if entity_context_base["Type"] in (
            "Public Company",
            "Private Company",
            "Structured Finance",
            "Government Institution",
            "Educational Institution",
            "Foundation or Charitable Institution",
            "Arts Institution",
            "Labor Union",
            "Religious Institution",
            "Trade Association",
        ):
            entity_context_base["CompanyContext"] = self._map_company_context(input_entity_fields)
            entity_context_base["EntityType"] = "Company"
        elif entity_context_base["Type"] == "Fixed Income":
            entity_context_base["SecurityContext"] = self._map_security_context(input_entity_fields)
            entity_context_base["EntityType"] = "Security"
        elif entity_context_base["Type"] == "GEOGRAPHY":
            entity_context_base["CountryContext"] = self._map_country_context(input_entity_fields)
            entity_context_base["EntityType"] = "Country"
        elif entity_context_base["Type"] == "REVENUE SOURCE":
            entity_context_base["RSContext"] = self._map_rs_context(input_entity_fields)
            entity_context_base["EntityType"] = "RevenueSource"
            entity_context_base["Name"] = entity_context_base["RSContext"]["name"]

        return entity_context_base

    @staticmethod
    def _get_entity_scores(fields):
        item_score, item_mi_score, item_calculated_score = None, None, None
        for item in fields:
            if item["fieldName"] == "score":
                item_score = item["fieldValue"]
            if item["fieldName"] == "mi_entity_score":
                item_mi_score = item["fieldValue"]
            if item["fieldName"] == "calculated_score":
                item_calculated_score = item["fieldValue"]

        return item_score, item_mi_score, item_calculated_score

    @staticmethod
    def _map_company_context(fields):
        entity_context = {}
        for item in fields:
            if item["fieldName"] == "mi_id":
                entity_context["keyinstn"] = item["fieldValue"]
            elif item["fieldName"] == "id":
                entity_context["keyinstn"] = item["fieldValue"]
            elif item["fieldName"] == "rating_entity_id":
                entity_context["rating_entity_id"] = item["fieldValue"]
            elif item["fieldName"] == "name":
                entity_context["name"] = item["fieldValue"]
            elif item["fieldName"] == "KeyUniversalEntity":
                entity_context["KeyUniversalEntity"] = item["fieldValue"]
            elif item["fieldName"] == "trading_symbol":
                entity_context["TradingSymbol"] = item["fieldValue"]
            elif item["fieldName"] == "content_set":
                entity_context["ContentSet"] = item["fieldValue"]
            elif item["fieldName"] == "industry_description":
                entity_context["industry_description"] = item["fieldValue"]
            elif item["fieldName"] == "industry_description_gics":
                entity_context["industry_description_gics"] = item["fieldValue"]
            elif item["fieldName"] == "rd_sector":
                entity_context["rd_sector"] = item["fieldValue"]
            elif item["fieldName"] == "rd_subsector":
                entity_context["rd_subsector"] = item["fieldValue"]
            elif item["fieldName"] == "rd_industry":
                entity_context["rd_industry"] = item["fieldValue"]

        return entity_context

    @staticmethod
    def _map_country_context(fields):
        country_context = {}
        for item in fields:
            if item["fieldName"] == "KeyCountry":
                country_context["KeyCountry"] = item["fieldValue"]
            elif item["fieldName"] == "KeyUniversalEntity":
                country_context["keyinstn"] = item["fieldValue"]
            elif item["fieldName"] == "CountryCode":
                country_context["CountryCode"] = item["fieldValue"]

        return country_context

    @staticmethod
    def _map_security_context(fields):
        sec_context = {}
        for item in fields:
            if item["fieldName"] == "RDStatus":
                sec_context["RDStatus"] = item["fieldValue"]
            elif item["fieldName"] == "SecurityID":
                sec_context["SecurityID"] = item["fieldValue"]
            elif item["fieldName"] == "RDISIN":
                sec_context["RDISIN"] = item["fieldValue"]
            elif item["fieldName"] == "RDCUSIP":
                sec_context["RDCUSIP"] = item["fieldValue"]
            elif item["fieldName"] == "RDIssuerName":
                sec_context["RDIssuerName"] = item["fieldValue"]
            elif item["fieldName"] == "RDDescription":
                sec_context["RDDescription"] = item["fieldValue"]
            elif item["fieldName"] == "RDUrl":
                sec_context["RDUrl"] = item["fieldValue"]
            elif item["fieldName"] == "RDTranche":
                sec_context["RDTranche"] = item["fieldValue"]
            elif item["fieldName"] == "RDPrimaryIssuerName":
                sec_context["RDPrimaryIssuerName"] = item["fieldValue"]
            elif item["fieldName"] == "RDKOS":
                sec_context["RDKOS"] = item["fieldValue"]

        RD_url = sec_context["RDUrl"]
        if RD_url and RD_url != "null":
            parsed_url = urlparse("http://www.example.com/" + sec_context["RDUrl"].strip("#[]"))
            params = parse_qs(parsed_url.query)
            sec_context["IssuerKeyinstn"] = safe_get(params, ["Id", 0])
            sec_context["InsSymbol"] = safe_get(params, ["InsSymbol", 0])
            sec_context["SecSymbol"] = safe_get(params, ["SecSymbol", 0])

        return sec_context

    @staticmethod
    def _map_rs_context(fields):
        entity_context = {}
        for item in fields:
            if item["fieldName"] == "ASIDId":
                entity_context["ASIDId"] = item["fieldValue"]
            elif item["fieldName"] == "ASIDName":
                entity_context["name"] = item["fieldValue"]
            elif item["fieldName"] == "Obligor":
                entity_context["Obligor"] = item["fieldValue"]
            elif item["fieldName"] == "ObligorUrl":
                entity_context["ObligorUrl"] = item["fieldValue"]
            elif item["fieldName"] == "IssuerName":
                entity_context["Issuer"] = item["fieldValue"]
            elif item["fieldName"] == "IssuerNameUrl":
                entity_context["IssuerUrl"] = item["fieldValue"]

        return entity_context
