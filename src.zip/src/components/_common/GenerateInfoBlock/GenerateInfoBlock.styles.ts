import styled from '@emotion/styled';

export const StyledGenerateInfoBlock = styled.div`
  margin-left: 50px;
  font-size: var(--size-font-5);
  padding-top: 11px;
  .red
  {
    color: var(--color-base-red-55);
    font-weight: 700;
  }
`;

export const StyledInfoLink = styled.span`
  font-size: var(--size-font-4);
  padding: var(--size-space-0);

  button {
    padding: var(--size-space-0);

    span{
      padding : 2px 3px 2px 3px;
      font-size: 14px;
    }
  }
`;
