from datetime import date
from enum import Enum
from math import ceil
from typing import Optional, Union

from dateutil.relativedelta import relativedelta
from pydantic import BaseModel, Field

from chatrd.core.llm.parsers import PydanticOutputParser
from chatrd.core.llm.prompt.template import SimplePromptTemplate

# TODAY_DATE = date.today()

# -----------------------------------------
# TIME THRESHOLD DEFINITION - STRING OUTPUT
# -----------------------------------------

# STRING OUTPUT - Output Class
# ----------------------------


class PeriodTypeClass(Enum):
    """
    This class specifies available period types.
    """

    FISCAL_YEAR = "FY"
    FISCAL_QUARTER = "FQ"
    FISCAL_HALF_YEAR = "FH"
    RECENT_DATE = "RD"
    NONE = None


class TimeOutputSymbol(BaseModel):
    PeriodType: Optional[Union[PeriodTypeClass, None]] = Field(
        default=None,
        description="""Period type which is extracted from user's question:
            - FISCAL_YEAR stands for specific years
            - FISCAL_QUARTER stands for specific quarters of a year
            - FISCAL_HALF_YEAR stands for specific half year periods of a year
            - RECENT_DATE stands for the latest period
            - None, when no period is mentioned in the user's question
        """.strip(),
    )
    PeriodsList: Optional[Union[list[str], None]] = Field(
        default=None,
        description="""Specify, which periods are mentioned in the query. The format depends on the PeriodType extracted:
            - if FISCAL_YEAR, then return list of strings with a specific year followed by Y suffix. For example output [2023Y, 2024Y], when asked about fiscal years 2023 and 2024
            - if FISCAL_QUARTER, then return list of strings, each starting with a year, then capital letter Q, followed by a specific quarter number. For example output [2023Q3, 2023Q4, 2024Q1], when asked about period from Q3 2023 till Q1 2024
            - if FISCAL_HALF_YEAR, then return list of strings, each starting with a year, then capital letter H, and then a specific half hear number. For example, output [2023H2, 2024H1], when ashed about the second half of 2023 and the first half of 2024
            - if RECENT_DATE, then return a list with a single entry: LFY (Latest Fiscal Year), LFQ (Latest Fiscal Quarter), LTHY (Latest Half-Year) or LTM (Last Twelve Months)
        """,
    )
    ChainOfThought: Optional[Union[str, None]] = Field(
        default="",
        description="""Step-by-step logic which led you to the answer. Justify your selection of PeriodType and PeriodsList. You may directly quote the prompt. If you are unsure, do not hallucinate. The logic MUST corespond with the outputted values of PeriodType and PeriodsList.""",
    )


output_parser_time_threshold_symbol = PydanticOutputParser(pydantic_object=TimeOutputSymbol)

# STRING OUTPUT - Generic Prompt
# ------------------------------

TIME_THRESHOLD_FILTER_PROMPT_TEMPLATE_STRING = """
You are a financial advisor, trained to respond to questions about stock, credit ratings and financial events.

{short_task_description}

<instructions>
Your goal is to retrieve information about periods mentioned in user questions:
    - PeriodType represents type of time horizon which was retrieved from user question
    - PeriodsList represent a list of periods mentioned in the question. List all periods, for example when asked about timespan between the second quarter of 2021 and the first quarter of 2022 return [2021Q2, 2021Q3, 2021Q4, 2022Q1]. If the period is not specified, return null.
    - when multiple consecutive periods are listed, return all periods within the timespan
    - when Period is not specified, return PeriodType: null and PeriodsList: null
    - today is {today_date}
    {task_specific_instructions}
</instructions>

<formatting>
This information is to be output only when mentioned in the question. Format the output following these guidelines:

<format_guidelines>
{format_instructions}
</format_guidelines>

You MUST follow these rules:
    - Do not add anything other than the defined JSON schema
    - Do not say, this is the JSON output I requested
    - Do not justify your answer
    - Provide only the JSON
    - Follow closely the formatting instructions
    - Do not add other fields, than defined in format_guidelines
    - Provide both PeriodType and PeriodsList, when the period is specified. If not, set both PeriodType and PeriodsList to null.
    {format_instructions_additional}
</formatting>

Follow these examples, format them according to the format_guidelines
<examples>
{examples}
</examples>

Apply these instructions to this question
{question}
"""

# STRING OUTPUT - Prompt Inputs
# -----------------------------


def task_specific_instructions_string(today_date):
    output_string = f"""
    - when asked about recent previous period select PeriodType: RD and the appropriate period type for PeriodsList. For example, when the question mentions a previous year, return PeriodsList: [LFY]. PeriodsList: [LTM] is to be selected only when the user specifically mentioned last twelve months or LTM
    - when asked for last or recent report or data and when it's not specified if the question is about a year, quarter or half-year, select PeriodType: RD and PeriodsList: [LFY]
    - when asked about current period, return that period calculated based on today's date (today is {today_date}). For example, when asked about current year return PeriodType: FY and PeriodsList: [{today_date.year}Y]. This does not apply to questions about recent reports or data or financial metrics
    - when asked for current financial data, key financials, reports, metrics, etc, return PeriodType: RD and PeriodsList: [LFY]
    - return previous period in a fiscal format only, when that period is mentioned as a number (today is {today_date}). For example, when asked for year {today_date.year-1} return PeriodType: FY and PeriodsList: [{today_date.year-1}Y]
    - when multiple previous periods are requested (for example 3 last quarters), select the appropriate fiscal type instead, and follow PeriodsList format instructions applicable to that PeriodType. For example, when asked about two last years return PeriodType: FY and PeriodsList: [{today_date.year-2}Y, {today_date.year-1}Y]
    - when asked about several previous quarters (current quarter is '{today_date.year}Q{ceil(today_date.month/3)}'), start PeriodsList from previous quarter '{(today_date + relativedelta(months=-3)).year}Q{ceil((today_date + relativedelta(months=-3)).month/3)}' 
    - for future periods, always use fiscal PeriodType (for example, when asked about next two years return PeriodType: FY and PeriodsList: [{today_date.year+1}Y, {today_date.year+2}Y])
    - set PeriodType: RD and PeriodsList: LTM only, when the question specifically mentions LTM or Last Twelve Months
    - when a date is partially specified and a year is missing, assume that the question pertains to the current year (today is {today_date}). For example, when asked about Q1, assume the current year {today_date.year} and return PeriodType: FQ and PeriodsList: [{today_date.year}Q1]
    - when asked about last few fiscal periods (years, half-years or quarters) return 4 previous fiscal periods of that sort (4 previous years, 4 previous half-years or 4 previous quarters). For example, when asked about last few years (today is {today_date}), output PeriodType: FY and PeriodsList: [{today_date.year-4}Y, {today_date.year-3}Y, {today_date.year-2}Y, {today_date.year-1}Y]
    - when only beginning of the period is specified output 100 fiscal years after the requested period start date. For example, when asked about period "after 2023" return PeriodType: FY and PeriodsList: [2023Y, 2024Y, ..., 2122Y]
    - when the period is not mentioned nor specified, output PeriodType: null, PeriodsList: null
    """.strip()
    return output_string


def get_quarter(date_obj):
    return f"{date_obj.year}Q{ceil(date_obj.month / 3)}"


def get_previous_quarters(n, today_date):
    return [get_quarter(today_date - relativedelta(months=3 * i)) for i in range(1, n + 1)]


def task_specific_examples_string(today_date):
    output_list = [
        [
            f"Last 3 quarters",
            f"""PeriodType: 'FQ', PeriodsList: {get_previous_quarters(3, today_date)}, ChainOfThought: 'Today is {today_date}. The question asks about 3 previous quarters. The current quarter is '{get_quarter(today_date)}', previous quarter is '{get_previous_quarters(3, today_date)[0]}'. The PeriodsList contains 3 previous quarters, starting from the previous quarter: {', '.join(get_previous_quarters(3, today_date))}'""",
        ],
        [
            f"Last 4 quarters",
            f"""PeriodType: 'FQ', PeriodsList: {get_previous_quarters(4, today_date)}, ChainOfThought: 'Today is {today_date}. The question asks about 4 previous quarters. The current quarter is '{get_quarter(today_date)}', previous quarter is '{get_previous_quarters(4, today_date)[0]}'. The PeriodsList contains 4 previous quarters, starting from the previous quarter: {', '.join(get_previous_quarters(4, today_date))}'""",
        ],
        [
            f"Last 5 quarters",
            f"""PeriodType: 'FQ', PeriodsList: {get_previous_quarters(5, today_date)}, ChainOfThought: 'Today is {today_date}. The question asks about 5 previous quarters. The current quarter is '{get_quarter(today_date)}', previous quarter is '{get_previous_quarters(5, today_date)[0]}'. The PeriodsList contains 5 previous quarters, starting from the previous quarter: {', '.join(get_previous_quarters(5, today_date))}'""",
        ],
        [
            f"Last 6 quarters",
            f"""PeriodType: 'FQ', PeriodsList: {get_previous_quarters(6, today_date)}, ChainOfThought: 'Today is {today_date}. The question asks about 6 previous quarters. The current quarter is '{get_quarter(today_date)}', previous quarter is '{get_previous_quarters(6, today_date)[0]}'. The PeriodsList contains 6 previous quarters, starting from the previous quarter: {', '.join(get_previous_quarters(6, today_date))}'""",
        ],
        [
            f"Last 7 quarters",
            f"""PeriodType: 'FQ', PeriodsList: {get_previous_quarters(7, today_date)}, ChainOfThought: 'Today is {today_date}. The question asks about 7 previous quarters. The current quarter is '{get_quarter(today_date)}', previous quarter is '{get_previous_quarters(7, today_date)[0]}'. The PeriodsList contains 7 previous quarters, starting from the previous quarter: {', '.join(get_previous_quarters(7, today_date))}'""",
        ],
        [
            f"Last 8 quarters",
            f"""PeriodType: 'FQ', PeriodsList: {get_previous_quarters(8, today_date)}, ChainOfThought: 'Today is {today_date}. The question asks about 8 previous quarters. The current quarter is '{get_quarter(today_date)}', previous quarter is '{get_previous_quarters(8, today_date)[0]}'. The PeriodsList contains 8 previous quarters, starting from the previous quarter: {', '.join(get_previous_quarters(8, today_date))}'""",
        ],
        [
            "Provide me last 5 quarter data Pretax Profit, Revenue Adjusted of ABD and DEF companies",
            f"""PeriodType: 'FQ', PeriodsList: {get_previous_quarters(5, today_date)}, ChainOfThought: 'Today is {today_date}. The question asks about 5 previous quarters.  The current quarter is '{get_quarter(today_date)}', previous quarter is '{get_previous_quarters(5, today_date)[0]}'. The PeriodsList contains 5 previous quarters, starting from the previous quarter: {', '.join(get_previous_quarters(5, today_date))}'""",
        ],
        [
            "what were the EBITDA margins for Shenzhen international in Q1, Q2 and Q3 of 2024",
            "PeriodType: 'FQ', PeriodsList: ['2024Q1', '2024Q2', '2024Q3'], ChainOfThought: 'Three quarters are specified, output doesn't depend on the current date, outputting PeriodType: 'FQ' and listed quarters as PeriodsList.'",
        ],
        [
            "Show me current financial metrics for abc",
            """PeriodType: 'RD', PeriodsList: ['LFY'], ChainOfThought: 'The question mentions current financial metrics. Quoting the instructions: "when asked for current financial data, key financials, reports, metrics, etc, return PeriodType: RD and PeriodsList: [LFY]", returning PeriodType: RD and PeriodsList: [LFY].'""",
        ],
        [
            "What's the news about xyz?",
            """PeriodType: null, PeriodsList: null, ChainOfThought: 'The period is not specified, quoting the instructions: "when the period is not mentioned nor specified, output PeriodType: null, PeriodsList: null", outputting PeriodType: null, PeriodsList: null'""",
        ],
        [
            "Show me some financial trends for Coca-Cola over the past three years.",
            f"""PeriodType: 'FY', PeriodsList: ['{today_date.year-3}Y', '{today_date.year-2}Y', '{today_date.year-1}Y]', ChainOfThought: 'Today is {today_date}. The question mentions past three years, quoting the instructions: "when multiple previous periods are requested (for example 3 last quarters), select the appropriate fiscal type instead, and follow PeriodsList format instructions" and returning PeriodType: 'FY', PeriodsList: ['{today_date.year-3}Y', '{today_date.year-2}Y', '{today_date.year-1}Y].'""",
        ],
        [
            "show me the latest FY CSD stats for Ford Motor",
            """PeriodType: 'RD', PeriodsList: ['LFY'], ChaiOfThought: 'The question mentions 'latest stats'. Quoting the instructions: "when asked for last or recent report or data and when it's not specified if the question is about a year, quarter or half-year, select PeriodType: RD and PeriodsList: [LFY]" and returning PeriodType: RD and PeriodsList: [LFY].'""",
        ],
        [
            "What was the net income of XYZ in 2023",
            "PeriodType: 'FY', PeriodsList: ['2023Y'], ChainOfThought: 'The question asks about the net income of XYZ in 2023, which is a specific fiscal year. Therefore, the PeriodType is set to 'FY' and the PeriodsList contains '2023Y'.'",
        ],
        [
            "Show me Micron's Revenue in the last years mid-year report?",
            """PeriodType: 'RD', PeriodsList: ['LTHY'], ChainOfThought: 'The question mentions last half year. Quoting the instructions: "when asked about recent previous period select PeriodType: RD and the appropriate period type for PeriodsList.", period type is Latest Half-Year, hence returning PeriodType: 'RD', PeriodsList: ['LTHY']'""",
        ],
        [
            "What was company income in the previous quarter?",
            """PeriodType: 'RD', PeriodsList: ['LFQ'],  ChainOfThought: 'The question mentions last quarter. Quoting the instructions: "when asked about recent previous period select PeriodType: RD and the appropriate period type for PeriodsList.", period type is Latest Quarter, hence returning PeriodType: 'RD', PeriodsList: ['LFQ']'""",
        ],
        [
            "show me all companies downgraded in Insurance Sector in 2024",
            """PeriodType: 'FY', PeriodsList: ['2024Y'], ChainOfThought: 'The question asks about 2024, which is a specific fiscal year. Therefore, the PeriodType is set to 'FY' and the PeriodsList contains '2024Y'.'""",
        ],
        [
            "What securities were issued by company XYZ with maturity date last year",
            """PeriodType: 'RD', PeriodsList: ['LFY'],  ChainOfThought: 'The question mentions last year. Quoting the instructions: "when asked about recent previous period select PeriodType: RD and the appropriate period type for PeriodsList.", period type is Latest Year, hence returning PeriodType: 'RD', PeriodsList: ['LFY']'""",
        ],
        [
            "List all securities issued in the first half of 2020",
            """PeriodType: 'FH', PeriodsList: ['2020H1'], ChainOfThought: 'The question mentions the first half of 2020. Following the instructions, this corresponds to a FISCAL_HALF_YEAR period type, and the PeriodsList should contain '2020H1'.""",
        ],
        [
            "Show me key financial metrics for company DEF",
            """PeriodType: null, PeriodsList: null, ChainOfThought: 'The period is not specified, quoting the instructions: "when the period is not mentioned nor specified, output PeriodType: null, PeriodsList: null", outputting PeriodType: null, PeriodsList: null'""",
        ],
        [
            "Show me current key financial metrics for company DEF",
            """PeriodType: 'RD', PeriodsList: ['LFY'], ChainOfThought: 'The question mentions current key financial metrics. Quoting the instructions: "when asked for current financial data, key financials, reports, metrics, etc, return PeriodType: RD and PeriodsList: [LFY]", returning PeriodType: RD and PeriodsList: [LFY].'""",
        ],
        [
            "Show me securities issued by company ABC with maturity date after 2030",
            """PeriodType: 'FY', PeriodsList: ['2030Y', '2031Y', '2032Y', '2033Y', '2034Y', '2035Y', '2036Y', '2037Y', '2038Y', '2039Y', '2040Y', '2041Y', '2042Y', '2043Y', '2044Y', '2045Y', '2046Y', '2047Y', '2048Y', '2049Y', '2050Y', '2051Y', '2052Y', '2053Y', '2054Y', '2055Y', '2056Y', '2057Y', '2058Y', '2059Y', '2060Y', '2061Y', '2062Y', '2063Y', '2064Y', '2065Y', '2066Y', '2067Y', '2068Y', '2069Y', '2070Y', '2071Y', '2072Y', '2073Y', '2074Y', '2075Y', '2076Y', '2077Y', '2078Y', '2079Y', '2080Y', '2081Y', '2082Y', '2083Y', '2084Y', '2085Y', '2086Y', '2087Y', '2088Y', '2089Y', '2090Y', '2091Y', '2092Y', '2093Y', '2094Y', '2095Y', '2096Y', '2097Y', '2098Y', '2099Y', '2100Y', '2101Y', '2102Y', '2103Y', '2104Y', '2105Y', '2106Y', '2107Y', '2108Y', '2109Y', '2110Y', '2111Y', '2112Y', '2113Y', '2114Y', '2115Y', '2116Y', '2117Y', '2118Y', '2119Y', '2120Y', '2121Y', '2122Y', '2123Y', '2124Y', '2125Y', '2126Y', '2127Y', '2128Y', '2129Y'], ChainOfThought: 'Question mentions period after 2030. Quoting the instructions: "when only beginning of the period is specified output 100 fiscal years after the requested period start date." and returning PeriodType: 'FY' and PeriodsList is 100 Fiscal Years starting from 2030.'""",
        ],
        [
            "Show me securities for XYZ with maturity date next year",
            f"""PeriodType: 'FY', PeriodsList: ['{today_date.year+1}Y'], ChainOfThought: 'Today is {today_date}. The question asks about next year. Following the instructions, since the question is about a future period the PeriodType is set to 'FY'. PeriodsList contains '{today_date.year+1}' as the next fiscal year.'""",
        ],
        [
            "Current year",
            f"""PeriodType: 'FY', PeriodsList: ['{today_date.year}Y'], ChainOfThought: 'Today is {today_date}. The question asks about current year. Quoting the instruction: "when asked about current period, return that period calculated based on today's date", returning the current fiscal year.'""",
        ],
        [
            "Current quarter",
            f"""PeriodType: 'FQ', PeriodsList: ['{today_date.year}Q{ceil(today_date.month/3)}'], ChainOfThought: 'Today is {today_date}. The question asks about current quarter. Quoting the instruction: "when asked about current period, return that period calculated based on today's date", returning the current fiscal quarter.'""",
        ],
        [
            "Current half year",
            f"""PeriodType: 'FH', PeriodsList: ['{today_date.year}H{ceil(today_date.month/6)}'], ChainOfThought: 'Today is {today_date}. The question asks about current half-year. Quoting the instruction: "when asked about current period, return that period calculated based on today's date", returning the current fiscal half-year.'""",
        ],
        [
            "Previous year",
            """PeriodType: 'RD', PeriodsList: ['LFY'], ChainOfThought: 'The question asks about the previous year, so I am setting the PeriodType to 'RD' (Recent Date) and the PeriodsList to ['LFY'] (Latest Fiscal Year) as per the instructions.'""",
        ],
        [
            "prevous quarter",
            """PeriodType: 'RD', PeriodsList: ['LFQ'], ChainOfThought: 'The question asks about the previous quarter, so I am setting the PeriodType to 'RD' (Recent Date) and the PeriodsList to ['LFQ'] (Latest Fiscal Quarter) as per the instructions.'""",
        ],
        [
            "previous half year",
            """PeriodType: 'RD', PeriodsList: ['LTHY'], ChainOfThought: 'The question asks about the previous year, so I am setting the PeriodType to 'RD' (Recent Date) and the PeriodsList to ['LFY'] (Latest Fiscal Year) as per the instructions.'""",
        ],
        [
            "show me EBITDA Adjusted and Debt/ EBITDA Adjusted for Tesla",
            """PeriodType: null, PeriodsList: null, ChainOfThought: 'The period is not specified, quoting the instructions: "when the period is not mentioned nor specified, output PeriodType: null, PeriodsList: null", outputting PeriodType: null, PeriodsList: null'""",
        ],
        [
            "What's the Stock Compensation Expense (Adjusted) for Microsoft?",
            """PeriodType: null, PeriodsList: null, ChainOfThought: 'The period is not specified, quoting the instructions: "when the period is not mentioned nor specified, output PeriodType: null, PeriodsList: null", outputting PeriodType: null, PeriodsList: null'""",
        ],
        [
            "What is the debt to EBITDA ratio for XYZ?",
            """PeriodType: null, PeriodsList: null, ChainOfThought: 'The period is not specified, quoting the instructions: "when the period is not mentioned nor specified, output PeriodType: null, PeriodsList: null", outputting PeriodType: null, PeriodsList: null'""",
        ],
        [
            "What are the current ratings, return on equity and net income of XYZ?",
            """PeriodType: 'RD', PeriodsList: ['LFY'], ChainOfThought: 'The question mentions current ratings and financial metrics. Quoting the instructions: "when asked for current financial data, key financials, reports, metrics, etc, return PeriodType: RD and PeriodsList: [LFY]", returning PeriodType: RD and PeriodsList: [LFY].'""",
        ],
    ]
    output_list_formatted = "\n\n________\n\n".join(
        [f"""Question: {question} \nOutput: {response}""" for question, response in output_list]
    )
    return output_list_formatted


TIME_THRESHOLD_STRING_INPUT = {
    "short_task_description": "",
    # "task_specific_instructions": TASK_SPECIFIC_INSTRUCTIONS_STRING,
    "format_instructions": output_parser_time_threshold_symbol.get_format_instructions(),
    "format_instructions_additional": "",
    # "examples": TASK_SPECIFIC_EXAMPLES_STRING_FORMATTED,
}

TIME_THRESHOLD_PROMPT_STRING_OUTPUT = SimplePromptTemplate(
    template=TIME_THRESHOLD_FILTER_PROMPT_TEMPLATE_STRING,
    partial_variables=TIME_THRESHOLD_STRING_INPUT,
)


# ---------------------------------
# TIME THRESHOLD DEFINITION - DATES
# ---------------------------------

# DATE OUTPUT - Output Class
# --------------------------


class QuestionIntentClass(Enum):
    """
    This is to store user intent specification
    """

    SPECIFIC_DATES = "SD"
    FISCAL_PERIOD = "FP"
    INCLUDES_TODAY = "IT"
    PERIOD_TO_DATE = "PD"
    UNSPECIFIED = "US"


class PeriodsNumber(Enum):
    """
    This class specifies if PeriodStart and PeriodEnd dates are provided by the user
    """

    BOTH = "B"
    ONLY_START = "OS"
    ONLY_END = "OE"
    NONE = None


ADDITIONAL_INFO_UNSTRUCTURED = """- If the question explicitly mentions current year or quarter and concerns events that have already happened until now (e.g. events that have happened this year, or between 2022 and this year etc.), set Question_Intent: PD and PeriodEnd to today's date.
- If the question explicitly mentions current year or quarter and concerns forecasting, scheduled events or forward-looking, set the PeriodEnd to the last day of mentioned period and appropriate Question_Intent. """


class TimeOutputDates(BaseModel):
    Question_Intent: Optional[Union[QuestionIntentClass, None]] = Field(
        default="US",
        description="""User intent specification:
            - SPECIFIC_DATES, if period definition does not depend on the current date, for example: 'between 20 March and 15 June 2021', or 'before 2023', or 'all options expiring in 2023'
            - FISCAL_PERIOD, if period definition references a fiscal period, such as year (defined in FISCAL_YEAR_DEFINITION), quarter (defined in FISCAL_QUARTER_DEFINITION), half-hear (defined in FISCAL_HALF_YEAR_DEFINITION) or month (first and last day of a calendar month)
            - INCLUDES_TODAY, if period definition references a period relative to the current date
            - PERIOD_TO_DATE, if period definition references the beginning of a fiscal period till today
            - UNSPECIFIED, when no period is mentioned, for example: show me current company rating
        """.strip(),
    )
    WhichPeriods: Optional[Union[PeriodsNumber, None]] = Field(
        default=None,
        description="""Information about the periods provided by the user:
            - when BOTH, fill PeriodStart and PeriodEnd
            - when ONLY_START, fill PeriodStart and set PeriodEnd to None
            - when ONLY_END, set PeriodStart to None and fill PeriodEnd
            - when NONE, set PeriodStart to None and set PeriodEnd to None
        """.strip(),
    )
    PeriodStart: Optional[Union[date, None]] = Field(
        default=None,
        description="Start date of the period",
    )
    PeriodEnd: Optional[Union[date, None]] = Field(
        default=None,
        description="End date of the period",
    )
    Explanation: str = Field(
        description="""Describe the logic you applied to select:
            - Question_Intent, if FISCAL_PERIOD (FP) or INCLUDES_TODAY (IT) was selected, quote the most appropriate phrase from FISCAL_PERIOD_KEYWORDS or INCLUDES_TODAY_KEYWORDS
            - WhichPeriods
            - PeriodStart, if needed reference the current date
            - PeriodEnd, if needed reference the current date
        """
    )


output_parser_time_threshold_dates = PydanticOutputParser(pydantic_object=TimeOutputDates)


# DATE OUTPUT - Generic Prompt
# ----------------------------
# time inputs: today_date and today_date_year and last_year and today_date_minus_year
TIME_THRESHOLD_DATES_OUTPUT_PROMPT = """
You are a financial advisor, trained to respond to questions about stock, credit ratings and financial events.

Your role is to closely follow the instructions and retrieve data from user question. Today is {today_date}.

{short_task_description}
{task_specific_instructions}

<instructions>
Your goal is to retrieve information about period start and dates from a question. Follow these steps:
    1) Determine Question_Intent. You MUST select one of four possible options:
        1a) SPECIFIC_DATES (SD): you MUST select this outpion, if he period is defined, and it does not depend on the current date
        1b) INCLUDES_TODAY (IT): a period which includes the current date, you MUST select this option if the question includes one of these phrases: <INCLUDES_TODAY_KEYWORDS>within last year, confined to last year, in less than a year, in under a year, recent year, within next year, confined to next year, in less than a year from now, in under a year from today (or month, or quarter, or half-year)</INCLUDES_TODAY_KEYWORDS>
        1c) FISCAL_PERIOD (FP): a fiscal or calendar period, you MUST select this option if the question includes one of these phrases: <FISCAL_PERIOD_KEYWORDS>last year, previous year, in last year, inside last year, during last year, next year, coming year, in next year, inside next year, during next year (or month, or quarter, or half-year), this year, this quarter</FISCAL_PERIOD_KEYWORDS>
        1d) PERIOD_TO_DATE (PD): a period starting on the day being the beginning of a fiscal period, ending today. You MUST select this option if the question includes one of these phrases: <PERIOD_TO_DATE_KEYWORDS>year to date, YTD, half year to date, quarter to date, QTD, month to date, MTD, this year or {today_date_year} (for past events), this quarter (for past events)</PERIOD_TO_DATE_KEYWORDS>
        1e) UNSPECIFIED (US): no period was specified by the user, you must input Question_Intent: US
    2) WhichPeriods defines which periods are mentioned in the question:
        2a) BOTH: when period beginning and end can be determined
        2b) ONLY_START: when only period beginning is available
        2c) ONLY_END: when only period end is available
        2d) NONE (null): no period is mentioned
    3) Fill PeriodStart and PeriodEnd. You must follow this guidance, select best possible option based on Question_Intent and WhichPeriods:
        3a) if Question_Intent is SPECIFIC_DATES (Question_Intent: SD), you MUST fill PeriodStart and PeriodEnd (whatever's provided, as per WhichPeriods)
        3b) when Question_Intent is FISCAL_PERIOD (Question_Intent: FP), you MUST first determine the type of period requested (year, half-year, quarter or month) and then you MUST select the right period in time (one or multiple periods; current or historical or future periods). For example, when asked about previous year return PeriodStart: {last_year}-01-01, PeriodEnd: {last_year}-12-31
        3c) when Question_Intent is INCLUDES_TODAY (Question_Intent: IT), you MUST first determine the type of period requested (year, half-year, quarter or month), and then you MUST determine the difference between the current date and PeriodStart or PeriodEnd. For example, when asked about events taking place within previous year, return PeriodStart: {today_date_minus_year}, PeriodEnd: {today_date}
        3d) when Question_Intent is PERIOD_TO_DATE (Question_Intent: PD), you MUST first determine the type of period requested (year, half-year, quarter or month) and then you MUST set PeriodStart to the beginning of the current period of that sort, and PeriodEnd to today. For example, when asked about inflation YTD, return PeriodStart: {today_date_year}-01-01, PeriodEnd: {today_date}
        3e) when Question_Intent is UNSPECIFIED (Question_Intent: US), you MUST return PeriodStart: null and PeriodEnd: null
    4) Explanation is to be provided. For example, for question "What will the inflation be inside next two years?" output Explanation: "Question_Intent: FP, the matching phrase from FISCAL_PERIOD_KEYWORDS 'inside next year', returning two next fiscal years (following FISCAL_YEAR_DEFINITION)."

Important notice:
- <FISCAL_YEAR_DEFINITION>Fiscal (calendar) year starts on 1st January and ends on 31st December</FISCAL_YEAR_DEFINITION>
- <FISCAL_HALF_YEAR_DEFINITION>There are 2 fiscal (calendar) half-years in a fiscal year: [1st January : 30th June] and [1st July : 31st December]</FISCAL_HALF_YEAR_DEFINITION>
- <FISCAL_QUARTER_DEFINITION>There are 4 fiscal (calendar) quarters in a fiscal year: [1st January : 31 March], [1st April : 30th June], [1st July : 30th September], [1st October : 31th December]</FISCAL_QUARTER_DEFINITION>
- You MUST NOT select Question_Intent: FP (FISCAL_PERIOD), when the question contains a phrase from PREVIOUS_PERIOD_RECENT
- You MUST NOT select Question_Intent: IT (INCLUDES_TODAY), when the question does not contain a phrase from INCLUDES_TODAY_KEYWORDS
- When Question_Intent: FP (FISCAL_PERIOD), the period MUST NOT contain the current date. A fiscal period MUST be output as PeriodStart and PeriodEnd
- When Question_Intent: IT (INCLUDES_TODAY), the period MUST contain the current date. A fiscal period MUST NOT be output
- When asked about recent/current credit rating actions (such as updates, downgrades, upgrades, new ratings or defaults), recent/current research or recent/current data and the period remains unspecified, for example "show me recent rating changes" (question does not mention year, half-year, quarter nor month), you MUST NOT find matching keywords in on FISCAL_PERIOD_KEYWORDS and INCLUDES_TODAY_KEYWORDS. Output Question_Intent: US, WhichPeriods: null, PeriodStart: null, PeriodEnd: null
- If the question mentions recent period, and the period is specified (for example recent quarter), then this matches one of the phrases from INCLUDES_TODAY_KEYWORDS (recent year), and you MUST output Question_Intent: IT
- If a date is only partially specified and a year is missing, assume that the question pertains to the current year, output Question_Intent: SD and set PeriodStart and PeriodEnd to the beginning and end of that period
- If asked about last few periods (years, half-years, quarters or months) return 4 previous periods, do not include the current year, half-year, quarter or month. Determine Question_Intent based on FISCAL_PERIOD_KEYWORDS and INCLUDES_TODAY_KEYWORDS
{additional_important_notice}

INCLUDES_TODAY_KEYWORDS

</instructions>

<formatting>
This information is to be output only when mentioned in the question. Format the output following these guidelines:

<format_guidelines>
{format_instructions}
</format_guidelines>

You MUST follow these rules:
    - Do not add anything other than the defined JSON schema
    - Do not say, this is the JSON output I requested
    - Do not justify your answer
    - Provide only the JSON
    - Follow closely the formatting instructions
    - Do not add other fields, than defined in format_guidelines
    {format_instructions_additional}
</formatting>
Remember that today is {today_date}.
Follow these examples, format them according to the format_guidelines<examples>
{examples}
</examples>

Apply these instructions to this question
{question}
"""

# STRING OUTPUT - Prompt Inputs
# -----------------------------


def time_threshold_date_examples_string(today_date):
    output = [
        [
            "Current year",
            f"""Question_Intent: FP, WhichPeriods: B, PeriodStart: {today_date.year}-01-01, PeriodEnd: {today_date.year}-12-31, Explanation: "Question_Intent: FP, the matching phrase from FISCAL_PERIOD_KEYWORDS 'this year', today is {today_date}, returning the current fiscal year (following FISCAL_YEAR_DEFINITION)" """,
        ],
        [
            "Current quarter",
            f"""Question_Intent: FP, WhichPeriods: B, PeriodStart: {today_date + relativedelta(months=-(today_date.month%3) + 1, day=1)}, PeriodEnd: {today_date + relativedelta(months=-(today_date.month%3) + 3, day=31)}, Explanation: "Question_Intent: FP, the matching phrase from FISCAL_PERIOD_KEYWORDS 'this quarter', today is {today_date}, returning the current fiscal quarter (following FISCAL_QUARTER_DEFINITION)" """,
        ],
        [
            "Current half-year",
            f"""Question_Intent: FP, WhichPeriods: B, PeriodStart: {today_date + relativedelta(months=-(today_date.month%6) + 1, day=1)}, PeriodEnd: {today_date + relativedelta(months=-(today_date.month%6) + 6, day=31)}, Explanation: "Question_Intent: FP, the matching phrase from FISCAL_PERIOD_KEYWORDS 'last half-year' or 'next half-year', today is {today_date}, returning the current fiscal half-year (following FISCAL_HALF_YEAR_DEFINITION)" """,
        ],
        [
            "Current month",
            f"""Question_Intent: FP, WhichPeriods: B, PeriodStart: {today_date + relativedelta(day=1)}, PeriodEnd: {today_date + relativedelta(day=31)}, Explanation: "Question_Intent: FP, the matching phrase from FISCAL_PERIOD_KEYWORDS 'last month' or 'next month', today is {today_date}, returning the current fiscal month" """,
        ],
        [
            "Last year",
            f"""Question_Intent: FP, WhichPeriods: B, PeriodStart: {today_date.year - 1}-01-01, PeriodEnd: {today_date.year - 1}-12-31, Explanation: "Question_Intent: FP, the matching phrase from FISCAL_PERIOD_KEYWORDS 'last year', today is {today_date}, returning the previous fiscal year (following FISCAL_YEAR_DEFINITION)" """,
        ],
        [
            "Last 3 years",
            f"""Question_Intent: FP, WhichPeriods: B, PeriodStart: {today_date.year - 3}-01-01, PeriodEnd: {today_date.year - 1}-12-31, Explanation: "Question_Intent: FP, the matching phrase from FISCAL_PERIOD_KEYWORDS 'last year', today is {today_date}, returning the previous 3 fiscal years (following FISCAL_YEAR_DEFINITION)" """,
        ],
        [
            "Last quarter",
            f"""Question_Intent: FP, WhichPeriods: B, PeriodStart: {today_date + relativedelta(months=-(today_date.month%3) - 2, day=1)}, PeriodEnd: {today_date + relativedelta(months=-(today_date.month%3), day=31)}, Explanation: "Question_Intent: FP, the matching phrase from FISCAL_PERIOD_KEYWORDS 'last quarter', today is {today_date}, returning the previous fiscal quarter (following FISCAL_QUARTER_DEFINITION)" """,
        ],
        [
            "Previous half-year",
            f"""Question_Intent: FP, WhichPeriods: B, PeriodStart: {today_date + relativedelta(months=-(today_date.month%6) - 5, day=1)}, PeriodEnd: {today_date + relativedelta(months=-(today_date.month%6), day=31)}, Explanation: "Question_Intent: FP, the matching phrase from FISCAL_PERIOD_KEYWORDS 'previous half-year', today is {today_date}, returning the previous fiscal half-year (following FISCAL_HALF_YEAR_DEFINITION)" """,
        ],
        [
            "Last month",
            f"""Question_Intent: FP, WhichPeriods: B, PeriodStart: {today_date + relativedelta(months=-1, day=1)}, PeriodEnd: {today_date + relativedelta(months=-1, day=31)}, Explanation: "Question_Intent: FP, the matching phrase from FISCAL_PERIOD_KEYWORDS 'last month', today is {today_date}, returning the previous fiscal month" """,
        ],
        [
            "Next year",
            f"""Question_Intent: FP, WhichPeriods: B, PeriodStart: {today_date.year + 1}-01-01, PeriodEnd: {today_date.year + 1}-12-31, Explanation: "Question_Intent: FP, the matching phrase from FISCAL_PERIOD_KEYWORDS 'next year', today is {today_date}, returning the next fiscal year (following FISCAL_YEAR_DEFINITION)" """,
        ],
        [
            "Next quarter",
            f"""Question_Intent: FP, WhichPeriods: B, PeriodStart: {today_date + relativedelta(months=-(today_date.month%3) + 4, day=1)}, PeriodEnd: {today_date + relativedelta(months=-(today_date.month%3)+6, day=31)}, Explanation: "Question_Intent: FP, the matching phrase from FISCAL_PERIOD_KEYWORDS 'next quarter', today is {today_date}, returning the next fiscal quarter (following FISCAL_QUARTER_DEFINITION)" """,
        ],
        [
            "Next half-year",
            f"""Question_Intent: FP, WhichPeriods: B, PeriodStart: {today_date + relativedelta(months=-(today_date.month%6) + 6, day=1)}, PeriodEnd: {today_date + relativedelta(months=-(today_date.month%6) + 12, day=31)}, Explanation: "Question_Intent: FP, the matching phrase from FISCAL_PERIOD_KEYWORDS 'next half-year', today is {today_date}, returning the next fiscal half-year (following FISCAL_HALF_YEAR_DEFINITION)" """,
        ],
        [
            "Next month",
            f"""Question_Intent: FP, WhichPeriods: B, PeriodStart: {today_date + relativedelta(months=+1, day=1)}, PeriodEnd: {today_date + relativedelta(months=+1, day=31)}, Explanation: "Question_Intent: FP, the matching phrase from FISCAL_PERIOD_KEYWORDS 'next month', today is {today_date}, returning the next fiscal month" """,
        ],
        [
            "List of securities with maturity before 2024",
            """Question_Intent: SD, WhichPeriods: OE, PeriodStart: null, PeriodEnd: 2023-12-31, Explanation: "Question_Intent: SD, PeriodStart is not provided, PeriodEnd date is the last day of 2023" """,
        ],
        [
            "Show me research about company ABC published after May 2023",
            """Question_Intent: SD, WhichPeriods: OS, PeriodStart: 2023-06-01, PeriodEnd: null, Explanation: "Question_Intent: SD, PeriodStart is set to the first day after May 2023 (which is 2023-06-01), PeriodEnd is not provided" """,
        ],
        [
            "List all articles dated between 20 and 30 June 2023",
            """Question_Intent: SD, WhichPeriods: B, PeriodStart: 2023-06-20, PeriodEnd: 2023-06-30, Explanation: "Question_Intent: SD, PeriodStart and PeriodEnd dates are provided" """,
        ],
        [
            "List all bonds which expired in 2021",
            """Question_Intent: SD, WhichPeriods: B, PeriodStart: 2023-01-01, PeriodEnd: 2023-12-31, Explanation: "Question_Intent: SD, The question is about year 2021, setting PeriodEnd the beginning of 2021 and PeriodEnd to the end of 2021" """,
        ],
        [
            "Show me all bonds maturing this year",
            f"""Question_Intent: FP, WhichPeriods: B, PeriodStart: {today_date.year}-01-01, PeriodEnd: {today_date.year}-12-31, Explanation: "Question_Intent: FP, the matching phrase from FISCAL_PERIOD_KEYWORDS 'this year', today is {today_date}, returning the current fiscal year (following FISCAL_YEAR_DEFINITION)" """,
        ],
        [
            "What securities will mature in 2050?",
            """Question_Intent: SD, WhichPeriods: B, PeriodStart: 2050-01-01, PeriodEnd: 2050-12-31, Explanation: "Question_Intent: SD, The question is about year 2021, setting PeriodEnd the beginning of 2021 and PeriodEnd to the end of 2021" """,
        ],
        [
            "Financial reports published last two years",
            f"""Question_Intent: FP, WhichPeriods: B, PeriodStart: {today_date.year - 2}-01-01, PeriodEnd: {today_date.year - 1}-12-31, Explanation: "Question_Intent: FP, the matching phrase from FISCAL_PERIOD_KEYWORDS 'last year', today is {today_date}, returning two previous fiscal years (following FISCAL_YEAR_DEFINITION)" """,
        ],
        [
            "Financial reports published last two years",
            f"""Question_Intent: FP, WhichPeriods: B, PeriodStart: {today_date.year - 2}-01-01, PeriodEnd: {today_date.year - 1}-12-31, Explanation: "Question_Intent: FP, the matching phrase from FISCAL_PERIOD_KEYWORDS 'last year', today is {today_date}, returning two previous fiscal years (following FISCAL_YEAR_DEFINITION)" """,
        ],
        [
            "Show me list of construction companies whose credit rating was downgraded in the last 5 years",
            f"""Question_Intent: FP, WhichPeriods: B, PeriodStart: {today_date.year - 5}-01-01, PeriodEnd: {today_date.year - 1}-12-31, Explanation: "Question_Intent: FP, the matching phrase from FISCAL_PERIOD_KEYWORDS 'last year', today is {today_date}, returning five previous fiscal years (following FISCAL_YEAR_DEFINITION)" """,
        ],
        [
            "Show me all German companies with rating downgrade inside the previous half-year",
            f"""Question_Intent: FP, WhichPeriods: B, PeriodStart: {today_date.year - 1}-07-01, PeriodEnd: {today_date.year - 1}-12-31, Explanation: "Question_Intent: FP, the matching phrase from FISCAL_PERIOD_KEYWORDS 'inside last half-year', today is {today_date}, returning the previous fiscal half-year (following FISCAL_HALF_YEAR_DEFINITION)" """,
        ],
        [
            "What was the inflation rate in previous year?",
            f"""Question_Intent: FP, WhichPeriods: B, PeriodStart: {today_date.year - 1}-01-01, PeriodEnd: {today_date.year - 1}-12-31, Explanation: "Question_Intent: FP, the matching phrase from FISCAL_PERIOD_KEYWORDS 'previous year', today is {today_date}, returning the previous fiscal year (following FISCAL_YEAR_DEFINITION)" """,
        ],
        [
            "What were important events for ABC company inside last two quarters?",
            f"""Question_Intent: FP, WhichPeriods: B, PeriodStart: {today_date + relativedelta(months=-(today_date.month%3) - 5, day=1)}, PeriodEnd: {today_date + relativedelta(months=-(today_date.month%3), day=31)}, Explanation: "Question_Intent: FP, the matching phrase from FISCAL_PERIOD_KEYWORDS 'inside last quarter', today is {today_date}, returning the previous two fiscal quarters (following FISCAL_QUARTER_DEFINITION)" """,
        ],
        [
            "Were there any important economic events in the EU during last three quarters?",
            f"""Question_Intent: FP, WhichPeriods: B, PeriodStart: {today_date + relativedelta(months=-(today_date.month%3) - 8, day=1)}, PeriodEnd: {today_date + relativedelta(months=-(today_date.month%3), day=31)}, Explanation: "Question_Intent: FP, the matching phrase from FISCAL_PERIOD_KEYWORDS 'last quarter', today is {today_date}, returning the previous 3 fiscal quarters (following FISCAL_QUARTER_DEFINITION)" """,
        ],
        [
            "Will FED raise interest rates during next two years?",
            f"""Question_Intent: FP, WhichPeriods: B, PeriodStart: {today_date.year+1}-01-01, PeriodEnd = {today_date.year+2}-12-31, Explanation: "Question_Intent: FP, the matching phrase from FISCAL_PERIOD_KEYWORDS 'next year', today is {today_date}, returning the next 2 fiscal years (following FISCAL_YEAR_DEFINITION)" """,
        ],
        [
            "Will company ABC pay dividend next quarter?",
            f"""Question_Intent: FP, WhichPeriods: B, PeriodStart: {today_date + relativedelta(months=-(today_date.month%3) + 4, day=1)}, PeriodEnd: {today_date + relativedelta(months=-(today_date.month%3) + 6, day=31)}, Explanation: "Question_Intent: FP, the matching phrase from FISCAL_PERIOD_KEYWORDS 'next quarter', today is {today_date}, returning the next fiscal quarter (following FISCAL_QUARTER_DEFINITION)" """,
        ],
        [
            "Securities issued within three last quarters",
            f"""Question_Intent: IT, WhichPeriods: B, PeriodStart: {today_date + relativedelta(months=-9)}, PeriodEnd: {today_date}, Explanation: "Question_Intent: IT, the matching phrase from INCLUDES_TODAY_KEYWORDS 'within last quarter', today is {today_date}, to get PeriodStart the number of days equal to 3 quarters was subtracted from today's date, PeriodEnd is today" """,
        ],
        [
            "Was there any bonds issuances confined to last two quarters?",
            f"""Question_Intent: IT, WhichPeriods: B, PeriodStart: {today_date + relativedelta(months=-6)}, PeriodEnd: {today_date}, Explanation: "Question_Intent: IT, the matching phrase from INCLUDES_TODAY_KEYWORDS 'confined to last quarter', today is {today_date}, to get PeriodStart the number of days equal to 2 quarters was subtracted from today's date, PeriodEnd is today" """,
        ],
        [
            "List all Italian companies whose rating deteriorated in less than a year",
            f"""Question_Intent: IT, WhichPeriods: B, PeriodStart: {today_date + relativedelta(years=-1)}, PeriodEnd: {today_date}, Explanation: "Question_Intent: IT, the matching phrase from INCLUDES_TODAY_KEYWORDS 'in less than a year', today is {today_date}, to get PeriodStart the number of days equal to 1 year was subtracted from today's date, PeriodEnd is today" """,
        ],
        [
            "Did ABC company pay a dividend in under two years?",
            f"""Question_Intent: IT, WhichPeriods: B, PeriodStart: {today_date + relativedelta(years=-2)}, PeriodEnd: {today_date}, Explanation: "Question_Intent: IT, the matching phrase from INCLUDES_TODAY_KEYWORDS 'in under a year', today is {today_date}, to get PeriodStart the number of days equal to 1 year was subtracted from today's date, PeriodEnd is today" """,
        ],
        [
            "Is FED expected to raise interest rates within next year?",
            f"""Question_Intent: IT, WhichPeriods: B, PeriodStart: {today_date}, PeriodEnd: {today_date + relativedelta(years=+2)}, Explanation: "Question_Intent: IT, the matching phrase from INCLUDES_TODAY_KEYWORDS 'within next year', today is {today_date}, PeriodStart is today, to get PeriodEnd the number of days equal to 1 year was added to today's date" """,
        ],
        [
            "What important economic events will take place in less than a year from now?",
            f"""Question_Intent: IT, WhichPeriods: B, PeriodStart: {today_date}, PeriodEnd: {today_date + relativedelta(years=+1)}, Explanation: "Question_Intent: IT, the matching phrase from INCLUDES_TODAY_KEYWORDS 'in less than a year from now', today is {today_date}, PeriodStart is today, to get PeriodEnd the number of days equal to 1 year was added to today's date" """,
        ],
        [
            "Is CPI expected to grow within next three quarters?",
            f"""Question_Intent: IT, WhichPeriods: B, PeriodStart: f{today_date}, PeriodEnd: {today_date + relativedelta(months=+9)}, Explanation: "Question_Intent: IT, the matching phrase from INCLUDES_TODAY_KEYWORDS 'within next quarter', today is {today_date}, PeriodStart is today, to get PeriodEnd the number of days equal to 3 quarters was added to today's date" """,
        ],
        [
            "How many bonds will mature within next quarter?",
            f"""Question_Intent: IT, WhichPeriods: B, PeriodStart: {today_date}, PeriodEnd: {today_date + relativedelta(months=+3)}, Explanation: "Question_Intent: IT, the matching phrase from INCLUDES_TODAY_KEYWORDS 'within next quarter', today is {today_date}, PeriodStart is today, to get PeriodEnd the number of days equal to 1 quarter was added to today's date" """,
        ],
        [
            "Is any of the bonds maturing in under half-year from today?",
            f"""Question_Intent: IT, WhichPeriods: B, PeriodStart: {today_date}, PeriodEnd: {today_date + relativedelta(months=+6)}, Explanation: "Question_Intent: IT, the matching phrase from INCLUDES_TODAY_KEYWORDS 'in under half-year from today', today is {today_date}, PeriodStart is today, to get PeriodEnd the number of days equal to half year was added to today's date" """,
        ],
        [
            "Has German rating been updater recent year?",
            f"""Question_Intent: IT, WhichPeriods: B, PeriodStart: {today_date+ relativedelta(years=-1)}, PeriodEnd: {today_date}, Explanation: "Question_Intent: IT, the matching phrase from INCLUDES_TODAY_KEYWORDS 'recent year', today is {today_date}, to get PeriodStart the number of days equal to year was subtracted from today's date, PeriodEnd is today" """,
        ],
        [
            "Show me all recent actions of Tesla's credit rating",
            """Question_Intent: US, WhichPeriods: null, PeriodStart: null, PeriodEnd: null, Explanation: "Question_Intent: US, recent credit action mentioned, but no specific period (year, half-year, quarter or month) was provided. PeriodStart and PeriodEnd set to null", quoting the instructions: 'When asked about recent/current rating actions (...) and the period remains unspecified (...), you MUST NOT find matching keywords in on FISCAL_PERIOD_KEYWORDS and INCLUDES_TODAY_KEYWORDS. Output Question_Intent: US, WhichPeriods: null, PeriodStart: null, PeriodEnd: null' " """,
        ],
        [
            "When was the last rating update of credit rating for the US?",
            """Question_Intent: US, WhichPeriods: null, PeriodStart: null, PeriodEnd: null, Explanation: "Question_Intent: US, recent credit action event mentioned, but no specific period was provided. PeriodStart and PeriodEnd set to null , quoting the instructions: 'When asked about recent/current rating actions (...) and the period remains unspecified (...), you MUST NOT find matching keywords in on FISCAL_PERIOD_KEYWORDS and INCLUDES_TODAY_KEYWORDS. Output Question_Intent: US, WhichPeriods: null, PeriodStart: null, PeriodEnd: null'" """,
        ],
        [
            "Show me all pharmaceutical companies whose rating was recently updated.",
            """Question_Intent: US, WhichPeriods: null, PeriodStart: null, PeriodEnd: null, Explanation: "Question_Intent: US, recent credit action event mentioned ("recently updated"), but period type is unspecified. Not looking for matching keywords in on FISCAL_PERIOD_KEYWORDS and INCLUDES_TODAY_KEYWORDS, PeriodStart and PeriodEnd set to null" """,
        ],
        [
            "Summarize the most recent research about company ABC",
            """Question_Intent: US, WhichPeriods: null, PeriodStart: null, PeriodEnd: null, Explanation: "Question_Intent: US, recent credit action event mentioned ("most recent research"), but period type is unspecified. Not looking for matching keywords in on FISCAL_PERIOD_KEYWORDS and INCLUDES_TODAY_KEYWORDS, PeriodStart and PeriodEnd set to null" """,
        ],
        [
            "Do sovereigns have debt ratings?",
            """Question_Intent: US, WhichPeriods: null, PeriodStart: null, PeriodEnd: null, Explanation: "Question_Intent: US, the question is about whether sovereigns have debt ratings, but does not specify any period. Not looking for matching keywords in FISCAL_PERIOD_KEYWORDS and INCLUDES_TODAY_KEYWORDS, PeriodStart and PeriodEnd set to null." """,
        ],
        [
            "What was company ABC dividend in Q1?",
            f"""Question_Intent: SD, WhichPeriods: B, PeriodStart: {today_date.year}-01-01, PeriodEnd: {today_date.year}-03-31, Explanation: "Question_Intent: SD, period not fully specified, the year not mentioned, today is {today_date}. Assuming, that the question pertains to the current year: {today_date.year}. PeriodStart set to the beginning of Q1 {today_date.year}, PeriodStart set to the end of Q1 {today_date.year}" """,
        ],
        [
            "What was GDP growth over last few years?",
            f"""Question_Intent: SD, WhichPeriods: B, PeriodStart: {today_date.year-4}-01-01, PeriodEnd: {today_date.year-1}-12-31, Explanation: "Question_Intent: FP, the matching phrase from FISCAL_PERIOD_KEYWORDS 'last year', the number of years not specified. As the question is about "few" years the number of years set to 4 years. Today is {today_date}, returning four previous fiscal years" """,
        ],
        [
            "What is the inflation rate year to date?",
            f"""Question_Intent: PD, WhichPeriods: B, PeriodStart: {today_date.year}-01-01, PeriodEnd: {today_date}, Explanation: "Question_Intent: PD, the matching phrase from PERIOD_TO_DATE_KEYWORDS 'year to date', today is {today_date}, PeriodStart is the beginning of the current fiscal year, PeriodEnd is today" """,
        ],
        [
            "What was the change in company ABC stock value QTD?",
            f"""Question_Intent: PD, WhichPeriods: B, PeriodStart: {today_date + relativedelta(months=-(today_date.month%3) + 1, day=1)}, PeriodEnd: {today_date}, Explanation: "Question_Intent: PD, the matching phrase from PERIOD_TO_DATE_KEYWORDS 'QTD', today is {today_date}, PeriodStart is the beginning of the current fiscal quarter, PeriodEnd is today" """,
        ],
        [
            "Has there been any announcements about company ABC month to date?",
            f"""Question_Intent: PD, WhichPeriods: B, PeriodStart: {today_date + relativedelta(day=1)}, PeriodEnd: {today_date}, Explanation: "Question_Intent: PD, the matching phrase from PERIOD_TO_DATE_KEYWORDS 'month to date', today is {today_date}, PeriodStart is the beginning of the current fiscal month, PeriodEnd is today" """,
        ],
        [
            "Which of Chinese companies had their rating recently updated",
            """Question_Intent: US, WhichPeriods: null, PeriodStart: null, PeriodEnd: null, Explanation: "Question_Intent: US, recent credit rating action mentioned ("recently updated"), period not specified, PeriodStart and PeriodEnd set to null, quoting the instructions: 'When asked about recent/current rating actions (...) and the period remains unspecified (...), you MUST NOT find matching keywords in on FISCAL_PERIOD_KEYWORDS and INCLUDES_TODAY_KEYWORDS. Output Question_Intent: US, WhichPeriods: null, PeriodStart: null, PeriodEnd: null'" """,
        ],
        [
            "Retrieve all companies in the pharmaceutical sector were newly rated",
            """Question_Intent: US, WhichPeriods: null, PeriodStart: null, PeriodEnd: null, Explanation: "Question_Intent: US, recent credit rating action mentioned ("newly rated"), period not specified, PeriodStart and PeriodEnd set to null, quoting the instructions: 'When asked about recent/current rating actions (...) and the period remains unspecified (...), you MUST NOT find matching keywords in on FISCAL_PERIOD_KEYWORDS and INCLUDES_TODAY_KEYWORDS. Output Question_Intent: US, WhichPeriods: null, PeriodStart: null, PeriodEnd: null'" """,
        ],
        [
            "Provide me a list of Brazilian companies in the mining sector which had their rating downgraded",
            """Question_Intent: US, WhichPeriods: null, PeriodStart: null, PeriodEnd: null, Explanation: "Question_Intent: US, recent credit rating action mentioned ("downgraded"), period not specified, PeriodStart and PeriodEnd set to null, quoting the instructions: 'When asked about recent/current rating actions (...) and the period remains unspecified (...), you MUST NOT find matching keywords in on FISCAL_PERIOD_KEYWORDS and INCLUDES_TODAY_KEYWORDS. Output Question_Intent: US, WhichPeriods: null, PeriodStart: null, PeriodEnd: null'" """,
        ],
        [
            "How many companies have recently defaulted in the automotive industry in the US?",
            """Question_Intent: US, WhichPeriods: null, PeriodStart: null, PeriodEnd: null, Explanation: "Question_Intent: US, recent credit action event mentioned ("recently defaulted"), but period type is unspecified. Not looking for matching keywords in on FISCAL_PERIOD_KEYWORDS and INCLUDES_TODAY_KEYWORDS, PeriodStart and PeriodEnd set to null" """,
        ],
        [
            "What are the last 10 companies from the automotive segmeht that had their rating upgraded?",
            """Question_Intent: US, WhichPeriods: null, PeriodStart: null, PeriodEnd: null, Explanation: "Question_Intent: US, recent credit action event mentioned ("recently upgraded"), but period type is unspecified. Not looking for matching keywords in on FISCAL_PERIOD_KEYWORDS and INCLUDES_TODAY_KEYWORDS, PeriodStart and PeriodEnd set to null" """,
        ],
        [
            "How many companies were newly rated in Spain, in the corporate segment?",
            """Question_Intent: US, WhichPeriods: null, PeriodStart: null, PeriodEnd: null, Explanation: "Question_Intent: US, recent credit action event mentioned ("newly rated"), but period type is unspecified. Not looking for matching keywords in on FISCAL_PERIOD_KEYWORDS and INCLUDES_TODAY_KEYWORDS, PeriodStart and PeriodEnd set to null" """,
        ],
        [
            "Compare the impact of trump trade tariffs on xyz company and abc company",
            """Question_Intent: US, WhichPeriods: null, PeriodStart: null, PeriodEnd: null, Explanation: "Question_Intent: US, period is not specified. Not looking for matching keywords in on FISCAL_PERIOD_KEYWORDS and INCLUDES_TODAY_KEYWORDS, PeriodStart and PeriodEnd set to null" """,
        ],
    ]
    output_string = "\n\n________\n\n".join(
        [f"""Question: {question} \nOutput: {response}""" for question, response in output]
    )
    return output_string


def time_threshold_date_additional_examples_string(today_date):
    output = [
        [
            f"What are the global credit conditions Q{ceil(today_date.month/3)} {today_date.year}?",
            f"""Question_Intent: SD, WhichPeriods: B, PeriodStart: {date(today_date.year, ceil(today_date.month/3)*3-2, 1)}, PeriodEnd: {date(today_date.year, ceil(today_date.month/3)*3, 1) + relativedelta(months=+3)}, Explanation: "Question_Intent: SD, the question mentions current quarter and is most probably more about an outlook, so setting PeriodEnd to end of the mentioned period." """,
        ],
        [
            f"What is the predicted inflation rate through {today_date.year}?",
            f"""Question_Intent: SD, WhichPeriods: B, PeriodStart: {today_date.year}-01-01, PeriodEnd: {today_date.year}-12-31, Explanation: "Question_Intent: SD, the question mentions current year and it's about predictions, so setting PeriodEnd to end of the mentioned period." """,
        ],
        [
            "What trends are expected to impact the tech sector in this year?",
            f"""Question_Intent: FP, WhichPeriods: B, PeriodStart: {today_date.year}-01-01, PeriodEnd: {today_date.year}-12-31, Explanation: the matching phrase from FISCAL_PERIOD_KEYWORDS 'this year', today is {today_date}, returning the current fiscal year (following FISCAL_YEAR_DEFINITION), with PeriodEnd set to end of the mentioned period because the question is about expectations/predictions. """,
        ],
        [
            f"Show me articles for XYZ published in {today_date.year}",
            f"""Question_Intent: PD, WhichPeriods: B, PeriodStart: {today_date.year}-01-01, PeriodEnd: {today_date}, Explanation: "Question_Intent: PD, the matching phrase from PERIOD_TO_DATE_KEYWORDS 'this year (past events)', today is {today_date}. The question explicitly mentions current year and is about events that have already happened, so setting PeriodEnd to today's date." """,
        ],
        [
            f"Has Tesla changed it's rating in {today_date.year}?",
            f"""Question_Intent: PD, WhichPeriods: B, PeriodStart: {today_date.year}-01-01, PeriodEnd: {today_date}, Explanation: "Question_Intent: PD, the matching phrase from PERIOD_TO_DATE_KEYWORDS 'this year (past events)', today is {today_date}. The question mentions current year and it's about up-to-date state, so setting PeriodEnd to today's date." """,
        ],
        [
            f"Which banks pivoted hardest between {today_date.year-2} and {today_date.year}?",
            f"""Question_Intent: PD, WhichPeriods: B, PeriodStart: {today_date.year-2}-01-01, PeriodEnd: {today_date}, Explanation: "Question_Intent: PD, the matching phrase from PERIOD_TO_DATE_KEYWORDS '{today_date.year} (past events)', today is {today_date}. The question explicitly mentions current year (as the end of the period) and is about past events that have happened until now, so setting PeriodEnd to today's date." """,
        ],
        [
            "What is the outlook for xyz?",
            """Question_Intent: US, WhichPeriods: null, PeriodStart: null, PeriodEnd: null, Explanation: "Question_Intent: US, this is a forward-looking question, but period is unspecified. Not looking for matching keywords in FISCAL_PERIOD_KEYWORDS and INCLUDES_TODAY_KEYWORDS, PeriodStart and PeriodEnd set to null" """,
        ],
        [
            "What is xyz's <N>Y Bond yield forecast?",
            """Question_Intent: US, WhichPeriods: null, PeriodStart: null, PeriodEnd: null, Explanation: "Question_Intent: US, this is a forward-looking question, but period is unspecified. Not looking for matching keywords in FISCAL_PERIOD_KEYWORDS and INCLUDES_TODAY_KEYWORDS, PeriodStart and PeriodEnd set to null" """,
        ],
    ]
    output_string = (
        time_threshold_date_examples_string(today_date=today_date)
        + "\n\n________\n\n"
        + "\n\n________\n\n".join([f"""Question: {question} \nOutput: {response}""" for question, response in output])
    )
    return output_string


def empty_instructions_string(today_date):
    return ""


TIME_THRESHOLD_DATES_INPUT = {
    # "today_date": TODAY_DATE,
    "short_task_description": "",
    "format_instructions": output_parser_time_threshold_dates.get_format_instructions(),
    "format_instructions_additional": "",
    # "examples": TIME_THRESHOLD_DATES_EXAMPLES_FORMATTED,
    "additional_important_notice": "",
}

TIME_THRESHOLD_DATES_INPUT_UNSTRUCTURED = {
    # "today_date": TODAY_DATE,
    "short_task_description": "",
    "format_instructions": output_parser_time_threshold_dates.get_format_instructions(),
    "format_instructions_additional": "",
    # "examples": TIME_THRESHOLD_DATES_EXAMPLES_FORMATTED_UNSTRUCTURED,
    "additional_important_notice": ADDITIONAL_INFO_UNSTRUCTURED,
}

TIME_THRESHOLD_PROMPT_DATE_OUTPUT = SimplePromptTemplate(
    template=TIME_THRESHOLD_DATES_OUTPUT_PROMPT,
    partial_variables=TIME_THRESHOLD_DATES_INPUT,
)

TIME_THRESHOLD_PROMPT_DATE_OUTPUT_UNSTRUCTURED = SimplePromptTemplate(
    template=TIME_THRESHOLD_DATES_OUTPUT_PROMPT,
    partial_variables=TIME_THRESHOLD_DATES_INPUT_UNSTRUCTURED,
)
