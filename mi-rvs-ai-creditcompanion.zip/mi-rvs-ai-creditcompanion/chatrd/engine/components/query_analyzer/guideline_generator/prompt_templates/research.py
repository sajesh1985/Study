from chatrd.engine.components.query_analyzer.utils import EntityType

RESEARCH_GUIDELINES_EXAMPLES = """
{
    "question": "What is the latest research for xyz?",
    "guidelines": "1. Write an abstract that will summarize all the key point of the answer and call it **Summary**. Format the abstract/summary part as a paragraph. \n2. Follow the abstract/summary with 'Based on the latest S&P Global Ratings research:'\n3. Include the following key points in bullet format: *Business Profile**, **Credit Highlights**, **Challenges and Risks** (from Business Risks and Financial Risks sections of articles), **Financial Performance**, **Liquidity**, **Outlook and Rating Scenarios**, **Downside and Upside Scenarios**.\n3. Mention any recent updates or changes to xyz's rating or CreditWatch/Outlook, including what changed, when it changed, and how it happened."
}
__________________
{
    "question": "What is the health of xyz?",
    "guidelines": "1. Write an abstract that will summarize all the key point of the answer and call it **Summary**. Format the abstract/summary part as a paragraph. \n2. Follow the abstract/summary with 'Based on the latest S&P Global Ratings research:'\n3. Include the following key points in bullet format:  **Business Profile**, **Challenges and Risks**, **Financial Performance and Outlook**, **Outlook and Rating Scenarios**, **Downside and Upside Scenarios**.\n3. Mention any recent updates or changes to xyz's rating or CreditWatch/Outlook, including what changed, when it changed, and how it happened."
}
"""


USPF_RS_RESEARCH_GUIDELINES_EXAMPLES = """
{
    "question": "What is the latest research for xyz?",
    "guidelines": "1. At the beginning of your response, you MUST provide a concise summary or abstract that encapsulates the main points of your entire response and call it **Summary**. This summary should give the reader a clear and quick understanding of the key information and insights you will cover. REMOVE any credit/credit profile ratings and credit watch outlook from the summary/abstract AND from any further information that you provide.\n2. Follow-Up Guidelines: After providing the summary, follow the rest of the guidelines as individual instructions to structure the detailed part of your response. Ignore the question and stick to the guidelines here.\n3. REMOVE any credit/credit profile ratings and credit watch outlook from the details/answers/responses you provide.\n4. After that summary on top, mention in bullets a pointwise summary of the following key header points if they are available in the documents saying 'Based on the latest S&P Global Ratings research:' : xyz's Economic fundamentals, Financial Risk, Management and governance, Financial Profile, State appropriations, Debt and contingent liabilities, Pensions and OPEB, Liquidity, Covenant Analysis. You must omit all headers where there is no relevant information.\n5. Skip all the header points to which you don't find any relevant information in the documents. Headers are optional only if there is relevant information.\n6. Follow the formatting example strictly.\n7. Formatting example:\n<header>**Summary**</header>\n\n<paragraph>content of summary</paragraph>\n\n<sentence>Based on the latest S&P Global Ratings research:</sentence>\n\n<optional><header>**Economic fundamentals**</header></optional>\n\n<optional><header>**Financial Risk**</header></optional>\n\n<optional><header>**Management and Governance**</header></optional>\n\n<optional><header>**Financial Profile**</header></optional>\n\n<optional><header>**State Appropriations**</header></optional>\n\n<optional><header>**Debt and Contingent Liabilities**</header></optional>\n\n<optional><header>**Pensions and OPEB**</header></optional>\n\n<optional><header>**Liquidity**</header></optional>\n\n<optional><header>**Covenant Analysis**</header></optional>\n8. When following the header points mentioned in the list keep in mind that you don't have to forcefully invent content for those header points and you must only keep a header point if you can find content about it in the context information provided AND you MUST SKIP the ones that you don't find any information about."
}
__________________
{
    "question": "What is the health of xyz?",
    "guidelines": "1. At the beginning of your response, you MUST provide a concise summary or abstract that encapsulates the main points of your entire response and call it **Summary**. This summary should give the reader a clear and quick understanding of the key information and insights you will cover. REMOVE any credit/credit profile ratings and credit watch outlook from the summary/abstract AND from any further information that you provide.\n2. Follow-Up Guidelines: After providing the summary, follow the rest of the guidelines as individual instructions to structure the detailed part of your response. Ignore the question and stick to the guidelines here.\n3. REMOVE any credit/credit profile ratings and credit watch outlook from the details/answers/responses you provide.\n4. After that summary on top, mention in bullets a pointwise summary of the following key header points if they are available in the documents saying 'Based on the latest S&P Global Ratings research' : xyz's Economic fundamentals, Financial Risk, Management and governance, Financial Profile, State appropriations, Debt and contingent liabilities, Pensions and OPEB, Liquidity, Covenant Analysis. You must omit all headers where there is no relevant information.\n5. Skip all the header points to which you don't find any relevant information in the documents. Headers are optional only if there is relevant information.\n6. Follow the formatting example strictly.\n7. Formatting example:\n<header>**Summary**</header>\n\n<paragraph>content of summary</paragraph>\n\n<sentence>Based on the latest S&P Global Ratings research:</sentence>\n\n<optional><header>**Economic fundamentals**</header></optional>\n\n<optional><header>**Financial Risk**</header></optional>\n\n<optional><header>**Management and Governance**</header></optional>\n\n<optional><header>**Financial Profile**</header></optional>\n\n<optional><header>**State Appropriations**</header></optional>\n\n<optional><header>**Debt and Contingent Liabilities**</header></optional>\n\n<optional><header>**Pensions and OPEB**</header></optional>\n\n<optional><header>**Liquidity**</header></optional>\n\n<optional><header>**Covenant Analysis**</header></optional>\n8. When following the header points mentioned in the list keep in mind that you don't have to forcefully invent content for those header points and you must only keep a header point if you can find content about it in the context information provided AND you MUST SKIP the ones that you don't find any information about."
}
__________________
{
    "question": "recent research for xyz?",
    "guidelines": "1. At the beginning of your response, you MUST provide a concise summary or abstract that encapsulates the main points of your entire response and call it **Summary**. This summary should give the reader a clear and quick understanding of the key information and insights you will cover. REMOVE any credit/credit profile ratings and credit watch outlook from the summary/abstract AND from any further information that you provide.\n2. Follow-Up Guidelines: After providing the summary, follow the rest of the guidelines as individual instructions to structure the detailed part of your response. Ignore the question and stick to the guidelines here.\n3. REMOVE any credit/credit profile ratings and credit watch outlook from the details/answers/responses you provide.\n4. After that summary on top, mention in bullets a pointwise summary of the following key header points if they are available in the documents saying 'Based on the latest S&P Global Ratings research:' : xyz's Economic fundamentals, Financial Risk, Management and governance, Financial Profile, State appropriations, Debt and contingent liabilities, Pensions and OPEB, Liquidity, Covenant Analysis. You must omit all headers where there is no relevant information.\n5. Skip all the header points to which you don't find any relevant information in the documents. Headers are optional only if there is relevant information.\n6. Follow the formatting example strictly.\n7. Formatting example:\n<header>**Summary**</header>\n\n<paragraph>content of summary</paragraph>\n\n<sentence>Based on the latest S&P Global Ratings research:</sentence>\n\n<optional><header>**Economic fundamentals**</header></optional>\n\n<optional><header>**Financial Risk**</header></optional>\n\n<optional><header>**Management and Governance**</header></optional>\n\n<optional><header>**Financial Profile**</header></optional>\n\n<optional><header>**State Appropriations**</header></optional>\n\n<optional><header>**Debt and Contingent Liabilities**</header></optional>\n\n<optional><header>**Pensions and OPEB**</header></optional>\n\n<optional><header>**Liquidity**</header></optional>\n\n<optional><header>**Covenant Analysis**</header></optional>\n8. When following the header points mentioned in the list keep in mind that you don't have to forcefully invent content for those header points and you must only keep a header point if you can find content about it in the context information provided AND you MUST SKIP the ones that you don't find any information about."
}
"""


RESEARCH_GUIDELINES_PROMPTS = """
You are an excellent financial credit analyst and you will be given a question from the user.
Your task will be to extract information regarding user question:
* Guidelines highlighting relevant factors when answering the question. Your answer MUST start with "Based on the latest S&P Global Rating's research..." and should be verbose, including as much *relevant* information as possible. (key: guidelines)

<Examples pairs of question (key: question) and guidelines (key: guidelines) are given below in JSON format:>
{examples}

Take a deep breath and understand that these examples should not affect the extractions for any other keys.

Answer JSON object which should contain following properties:
* "guidelines"

<Question>
{question}

Just return an guidelines JSON object. Return the JSON object only. Do not return 'Here are the guidelines for answering the question "{question}":' or any other string.
"""


research_guidelines = {
    "prompt": RESEARCH_GUIDELINES_PROMPTS,
    "examples": {
        EntityType.COMPANY: RESEARCH_GUIDELINES_EXAMPLES,
        EntityType.USPF: USPF_RS_RESEARCH_GUIDELINES_EXAMPLES,
        EntityType.REVENUE_SOURCE: USPF_RS_RESEARCH_GUIDELINES_EXAMPLES,
        EntityType.SOVEREIGN: RESEARCH_GUIDELINES_EXAMPLES,
    },
}
