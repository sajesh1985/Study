from chatrd.engine.data_service.model_output_parser import utils


def test_GenerateRatingList():
    greater_result_list = utils.GenerateRatingList(utils.GLOBAL_CREDIT_RATING_MAPPING).greater_than("a+")
    between_result_list = utils.GenerateRatingList(utils.GLOBAL_CREDIT_RATING_MAPPING).between("[b]-[bb]")

    greater_expected_result = ["aaa", "aa+", "aa", "aa-"]
    between_expected_result = ["bb", "bb-", "b+", "b"]

    assert greater_result_list == greater_expected_result
    assert between_result_list == between_expected_result


def test__format_rating_list_values():
    str_list_1 = ["aaa"]
    str_list_2 = ["bb", "bb-", "b+", "b"]

    result_1 = utils._format_rating_list_values(str_list_1)
    result_2 = utils._format_rating_list_values(str_list_2)

    expected_result_1 = "aaa"
    expected_result_2 = "\"'bb','bb-','b+','b'\""

    assert result_1 == expected_result_1
    assert result_2 == expected_result_2


def test_validate_rating_string():
    value_str_1 = "positive, stable, increasing"
    value_str_2 = "[c+]-[a]"

    (
        value_str_1,
        operator_payload_1,
        operator_text_1,
    ) = utils.validate_rating_string(334235, value_str_1, 7, "in")
    (
        value_str_2,
        operator_payload_2,
        operator_text_2,
    ) = utils.validate_rating_string(334045, value_str_2, 17, "between")

    expected_value_str_1 = (
        "'positive', 'developing', 'stable', 'negative', 'watch pos', 'watch dev', 'watch neg', 'nm', 'nr'"
    )
    expected_value_str_2 = "'AAA','AA+','AA','AA-','A+','A','A-','BBB+','BBB','BBB-','BB+','BB','BB-','B+','B','B-','CCC+','CCC','CCC-','CC','C','R','SD','D','NR'".lower()
    expected_operator_payload = 7
    expected_operator_text = "in"

    assert value_str_1 == expected_value_str_1
    assert value_str_2 == expected_value_str_2
    assert operator_payload_1 == expected_operator_payload
    assert operator_payload_2 == expected_operator_payload
    assert operator_text_1 == expected_operator_text
    assert operator_text_2 == expected_operator_text
