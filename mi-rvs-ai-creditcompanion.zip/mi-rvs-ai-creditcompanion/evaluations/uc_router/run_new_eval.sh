set -e
python evaluations/uc_router/new_eval.py