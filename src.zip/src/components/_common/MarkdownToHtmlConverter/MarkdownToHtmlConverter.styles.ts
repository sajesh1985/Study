import styled from '@emotion/styled';

export const MarkdownToHtmlConverterStyled = styled.div`
  font-feature-settings: 'clig' off, 'liga' off;
  font-family: "Akkurat";
  font-size: 11px;
  font-style: normal;
  font-weight: 400;
  line-height: var(--scale-line-height-150);
  max-height: 80vh;
  overflow: auto;

  & a {
    color: var(--color-text-link);
  }

  & a:hover {
    color: var(--color-text-link-visited);
  }

  & a:visited {
    color: var(--color-text-link-visited);
  }
  
  table {
    width: 660px;
    border-collapse: collapse;
  }

  th,
  td {
    border: 1px solid #ddd;
    padding: 4px;
    // white-space: nowrap; /* Prevent text from wrapping */
  }

  th {
    // background-color: #f2f2f2;
  }
`;

