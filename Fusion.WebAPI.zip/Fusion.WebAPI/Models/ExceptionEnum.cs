﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace Fis.Epp.Fusion.WebAPI.Models
{
    public enum ExceptionEnum
    {
        [Description("cipherText")]
        cipherText,
        [Description("Key")]
        Key,
        [Description("IV")]
        IV,
        [Description("plainText")]
        plainText,
        [Description("validationKey")]
        validationKey,
        [Description("claims")]
        claims,
        [Description("token")]
        token
    }
}
