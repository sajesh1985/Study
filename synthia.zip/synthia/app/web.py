"""Streamlit frontend for Synthia."""

import streamlit as st
import requests
import time
import json
import logging
import hashlib
import asyncio
import uuid
from typing import Dict, List, Any, Optional
import pandas as pd
# import plotly.express as px
from sympy import sec
from src.synthia.config.url_config import getApiUrl
from src.synthia.utils.template_util import get_sections
from src.synthia.utils import helper
import os
import datetime
import streamlit.components.v1 as components
import sys

from src.synthia.schemas.workflow import PeerCompany

# Configure page FIRST before any other Streamlit operations
st.set_page_config(
    page_title="Synthia - AI Report Generator",
    page_icon="📝",
    layout="wide",
    initial_sidebar_state="expanded",
)


# Configure logging AFTER page config for Streamlit compatibility
def setup_logging():
    """Setup logging configuration for Streamlit."""
    # Create a custom formatter
    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # Get the root logger
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)

    # Remove any existing handlers to avoid duplicates
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)

    # Create console handler for stdout (visible in Streamlit)
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(formatter)

    # Add handler to logger
    logger.addHandler(console_handler)

    # Also set up the specific logger for this module
    module_logger = logging.getLogger(__name__)
    module_logger.setLevel(logging.INFO)

    return module_logger


# Setup logging
logger = setup_logging()

# Define application directory path for use in image resolution
chart_images_dir = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..", "resources", "chart_images")
)
# chart_images_dir = os.path.join(app_dir, "chart_images")

# Log directory paths for debugging
logger.info(f"Chart images directory: {chart_images_dir}")
logger.info(f"Working directory: {os.getcwd()}")

# Ensure chart_images_dir exists and log its contents
if os.path.exists(chart_images_dir):
    logger.info(f"Chart images available: {os.listdir(chart_images_dir)}")
else:
    logger.warning(f"Chart images directory not found at {chart_images_dir}")


# Define settings directly instead of importing
def get_settings():
    """Simple settings function to avoid import issues"""

    class Settings:
        api_url = getApiUrl()
        # Default credentials (in production these should come from environment variables or a secure config)
        default_username = "admin"
        default_password_hash = (
            "5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8"
        )

    return Settings()


# Initialize session state for auth
if "authenticated" not in st.session_state:
    st.session_state.authenticated = False
if "login_attempts" not in st.session_state:
    st.session_state.login_attempts = 0
if "show_password" not in st.session_state:
    st.session_state.show_password = False
if "username" not in st.session_state:
    st.session_state.username = None

# Initialize session state for client selection
if "selected_client" not in st.session_state:
    st.session_state.selected_client = "system"

# Initialize session state
if "job_id" not in st.session_state:
    st.session_state.job_id = None
if "report_data" not in st.session_state:
    st.session_state.report_data = None
if "report_section" not in st.session_state:
    st.session_state.report_section = {}
if "monitoring" not in st.session_state:
    st.session_state.monitoring = False
if "outline_approved" not in st.session_state:
    st.session_state.outline_approved = False
if "outline_rejected" not in st.session_state:
    st.session_state.outline_rejected = False
if "show_rejection_options" not in st.session_state:
    st.session_state.show_rejection_options = False
if "revision_submitted" not in st.session_state:
    st.session_state.revision_submitted = False

# Add session state variables for outline approval workflow
if "awaiting_approval" not in st.session_state:
    st.session_state.awaiting_approval = False
if "outline_data" not in st.session_state:
    st.session_state.outline_data = None
if "show_revision_options" not in st.session_state:
    st.session_state.show_revision_options = False
if "last_status_check" not in st.session_state:
    st.session_state.last_status_check = None

# Allow user to add custom sections
if "user_sections" not in st.session_state:
    st.session_state.user_sections = []

# Add session state variables for final report approval workflow
if "awaiting_final_approval" not in st.session_state:
    st.session_state.awaiting_final_approval = False
if "final_report_data" not in st.session_state:
    st.session_state.final_report_data = None

# --- Add session state for section regeneration ---
if "regen_job_id" not in st.session_state:
    st.session_state.regen_job_id = None
if "regen_job_monitoring" not in st.session_state:
    st.session_state.regen_job_monitoring = False

if "regen_section_name" not in st.session_state:
    st.session_state.regen_section_name = None
if "regen_section_id" not in st.session_state:
    st.session_state.regen_section_id = None
if "regen_edited_section" not in st.session_state:
    st.session_state.regen_edited_section = None

if "regen_generate_clicked" not in st.session_state:
    st.session_state.regen_generate_clicked = False

if "custom_prompt" not in st.session_state:
    st.session_state.custom_prompt = ""
if "custom_prompt_input" not in st.session_state:
    st.session_state.custom_prompt_input = ""
if "prompt_id" not in st.session_state:
    st.session_state.prompt_id = ""
if "previous_prompt_id" not in st.session_state:
    st.session_state.previous_prompt_id = None



def get_api_url() -> str:
    """Get API URL from settings."""
    settings = get_settings()
    api_url = settings.api_url or "http://localhost:8000"
    return api_url


def get_token(username="", password="") -> str:
    """Get Token."""
    settings = get_settings()
    if st.session_state.username == settings.default_username:
        st.session_state.proptoken = helper.auth_token
        return helper.auth_token
    token = helper.get_headers(username, password)
    st.session_state.proptoken = token
    return token


def get_s3_template_prefix(client: str) -> str:
    """Get S3 template prefix based on selected client."""
    client_prefixes = {
        "system": "system/",
        "intesa": "intesa/",
        "shell": "shell/"
    }
    return client_prefixes.get(client.lower(), "system/")


def start_report_generation(
    topic: str,
    style: str,
    depth: int,
    sections: int,
    input_section_title: str,
    input_subsection_title: str = "",
    peer_companies: str = "",
    s3_template_prefix: str = "system/",
) -> str:
    """Start a new report generation job via API."""
    api_url = get_api_url()
    token = get_token()

    try:
        try:
            parsed_peer_companies = json.loads(peer_companies) if peer_companies else []
        except (json.JSONDecodeError, TypeError):
            parsed_peer_companies = []

        response = requests.post(
            f"{api_url}/reports",
            json={
                "topic": topic,
                "style": style,
                "depth": depth,
                "sections": sections,
                "input_section_title": input_section_title,
                "input_subsection_title": input_subsection_title,
                "peer_companies": parsed_peer_companies,
                "s3_template_prefix": s3_template_prefix
            },
            headers={
                "Authorization": f"{token}",
                "Content-Type": "application/json",
                "Accept": "application/json"
            },
            timeout=60,
        )
        response.raise_for_status()
        return response.json().get("job_id")
    except requests.exceptions.RequestException as e:
        st.error(f"Failed to start report generation: {str(e)}")
        return None

def replace_section_by_id(sections, section_id, new_section):
    """Recursively replace a section by id in a list of sections."""
    updated = []
    for section in sections:
        if (
            getattr(section, "id", None) == f"{section_id}_old"
            or (isinstance(section, dict)
            and section.get("id") == f"{section_id}_old")
        ):
            continue  # Skip the old section
        # If this is the section to replace
        if (
            getattr(section, "id", None) == f"{section_id}_new"
            or (isinstance(section, dict)
            and section.get("id") == f"{section_id}_new")
        ):
            updated.append(new_section)
        else:
            # If this section has nested sections, recurse
            if hasattr(section, "sections") and section.sections:
                # For Pydantic models
                section.sections = replace_section_by_id(section.sections, section_id, new_section)
                updated.append(section)
            elif isinstance(section, dict) and section.get("sections"):
                section["sections"] = replace_section_by_id(section["sections"], section_id, new_section)
                updated.append(section)
            else:
                updated.append(section)
    return updated

def remove_regenerated_section_by_id(sections, section_id):
    """Recursively remove the regenerated section and restore the original section by removing '_old' and '(Original)' suffixes."""
    updated = []
    for section in sections:
        # If this is the regenerated section (has "_new" suffix), skip it
        if (getattr(section, "id", None) == f"{section_id}_new" 
            or (isinstance(section, dict) and section.get("id") == f"{section_id}_new")):
            continue  # Skip the regenerated section
        
        # If this is the original section (has "_old" suffix), restore it
        elif (getattr(section, "id", None) == f"{section_id}_old" 
              or (isinstance(section, dict) and section.get("id") == f"{section_id}_old")):
            # Restore the original section by removing suffixes
            if isinstance(section, dict):
                section["id"] = section_id  # Remove "_old" suffix
                section["name"] = section["name"].replace(" (Original)", "")  # Remove "(Original)" suffix
            else:
                section.id = section_id
                section.name = section.name.replace(" (Original)", "")
            updated.append(section)
        else:
            # If this section has nested sections, recurse
            if hasattr(section, "sections") and section.sections:
                # For Pydantic models
                section.sections = remove_regenerated_section_by_id(section.sections, section_id)
                updated.append(section)
            elif isinstance(section, dict) and section.get("sections"):
                section["sections"] = remove_regenerated_section_by_id(section["sections"], section_id)
                updated.append(section)
            else:
                updated.append(section)
    return updated

def append_regenerated_section_by_id(sections, section_id, new_section):
    """Recursively append a section by id in a list of sections."""
    updated = []
    for section in sections:
        # If this is the section to replace
        if getattr(section, "id", None) == section_id or (isinstance(section, dict) and section.get("id") == section_id):
            section["id"] = f"{section['id']}_old"
            section["name"] = f"{section['name']} (Original)"
            updated.append(section)
            new_section["id"] = f"{new_section['id']}_new"
            new_section["name"] = f"{new_section['name']} (Regenerated)"
            updated.append(new_section)
        else:
            # If this section has nested sections, recurse
            if hasattr(section, "sections") and section.sections:
                # For Pydantic models
                section.sections = append_regenerated_section_by_id(section.sections, section_id, new_section)
                updated.append(section)
            elif isinstance(section, dict) and section.get("sections"):
                section["sections"] = append_regenerated_section_by_id(section["sections"], section_id, new_section)
                updated.append(section)
            else:
                updated.append(section)
    return updated

def get_report_status(job_id: str) -> Dict[str, Any]:
    """Get the status of a report generation job."""
    api_url = get_api_url()
    token = get_token()

    try:
        logger.info(f"Fetching status for job {job_id} from {api_url}/reports/{job_id}")
        response = requests.get(
            f"{api_url}/reports/{job_id}",
            headers={"Authorization": f"{token}"},
            timeout=60,
        )
        response.raise_for_status()
        result = response.json()

        logger.info(
            f"Received status response for job {job_id}: status={result.get('status')}"
        )

        # --- FIX: If awaiting_final_approval, always set final_report_data in session state ---
        if result.get("status") in (
            "awaiting_final_approval",
            "interrupt_final_report_approval",
        ):
            final_report = result.get("final_report")
            if final_report:
                st.session_state.final_report_data = final_report
                st.session_state.awaiting_final_approval = True
                logger.info(f"Set final_report_data in session state for job {job_id}")
        # --- END FIX ---

        # Debug image paths in sections
        sections = result.get("sections", [])
        if sections:
            logger.info(f"API returned {len(sections)} sections")
            for i, section in enumerate(sections):
                # Handle both dict and ReportSection object formats
                image_field = None
                if isinstance(section, dict):
                    image_field = section.get("image")
                else:
                    image_field = getattr(section, "image", None)

                if image_field:
                    logger.info(
                        f"API returned image path for section {i}: {image_field}"
                    )

        return result
    except requests.exceptions.RequestException as e:
        logger.error(f"Failed to get report status for job {job_id}: {str(e)}")
        st.error(f"Failed to get report status: {str(e)}")
        return None


def render_highcharts(chart_data: dict, chart_id: str = "highchart") -> None:
    """Render Highcharts chart(s) using Streamlit HTML component, side by side in 2 columns if multiple."""
    if not chart_data:
        return
    import json

    highcharts_js = "https://code.highcharts.com/highcharts.js"
    # If chart_data is a list, render each chart in 2 columns
    if isinstance(chart_data, list):
        cols = None
        if len(chart_data) > 1:
            cols = st.columns(2)
        for idx, chart in enumerate(chart_data):
            chart_json = json.dumps(chart)
            html = f"""
            <div id="{chart_id}_{idx}" style="width:100%;height:400px;"></div>
            <script src="{highcharts_js}"></script>
            <script>
            document.addEventListener("DOMContentLoaded", function() {{
                Highcharts.chart('{chart_id}_{idx}', {chart_json});
            }});
            </script>
            """
            if chart.get("chart", {}).get("type", "") == "organization":
                html = f"""
                <script src="{highcharts_js}"></script>
                <script src="https://code.highcharts.com/modules/sankey.js"></script>
                <script src="https://code.highcharts.com/modules/organization.js"></script>
                <script src="https://code.highcharts.com/modules/exporting.js"></script>
                <script src="https://code.highcharts.com/modules/accessibility.js"></script>
                <script src="https://code.highcharts.com/themes/adaptive.js"></script>
                <div id="{chart_id}_{idx}" style="width:100%;min-height:100%"></div>
                <script src="{highcharts_js}"></script>
                <script>
                document.addEventListener("DOMContentLoaded", function() {{
                    Highcharts.chart('{chart_id}_{idx}', {chart_json});
                }});
                </script>
                """
                components.html(html, height=1000)
                continue
            elif cols is None:
                cols = st.columns(2)
            with cols[idx % 2]:
                components.html(html, height=420)
    elif isinstance(chart_data, dict):
        chart_json = json.dumps(chart_data)
        html = f"""
        <div id="{chart_id}" style="width:100%;height:400px;"></div>
        <script src="{highcharts_js}"></script>
        <script>
        document.addEventListener("DOMContentLoaded", function() {{
            Highcharts.chart('{chart_id}', {chart_json});
        }});
        </script>
        """
        if chart_data.get("chart", {}).get("type", "") == "organization":
            html = f"""
            <script src="{highcharts_js}"></script>
            <script src="https://code.highcharts.com/modules/sankey.js"></script>
            <script src="https://code.highcharts.com/modules/organization.js"></script>
            <script src="https://code.highcharts.com/modules/exporting.js"></script>
            <script src="https://code.highcharts.com/modules/accessibility.js"></script>
            <script src="https://code.highcharts.com/themes/adaptive.js"></script>
            <div id="{chart_id}" style="width:100%;min-height:100%"></div>
            <script src="{highcharts_js}"></script>
            <script>
            document.addEventListener("DOMContentLoaded", function() {{
                Highcharts.chart('{chart_id}', {chart_json});
            }});
            </script>
            """
            components.html(html, height=1000)
            return
        components.html(html, height=420)


def render_report(sections: List[Dict[str, Any]]) -> None:
    """Render the generated report sections."""
    if not sections:
        st.warning("No report sections available.")
        return

    for idx, section in enumerate(sections):
        # Handle both dict and ReportSection object formats
        if isinstance(section, dict):
            section_title = section.get(
                "name", section.get("title", "Untitled Section")
            )
            section_content = section.get("content", section.get("description", ""))
            section_sources = section.get("sources", [])
            section_image = section.get("image", None)
            chart_data = (
                section.get("chart_data", None)
                if isinstance(section, dict)
                else getattr(section, "chart_data", None)
            )
        else:
            section_title = getattr(
                section, "name", getattr(section, "title", "Untitled Section")
            )
            section_content = getattr(
                section, "content", getattr(section, "description", "")
            )
            section_sources = getattr(section, "sources", [])
            section_image = getattr(section, "image", None)
            chart_data = getattr(section, "chart_data", None)

        if section_content:
            section_content = str(section_content).replace("$", "\\$")
        else:
            section_content = ""

        logger.info(f"Rendering section_image: {section_image}")
        logger.info(f"FROM Rendering section: {section}")

        st.header(section_title, divider="red")
        st.markdown(section_content, unsafe_allow_html=True)
        # --- Render Highcharts if chart_data is present and valid ---
        if chart_data:
            try:
                # If chart_data is a list, render all charts
                render_highcharts(chart_data, chart_id=f"highchart_{idx}")
            except Exception as e:
                st.warning(f"Failed to render chart: {e}")
        # --- end chart rendering ---
        # Handle image display
        if section_image:
            # Normalize the image path
            section_image = normalize_image_path(section_image)
            st.write(f"Image path: {section_image}")

            # Try different path resolution approaches
            image_paths_to_try = [
                section_image,  # As-is
                # os.path.join(app_dir, section_image),  # Relative to app directory
                os.path.join(
                    os.getcwd(), section_image
                ),  # Relative to working directory
                os.path.join(
                    "src/synthia/app", section_image
                ),  # Another common location
                os.path.join(
                    chart_images_dir, section_image
                ),  # Direct from chart_images dir
                os.path.join(
                    chart_images_dir, os.path.basename(section_image)
                ),  # Just the filename in chart_images
            ]

            image_displayed = False
            for path in image_paths_to_try:
                try:
                    logger.info(
                        f"Trying image path: {path}, exists: {os.path.exists(path)}"
                    )
                    if os.path.exists(path):
                        st.image(path, caption=section_title)
                        st.success(f"Image displayed from: {path}")
                        image_displayed = True
                        break
                except Exception as e:
                    logger.warning(
                        f"Failed to display image from path {path}: {str(e)}"
                    )

            if not image_displayed:
                # Last attempt - look for any matching filename in chart_images directory
                try:
                    filename = os.path.basename(section_image)
                    matching_files = [
                        f
                        for f in os.listdir(chart_images_dir)
                        if filename.lower() in f.lower()
                    ]

                    if matching_files:
                        best_match = matching_files[0]
                        image_path = os.path.join(chart_images_dir, best_match)
                        st.image(image_path, caption=section_title)
                        st.success(f"Image displayed (fuzzy match) from: {image_path}")
                        image_displayed = True
                except Exception as e:
                    logger.warning(f"Fuzzy matching failed: {str(e)}")

            if not image_displayed:
                logger.error(
                    f"Could not display image. Tried paths: {image_paths_to_try}"
                )

        # Add proper sources rendering
        if section_sources:
            if isinstance(section_sources, list):
                st.subheader("Sources")
                for source in section_sources:
                    st.markdown(f"{source}", unsafe_allow_html=True)
            else:
                st.subheader("Source")
                st.write(section_sources)


def render_report_sections_tree(
    sections: List[Dict[str, Any]], expanded_by_default: bool = True
) -> None:
    """Render the report sections as a hierarchical tree structure where each section is an expandable node."""
    if not sections:
        st.warning("No report sections available.")
        return

    st.write("### 📊 Report Structure")

    def render_section_tree_node(section, section_number=""):
        """Render a single section as an expander node (recursively renders subsections)."""

        # Handle both dict and ReportSection object formats
        if isinstance(section, dict):
            section_id = section.get("id", "")
            section_name = section.get("name", "Untitled Section")
            section_content = section.get("content", "")
            section_sources = section.get("sources", [])
            chart_data = section.get("chart_data", None)
            subsections = section.get("sections", [])
        else:
            section_id = getattr(section, "id", "")
            section_name = getattr(section, "name", "Untitled Section")
            section_content = getattr(section, "content", "")
            section_sources = getattr(section, "sources", [])
            chart_data = getattr(section, "chart_data", None)
            subsections = getattr(section, "sections", [])

        # Choose icon
        if subsections and len(subsections) > 0:
            icon = "📁"
        elif chart_data:
            icon = "📈"
        elif section_content and len(str(section_content).strip()) > 0:
            icon = "📄"
        else:
            icon = "📝"

        # Build display name
        section_display_name = (
            f"{section_number} {section_name}" if section_number else section_name
        )
        expander_label = f"{icon} **{section_display_name}**"

        try:
            with st.expander(expander_label, expanded=expanded_by_default):
                # Content preview
                if section_content:
                    st.markdown(f"{section_content}", unsafe_allow_html=True)

                # Chart rendering (if present)
                if chart_data:
                    try:
                        chart_id = f"highchart_{hashlib.md5(section_display_name.encode()).hexdigest()[:8]}"
                        render_highcharts(chart_data, chart_id=chart_id)
                    except Exception as e:
                        logger.warning(f"Failed to render chart for {section_display_name}: {e}")
                        st.markdown("📈 *Contains chart data (render failed)*")

                # Sources
                if section_sources:
                    if isinstance(section_sources, list):
                        st.markdown(f"🔗 *{len(section_sources)} source(s)*")
                        for src in section_sources:
                            st.markdown(f"- {src}", unsafe_allow_html=True)
                    else:
                        st.markdown("🔗 *1 source*")
                        st.markdown(f"- {section_sources}", unsafe_allow_html=True)

                # Render subsections recursively
                if subsections and len(subsections) > 0:
                    for i, sub in enumerate(subsections):
                        sub_number = f"{section_number}.{i+1}" if section_number else f"{i+1}"
                        render_section_tree_node(sub, sub_number)
        except Exception as e:
            logger.error(f"Error rendering section node {section_display_name}: {e}")
            st.error(f"Error rendering section {section_display_name}: {e}")

    try:
        for i, sec in enumerate(sections):
            num = f"{i+1}"
            render_section_tree_node(sec, num)
            if i < len(sections) - 1:
                st.markdown("---")
    except Exception as e:
        logger.error(f"Error rendering report sections tree: {e}")
        st.error(f"Error rendering report sections tree: {e}")

        with st.expander("Debug Report Structure", expanded=True):
            st.write(f"Sections type: {type(sections)}")
            st.write(f"Sections length: {len(sections) if sections else 0}")
            if sections and len(sections) > 0:
                st.write(f"First section type: {type(sections[0])}")
                try:
                    if hasattr(sections[0], "__dict__"):
                        st.json(sections[0].__dict__)
                    else:
                        st.json(sections[0])
                except:
                    st.write(str(sections[0]))

def format_elapsed_time(start_iso, end_iso=None):
    """Format elapsed time between two ISO timestamps."""
    try:
        if not start_iso:
            return "N/A"
        import datetime

        start = datetime.datetime.fromisoformat(start_iso)
        end = (
            datetime.datetime.fromisoformat(end_iso)
            if end_iso
            else datetime.datetime.now()
        )
        elapsed = end - start
        minutes = int(elapsed.total_seconds() // 60)
        seconds = int(elapsed.total_seconds() % 60)
        return f"{minutes}m {seconds}s"
    except Exception as e:
        logger.warning(f"Error formatting elapsed time: {e}")
        return "N/A"


def display_progress_metrics(status_data: Dict[str, Any]) -> None:
    """Display progress metrics and visualizations, including elapsed time for each step."""
    # Use progress field from ReportStatus
    progress = status_data.get("progress", 0.0)
    if progress is not None:
        progress = float(progress) / 100.0 if progress > 1.0 else float(progress)
    else:
        progress = 0.0

    status = status_data.get("status", "unknown")
    completed_at = status_data.get("completed_at", None)

    # Calculate current section info from sections array
    sections = status_data.get("sections", [])
    outline = status_data.get("outline", [])
    current_section_idx = len([s for s in sections if s]) if sections else 0
    total_sections = len(outline) if outline else 0

    # Elapsed time tracking - these fields come from ReportStatus
    started_at = status_data.get("started_at")
    completed_at_iso = completed_at

    st.progress(progress)
    if total_sections > 0:
        st.info(f"Progress: {current_section_idx}/{total_sections} sections completed")

    if status and status.lower() == "completed":
        try:
            completed_time = completed_at
            if completed_at_iso:
                completed_time = completed_at_iso
                completed_time_fmt = ""
                try:
                    import datetime

                    completed_time_fmt = datetime.datetime.fromisoformat(
                        completed_at_iso
                    ).strftime("%H:%M:%S")
                except Exception:
                    completed_time_fmt = completed_at_iso
                st.metric(
                    "Status",
                    f"{status.capitalize()} @ {completed_time_fmt}",
                    delta=f"{int(progress * 100)}%",
                )
            else:
                st.metric(
                    "Status", f"{status.capitalize()}", delta=f"{int(progress * 100)}%"
                )
        except Exception:
            st.metric(
                "Status", f"{status.capitalize()}", delta=f"{int(progress * 100)}%"
            )
    else:
        # For section_generated status, make it more descriptive
        if status == "section_generated":
            st.metric(
                "Status",
                f"Generating section {current_section_idx + 1}",
                delta=f"{int(progress * 100)}%",
            )
        else:
            st.metric(
                "Status",
                status.capitalize() if status else "Unknown",
                delta=f"{int(progress * 100)}%",
            )

    # If we have section data, show additional metrics
    if sections:
        # Count total words
        total_words = 0
        section_word_counts = {}

        for section in sections:
            # Handle both dict and ReportSection object formats
            section_name = None
            section_content = None

            if isinstance(section, dict):
                section_name = section.get("name", section.get("title", "Untitled"))
                section_content = section.get("content", section.get("description", ""))
            else:
                section_name = getattr(
                    section, "name", getattr(section, "title", "Untitled")
                )
                section_content = getattr(
                    section, "content", getattr(section, "description", "")
                )

            if "Sources & References" in section_name:
                continue

            if section_content:
                section_words = len(str(section_content).split())
                total_words += section_words
                section_word_counts[section_name] = section_words

        # Display metrics
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Total Words", total_words)
        with col2:
            st.metric(
                "Sections", len(sections) - 1 if sections else 0
            )  # Exclude "Sources & References"

        # Create a DataFrame for visualization
        if section_word_counts:
            df = pd.DataFrame(
                {
                    "Section": list(section_word_counts.keys()),
                    "Word Count": list(section_word_counts.values()),
                }
            )

            # Create bar chart
            # fig = px.bar(
            #     df,
            #     x="Section",
            #     y="Word Count",
            #     title="Word Count by Section",
            #     color="Word Count",
            #     color_continuous_scale="viridis",
            # )
            # st.plotly_chart(fig, use_container_width=True)


def approve_reject_outline(
    job_id: str,
    approved: bool,
    user_sections: Dict = None,
    revised_sections: Optional[int] = None,
    revised_depth: Optional[int] = None,
) -> Dict[str, Any]:
    """Approve or reject a report outline via API."""
    api_url = get_api_url()
    token = get_token()

    payload = {"approved": approved}
    if user_sections is not None:
        payload["user_sections"] = user_sections

    if revised_sections is not None:
        payload["revised_sections"] = revised_sections

    if revised_depth is not None:
        payload["revised_depth"] = revised_depth

    try:
        response = requests.post(
            f"{api_url}/reports/{job_id}/approve-outline",
            json=payload,
            headers={"Authorization": f"{token}"},
            timeout=60,
        )
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        st.error(f"Failed to approve/reject outline: {str(e)}")
        return None


def render_outline(outline: List[Any]) -> None:
    """Render the generated report outline as a hierarchical tree structure."""
    if not outline:
        logger.warning("No outline available to render")
        st.warning("No outline available.")
        return

    # Log the structure of the outline for debugging
    logger.info(
        f"Rendering outline - type: {type(outline)}, length: {len(outline) if outline else 0}"
    )
    if outline and len(outline) > 0:
        logger.info(f"First outline item type: {type(outline[0])}")

    st.write("### 📋 Report Outline")

    def render_section_tree(section, level=0, section_number=""):
        """Recursively render a section and its subsections as interactive expandable elements."""

        # Handle TemplateSection objects
        if hasattr(section, "section_title"):
            title = section.section_title or "Untitled Section"
            description = section.description or ""
            tools = section.tools or []
            subsections = section.sections or []
        elif isinstance(section, dict):
            title = section.get(
                "section_title",
                section.get("name", section.get("title", "Untitled Section")),
            )
            description = section.get("description", "")
            tools = section.get("tools", [])
            subsections = section.get("sections", [])
        else:
            title = str(
                getattr(
                    section,
                    "section_title",
                    getattr(section, "name", "Untitled Section"),
                )
            )
            description = str(getattr(section, "description", ""))
            tools = getattr(section, "tools", [])
            subsections = getattr(section, "sections", [])

        # Choose appropriate icon based on whether it's a leaf node or not
        if subsections and len(subsections) > 0:
            icon = "📄"  # Non-leaf node (has children)
        else:
            icon = "📝"  # Leaf node (no children)

        # Create expandable section
        if subsections and len(subsections) > 0:
            # For sections with children, use expander
            expander_label = f"{icon} **{section_number} {title}**"
            with st.expander(expander_label, expanded=level == 0):
                # Show description if available
                if description:
                    st.markdown(f"💭 *{description}*")

                # Show tools if available
                if tools:
                    if isinstance(tools, list):
                        tools_str = ", ".join(tools)
                    else:
                        tools_str = str(tools)
                    st.markdown(f"🔧 Tools: `{tools_str}`")

                # Render subsections
                for i, subsection in enumerate(subsections):
                    subsection_number = (
                        f"{section_number}.{i+1}" if section_number else f"{i+1}"
                    )
                    render_section_tree(subsection, level + 1, subsection_number)
        else:
            # For leaf nodes, display directly
            indent = "  " * level
            section_display = f"{indent}{icon} **{section_number} {title}**"
            st.markdown(section_display)

            # Show description if available
            if description:
                desc_indent = "  " * (level + 1)
                st.markdown(f"{desc_indent}💭 *{description}*")

            # Show tools if available
            if tools:
                tools_indent = "  " * (level + 1)
                if isinstance(tools, list):
                    tools_str = ", ".join(tools)
                else:
                    tools_str = str(tools)
                st.markdown(f"{tools_indent}🔧 Tools: `{tools_str}`")

    try:
        # Render each top-level section
        for i, section in enumerate(outline):
            section_number = f"{i+1}"
            render_section_tree(section, 0, section_number)

            # Add some spacing between top-level sections
            if i < len(outline) - 1:
                st.markdown("---")

    except Exception as e:
        logger.error(f"Error rendering outline tree: {e}")
        st.error(f"Error rendering outline: {e}")

        # Fallback to debug view
        with st.expander("Debug Outline Structure", expanded=True):
            st.write(f"Outline type: {type(outline)}")
            st.write(f"Outline length: {len(outline) if outline else 0}")
            if outline and len(outline) > 0:
                st.write(f"First item type: {type(outline[0])}")
                # Try to show the first item's structure
                try:
                    if hasattr(outline[0], "__dict__"):
                        st.json(outline[0].__dict__)
                    else:
                        st.json(outline[0])
                except:
                    st.write(str(outline[0]))


# Helper functions for outline approval workflow
def handle_approve_outline():
    """Handle the approval of an outline."""
    job_id = st.session_state.job_id
    logger.info(f"Starting outline approval process for job {job_id}")

    if not job_id:
        logger.error("No job ID available for approval")
        st.error("No job ID available for approval")
        return False

    try:
        logger.info(
            f"Sending approval request for job {job_id} with user_sections: {st.session_state.user_sections}"
        )
        with st.spinner("Processing approval..."):
            response = approve_reject_outline(
                job_id, True, st.session_state.user_sections
            )
            if response:
                logger.info(f"Outline approval successful for job {job_id}: {response}")
                st.success("Outline approved! Continuing with report generation.")

                # Update session state in correct order
                st.session_state.outline_approved = True
                st.session_state.awaiting_approval = False
                st.session_state.outline_data = None
                st.session_state.show_revision_options = False
                st.session_state.user_sections = (
                    []
                )  # Clear user sections after approval
                st.session_state.monitoring = True

                logger.info("Session state updated successfully after outline approval")
                return True
            else:
                logger.error(
                    f"Outline approval failed for job {job_id} - no response from API"
                )
                st.error("Failed to approve outline. Please try again.")
                return False
    except Exception as e:
        logger.error(
            f"Exception during outline approval for job {job_id}: {str(e)}",
            exc_info=True,
        )
        st.error(f"Error during outline approval: {str(e)}")
        return False


def handle_reject_outline(revised_sections=None, revised_depth=None):
    """Handle the rejection of an outline."""
    job_id = st.session_state.job_id
    logger.info(
        f"Handling outline rejection for job {job_id} with revised_sections={revised_sections}, revised_depth={revised_depth}"
    )

    with st.spinner("Processing revision..."):
        response = approve_reject_outline(
            job_id, False, None, revised_sections, revised_depth
        )
        if response:
            st.info("Outline rejected. Generating new outline with revised parameters.")
            logger.info(f"Outline rejected for job {job_id}: {response}")

            # Reset outline approval session state
            st.session_state.awaiting_approval = False
            st.session_state.outline_data = None
            st.session_state.show_revision_options = False
            # Resume monitoring
            st.session_state.monitoring = True


def toggle_revision_options():
    """Toggle the display of revision options."""
    st.session_state.show_revision_options = not st.session_state.show_revision_options


def get_login_attempts_remaining() -> int:
    """Get the number of remaining login attempts."""
    max_attempts = 5
    return max_attempts - st.session_state.login_attempts


def toggle_password_visibility():
    """Toggle password visibility."""
    st.session_state.show_password = not st.session_state.show_password


def check_password(username: str, password: str) -> bool:
    """Check if the provided username and password are valid."""
    settings = get_settings()
    valid_username = settings.default_username
    valid_password_hash = settings.default_password_hash

    # Hash the provided password
    password_hash = hashlib.sha256(password.encode()).hexdigest()

    # Check if username and hashed password match
    return username == valid_username and password_hash == valid_password_hash


def login_form():
    """Display the login form."""
    st.markdown("## 🔐 Login")
    st.markdown("Please log in to access the Synthia Report Generator.")

    col1, col2 = st.columns([3, 1])
    with col1:
        username = st.text_input("Username", key="username_input")

        # Password field with show/hide toggle
        if st.session_state.show_password:
            password = st.text_input("Password", key="password_input")
        else:
            password = st.text_input("Password", type="password", key="password_input")

    with col2:
        st.markdown("<br>", unsafe_allow_html=True)  # Add space
        st.checkbox(
            "Show password", key="show_pwd", on_change=toggle_password_visibility
        )

    login_button = st.button("Log In", type="primary")

    if login_button:
        ## FIXME: REMOVE THIS HARDCODED USERNAME AND PASSWORD!!!
        if not username or not password:
            st.error("Please enter both username and password.")
            return
        if check_password(username, password) or get_token(username, password):
            st.session_state.username = username
            st.session_state.authenticated = True
            st.session_state.login_attempts = 0
            st.success("Login successful!")
            st.rerun()
        else:
            st.session_state.login_attempts += 1
            remaining_attempts = 5 - st.session_state.login_attempts
            if remaining_attempts > 0:
                st.error(
                    f"Invalid username or password. {remaining_attempts} attempts remaining."
                )
            else:
                st.error("Too many failed login attempts. Please try again later.")
                st.session_state.login_attempts = 0


def render_user_sections(outline: List[Dict[str, Any]]) -> None:
    """Render user-defined sections for the report."""
    st.subheader("User-Defined Sections")

    dropdown_options = []
    for i, section in enumerate(outline):
        dropdown_options.append(i + 1)

    selected_option = st.selectbox(
        "Select section to update",
        options=dropdown_options,
        index=0,
        key="section_view_select",
    )
    user_prompt = st.text_area("LLM Section Prompt", "")

    if (
        selected_option is not None
        and user_prompt is not None
        and user_prompt.strip() != ""
    ):
        # Check if the section already exists
        existing_section = next(
            (
                s
                for s in st.session_state.user_sections
                if s["selected_option"] == selected_option
            ),
            None,
        )
        if existing_section:
            # Update existing section
            existing_section["selected_content"] = user_prompt
        else:
            # Add new section
            st.session_state.user_sections.append(
                {
                    "selected_option": selected_option,
                    "selected_content": user_prompt,
                }
            )


def ensure_chart_directory():
    """Ensure the chart directory exists for storing generated charts."""
    chart_dir = os.path.join(os.path.dirname(__file__), "chart_images")
    if not os.path.exists(chart_dir):
        os.makedirs(chart_dir)
        st.success(f"Created chart directory at {chart_dir}")
    return chart_dir


def normalize_image_path(image_path):
    """
    Normalize image path to improve image finding.
    1. If it's a full path to chart_images, leave it as is
    2. If it seems to be just a filename, make it relative to chart_images
    3. If it contains common image keywords like 'chart', 'graph', or company names, try to find matching files
    """
    if not image_path:
        return None

    # If already has chart_images in the path, leave it
    if "chart_images" in image_path:
        return image_path

    # If it seems to be a full URL or absolute path outside of our app, leave it
    if image_path.startswith(("http://", "https://", "/")):
        return image_path

    # If it's just a filename, make it relative to chart_images
    if "/" not in image_path and "\\" not in image_path:
        return os.path.join(chart_images_dir, image_path)

    # Default - return as is
    return image_path


def approve_reject_final_report(
    job_id: str, approved: bool, feedback: Optional[str] = None
) -> Dict[str, Any]:
    """Approve or reject a final report via API."""
    api_url = get_api_url()
    token = get_token()
    payload = {"approved": approved}
    if feedback is not None:
        payload["feedback"] = feedback
    try:
        response = requests.post(
            f"{api_url}/reports/{job_id}/approve-final-report",
            json=payload,
            headers={"Authorization": f"{token}"},
            timeout=60,
        )
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        st.error(f"Failed to approve/reject final report: {str(e)}")
        return None


def handle_approve_final_report():
    """Handle the approval of a final report."""
    job_id = st.session_state.job_id
    logger.info(f"Handling final report approval for job {job_id}")
    with st.spinner("Processing final approval..."):
        response = approve_reject_final_report(job_id, True)
        if response:
            st.success("Final report approved! Report generation completed.")
            logger.info(f"Final report approved for job {job_id}: {response}")
            st.session_state.awaiting_final_approval = False
            st.session_state.final_report_data = None
            st.session_state.monitoring = True


def handle_reject_final_report(feedback=None):
    """Handle the rejection of a final report."""
    job_id = st.session_state.job_id
    logger.info(
        f"Handling final report rejection for job {job_id} with feedback={feedback}"
    )
    with st.spinner("Processing rejection and regenerating..."):
        response = approve_reject_final_report(job_id, False, feedback)
        if response:
            st.info("Final report rejected. Regenerating sections with your feedback.")
            logger.info(f"Final report rejected for job {job_id}: {response}")
            st.session_state.awaiting_final_approval = False
            st.session_state.final_report_data = None
            st.session_state.monitoring = True


def get_leaf_sections(sections):
    leaf_nodes = {}
    for section in sections:
        # If 'sections' is empty, None, or not a list, it's a leaf
        if not section.get("sections"):
            leaf_nodes[section["name"]] = section["id"]
        else:
            # Recursively collect from subsections
            leaf_nodes.update(get_leaf_sections(section["sections"]))
    return leaf_nodes


def start_section_regeneration(
    job_id: str,
    prompt_id: str,
    prompt: str,
    section_id: str,
    section_name: str,
    previous_prompt_id: str = None,
) -> str:
    """
    Simulate section regeneration API call.
    Takes inspiration from start_report_generation.
    """
    api_url = get_api_url()
    token = get_token()
    
    try:
        response = requests.post(
            f"{api_url}/reports/section-edit",
            json={
                "job_id": job_id,
                "prompt_id": prompt_id,
                "prompt": prompt,
                "section_id": section_id,
                "section_name": section_name,
                "previous_prompt_id": previous_prompt_id
            },
            headers={
                "Authorization": f"{token}",
                "Content-Type": "application/json",
                "Accept": "application/json"
            },
            timeout=60,
        )
        response.raise_for_status()
        return response.json().get("status")
    except requests.exceptions.RequestException as e:
        st.error(f"Failed to start section edit generation: {str(e)}")
        return None
    except Exception as e:
        st.error(f"Failed to start section edit generation: {str(e)}")
        return None


def get_section_regenration_status(
    job_id: str,
    prompt_id: str
) -> dict:
    """
    Simulate polling section regeneration status API.
    """
    api_url = get_api_url()
    token = get_token()

    try:
        logger.info(f"Fetching status for section edit job {job_id} from {api_url}/reports/{job_id}/section-edit/{prompt_id}/poll")
        response = requests.get(
            f"{api_url}/reports/{job_id}/section-edit/{prompt_id}/poll",
            headers={"Authorization": f"{token}"},
            timeout=60,
        )
        response.raise_for_status()
        result = response.json()

        logger.info(
            f"Received status response for section edit job {job_id}: status={result.get('status')}"
        )
        return result
    except requests.exceptions.RequestException as e:
        logger.error(f"Failed to get section edit status for job {job_id}: {str(e)}")
        st.error(f"Failed to get section edit status: {str(e)}")
        return None


def accept_reject_retry_final_section_edit(
    job_id: str, 
    prompt_id: str,
    action: str
) -> Dict[str, Any]:
    """Accept or Reject or Retry a section edit regenration via API."""
    api_url = get_api_url()
    token = get_token()

    payload = {
        "job_id": job_id,
        "prompt_id": prompt_id,
        "action": action  # "approve", "reject", or "retry"
    }

    try:
        response = requests.post(
            f"{api_url}/reports/section-edit/approval",
            json=payload,
            headers={"Authorization": f"{token}"},
            timeout=60,
        )
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        st.error(f"Failed to approve/reject/retry section edit regeneration: {str(e)}")
        return None


def handle_accept_reject_retry_section_edit(action: str):
    """Handle accept/reject/retry action for section edit."""
    job_id = st.session_state.job_id
    prompt_id = st.session_state.prompt_id
    logger.info(
        f"Handling section edit action for job {job_id} with prompt_id={prompt_id} and action={action}"
    )
    with st.spinner(f"Processing section edit {action} action..."):
        response = accept_reject_retry_final_section_edit(job_id, prompt_id, action)
        if response:
            st.info(f"Section edit action processed successfully -- {action}.")
            logger.info(f"Section edit action processed for job {job_id}: {response}")
            # st.session_state.regen_job_monitoring = True

def reset_section_edit_state():
    """Reset section edit related session state variables."""
    st.session_state.regen_edited_section = None
    st.session_state.prompt_id = None
    st.session_state.prompt_history = []
    st.session_state.regen_section_id = None
    st.session_state.regen_section_name = None
    st.session_state.regen_job_monitoring = False
    st.session_state.regen_job_id = None
    st.session_state.custom_prompt = ""
    st.session_state.custom_prompt_input = ""
    st.session_state.prompt_id = ""
    st.session_state.previous_prompt_id = None


def main():
    """Main Streamlit application."""
    logger.info("Starting Synthia main application")

    # Check authentication
    if not st.session_state.authenticated:
        logger.info("User not authenticated, showing login form")
        login_form()
        return

    logger.info("User authenticated, showing main application")

    # Sidebar for report configuration

    import requests

    if "uploaded_documents" not in st.session_state:
        st.session_state.uploaded_documents = []

    with st.sidebar:
        st.header("Report Configuration")

        # Add logout button at the top of sidebar
        if st.button("Logout"):
            st.session_state.authenticated = False
            st.rerun()

        # Client selection dropdown
        st.subheader("Client Selection")
        client_options = ["system", "intesa", "shell"]
        st.session_state.selected_client = st.selectbox(
            "Select Client",
            options=client_options,
            index=client_options.index(st.session_state.selected_client),
            help="Select the client to load templates from S3"
        )
        
        # Get the S3 prefix for the selected client
        s3_template_prefix = get_s3_template_prefix(st.session_state.selected_client)

        topic = st.text_input(
            "What company would like to create a report for?", """{name:"Amazon.com, Inc.", keyinstn:"3001792"}"""
        )

        peers = [
            PeerCompany(name="Alphabet Inc.", keyInstn="4633618"),
            PeerCompany(name="Microsoft Corporation", keyInstn="4004214")
        ]
        peer_companies_json = json.dumps([company.dict() for company in peers], indent=2)

        peer_companies = st.text_area("Peer Companies", peer_companies_json)

        style = st.selectbox(
            "Report Template To Use",
            options=["corporates_template", "bank_template"],
            index=0,
        )

        disable_custom = style == ""  # True if no style is selected

        # Load all leaf or subsection nodes as logical sections #
        # We don't have any concept of subsection in report #
        # We have only topic (style) and section in a report #

        if style:
            sections_objects = asyncio.run(get_sections(style, s3_template_prefix)) if style else []
            logical_section = [section.section_title for section in sections_objects]
            logical_subsections = []
            from src.synthia.utils.template_util import get_subsections
            for section_title in logical_section:
                subsections = asyncio.run(get_subsections(style, section_title, s3_template_prefix))
                logical_subsections.extend(
                    [subsection.section_title for subsection in subsections]
                )
            logical_sections = logical_subsections
            logical_sections_with_empty = [""] + logical_sections

            # User input (logical section)
            input_section_title = st.selectbox(
                "Select Logical Section",
                options=logical_sections_with_empty,
                index=0,
                key="logical_section_select",
                disabled=disable_custom,
            )

        # [OLD CODE] Loading section and its related subsection #

        # Load logical sections (top-level sections)
        # sections_objects = get_sections(style) if style else []
        # logical_sections = [section.section_title for section in sections_objects]
        # logical_sections_with_empty = [""] + logical_sections
        #
        # input_section_title = st.selectbox(
        #     "Select Logical Section",
        #     options=logical_sections_with_empty,
        #     index=0,
        #     key="logical_section_select",
        #     disabled=disable_custom,
        # )

        # Load subsections based on selected logical section
        # input_subsection_title = ""
        # if input_section_title and style:
        #     from src.synthia.utils.template_util import get_subsections
        #
        #     subsections = get_subsections(style, input_section_title)
        #     if subsections:
        #         subsection_titles = [
        #             subsection.section_title for subsection in subsections
        #         ]
        #         subsection_titles_with_empty = [""] + subsection_titles
        #
        #         input_subsection_title = st.selectbox(
        #             "Select Subsection (Optional)",
        #             options=subsection_titles_with_empty,
        #             index=0,
        #             key="subsection_select",
        #             help="Choose a specific subsection or leave empty to generate all subsections",
        #         )

        # --- Upload Documents Section ---
        st.header("Upload Documents")
        if "file_uploader_key" not in st.session_state:
            st.session_state.file_uploader_key = "file_uploader_default"

        uploaded_files = st.file_uploader(
            "Choose documents",
            type=["pdf"],
            accept_multiple_files=True,
            key=st.session_state.file_uploader_key,
        )
        section_titles_input = []
        if uploaded_files:
            for idx, uploaded_file in enumerate(uploaded_files):
                # Use selectbox for section title, default to "General"
                section_title = st.selectbox(
                    f"Section Title for Document {uploaded_file.name}",
                    options=["General"] + logical_sections,
                    index=0,
                    key=f"section_title_{idx}",
                )
                section_titles_input.append(
                    section_title if section_title.strip() else "General"
                )

            if st.button("Upload Selected Documents"):
                for idx, uploaded_file in enumerate(uploaded_files):
                    api_url = get_api_url() + "/upload-document"
                    with st.spinner(f"Uploading {uploaded_file.name}..."):
                        files = {
                            "file": (
                                uploaded_file.name,
                                uploaded_file,
                                uploaded_file.type,
                            )
                        }
                        data = {
                            "username": st.session_state.username.lower(),
                            "section_title": section_titles_input[idx].strip().lower(),
                        }
                        response = requests.post(api_url, files=files, data=data)
                        if response.ok and response.json().get("success"):
                            s3_uri = response.json()["s3_uri"]
                            st.session_state.uploaded_documents.append(
                                {
                                    "s3_uri": s3_uri,
                                    "section_title": section_titles_input[idx].strip(),
                                    "file_name": uploaded_file.name,
                                }
                            )
                            st.success(f"Uploaded {uploaded_file.name} to {s3_uri}")
                        else:
                            st.error(
                                f"Upload failed for {uploaded_file.name}: {response.json().get('error', 'Unknown error')}"
                            )
                with st.spinner("Processing documents..."):
                    response = requests.post(get_api_url() + "/synchronize-kb")
                    if response.ok and response.json().get("success"):
                        st.success("Documents processed successfully.")
                    else:
                        st.error(
                            f"Processing failed: {response.json().get('error', 'Unknown error')}"
                        )
                # Reset file uploader by changing its key
                st.session_state.file_uploader_key = str(uuid.uuid4())
                st.rerun()

        # --- Display mapping of uploaded documents and their associated sections ---
        if st.session_state.uploaded_documents:
            st.subheader("Uploaded Documents & Associated Sections")
            for doc in st.session_state.uploaded_documents:
                st.write(f"**{doc['file_name']}** → Section: `{doc['section_title']}`")

        depth = st.slider("Content Depth (1-5)", 1, 5, 3)
        sections = st.slider("Number of Sections", 1, 15, 5)
        start_button = st.button("Generate Report", type="primary")

        if st.session_state.job_id:
            if st.button("Reset"):
                # --- Reset all report-related session state ---
                st.session_state.job_id = None
                st.session_state.report_data = None
                st.session_state.monitoring = False
                st.session_state.awaiting_approval = False
                st.session_state.outline_data = None
                st.session_state.user_sections = []
                st.session_state.outline_approved = False
                st.session_state.outline_rejected = False
                st.session_state.show_rejection_options = False
                st.session_state.revision_submitted = False
                st.session_state.show_revision_options = False
                st.session_state.last_status_check = None
                st.session_state.awaiting_final_approval = False
                st.session_state.final_report_data = None
                # --- End reset ---
                st.rerun()

        if st.session_state.job_id and st.session_state.awaiting_approval:
            if (
                st.session_state.outline_data is not None
                and len(st.session_state.outline_data) > 0
            ):
                render_user_sections(st.session_state.outline_data)

    # Main area - handle report generation flow
    if start_button and not st.session_state.job_id:
        logger.info(
            f"Starting new report generation: topic={topic}, style={style}, depth={depth}, sections={sections}, "
            f"section={input_section_title}, client={st.session_state.selected_client}, s3_prefix={s3_template_prefix}"
        )
        with st.spinner("Starting report generation..."):
            job_id = start_report_generation(
                topic=topic,
                style=style,
                depth=depth,
                sections=sections,
                input_section_title=input_section_title,
                peer_companies=peer_companies,
                s3_template_prefix=s3_template_prefix
            )
            if job_id:
                logger.info(
                    f"Report generation started successfully with job ID: {job_id}"
                )
                st.session_state.job_id = job_id
                st.session_state.monitoring = True
                st.success(f"Report generation started! Job ID: {job_id}")
                st.rerun()
            else:
                logger.error("Failed to start report generation - no job ID returned")

    # If we have an active job, monitor progress
    if st.session_state.job_id and st.session_state.monitoring:
        logger.info(f"Monitoring job {st.session_state.job_id}")
        st.subheader(f"Report Generation Progress")
        st.code(f"Job ID: {st.session_state.job_id}")
        status_placeholder = st.empty()
        report_placeholder = st.empty()

        # Create expander for detailed job information
        with st.expander("Job Details"):
            st.code(f"Job ID: {st.session_state.job_id}")

            if st.button("Stop Monitoring"):
                st.session_state.monitoring = False
                st.rerun()

        # Monitor progress
        while st.session_state.monitoring:
            status_data = get_report_status(st.session_state.job_id)

            if status_data:
                current_status = status_data.get("status")
                awaiting_final = status_data.get("awaiting_final_approval", False)
                final_report = status_data.get("final_report", "")
                logger.info(
                    f"Job {st.session_state.job_id} status update: status={current_status}, awaiting_approval={status_data.get('awaiting_approval')}, awaiting_final_approval={awaiting_final}"
                )

                with status_placeholder.container():
                    display_progress_metrics(status_data)

                # Check if outline needs approval
                if current_status == "awaiting_approval" or status_data.get(
                    "awaiting_approval"
                ):
                    outline = status_data.get("outline")
                    if outline:
                        logger.info(
                            f"Job {st.session_state.job_id} needs outline approval, stopping monitoring"
                        )
                        st.session_state.outline_data = outline
                        st.session_state.awaiting_approval = True
                        st.session_state.monitoring = (
                            False  # Stop monitoring to show approval UI
                        )
                        st.rerun()

                # Continue monitoring during report creation phase
                elif (
                    current_status == "creating_report"
                    or current_status == "outline_approved"
                ):
                    # Keep polling during report creation
                    pass

                # Check if final report needs approval - remove deprecated statuses
                elif current_status == "awaiting_final_approval" or awaiting_final:
                    final_report = status_data.get("final_report")
                    if final_report:
                        st.session_state.final_report_data = final_report
                        st.session_state.awaiting_final_approval = True
                        st.session_state.monitoring = False
                        st.rerun()

                # Check if report is completed
                elif current_status == "completed":
                    sections = status_data.get("sections", [])
                    if sections:
                        st.session_state.report_data = sections
                        st.session_state.report_section = get_leaf_sections(sections)
                    st.session_state.monitoring = False
                    st.success("Report generation completed!")
                    st.rerun()

                # Show the partial report if there's any data
                elif status_data.get("sections"):
                    sections = status_data.get("sections", [])
                    with report_placeholder.container():
                        st.subheader(
                            f"Report Preview - {len(sections)} sections completed"
                        )
                        st.caption(
                            f"Status: {status_data.get('status')} - Current section: {status_data.get('current_section_idx', 0)}"
                        )
                        render_report(sections)

                # Check if there was an error
                elif status_data.get("status") == "failed":
                    st.error(f"Report generation failed: {status_data.get('error')}")
                    st.session_state.monitoring = False

            # Only wait if we're still monitoring
            if st.session_state.monitoring:
                time.sleep(5)  # polling interval

    # If monitoring is off but we have a job ID, just show status
    elif st.session_state.job_id and not st.session_state.monitoring:
        status_data = get_report_status(st.session_state.job_id)
        if status_data:
            st.subheader("Report Status")
            st.code(f"Job ID: {st.session_state.job_id}")
            display_progress_metrics(status_data)

    # Handle outline approval outside the monitoring loop
    if (
        st.session_state.job_id
        and st.session_state.awaiting_approval
        and st.session_state.outline_data
    ):
        logger.info(f"Showing outline approval UI for job {st.session_state.job_id}")
        with st.container():
            st.subheader("📋 Outline Approval (Step 1/2)")
            st.info("Please review the following outline and approve or reject it.")

            # Display the outline
            render_outline(st.session_state.outline_data)

            col1, col2 = st.columns(2)
            with col1:
                # Remove form wrapper to eliminate borders
                approve_clicked = st.button(
                    "✅ Approve Outline", type="primary", key="approve_outline_btn"
                )
                if approve_clicked:
                    logger.info("Approve outline button clicked")
                    success = handle_approve_outline()
                    if success:
                        logger.info("Outline approval successful, rerunning app")
                        st.rerun()
                    else:
                        logger.error("Outline approval failed")

            with col2:
                # Remove form wrapper to eliminate borders
                reject_clicked = st.button(
                    "❌ Reject & Start Over", key="reject_outline_btn"
                )
                if reject_clicked:
                    logger.info("Reject outline button clicked - resetting job")
                    # Reset to start over completely
                    st.session_state.job_id = None
                    st.session_state.report_data = None
                    st.session_state.monitoring = False
                    st.session_state.awaiting_approval = False
                    st.session_state.outline_data = None
                    st.session_state.user_sections = []
                    st.session_state.outline_approved = False
                    st.session_state.outline_rejected = False
                    st.session_state.show_rejection_options = False
                    st.session_state.revision_submitted = False
                    st.session_state.last_status_check = None
                    st.session_state.awaiting_final_approval = False
                    st.session_state.final_report_data = None
                    logger.info("Job reset completed")
                    st.info(
                        "Job reset. Please configure and start a new report generation."
                    )
                    st.rerun()

    # Final report approval step
    if st.session_state.job_id and st.session_state.awaiting_final_approval:
        logger.info(
            f"Rendering final approval UI. job_id: {st.session_state.job_id}, awaiting_final_approval: {st.session_state.awaiting_final_approval}, final_report_data length: {len(st.session_state.final_report_data) if st.session_state.final_report_data else 'None'}"
        )
        with st.container():
            st.subheader("📄 Final Report Approval (Step 2/2)")
            st.info(
                "Please review the final report and approve or provide feedback for regeneration."
            )
            # --- FIX: Always fetch latest status_data to get final_report ---
            status_data = get_report_status(st.session_state.job_id)
            final_report = None
            if status_data:
                final_report = status_data.get("final_report")
                if final_report:
                    st.session_state.final_report_data = final_report
            # --- END FIX ---

            if st.session_state.final_report_data:
                st.markdown(
                    """
                    <style>
                    .report-container {
                        max-width: 1200px;
                        margin-left: auto;
                        margin-right: auto;
                        overflow-x: auto;
                        padding: 1rem;
                    }
                    </style>
                    """,
                    unsafe_allow_html=True,
                )
                logger.info("Rendering final report with sections.")
                tab1, tab2 = st.tabs(["Formatted Report", "Raw Data"])
                with tab1:
                    with st.container():
                        st.markdown(
                            '<div class="report-container">', unsafe_allow_html=True
                        )
                        try:
                            # --- FIX: Always parse final_report_data as JSON array of sections ---
                            report_sections = json.loads(
                                st.session_state.final_report_data
                            )
                            if isinstance(report_sections, list):
                                # render_report(report_sections)
                                render_report_sections_tree(
                                    report_sections, expanded_by_default=True
                                )
                            else:
                                st.markdown(
                                    st.session_state.final_report_data,
                                    unsafe_allow_html=True,
                                )
                        except Exception:
                            st.markdown(
                                st.session_state.final_report_data,
                                unsafe_allow_html=True,
                            )
                        st.markdown("</div>", unsafe_allow_html=True)
                        # Show report generation time if available
                        if status_data and status_data.get("completed_at"):
                            st.info(
                                f"Report generation time: {status_data['completed_at']}"
                            )

                        logger.info("Before delete block")

                        # Delete the documents from S3 prop data store
                        if (
                            "uploaded_documents" in st.session_state
                            and st.session_state.uploaded_documents
                        ):
                            delete_api_url = get_api_url() + "/delete-document"
                            response = requests.delete(
                                delete_api_url,
                                data={
                                    "username": st.session_state.username.lower()
                                },  # Ensure username is lowercase for consistency
                            )
                            # Clear uploaded documents from sidebar after deletion
                            st.session_state.uploaded_documents = []
                with tab2:
                    st.code(st.session_state.final_report_data, language="json")

                # --- Add Approve and Regenerate buttons ---
                feedback_text = st.text_area(
                    "Feedback for Regeneration (optional)",
                    placeholder="Provide specific feedback if you want to reject and regenerate...",
                )
                col1, col2 = st.columns(2)
                with col1:
                    if st.button("✅ Approve Final Report", type="primary"):
                        handle_approve_final_report()
                        st.session_state.monitoring = True
                        st.rerun()
                with col2:
                    if st.button("🔄 Regenerate"):
                        handle_reject_final_report(
                            feedback_text if feedback_text.strip() else None
                        )
                        st.session_state.monitoring = True
                        st.rerun()
                # --- End buttons ---
            else:
                st.error("No final report data available for approval.")
                st.write("Debug info:")
                st.write(f"- Job ID: {st.session_state.job_id}")
                st.write(
                    f"- Awaiting final approval: {st.session_state.awaiting_final_approval}"
                )
                st.write(f"- Final report data: {st.session_state.final_report_data}")
                if st.button("Refresh Status"):
                    st.session_state.monitoring = True
                    st.rerun()
    if st.session_state.report_data:
        st.header("Generated Report")
        report_json = json.dumps(st.session_state.report_data, indent=2)
        st.download_button(
            label="Download Report JSON",
            data=report_json,
            file_name=f"synthia_report_{st.session_state.job_id}.json",
            mime="application/json",
        )

        main_col, right_sidebar = st.columns([4, 2], gap="large")
        
        with main_col:
            tab1, tab2 = st.tabs(["Formatted Report", "Raw Data"])
            with tab1:
                render_report_sections_tree(st.session_state.report_data)
                status_data = get_report_status(st.session_state.job_id)
                if status_data and status_data.get("completed_at"):
                    st.info(f"Report generation time: {status_data['completed_at']}")
            with tab2:
                st.json(st.session_state.report_data)
        
        # --- Begin Right Sidebar Layout ---
        with right_sidebar:
            is_action_button_disabled = lambda: st.session_state.regen_job_monitoring or (not st.session_state.regen_edited_section)
            is_generate_button_disabled = lambda: st.session_state.regen_generate_clicked or st.session_state.regen_job_monitoring

            st.markdown("### Actions", unsafe_allow_html=True)
            regen_input = st.container(border=True)
            
            # leaf_section contains mapping of section name to section ID, i.e. {"Market Analysis": "MAC1", ...}
            leaf_sections = st.session_state.report_section if "report_section" in st.session_state else {}
            selected_section_name = regen_input.selectbox(
                "Select Section to edit",
                options=[""] + list(leaf_sections.keys()),
                index=0,
                key="right_sidebar_logical_section"
            )
            if selected_section_name:
                logger.info(f"Selected section for regeneration: {selected_section_name}, section_id: {leaf_sections.get(selected_section_name)}")
                if selected_section_name != st.session_state.get("regen_section_name", None):
                    logger.info("Resetting current section edit state...")
                    reset_section_edit_state()
                st.session_state.regen_section_name = selected_section_name
                st.session_state.regen_section_id = leaf_sections.get(selected_section_name)
            else:
                st.session_state.regen_section_name = None
                st.session_state.regen_section_id = None
            st.markdown("---")
            
            # accept, decline, try again buttons in a row
            if st.session_state.regen_section_name:
                btn_col1, btn_col2, btn_col3 = st.columns([1, 1, 1], gap="small")
                with btn_col1:
                    accept = st.button("Accept", key="right_sidebar_accept", use_container_width=True, disabled=is_action_button_disabled())
                with btn_col2:
                    decline = st.button("Decline", key="right_sidebar_decline", use_container_width=True, disabled=is_action_button_disabled())
                with btn_col3:
                    retry = st.button("Retry", key="right_sidebar_try_again", use_container_width=True, disabled=is_action_button_disabled())

                if accept:
                    handle_accept_reject_retry_section_edit(action="approve")
                    st.session_state.regen_job_monitoring = True
                    # st.session_state.regen_section_id = None
                    st.session_state.custom_prompt = ""
                    st.rerun()
                if decline:
                    handle_accept_reject_retry_section_edit(action="decline")
                    # st.session_state.regen_section_name = None
                    # st.session_state.regen_section_id = None
                    st.session_state.regen_job_monitoring = True
                    st.session_state.regen_edited_section = None
                    st.rerun()
                if retry:
                    handle_accept_reject_retry_section_edit(action="retry")
                    # Set regenerate clicked to true to trigger regeneration flow
                    st.session_state.regen_generate_clicked = True
                    # st.rerun()

            # Custom prompt input and Generate button at the bottom
            def handle_custom_prompt_change():
                st.session_state["custom_prompt_input"] = st.session_state.get("custom_prompt_key", "")
                logger.info("Custom prompt updated via callback: " + st.session_state["custom_prompt_input"])

            if st.session_state.regen_section_name:
                st.text_area(
                    "Custom Prompt", 
                    key="custom_prompt_key", 
                    value=st.session_state.custom_prompt if "custom_prompt" in st.session_state else "", 
                    height=150, 
                    placeholder="Enter custom prompt for regeneration...", 
                    disabled=is_generate_button_disabled(),
                    on_change=handle_custom_prompt_change      
                )
                generate_button = st.button("Generate", key="right_sidebar_generate", 
                                            use_container_width=True, disabled=is_generate_button_disabled())
                if generate_button:
                    st.session_state.regen_generate_clicked = True

            logger.info("Custom prompt updated via callback: " + st.session_state["custom_prompt_input"])
            # handle section regeneration flow on click of Generate button
            if st.session_state.regen_generate_clicked:

                if not st.session_state.regen_section_name:
                    st.error("Please select a section to regenerate.")
                    st.stop()

                if not st.session_state.get("custom_prompt_input", "").strip():
                    st.error("Please enter a custom prompt for regeneration.")
                    st.stop()

                # set prompt_id and previous_prompt_id
                if st.session_state.get("custom_prompt_input", "").strip() != st.session_state.custom_prompt:
                    st.session_state.custom_prompt = st.session_state.get("custom_prompt_input", "").strip()
                    st.session_state.previous_prompt_id = st.session_state.prompt_id  # Reset previous prompt ID if prompt changed
                    st.session_state.prompt_id = str(uuid.uuid4())
                
                logger.info(
                    f"Starting new section regeneration: section={selected_section_name}, section_id={leaf_sections.get(selected_section_name)}"
                )
                with st.spinner("Starting section regeneration..."):
                    status = start_section_regeneration(
                        job_id=st.session_state.job_id,
                        prompt_id=st.session_state.prompt_id,
                        prompt=st.session_state.custom_prompt,
                        section_id=leaf_sections.get(selected_section_name),
                        section_name=selected_section_name,
                        previous_prompt_id=st.session_state.previous_prompt_id
                    )
                
                # Reset the generate clicked state
                if st.session_state.regen_generate_clicked:
                    st.session_state.regen_generate_clicked = False

                if status == "accepted" or status == "section_edit_queued":
                    logger.info(
                        f"Section regeneration started successfully with job ID: {st.session_state.job_id} and prompt ID: {st.session_state.prompt_id}"
                    )
                    st.session_state.regen_job_monitoring = True
                    st.success(f"Section regeneration started! Job ID: {st.session_state.job_id} Prompt ID: {st.session_state.prompt_id}")
                    st.rerun()
                else:
                    logger.error("Failed to start section regeneration - no job ID returned")
                    st.session_state.regen_job_monitoring = False
                    # st.rerun()


            # If we have an active section regen job, monitor progress
            if st.session_state.job_id and st.session_state.prompt_id and st.session_state.regen_job_monitoring:
                logger.info(f"Monitoring section edit regeneration job {st.session_state.job_id}")
                report_placeholder = st.empty()

                # Monitor progress for section regeneration
                with st.spinner("Monitoring section regeneration progress..."):
                    while st.session_state.regen_job_monitoring:
                        status_data = get_section_regenration_status(
                            st.session_state.job_id,
                            st.session_state.prompt_id
                        )

                        if status_data:
                            current_status = status_data.get("status")
                            
                            logger.info(
                                f"Section edit Job {st.session_state.job_id} and Prompt id: {st.session_state.prompt_id} status update: status={current_status}"
                            )

                            # Check if outline needs approval
                            if current_status == "section_edit_awaiting_approval" or current_status == "section_edit_completed":
                                edited_section = status_data.get("response", {}).get("edited_section", "")
                                st.session_state.regen_edited_section = edited_section
                                logger.info(f"Updated edited section in session state for job {st.session_state.job_id} and prompt id: {st.session_state.prompt_id}: \n {edited_section}")
                                st.session_state.regen_job_monitoring = False
                                st.success("Section regeneration completed!")
                                # Set old and new data for diff view
                                edited_section["sources"] = []
                                updated_section = append_regenerated_section_by_id(
                                        st.session_state.report_data, 
                                        edited_section.get("id"), 
                                        edited_section if edited_section else {}
                                )
                                st.session_state.report_data = updated_section
                                st.rerun()

                            elif current_status == "section_edit_processing":
                                # Keep polling during section creation
                                pass

                            elif current_status == "section_edit_approved":
                                st.success("Section edit approved and applied to the report!")
                                st.session_state.regen_job_monitoring = False
                                edited_section = status_data.get("response", {}).get("edited_section", "")
                                edited_section["sources"] = []
                                updated_section = replace_section_by_id(
                                        st.session_state.report_data, 
                                        edited_section.get("id"), 
                                        edited_section if edited_section else {}
                                )
                                st.session_state.report_data = updated_section
                                st.session_state.regen_edited_section = None
                                st.rerun()

                            elif current_status == "section_edit_declined":
                                edited_section = status_data.get("response", {}).get("edited_section", "")
                                updated_section = remove_regenerated_section_by_id(
                                    st.session_state.report_data,
                                    edited_section.get("id")
                                )
                                st.session_state.report_data = updated_section
                                st.session_state.regen_job_monitoring = False
                                st.session_state.regen_edited_section = None
                                st.warning("Section edit was declined. You can try regenerating again.")
                                st.rerun()

                            # Continue monitoring during section creation phase
                            elif current_status == "section_edit_queued":
                                # Keep polling during report creation
                                pass

                            # Check if there was an error
                            elif status_data.get("status") == "failed":
                                st.error(f"Section regeneration failed: {status_data.get('error')}")
                                st.session_state.regen_job_monitoring = False
                                st.rerun()

                        # Only wait if we're still monitoring
                        if st.session_state.regen_job_monitoring:
                            time.sleep(5)  # polling interval

        # --- End Right Sidebar Layout ---

        # Delete S3 object after report is generated
        if (
            "uploaded_document" in st.session_state
            and st.session_state.uploaded_document
        ):
            logging.info(f"delete document {st.session_state.uploaded_document}")
            delete_api_url = get_api_url() + "/delete-document"
            response = requests.delete(
                delete_api_url,
                data={
                    "username": st.session_state.username.lower()
                },  # Ensure username is lowercase for consistency
            )


if __name__ == "__main__":
    logger.info("Synthia application starting...")
    # Call this early in your app startup
    chart_dir = ensure_chart_directory()
    logger.info(f"Chart directory ensured at: {chart_dir}")
    main()
