from enum import Enum
from typing import Dict, Union

from typing_extensions import Self


class LLMInputOption(Enum):
    """The default keys for LLM configuration options"""

    MAX_TOKENS = "max_tokens"  # Maximum number of tokens to generate in the output.
    STOP = "stop_sequences"  # A list of strings where the model will stop generating further tokens.

    @staticmethod
    def has_value(name: str) -> bool:
        return name in [i.value for i in LLMInputOption]

    @staticmethod
    def has_key(key: str) -> bool:
        return key in [i.name for i in LLMInputOption]

    @staticmethod
    def parse(cfg_key: str) -> Union[Self, None]:
        """Parse the configuration key to the corresponding LLMInputOption to get default value."""
        if not LLMInputOption.has_value(cfg_key):
            return None
        for item in LLMInputOption:
            if item.value == cfg_key:
                return item


class ProviderDetails:
    """Helper class to hold provider details.

    Arguments:
        input_key (str): The key for the user input/prompt.
        output_key (str): The key for the model's result output.
        input_config_key (str, optional): The key for the input configuration.
            Defaults to None, if the configuration should be on the root level.
        custom_input_configuration (Dict[ConfigOption, str], optional): Custom mapping for input configurations,
            if the provider uses different keys for configuration options than the default ones.
            Defaults to an empty dictionary if the provider use the default ones.
    """

    def __init__(
        self,
        input_key: str,
        output_key: str,
        input_config_key: str = None,
        custom_input_configuration: Dict[LLMInputOption, str] = {},
    ):
        self.input_key = input_key
        self.output_key = output_key
        self.input_config_key = input_config_key
        self.custom_input_configuration = custom_input_configuration

    def get_input_config_name(self, config: Union[str, LLMInputOption]) -> str:
        """Get custom or default configuration name for the provider."""
        input_option = config if isinstance(config, LLMInputOption) else LLMInputOption.parse(config)

        if not input_option:
            return config
        spec_cfg = self.custom_input_configuration.get(input_option)
        if spec_cfg:
            return spec_cfg
        return input_option.value


# Define typical ProviderDetails for different LLM providers
amazon_like_provider = ProviderDetails(
    input_key="inputText",
    output_key="results[0].outputText",
    input_config_key="inputTextConfig",
    custom_input_configuration={
        LLMInputOption.MAX_TOKENS: "maxTokenCount",
        LLMInputOption.STOP: None,  # Not supported
    },
)
generation_output_provider = ProviderDetails(
    input_key="prompt",
    output_key="generations[0].text",
)
completion_output_provider = ProviderDetails(
    input_key="prompt",
    output_key="completion",
    custom_input_configuration={
        LLMInputOption.MAX_TOKENS: "max_tokens_to_sample",
    },
)
completion_data_text_output_provider = ProviderDetails(
    input_key="prompt",
    output_key="completions[0].data.text",
    custom_input_configuration={
        LLMInputOption.MAX_TOKENS: "maxTokens",
        LLMInputOption.STOP: "stopSequences",
    },
)
content_output_provider = ProviderDetails(
    input_key="prompt",
    output_key="content",
    custom_input_configuration={
        LLMInputOption.MAX_TOKENS: "max_gen_len",
        LLMInputOption.STOP: None,  # Not supported
    },
)
text_output_provider = ProviderDetails(
    input_key="prompt",
    output_key="text",
    custom_input_configuration={
        LLMInputOption.STOP: None,  # Not supported
    },
)


class ProviderMapping(Enum):
    """Enum to map providers to their input and output formats."""

    AI21 = completion_data_text_output_provider
    AI21_LLM = completion_data_text_output_provider
    ANTHROPIC = completion_output_provider
    AMAZON = amazon_like_provider
    BEDROCK = amazon_like_provider
    CLAUDE = completion_output_provider
    COHERE = generation_output_provider
    COHERE_LLM = generation_output_provider
    LLAMA = content_output_provider
    META = content_output_provider
    MISTRAL = text_output_provider

    def parse(provider: str) -> Self:
        try:
            provider = provider.replace("-", "_").upper()
            return ProviderMapping[provider]
        except KeyError:
            raise ValueError(f"Unknown provider: {provider}")

    def get_role_format(self, role: str) -> str:
        """Get the role format based on the provider."""
        if role in ["assistant", "system"]:
            return f"\n\n{role.capitalize()}:"
        elif role == "user":
            if self in [ProviderMapping.ANTHROPIC, ProviderMapping.CLAUDE]:
                return "\n\nHuman:"
            return "\n\nUser:"
        else:
            raise ValueError(f"Invalid role: {role}. Supported roles are 'assistant', 'system', and 'user'.")
