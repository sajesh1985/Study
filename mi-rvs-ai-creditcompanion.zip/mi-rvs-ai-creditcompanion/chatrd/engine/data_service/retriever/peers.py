import logging

from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.data_service.retriever.base import BaseRetriever
from chatrd.engine.data_service.retriever.utils import _retrieve
from chatrd.engine.data_service.schema import Analyzer, ProcessorInput, Retriever

logger = logging.getLogger(__name__)
config_machinery = get_config_machinery()


class PeersRetriever(BaseRetriever):
    def retrieve(self, processor: ProcessorInput = None, analyzer: Analyzer = None):
        if not processor.entities or len(processor.entities["companies"]) == 0:
            return Retriever()
        entities = processor.entities
        rd_subsector = entities["companies"][0]["subsector_code"]
        keyinstn_id = entities["companies"][0]["mi_id"]
        endpoint_path = Constants.RatingsAPI.RATINGS_API_ANALYST_PEER_ENDPOINT_PATH
        parameter = keyinstn_id

        if rd_subsector == "SOV":
            url = entities["companies"][0]["url"]
            KeyCountry = url.split("keycountry=")[-1]
            endpoint_path = Constants.RatingsAPI.RATINGS_API_ANALYST_PEER_COUNTRY_ENDPOINT_PATH
            parameter = f"{KeyCountry}/{keyinstn_id}"

        return _retrieve(endpoint_path, parameter)
