from asyncio import TaskGroup
from typing import List
from src.synthia.persistence.template_metadata_repository import DatabaseTemplateMetadataRepository
from src.synthia.schemas.template import Template
from src.synthia.services.template_service.dto import CompanyTemplate
from src.synthia.services.template_service.dto_factory import to_dto
from src.synthia.services.template_service.template_choosing import choose_by_metadata
from src.synthia.utils.template_util import load_all_templates
from uuid import UUID


class TemplateService:
    """
    Note: figure out the better way to load specific template than by load_all_templates someday/next iteration
    """
    def __init__(self, repository: DatabaseTemplateMetadataRepository):
        self.repository = repository
        self.fields = DatabaseTemplateMetadataRepository.Columns

    async def get_company_templates_metadata(self, company_name: str | None) -> List[CompanyTemplate]:
        templates_metadata = await self.repository.get_templates_metadata(company_name)
        return [to_dto(metadata) for metadata in templates_metadata]

    async def get_company_template_content_by_id(self, company_name: str, template_id: UUID) -> Template | None:
        async with TaskGroup() as tg:
            metadata_if_found_task = tg.create_task(self.repository.get_template_metadata_by_id(company_name, template_id))
            filenames_to_content_task = tg.create_task(load_all_templates())
        return choose_by_metadata(filenames_to_content_task.result(), metadata_if_found_task.result())



