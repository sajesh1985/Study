import React from 'react';
import {
  Badge,
  badgeAppearance,
  Button,
  Card,
  CardBody,
  CardHeader,
  NotificationType,
  useNotification,
} from '@spglobal/react-components';
import { AccessDeniedError, SpgError, toDetailedError, toError } from '@spglobal/error';
import { data, dataDetailExtractor } from './errorMock';

export const ErrorTemplate: React.FC = () => {
  const { addNotification } = useNotification();

  return (
    <>
      <div id="error_example" className="spg-m-sm" />
      <Card hasBorder>
        <CardHeader title="Error Example" />
        <CardBody className="spg-text-medium">
          <p>
            This is the example of <code>@spglobal/error</code> usage.
          </p>
          <p>
            <code>@spglobal/error</code> provides:
            <ul>
              <li>
                <strong>
                  <code>SpgError</code>
                </strong>{' '}
                — base Error extension that has the primary function of supporting copy constructor
                and toError functionality;
              </li>
              <li>
                <strong>
                  <code>toError</code>
                </strong>{' '}
                — returns a SpgError or derivative;
              </li>
              <li>
                <strong>
                  <code>toDetailedError</code>
                </strong>{' '}
                — create an error of a specific type and populate the error from data using an
                extraction function;
              </li>
            </ul>
          </p>
          <p>
            Other available exports are{' '}
            <code>AccessDeniedError, NotImplementedError, TimeoutError</code>.
          </p>
          <p>
            For the following examples, we use <code>InlineNotificationGroup</code> from{' '}
            <code>@spglobal/react-components</code>. You can use another way of showing an error
            depending on your purpose.
          </p>
          <Badge className="spg-mb-sm">Sample</Badge>
          <div className="spg-align-center spg-mb-sm">
            <Button
              onClick={() => {
                const source = { name: 'Custom error name', message: 'Custom error message' };
                const err = new SpgError(source.name, source.message);
                addNotification(
                  <div>
                    <p>
                      Error name is <strong>{err.name}</strong>.
                    </p>
                    <p>
                      Error massage is <strong>{err.message}</strong>.
                    </p>
                  </div>,
                  NotificationType.ERROR
                );
              }}
              className="spg-ml-md"
            >
              Create a new SpgError
            </Button>
            <Button
              onClick={() => {
                const err = toDetailedError(
                  data,
                  dataDetailExtractor,
                  SpgError,
                  'Custom error message'
                );
                const { details } = err;
                const { type, correlationId, securities, statusCode, statusMessage } = details;
                addNotification(
                  <div>
                    <strong>{err.message}</strong>
                    <table>
                      <tbody>
                        <tr>
                          <td>
                            <strong>Error details:</strong>
                          </td>
                        </tr>
                        <tr>
                          <td>Type:</td>
                          <td>{type}</td>
                        </tr>
                        <tr>
                          <td>Correlation ID:</td>
                          <td>{correlationId}</td>
                        </tr>
                        <tr>
                          <td>Securities:</td>
                          <td>{securities}</td>
                        </tr>
                        <tr>
                          <td>Status Code:</td>
                          <td>{statusCode}</td>
                        </tr>
                        <tr>
                          <td>Status Message:</td>
                          <td>{statusMessage}</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>,
                  NotificationType.ERROR
                );
              }}
              className="spg-ml-md"
            >
              Create a new SpgError with details
            </Button>
            <Button
              onClick={() => {
                const inputError = new SpgError('You are not authorized to access the page');
                const err = toError(inputError, true, AccessDeniedError);
                addNotification(
                  <div>
                    <p>
                      Error name is <strong>{err.name}</strong>.
                    </p>
                    <p>
                      Error massage is <strong>{err.message}</strong>.
                    </p>
                  </div>,
                  NotificationType.ERROR
                );
              }}
              className="spg-ml-md"
            >
              Convert SpgError to <strong>AccessDeniedError</strong>.
            </Button>
          </div>
          <div className="spg-row">
          </div>
          <p>
            <Badge purpose={badgeAppearance.seventh} className="spg-mb-sm">
              Note:
            </Badge>
            a full set of usage examples can be found in the unit testing file{' '}
            <code>spgError.test.ts</code>.
          </p>
        </CardBody>
      </Card>
    </>
  );
};
