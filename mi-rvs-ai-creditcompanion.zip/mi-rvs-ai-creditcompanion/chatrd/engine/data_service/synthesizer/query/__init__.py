from .generic import GenericQuerySynthesizer
