import json
import logging
import re
from collections import defaultdict
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd

from chatrd.core.llm import LCLLMFactory
from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.data_service.synthesizer.financial.prompt import (
    PROMPT_FINANCIAL_SYNTHESIZER_TEMPLATE,
    TABLE_DECTECTION_LLM_PROMPT,
)
from chatrd.engine.data_service.synthesizer.utils import text_response

logger = logging.getLogger(__name__)
config_machinery = get_config_machinery()


def get_sourcing_footnote_base_url() -> str:
    source_base_url = config_machinery.get_config_value(Constants.SourceGeneration.BASE_URL)
    footnote_url_slug = config_machinery.get_config_value(Constants.SourceGeneration.FOOTNOTE_URL_SLUG)
    return source_base_url + footnote_url_slug


def _merge_definitions_data(response: dict):
    response_actual_data = response.get("value", [])
    response_metadata = json.loads(response.get("metadata", "{}")).get("value", [])

    metadata_dict = {item["PropertyName"]: item for item in response_metadata}

    for data in response_actual_data:
        data["definition"] = metadata_dict.get(data.get("ItemName"))

    return response_actual_data


def clean_and_transform_dataframe(json_data):
    """
    Cleans and transforms a JSON-like dataset into a structured pandas DataFrame.

    Args:
        json_data (list of dict): The input data in JSON format, where each dictionary represents a row.

    Returns:
        pd.DataFrame: A cleaned and transformed DataFrame with the following changes:
            - Replaces occurrences of '&nbsp;' with None.
            - Extracts and renames columns starting with "YEAR_" based on the first row's values.
            - Renames the "ProductCaption" column to "MetricName".
            - Drops the "ItemName" and "Sort_Order" columns if they exist.
            - Removes rows where all year columns have None values.
            - Removes columns where all values are None.
            - Resets the index of the DataFrame.

    """
    df = pd.DataFrame(json_data)
    df = df.replace(r"&nbsp;?", None, regex=True)
    year_cols = [c for c in df.columns if c.startswith("YEAR_")]
    if not year_cols:
        logger.info("No YEAR_ columns found in data.")
        return df

    if df.empty or df.shape[0] < 1:
        logger.info("The DataFrame does not have enough rows to extract year names.")
        return df
    year_names = df.iloc[0][year_cols].tolist()
    df = df.drop(index=0).reset_index(drop=True)
    rename_dict = {old: new for old, new in zip(year_cols, year_names)}
    df = df.rename(columns={"ProductCaption": "MetricName", **rename_dict})
    df = df.drop(columns=["ItemName", "Sort_Order"], errors="ignore")
    df = df.dropna(subset=year_names, how="all")
    df = df.dropna(axis=1, how="all")
    df = df.reset_index(drop=True)
    return df


def filter_financial_year_data(response_data, time_periods):
    quarters = [t.strip() for t in time_periods if "Q" in t]
    half_years = [t.strip() for t in time_periods if "H" in t]
    fiscal_years = [t.strip() for t in time_periods if "Y" in t and "Q" not in t and "H" not in t]

    metric_period_map = defaultdict(lambda: defaultdict(dict))  # company -> metric -> period -> data

    for item in response_data:
        company = item.get("Company", "").strip()
        metric = item.get("MetricName", "").strip()
        period = item.get("Period", "").strip()
        if item.get("MetricValue"):
            metric_period_map[company][metric][period] = item

    final_flat_list = []

    for company, metrics in metric_period_map.items():
        for metric, periods in metrics.items():
            added = False
            if quarters == ["LFQ"]:
                final_flat_list.extend(periods.values())
            for q in quarters:
                if q in periods:
                    final_flat_list.append(periods[q])
                    added = True
            if not added:
                for h in half_years:
                    if h in periods:
                        final_flat_list.append(periods[h])
                        added = True
            if not added:
                for fy in fiscal_years:
                    if fy in periods:
                        final_flat_list.append(periods[fy])
                        added = True
            if not (quarters or half_years) and not added:
                for p in sorted(periods):
                    if "Y" in p and "Q" not in p and "H" not in p:
                        final_flat_list.append(periods[p])

    return final_flat_list


def template_leading_line(
    company_name: List[str] = "", metrics_status: str = "default", rd_sector=None, entity_id=None
) -> str:
    """
    Generate leading line based on metrics status - simplified to two conditions

    Args:
        rev_source_name: The source name
        metrics_status: "general" or "empty"
    """
    if isinstance(company_name, list):
        company_name = ", ".join(company_name)

    base_url = get_sourcing_footnote_base_url()
    sector_urls = {
        "Corporates": "#company/csd?Id=",
        "Financial Institutions": "#company/financialhighlightsFI?Id=",
        "Insurance": "#company/insuranceData?Id=",
    }

    if metrics_status == "general":
        if company_name and entity_id and rd_sector:
            url_suffix = sector_urls.get(rd_sector, "#company/csd?Id=")
            sourcing_url = base_url + url_suffix + entity_id
            template = (
                f"{company_name} has the following financial highlights "
                f'<a href="{sourcing_url}" target="_blank" title="{company_name}">[1]</a> from CreditStats Direct®:'
            )
        else:
            template = f"Sorry, CreditCompanion<sup>TM</sup> couldn't find requested information for {company_name}. Please rephrase your question and try again."

    elif metrics_status == "empty":
        template = f"Sorry, CreditCompanion<sup>TM</sup> couldn't find requested information for {company_name}. Please rephrase your question and try again."

    else:
        template = f"Sorry, CreditCompanion<sup>TM</sup> couldn't find requested information for {company_name}. Please rephrase your question and try again."

    return template


def template_error_leading_line(metric_name=None, company_name=None, entity_id=None, rd_sector=None) -> str:
    """
    Returns a CreditCompanion error message.

    - For a single entity: Includes a hyperlink to CreditStats Direct® if entity_id and rd_sector are provided.
    - For multiple entities: Returns a general fallback message without hyperlinks.

    Parameters:
    - metric_name: str or list of metric names
    - company_name: str or list of entity names
    - entity_id: str or list of entity IDs (for single entity only)
    - rd_sector: str or list of sectors (for single entity only)

    Returns:
    - str: formatted error message
    """

    base_url = get_sourcing_footnote_base_url()
    sector_urls = {
        "Corporates": "#company/csd?Id=",
        "Financial Institutions": "#company/financialhighlightsFI?Id=",
        "Insurance": "#company/insuranceData?Id=",
    }
    metrics_str = ", ".join(metric_name) if isinstance(metric_name, list) else metric_name

    # Case: multiple entities
    if isinstance(company_name, list):
        names_str = ", ".join(company_name)
        if len(company_name) > 1:
            template = (
                f"Sorry, CreditCompanion<sup>TM</sup> couldn't find requested information for {names_str}. "
                f"Please rephrase your question and try again."
            )
            return template

        # Case: single entity
        else:
            url_suffix = sector_urls.get(rd_sector, "#company/csd?Id=")
            sourcing_url = base_url + url_suffix + entity_id
            metrics_str = ", ".join(metric_name) if isinstance(metric_name, list) else metric_name

            template = f"""Unfortunately, CreditCompanion<sup>TM</sup> is unable to provide information about {metrics_str}.
                Please review the following financial highlights of {names_str} from CreditStats Direct®:
                <a href="{sourcing_url}" target="_blank">{names_str} | Financial Highlights</a>"""
            return template


def prepare_metric_categories_from_metric_type(metrics_list: list) -> dict:
    """
    Prepare metric categories mapping for the LLM prompt using MetricType,
    ensuring each unique metric appears in only one category.

    Args:
        metrics_list: List of metric dicts with 'MetricName' and 'MetricType'

    Returns:
        dict: Mapping of categories to their respective unique metric names
    """
    metric_type_to_category = {
        "FH": "Financial Highlights",
        "IS": "Income Statement Adjusted",
        "BS": "Balance Sheet Adjusted",
        "CF": "Cashflow Adjusted",
        "CS": "Capital Structure Adjusted",
        "SUP": "Supplemental Adjusted",
        "CA": "Capital Analysis Adjusted",
    }

    category_metrics = {}
    assigned_metrics = set()

    for metric in metrics_list:
        name = metric.get("MetricName")
        mtype = metric.get("MetricType")

        if not name or not mtype or name in assigned_metrics:
            continue

        category = metric_type_to_category.get(mtype, "Financial Highlights")
        if category not in category_metrics:
            category_metrics[category] = []
        category_metrics[category].append(name)
        assigned_metrics.add(name)

    return category_metrics


def get_sector_category_fragment(rd_sector: str, category: str) -> str:
    """
    Returns the URL hash fragment based on rd_sector and category.
    Falls back to Financial Highlights if mapping not found.
    """
    fragment_map = {
        ("Corporates", "Financial Highlights"): "#company/csd?Id=",
        ("Corporates", "Income Statement Adjusted"): "#company/incomeStatement?Id=",
        ("Corporates", "Balance Sheet Adjusted"): "#company/balanceSheetRD?Id=",
        ("Corporates", "Cashflow Adjusted"): "#company/cashFlow?Id=",
        ("Corporates", "Capital Structure Adjusted"): "#company/capitalStructure?Id=",
        ("Corporates", "Supplemental Adjusted"): "#company/supplemental?Id=",
        ("Financial Institutions", "Financial Highlights"): "#company/financialhighlightsFI?Id=",
        ("Financial Institutions", "Income Statement Adjusted"): "#company/incomeStatementFI?Id=",
        ("Financial Institutions", "Balance Sheet Adjusted"): "#company/balanceSheetFI?Id=",
        ("Financial Institutions", "Capital Analysis Adjusted"): "#company/capitalanalysisFI?Id=",
        ("Insurance", "Financial Highlights"): "#company/insuranceData?Id=",
    }

    # Fallback to Financial Highlights
    return fragment_map.get(
        (rd_sector, category), fragment_map.get((rd_sector, "Financial Highlights"), "#company/csd?Id=")
    )


def assign_citations(
    data: list,
    analyzer_response: dict,
    base_url: str,
    citation_counter: int,
    url_citation_map: dict,
    citation_map_per_entry: dict,
):
    """
    Assigns citations and URLs to each data entry using Analyzer response directly.

    Args:
        data: List of metric data dicts with 'Company', 'MetricName', 'Period'.
        analyzer_response: Analyzer.response dictionary.
        base_url: Base URL for generating citation links.
        citation_counter: Current citation number.
        url_citation_map: URL to citation number mapping.
        citation_map_per_entry: (company, metric, period) to citation/url mapping.

    Returns:
        Updated data list and citation_counter
    """
    metrics_list = analyzer_response["metricsList"]
    results = analyzer_response["result"]

    # Build category map
    metric_categories = prepare_metric_categories_from_metric_type(metrics_list)
    company_map = {
        result["company"].strip(): {"entity_id": result["keyInstn"], "rd_sector": result["rd_sector"]}
        for i, result in enumerate(results)
    }

    for entry in data:
        company = entry["Company"].strip()
        metric_name = entry["MetricName"]
        period = entry["Period"].strip()

        company_info = company_map.get(company)
        if not company_info:
            raise ValueError(f"No metadata found for company: {company}")

        rd_sector = company_info["rd_sector"]
        entity_id = company_info["entity_id"]

        category = next(
            (cat for cat, names in metric_categories.items() if metric_name in names), "Financial Highlights"
        )

        hash_fragment = get_sector_category_fragment(rd_sector, category)
        # hash_fragment = fragment_map.get((rd_sector, category), "#company/csd?Id=")
        raw_url = f"{base_url}{hash_fragment}{entity_id}"

        if raw_url not in url_citation_map:
            url_citation_map[raw_url] = citation_counter
            citation_counter += 1

        citation = url_citation_map[raw_url]
        html_url = (
            f'<a href="{raw_url}" title="{company}-{category}" target="_blank" '
            f'rel="noopener noreferrer" class="ccInTextCitation">[{citation}]</a>'
        )
        citation_map_per_entry[(company, metric_name, period)] = {"citation": citation, "url": html_url}

        entry["citation_url"] = html_url

    return data, citation_counter


def clean_metric_names(data):
    cleaned_data = []
    for item in data:
        metric = item["MetricName"].strip()
        # Check for a trailing (...) and remove it ONLY IF it does NOT contain a %
        # This targets the last (...) group at the end of the string
        match = re.search(r"\(([^)]*)\)\s*$", metric)
        if match and "%" not in match.group(1):
            # Remove the trailing (...) only
            metric = re.sub(r"\s*\([^)]*\)\s*$", "", metric).strip()

        item["MetricName"] = metric
        cleaned_data.append(item)
    return cleaned_data


def get_synthesizer_llm_response(llm_model, user_query):
    # response_data, company_list, metrics_list, original_language
    try:
        llm_tagging = LCLLMFactory().get_llm(deployment_name_or_model_id=llm_model, temperature=0.0)
        prompt = TABLE_DECTECTION_LLM_PROMPT.format(user_query=str(user_query))
        response = llm_tagging.invoke(prompt)
        response_text = response.content if hasattr(response, "content") else str(response)
        return response_text

    except Exception as e:
        logger.info(f"Error in LLM format detection: {e}")
        raise


def detect_format(user_query: str, company_list: List[str], llm_model: str) -> str:
    company_count = len(company_list)

    # Step 1: LLM if user explicitly requested TABLE
    response_text = get_synthesizer_llm_response(llm_model=llm_model, user_query=user_query)
    match = re.search(r"format:\s*(TABLE|UNKNOWN)", response_text, re.IGNORECASE)
    if match:
        format_detected = match.group(1).upper()
        if format_detected == "TABLE":
            return "TABLE"
        # If UNKNOWN → fallback to company count logic below

    # Step 3: Fallback to rule-based logic
    if company_count == 1:
        return "TEXT"
    elif company_count > 1:
        return "TABLE"
    else:
        return "TABLE"  # default


def generate_markdown_table(response_data: list):
    df = pd.DataFrame(response_data)

    df["Period"] = df["Period"].str.strip()

    # Extract citation number, URL, and title from anchor tag
    def extract_citation_number(link):
        if pd.isna(link) or link == "":
            return ""
        match = re.search(r"\[([0-9]+)\]", str(link))
        return match.group(1) if match else ""

    def extract_href(link):
        if pd.isna(link) or link == "":
            return ""
        match = re.search(r'href="([^"]+)"', str(link))
        return match.group(1) if match else ""

    def extract_title(link):
        if pd.isna(link) or link == "":
            return ""
        match = re.search(r'title="([^"]*)"', str(link))
        return match.group(1) if match else ""

    def extract_class(link):
        if pd.isna(link) or link == "":
            return ""
        match = re.search(r'class="([^"]*)"', str(link))
        return match.group(1) if match else ""

    def extract_target(link):
        if pd.isna(link) or link == "":
            return ""
        match = re.search(r'target="([^"]*)"', str(link))
        return match.group(1) if match else ""

    def extract_rel(link):
        if pd.isna(link) or link == "":
            return ""
        match = re.search(r'rel="([^"]*)"', str(link))
        return match.group(1) if match else ""

    # Extract citation info first
    df["CitationNumber"] = df["citation_url"].apply(extract_citation_number)
    df["CitationURL"] = df["citation_url"].apply(extract_href)
    df["CitationTitle"] = df["citation_url"].apply(extract_title)
    df["CitationClass"] = df["citation_url"].apply(extract_class)
    df["CitationTarget"] = df["citation_url"].apply(extract_target)
    df["CitationRel"] = df["citation_url"].apply(extract_rel)

    # Process metric values with magnitude and citation (including title for hover)
    def format_metric_with_citation(row):
        value_part = f"{row['MetricValue']}"
        magnitude_part = f" {row['Magnitude']}" if row["Magnitude"] else ""

        if row["CitationNumber"] and row["CitationURL"]:
            attributes = []
            attributes.append(f'href="{row["CitationURL"]}"')

            if row["CitationTitle"]:
                attributes.append(f'title="{row["CitationTitle"]}"')
            if row["CitationTarget"]:
                attributes.append(f'target="{row["CitationTarget"]}"')
            if row["CitationRel"]:
                attributes.append(f'rel="{row["CitationRel"]}"')
            if row["CitationClass"]:
                attributes.append(f'class="{row["CitationClass"]}"')

            attributes_str = " ".join(attributes)
            citation_part = f' <a {attributes_str}>[{row["CitationNumber"]}]</a>'
            return f"{value_part}{magnitude_part}{citation_part}"

        else:
            return f"{value_part}{magnitude_part}"

    df["MetricWithCitation"] = df.apply(format_metric_with_citation, axis=1)

    # Get the original order of metrics as they appear in the data
    original_metric_order = df["MetricName"].drop_duplicates().tolist()

    # Pivot to wide format
    pivot_df = df.pivot_table(
        index=["Company", "Period"], columns="MetricName", values="MetricWithCitation", aggfunc="first"
    ).reset_index()

    # Fill NaN values with N/A instead of empty string
    pivot_df = pivot_df.fillna("N/A")

    # Get metric columns that actually exist in the pivoted data
    available_metrics = [col for col in original_metric_order if col in pivot_df.columns]

    # Preserve the original order of metrics as they appear in the data
    # Reorder the dataframe to keep Company and Period first, then metrics in their original order
    pivot_df = pivot_df[["Company", "Period"] + available_metrics]

    # Convert to markdown
    markdown_table = pivot_df.to_markdown(index=False, tablefmt="github")

    return markdown_table


def template_table_leading_line(company_list, period_list):
    companies = ", ".join(company_list)
    periods = ", ".join(period_list)
    return f"Here is the financial data for {companies} for {periods}."


def text_with_table(company_list, period_list, table_data) -> Dict[str, Any]:
    leading_line = template_table_leading_line(company_list, period_list)
    table_text = generate_markdown_table(table_data)
    return [text_response(f"{leading_line}\n\n{table_text}")]


def get_synthesizer_llm_response_text(llm_model, response_data, original_language):
    llm_tagging = LCLLMFactory().get_llm(deployment_name_or_model_id=llm_model, temperature=0.0)
    prompt = PROMPT_FINANCIAL_SYNTHESIZER_TEMPLATE.format(input_data=response_data, original_language=original_language)
    response = llm_tagging.invoke(prompt)
    return response.content


def source_description(
    company_name: str,
    entity_id: str,
    rd_sector: str,
    metric_categories: Optional[Dict[str, List[str]]] = None,
    response_data: Optional[List[Dict]] = None,
) -> List[Tuple[str, str]]:
    """
    Generates source description URLs based on the entity's sector and metric categories present in response data.
    Falls back to 'FINANCIAL HIGHLIGHTS' only if no metric categories are provided.

    Args:
        company_name (str): The name of the entity.
        entity_id (str): The unique identifier of the entity.
        rd_sector (str): The sector of the entity.
        metric_categories (dict, optional): Category to metric list mapping.
        response_data (List[Dict], optional): List of metric records.

    Returns:
        A list containing a tuple with the formatted source description and the generated URL.
        If an error occurs during the process, a default description with an empty URL is returned.
    """
    try:
        base_url = get_sourcing_footnote_base_url()
        result = []

        # Fallback if metric categories are not provided
        if not metric_categories:
            url_add = get_sector_category_fragment(rd_sector, "Financial Highlights")
            sourcing_url = base_url + url_add + entity_id
            return (
                [(f"{company_name} | CreditStats Direct® > FINANCIAL HIGHLIGHTS", sourcing_url)] if sourcing_url else []
            )

        # Safe extraction of metric names
        response_metrics = {
            entry.get("MetricName", "").strip() for entry in (response_data or []) if entry.get("MetricName")
        }

        # Match categories that contain any of the response metrics
        for category, metrics in metric_categories.items():
            cleaned_metrics = []
            for metric in metrics:
                match = re.search(r"\(([^)]*)\)\s*$", metric)
                if match and "%" not in match.group(1):
                    metric = re.sub(r"\s*\([^)]*\)\s*$", "", metric).strip()
                cleaned_metrics.append(metric)

            if any(metric in response_metrics for metric in cleaned_metrics):
                url_add = get_sector_category_fragment(rd_sector, category)
                sourcing_url = base_url + url_add + entity_id
                if sourcing_url:  # only add if sourcing_url is valid
                    source_text = f"{company_name} | CreditStats Direct® > {category}"
                    result.append((source_text, sourcing_url))

        return result

    except Exception as e:
        logger.error(
            f"Failed to generate source description for entity '{company_name}' "
            f"(ID: {entity_id}, RD_Sector: {rd_sector}, Metric Categories: {metric_categories}). Error: {e}"
        )
        return []
