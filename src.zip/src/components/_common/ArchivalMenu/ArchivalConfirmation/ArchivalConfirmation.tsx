
import React from 'react';
import { DivformattedContent } from '../../Content';
import { ArchivalCancelButton, ArchivalConfirmButton, ArchivalConfirmContainer } from './ArchivalConfirmation.styles';


interface ArchivalConfirmProps {
  onConfirm : () => void;
  onCancel : () => void;
}
export const ArchivalConfirm: React.FC<ArchivalConfirmProps> = ({ onConfirm, onCancel }) => {
  const handleConfirmClick = () => {
      onConfirm();
  };

  const handleCancelClick = () => {
      onCancel();
  };


  return (
    <ArchivalConfirmContainer>
    <h1>Archive All</h1>
    <DivformattedContent className="spg-mb-sm">
      Chosing this selection will result in all of your chat history going into your <span style={{color:'#0d71c6'}}> Archived Chats</span> folder. Are you sure? 
    </DivformattedContent>
    <br />
    <ArchivalCancelButton onClick={handleCancelClick}>Cancel</ArchivalCancelButton>
    <ArchivalConfirmButton onClick={handleConfirmClick}>Archive</ArchivalConfirmButton>
  </ArchivalConfirmContainer>

  );
};

