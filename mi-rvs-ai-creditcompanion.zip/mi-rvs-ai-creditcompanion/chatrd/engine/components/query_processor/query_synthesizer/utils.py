import logging
import re
from string import Template
from typing import List, Sequence, Tuple, Union

from chatrd.core.document import (
    CSDTableResponse,
    Document,
    ParentChildTableResponse,
    TableDocument,
    TableResponse,
)

logger = logging.getLogger(__name__)


criteria_link = Template(
    "https://www.capitaliq.spglobal.com/web/client?auth=inherit#ratingsdirect/creditResearch?artObjectId=$id&html=true"
)
research_link = Template(
    "https://www.capitaliq.spglobal.com/web/client?auth=inherit#ratingsdirect/creditResearch?rid=$id"
)


def get_next_untitled_table_name(table_list):
    """
    Given a list of (title, url) tuples, returns the next "Untitled table N" name.
    """
    max_num = 0
    pattern = re.compile(r"^Untitled table (\d+)$", re.IGNORECASE)

    for title, _ in table_list:
        match = pattern.match(title.strip())
        if match:
            num = int(match.group(1))
            max_num = max(max_num, num)

    return f"Untitled table {max_num + 1}"


def split_documents(
    documents: List[Union[Document, TableDocument]],
) -> Tuple[List[Union[Document, TableDocument]], List[Union[Document, TableDocument]]]:
    """
    Split documents based on chunk_type metadata.
    Returns: (table_documents, non_table_documents)
    """
    table_documents = []
    non_table_documents = []

    for doc in documents:
        chunk_type = doc.metadata.get("chunk_type", "")
        if (
            chunk_type == "table"
            or isinstance(doc.content, TableResponse)
            or isinstance(doc.content, CSDTableResponse)
            or isinstance(doc.content, ParentChildTableResponse)
        ):
            table_documents.append(doc)
        else:
            non_table_documents.append(doc)

    logger.info(
        f"Split documents: {len(table_documents)} table documents, {len(non_table_documents)} non-table documents"
    )
    return table_documents, non_table_documents
