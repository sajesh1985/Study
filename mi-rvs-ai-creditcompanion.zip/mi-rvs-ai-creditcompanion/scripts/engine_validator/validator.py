"""This script is designed to validate the ChatRD engine by running a series of prompts against it.
It uses the ChatRD engine to process the prompts and save the LLM results as well as some statistics of the execution.
The execution happens in session with all combinations of the provided LLM configurations.
    E.g: With 2 MAIN_LLMS, 1 DATA_SERVICE_LLM, and 10 prompts, it will run 2 sessions with 10 prompts each.

Use cases:
- Test different LLM configurations and compare their performance.
- Validate the ChatRD engine with custom prompts.
- Generate statistics to compare the performance of different LLMs across various prompts and environments.
- Compare your local changes against the default dev/staging/production environment.
    (Run this script on dev environment then on your local brach and compare the results with the `stat_analyzer.py` script.)

Inputs:
- llm_configs: List of LLM configuration dictionaries. Can be generated easily using the `create_llm_configs` function.
    - main_models: List of main model names. Supported models: see: .constants.MAIN_LLMS}
    - data_service_models: List of data service model names. Supported models: .constants.DATA_SERVICE_LLMS
    - streaming: Whether to enable streaming for the LLMs.
- prompts: List of prompts to test against the LLM. (Default is the predefined set of prompts, See: .prompts.test_prompts)
- stats_file: Name of the file to save statistics. (model prefix will be added to the final name)
- responses_file: Name of the file to save LLM responses. (model prefix will be added to the final name)
- output_folder: Folder to save the output files. (Default is the current working directory.)

Outputs:
    (Each session create own output files with LLM model prefix.
- stats: Multiple CSV file containing the statistics for each prompt with LLM configuration details.
- responses: List of LLM responses in markdown file format for each prompt.
"""

import logging
import os
import time
import types
from contextlib import contextmanager
from itertools import product
from pathlib import Path

import pandas as pd
from dotenv import load_dotenv
from tqdm import tqdm

from chatrd.core.llm.components.message import AIMessage, BaseMessage
from scripts.engine_validator.constants import (
    CSV_DELIMITER,
    DATA_SERVICE_LLMS,
    DEFAULT_LLM,
    MAIN_LLMS,
)
from scripts.engine_validator.prompts import (
    UCType,
    get_prompts_for_uc_types,
    prompt_collection,
)

ERROR_MSG_INDICATOR = "CreditCompanion™ couldn't find"
DEFAULT_MAX_RETRY = 1  # Maximum number of retries for failed requests (response length under 200 chars)
ROOT_FOLDER = Path(__file__).resolve().parents[2]
LOCAL_FOLDER = Path.joinpath(ROOT_FOLDER, "scripts", "engine_validator")
env_file = os.path.join(ROOT_FOLDER, ".env")

# Configure logging with file handler for error logs
log_file = Path.joinpath(LOCAL_FOLDER, "validation.log")
file_handler = logging.FileHandler(log_file, mode="w", encoding="utf-8")
file_handler.setLevel(logging.INFO)
file_formatter = logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s")
file_handler.setFormatter(file_formatter)
logging.basicConfig(level=logging.INFO, handlers=[file_handler])
logger = logging.getLogger(__file__)

print(f"Loading environment variables from {env_file}")
load_dotenv(env_file)


def run_chatengine_with_prompts(
    llm_configs, prompt_dict, stats_file="stats.csv", responses_file="responses.txt", output_folder=""
):
    """Run the chat engine with the provided prompts and save the results and stats."""

    if output_folder:
        root_folder = (
            Path(output_folder) if os.path.isabs(output_folder) else Path.joinpath(LOCAL_FOLDER, output_folder)
        )
    else:
        root_folder = LOCAL_FOLDER
    Path(root_folder).mkdir(parents=True, exist_ok=True)
    session_times = {}

    num_of_prompts = sum(len(prompts) for prompts in prompt_dict.values())
    total_prompts = num_of_prompts * len(llm_configs)
    with tqdm(total=total_prompts, desc="\nRunning ChatRD validation", unit=" prompt") as pbar:
        with measure_execution(session_times, "total"):
            for idx, config in enumerate(llm_configs):
                session_config, stat_results, response_lines = _prepare_configs(
                    config, root_folder, stats_file, responses_file
                )
                tqdm.write(
                    f"\n\nStarting session {idx + 1}/{len(llm_configs)} with config LLM models: "
                    f"{session_config['main_llm']['model']} (Main) | {session_config['data_llm']['model']} (Data)"
                )
                exec_id = f"{idx}-{session_config['session_id']}"
                with measure_execution(session_times, exec_id):
                    for uc_type, prompts in prompt_dict.items():
                        CHAT = RDChatEngine()
                        try:
                            for prompt in prompts:
                                _prompt_processing(CHAT, uc_type, prompt, session_config, stat_results, response_lines)
                                pbar.update(1)
                        except Exception as e:
                            logger.error(f"Error processing prompts for {uc_type}: {e}")
                            logger.info("Continuing with the next use case type...")
                            continue
                tqdm.write(f"Session finished. It took {session_times.get(exec_id):.3f}s.\nSaving stats and results...")

                # Save stats and responses
                df = pd.DataFrame(stat_results)
                df.to_csv(session_config["stat_file"], index=False, sep=CSV_DELIMITER, encoding="utf-8")

                with open(session_config["response_file"], "w", encoding="utf-8") as f:
                    f.writelines(response_lines)

    # Show performance summary statistics
    total_time = session_times.pop("total")
    print(f"\n\nValidation completed for {len(llm_configs)} configurations.\n\nSUMMARY STATISTICS:")
    for key, value in session_times.items():
        print(f"\tSession {key}: {value:.3f}s")
    print(f"TOTAL PROCESSING TIME: {total_time:.3f}s")


def _prepare_configs(config, root_folder, stats_file, responses_file):
    """Setup session specific config and prepare output containers"""
    main_llm, data_llm = config.get("main_model"), config.get("data_service_model")
    main_llm_repr, data_llm_repr = main_llm.replace("-", "_"), data_llm.replace("-", "_")
    llm_prefix = main_llm_repr if main_llm == data_llm else f"{main_llm_repr}-{data_llm_repr}"
    session_config = {
        "session_id": llm_prefix,
        "main_llm": {"model": main_llm, "prefix": main_llm_repr},
        "data_llm": {"model": data_llm, "prefix": data_llm_repr},
        "stat_file": Path.joinpath(root_folder, f"{llm_prefix}-{stats_file}"),
        "response_file": Path.joinpath(root_folder, f"{llm_prefix}-{responses_file}"),
        "streaming": config.get("streaming", False),
    }
    stats = []
    responses = [
        "# ChatRD Engine Validator Results\n\nUsed LLM models:\n",
        f"- Main LLM (for analyzer & synthesizer): {main_llm}\n- Data LLM: {data_llm}\n{20*'='}\n",
    ]
    return session_config, stats, responses


def _prompt_processing(CHAT, uc_type, prompt, session_config, stat_results, response_lines):
    """Process each prompt with the ChatRD engine and collect results."""
    cfg_keys = ["main_llm", "data_llm", "streaming"]
    main_llm, data_llm, is_streaming = [session_config.get(cfg) for cfg in cfg_keys]
    tqdm.write(f"\tPROCESSING PROMPT: {prompt}")
    attempt = 0
    while attempt < DEFAULT_MAX_RETRY:
        metrics = {}
        with measure_execution(metrics):
            response = CHAT.chat(
                message=prompt,
                model_name_for_analyzer=main_llm.get("model"),
                temperature_for_analyzer=0.00,
                model_name_for_synthesizer=main_llm.get("model"),
                temperature_for_synthesizer=0.00,
                model_name_for_data_service=data_llm.get("model"),
                chat_history=[],
                streaming=is_streaming,
            )
        # Parse the response and handle different types
        response = _parse_response(response)
        response = "\n".join(response)

        # Save the results and stats
        response_lines.append(
            f'UC_TYPE: {uc_type}, PROMPT: {prompt}\n{"-"*20}\nRESULT: {response}\n{"-"*20}\n{"-"*20}\n'
        )
        content_length = len(response) or 0
        if content_length < 200 or ERROR_MSG_INDICATOR in response:
            attempt += 1
            tqdm.write(f"\tResponse too short, ({content_length} characters): {response}\nRetrying...")
            continue
        else:
            break
    tqdm.write(f"\tResponse: {content_length} characters\n\tDuration: {metrics.get('duration'):.3f}s")
    stat_results.append(
        {
            "uc_type": uc_type,
            "prompt": prompt,
            "llm_specifier": f"{main_llm.get('prefix')}-{data_llm.get('prefix')}",
            "content_length": content_length,
            "processing_time": metrics.get("duration"),
        }
    )


def _parse_response(response):
    """Parse the response from the chat engine and return a list of response texts."""
    result = []
    for res in response.content:
        if isinstance(res, AIMessage):
            res = res.text()
        elif res["type"] == "text":
            res = res["content"]
            if isinstance(res, BaseMessage):
                res = res.text()
            if isinstance(res, str):
                response_text = res
            elif isinstance(res, list):
                response_text = "\n".join(res)
            elif isinstance(res, types.GeneratorType):
                response_text = "".join(item.content for item in res)
            else:
                raise ValueError(f"Unsupported response content type: {type(res)}")
        elif res["type"] in ["table", "csd_table", "parentchild_table"]:
            content = res["content"]
            res_df = pd.DataFrame(content.rows if hasattr(content, "rows") else content.data)
            response_text = res_df.to_markdown(index=False)
        elif res["type"] and isinstance(res["content"], types.GeneratorType):
            response_text = res["content"]
        elif res["type"] == "suggestion":
            suggested_entities = res["content"].content
            if suggested_entities:
                response_text = suggested_entities[0].text
                for entity in suggested_entities[1].suggestions:
                    response_text += f"\n{entity.id}: {entity.name}"
        else:
            raise ValueError(f"Unsupported response type: {res['type']}")

        result.append(response_text)
    return result


def create_llm_configs(
    main_models: list[str] = [DEFAULT_LLM], data_service_models: list[str] = [DEFAULT_LLM], streaming: bool = False
):
    """Helper function to create a list of configuration dictionaries for running the validation."""
    combinations = list(product(main_models, data_service_models))

    configs = []
    for main_model, data_service_model in combinations:
        configs.append(
            {
                "main_model": main_model,  # For analyzer & synthesizer
                "data_service_model": data_service_model,
                "streaming": streaming,
            }
        )
    return configs


@contextmanager
def measure_execution(container: dict, key: str = "duration"):
    """Measure the execution time of a code block."""
    start_time = time.perf_counter()
    try:
        yield
    finally:
        end_time = time.perf_counter()
        duration = end_time - start_time
        container[key] = duration


if __name__ == "__main__":
    """Set your configuration in the following section to get a custom and quick validation of ChatRD engine.
    - The script will use the provided prompts and LLM configuration to run the validation.
    - If you want to use the default test prompts, just leave the CUSTOM_PROMPTS empty.
    - The script will save the results and stats to the specified files.
        - stats_path: Path to save the stats CSV file (prompt, round, content_length, processing_time).
        - responses_path: Path to save the LLM responses into a text file.
    - Configuration options:
        - custom_prompts: List of custom prompts to use for validation (default: predefined test_prompts).
        - llm_config: List of LLM configuration dictionaries to customize the validation.
            - main_models: List of models used for the analyzer and synthesizer.
            - data_service_models: Models to use for the data service.
        - filenames for saving the results both LLM responses and statistics.
            NOTE: final name will also include the used models, like: "<main_llm>-<data_llm>-<filename.extension>"
            Eg.: "claude_3_sonnet-claude_3_haiku-chatrd_stats.csv"

    FYI: Another script `stat_analyzer.ipynb` can be used to analyze the generated statistics
        and create performance comparison and visualization.
    """
    from chatrd.engine.app.chat_engine import \
        RDChatEngine  # Late import to ensure env vars are set before inital setup

    CUSTOM_PROMPTS = [
        # Put your custom prompts here, otherwise it will fallback to UC_TYPES
    ]
    CUSTOM_UC_TYPES = [
        # Put your use case types here, otherwise it will fallback to default UC_TYPE - prompt dict
        # e.g: UCType.GENERAL,
    ]

    # Define the LLM configuration
    llm_configs = create_llm_configs(main_models=["claude-3-haiku"], data_service_models=DATA_SERVICE_LLMS)

    # Define the filenames for saving the results
    result_txt_filename = "chatrd_responses.md"
    stat_results_filename = "chatrd_stats.csv"

    if CUSTOM_PROMPTS:
        input_prompts = {"custom": CUSTOM_PROMPTS}
    elif CUSTOM_UC_TYPES:
        input_prompts = get_prompts_for_uc_types(*CUSTOM_UC_TYPES)
    else:
        input_prompts = prompt_collection

    run_chatengine_with_prompts(
        llm_configs=llm_configs,
        prompt_dict=input_prompts,
        stats_file=stat_results_filename,
        responses_file=result_txt_filename,
        output_folder="outputs",
    )
