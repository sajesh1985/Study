from .extractor import ArticleTypeExtractor
