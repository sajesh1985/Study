import os
import asyncio
import logging
from typing import Any, Dict, Optional
from sqlalchemy.ext.asyncio import create_async_engine
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
from langgraph.store.postgres.aio import AsyncPostgresStore
from langgraph.store.memory import InMemoryStore
from langgraph.checkpoint.memory import InMemorySaver
from psycopg_pool import AsyncConnectionPool
from langchain_core.globals import set_llm_cache
from langchain_community.cache import InMemoryCache

from src.synthia.aws_utils.aws_client import get_aws_client, get_secret
from src.synthia.config.api_config import get_config
from src.synthia.utils.logging_config import configure_logging
from src.synthia.persistence.prompt_cache_config import (
    AsyncPostGreSQLCache,
    HashedLLMCache,
)

logger = configure_logging(
    log_file="synthia.log",
    module_levels={__name__: logging.DEBUG},  # Set this module to DEBUG
)

# Global connection pool - initialize once for the entire application
_connection_pool: Optional[AsyncConnectionPool] = None
_connection_pool_agent: Optional[AsyncConnectionPool] = None
_checkpointer = None
_store = None
_engine = None

cfg = get_config()
postgress_host = cfg["postgres_host"]
postgres_secrets = cfg["postgres_secrets"]


async def _get_secrets() -> Dict[str, Any]:
    """Get secrets from AWS Secrets Manager."""
    secrets_manager_client = get_aws_client("secretsmanager")
    return await asyncio.to_thread(get_secret, secrets_manager_client, postgres_secrets)


async def initialize_main_connection_pool(postgres_connection_string: str):
    """Initialize the main connection pool."""
    global _connection_pool
    if _connection_pool is None:
        connection_kwargs = {
            "autocommit": True,
            "prepare_threshold": 0,
        }
        _connection_pool = AsyncConnectionPool(
            conninfo=postgres_connection_string,
            max_size=10,
            kwargs=connection_kwargs,
            open=False,
        )
        await _connection_pool.open()


async def initialize_agent_connection_pool(postgres_connection_string: str):
    """Initialize the agent connection pool and storage components."""
    global _connection_pool_agent, _checkpointer, _store
    if _connection_pool_agent is None:
        connection_kwargs = {
            "autocommit": True,
            "prepare_threshold": 0,
        }
        _connection_pool_agent = AsyncConnectionPool(
            conninfo=postgres_connection_string + "?options=-csearch_path%3DAgent",
            max_size=10,
            kwargs=connection_kwargs,
            open=False,
        )
        await _connection_pool_agent.open()

        # Initialize global checkpointer and store
        if os.environ.get("RUNNING_LOCALLY", "false").lower() in ("true", "1", "yes"):
            _checkpointer = InMemorySaver()
            _store = InMemoryStore()
            # set_llm_db_cache(InMemoryCache()) # custom lookup not implemented hence not used in local mode
        else:
            _checkpointer = AsyncPostgresSaver(_connection_pool_agent)
            _store = AsyncPostgresStore(_connection_pool_agent)

            postgres_connection_string = postgres_connection_string.replace(
                "postgresql://", "postgresql+psycopg://"
            )
            _engine = create_async_engine(
                postgres_connection_string + "?options=-csearch_path%3DAgent",
                pool_size=10,
                max_overflow=20,
            )
            _llm_db_cache = AsyncPostGreSQLCache(
                engine=_engine, cache_schema=HashedLLMCache
            )
            await _llm_db_cache.initialize_schema()
            set_llm_db_cache(_llm_db_cache, engine_name="PostGreSQLCache")

            async with _connection_pool_agent.connection() as conn:
                await conn.execute("CREATE SCHEMA IF NOT EXISTS Agent")

            await _checkpointer.setup()
            await _store.setup()


async def initialize_connection_pool():
    """Initialize both main and agent connection pools and storage components. Call this during FastAPI startup."""
    secrets = await _get_secrets()
    username = secrets["username"]
    password = secrets["password"]

    postgres_connection_string = (
        f"postgresql://{username}:{password}@{postgress_host}/testdb"
    )
    await initialize_main_connection_pool(postgres_connection_string)
    await initialize_agent_connection_pool(postgres_connection_string)


async def close_main_connection_pool():
    """Close the main connection pool."""
    global _connection_pool

    async def close_pool_safely(pool, pool_name):
        if pool:
            try:
                await pool.close()
                # Give the pool workers a moment to shut down cleanly
                await asyncio.sleep(0.1)
            except Exception as e:
                logging.warning(f"Error closing {pool_name}: {e}")

    await close_pool_safely(_connection_pool, "main connection pool")
    _connection_pool = None


async def close_agent_connection_pool():
    """Close the agent connection pool and cleanup storage."""
    global _connection_pool_agent, _checkpointer, _store

    # Cleanup global storage components
    _checkpointer = None
    _store = None

    async def close_pool_safely(pool, pool_name):
        if pool:
            try:
                await pool.close()
                # Give the pool workers a moment to shut down cleanly
                await asyncio.sleep(0.1)
            except Exception as e:
                logging.warning(f"Error closing {pool_name}: {e}")

    await close_pool_safely(_connection_pool_agent, "agent connection pool")
    _connection_pool_agent = None


async def close_engine():
    """Close the engine connection."""
    global _engine
    if _engine:
        try:
            await _engine.dispose()  # Dispose the engine safely
            await asyncio.sleep(0.1)
        except Exception as e:
            logging.warning(f"Error closing engine: {e}")
    _engine = None


async def close_connection_pool():
    """Close both main and agent connection pools and cleanup storage. Call this during FastAPI shutdown."""
    await close_main_connection_pool()
    await close_agent_connection_pool()
    await close_engine()


def get_connection_pool() -> Optional[AsyncConnectionPool]:
    """Get the global connection pool."""
    return _connection_pool


def get_connection_pool_agent() -> Optional[AsyncConnectionPool]:
    """Get the global connection pool for agent."""
    return _connection_pool_agent


def get_checkpointer():
    """Get the global checkpointer instance."""
    return _checkpointer


def get_store():
    """Get the global store instance."""
    return _store


def set_llm_db_cache(cache, engine_name: str = "in_memory_store") -> None:
    """
    Set the langchain global LLM cache compatible
    with the langchain model classes using the recommender
    setter func.

    Args:
        cache: The cache instance to set
        engine_name: Name of the cache engine for logging
    Returns:
        None
    """

    if os.getenv("ENABLE_CACHE", "false").lower() in ("true", "1", "yes"):
        logger.info(f"Enabling Global LLM cache with {engine_name}")
        set_llm_cache(cache)
    else:
        logger.info("Global LLM cache is disabled")
