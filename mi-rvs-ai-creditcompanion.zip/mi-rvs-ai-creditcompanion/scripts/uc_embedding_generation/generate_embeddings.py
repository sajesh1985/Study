"""
This file generate the embeddings after generating questions from templates (chatrd/components/query_analyzer/uc_router/generation/generate_questions.py)
"""

import json
import logging
import os

import numpy as np
from tqdm.auto import tqdm

from chatrd.core.embedding import embedding_factory

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

logger = logging.getLogger(__name__)

model = embedding_factory("cohere-multi")

if os.path.exists("scripts/uc_embedding_generation/questions.json"):
    print("Loading Questions....")
    with open("scripts/uc_embedding_generation/questions.json", "r") as json_file:
        questions = json.load(json_file)
    flattened_list = [item for sublist in questions.values() for item in sublist]
    logger.info(f"Loaded Questions : {len(flattened_list)}")
else:
    raise Exception("No file exists for loading questions.")


def get_embeddings(texts):
    embeddings = []
    for text in tqdm(texts):
        response = model.embed_query(text)
        embeddings.append(response)
    return np.array(embeddings)


embeddings_type_dict = {}
embeddings = {}

for question_type in list(questions):
    logger.info(f"Generating embeddings for {question_type}.")
    class_embeddings = get_embeddings(questions[question_type])
    embeddings[question_type] = list(class_embeddings)
    embeddings_type_dict[question_type] = list(np.mean(class_embeddings, axis=0))

np.savez("chatrd/engine/data/use_case_embeddings.npz", **embeddings_type_dict)
np.savez("chatrd/engine/data/question_embeddings.npz", **embeddings)
