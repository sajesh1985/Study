import os

from boto3 import Session
from botocore.credentials import RefreshableCredentials
from botocore.session import get_session

session_cache = {}


def assumed_session(role_arn, session_name, region_name):
    # For local run skip configuring session and return a basic session with credentials from local ~/.aws/credentials
    if os.getenv("LOCAL_RUN", "false").lower() == "true":
        return Session()

    cache_key = f"{role_arn}:{session_name}:{region_name}"

    if cache_key in session_cache:
        return session_cache[cache_key]

    # Force create a session in the target region
    base_session = Session(region_name=region_name)

    def refresh():
        # Use STS in the same region as the Bedrock client you will use
        credentials = base_session.client("sts", region_name=region_name).assume_role(
            RoleArn=role_arn, RoleSessionName=session_name
        )["Credentials"]
        return {
            "access_key": credentials["AccessKeyId"],
            "secret_key": credentials["SecretAccessKey"],
            "token": credentials["SessionToken"],
            "expiry_time": credentials["Expiration"].isoformat(),
        }

    session_credentials = RefreshableCredentials.create_from_metadata(
        metadata=refresh(), refresh_using=refresh, method="sts-assume-role"
    )

    botocore_sess = get_session()
    botocore_sess._credentials = session_credentials
    botocore_sess.set_config_variable("region", region_name)

    new_session = Session(botocore_session=botocore_sess, region_name=region_name)
    session_cache[cache_key] = new_session
    return new_session
