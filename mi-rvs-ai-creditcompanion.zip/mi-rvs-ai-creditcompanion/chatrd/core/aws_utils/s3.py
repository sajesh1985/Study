import io
import json
from typing import Dict

import pandas as pd

from chatrd.engine.configuration import Constants, get_config_machinery

config_machinery = get_config_machinery()

from chatrd.core.aws_utils.common import assumed_session

region_name = config_machinery.get_config_value(Constants.Bedrock.BEDROCK_REGION_NAME)
# Cache for S3 clients by role_arn
_s3_client_cache: Dict[str, object] = {}


def get_cached_s3_client(role_arn: str):
    if role_arn not in _s3_client_cache:
        session = assumed_session(
            role_arn=role_arn,
            session_name="AssumeRoleSession-" + region_name,
            region_name=region_name,
        )
        _s3_client_cache[role_arn] = session.client("s3")
    return _s3_client_cache[role_arn]


def load_data_from_s3(s3_uri: str, role_arn: str):
    # Reuse cached S3 client
    s3 = get_cached_s3_client(role_arn)

    # Parse S3 URI
    bucket_name, key = parse_s3_uri(s3_uri)

    # Download file from S3
    data = s3.get_object(Bucket=bucket_name, Key=key)["Body"].read()

    # Read data based on content type
    if "json" in key:
        return json.loads(data.decode("utf-8"))

    elif "parquet" in key:
        return pd.read_parquet(io.BytesIO(data))

    else:
        return io.BytesIO(data)


def parse_s3_uri(s3_uri):
    parts = s3_uri.replace("s3://", "").split("/", 1)
    return parts[0], parts[1]
