// import { ChatRDProvider } from '../../context/chatrd';
// import { App } from '../../components/chatrd/chatrd';
// import { addLocaleResourceBundle } from '../../utils/localeManager';
// import { useFlag } from '@spglobal/featureflags';
// import { Checkbox, FilterBox, FilterColumn, FilterGroup, FilterRow, FilterSubGroup, FormGroup, InputField, useFilterBoxContext, IOption, Select, FilterBoxProvider, FilterBar } from '@spglobal/react-components';
import { IOption, Select } from '@spglobal/koi-select';
// import { Alignment } from '@spglobal/koi-helpers';
import { Size } from '@spglobal/koi-helpers';
import { DateRange } from '@spglobal/koi-datepicker';
import { FilterBar, FormGroup, InputField,   useFilterBoxContext,Button, DropDown, DropDownGroup, DropDownItem,Icon, IconSize, NotificationType,Tooltip, TooltipText, useNotification} from '@spglobal/react-components';


import { ColumnCheckboxSelector } from './ColumnCheckboxSelector';
//import { Button, DropDown, DropDownGroup, DropDownItem, FilterBar, Icon, IconSize, NotificationType, Tooltip, TooltipText,  useNotification } from '@spglobal/react-components';
// import FeedBackGrid from './FeedbackGrid';
import KoiFeedBackGrid from './KoiFeedbackGrid';
import { FeedbackPagination } from './FeedbackPagination';
import ShowFeedbackTime from '../../_common/ShowFeedbackTime/ShowFeedbackTime';
import React, { useState, useEffect, SetStateAction } from 'react';
//import Worker from '../../../workers/export-worker.worker.js';

import { makeDashboardApiRequest } from '../../../services/api';
import { fromFeedbackToGrid, ServerResponseType, TransformedResponseType } from './helpers';

//import { IOption } from '@spglobal/koi-select';
import { useUserTraits } from '@spglobal/userprofileservice';


//   import { config } from '@spglobal/spa';
//   import { useUserTraits } from '@spglobal/userprofileservice';

import {
  koiColumnDefs,
  chooseDefaultValues
} from './koiGridData.model';

import {
  selectFiltersConfig,
  dateRange,
  defaultSelectFiltersOptions,
  defaultSelectFiltersConfig,
  defaConfig
} from './ColumnCheckboxSelector.model';


import { faInfoCircle } from '@fortawesome/free-solid-svg-icons';

interface iPayload {
  startDate?: string | '' | undefined;
  endDate?: string | '' | undefined;
  feedback_sentiment?: 'positive' | 'negative' | '' | undefined;
  text_feedback?: string | '' | undefined;
  tags?: 'completeness' | 'accuracy' | '' | undefined;
  test?: any
}

const LandingPageDashboard: React.FC = () => {
  const userInformation = useUserTraits(['culture', 'mSTimeZoneID']);
  const { addNotification } = useNotification() || {};
  const [isExportStarted,setExportStarted] = useState(false);

  const [stateResponse, setStateResponse] = useState<TransformedResponseType[]>([]);
  const [rowDataForGrid, setRowDataForGrid] = useState<TransformedResponseType[]>([]);

  const [columnDefs, setColumnDefs] = useState(chooseDefaultValues);

  const [payload, setPayload] = useState<iPayload>({});

  const [rangeValues, setRangeValues] = useState(dateRange)
  const [savedRangeValues, setSavedRangeValues] = useState(dateRange)

  const [isLoading, setIsLoading] = useState(null);

  const [pageNumber, setPageNumber] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(20);

  const [timeUpdated, setTimeUpdated] = useState<Date | null>(null);

  //const [worker, setWorker] = useState(null);
  //const [isExporting, setIsExporting] = useState(false);

  // Create the Web Worker
  /*useEffect(() => {
    const workerInstance = new Worker();
    setWorker(workerInstance);

    // Handle worker messages
    workerInstance.onmessage = (e: MessageEvent) => {
      const { success, data } = e.data;
      if (success) {
        handleExcelDownload(data);  // Trigger the download if export is successful
      }
      setIsExporting(false);  // Reset the exporting state
    };

    // Cleanup worker on component unmount
    return () => {
      workerInstance.terminate();
    };
  }, []);*/

  // Handle export trigger
  /*const startExport = () => {
    if (!worker || isExporting) return;

    setIsExporting(true);  // Set exporting flag
    
    // Send the data to the Web Worker
    //worker.postMessage({ gridApi: gridApi, allRecords: JSON.parse(JSON.stringify(stateResponse)) });
    worker.postMessage({ gridApi: 'Saj' });
  };

  // Function to handle the Excel download
  const handleExcelDownload = (excelData: ArrayBuffer) => {
    const blob = new Blob([excelData], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'export.xlsx';  // Specify the file name
    link.click();
  };*/


  const handleColumnCheckboxSelectorChange = (values: IOption[]) => {
    const chekedKoiColumnDefs = koiColumnDefs.filter((el) =>
      values.some((item) => item.value === el.field)
    );
    setColumnDefs(chekedKoiColumnDefs);
  };

  const [gridApi, setGridApi] = React.useState(null);
  const onGridReady = (params: any) => {
    setGridApi(params.api);
  };


  useEffect(() => {

    if (payload?.test){
      console.log('request trigger', payload?.test)
    }

    const myPayload:iPayload = {};

    if (String(dateRange[0])){ myPayload.startDate = new Date(savedRangeValues[0]).toISOString() }
    if (String(dateRange[1])){ myPayload.endDate = new Date(savedRangeValues[1]).toISOString() }

    if (getFilter('filter2')?.[0]?.value){ 
      myPayload.feedback_sentiment = getFilter('filter2')?.[0]?.value 
    }
    if (getFilter('filter3')?.[0]?.value){ 
      myPayload.tags = getFilter('filter3')?.[0]?.value
    }
    if (getFilter('userInput')?.[0]){ 
      myPayload.text_feedback = getFilter('userInput')
    }

    setIsLoading(true);

    const loadData = async () => {
      try {
        let response: ServerResponseType[] | null = null;

        response = await makeDashboardApiRequest(myPayload);
        const mappedDataResponce = fromFeedbackToGrid(response, userInformation);

        setStateResponse(mappedDataResponce);
        /*gridApi.setDatasource({
          getRows: (params:any) => {
            params.successCallback(stateResponse, stateResponse.length);
          }});*/
        
        setIsLoading(false);
        setTimeUpdated(new Date());
        } catch (error) {
        console.error('Fetch error', error);
        setStateResponse([]);
        setTimeUpdated(null);
      } finally {
        setIsLoading(false);
        console.log('Fetch finally', stateResponse);
      }
    };

    const timerId = setTimeout(loadData, 100);

    return () => {
      clearTimeout(timerId);
      if (isLoading) setIsLoading(false);
    };
  }, [payload]);

  useEffect(() => {
    const startIndex = (pageNumber - 1) * pageSize;
    const endIndex = startIndex + pageSize;

    const rowDataDependsOfPage = stateResponse.slice(startIndex, endIndex);

    setRowDataForGrid(rowDataDependsOfPage);
  }, [stateResponse, pageNumber, pageSize]);

  // -------------- Pagination logic------------

  const onChangePage = (value: SetStateAction<number>) => {
    console.log('PageNumber:', value);
    setPageNumber(value);
  };

  const onChangePageSize = (value: SetStateAction<number>) => {
    console.log('PageSize:', value);
    setPageSize(value);
  };

  const {
    addDefaultFilters,
    updateFilters,
    getFilter
  } = useFilterBoxContext();

  React.useEffect(() => {
    addDefaultFilters({
      ...defaultSelectFiltersConfig, 
      userInput: defaConfig.userInput
    })
  }, []);

  const selectOnChange = (key: string) => {
    return (values: IOption[]) => {
      updateFilters(key, values);
      if (key === "filter1") handleColumnCheckboxSelectorChange(values)
    };
  };

  const onRestoreDefaults = () => {
    addDefaultFilters({
      ...defaultSelectFiltersConfig, 
      userInput: defaConfig.userInput
    })
    handleColumnCheckboxSelectorChange(defaultSelectFiltersOptions.filter1);
    setColumnDefs(chooseDefaultValues);

    setRangeValues(dateRange);
    setPayload({test: "onRestoreDefaults"})
  }

  const inputChangeHandler = (e: React.ChangeEvent<HTMLInputElement>): void => {
    updateFilters('userInput', e.target.value);
  };
  
  const handlerChangeRangeValue = (e:any)=>{
    setSavedRangeValues(e);
  }

  const handleOnApplyButton = ()=>{

    setRangeValues(savedRangeValues)
    setPayload({ test: "handleOnApplyButton" })
  }
  
   const exlExport = () => {
    //startExport();
    //addNotification("Export started: may take more than 2 mins", NotificationType.INFO);
    //const rec = stateResponse.slice(0,2000);
    //gridApi.applyTransaction({add:rec});
    //gridApi.updateRowData({add: rec});
    setTimeout(() => {
      const rec = stateResponse.slice(0,2000);
      gridApi.setRowData(rec);
      gridApi.exportDataAsExcel({allColumns: true,allRows: true,rowData: rec,fileName: "User feedback_" + new Date(savedRangeValues[0]).toLocaleDateString() + "-" + new Date(savedRangeValues[1]).toLocaleDateString() + ".xlsx"});
      addNotification("Export completed", NotificationType.SUCCESS);
      gridApi.setRowData(rowDataForGrid);
      setExportStarted(false);
    },500);
   
    //gridApi.updateRowData({add: rowDataForGrid});
    
   
  };

  useEffect(() => {
      isExportStarted && exlExport();
  }, [isExportStarted]);



  const csvExport = () => {
    //addNotification("Export started: may take more than 2 mins", NotificationType.INFO);
    setTimeout(() => {
    const rec = stateResponse.slice(0,2000);
    gridApi.setRowData(rec);
    gridApi.exportDataAsCsv({allColumns: true,processHeaderCallback:function processHeaderCSV(params:any){ 
      return `<b>${params.column.getColDef().headerName}</b>`;
    },allRows: true,rowData: rec,fileName: "User feedback_" + new Date(savedRangeValues[0]).toLocaleDateString() + "-" + new Date(savedRangeValues[1]).toLocaleDateString() + ".csv"});
    addNotification("Export completed", NotificationType.SUCCESS);
    gridApi.setRowData(rowDataForGrid);
    },500);
  };

  

  const triggerDropdown = (
    <Button purpose="secondary">
      Export
    </Button>
  );


  return (
    <>
        <FilterBar
          instantFilters={
              <ColumnCheckboxSelector
                selectOnChange={selectOnChange}
                getFilter={getFilter}
              />
          }
          hasRestoreDefaults={true}
          onRestoreDefaults={onRestoreDefaults}
          onApplyFilters={handleOnApplyButton}
          moreFilters ={
            <>
            <FormGroup
              alignment="right"
              isInline
              label="User input Value "
            >
              <InputField
                componentSize={Size.MEDIUM}
                inFieldLabel=""
                maxLength={30}
                placeholder="Search text"
                skeletonConfig={{
                  animation: true,
                  loading: false
                }}
                type="text"
                value={getFilter('userInput')} 
                onChange={inputChangeHandler}
              />
  
            </FormGroup>
            <FormGroup isInline 
              label="Fedback sentiment" 
              alignment="right"
            >
              <Select
                isMulti={false}
                isSearchable={false}
                options={selectFiltersConfig.filter2.value}
                onChange={selectOnChange('filter2')}
                values={getFilter('filter2')} 
                />
            </FormGroup>
            <FormGroup isInline 
              label="Fedback tags" 
              alignment="right"
            >
              <Select
                isMulti={false}
                isSearchable={false}
                options={selectFiltersConfig.filter3.value}
                onChange={selectOnChange('filter3')}
                values={getFilter('filter3')} 
                />
            </FormGroup>
            <FormGroup isInline 
              label="Date range" 
              alignment="right"
            >
              <DateRange 
                leftInputPlaceholder={'Start date'}
                rightInputPlaceholder={'End date'}
                defaultValues={ rangeValues }
                values={rangeValues}
                onChangeRangeValue={handlerChangeRangeValue}
              />
            </FormGroup>
            </>
          }
        /> 
      <div style={{ display: 'flex', justifyContent: 'right', fontSize: '11px',paddingBottom:'4px' }}>
      <DropDown triggerElement={triggerDropdown}>
        <DropDownGroup>
          <DropDownItem>
            <Button onClick={() => {addNotification("Export started: may take more than 2 mins", NotificationType.INFO);setExportStarted(true);}}>
              Export to Excel
            </Button>
          </DropDownItem>
          <DropDownItem>
            <Button onClick={() =>{ addNotification("Export started: may take more than 2 mins", NotificationType.INFO); csvExport();}}>
              Export to CSV
            </Button>
          </DropDownItem>
        </DropDownGroup>
      </DropDown>
      <Tooltip
            canEnterKeyOpen
            triggerElement={<Icon style={{padding:'5px',scale:'2'}} icon={faInfoCircle} size={IconSize.XXXSMALL} />}
          >
        <TooltipText>
          Excel/CSV exports are limited to 2,000 records
        </TooltipText>
        </Tooltip>
      </div>
      <ShowFeedbackTime date={timeUpdated} />
      <KoiFeedBackGrid row_data={rowDataForGrid} column_defs={columnDefs} onGridReady={onGridReady} />

      <FeedbackPagination
        totalItems={stateResponse.length}
        onChange={onChangePage}
        onChangePageSize={onChangePageSize}
        defaultPageSize={20}
      />
      </>
  );
};

export default LandingPageDashboard;
