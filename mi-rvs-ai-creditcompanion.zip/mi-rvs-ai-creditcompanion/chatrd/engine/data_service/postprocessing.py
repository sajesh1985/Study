"""This module modifies output of screener API to get human friendly display of data."""

import logging
import re
from datetime import datetime
from typing import List, Tuple, Union

import pandas as pd

from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.data_service.model_output_parser.variables import (
    GLOBAL_CREDIT_RATING_MAPPING,
)
from chatrd.engine.data_service.retriever.utils import process_date_str

config_machinery = get_config_machinery()

logger = logging.getLogger(__name__)

CWOL_MAPPING = config_machinery.get_config_value(Constants.DataService.CWOL_MAPPING)


def transform_servicer_outlook_field(row: List[List[str]]) -> str:
    """
    Transform values of 'SERVICER EVALUATIONS RANKING WATCH/OUTLOOK' field.

    Parameters:
    - row (List[List[str]]):  Nested list containing cell's data: id, outlook, date_raw, operation_type, country

    Returns:
    - str: Transformed string containing data in the format similar to CapIQ UI.
    """
    output = []
    for _, outlook, date_raw, operation_type, country in row:
        operation_item = (
            f"{outlook} ({process_date_str(date_raw)}) | Operation Type: {operation_type} | Country Name:{country}"
        )
        output.append(operation_item)
    output = "\n".join(output)
    return output


def transform_servicer_ranking_field(row: List[List[str]]) -> str:
    """
    Transform values of 'SERVICER EVALUATIONS RANKING' field.

    Parameters:
    - row (List[List[str]]): Nested list containing cell's data: id, status, operation_type, country, date_raw.

    Returns:
    - str: Transformed string containing data in the format similar to CapIQ UI.
    """
    output = []
    for _, status, operation_type, country, date_raw in row:
        operation_item = (
            f"{status} ({process_date_str(date_raw)}) | Operation Type: {operation_type} | Country Name:{country}"
        )
        output.append(operation_item)
    output = "\n".join(output)
    return output


def transform_rating_action_field(row: Union[str, List[str]]) -> str:
    """
    Transform values of 'S&P CREDIT RATING ACTION' field.

    Parameters:
    - row (List[List[str]]):  Nested list containing cell's data: id, status, date_raw

    Returns:
    - str: Transformed string containing data in the format similar to CapIQ UI.
    """
    output = []
    if isinstance(row, str):
        return row
    elif isinstance(row, list):
        for _, status, date_raw in row:
            operation_item = f"{status} ({process_date_str(date_raw)})"
            output.append(operation_item)
            output = "\n".join(output)
        return output


def get_date_string(timestamp: str) -> str:
    """
    Converts a timestamp string to a date string in MM/DD/YYYY format.

    The timestamp string is expected to be in the format `/Date(<milliseconds>-<offset>)/`.
    The function extracts the milliseconds part, converts it to seconds, and then formats
    it into MM/DD/YYYY.

    Args:
        timestamp (Optional[str]): The timestamp string to convert.
                                    It should be in the format `/Date(<milliseconds>-<offset>)/`.

    Returns:
        str: The formatted date string in MM/DD/YYYY format. Returns an empty string if input is invalid.
    """
    try:
        if timestamp:
            timestamp = timestamp.replace("/Date(", "").replace(")/", "").split("-")[0]
            dt = datetime.fromtimestamp(int(timestamp) / 1000)
            return dt.strftime(" (%m/%d/%Y)")
        return ""
    except Exception as e:
        logger.info(f"Error in get_date_string with timestamp {timestamp}: {e}")
        return ""


def readable_rating_action(items: List[Tuple[str, str, str]]) -> str:
    """
    Formats a list of items into a semicolon-separated string with each item formatted
    as 'rating action (date)' where 'Date' is derived from the timestamp.

    Each item in the list is expected to be a tuple of three strings:
    (identifier, rating action, timestamp). The function formats the date using `get_date_string()`.

    Args:
        items (List[List[str, str, str]]): A list of tuples, where each tuple contains
                                            an identifier, a rating action, and a timestamp string.

    Returns:
        str: A semicolon-separated string where each entry is formatted as 'rating action (date)'.
    """
    if not items or not isinstance(items, list):
        return ""

    rating_actions = []
    for item in items:
        if isinstance(item, (list, tuple)) and len(item) == 3:
            _, action, timestamp = item
            try:
                formatted_action = action + get_date_string(timestamp)
                rating_actions.append(formatted_action)
            except Exception:
                continue  # Skip invalid entries
    return "; ".join(rating_actions)


def postprocess_table_for_query(df: pd.DataFrame) -> pd.DataFrame:
    """
    Postprocess the table, arranging the columns and sorting the rows for uc_type == query

    Args:
        df (DataFrame): The input DataFrame to be processed.

    Returns:
        DataFrame: The processed DataFrame.
    """
    ordered_columns = df.columns

    # Define the columns to check for sorting
    patterns = [
        "S&P CREDIT RATING (ISSUER CREDIT RATING / FOREIGN CURRENCY LT)",
        "S&P CREDIT RATING (FSR) (FINANCIAL STRENGTH RATING / FOREIGN CURRENCY LT)",
    ]

    # Sort by the appropriate credit rating column if available
    column_to_sort = None
    for col in df.columns:
        if any(col.startswith(pattern) for pattern in patterns):
            column_to_sort = col
            break

    if column_to_sort:
        df_sorter = (
            pd.DataFrame([x.upper() for x in GLOBAL_CREDIT_RATING_MAPPING])
            .reset_index()
            .rename(
                columns={
                    "index": "sortOrder",
                    0: column_to_sort,
                }
            )
        )
        df = df.merge(df_sorter, on=column_to_sort, how="left")
        df = df.sort_values(["sortOrder"]).reset_index(drop=True)
        del df["sortOrder"]
    ra_columns = [x for x in ordered_columns if "S&P CREDIT RATING ACTION" in x]
    for col in ra_columns:
        if "S&P CREDIT RATING ACTION DATE" in col:
            df[col] = df[col].map(get_date_string).str.replace(r"[()]", "", regex=True)
        else:
            df[col] = df[col].map(readable_rating_action)
    return df


def postprocess_cells_view(key_perspective: int, env: str, df: pd.DataFrame) -> pd.DataFrame:
    """
    Postprocess the cells(fix dates and other) in the DataFrame based on columns' names and the given key_perspective.

    Args:
        key_perspective (int): The key perspective identifier.
        df (DataFrame): The input DataFrame to be processed.
        env (str): The environment of the database to get data.

    Returns:
        DataFrame: The processed DataFrame.
    """
    for col in ["MI INDUSTRY CLASSIFICATION", "S&P GLOBAL RATINGS SECTORS"]:
        if col in df.columns and df[col].apply(lambda x: isinstance(x, list)).all():
            df[col] = df[col].apply(
                lambda nested_list: "; ".join(
                    item[1] for item in nested_list if isinstance(item, list) and len(item) > 1
                )
            )

    if "SERVICER EVALUATIONS RANKING WATCH/OUTLOOK" in df.columns:
        df["SERVICER EVALUATIONS RANKING WATCH/OUTLOOK"] = df["SERVICER EVALUATIONS RANKING WATCH/OUTLOOK"].apply(
            transform_servicer_outlook_field
        )

    if "SERVICER EVALUATIONS RANKING" in df.columns:
        df["SERVICER EVALUATIONS RANKING"] = df["SERVICER EVALUATIONS RANKING"].apply(transform_servicer_ranking_field)

    if "S&P CREDIT RATING ACTION" in df.columns:
        df["S&P CREDIT RATING ACTION"] = df["S&P CREDIT RATING ACTION"].apply(transform_rating_action_field)

    if "S&P CREDITWATCH/OUTLOOK" in df.columns:
        df["S&P CREDITWATCH"] = None
        df["S&P OUTLOOK"] = None
        for k in CWOL_MAPPING.keys():
            col_name = "S&P " + CWOL_MAPPING[k].upper()
            df.loc[df["S&P CREDITWATCH/OUTLOOK"].str.lower() == k, col_name] = k.upper()
        if df["S&P CREDITWATCH/OUTLOOK"].str.contains("NM").any():
            logger.info("No values for NM in 'S&P CREDITWATCH/OUTLOOK' columns")
        else:
            df.drop(columns=["S&P CREDITWATCH/OUTLOOK"], inplace=True)

        for col in ["S&P CREDITWATCH", "S&P OUTLOOK"]:
            if df[col].isnull().sum() == df.shape[0]:
                df.drop(columns=[col], inplace=True)
    else:
        logger.info("postprocess_cells_view skipped")

    return df
