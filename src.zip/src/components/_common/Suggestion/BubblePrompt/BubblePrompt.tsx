import { BubblePromptContainer } from './BubblePrompt.styles';

interface BubblePromptProps {
  text: string;
  onClick: () => void;
}

const BubblePrompt: React.FC<BubblePromptProps> = ({ text, onClick }) => {
  return (
      <BubblePromptContainer onClick={onClick}>
          {text}
      </BubblePromptContainer>
  );
};

export default BubblePrompt;
