#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Copyright (C) S&P Global. All Rights Reserved.
NOTICE: All information contained herein is, and remains the  property of S&P Global and its suppliers,
if any. The intellectual and technical concepts contained herein are  proprietary to S&P Global and its suppliers and
may be covered by U.S. and Foreign Patents, patents in process,  and are protected by trade secret or copyright law.
Dissemination of this information or reproduction of this  material is strictly forbidden unless prior written
permission is obtained from S&P Global.
"""
import argparse
import json
import os
import random
import re
from copy import copy
from string import Template
from typing import List

import pandas as pd
from dotenv import load_dotenv

# from llama_index.llms import AzureOpenAI
from langchain.prompts import PromptTemplate
from langchain_openai import AzureChatOpenAI

load_dotenv()


openai_api_type = os.getenv("OPENAI_API_TYPE")
openai_api_version = os.getenv("OPENAI_API_VERSION")
azure_openai_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
open_api_key = os.getenv("OPENAI_API_KEY")

GPT_4 = AzureChatOpenAI(deployment_name="gpt-4-turbo", temperature=0.1)
CHAT_GPT = AzureChatOpenAI(deployment_name="gpt-35-turbo-v0613", temperature=0.1)
# CHAT_GPT = AzureChatOpenAI(deployment_name="gpt-35-turbo-v0613", temperature=0.1)


SINGLE_PROMPTS = [
    Template("What was the latest credit rating for issuer $issuer_name, and how does it compare to its peers?"),
    Template("What is the credit health of $issuer_name issuer?"),
    Template("What are the financial trends of $issuer_name issuer?"),
    Template("What was the latest Rating and credit watch outlook for issuer, $issuer_name?"),
    Template(
        "What are the micro (intracompany) or macro (external to company) factors contributing to a $issuer_name credit health or credit worthiness?"
    ),
    Template("What is $issuer_name credit health relative to my peers?"),
    Template("What are the projects for $issuer_name municipality?"),
    Template("What is the latest SWOT analysis of $issuer_name?"),
    Template("What are $issuer_name's triggers for a downgrade?"),
    Template("What are $issuer_name's strengths and challenges versus its peers?"),
]

CRITERIA_PROMPTS = [
    Template("Explain business risk for $instrument_name"),
    Template("Summarise the methodology to rate a $instrument_name"),
    Template("What are the main factors that influence the credit ratings of $instrument_name?"),
]

GEN_PROMPT = PromptTemplate.from_template(
    """
Task Description:

Input: You are provided with a document and a question pattern.

Output: Your task is to generate two components: a fixed question related to the document and an answer to that 
question. However, you should only return both outputs if the document contains the relevant answer, otherwise return 
NOPE. 

In summary, your algorithm should extract pertinent information from the document, formulate a question, identify the 
corresponding answer as a citation from original document, and provide both if the answer is found within the 
document. Input document: {document} Question pattern: {question} Fixed question: """
)

REPHRASE_PROMPT = PromptTemplate.from_template(
    """
Task Description:

Input: You are provided with a question.

Output: Your task is to rephrase question keeping same meaning.

Input question:
{question}
Rephrased question:
"""
)

parser = argparse.ArgumentParser()
parser.add_argument(
    "--input-file-path",
    required=True,
    type=str,
    help="the input file which contains chunked article" " data in parquet format",
)
parser.add_argument(
    "--n-samples",
    required=True,
    type=int,
    default=None,
    help="number of samples needed for testing",
)
parser.add_argument(
    "--output-file-path",
    required=True,
    type=str,
    help="the output json file containing question and answers",
)

parser.add_argument(
    "--article-type",
    required=True,
    type=str,
    choices=["research", "criteria"],
    help="types of articles to be used for test case generation," " it can either be research or criteria",
)

args = parser.parse_args()
n_samples = args.n_samples
input_file_path = args.input_file_path
output_file_path = args.output_file_path
article_type = args.article_type


def extract_question_answer(text):
    question_pattern = r"(.+)\nAnswer:"
    answer_pattern = r"Answer:(.+)"

    question_match = re.search(question_pattern, text, re.DOTALL)
    answer_match = re.search(answer_pattern, text, re.DOTALL)

    if question_match and answer_match:
        question = question_match.group(1).strip()
        answer = answer_match.group(1).strip()
    else:
        return None

    return question, answer


def generate_test_dataset(dataset: pd.DataFrame, size_of_dataset: n_samples) -> List[dict]:
    test_dataset = []
    prompts = []
    documents_list = list(dataset["text"].values)

    for _ in range(size_of_dataset):
        if article_type == "research":
            random_question_idx = random.randint(0, len(SINGLE_PROMPTS) - 1)
            prompts = SINGLE_PROMPTS
            print(prompts)
        elif article_type == "criteria":
            random_question_idx = random.randint(0, len(CRITERIA_PROMPTS) - 1)
            prompts = CRITERIA_PROMPTS
            print(prompts)

        random_doc_idx = random.randint(0, len(documents_list) - 1)

        try:
            response = GPT_4.complete(
                GEN_PROMPT.format(
                    document=documents_list[random_doc_idx],
                    question=prompts[random_question_idx].substitute(issuer_name="XYZ"),
                )
            )

            print(response)
            question_answer = extract_question_answer(response.text)
            if question_answer:
                question, answer = question_answer
                test_dataset.append(
                    {
                        "document_id": random_doc_idx,
                        "question": question,
                        "answer": answer,
                    }
                )
        except:
            print("Q/A could not be printed for this chunk!")

    return test_dataset


def filter_dataset(test_dataset: List[dict]) -> List[dict]:
    filtered_lst = []
    for item in test_dataset:
        if item["answer"] == "NOPE" or "The document does not provide" in item["answer"]:
            ...
        else:
            filtered_lst.append(item)
    return filtered_lst


def augment_dataset(test_dataset: List[dict]) -> List[dict]:
    augmented_lst = []

    for item in test_dataset:
        response = CHAT_GPT.complete(REPHRASE_PROMPT.format(question=item["question"]))
        temp = copy(item)
        temp["question"] = response.text
        augmented_lst.append(item)
        augmented_lst.append(temp)

    return augmented_lst


def run_generation(dataset_path=input_file_path, output_file=output_file_path):
    """
    Generate a JSON output file containing question, document_id which answer this question and
    answer. Right now function supports only single entity questions.

    This function takes a dataset in parquet format, processes it, and generates a JSON output file
    containing the processed data.

    Parameters:
    - dataset_path (str): The path to the chunked parquet file

    - output_file (str): The path to the JSON file where the generated data will be saved.

    Returns:
    None

    Example:
    >>> run_generation(dataset_path="my_data.parquet", output_file="output.json")

    Note:
    - Ensure that the dataset is in parquet format and has the required structure for processing.
    - Make sure that the output file's path is writable and that the directories exist.

    """
    dataset = pd.read_parquet(dataset_path)
    print("data_loading")
    print("len of data {}".format(len(dataset)))
    test_dataset = generate_test_dataset(dataset, n_samples)
    print("generating test data")
    test_dataset = filter_dataset(test_dataset)

    for item in test_dataset:
        item["document_id"] = int(dataset.iloc[item["document_id"]]["ARTICLE_ID"])

    with open(output_file, "w") as json_file:
        json.dump(test_dataset, json_file)


if __name__ == "__main__":
    run_generation()
