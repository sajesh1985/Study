import os

ENV = os.getenv("SYNTHIA_ENV", "dev").lower()

CONFIG = {
    "dev": {
        "capitaliq_base_url": "https://www.capitaliqdev.spglobal.com/apisv3/spg-ratingsresearch-service/api/v3/",
        "omni_suggest_base_url": "https://www.capitaliqdev.spglobal.com/apisv3/search-service/v3/OmniSuggest/suggest",
        "opensearch_url": "https://vpc-mi-crs-chatrd-dev-4bzv6hif6zsyfsw6uhelm2s5ti.us-east-1.es.amazonaws.com",
        "news_article_url": "https://www.capitaliqdev.spglobal.com/apisv3/spg-webplatform-core/news/article?id=",
        "capitaliq_graphql_url": "https://www.capitaliqdev.spglobal.com/apisv3/federation/",
        "opensearch_research_index": "embedding-job-chatrd-research-dev-new",
        "opensearch_commentary_index": "embedding-job-chatrd-commentary-dev-new",
        "opensearch_criteria_index": "embedding-job-chatrd-criteria-dev-new",
        "neural_search_model_id": "NW8Gzo4B4hj467SORj0Z",
        "search_pipeline_name": "cohere-multilingual-search-pipeline",
        "reranker_endpoint_name": "mi-crs-chatrd-dev-ms-marco-cross-encoder-endpoint",
        "dataapi_url": "https://www.capitaliqdev.spglobal.com/apisv3/dataapi-service/",
        "capitaliq_base_inherit_auth_url": "https://www.capitaliqdev.spglobal.com/web/client?auth=inherit",
        "oauth_security_service_url": "https://www.capitaliqdev.spglobal.com/apisv3/security-service/oauth/",
        "ratings_article_base_url": "https://www.capitaliqdev.spglobal.com/web/login",
        "opensearch_username_key": "dev/synthia/opensearch-username",
        "opensearch_password_key": "dev/synthia/opensearch-password",
        "bedrock_kb_id_key": "dev/synthia/bedrock_kb_id",
        "bedrock_kb_datasource_id_key": "dev/synthia/bedrock_kb_datasource_id",
        "propdata_s3_bucket_key": "dev/synthia/propdata_s3_bucket",
        "capitaliq_kou_url":"https://www.capitaliqdev.spglobal.com/apisv3/security-service/v1/Context/UserProfiles/Context.UserProfile?$select=Email,KeyOnlineUser",
        "core_url":"https://www.capitaliqdev.spglobal.com/apisv3/spg-webplatform-core/",
        "old_ciqpro_url":"https://www.capitaliqdev.spglobal.com/web/client?auth=inherit",
        "kensho_grounding_api_url":"https://grounding-alpha.preview.kensho.com/api/v1/search",
        "kensho_authentication_url":"https://kensho.okta.com/oauth2/default/v1/token",
        "kensho_private_pem_key": "dev/synthia/kensho_private_pem",
        "kensho_client_id": "0oasontxl2EZZ7DGX4x7",
        "postgres_host":"synthia-poc.czycoa8oafe0.us-east-1.rds.amazonaws.com:5432",
        "postgres_secrets":"rds!db-f63217a8-7469-49d6-8344-e87a3093477c",
        "QUEUE_URL":"https://sqs.us-east-1.amazonaws.com/339712941790/creditmemo-agent-sqs"
    },
    "stage": {
        "capitaliq_base_url": "https://www.capitaliqstg.spglobal.com/apisv3/spg-ratingsresearch-service/api/v3/",
        "omni_suggest_base_url": "https://www.capitaliqstg.spglobal.com/apisv3/search-service/v3/OmniSuggest/suggest",
        "opensearch_url": "https://vpc-mi-crs-chatrd-stg-3mm7iwegxxtgnvxj2ewkyb62ba.us-east-1.es.amazonaws.com",
        "news_article_url": "https://www.capitaliqstg.spglobal.com/apisv3/spg-webplatform-core/news/article?id=",
        "capitaliq_graphql_url": "https://www.capitaliqstg.spglobal.com/apisv3/federation/",
        "opensearch_research_index": "embedding-job-chatrd-research-stg-2412",
        "opensearch_commentary_index": "embedding-job-chatrd-commentary-2412",
        "opensearch_criteria_index": "embedding-job-chatrd-criteria-2412",
        "neural_search_model_id": "gg7-ho8BFqV2WuSKOrGq",
        "search_pipeline_name": "cohere-multilingual-search-pipeline",
        "reranker_endpoint_name": "mi-crs-chatrd-dev-ms-marco-cross-encoder-endpoint",
        "dataapi_url": "https://www.capitaliqstg.spglobal.com/apisv3/dataapi-service/",
        "capitaliq_base_inherit_auth_url": "https://www.capitaliqstg.spglobal.com/web/client?auth=inherit",
        "oauth_security_service_url": "https://www.capitaliqstg.spglobal.com/apisv3/security-service/oauth/",
        "ratings_article_base_url": "https://www.capitaliqstg.spglobal.com/web/login",
        "opensearch_username_key": "stage/synthia/opensearch-username",
        "opensearch_password_key": "stage/synthia/opensearch-password",
        "bedrock_kb_id_key": "dev/synthia/bedrock_kb_id",
        "bedrock_kb_datasource_id_key": "dev/synthia/bedrock_kb_datasource_id",
        "propdata_s3_bucket_key": "dev/synthia/propdata_s3_bucket",
        "capitaliq_kou_url":"https://www.capitaliqstg.spglobal.com/apisv3/security-service/v1/Context/UserProfiles/Context.UserProfile?$select=Email,KeyOnlineUser",
        "core_url":"https://www.capitaliqstg.spglobal.com/apisv3/spg-webplatform-core/",
        "old_ciqpro_url":"https://www.capitaliqstg.spglobal.com/web/client?auth=inherit",
        "kensho_grounding_api_url":"https://grounding-alpha.preview.kensho.com/api/v1/search",
        "kensho_authentication_url":"https://kensho.okta.com/oauth2/default/v1/token",
        "kensho_private_pem_key": "stage/synthia/kensho_private_pem",
        "kensho_client_id": "0oasontxl2EZZ7DGX4x7",
        "postgres_host":"synthia-poc.czycoa8oafe0.us-east-1.rds.amazonaws.com:5432",
        "postgres_secrets":"rds!db-f63217a8-7469-49d6-8344-e87a3093477c",
        "QUEUE_URL":"https://sqs.us-east-1.amazonaws.com/339712941790/creditmemo-agent-sqs"
    },
    "prod": {
        "capitaliq_base_url": "https://www.capitaliq.spglobal.com/apisv3/spg-ratingsresearch-service/api/v3/",
        "omni_suggest_base_url": "https://www.capitaliq.spglobal.com/apisv3/search-service/v3/OmniSuggest/suggest"
    }
}

def get_config():
    return CONFIG.get(ENV, CONFIG["dev"])