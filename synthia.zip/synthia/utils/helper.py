from urllib.parse import urlparse

import httpx
import traceback
import os
from typing import Optional

import requests
import time
import json
import logging
import streamlit as st

from src.synthia.aws_utils.aws_client import get_aws_client
from src.synthia.config.api_config import get_config
from dotenv import load_dotenv

logger = logging.getLogger(__name__)

load_dotenv(override=True)
cfg = get_config()

oauth_security_service_url =  cfg["oauth_security_service_url"]

def _init_token_state():
    if "TOKEN" not in st.session_state:
        st.session_state.TOKEN = None
    if "TOKEN_EXPIRY" not in st.session_state:
        st.session_state.TOKEN_EXPIRY = 0
    if "CLIENT_ID" not in st.session_state:
        st.session_state.CLIENT_ID = None
    if "CLIENT_SECRET" not in st.session_state:
        st.session_state.CLIENT_SECRET = None
    if "REFRESH_TOKEN" not in st.session_state:
        st.session_state.REFRESH_TOKEN = None

def _fetch_token_from_refresh_token():
    """Fetch a new Bearer token using the refresh token."""
    _init_token_state()
    payload = {
        "client_id": st.session_state.CLIENT_ID,
        "client_secret": st.session_state.CLIENT_SECRET,
        "grant_type": "refresh_token",
        "scope": "https://www.snl.com",
        "refresh_token": st.session_state.REFRESH_TOKEN,
    }
    headerdata = {
        "Content-Type": "application/x-www-form-urlencoded",
        "Accept": "application/json",
        "spg-appid": "ASP0016439",  # Replace with your actual app ID
    }
    response = requests.post(
        oauth_security_service_url + "token",
        data=payload,
        headers=headerdata,
    )
    if response.status_code == 200:
        data = response.json()
        logger.info("Fetched new Bearer token.")
        return data
    else:
        logger.error(f"Failed to fetch token: {response.status_code} {response.text}")
        return None

def _fetch_token(username, password):
    """Fetch a new Bearer token using the provided username and password."""
    #_init_token_state()
    if not st.session_state.CLIENT_ID or not st.session_state.CLIENT_SECRET:
        logger.info("Setting MI client credentials.")
        _set_mi_client_credentials()
    payload = {
        "username": username,
        "password": password,
        "client_id": st.session_state.CLIENT_ID,
        "client_secret": st.session_state.CLIENT_SECRET,
        "grant_type": "password",
        "scope": "https://www.snl.com",
    }
    headerdata = {
        "Content-Type": "application/x-www-form-urlencoded",
        "Accept": "application/json",
        "spg-appid": "702FAA98-FE6D-4CAB-808F-41F72760C8CF",  # Replace with your actual app ID
    }
    response = requests.post(
        oauth_security_service_url + "token",
        data=payload,
        headers=headerdata,
    )
    if response.status_code == 200:
        data = response.json()
        logger.info("Fetched new Bearer token.")
        return data
    else:
        logger.error(f"Failed to fetch token: {response.status_code} {response.text}")
        return None

def get_headers(username="", password=""):
    """Get headers with Bearer token for authentication."""
    _init_token_state()
    #logger.info(f"Env token: {auth_token}")
    if not st.session_state.TOKEN or time.time() > st.session_state.TOKEN_EXPIRY:
        if not st.session_state.REFRESH_TOKEN:
            logger.info("Fetching new Bearer token.")
            data = _fetch_token(username, password)
            if data is None:
                return None
            
            st.session_state.TOKEN = data["access_token"]
            logger.info(f"Access Token is {st.session_state.TOKEN}.")
            st.session_state.TOKEN_EXPIRY = time.time() + data.get("expires_in", 3600) - 1800
            st.session_state.REFRESH_TOKEN = data["refresh_token"]
        else:
            logger.info("Refreshing Bearer token using refresh token.")
            data = _fetch_token_from_refresh_token()
            if data is None:
                return None
            st.session_state.TOKEN = data["access_token"]
            st.session_state.TOKEN_EXPIRY = time.time() + data.get("expires_in", 3600) - 1800
            st.session_state.REFRESH_TOKEN = data["refresh_token"]

    token = st.session_state.TOKEN
    if not token[:10].lower().startswith("bearer "):
        token = f"Bearer {token}"
    return token

def _set_mi_client_credentials():
    #_init_token_state()
    response = requests.get(
        url= oauth_security_service_url + "clientCredentials"
    )
    logger.info(f"Response status: {response.status_code} {response.text}")
    mi_credentials = response.json()
    st.session_state.CLIENT_SECRET = mi_credentials["client_secret"]
    st.session_state.CLIENT_ID = mi_credentials["client_id"]

async def renew_access_token(client_id: str, client_secret: str, refresh_token: str) -> Optional[str]:
    async with httpx.AsyncClient() as client:
        try:
            payload = f"grant_type=refresh_token&client_id={client_id}&client_secret={client_secret}"
            headers = {
                "Content-Type": "application/x-www-form-urlencoded",
                "Accept": "application/json",
                "spg-appid": "ASP0016439",  # Replace with your actual app ID
                "Cookie": f"OAUTH_REFRESH_TOKEN={refresh_token}"
            }
            logger.info(f"OAuth URL :: {oauth_security_service_url}token")
            logger.info(f"Request params clientId:: {client_id}, clientSecret:: {client_secret}")
            logger.info(f"Refresh token :: {str(refresh_token)[:50]}")
            response = await client.post(
                oauth_security_service_url + "token",
                data=payload,
                headers=headers,
            )
            if response.status_code == 200:
                data = response.json()
                logger.info("Fetched new Bearer token.")
                return data
            else:
                logger.error(f"Failed to fetch token: {response.status_code} {response.text}")
                return None
        except httpx.RequestError as e:
            logger.error(f"An error occurred while renewing the token: {e}")
            logger.error(traceback.format_exc())
            return None
        except Exception as e:
            logger.error(f"Unexpected error occurred while renewing the token: {e}")
            logger.error(traceback.format_exc())
            return None

def get_presigned_url(s3_uri: str, expiration: int = 3600) -> str:
    """
    Generate a presigned URL for an S3 object from S3 URI.

    Args:
        s3_uri (str): The S3 URI (e.g., s3://bucket-name/object-key).
        expiration (int): Time in seconds for the presigned URL to remain valid.
    Returns:
        str: The presigned URL. If the input is not a valid S3 URI, returns it unchanged.
    """
    parsed = urlparse(s3_uri)
    bucket = parsed.netloc

    if parsed.scheme != 's3' or not bucket or not parsed.path:
        return s3_uri

    key = parsed.path.lstrip('/')

    s3_client = get_aws_client("s3", signature_version="s3v4")
    url = s3_client.generate_presigned_url(
        'get_object',
        Params={'Bucket': bucket, 'Key': key},
        ExpiresIn=expiration
    )
    return url