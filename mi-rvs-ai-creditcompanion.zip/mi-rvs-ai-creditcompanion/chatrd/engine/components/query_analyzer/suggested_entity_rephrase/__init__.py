from chatrd.engine.components.query_analyzer.suggested_entity_rephrase.prompter import (
    SuggestedEntityRephrasePrompter,
)
