import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import {
  LoadingIndicator,
  LoaderOverlay,
  LoaderPosition,
  LoaderType,
  NotificationType,
  useNotification,
} from '@spglobal/react-components';
import { useMessageBus } from '@spglobal/spa';
import { SpgError } from '@spglobal/error';
import * as dashboardModel from './dashboard.model';
import { Blog, IBlog } from '../blog/Blog';

export interface TestMessage {
  type: string;
  payload: {
    textInput: string;
  };
}

const Dashboard: React.FC = () => {
  const [blogsData, setBlogsData] = useState<IBlog>({});
  const [blogsDataError, setBlogsDataError] = useState<Error>(null);
  const messageBus = useMessageBus();
  const { addNotification } = useNotification();

  const userSession = useSelector((state?) => {
    return state?.userSession;
  });

  // subscribe to messages
  useEffect(() => {
    const subscription = messageBus.main.subscribe((message: TestMessage) => {
      if (message.type === 'test-click') {
        window.alert(`Message from MessageBus: ${message.payload.textInput}`);
      }
    });
    return () => subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (userSession && userSession.isLoggedIn) {
      const parameters = {
        activemicoverage: 1,
        contextOverrides: 'KeyGeographyTree,KeyMIIndustryTree',
        featureId: '1',
        keyArticleType: 'null',
        keyGeographyTree: userSession.userInformation?.preferredKeyGeographies?.join(' '),
        keyMIIndustryTree: userSession.userInformation?.preferredKeyMIIndustries?.join(' '),
        keyOnlinePortfolio: 'null',
        skipUserProfile: 1,
        timeZone: userSession.userInformation?.mSTimeZoneID,
      };

      dashboardModel
        .getBlogsDataSet(parameters)
        .then(function (newsBlogs: IBlog) {
          if (newsBlogs) {
            setBlogsData(newsBlogs);
            setBlogsDataError(null);
          }
        })
        .catch((e) => {
          setBlogsDataError(e);
        });
    }
  }, [userSession]);

  useEffect(() => {
    if (blogsDataError) {
      //an example of custom error message
      const customErrorName = blogsDataError.message.includes('500')
        ? 'Internal Server Error'
        : blogsDataError.name;
      const err = new SpgError(customErrorName, blogsDataError.message);
      addNotification(
        <div>
          <p>{err.name}.</p>
          <p>
            <strong>{err.message}</strong>.
          </p>
        </div>,
        NotificationType.ERROR
      );
    }
  }, [blogsDataError]);

  if (blogsData.FeatureNewsData === undefined && userSession?.isLoggedIn && !blogsDataError) {
    return (
      <LoadingIndicator
        overlay={LoaderOverlay.DEFAULT}
        position={LoaderPosition.FIXED}
        type={LoaderType.CENTER}
      />
    );
  } else if (blogsDataError) {
    return (
      <div className="spg-mt-lg">
      </div>
    );
  } else {
    return <Blog FeatureNewsData={blogsData.FeatureNewsData} />;
  }
};

export default Dashboard;
