from pydantic import BaseModel


class ExtractedGuidelines(BaseModel):
    guidelines: str
