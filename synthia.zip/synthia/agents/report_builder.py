import re
from dotenv import load_dotenv
import json
import logging
from langchain_core.messages import AIMessage
from pydantic import TypeAdapter
from src.synthia.schemas.sections import Section
from src.synthia.schemas.workflow import ReportConfig, OutlineSection, ReportSection
from typing import Any, Dict, List, Optional, Tuple
import traceback
from src.synthia.utils.logging_config import configure_logging
from src.synthia.agents.agent_factory import AgentFactory
from src.synthia.utils.template_util import (
    get_sections,
    get_subsections,
    get_template_prompt,
    get_tools_for_subsection,
)
from src.synthia.prompts.utils import (
    get_system_prompt_for_section,
)
from src.synthia.prompts.system_prompts import section_prompt, charts_prompt, synthesizer_prompt

load_dotenv(override=True)
from langchain.globals import set_verbose , set_debug

#set_verbose(True)
#set_debug(True)
class ReportBuilder:
    def __init__(self, agent_factory: AgentFactory, thread_config: Any):
        self.agent_factory = agent_factory
        self.thread_config = thread_config
        self.logger = configure_logging(
            log_file="synthia.log",
            module_levels={__name__: logging.DEBUG},  # Set this module to DEBUG
        )

    async def generate_outline(self, config: ReportConfig) -> List[Section]:
        topic = config["topic"]
        report_template = config.get("style", "")
        depth = config.get("depth", 3)
        num_sections = config.get("num_sections", 5)
        input_section_title = config.get("input_section_title", "")
        self.logger.debug(
            f"Generating outline for topic: {topic}, style: {report_template}, sections: {num_sections}"
        )

        if len(report_template) == 0:
            try:
                report_agent = await self.agent_factory.get_agent(agent_type="outline")
                response = await report_agent.ainvoke(
                    {
                        "messages": [
                            {
                                "role": "user",
                                "content": f"""Using tool available and exposed to you. 
                            Generate a plan with {num_sections} sections for the report focusing on company analysis.                  
                            Provide a short description for each section no more than 2-3 sentences.
                            You can assume that the company name will be converted to an ID to make use of the tools available.
                            Make sure to only use the tools available. If you don't have enough information to generate a section, return "Not enough data to generate section" for the section where info is lacking".
                            Do not use your own knowledge. 
                            Do not use any other tools than the ones available to you.
                            Here is the report topic: {topic}. Topic represents the Company InstID 
                            InstID/KeyInstn/MI Key - S&P's unique key to identify institutions. Institutions are corporations, partnerships, proprietorships, not-for-profit organizations, government agencies, and any other chartered organization.
                            If don't have enough information from the tools available, return "Not enough data to generate section" for the section where info is lacking"
                            """,
                            }
                        ]
                    },
                    config=self.thread_config,
                )

                # --- NEW: handle structured_response directly ---
                if "structured_response" in response and isinstance(
                    response["structured_response"], list
                ):
                    return [Section(**s) for s in response["structured_response"]]
                # --- END NEW ---
            except Exception as e:
                self.logger.error(f"Error generating outline: {str(e)}")

            return []
        else:  # Template based flow

            self.logger.debug(
                f"Using template style: {report_template} to generate outline for topic: {topic}, depth: {depth}, sections: {num_sections}"
            )
            sections = []
            for section in get_sections(f"{report_template}.json"):
                self.logger.debug(f"Processing section: {section}")
                subsections = get_subsections(f"{report_template}.json", section)
                if input_section_title:
                    subsections = [s for s in subsections if s.get("title") == input_section_title]
                for subsection in subsections:
                    tools_for_subsection = get_tools_for_subsection(
                        f"{report_template}.json", subsection
                    )
                    description = subsection.get("description", section)
                    sections.append(
                        Section(
                            name=subsection.get("title", section),
                            description=description,
                            tools=list(tools_for_subsection),
                        )
                    )
            print(f"Sections collected from the template: {sections}")
            return sections

    async def generate_section_content(
        self, config: ReportConfig, section: OutlineSection
    ) -> ReportSection:
        try:
            topic = config["topic"]
            report_template = config.get("style", "")
            depth = config.get("depth", 3)
            section_title = section["name"]
            user_pref_prompt = section["description"]
            section_index = section["section_index"]

            sys_pref_prompt = get_system_prompt_for_section(section_title)

            self.logger.debug(
                f"Generating content for section: {section_title} on topic: {topic}, section_content={user_pref_prompt} with report_template: {report_template} at depth: {depth}"
            )
            section_agent = await self.agent_factory.get_agent(
                agent_type="section",
                report_template=report_template,
                section_name=section_title,
            )

            if section_agent is None:
                self.logger.error(
                    f"No agent found for section: {section_title} with report_template: {report_template}"
                )
                return ReportSection(
                    name=section_title,
                    content=f"Content about {section_title}",
                    sources=["No agent available for this section"],
                    image=None,  # Explicitly include image field as None
                    section_index=section_index,
                )

            agent_config = {"recursion_limit": 50}

            
            chart_prompt = ""
            if ("chart" in sys_pref_prompt.lower() or 
                "chart" in user_pref_prompt.lower()):
                chart_prompt = charts_prompt

            formatted_prompt = section_prompt.format(
                section_title=section_title,
                topic=topic,
                section_index=section_index,
                depth=depth,
                chart_prompt=chart_prompt,
                sys_pref_prompt=sys_pref_prompt,
                user_pref_prompt=user_pref_prompt
            )

            response = await section_agent.ainvoke(
                {
                    "messages": [
                        {
                            "role": "user",
                            "content": formatted_prompt,
                        }
                    ]
                },
                config={**self.thread_config, **agent_config},
            )

            parsed_section_content = None

            # If response contains 'messages', process them for sources and content
            if "messages" in response:
                for message in response["messages"]:
                    # ToolMessage: extract sources
                    from langchain_core.messages import ToolMessage, HumanMessage

                    if isinstance(message, ToolMessage):
                        self.logger.debug(
                            f"Tool message received from tool '{getattr(message, 'name', '')[:100]}...'"
                        )
                    # AIMessage: parse JSON content
                    elif isinstance(message, AIMessage):
                        self.logger.debug(
                            f"Processing AIMessage for content: {str(message.content)[:100]}..."
                        )
                        if isinstance(message.content, str):
                            try:
                                parsed_section_content = json.loads(message.content)
                            except json.JSONDecodeError:
                                import re

                                json_match = re.search(
                                    r"\{.*\}", message.content, re.DOTALL
                                )
                                if json_match:
                                    try:
                                        parsed_section_content = json.loads(
                                            json_match.group()
                                        )
                                    except json.JSONDecodeError:
                                        self.logger.warning(
                                            f"Failed to parse JSON: {json_match.group()[:100]}..."
                                        )
                        else:
                            parsed_section_content = message.content
            # If response is already a dict with 'structured_response', use it
            elif "structured_response" in response and isinstance(
                response["structured_response"], dict
            ):
                parsed_section_content = response["structured_response"]
            elif "structured_response" in response and isinstance(
                response["structured_response"], list
            ):
                # fallback for list
                parsed_section_content = {"section": response["structured_response"]}

            self.logger.debug(f"Section content parsed: {parsed_section_content}")

            # Transform the section format to match the expected schema
            if (
                parsed_section_content
                and "section" in parsed_section_content
                and len(parsed_section_content["section"]) > 0
            ):
                section_data = parsed_section_content["section"][0]
                title = section_data.get("title", section_title)
                content = section_data.get("content", "No content provided")
                ai_sources = section_data.get("sources", [])
                chart_data = section_data.get("chart_data", None)
                if isinstance(ai_sources, str):
                    ai_sources = [ai_sources]
                all_sources = list(set(ai_sources))
                image = section_data.get("image", None)
                self.logger.debug(
                    f"Generated section: {title}, content length: {len(content)}, sources: {all_sources}, image: {image}"
                )
                return ReportSection(
                    name=title,
                    content=content,
                    sources=all_sources,
                    image=image,
                    section_index=section_index,
                    chart_data=chart_data
                )
            else:
                self.logger.warning(
                    "Failed to parse section content, using fallback without image"
                )
                return ReportSection(
                    name=section_title,
                    content=f"Content about {section_title}",
                    sources=[f"sources for {section_title}"],
                    image=None,
                    section_index=section_index,
                    chart_data=None
                )

        except Exception as e:
            self.logger.error(f"Error generating section: {str(e)}")
            self.logger.error(traceback.format_exc())
            return ReportSection(
                name=section.get("name", "Unknown"),
                content=f"Content about {section.get('name', 'Unknown')} (Error: {str(e)})",
                sources=[f"Error generating sources: {str(e)}"],
                image=None,
                section_index=section.get("section_index", None),
            )


    async def finalize_report(
        self, sections: List[ReportSection], report_template: str = ""
    ) -> List[ReportSection]:
        """Finalize the report."""
        # Ensure all sections match the expected schema (name/description format)
        transformed_sections = []

        try:
            self.logger.info(f"draft report:{sections}")

            # Save chart data at the beginning before any processing using section titles
            chart_data_backup = {}
            for section in sections:
                section_title = section.name
                chart_data_backup[section_title] = section.chart_data
                section.chart_data = None

            sections = await self.synthesize_report(sections, report_template)

            # Restore chart data after synthesis
            for section in sections:
                if section.name in chart_data_backup:
                    section.chart_data = chart_data_backup[section.name]

            # Collect all unique sources from all sections
            all_sources = []
            seen = set()
            sources_dict = {}
            import re
            for section in sections:
                sources = section.sources or []
                section.sources = []
                if isinstance(sources, str):
                    sources = [sources]
                elif not isinstance(sources, list):
                    sources = list(sources)
                for src in sources:
                    if src and src not in seen:
                        all_sources.append(src)
                        seen.add(src)

            self.logger.info(f"all_sources:{all_sources}")
            # Sort sections by section_index if present, ignore sections without section_index
            def get_section_index(section):
                if isinstance(section, dict):
                    return section.get("section_index", float("inf"))
                return getattr(section, "section_index", float("inf"))

            sorted_sections = sorted(
                [s for s in sections if get_section_index(s) != float("inf")],
                key=get_section_index,
            )
            # Add any sections without section_index at the end (except the sources section)
            unsorted_sections = [
                s for s in sections if get_section_index(s) == float("inf")
            ]

            final_sections = sorted_sections + unsorted_sections

            # sections_adapter = TypeAdapter(List[ReportSection])
            # sections_s = sections_adapter.validate_python(final_sections) if final_sections else None
            # final_sections_str = sections_adapter.dump_json(sections_s).decode('utf-8') if sections_s else None

            # self.logger.info(f"final_sections_str:{final_sections_str}")

            # final_sections_with_citations_fixed = final_sections
            final_sections.append(
                ReportSection(
                    name="Sources & References",
                    content="",
                    image=None,
                    sources=all_sources,
                    section_index=len(final_sections) + 1
                )
            )
            result_section = self.post_process_sections(final_sections)
            
            # Ensure chart data is preserved in the final result
            for section in result_section:
                if section.name in chart_data_backup:
                    section.chart_data = chart_data_backup[section.name]
                    
            self.logger.info(f"final_sections after adding sources & references:{result_section}")
            return result_section
        except Exception as e:
            self.logger.error(f"Error occured:{str(e)}")
            self.logger.error(f"{traceback.format_exc()}")
            
            # Restore chart data even in error case
            for section in sections:
                if section.name in chart_data_backup:
                    section.chart_data = chart_data_backup[section.name]
            return sections

    def _extract_url_and_text(self, src_rest: str) -> Tuple[Optional[str], str]:
        """
        Try to extract a URL and readable text from a source string.
        - If there's an <a ...>text</a>, prefer text inside it and find the first http(s) URL.
        - If no anchor but a visible URL exists, use that URL as text.
        - Otherwise treat the whole rest as plain text.
        This is forgiving for slightly malformed tags.
        """
        # find first URL-looking substring
        url_match = re.search(r"https?://[^\s\"\'<>]+", src_rest)
        url = url_match.group(0).strip() if url_match else None

        # try to extract inner text of <a>...</a>
        anchor_text_match = re.search(r"<a\b[^>]*>(.*?)</a>", src_rest, flags=re.IGNORECASE | re.DOTALL)
        if anchor_text_match:
            text = anchor_text_match.group(1).strip()
        elif url:
            text = url
        else:
            text = src_rest.strip()

        return url, text

    def _normalize_key(self, url: Optional[str], text: str) -> str:
        """
        Create a canonical key for deduplication: prefer normalized URL if available,
        else normalized text.
        """
        if url:
            # basic normalization: lower-case, strip trailing slash and common trailing punctuation
            k = url.strip().lower().rstrip("/").rstrip(">").rstrip('"').strip()
            return k
        return text.strip().lower()

    def post_process_sections(self, sections: List[ReportSection]) -> List[ReportSection]:
        """
        1) Read 'Sources & References' (assumed last section) and parse entries like:
        '[1.2] <a href="https://...">text</a>' or '[2.3] plain text'
        2) Deduplicate sources (by URL when present, else by text) preserving first-seen order.
        3) Build mapping old_label -> new sequential number (1..n).
        4) Replace inline citations in all earlier sections:
        - '<a ...>[1.1]</a>' => '<a ...>[1]</a>' (anchor preserved)
        - plain '[1.3]' => '[1]' (plain preserved)
        5) Replace the last section.sources with the unified deduplicated list:
        e.g. '[1] <a href="https://...">Text</a>' or '[2] Source text'
        """
        if not sections:
            return sections

        last = sections[-1]
        raw_sources = last.sources or []

        label_re = re.compile(r"^\s*\[(\d+(?:\.\d+)*)\]\s*(.*)$")  # capture [1.2] rest...
        key_to_newnum: Dict[str, int] = {}
        newnum_to_info: Dict[int, Dict[str, Optional[str]]] = {}
        oldlabel_to_newnum: Dict[str, int] = {}
        next_num = 1

        # 1) Parse last section sources in order and assign new numbers for unique keys
        for entry in raw_sources:
            m = label_re.match(entry)
            if not m:
                # skip or treat as plain text without old label
                continue
            old_label, rest = m.group(1), m.group(2).strip()
            url, text = self._extract_url_and_text(rest)
            key = self._normalize_key(url, text)

            if key not in key_to_newnum:
                key_to_newnum[key] = next_num
                newnum_to_info[next_num] = {"url": url, "text": text}
                oldlabel_to_newnum[old_label] = next_num
                next_num += 1
            else:
                # duplicate — map this old_label to the already assigned number
                assigned = key_to_newnum[key]
                oldlabel_to_newnum[old_label] = assigned
                # possibly prefer a nicer "text" when we previously only stored url or generic text
                prev = newnum_to_info[assigned]
                # if previous had no text but this has, prefer this text
                if prev.get("text") in (None, "") and text:
                    prev["text"] = text
                # if previous had no url but this has, prefer url
                if prev.get("url") is None and url:
                    prev["url"] = url

        # 2) Replace inline citations across all sections except last
        # Matches optional opening <a...>, then [1.2], then optional closing </a>
        citation_pattern = re.compile(r'(<a\b[^>]*?>)?\[(\d+(?:\.\d+)*)\](</a>)?', flags=re.IGNORECASE)

        def _replace_match(m: re.Match) -> str:
            opening = m.group(1) or ""
            old_label = m.group(2)
            closing = m.group(3) or ""
            newnum = oldlabel_to_newnum.get(old_label)
            if newnum is None:
                # not found in sources map — leave unchanged
                return m.group(0)
            # preserve anchor tag if present
            if opening:
                return f"{opening}[{newnum}]{closing}"
            else:
                return f"[{newnum}]"

        for sec in sections[:-1]:
            sec.content = citation_pattern.sub(lambda mm: _replace_match(mm), sec.content)

        # 3) Build unified sources list in numeric order
        unified_sources: List[str] = []
        for num in range(1, next_num):
            info = newnum_to_info.get(num, {})
            url = info.get("url")
            text = (info.get("text") or f"Source {num}").strip()
            if url:
                # produce a clean anchor tag (consistent)
                anchor = f'<a href="{url}" target="_blank">{text}</a>'
                unified_sources.append(f'[{num}] {anchor}')
            else:
                unified_sources.append(f'[{num}] {text}')

        # Replace last section's sources with the unified list and clear its content
        last.sources = unified_sources
        last.content = last.content  # keep content as-is (empty in your example)

        return sections

    async def synthesize_report(
        self,
        sections: List[ReportSection],
        report_template: str = "",
    ) -> List[ReportSection]:
        """Synthesize the report from the generated sections."""
        try:
            template_prompt = get_template_prompt(f"{report_template}.json")
            self.logger.info(f"template_prompt:{template_prompt}")

            prompt = synthesizer_prompt.format(
                sections=sections,
                template_prompt=template_prompt
            )

            self.logger.info(f"Optimized prompt for synthesizer")
            try:
                agent = await self.agent_factory.get_agent(
                    agent_type="synthesizer",
                )
                response = await agent.ainvoke(
                    {"messages": [{"role": "user", "content": prompt}]},
                    config=self.thread_config,
                )
                self.logger.info(f"complete response from LLM:{response}")
                sections_data = None
                for message in response["messages"]:
                    if isinstance(message, AIMessage):
                        self.logger.info(f"AIMessage received: {message.content}")
                        if message.content:
                            if isinstance(message.content, str):
                                try:
                                    sections_data = json.loads(message.content)
                                except json.JSONDecodeError:
                                    import re

                                    json_match = re.search(
                                        r"\{.*\}", message.content, re.DOTALL
                                    )
                                    if json_match:
                                        try:
                                            sections_data = json.loads(
                                                json_match.group()
                                            )
                                        except json.JSONDecodeError:
                                            self.logger.warning(
                                                f"Failed to parse JSON from match: {json_match.group()[:100]}..."
                                            )
                            else:
                                sections_data = message.content
                synthesized_sections = []
                if isinstance(sections_data, dict) and "sections" in sections_data:
                    for section_dict in sections_data.get("sections", []):
                        synthesized_sections.append(
                            ReportSection(
                                name=section_dict.get("title", ""),
                                content=section_dict.get("content", ""),
                                image=section_dict.get("image", ""),
                                section_index=section_dict.get("section_index", ""),
                                sources=section_dict.get("sources", []),
                                chart_data=section_dict.get("chart_data", None),
                            )
                        )
                    self.logger.debug(
                        f"Synthesized sections: {len(synthesized_sections)} sections found."
                    )
                    synthesized_report = synthesized_sections
                else:
                    self.logger.warning(
                        "LLM did not return valid JSON with 'sections'. Returning markdown string instead."
                    )
                    # Fallback: return the LLM's markdown output or the raw report
                    synthesized_report = (
                        message.content
                        if "message" in locals() and hasattr(message, "content")
                        else sections
                    )
            except Exception as e:
                self.logger.error(f"LLM synthesis failed: {e}")
                self.logger.error("Returning raw report as fallback.")
                self.logger.error(f"{traceback.format_exc()}")
                synthesized_report = sections
            self.logger.info(f"Final sections after synthesizer:{synthesized_report}")
            return synthesized_report
        except Exception as e:
            self.logger.error(f"Error synthesizing report: {str(e)}")
            self.logger.error(traceback.format_exc())
            return []