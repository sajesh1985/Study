from typing import Optional, Union

from pydantic import BaseModel, Field

from chatrd.core.llm.parsers import PydanticOutputParser
from chatrd.core.llm.prompt.template import SimplePromptTemplate


class QuestionTopicClassifier(BaseModel):
    CompanyInSubject: Optional[Union[bool, None]] = Field(
        default=None,
        description="Indicator if at least one of the listed companies is a subject of the question",
    )
    ChainOfThought: Optional[Union[str, None]] = Field(
        default="",
        description="Step-by-step logic which led you to the answer. Determine question subject and the role of provided entities.",
    )


parser_rating_action_subrouting = PydanticOutputParser(pydantic_object=QuestionTopicClassifier)

RATING_ACTION_SUBROUTING_TEMPLATE = """
You are a financial advisor, whose goal is to analyze a subject of user's question.

<instructions>
Your are provided with two elements:
    - question
    - list of entity names (company, municipality, country, etc)

CompanyInSubject: your goal is determine, if provided entities are a subject of the question:
    - output true, when the questions is about one of these entities
    - output false, when the question is about a different topic. The entities might be used to define filtering criteria for data, etc

ChainOfThought:
    - Determine what is question subject and what is the role of provided entities
</instructions>

<formatting>
This information is to be output only when mentioned in the question. Format the output following these guidelines:

<format_guidelines>
{format_instructions}
</format_guidelines>

You MUST follow these rules:
    - Do not add anything other than the defined JSON schema
    - Do not say, this is the JSON output I requested
    - Do not justify your answer
    - Provide only the JSON
    - Follow closely the formatting instructions
    - Do not add other fields, than defined in format_guidelines
</formatting>

Follow these examples, format them according to the format_guidelines
<examples>
{examples}
</examples>

Apply these instructions to this input
Question: {question}
Entities: {entities}
"""


RATING_ACTION_SUBROUTING_EXAMPLES = [
    [
        "Question: 'Show me Tesla's most recent rating change', Entities: 'Tesla'",
        "CompanyInSubject: true, ChainOfThought: 'The question is about Tesla and its rating change'",
    ],
    [
        "Question: 'What are the recent rating downgrades for Swiss banks?', Entities: 'Swiss'",
        "CompanyInSubject: false, ChainOfThought: 'This is a question about all banks, Switzerland is not a topic of this question. It is used as a location, to narrow down the list'",
    ],
    [
        "Question: 'When was the last time rating of Greece deteriorated', Entities: 'Greece'",
        "CompanyInSubject: true, ChainOfThought: 'The question is about Greece and its rating change'",
    ],
    [
        "Question: 'Show me all newly rated companies from Greece', Entities: 'Greece'",
        "CompanyInSubject: false, ChainOfThought: 'This is a question about all companies, Greece is used as a filter which narrows down the list'",
    ],
    [
        "Give the latest rating action for the economies of France and Egypt', Entities: 'France, Egypt'",
        "CompanyInSubject: true, ChainOfThought: 'Question is about France and Egypt, and their economies's rating actions. Entities are not used as filtering criteria, but as subjects of the question'",
    ],
    [
        "Question: 'Can you provide me a list of entities in France that have been downgraded in the last 24 months?, Entities: 'France'",
        "CompanyInSubject: false, ChainOfThought: 'This is a question about all entities, France is used as a location, to narrow down the list'",
    ],
    [
        "Question: Show me recent rating changes for AMD and Intel'?, Entities: 'AMD, Intel'",
        "CompanyInSubject: true, ChainOfThought: 'This is a question about AMD and Intel, and their rating changes'",
    ],
    [
        "Question: List upgraded financial companies in US'?, Entities: 'USA'",
        "CompanyInSubject: false, ChainOfThought: 'This is a question about all companies, USA is used as a location, to narrow down the list'",
    ],
    [
        "Question: What are the last 5 defaulted American entities'?, Entities: 'US'",
        "CompanyInSubject: false, ChainOfThought: 'This is a question about all companies, USA is used as additional geographical condition, to narrow down the list'",
    ],
    [
        "Question: 'What are the recent rating actions for British mining companies?', Entities: 'British'",
        "CompanyInSubject: false, ChainOfThought: 'This is a question about all mining companies, Great Britain is not a topic of this question. British is used as a location, to narrow down the list'",
    ],
    [
        "Question: 'What are the recent rating downgrades for Swiss banks?', Entities: 'Swiss'",
        "CompanyInSubject: false, ChainOfThought: 'This is a question about all banks, Switzerland is not a topic of this question. It is used as a location, to narrow down the list'",
    ],
    [
        "Question: 'What is the latest Rating action taken for Belgium', Entities: 'Belgium'",
        "CompanyInSubject: true, ChainOfThought: 'The question is about Belgium and its rating action'",
    ],
    [
        "Question: 'Latest rating action for the economies of Portugal, Italy, Ireland, Greece and Spain', Entities: 'Portugal, Italy, Ireland, Greece and Spain'",
        "CompanyInSubject: true, ChainOfThought: 'Question is about Portugal, Italy, Ireland, Greece and Spain, and their economies's rating actions. Entities are not used as filtering criteria, but as subjects of the question'",
    ],
]

RATING_ACTION_SUBROUTING_EXAMPLES_FORMATTED = "\n\n________\n\n".join(
    [f"""Question: {question} \nOutput: {response}""" for question, response in RATING_ACTION_SUBROUTING_EXAMPLES]
)

rating_action_subrouting_input = {
    "format_instructions": parser_rating_action_subrouting.get_format_instructions(),
    "examples": RATING_ACTION_SUBROUTING_EXAMPLES_FORMATTED,
}


RATING_ACTION_SUBROUTING_TEMPLATE = SimplePromptTemplate(
    template=RATING_ACTION_SUBROUTING_TEMPLATE,
    partial_variables=rating_action_subrouting_input,
)
