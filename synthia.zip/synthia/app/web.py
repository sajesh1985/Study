"""Streamlit frontend for Synthia."""

import streamlit as st
import requests
import time
import json
import logging
import hashlib
from typing import Dict, List, Any, Optional
import pandas as pd
import plotly.express as px
from sympy import sec
from src.synthia.config.url_config import getApiUrl
from src.synthia.utils.template_util import load_section_options
from src.synthia.utils import helper
import os
import datetime
import streamlit.components.v1 as components
import sys

# Configure page FIRST before any other Streamlit operations
st.set_page_config(
    page_title="Synthia - AI Report Generator",
    page_icon="📝",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Configure logging AFTER page config for Streamlit compatibility
def setup_logging():
    """Setup logging configuration for Streamlit."""
    # Create a custom formatter
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    # Get the root logger
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    
    # Remove any existing handlers to avoid duplicates
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)
    
    # Create console handler for stdout (visible in Streamlit)
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(formatter)
    
    # Add handler to logger
    logger.addHandler(console_handler)
    
    # Also set up the specific logger for this module
    module_logger = logging.getLogger(__name__)
    module_logger.setLevel(logging.INFO)
    
    return module_logger

# Setup logging
logger = setup_logging()

# Define application directory path for use in image resolution
chart_images_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "resources", "chart_images"))
# chart_images_dir = os.path.join(app_dir, "chart_images")

# Log directory paths for debugging
logger.info(f"Chart images directory: {chart_images_dir}")
logger.info(f"Working directory: {os.getcwd()}")

# Ensure chart_images_dir exists and log its contents
if os.path.exists(chart_images_dir):
    logger.info(f"Chart images available: {os.listdir(chart_images_dir)}")
else:
    logger.warning(f"Chart images directory not found at {chart_images_dir}")

# Define settings directly instead of importing
def get_settings():
    """Simple settings function to avoid import issues"""
    class Settings:
        api_url = getApiUrl()
        # Default credentials (in production these should come from environment variables or a secure config)
        default_username = "admin"
        default_password_hash = "5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8"
    return Settings()

# Initialize session state for auth
if "authenticated" not in st.session_state:
    st.session_state.authenticated = False
if "login_attempts" not in st.session_state:
    st.session_state.login_attempts = 0
if "show_password" not in st.session_state:
    st.session_state.show_password = False
if "username" not in st.session_state:
    st.session_state.username = None

# Initialize session state
if "job_id" not in st.session_state:
    st.session_state.job_id = None
if "report_data" not in st.session_state:
    st.session_state.report_data = None
if "monitoring" not in st.session_state:
    st.session_state.monitoring = False
if "outline_approved" not in st.session_state:
    st.session_state.outline_approved = False
if "outline_rejected" not in st.session_state:
    st.session_state.outline_rejected = False
if "show_rejection_options" not in st.session_state:
    st.session_state.show_rejection_options = False
if "revision_submitted" not in st.session_state:
    st.session_state.revision_submitted = False

# Add session state variables for outline approval workflow
if "awaiting_approval" not in st.session_state:
    st.session_state.awaiting_approval = False
if "outline_data" not in st.session_state:
    st.session_state.outline_data = None
if "show_revision_options" not in st.session_state:
    st.session_state.show_revision_options = False
if "last_status_check" not in st.session_state:
    st.session_state.last_status_check = None

#Allow user to add custom sections
if "user_sections" not in st.session_state:
    st.session_state.user_sections = []

# Add session state variables for final report approval workflow
if "awaiting_final_approval" not in st.session_state:
    st.session_state.awaiting_final_approval = False
if "final_report_data" not in st.session_state:
    st.session_state.final_report_data = None

def get_api_url() -> str:
    """Get API URL from settings."""
    settings = get_settings()
    api_url = settings.api_url or "http://localhost:8000"
    return api_url

def get_token(username="",password="") -> str:
    """Get Token."""
    settings = get_settings()
    if st.session_state.username == settings.default_username:
        st.session_state.proptoken = helper.auth_token
        return helper.auth_token
    token = helper.get_headers(username, password)
    st.session_state.proptoken = token
    return token

def start_report_generation(topic: str, style: str, depth: int, sections: int, input_section_title: str) -> str:
    """Start a new report generation job via API."""
    api_url = get_api_url()
    token = get_token()
    
    try:
        response = requests.post(
            f"{api_url}/reports",
            json={
                "topic": topic,
                "style": style,
                "depth": depth,
                "sections": sections,
                "input_section_title": input_section_title,
            },
            headers={"Authorization": f"{token}"},
            timeout=60,
        )
        response.raise_for_status()
        return response.json().get("job_id")
    except requests.exceptions.RequestException as e:
        st.error(f"Failed to start report generation: {str(e)}")
        return None


def get_report_status(job_id: str) -> Dict[str, Any]:
    """Get the status of a report generation job."""
    api_url = get_api_url()
    token = get_token()
    
    try:
        logger.info(f"Fetching status for job {job_id} from {api_url}/reports/{job_id}")
        response = requests.get(
            f"{api_url}/reports/{job_id}", 
            headers={"Authorization": f"{token}"},
            timeout=60
        )
        response.raise_for_status()
        result = response.json()
        
        logger.info(f"Received status response for job {job_id}: status={result.get('status')}")
        
        # --- FIX: If awaiting_final_approval, always set final_report_data in session state ---
        if result.get("status") in ("awaiting_final_approval", "interrupt_final_report_approval"):
            final_report = result.get("final_report")
            if final_report:
                st.session_state.final_report_data = final_report
                st.session_state.awaiting_final_approval = True
                logger.info(f"Set final_report_data in session state for job {job_id}")
        # --- END FIX ---

        # Debug image paths in sections
        sections = result.get('sections', [])
        if sections:
            logger.info(f"API returned {len(sections)} sections")
            for i, section in enumerate(sections):
                # Handle both dict and ReportSection object formats
                image_field = None
                if isinstance(section, dict):
                    image_field = section.get('image')
                else:
                    image_field = getattr(section, 'image', None)
                    
                if image_field:
                    logger.info(f"API returned image path for section {i}: {image_field}")
                    
        return result
    except requests.exceptions.RequestException as e:
        logger.error(f"Failed to get report status for job {job_id}: {str(e)}")
        st.error(f"Failed to get report status: {str(e)}")
        return None


def render_highcharts(chart_data: dict, chart_id: str = "highchart") -> None:
    """Render Highcharts chart(s) using Streamlit HTML component, side by side in 2 columns if multiple."""
    if not chart_data:
        return
    import json
    highcharts_js = "https://code.highcharts.com/highcharts.js"
    # If chart_data is a list, render each chart in 2 columns
    if isinstance(chart_data, list):
        cols = st.columns(2)
        for idx, chart in enumerate(chart_data):
            chart_json = json.dumps(chart)
            html = f"""
            <div id="{chart_id}_{idx}" style="width:100%;height:400px;"></div>
            <script src="{highcharts_js}"></script>
            <script>
            document.addEventListener("DOMContentLoaded", function() {{
                Highcharts.chart('{chart_id}_{idx}', {chart_json});
            }});
            </script>
            """
            with cols[idx % 2]:
                components.html(html, height=420)
    elif isinstance(chart_data, dict):
        chart_json = json.dumps(chart_data)
        html = f"""
        <div id="{chart_id}" style="width:100%;height:400px;"></div>
        <script src="{highcharts_js}"></script>
        <script>
        document.addEventListener("DOMContentLoaded", function() {{
            Highcharts.chart('{chart_id}', {chart_json});
        }});
        </script>
        """
        components.html(html, height=420)

def render_report(sections: List[Dict[str, Any]]) -> None:
    """Render the generated report sections."""
    if not sections:
        st.warning("No report sections available.")
        return

    for idx, section in enumerate(sections):
        # Handle both dict and ReportSection object formats
        if isinstance(section, dict):
            section_title = section.get("name", section.get("title", "Untitled Section"))
            section_content = section.get("content", section.get("description", ""))
            section_sources = section.get("sources", [])
            section_image = section.get("image", None)
            chart_data = section.get("chart_data", None) if isinstance(section, dict) else getattr(section, 'chart_data', None)
        else:
            section_title = getattr(section, 'name', getattr(section, 'title', "Untitled Section"))
            section_content = getattr(section, 'content', getattr(section, 'description', ""))
            section_sources = getattr(section, 'sources', [])
            section_image = getattr(section, 'image', None)
            chart_data = getattr(section, 'chart_data', None)

        if section_content:
            section_content = str(section_content).replace('$', '\\$')
        else:
            section_content = ""
        
        logger.info(f"Rendering section_image: {section_image}")
        logger.info(f"FROM Rendering section: {section}")
        
        st.header(section_title, divider="red")
        st.markdown(section_content, unsafe_allow_html=True)
        # --- Render Highcharts if chart_data is present and valid ---
        if chart_data:
            try:
                # If chart_data is a list, render all charts
                render_highcharts(chart_data, chart_id=f"highchart_{idx}")
            except Exception as e:
                st.warning(f"Failed to render chart: {e}")
        # --- end chart rendering ---
        # Handle image display
        if section_image:
            # Normalize the image path
            section_image = normalize_image_path(section_image)
            st.write(f"Image path: {section_image}")
            
            # Try different path resolution approaches
            image_paths_to_try = [
                section_image,  # As-is
                # os.path.join(app_dir, section_image),  # Relative to app directory
                os.path.join(os.getcwd(), section_image),  # Relative to working directory
                os.path.join("src/synthia/app", section_image),  # Another common location
                os.path.join(chart_images_dir, section_image),  # Direct from chart_images dir
                os.path.join(chart_images_dir, os.path.basename(section_image))  # Just the filename in chart_images
            ]
            
            image_displayed = False
            for path in image_paths_to_try:
                try:
                    logger.info(f"Trying image path: {path}, exists: {os.path.exists(path)}")
                    if os.path.exists(path):
                        st.image(path, caption=section_title)
                        st.success(f"Image displayed from: {path}")
                        image_displayed = True
                        break
                except Exception as e:
                    logger.warning(f"Failed to display image from path {path}: {str(e)}")
            
            if not image_displayed:
                # Last attempt - look for any matching filename in chart_images directory
                try:
                    filename = os.path.basename(section_image)
                    matching_files = [f for f in os.listdir(chart_images_dir) 
                                      if filename.lower() in f.lower()]
                    
                    if matching_files:
                        best_match = matching_files[0]
                        image_path = os.path.join(chart_images_dir, best_match)
                        st.image(image_path, caption=section_title)
                        st.success(f"Image displayed (fuzzy match) from: {image_path}")
                        image_displayed = True
                except Exception as e:
                    logger.warning(f"Fuzzy matching failed: {str(e)}")
                    
            if not image_displayed:
                logger.error(f"Could not display image. Tried paths: {image_paths_to_try}")
                
        # Add proper sources rendering
        if section_sources:
            if isinstance(section_sources, list):
                st.subheader("Sources")
                for source in section_sources:
                    st.markdown(f"{source}", unsafe_allow_html=True)
            else:
                st.subheader("Source")
                st.write(section_sources)
      

def format_elapsed_time(start_iso, end_iso=None):
    """Format elapsed time between two ISO timestamps."""
    try:
        if not start_iso:
            return "N/A"
        import datetime
        start = datetime.datetime.fromisoformat(start_iso)
        end = datetime.datetime.fromisoformat(end_iso) if end_iso else datetime.datetime.now()
        elapsed = end - start
        minutes = int(elapsed.total_seconds() // 60)
        seconds = int(elapsed.total_seconds() % 60)
        return f"{minutes}m {seconds}s"
    except Exception as e:
        logger.warning(f"Error formatting elapsed time: {e}")
        return "N/A"

def display_progress_metrics(status_data: Dict[str, Any]) -> None:
    """Display progress metrics and visualizations, including elapsed time for each step."""
    # Use progress field from ReportStatus
    progress = status_data.get("progress", 0.0)
    if progress is not None:
        progress = float(progress) / 100.0 if progress > 1.0 else float(progress)
    else:
        progress = 0.0
        
    status = status_data.get("status", "unknown")
    completed_at = status_data.get("completed_at", None)
    
    # Calculate current section info from sections array
    sections = status_data.get("sections", [])
    outline = status_data.get("outline", [])
    current_section_idx = len([s for s in sections if s]) if sections else 0
    total_sections = len(outline) if outline else 0

    # Elapsed time tracking - these fields come from ReportStatus
    started_at = status_data.get("started_at")
    completed_at_iso = completed_at

    st.progress(progress)
    if total_sections > 0:
        st.info(f"Progress: {current_section_idx}/{total_sections} sections completed")
    
    if status and status.lower() == "completed":
        try:
            completed_time = completed_at
            if completed_at_iso:
                completed_time = completed_at_iso
                completed_time_fmt = ""
                try:
                    import datetime
                    completed_time_fmt = datetime.datetime.fromisoformat(completed_at_iso).strftime("%H:%M:%S")
                except Exception:
                    completed_time_fmt = completed_at_iso
                st.metric("Status", f"{status.capitalize()} @ {completed_time_fmt}", delta=f"{int(progress * 100)}%")
            else:
                st.metric("Status", f"{status.capitalize()}", delta=f"{int(progress * 100)}%")
        except Exception:
            st.metric("Status", f"{status.capitalize()}", delta=f"{int(progress * 100)}%")
    else:
        # For section_generated status, make it more descriptive
        if status == "section_generated":
            st.metric("Status", f"Generating section {current_section_idx + 1}", delta=f"{int(progress * 100)}%")
        else:
            st.metric("Status", status.capitalize() if status else "Unknown", delta=f"{int(progress * 100)}%")
    
    # If we have section data, show additional metrics
    if sections:
        # Count total words
        total_words = 0
        section_word_counts = {}
        
        for section in sections:
            # Handle both dict and ReportSection object formats
            section_name = None
            section_content = None
            
            if isinstance(section, dict):
                section_name = section.get("name", section.get("title", "Untitled"))
                section_content = section.get("content", section.get("description", ""))
            else:
                section_name = getattr(section, 'name', getattr(section, 'title', "Untitled"))
                section_content = getattr(section, 'content', getattr(section, 'description', ""))
            
            if "Sources & References" in section_name:
                continue
                
            if section_content:
                section_words = len(str(section_content).split())
                total_words += section_words
                section_word_counts[section_name] = section_words
        
        # Display metrics
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Total Words", total_words)
        with col2:
            st.metric("Sections", len(sections)-1 if sections else 0)  # Exclude "Sources & References"
        
        # Create a DataFrame for visualization
        if section_word_counts:
            df = pd.DataFrame({
                'Section': list(section_word_counts.keys()),
                'Word Count': list(section_word_counts.values())
            })
            
            # Create bar chart
            fig = px.bar(
                df, 
                x='Section', 
                y='Word Count',
                title='Word Count by Section',
                color='Word Count',
                color_continuous_scale='viridis'
            )
            st.plotly_chart(fig, use_container_width=True)


def approve_reject_outline(job_id: str, approved: bool, user_sections: Dict = None,revised_sections: Optional[int] = None, revised_depth: Optional[int] = None) -> Dict[str, Any]:
    """Approve or reject a report outline via API."""
    api_url = get_api_url()
    token = get_token()
    
    payload = {
        "approved": approved
    }
    if user_sections is not None:
        payload["user_sections"] = user_sections

    if revised_sections is not None:
        payload["revised_sections"] = revised_sections
        
    if revised_depth is not None:
        payload["revised_depth"] = revised_depth
    
    try:
        response = requests.post(
            f"{api_url}/reports/{job_id}/approve-outline",
            json=payload,
            headers={"Authorization": f"{token}"},
            timeout=60,
        )
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        st.error(f"Failed to approve/reject outline: {str(e)}")
        return None


def render_outline(outline: List[Dict[str, Any]]) -> None:
    """Render the generated report outline for approval."""
    if not outline:
        logger.warning("No outline available to render")
        st.warning("No outline available.")
        return

    # Log the structure of the outline for debugging
    logger.info(f"Rendering outline - type: {type(outline)}, length: {len(outline) if outline else 0}")
    if outline and len(outline) > 0:
        logger.info(f"First outline item type: {type(outline[0])}")
    
    # Add debug expander to show outline structure
    with st.expander("Debug Outline Structure", expanded=False):
        st.write(f"Outline type: {type(outline)}")
        st.write(f"Outline length: {len(outline) if outline else 0}")
        if outline and len(outline) > 0:
            st.write(f"First item type: {type(outline[0])}")
            st.json(outline[0])

    # Show the outline in a table
    st.write("### Report Outline")
    
    # Create a DataFrame for the outline
    outline_data = []
    
    try:
        for i, section in enumerate(outline):
            # Handle both dictionary and Section object formats
            if hasattr(section, 'name') and hasattr(section, 'description'):
                # It's likely a Pydantic Section object that was serialized
                section_name = section.name
                section_desc = section.description
                section_tools = section.tools
            elif isinstance(section, dict):
                section_name = section.get("name", section.get("title", "Untitled Section"))
                section_desc = section.get("description", section.get("content", ""))
                section_tools = section.get("tools", "")
            else:
                # It's something else, try to handle it
                section_name = str(getattr(section, 'name', getattr(section, 'title', "Untitled Section")))
                section_desc = str(getattr(section, 'description', getattr(section, 'content', "")))
                section_tools = str(getattr(section, 'tools', getattr(section, 'tools', "")))
            
            outline_data.append({
                "Section #": i+1,
                "Name": section_name,
                "Description": section_desc,
                "Suggested Tools": section_tools
            })
    except Exception as e:
        logger.error(f"Error rendering outline: {e}")
        st.error(f"Error rendering outline: {e}")
    
    if outline_data:
        df = pd.DataFrame(outline_data)
        st.table(df)
    else:
        st.warning("Could not parse outline data correctly.")


# Helper functions for outline approval workflow
def handle_approve_outline():
    """Handle the approval of an outline."""
    job_id = st.session_state.job_id
    logger.info(f"Starting outline approval process for job {job_id}")
    
    if not job_id:
        logger.error("No job ID available for approval")
        st.error("No job ID available for approval")
        return False
    
    try:
        logger.info(f"Sending approval request for job {job_id} with user_sections: {st.session_state.user_sections}")
        with st.spinner("Processing approval..."):
            response = approve_reject_outline(job_id, True, st.session_state.user_sections)
            if response:
                logger.info(f"Outline approval successful for job {job_id}: {response}")
                st.success("Outline approved! Continuing with report generation.")
                
                # Update session state in correct order
                st.session_state.outline_approved = True
                st.session_state.awaiting_approval = False
                st.session_state.outline_data = None
                st.session_state.show_revision_options = False
                st.session_state.user_sections = []  # Clear user sections after approval
                st.session_state.monitoring = True
                
                logger.info("Session state updated successfully after outline approval")
                return True
            else:
                logger.error(f"Outline approval failed for job {job_id} - no response from API")
                st.error("Failed to approve outline. Please try again.")
                return False
    except Exception as e:
        logger.error(f"Exception during outline approval for job {job_id}: {str(e)}", exc_info=True)
        st.error(f"Error during outline approval: {str(e)}")
        return False


def handle_reject_outline(revised_sections=None, revised_depth=None):
    """Handle the rejection of an outline."""
    job_id = st.session_state.job_id
    logger.info(f"Handling outline rejection for job {job_id} with revised_sections={revised_sections}, revised_depth={revised_depth}")
    
    with st.spinner("Processing revision..."):
        response = approve_reject_outline(
            job_id, 
            False,
            None, 
            revised_sections, 
            revised_depth
        )
        if response:
            st.info("Outline rejected. Generating new outline with revised parameters.")
            logger.info(f"Outline rejected for job {job_id}: {response}")
            
            # Reset outline approval session state
            st.session_state.awaiting_approval = False
            st.session_state.outline_data = None
            st.session_state.show_revision_options = False
            # Resume monitoring
            st.session_state.monitoring = True


def toggle_revision_options():
    """Toggle the display of revision options."""
    st.session_state.show_revision_options = not st.session_state.show_revision_options


def get_login_attempts_remaining() -> int:
    """Get the number of remaining login attempts."""
    max_attempts = 5
    return max_attempts - st.session_state.login_attempts


def toggle_password_visibility():
    """Toggle password visibility."""
    st.session_state.show_password = not st.session_state.show_password


def check_password(username: str, password: str) -> bool:
    """Check if the provided username and password are valid."""
    settings = get_settings()
    valid_username = settings.default_username
    valid_password_hash = settings.default_password_hash
    
    # Hash the provided password
    password_hash = hashlib.sha256(password.encode()).hexdigest()
    
    # Check if username and hashed password match
    return username == valid_username and password_hash == valid_password_hash


def login_form():
    """Display the login form."""
    st.markdown("## 🔐 Login")
    st.markdown("Please log in to access the Synthia Report Generator.")
    
    col1, col2 = st.columns([3, 1])
    with col1:
        username = st.text_input("Username", key="username_input")
        
        # Password field with show/hide toggle
        if st.session_state.show_password:
            password = st.text_input("Password", key="password_input")
        else:
            password = st.text_input("Password", type="password", key="password_input")
    
    with col2:
        st.markdown("<br>", unsafe_allow_html=True)  # Add space
        st.checkbox("Show password", key="show_pwd", on_change=toggle_password_visibility)
    
    login_button = st.button("Log In", type="primary")
    
    if login_button:
        ## FIXME: REMOVE THIS HARDCODED USERNAME AND PASSWORD!!!
        if not username or not password:
            st.error("Please enter both username and password.")
            return
        if check_password(username, password)  or get_token(username, password):
            st.session_state.username = username
            st.session_state.authenticated = True
            st.session_state.login_attempts = 0
            st.success("Login successful!")
            st.rerun()
        else:
            st.session_state.login_attempts += 1
            remaining_attempts = 5 - st.session_state.login_attempts
            if remaining_attempts > 0:
                st.error(f"Invalid username or password. {remaining_attempts} attempts remaining.")
            else:
                st.error("Too many failed login attempts. Please try again later.")
                st.session_state.login_attempts = 0

def render_user_sections(outline: List[Dict[str, Any]]) -> None:
    """Render user-defined sections for the report."""
    st.subheader("User-Defined Sections")
    
    dropdown_options = []
    for i, section in enumerate(outline):
         dropdown_options.append(i+1)
    
    selected_option = st.selectbox(
        "Select section to update",
        options=dropdown_options,
        index=0,
        key="section_view_select"
    )    
    user_prompt = st.text_area("LLM Section Prompt", "")

    if(selected_option is not None and user_prompt is not None and 
       user_prompt.strip() != ""):         
        # Check if the section already exists
        existing_section = next((s for s in st.session_state.user_sections if s["selected_option"] == selected_option), None)
        if existing_section:
            # Update existing section
            existing_section["selected_content"] = user_prompt
        else:
            # Add new section
            st.session_state.user_sections.append({
            "selected_option": selected_option,
            "selected_content": user_prompt,})
    
   


def ensure_chart_directory():
    """Ensure the chart directory exists for storing generated charts."""
    chart_dir = os.path.join(os.path.dirname(__file__), "chart_images")
    if not os.path.exists(chart_dir):
        os.makedirs(chart_dir)
        st.success(f"Created chart directory at {chart_dir}")
    return chart_dir

def normalize_image_path(image_path):
    """
    Normalize image path to improve image finding.
    1. If it's a full path to chart_images, leave it as is
    2. If it seems to be just a filename, make it relative to chart_images
    3. If it contains common image keywords like 'chart', 'graph', or company names, try to find matching files
    """
    if not image_path:
        return None
    
    # If already has chart_images in the path, leave it
    if "chart_images" in image_path:
        return image_path
    
    # If it seems to be a full URL or absolute path outside of our app, leave it
    if image_path.startswith(('http://', 'https://', '/')):
        return image_path
    
    # If it's just a filename, make it relative to chart_images
    if "/" not in image_path and "\\" not in image_path:
        return os.path.join(chart_images_dir, image_path)
    
    # Default - return as is
    return image_path

def approve_reject_final_report(job_id: str, approved: bool, feedback: Optional[str] = None) -> Dict[str, Any]:
    """Approve or reject a final report via API."""
    api_url = get_api_url()
    token = get_token()
    payload = {"approved": approved}
    if feedback is not None:
        payload["feedback"] = feedback
    try:
        response = requests.post(
            f"{api_url}/reports/{job_id}/approve-final-report",
            json=payload,
            headers={"Authorization": f"{token}"},
            timeout=60,
        )
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        st.error(f"Failed to approve/reject final report: {str(e)}")
        return None

def handle_approve_final_report():
    """Handle the approval of a final report."""
    job_id = st.session_state.job_id
    logger.info(f"Handling final report approval for job {job_id}")
    with st.spinner("Processing final approval..."):
        response = approve_reject_final_report(job_id, True)
        if response:
            st.success("Final report approved! Report generation completed.")
            logger.info(f"Final report approved for job {job_id}: {response}")
            st.session_state.awaiting_final_approval = False
            st.session_state.final_report_data = None
            st.session_state.monitoring = True

def handle_reject_final_report(feedback=None):
    """Handle the rejection of a final report."""
    job_id = st.session_state.job_id
    logger.info(f"Handling final report rejection for job {job_id} with feedback={feedback}")
    with st.spinner("Processing rejection and regenerating..."):
        response = approve_reject_final_report(job_id, False, feedback)
        if response:
            st.info("Final report rejected. Regenerating sections with your feedback.")
            logger.info(f"Final report rejected for job {job_id}: {response}")
            st.session_state.awaiting_final_approval = False
            st.session_state.final_report_data = None
            st.session_state.monitoring = True

def main():
    """Main Streamlit application."""
    logger.info("Starting Synthia main application")
        
    # Check authentication
    if not st.session_state.authenticated:
        logger.info("User not authenticated, showing login form")
        login_form()
        return

    logger.info("User authenticated, showing main application")
    
    # Sidebar for report configuration

    import requests

    if "uploaded_documents" not in st.session_state:
        st.session_state.uploaded_documents = []

    with st.sidebar:
        st.header("Report Configuration")
        
        # Add logout button at the top of sidebar
        if st.button("Logout"):
            st.session_state.authenticated = False
            st.rerun()
        
        topic = st.text_input("What company would like to create a report for?", "3001792")
        
        style = st.selectbox(
            "Report Template To Use",
            options=["", "company_analysis", "peer_analysis", "sector_analysis"],
            index=0,
        )

        disable_custom = style == ""  # True if no style is selected

        section_titles = load_section_options(style)
        section_titles_with_empty = [""] + section_titles
        input_section_title = st.selectbox(
            "Select Section Title",
            options=section_titles_with_empty,
            index=0,
            key="section_title_select",
            disabled=disable_custom
        )

        # --- Upload Documents Section ---
        st.header("Upload Documents")
        if "file_uploader_key" not in st.session_state:
            st.session_state.file_uploader_key = "file_uploader_default"

        uploaded_files = st.file_uploader(
            "Choose documents", type=["pdf"], accept_multiple_files=True, key=st.session_state.file_uploader_key
        )
        section_titles_input = []
        if uploaded_files:
            for idx, uploaded_file in enumerate(uploaded_files):
                # Use selectbox for section title, default to "General"
                section_title = st.selectbox(
                    f"Section Title for Document {uploaded_file.name}",
                    options=["General"] + section_titles,
                    index=0,
                    key=f"section_title_{idx}"
                )
                section_titles_input.append(section_title if section_title.strip() else "General")

            if st.button("Upload Selected Documents"):
                for idx, uploaded_file in enumerate(uploaded_files):
                    api_url = get_api_url() + "/upload-document"
                    with st.spinner(f"Uploading {uploaded_file.name}..."):
                        files = {"file": (uploaded_file.name, uploaded_file, uploaded_file.type)}
                        data = {
                            "username": st.session_state.username.lower(),
                            "section_title": section_titles_input[idx].strip().lower(),
                        }
                        response = requests.post(api_url, files=files, data=data)
                        if response.ok and response.json().get("success"):
                            s3_uri = response.json()["s3_uri"]
                            st.session_state.uploaded_documents.append({
                                "s3_uri": s3_uri,
                                "section_title": section_titles_input[idx].strip(),
                                "file_name": uploaded_file.name
                            })
                            st.success(f"Uploaded {uploaded_file.name} to {s3_uri}")
                        else:
                            st.error(
                                f"Upload failed for {uploaded_file.name}: {response.json().get('error', 'Unknown error')}"
                            )
                with st.spinner("Processing documents..."):
                    response = requests.post(get_api_url() + "/synchronize-kb")
                    if response.ok and response.json().get("success"):
                        st.success("Documents processed successfully.")
                    else:
                        st.error(f"Processing failed: {response.json().get('error', 'Unknown error')}")
                # Reset file uploader by changing its key
                import uuid
                st.session_state.file_uploader_key = str(uuid.uuid4())
                st.rerun()

        # --- Display mapping of uploaded documents and their associated sections ---
        if st.session_state.uploaded_documents:
            st.subheader("Uploaded Documents & Associated Sections")
            for doc in st.session_state.uploaded_documents:
                st.write(f"**{doc['file_name']}** → Section: `{doc['section_title']}`")

        
        depth = st.slider("Content Depth (1-5)", 1, 5, 3)
        sections = st.slider("Number of Sections", 1, 15, 5)
        start_button = st.button("Generate Report", type="primary")
        
        if st.session_state.job_id:
            if st.button("Reset"):
                # --- Reset all report-related session state ---
                st.session_state.job_id = None
                st.session_state.report_data = None
                st.session_state.monitoring = False
                st.session_state.awaiting_approval = False
                st.session_state.outline_data = None
                st.session_state.user_sections = []
                st.session_state.outline_approved = False
                st.session_state.outline_rejected = False
                st.session_state.show_rejection_options = False
                st.session_state.revision_submitted = False
                st.session_state.show_revision_options = False
                st.session_state.last_status_check = None
                st.session_state.awaiting_final_approval = False
                st.session_state.final_report_data = None
                # --- End reset ---
                st.rerun()
        
        if (st.session_state.job_id and 
            st.session_state.awaiting_approval):
            if(st.session_state.outline_data is not None and 
               len(st.session_state.outline_data) > 0):
                render_user_sections(st.session_state.outline_data)
    
    # Main area - handle report generation flow
    if start_button and not st.session_state.job_id:
        logger.info(f"Starting new report generation: topic={topic}, style={style}, depth={depth}, sections={sections}")
        with st.spinner("Starting report generation..."):
            job_id = start_report_generation(topic, style, depth, sections, input_section_title)
            if job_id:
                logger.info(f"Report generation started successfully with job ID: {job_id}")
                st.session_state.job_id = job_id
                st.session_state.monitoring = True
                st.success(f"Report generation started! Job ID: {job_id}")
                st.rerun()
            else:
                logger.error("Failed to start report generation - no job ID returned")
    
    # If we have an active job, monitor progress
    if st.session_state.job_id and st.session_state.monitoring:
        logger.info(f"Monitoring job {st.session_state.job_id}")
        st.subheader(f"Report Generation Progress")
        st.code(f"Job ID: {st.session_state.job_id}")
        status_placeholder = st.empty()
        report_placeholder = st.empty()
        
        # Create expander for detailed job information
        with st.expander("Job Details"):
            st.code(f"Job ID: {st.session_state.job_id}")
            
            if st.button("Stop Monitoring"):
                st.session_state.monitoring = False
                st.rerun()
        
        # Monitor progress
        while st.session_state.monitoring:
            status_data = get_report_status(st.session_state.job_id)
            
            if status_data:
                current_status = status_data.get('status')
                awaiting_final = status_data.get('awaiting_final_approval', False)
                final_report = status_data.get("final_report", "")
                logger.info(f"Job {st.session_state.job_id} status update: status={current_status}, awaiting_approval={status_data.get('awaiting_approval')}, awaiting_final_approval={awaiting_final}")
                
                with status_placeholder.container():
                    display_progress_metrics(status_data)
                    
                # Check if outline needs approval
                if current_status == "awaiting_approval" or status_data.get('awaiting_approval'):
                    outline = status_data.get('outline')
                    if outline:
                        logger.info(f"Job {st.session_state.job_id} needs outline approval, stopping monitoring")
                        st.session_state.outline_data = outline
                        st.session_state.awaiting_approval = True
                        st.session_state.monitoring = False  # Stop monitoring to show approval UI
                        st.rerun()
                
                # Continue monitoring during report creation phase
                elif current_status == "creating_report" or current_status == "outline_approved":
                    # Keep polling during report creation
                    pass
                
                # Check if final report needs approval - remove deprecated statuses
                elif current_status == "awaiting_final_approval" or awaiting_final:
                    final_report = status_data.get("final_report")
                    if final_report:
                        st.session_state.final_report_data = final_report
                        st.session_state.awaiting_final_approval = True
                        st.session_state.monitoring = False
                        st.rerun()
                
                # Check if report is completed
                elif current_status == "completed":
                    sections = status_data.get("sections", [])
                    if sections:
                        st.session_state.report_data = sections
                    st.session_state.monitoring = False
                    st.success("Report generation completed!")
                    st.rerun()
                
                # Show the partial report if there's any data
                elif status_data.get("sections"):
                    sections = status_data.get("sections", [])
                    with report_placeholder.container():
                        st.subheader(f"Report Preview - {len(sections)} sections completed")
                        st.caption(f"Status: {status_data.get('status')} - Current section: {status_data.get('current_section_idx', 0)}")
                        render_report(sections)
                
                # Check if there was an error
                elif status_data.get("status") == "failed":
                    st.error(f"Report generation failed: {status_data.get('error')}")
                    st.session_state.monitoring = False
            
            # Only wait if we're still monitoring
            if st.session_state.monitoring:
                time.sleep(5)  # polling interval
    
    # If monitoring is off but we have a job ID, just show status
    elif st.session_state.job_id and not st.session_state.monitoring:
        status_data = get_report_status(st.session_state.job_id)
        if status_data:
            st.subheader("Report Status")
            st.code(f"Job ID: {st.session_state.job_id}")
            display_progress_metrics(status_data)
    
    # Handle outline approval outside the monitoring loop
    if st.session_state.job_id and st.session_state.awaiting_approval and st.session_state.outline_data:
        logger.info(f"Showing outline approval UI for job {st.session_state.job_id}")
        with st.container():
            st.subheader("📋 Outline Approval (Step 1/2)")
            st.info("Please review the following outline and approve or reject it.")
            
            # Display the outline
            render_outline(st.session_state.outline_data)
            
            col1, col2 = st.columns(2)
            with col1:
                # Remove form wrapper to eliminate borders
                approve_clicked = st.button("✅ Approve Outline", type="primary", key="approve_outline_btn")
                if approve_clicked:
                    logger.info("Approve outline button clicked")
                    success = handle_approve_outline()
                    if success:
                        logger.info("Outline approval successful, rerunning app")
                        st.rerun()
                    else:
                        logger.error("Outline approval failed")
            
            with col2:
                # Remove form wrapper to eliminate borders
                reject_clicked = st.button("❌ Reject & Start Over", key="reject_outline_btn")
                if reject_clicked:
                    logger.info("Reject outline button clicked - resetting job")
                    # Reset to start over completely
                    st.session_state.job_id = None
                    st.session_state.report_data = None
                    st.session_state.monitoring = False
                    st.session_state.awaiting_approval = False
                    st.session_state.outline_data = None
                    st.session_state.user_sections = []
                    st.session_state.outline_approved = False
                    st.session_state.outline_rejected = False
                    st.session_state.show_rejection_options = False
                    st.session_state.revision_submitted = False
                    st.session_state.last_status_check = None
                    st.session_state.awaiting_final_approval = False
                    st.session_state.final_report_data = None
                    logger.info("Job reset completed")
                    st.info("Job reset. Please configure and start a new report generation.")
                    st.rerun()

    # Final report approval step
    if st.session_state.job_id and st.session_state.awaiting_final_approval:
        logger.info(f"Rendering final approval UI. job_id: {st.session_state.job_id}, awaiting_final_approval: {st.session_state.awaiting_final_approval}, final_report_data length: {len(st.session_state.final_report_data) if st.session_state.final_report_data else 'None'}")
        with st.container():
            st.subheader("📄 Final Report Approval (Step 2/2)")
            st.info("Please review the final report and approve or provide feedback for regeneration.")
            # --- FIX: Always fetch latest status_data to get final_report ---
            status_data = get_report_status(st.session_state.job_id)
            final_report = None
            if status_data:
                final_report = status_data.get("final_report")
                if final_report:
                    st.session_state.final_report_data = final_report
            # --- END FIX ---

            if st.session_state.final_report_data:
                st.markdown(
                    """
                    <style>
                    .report-container {
                        max-width: 1200px;
                        margin-left: auto;
                        margin-right: auto;
                        overflow-x: auto;
                        padding: 1rem;
                    }
                    </style>
                    """,
                    unsafe_allow_html=True,
                )
                logger.info("Rendering final report with sections.")
                tab1, tab2 = st.tabs(["Formatted Report", "Raw Data"])
                with tab1:
                    with st.container():
                        st.markdown('<div class="report-container">', unsafe_allow_html=True)
                        try:
                            # --- FIX: Always parse final_report_data as JSON array of sections ---
                            report_sections = json.loads(st.session_state.final_report_data)
                            if isinstance(report_sections, list):
                                render_report(report_sections)
                            else:
                                st.markdown(st.session_state.final_report_data, unsafe_allow_html=True)
                        except Exception:
                            st.markdown(st.session_state.final_report_data, unsafe_allow_html=True)
                        st.markdown('</div>', unsafe_allow_html=True)
                        # Show report generation time if available
                        if status_data and status_data.get("completed_at"):
                            st.info(f"Report generation time: {status_data['completed_at']}")

                        
                        logger.info("Before delete block")
                        
                        # Delete the documents from S3 prop data store
                        if "uploaded_documents" in st.session_state and st.session_state.uploaded_documents:
                            delete_api_url = get_api_url() + "/delete-document"
                            response = requests.delete(
                                delete_api_url,
                                data={"username": st.session_state.username.lower()}  # Ensure username is lowercase for consistency
                            )
                            # Clear uploaded documents from sidebar after deletion
                            st.session_state.uploaded_documents = []
                with tab2:
                    st.code(st.session_state.final_report_data, language="json")
                
                # --- Add Approve and Regenerate buttons ---
                feedback_text = st.text_area("Feedback for Regeneration (optional)", 
                                             placeholder="Provide specific feedback if you want to reject and regenerate...")
                col1, col2 = st.columns(2)
                with col1:
                    if st.button("✅ Approve Final Report", type="primary"):
                        handle_approve_final_report()
                        st.session_state.monitoring = True
                        st.rerun()
                with col2:
                    if st.button("🔄 Regenerate"):
                        handle_reject_final_report(feedback_text if feedback_text.strip() else None)
                        st.session_state.monitoring = True
                        st.rerun()
                # --- End buttons ---
            else:
                st.error("No final report data available for approval.")
                st.write("Debug info:")
                st.write(f"- Job ID: {st.session_state.job_id}")
                st.write(f"- Awaiting final approval: {st.session_state.awaiting_final_approval}")
                st.write(f"- Final report data: {st.session_state.final_report_data}")
                if st.button("Refresh Status"):
                    st.session_state.monitoring = True
                    st.rerun()
    if st.session_state.report_data:
        st.header("Generated Report")
        report_json = json.dumps(st.session_state.report_data, indent=2)
        st.download_button(
            label="Download Report JSON",
            data=report_json,
            file_name=f"synthia_report_{st.session_state.job_id}.json",
            mime="application/json",
        )
        tab1, tab2 = st.tabs(["Formatted Report", "Raw Data"])
        with tab1:
            render_report(st.session_state.report_data)
            status_data = get_report_status(st.session_state.job_id)
            if status_data and status_data.get("completed_at"):
                st.info(f"Report generation time: {status_data['completed_at']}")
        with tab2:
            st.json(st.session_state.report_data)
        
        # Delete S3 object after report is generated
        if "uploaded_document" in st.session_state and st.session_state.uploaded_document:
            logging.info(f"delete document {st.session_state.uploaded_document}")
            delete_api_url = get_api_url() + "/delete-document"
            response = requests.delete(
                delete_api_url,
                data={"username": st.session_state.username.lower()}  # Ensure username is lowercase for consistency
            )


if __name__ == "__main__":
    logger.info("Synthia application starting...")
    # Call this early in your app startup
    chart_dir = ensure_chart_directory()
    logger.info(f"Chart directory ensured at: {chart_dir}")
    main()
    
