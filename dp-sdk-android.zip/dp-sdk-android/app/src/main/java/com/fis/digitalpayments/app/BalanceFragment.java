// Copyright Notice!
// This document is protected under the trade secret and copyright
// laws as the property of Fidelity National Information Services, Inc.
// Copying, reproduction or distribution should be limited and only to
// employees with a “need to know” to do their job.
// Any disclosure of this document to third parties is strictly prohibited.
// © 2016 Fidelity National Information Services.
// All rights reserved worldwide.

package com.fis.digitalpayments.app;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.fis.digitalpayments.sdk.messaging.ProductType;
import com.fis.digitalpayments.sdk.messaging.WebEventType;
import com.fis.digitalpayments.sdk.mobile_payments.R;

import org.jetbrains.annotations.NotNull;

import java.util.HashMap;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link BalanceFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link BalanceFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class BalanceFragment extends Fragment {

    @SuppressWarnings("unused")
    private OnFragmentInteractionListener mListener;

    public BalanceFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment BalanceFragment.
     */
    @SuppressWarnings("unused")
    public static BalanceFragment newInstance(String param1, String param2) {
        return new BalanceFragment();
    }

    @Override
    public View onCreateView(@NotNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_balance, container, false);

        Bundle data = getArguments();
        if (data != null) {
            String eventId = data.getString("eventId");
            WebEventType eventType = (WebEventType) data.getSerializable("eventType");
            ProductType productType = (ProductType) data.getSerializable("productType");
            @SuppressWarnings("unchecked") HashMap<String, String> params = (HashMap<String, String>) data.getSerializable("params");

            ((MainActivity)getActivity()).toastEvent(getContext(), eventId, eventType, productType, params);
        }

        final Button button = view.findViewById(R.id.restart_button);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                ((OnFragmentInteractionListener)getActivity()).onBalanceFragmentInteraction(null);
            }
        });

        // Inflate the layout for this fragment
        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    @SuppressWarnings("unused")
    public interface OnFragmentInteractionListener {
        void onBalanceFragmentInteraction(Uri uri);
    }
}
