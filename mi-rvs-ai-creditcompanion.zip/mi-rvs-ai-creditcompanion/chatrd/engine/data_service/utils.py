import ast
import csv
import json
import logging
from io import StringIO
from typing import Dict, List

from chatrd.engine.configuration import get_config_machinery

logger = logging.getLogger(__name__)
config_machinery = get_config_machinery()


def parse_csv_string(csv_string: str) -> List[Dict[str, str]]:
    """
    Parses a multi-line CSV-formatted string into a list of dictionaries.

    Args:
        csv_string (str): A string containing CSV data, including a header row.

    Returns:
        List[Dict[str, str]]: A list of dictionaries representing each row in the CSV string.
    """
    csv_io = StringIO(csv_string.strip())
    reader = csv.DictReader(csv_io)
    return [row for row in reader]


def is_valid_json(string):
    try:
        json.loads(string)
        return True
    except (json.JSONDecodeError, TypeError):
        return False


def convert_response_to_dict_for_screener(query_string: str) -> Dict:
    """
    Convert the response string to a dictionary. Necessary for extracting all relevant
    information for creating payload.

    Args:
        query_string (str): response string from LLM

    Returns:
        response_dict (dict): converted response in dictionary form
    """
    try:
        logger.debug(f"The query string is {query_string}")
        response_dict = ast.literal_eval(query_string)
        return response_dict
    except (ValueError, SyntaxError) as error:
        logger.error(f"Parse the string {query_string} to dict failed with this error " f"message {error}.")
    return dict()


def get_rd_sector(entities):
    """
    Retrieves the R&D sector information of the first company in the list.

    Args:
        entities (dict): A dictionary containing entity lists.

    Returns:
        list: The R&D sector of the first company in the list, or an empty list if unavailable.
    """
    if entities and "companies" in entities and entities["companies"]:
        return entities["companies"][0].get("rd_sector") or []
    return []


def get_entity_type(entities):
    """
    Determines the entity type.

    Args:
        entities (dict): A dictionary containing entity lists, the keys are
                         'companies', 'securities', and 'revenue_sources'.

    Returns:
        str: One of 'company', 'security', or 'revenue_source',
             or an empty string if no entity is found.
    """
    if not entities:
        return ""

    if "companies" in entities and entities["companies"]:
        return "company"
    elif "securities" in entities and entities["securities"]:
        return "security"
    elif "revenue_sources" in entities and entities["revenue_sources"]:
        return "revenue_source"

    return ""
