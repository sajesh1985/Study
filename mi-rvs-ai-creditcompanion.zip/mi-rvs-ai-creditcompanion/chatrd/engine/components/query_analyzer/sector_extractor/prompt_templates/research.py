RESEARCH_SECTOR_EXAMPLES = """
__________________
{
    "question": "What is the average credit rating for xyz industries in 2024?",
    "answer": {
        "entities": ["xyz"],
    }
}
__________________
{
    "question": "How might changes in trade policies affect credit ratings of xyz sectors in the United States?",
    "answer": {
        "entities": ["xyz"],
    }
}
__________________
{
    "question": "What impact do ESG factors have on the credit rating of xyz and abc sectors?",
    "answer": {
        "entities": ["xyz", "abc"]
    }
}
__________________
{
    "question": "What is the ESG Profile/factors of eastern European countries?",
    "answer": {
        "entities": []
    }
}
__________________
{
    "question": "What is the rating of xyz company?",
    "answer": {
        "entities": []
    }
}
__________________
{
    "question": "What are the financial trends of xyz sector according to S&P Global Ratings?",
    "answer": {
        "entities": ["xyz"]
    }
}
__________________
{
    "question": "What was the latest Rating and credit watch outlook for the state of xyz?",
    "answer": {
        "entities": []
    }
}
__________________
{
    "question": "What are the ratings for aaa, bbb and ccc industries?",
    "answer": {
        "entities": ["aaa", "bbb", "ccc"]
    }
}
__________________
{
    "question": "What was the previous outlook for xyz industry?",
    "answer": {
        "entities": ["xyz"]
    }
}
__________________
{
    "question": "write me a credit analysis on xyz and abc programs with financials",
    "answer": {
        "entities": []
    }
}
_______________
{
    "question": "Where will interest rates go in the next 2 years?",
    "answer": {
        "entities": []
    }
}
_______________
{
    "question": "Make a SWOT analysis of xyz co. compared to abc co.",
    "answer": {
        "entities": []
    }
}
_______________
{
    "question": "write me a credit research report for aaa inc, bbb corp and ccc llc",
    "answer": {
        "entities": []
    }
}
_______________
{
    "question": "",
    "answer": {
        "entities": []
    }
}
_______________
{
    "question": "what is the rating of xyz university?",
    "answer": {
        "entities": []
    }
}
"""

RESEARCH_SECTOR_PROMPTS = """
You will receieve a request from the user and your task is to extract the excerpts from the provided input containing the general industry names. The input request is related to the financial performance, credit ratings, and other financial aspects of various industries. You must adhere strictly to the following guidelines to complete the task:
    * Extract explicit references to industry names from the provided input. Ensure that the industry reference is extracted precisely from the given input question and not generated randomly. If the question contains multiple explicit references to a sectors or industries, return all of them. Otherwise, return an empty list.
    * If the question contains names of directly mentioned entities such as company names or geographical names, do not, under any circumstances, attempt to retrieve them or their industry using your internal knowledge. Keep in mind that these entities could be in abbreviated or complex form. For better understanding, here are some examples of complex entity names which should not be extracted: 'honeywell international inc.', 'Wells Fargo & Company', 'Yoakum Indpt Sch Dist, TX Permanent School Fund Program', 'Barry Cnty R-IV Sch Dist (Cassville), MO Direct Deposit State Aid Program', 'Addison, TX Limited Tax General Operating Pledge', 'Yale Univ, CT General Obligation', 'XYZ Trust', 'XYZ school', 'XYZ company', 'XYZ bank'.
    * Do not provide any explanations at all. If you hit the limit or are unable to provide the requested information, just return the resulting JSON object at the output.
    * Output: (key: entities)

<Examples of pairs of questions (key: question) and answers (key: answer) are given below in JSON format. Do not adhere strictly to the answer values shown in the examples, as they are only meant to provide hints.>
{examples}

Take a deep breath and understand that these examples should not affect the extractions for any other keys.

The answer is a JSON object that must contain the following key:
- "entities"

<Question>
{question}

Just return the resulting JSON object as the output.
"""
