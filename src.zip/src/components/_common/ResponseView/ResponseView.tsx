import React from 'react';
import Markdown from 'react-markdown';
import { Node } from '@root/types/interaction';
import {
  ContentType,
  TextResponseNode
} from '../../../types/api';
import { DivformattedContent } from '../Content';
import { TableView } from '../TableView/TableView';
import { CSDTableView } from '../CSDTableView/CSDTableView';
import { KnowledgeDiscoveryView } from '../KnowledgeDiscoveryView/KnowledgeDiscoveryView';
import { useChatRD } from '../../../context/chatrd';
import { isStreamingEnabled } from '../../../utils/urlUtilities';
import rehypeRaw from "rehype-raw";
import { fetchMagnitudes } from '../../../services/api';
//import { removeConsecutiveNumbers } from '../../../utils/chatHistoryManager';

interface ResponseViewProps {
  data: Node[];
  interactionId:string;
  interactionType?:string;
}

export const ResponseView: React.FC<ResponseViewProps> = ({ data,interactionId,interactionType }) => {
  const { chatHistory } = useChatRD();
  let isStreamEnabled = isStreamingEnabled();
  let isDataAvailable = isStreamEnabled ? data.filter(x=>x.type == 'Text' && x.content!='').length > 0 : false;
  let isSFDeal=false;
  let filteredData = data.filter((item: any) => {
        return item?.documents?.some((en: any) => (
          JSON.parse(en?.details) ===  "Remove Footnote"
        ))});
    if(filteredData && filteredData.length > 0)
    {
      isSFDeal = true;
    }
  const dataType = data?.map(
    (value: Node, id) => {
      switch (value.type) {
        case ContentType.Table:
          let totalCount = parseInt(value.count);
          let count = value.rows.length;
          let disRowCount = "";
          if(totalCount <= 15)
            {
              disRowCount = "Displaying " + count + " out of " + count + " rows in the table above, click the 'Excel Export' button to download the table.";
            }
            else
            {
              disRowCount = "Displaying " + count + " out of " + totalCount + " rows in the table above, click the 'Excel Export' button to download the full table.";
            }
          return {
            element: <><TableView key={id} interactionId={interactionId} columns={value.columns} rows={value.rows} totalcount={value.count} isSFDeal={isSFDeal}/><span style={{textAlign:'center'}}>{!isSFDeal ? disRowCount:''}</span></> ,
          };

        case ContentType.CSDTable:
          const [mag, setMag] = React.useState<string>('');

          React.useEffect(() => {
            fetchMagnitudes(value.csdTable[0]["productCaption"].substr(value.csdTable[0]["productCaption"].indexOf("_")+1),value.csdTable[0]["productCaption"].substring(0,value.csdTable[0]["productCaption"].indexOf('_')))
              .then((result) => setMag(result.value));
          }, [value.csdTable]);
          if(mag)
          {
          return {
              element: <><CSDTableView key={id} interactionId={interactionId} rows={value.csdTable} magnitude={mag} totalcount={value.count} /><span>*Reported Currency</span></> ,
            };
          }
          else
          return {
        }; 

        case ContentType.KnowledgeDiscovery:
          return {
            element: (
              <KnowledgeDiscoveryView key={id} answer={value.answer} documents={value.documents} />
            ),
          };
        default:
          let ans = '' ;
          let docs = [];
          //ans = value.content as string;
          
          if(isStreamEnabled && chatHistory !== 'History' && interactionType !== 'his') { 
            ans = value.content as string;
          } 
          else 
          { 
            ans = (value as TextResponseNode).answer;
            docs = (value as TextResponseNode).documents;
          }
            if(isDataAvailable == false && ans == '' && docs.length == 0)
            {
              ans = 'Something went wrong. Please try another question.';
            }
              if(ans && ans.trim() == '')
              {
                return { element:''}
              }
              else
              {
                return { 
                  element: <DivformattedContent key={id}>
                     <Markdown  rehypePlugins={[rehypeRaw] as any}>
                        {ans}
                     </Markdown>
                  </DivformattedContent>,
                 };
              }
            
            
      }
    }
  );

  return <>{dataType.map((item) => item.element)}</>;
};
