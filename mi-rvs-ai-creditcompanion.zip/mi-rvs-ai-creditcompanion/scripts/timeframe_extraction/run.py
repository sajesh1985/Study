from chatrd.engine.components.query_analyzer.filter_retrievers.prompts import (
    TIME_THRESHOLD_PROMPT_DATE_OUTPUT_UNSTRUCTURED,
    output_parser_time_threshold_dates,
    empty_instructions_string,
    time_threshold_date_additional_examples_string,
)

from datetime import date
from dateutil.relativedelta import relativedelta         
from chatrd.engine.components.query_analyzer.filter_retrievers.time_threshold import (
    TimeThresholdFilter,
)

# Current unstructured version - for past events in this year PeriodEnd: today
date_retriever_date_output_unstructured = TimeThresholdFilter(
    uc_specific_prompt=TIME_THRESHOLD_PROMPT_DATE_OUTPUT_UNSTRUCTURED,
    output_parser=output_parser_time_threshold_dates,
    specific_instructions_fn=empty_instructions_string,
    examples_fn=time_threshold_date_additional_examples_string,
)


test_questions_dates = [ 
    # "Show me all articles from last two weeks", 
    # "Were there any important economic announcements last quarter?", 
    # "What is the highest income of company ABC reported previous 5 years?", 
    # "What was company's AAA previous year income tax?", 
    # "Show me all rating actions for the medical companies taking place in last year", 
    # "Show me all German companies whose rating was downgraded inside the previous half-year", 
    # "What was the growth rate of EU GDP during last year?", 
    # "List all important articles about Canadian fishing industry published within last year?", 
    # "Were there any changes of credit rating of Italy confined to last three years?", 
    # "Has FED suggested what the interest rates will be next year?", 
    # "What are the expectations about GDP growth in the next year?",
    # "What will the inflation be inside next two years?", 
    # "How many times will FED meet within next two quarters?", 
    # "Will company ABC pay a dividend within next year?", 
    # "What are the global credit conditions Q1 2025?", 
    # "What are the global credit conditions Q2 2025?", 
    # "What's the forecast for commodity prices (e.g., oil, gold) in 2025?", 
    # "What are the global credit conditions in 2025?", 
    # "What are the real estate market conditions in 2025?", 
    # "What economic scenarios are projected to influence global trade in 2025?", 
    # "How has the company xyz been performing this year so far?", 
    # "Show me EBIDTA changes that happend in 2025?", 
    # "Give me the outlook for xyz using publications from 2025", 
    # "Show me securities for XYZ with maturity date this year", 
    # "Show me articles for XYZ published in 2025", 
    # "What has been the growth rate of EU GDP this year?", 
    # "What companies have defaulted in this year?", 
    # "What articles have been published in 2025?", 
    # "What is the projected GDP growth rate for Europe in 2025?", 
    # "Will central banks tighten monetary policy in Q3 2025?", 
    # "provide real estate updates within life insurance companies using articles from last 6 months", 
    # "provide real estate updates within life insurance companies using articles from this year",
    # "Which IPO lock-up periods expire this year?", 
    # "Which IPO lock-up periods expire this quarter?", 
    # "What options are expiring in 2025?", 
    # "show me all bonds maturing in 2025" 
    # "show me all bonds maturing in 2025", 
    # "Has FED suggested any interest rates recently?", 
    # "What is the outlook for oil and gas industry?",
    # "what are the expected inflation trends within next year?",
	# "How did corporate profit margins trend throughout Q1 2025?",
	# "Which equity markets performed best in last quarter?",
	# "How did the corporate margin changed between 2022 and 2025?",
    # "what securities issued by company ABC are due this quarter?",
    # "list securities issued by mining companies which are due this quarter?",
    # "List all FED meetings for this quarter",
    # "List all important regulations coming into effect this quarter in the mining sector?"
]

for i, q in enumerate(test_questions_dates):
    print(f"{i}. {q}")
    ans = date_retriever_date_output_unstructured.invoke(
        user_question=q,
        today_date=date.today(),
        today_date_year=date.today().year,
        last_year=date.today().year - 1,
        today_date_minus_year=date.today()+relativedelta(years=-1),
        )
    print(ans)
