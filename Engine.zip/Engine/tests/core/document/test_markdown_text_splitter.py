"""Test cases for MarkdownHeaderTextSplitter to ensure it works similarly to the original code from langchain."""

import pytest

from chatrd.core.document.media import MediaDocument
from chatrd.core.document.text_splitters import MarkdownHeaderTextSplitter

markdown_text = """
# Title
Content under Title
## Subtitle
Content under Subtitle
### Section 1
Content under Section 1.
### Section 2
Content under Section 2.
"""
md_rows = markdown_text.strip().split("\n")
docs_with_full_content = [
    MediaDocument(metadata={"Header 1": "Title"}, page_content="\n".join(md_rows[1:])),
    MediaDocument(metadata={"Header 1": "Title", "Header 2": "Subtitle"}, page_content="\n".join(md_rows[3:])),
    MediaDocument(
        metadata={"Header 1": "Title", "Header 2": "Subtitle", "Header 3": "Section 1"},
        page_content="Content under Section 1.",
    ),
    MediaDocument(
        metadata={"Header 1": "Title", "Header 2": "Subtitle", "Header 3": "Section 2"},
        page_content="Content under Section 2.",
    ),
]
docs_with_local_content = [
    MediaDocument(metadata={"Header 1": "Title"}, page_content="Content under Title"),
    MediaDocument(metadata={"Header 1": "Title", "Header 2": "Subtitle"}, page_content="Content under Subtitle"),
    MediaDocument(
        metadata={"Header 1": "Title", "Header 2": "Subtitle", "Header 3": "Section 1"},
        page_content="Content under Section 1.",
    ),
    MediaDocument(
        metadata={"Header 1": "Title", "Header 2": "Subtitle", "Header 3": "Section 2"},
        page_content="Content under Section 2.",
    ),
]
all_headers = [(size * "#", f"Header {size}") for size in range(1, 7)]


class TestMarkdownHeaderTextSplitterSplitText(object):
    """Test cases for the MarkdownHeaderTextSplitter class."""

    @pytest.mark.parametrize(
        "markdown_text, headers_to_track, expected_output",
        [
            (markdown_text, all_headers[:1], docs_with_full_content[:1]),
            (markdown_text, all_headers[:2], [docs_with_local_content[0], docs_with_full_content[1]]),
            (markdown_text, all_headers, docs_with_local_content),
        ],
    )
    def test_split_markdown_with_mixed_headers_and_content(self, markdown_text, headers_to_track, expected_output):
        """Test splitting markdown text with headers."""
        splitter = MarkdownHeaderTextSplitter(headers_to_split_on=headers_to_track)

        chunks = splitter.split_text(markdown_text)
        assert isinstance(chunks, list)
        assert len(chunks) == len(expected_output)
        for chunk, expected in zip(chunks, expected_output):
            assert isinstance(chunk, MediaDocument)
            assert (
                chunk.metadata == expected.metadata
            ), f"Metadata mismatch: {chunk.metadata} not equals {expected.metadata}"
            assert (
                chunk.page_content == expected.page_content
            ), f"Content mismatch: {chunk.page_content} not equals {expected.page_content}"

    def test_split_empty_markdown(self):
        """Test splitting an empty markdown text."""
        markdown_text = ""
        splitter = MarkdownHeaderTextSplitter(
            [
                ("#", "Header"),
            ]
        )

        chunks = splitter.split_text(markdown_text)
        assert chunks == []

    def test_split_markdown_with_no_headers(self):
        """Test splitting an empty markdown text."""
        markdown_text = "This is a paragraph without headers."
        splitter = MarkdownHeaderTextSplitter(all_headers)

        chunks = splitter.split_text(markdown_text)
        assert len(chunks) == 1
        assert isinstance(chunks[0], MediaDocument)
        assert chunks[0].page_content == markdown_text
        assert chunks[0].metadata == {}

    def test_split_markdown_with_no_content_under_header(self):
        """Test splitting markdown text with headers but no content under them."""
        markdown_text = "# Title\n## Subtitle\n### Section"
        splitter = MarkdownHeaderTextSplitter(all_headers)

        chunks = splitter.split_text(markdown_text)
        assert chunks == []

    # Testing function aggregate_lines_to_chunks
    def test_aggregate_empty_lines(self):
        """Test aggregation of empty lines into chunks."""
        splitter = MarkdownHeaderTextSplitter(all_headers)
        lines = []

        aggregated_chunks = splitter.aggregate_lines_to_chunks(lines)
        assert aggregated_chunks == []

    def test_aggregate_lines_to_chunks_with_empty_content(self):
        """Test aggregation of lines with empty content."""
        splitter = MarkdownHeaderTextSplitter(all_headers)
        lines = [{"content": "", "metadata": {"Header 1": "Title"}}]

        aggregated_chunks = splitter.aggregate_lines_to_chunks(lines)
        assert len(aggregated_chunks) == 1
        assert isinstance(aggregated_chunks[0], MediaDocument)
        assert aggregated_chunks[0].page_content == ""
        assert aggregated_chunks[0].metadata == {"Header 1": "Title"}

    def test_aggregate_lines_to_chunks_without_headers(self):
        """Test aggregation of lines without headers."""
        splitter = MarkdownHeaderTextSplitter(all_headers)
        lines = [{"content": "This is a paragraph.", "metadata": {}}]

        aggregated_chunks = splitter.aggregate_lines_to_chunks(lines)
        assert len(aggregated_chunks) == 1
        assert isinstance(aggregated_chunks[0], MediaDocument)
        assert aggregated_chunks[0].page_content == "This is a paragraph."
        assert aggregated_chunks[0].metadata == {}

    def test_aggregate_lines_to_chunks_with_full_content(self):
        """Test aggregation of lines into chunks."""
        splitter = MarkdownHeaderTextSplitter(all_headers)
        lines = [{"content": doc.page_content, "metadata": doc.metadata} for doc in docs_with_full_content]

        aggregated_chunks = splitter.aggregate_lines_to_chunks(lines)
        assert len(aggregated_chunks) == 4
        for idx, chunk in enumerate(aggregated_chunks):
            assert isinstance(chunk, MediaDocument)
            assert chunk == docs_with_full_content[idx]

    def test_aggregate_lines_to_chunks_with_local_content(self):
        """Test aggregation of lines into chunks with local content."""
        splitter = MarkdownHeaderTextSplitter(all_headers)
        lines = [{"content": doc.page_content, "metadata": doc.metadata} for doc in docs_with_local_content]

        aggregated_chunks = splitter.aggregate_lines_to_chunks(lines)
        assert len(aggregated_chunks) == 4
        for idx, chunk in enumerate(aggregated_chunks):
            assert isinstance(chunk, MediaDocument)
            assert chunk == docs_with_local_content[idx]
