import logging
from datetime import datetime
from typing import Optional

from chatrd.core.llm import LCLLMFactory
from chatrd.core.llm.components.message import AIMessage
from chatrd.core.llm.parsers import PydanticOutputParser
from chatrd.core.llm.prompt.template import SimplePromptTemplate
from chatrd.core.thread_utils import submit_to_shared_thread_pool
from chatrd.engine.configuration import get_config_machinery
from chatrd.engine.data_service.analyzer.base import BaseAnalyzer
from chatrd.engine.data_service.analyzer.prompts.prompts import (
    RATINGS_CURRENT_OR_HISTORICAL_OUTPUT_PARSER_TEMPLATE,
    RatingsQuestionFilters,
    examples_ratings_current_or_historical_formatted,
    prompt_from_perspectives,
)
from chatrd.engine.data_service.perspectives import default_perspectives
from chatrd.engine.data_service.schema import Analyzer, ProcessorInput
from chatrd.engine.data_service.utils import convert_response_to_dict_for_screener

logger = logging.getLogger(__name__)

config_machinery = get_config_machinery()


class RatingsAnalyzer(BaseAnalyzer):
    """Query Analyzer for Ratings use case.
    Retrieving from query information about ratings type (recent ratings / historical ratings)
    """

    def __init__(self, vector_database_path: Optional[str] = None):
        self.vector_database_path = vector_database_path

        self.output_parser = PydanticOutputParser(pydantic_object=RatingsQuestionFilters)
        self.prompt_template = SimplePromptTemplate(
            template=RATINGS_CURRENT_OR_HISTORICAL_OUTPUT_PARSER_TEMPLATE,
            partial_variables={
                "format_instructions": self.output_parser.get_format_instructions(),
            },
        )

    def analyze(self, processor: ProcessorInput) -> Analyzer:
        user_input = processor.user_input
        uc_type = processor.uc_type
        if processor.uc_type not in ["ratings", "outlook"]:
            return Analyzer()

        self.model_for_data_service = LCLLMFactory().get_llm(
            deployment_name_or_model_id=processor.llm,
            temperature=processor.temperature,
        )

        # entity extraction
        prompt_template = prompt_from_perspectives(
            perspectives=default_perspectives(vectors_path=self.vector_database_path), user_input=user_input
        )

        future_invoke = submit_to_shared_thread_pool(self.model_for_data_service.invoke, prompt_template)
        response_dict = {}

        # ds tag
        current_year = datetime.now().year
        question_prompt = self.prompt_template.format(
            question=user_input,
            current_year=current_year,
            examples_ratings_current_or_historical_formatted=examples_ratings_current_or_historical_formatted(
                current_year
            ),
        )
        future_ds_invoke = submit_to_shared_thread_pool(self.model_for_data_service.invoke, question_prompt)

        try:
            response = future_invoke.result()
            if isinstance(response, AIMessage):
                response = response.content
            response = response.strip().lower().replace(".", "").split("\n\n")[0]
            response_dict = convert_response_to_dict_for_screener(response)
        except Exception as e:
            logger.error(f"Error in converting response to dict: {e}")
            response_dict = dict()
        logger.info(f"\nCompany Query Analyzer output : \n{response_dict}")

        try:
            output = future_ds_invoke.result()
            parsed_output = self.output_parser.invoke(output)
        except Exception as e:
            logger.error(f"Ratings Use Case, Query Analyzer failed, incorrect output format: {e}")
            parsed_output = {"CurrentOrHistoricalRating": None}
        try:
            output_tag_temp = parsed_output.CurrentOrHistoricalRating.value
            output_tag = output_tag_temp + " ratings" if output_tag_temp is not None else "current ratings"
        except Exception as e:
            logger.error(
                f"Ratings Use Case, Query Analyzer failed: {e}.\n"
                "Not able to resolve whether historical or current ratings."
            )
            # Treating failure scenario as default current ratings
            output_tag = "current ratings"
        analyzer_output = {"CurrentOrHistoricalRating": output_tag}
        logger.info(f"\nRatings Query Analyzer output : \n{analyzer_output}")

        return Analyzer(
            user_input=user_input,
            uc_type=uc_type,
            ds_tag=output_tag,
            response=response_dict,
        )
