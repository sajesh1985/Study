from mcp.server.fastmcp import FastMCP
from fastapi import FastAPI, APIRouter
import logging
import httpx
from contextlib import asynccontextmanager
import contextlib
import jwt
import time


from src.synthia.config.api_config import get_config
from src.synthia.utils.logging_config import configure_logging
from src.synthia.utils.source import Source
from src.synthia.aws_utils.aws_client import get_aws_client, get_secret

# Configure logging
configure_logging(log_file='kensho_grounding.log')
logger = logging.getLogger(__name__)

mcp: FastMCP = FastMCP("Kensho Grounding MCP", stateless_http=True)
cfg = get_config()
logger.info("Kensho Grounding MCP Server starting up...")
kensho_grounding_api_url = cfg.get("kensho_grounding_api_url")
kensho_authentication_url = cfg.get("kensho_authentication_url")
kensho_private_pem_key = cfg["kensho_private_pem_key"]
secrets_manager_client = get_aws_client("secretsmanager")


router = APIRouter()
async_client: httpx.AsyncClient = None
KENSHO_CLIENT_ID = cfg.get("kensho_client_id")
ALL_APPLICATION_SCOPES = "kensho:app:grounding-router"


async def get_access_token_from_key(client_id, scope=ALL_APPLICATION_SCOPES):
    synthia_secret = get_secret(secrets_manager_client, "crs-rd-creditmemo-synthia")
    kensho_private_pem = synthia_secret[kensho_private_pem_key]
    logger.info(f"Generating access token for client_id: {client_id} with scope: {scope}")
    iat = int(time.time())
    encoded = jwt.encode(
        {
            "aud": kensho_authentication_url,
            "exp": iat + (30 * 60),  # expire in 30 minutes
            "iat": iat,
            "sub": client_id,
            "iss": client_id,
        },
        kensho_private_pem,
        algorithm="RS256",
    )
    
    global async_client
    response = await async_client.post(
        kensho_authentication_url,
        headers={
            "Content-Type": "application/x-www-form-urlencoded",
            "Accept": "application/json",
        },
        data={
            "scope": scope,
            "grant_type": "client_credentials",
            "client_assertion_type": "urn:ietf:params:oauth:client-assertion-type:jwt-bearer",
            "client_assertion": encoded,
        }
    )
    
    if response.status_code != 200:
        logger.error(f"Failed to get access token: {response.status_code} - {response.text}")
        raise Exception(f"Failed to get access token: {response.status_code} - {response.text}")
    return response.json()["access_token"]

global KENSHO_ACCESS_TOKEN
KENSHO_ACCESS_TOKEN = None

@mcp.tool()
async def get_data_from_transcripts_filings(query: str ) -> dict:
    query = query.strip()
    alowed_datasets =["transcripts_filings_agent"]
    return await get_grounding_results(query, allowed_datasets=alowed_datasets)
    
@mcp.tool()
async def get_data_from_finanical_statements(query: str) -> dict:
    query = query.strip()
    alowed_datasets =["financials_market_cap"]
    return await get_grounding_results(query, allowed_datasets=alowed_datasets)


async def get_grounding_results(query: str, allowed_datasets: list ) -> dict:
    """
    Invokes the grounding API with the provided query and allowed_datasets, and returns the result in MCP format.

    Args:
        query (str): The grounding query string.
        allowed_datasets (list): List of allowed datasets for the grounding API.

    Returns:
        dict: A dictionary containing the grounding results in MCP format.
    """
    logger.info(f"get_grounding_results called for query: {query}, allowed_datasets: {allowed_datasets}")
    global KENSHO_ACCESS_TOKEN
    if KENSHO_ACCESS_TOKEN is None:   
        KENSHO_ACCESS_TOKEN = await get_access_token_from_key(KENSHO_CLIENT_ID)
    
    kensho_auth_headers = {
        "Authorization": f"Bearer {KENSHO_ACCESS_TOKEN}",
        "Content-Type": "application/json",
    }
    payload = {
        "query": query,
        "allowed_datasets": allowed_datasets
    }
    try:
        global async_client
        response = await async_client.post(kensho_grounding_api_url, json=payload, headers=kensho_auth_headers)
        if response.status_code == 200:
            api_data = response.json()
            logger.info(f"Grounding API response: {api_data}")
            problems_data = api_data.get("problems", [])
            if problems_data:
                logger.error(f"Grounding API returned problems: {problems_data}")
                return {"error": f"Grounding API returned problems: {problems_data}"}
            
            grounded_data = api_data.get("grounded_data", [])
            mcp_data = []
            mcp_sources = []
            for item in grounded_data:
                if item.get("representation_type") == "tabular":
                    columns = item["data"].get("columns", [])
                    for row in item["data"].get("data", []):
                        row_dict = dict(zip(columns, row))
                        # Try to get document link from metadata if available
                        doc_link = ""
                        metadata = item.get("metadata", {})
                        doc_link = metadata.get("source", {}).get("link", "")
                        metadata_row = metadata.get("row", {})
                        for meta in metadata_row.values():
                            doc_link = meta.get("source", {}).get("link", "")
                            break
                        if doc_link:
                            source = Source(title="Kensho grounding api url", url=doc_link)
                            mcp_sources.append(source)
                        mcp_data.append(row_dict)
            logger.info(f"Grounding data returned: {mcp_data}")
            return {"sources": mcp_sources, "data": mcp_data}
        elif response.status_code == 204:
            logger.info("No grounding data found for the given query.")
            source = Source(title="Kensho grounding api url", url=kensho_grounding_api_url)
            return {"sources": source, "data": [{"message": "No grounding data found for the given query."}]}
        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return {"error": f"{response.status_code} - {response.text}"}
    except httpx.RequestError as e:
        logger.error(f"Request failed: {e}")
        return {"error": f"Request failed: {e}"}

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Initializing Grounding MCP server task group...")
    global async_client
    async_client = httpx.AsyncClient(timeout=10)
    async with contextlib.AsyncExitStack() as stack:
        await stack.enter_async_context(mcp.session_manager.run())
        yield
    await async_client.aclose()

@router.get("/kensho-grounding/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "ok"}

# Create FastAPI app with lifespan
app = FastAPI(lifespan=lifespan)
app.mount("/kensho-grounding", mcp.streamable_http_app())
app.include_router(router)
logger.info("Kensho Grounding MCP Server started successfully.")