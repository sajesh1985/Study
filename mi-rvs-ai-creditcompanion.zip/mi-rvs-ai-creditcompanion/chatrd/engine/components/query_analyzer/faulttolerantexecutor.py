import logging
from abc import ABC, abstractmethod
from typing import Any, Optional, Tuple, TypeVar

T = TypeVar("T")
logger = logging.getLogger(__name__)


class FaultTolerantExecutor(ABC):
    """
    Abstract base class for Fault Tolerant Executors, these perform exception handling for their subclasses logging errors and returning default values when exceptions occur. This class differs from StateMachine in that it does not need a defined success or error message, subclasses can optionally define a default value and if not it will assume the output type is Optional and return None on failure.
    """

    @abstractmethod
    def run(self, **kwargs) -> T:
        """
        Run method, to be implemented by subclasses.
        """
        pass

    def get_default_value(self) -> Optional[T]:
        """
        Overridable method to provide a default value so that if run fails the program can continue.
        """
        return None

    def execute(self, **kwargs) -> Tuple[T, bool]:
        """
        Executes the subclasses run method returning a tuple of the result, either the default value on failure or the actual result and a boolean indicating success or failure.
        Args:
            **kwargs: Arguments to be passed to the run method of the subclass.
        Returns:
            - T : Result of the run method or the default value on failure.
            - bool : True if the run method succeeded, False if an exception occurred and the default value was returned.
        """
        try:
            result = self.run(**kwargs)
            return result, True
        except Exception as e:
            logger.error(f"Error during execution: {e}")
            default_value = self.get_default_value()
            return default_value, False
