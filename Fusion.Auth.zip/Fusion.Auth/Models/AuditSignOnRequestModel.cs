﻿// Copyright Notice! 
// This document is protected under the trade secret and copyright 
// laws as the property of Fidelity National Information Services, Inc. 
// Copying, reproduction or distribution should be limited and only to 
// employees with a “need to know” to do their job. 
// Any disclosure of this document to third parties is strictly prohibited.
// © 2018 Fidelity National Information Services.
// All rights reserved worldwide.

namespace Fis.Epp.Fusion.Auth.Models
{
    using System;

    /// <summary>Represents audit signon data.</summary>
    [Serializable]
    public class AuditSignOnRequestModel : BaseModel
    {
        [ValidateField]
        public string IpAddress { get; set; }
        [ValidateField]
        public string UserHeaderAgent { get; set; }
        [ValidateField]
        public string SessionID { get; set; }
        [ValidateField]
        public string ContextToken { get; set; }
    }
}
