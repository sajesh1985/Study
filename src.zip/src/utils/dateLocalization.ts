import moment from 'moment-timezone';
import { timeZone } from '../constants/dateConstants';
import { Cultures } from './localization';


export const dateFormattingOption = (timezone: string) => {
  return {
    year: 'numeric',
    month: 'numeric',
    day: 'numeric',
    timeZone: timeZone[timezone as keyof typeof timeZone],
  } as Intl.DateTimeFormatOptions;
};

const dateFormatterOption = {
  year: 'numeric',
  month: 'numeric',
  day: 'numeric'
} as Intl.DateTimeFormatOptions;

export const timeFormattingOption = (timezone: string) => {
  return {
    hour: 'numeric',
    minute: 'numeric',
    hour12: true,
    timeZone: timeZone[timezone as keyof typeof timeZone],
  } as Intl.DateTimeFormatOptions;
};

export const toFormattedDateTime = (
  date: string | Date,
  culture: string,
  timezone: string,
  timeZoneAbbreviation: string
): string => {
  const utcDate = moment
    .tz(date, timeZone['Eastern Standard Time' as keyof typeof timeZone])
    .utc()
    .format();
  const dateStr = new Intl.DateTimeFormat(culture, dateFormatterOption).format(
    new Date(utcDate)
  );
  const timeStr = new Intl.DateTimeFormat(culture, timeFormattingOption(timezone)).format(
    new Date(utcDate)
  );
  return `${dateStr} ${timeStr} ${timeZoneAbbreviation}`;
};

export const toDateCulture = (
  date: string | Date,
  timezone: string
): string => {
  const utcDate = moment(date);
  return  moment.tz(utcDate, timeZone[timezone as keyof typeof timeZone]).format("MMMM Do YYYY - h:mm:ss A");
};

export const toDateCultureResponse = (
  date: string | Date,
  timezone: string
): string => {
  if(date)
    {
      const utcDate = moment
  .tz(date, timeZone['Eastern Standard Time' as keyof typeof timeZone])
  .utc();

    return  moment.tz(utcDate, timeZone[timezone as keyof typeof timeZone]).format("MMMM Do YYYY - h:mm:ss A");
    }
    else
    return "";
  
};


const getFormattedDateTime = (culture: string, date: string | Date, timezone: string, isCSD:boolean): string => {
  const utcDate = moment
  .tz(date, timeZone['Eastern Standard Time' as keyof typeof timeZone])
  .utc();
  const dt = moment.tz(utcDate, timeZone[timezone as keyof typeof timeZone]);
  //const dateStr =transformDateString(dt.toString(), culture);
  const dateStr = transformDateString(new Intl.DateTimeFormat(culture, dateFormattingOption(timezone)).format(new Date(dt.toString())),culture);
  if(isCSD)
  {
    return dateStr;
  }
  const timeStr = dt.format("MMMM Do YYYY - h:mm:ss A").split('-')[1];
  return `${dateStr} ${timeStr}`;
};

const transformDateString = (inputString: string, culture: string): string => {
  switch (culture) {
    case 'ko-KR':
      const [y, m, d] = inputString.split('.').map((str) => str.trim());
      return `${y}-${m.padStart(2, '0')}-${d.padStart(2, '0')}`;
    case Cultures.CULTURE_HI_IN:
      return inputString.replace(/\//g, '-');
    case 'da-DK':
      return inputString.replace(/\./g, '-');
    case Cultures.CULture_PL_PL:
      return inputString.split('.').reverse().join('-');
    case Cultures.CULTURE_FR_BE:
    case Cultures.CULTURE_TA_IN:
    case Cultures.CULTURE_ZU_ZA:
      return inputString.split('/').join('-');
    case Cultures.CULTURE_DE_AT:
    case Cultures.CULTURE_NB_NO:
      return inputString.split('/').join('.');
    case Cultures.CULTURE_RW_RW:
      return transformDateForRW(inputString);
    case Cultures.CULTURE_XH_ZA:
      return inputString.split('/').reverse().join('/');
    case Cultures.CULTURE_TN_ZA:
      const [dd, mm, yyyy] = inputString.split('/').map((str) => str.trim());
      const yy = yyyy.slice(2, 4);
      return [dd, mm, yy].join('/');
    default:
      return inputString;
  }
};

export const getLocalizedDate = (
  date: Date | string,
  isFormattedTimeNeeded = false,
  culture = 'en-US',
  timezone:string,
  isCsd?:boolean
): string => {
    const formatedDate =
      isFormattedTimeNeeded
      ? getFormattedDateTime(culture, date,timezone,isCsd)
      : new Intl.DateTimeFormat(culture, cultureToDateTimeFormatOptions(culture)).format(
          new Date(date)
        );

    return formatedDate;
  }
;

const cultureToDateTimeFormatOptions = (culture: string): Intl.DateTimeFormatOptions => {
  switch (culture) {
    case Cultures.DEFAULT_CULTURE:
    case Cultures.CULTURE_EN_GB:
    case 'it-IT':
    case 'fr-FR':
    case 'ms-MY':
    case 'id-ID':
    case Cultures.CULTURE_ES_ES:
    case 'en-NZ':
    case 'de-DE':
    case 'de-AT':
    case 'nn-NO':
    case 'fr-CH':
    case 'de-CH':
    case 'ru-RU':
    case 'pt-PT':
    case 'pt-BR':
    case 'da-DK':
    case Cultures.CULTURE_HI_IN:
      return { month: '2-digit', day: '2-digit', year: 'numeric' };
    case Cultures.CULTURE_TA_IN:
    case Cultures.CULTURE_FR_BE:
    case 'nl-BE':
    case 'en-AU':
    case 'en-NZ':
    case 'th-TH-u-ca-gregory':
      return { month: '2-digit', day: '2-digit', year: 'numeric' };
    case 'zh-HK':
    case 'zh-MO':
    case 'am-ET':
    case 'el-GR':
    case 'cs-CZ':
    case 'fi-FI':
    case 'nl-NL':
    case 'fil-PH':
    case Cultures.CULTURE_JA_JP:
    case Cultures.CULture_PL_PL:
    case Cultures.CULTURE_RW_RW:
    case Cultures.CULTURE_TN_ZA:
    case Cultures.CULTURE_XH_ZA:
    case Cultures.CULTURE_ZU_ZA:
      return { month: '2-digit', day: '2-digit', year: 'numeric' };
    case 'sv-SE':
    case 'ko-KR':
    case 'zh-CN':
    case 'zh-SG':
    case 'zh-TW':
    case 'es-AR':
    case 'es-CL':
    case 'es-CO':
    case 'es-PA':
    case 'es-EC':
    case 'es-HN':
    case 'nb-NO':
      return {};
    default:
      return { dateStyle: 'long', timeZone: 'UTC' };
  }
};

export const convertStringToDate = (value: string): Date => {
  return isoDateStringToDate(value);
};

const isoDateStringToDate = (value: string | Date): Date => {
  // regular expression for iso date expressions
  const isoDateExp =
    /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2}(?:\.\d*)?)(?:([\+-])(\d{2})\:(\d{2}))?Z?$/;
  const dateExp = /^(\d{4})-(\d{2})-(\d{2})/;

  //wrapping with try-catch to make sure if anything goes wrong, we still return the value fed in
  let a;
  try {
    if (value && typeof value === 'string') {
      //this is what existing code was, jst checking for value to be containing T/t to make sure ISO string was passed
      //and construct Date according to that
      if (value.includes('T') || value.includes('t')) {
        a = isoDateExp.exec(value);
        if (a) {
          return new Date(+a[1], +a[2] - 1, +a[3], +a[4], +a[5], +a[6]);
        }
      }
      //else part is new to take care of date values that are YYYY-MM-DD format
      else {
        a = dateExp.exec(value);
        if (a) {
          return new Date(+a[1], +a[2] - 1, +a[3]);
        }
      }
    }
  } catch (e) {
    //if there occurred any exception, we would rather execute the old piece of code until enough unit test cases are
    //written on this. Soon to be romoved.
    a = isoDateExp.exec(value as string);
    if (a) {
      return new Date(+a[1], +a[2] - 1, +a[3], +a[4], +a[5], +a[6]);
    }
  }
  return value as Date;
};

function transformDateForRW(inputString: string): string {
  const [m, d, y] = inputString.split('/').map((str) => str.trim());
  const mm = m?.padStart(2, '0');
  return [d, mm, y].join('/');
}
