from typing import Dict, Optional, Union

from chatrd.engine.components.query_analyzer.utils import EntityType


class GuidelineTemplate(object):
    def __init__(self, prompt: str, examples: Dict):
        self.prompt = prompt
        self.examples = examples

    def __repr__(self):
        return f"Guidelines(prompt:{self.prompt}, examples: {self.examples})"

    def get_template(self, type: Optional[Union[EntityType, str]] = None):
        if type is None:
            return self.prompt, self.examples
        return self.prompt, self.examples[type]
