import logging
from typing import Optional

import pandas as pd

from chatrd.engine.components.query_analyzer.translator.utils import (
    Get_translation_result,
)
from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.data_service.schema import (
    Analyzer,
    ProcessorInput,
    Retriever,
    Synthesizer,
)
from chatrd.engine.data_service.synthesizer.base import BaseSynthesizer
from chatrd.engine.data_service.synthesizer.utils import (
    GenericTemplate,
    create_ratings_table,
    full_response,
    get_api_info,
    make_source_description,
    rating_history_url,
)

logger = logging.getLogger(__name__)

config_machinery = get_config_machinery()

CWOL_MAPPING = config_machinery.get_config_value(Constants.DataService.CWOL_MAPPING)


class CompanyRatingsSynthesizer(BaseSynthesizer, GenericTemplate):
    def filter_entity(self, df) -> pd.DataFrame:
        # pick a single entity if multiple entities returned
        # this can happen for insurance sector,
        # where the parent entity has MI KEY = ENTITY ID
        # for other subsidiary entities, they share same MI KEY
        # however, they have distinct ENTITY IDs
        if df.shape[0] > 1:
            # typically MI KEY is int, while ENTITY ID is str
            df["MI KEY"] = df["MI KEY"].astype(str)
            df["ENTITY ID"] = df["ENTITY ID"].astype(str)
            df = df[df["ENTITY ID"] == df["MI KEY"]]
        else:
            return df

        if df.shape[0] == 0:
            # above condition does not work
            # could be because a subset of results are returned from screener
            # in this case, we just return original data without any filter applied
            return df
        else:
            # typically this should return a dataframe with a single entry
            # however, if multiple entries are returned, this will be taken care of
            # in subsequent implementations in the templating logic
            return df

    def source_description(self, df: pd.DataFrame) -> list:
        try:
            # first check if we have entity name returned from screener
            entity_name = df["ENTITY NAME"].iloc[0]
            entity_id = str(df["ENTITY ID"].iloc[0])
            sep = ": "
            info = "Ratings & History Page"
            sources = make_source_description(entity_name, entity_id, sep, info, rating_history_url)
        except KeyError:
            # if returned dataframe does not contain entity id/entity name,
            # no sourcing url is generated
            logger.error("Error generating source description.")
            sources = []

        return sources

    def leading_line(self, icr_fsr, df) -> str:
        # entity name
        entity_name = df["ENTITY NAME"].iloc[0]
        if icr_fsr == "FSR":
            template = f"""{entity_name} has the following Financial Strength Ratings:"""
        else:  # for ICR
            template = f"""{entity_name} has the following Issuer Credit Ratings:"""
        return template

    def synthesize(
        self,
        processor: Optional[ProcessorInput] = None,
        analyzer: Optional[Analyzer] = None,
        retriever: Retriever = None,
    ) -> Synthesizer:
        """
        Synthesizes a response based on the provided processor, analyzer, and retriever.

        Args:
            processor (Optional[ProcessorInput]): An object containing entity data.
            analyzer (Optional[Analyzer]): An optional analyzer object.
            retriever (Retriever): An object to retrieve API data.

        Returns:
            Synthesizer: An instance of Synthesizer containing the response and source description.
        """
        df = self.filter_entity(pd.DataFrame(retriever.api_data))
        count = retriever.total_count

        rating_cols = [
            "S&P CREDIT RATING FOREIGN CURRENCY LT",
            "S&P CREDIT RATING LOCAL CURRENCY LT",
            "S&P CREDIT RATING FOREIGN CURRENCY ST",
            "S&P CREDIT RATING LOCAL CURRENCY ST",
        ]
        rating_fsr_cols = [x.replace("RATING", "RATING (FSR)") for x in rating_cols]

        cols_df = df.columns.tolist()

        # # check if its company perspective
        # # if screener_payload_object.key_perspective_str == "company":
        # # check if its a ratings related query and which rating
        which_rating = []
        for col in rating_cols:
            if col in cols_df:
                which_rating.append(col)

        which_fsr_rating = []
        for col in rating_fsr_cols:
            if col in cols_df:
                which_fsr_rating.append(col)

        num_icr_ratings = len(which_rating)
        num_fsr_ratings = len(which_fsr_rating)

        # check if query is asking for a singular rating type or all ratings
        response = []
        if num_fsr_ratings > 0:
            # Process FSR for only Insurance companies (payload will contain FS Ratings)
            template = self.leading_line("FSR", df=df)
            template = Get_translation_result(template, processor.original_language)
            template = template.result()

            df_tabular, has_valid_rows = create_ratings_table(df, rating_fsr_cols, "FSR")
            if has_valid_rows:
                response = full_response(
                    template=template,
                    data=df_tabular,
                    data_type="table",
                    count=count,
                )
        elif num_icr_ratings == 0 and num_fsr_ratings == 0:
            # not a rating related query
            # or query returned data that does not contain any rating fields
            logger.error(
                "User query is identified as ratings related, however screener doesn't return any ratings fields."
            )
            raise Exception("No rating fields returned. Data Service response can't be generated.")

        template = self.leading_line("ICR", df=df)
        template = Get_translation_result(template, processor.original_language)
        template = template.result()

        df_tabular, has_valid_rows = create_ratings_table(df, rating_cols, "ICR")
        if has_valid_rows:
            response = response + full_response(
                template=template,
                data=df_tabular,
                data_type="table",
                count=count,
            )

        sources = []
        if response != []:
            sources = self.source_description(df=df)

        api_info = get_api_info(
            api_method=retriever.api_method,
            api_type=retriever.api_type,
            url=retriever.url,
            screener_payload=retriever.screener_payload,
        )

        return Synthesizer(data_service_response=response, source_description=sources, api_info=api_info)
