"""Callback handlers for tracking progress and handling events."""

import logging
from math import log
from typing import Dict, Any, List, Callable, Optional
from langchain_core.callbacks import BaseCallbackHandler
from src.synthia.utils.logging_config import configure_logging

# Configure logging (ensures synthia.log is maintained)
logger = configure_logging(logger_name=__name__,)


class ProgressCallback(BaseCallbackHandler):
    """Callback handler to track progress of operations."""

    def __init__(self, state: Dict[str, Any]):
        """Initialize with a state dictionary to update."""
        self.state = state
        self.total_steps = 0
        self.completed_steps = 0

    def on_llm_start(self, *args, **kwargs):
        """Called when LLM starts."""
        self.total_steps += 1
        logger.debug(
            f"LLM start: Step {self.completed_steps+1}/{self.total_steps}")

    def on_llm_end(self, *args, **kwargs):
        """Called when LLM ends."""
        self.completed_steps += 1
        # Update progress in state
        if self.total_steps > 0:
            self.state["progress"] = min(
                0.95, self.completed_steps / self.total_steps)
            logger.debug(f"Progress updated: {self.state['progress']:.2f}")

    def on_tool_start(self, *args, **kwargs):
        """Called when a tool starts."""
        self.total_steps += 1
        logger.debug(
            f"Tool start: Step {self.completed_steps+1}/{self.total_steps}")

    def on_tool_end(self, *args, **kwargs):
        """Called when a tool ends."""
        self.completed_steps += 1
        # Update progress in state
        if self.total_steps > 0:
            self.state["progress"] = min(
                0.95, self.completed_steps / self.total_steps)
            logger.debug(f"Progress updated: {self.state['progress']:.2f}")

    def on_chain_start(self, *args, **kwargs):
        """Called when a chain starts."""
        logger.debug("Chain started")

    def on_chain_end(self, *args, **kwargs):
        """Called when a chain ends."""
        logger.debug("Chain ended")

    def on_text(self, text: str, **kwargs):
        """Called when text is generated."""
        logger.debug(f"Text generated: {text[:50]}...")


def initialize_callbacks(state: Dict[str, Any]) -> List[BaseCallbackHandler]:
    """Initialize callback handlers for the given state."""
    callbacks = [ProgressCallback(state)]
    return callbacks
