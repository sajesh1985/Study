from typing import Any, List, Optional, Sequence, Tuple, Type

from pydantic import BaseModel

from chatrd.core.document.schema import make_hashable
from chatrd.core.utils import ChatMessage
from chatrd.engine.components.query_analyzer.entity_extractor.utils import Entities
from chatrd.engine.components.query_analyzer.filter_retrievers.prompts import (
    TimeOutputDates,
)
from chatrd.engine.components.query_analyzer.suggested_entity_rephrase.utils import (
    SuggestedEntities,
)
from chatrd.engine.components.query_analyzer.utils import EntityType, TaggedEntity
from chatrd.engine.utils import ChatResponse


class QueryAnalyzerInput(BaseModel):
    llm: str
    temperature: float
    llm_for_entity_extractor: str
    temperature_for_entity_extractor: float
    llm_for_sector_extractor: str
    temperature_for_sector_extractor: float
    message: str
    list_of_tagged_entities: List[TaggedEntity]
    chat_history: Sequence[ChatMessage]


class QueryAnalyzerOutput(BaseModel):
    query: str
    original_query: str = ""
    original_language: str = ""
    uc_type: str
    multi_uc_type: Optional[bool] = False
    rephrased_query: Optional[str] = ""
    guidelines: Optional[str] = ""
    entities: Optional[Entities] = None
    suggested_entities: Optional[SuggestedEntities] = None
    sectors: Optional[BaseModel] = None
    entity_type: Optional[EntityType] = None
    subrouting_result: Optional[str] = None
    extracted_timeframe: Optional[TimeOutputDates] = None
    list_of_tagged_entities: Optional[List[TaggedEntity]] = None
    subquery_analyzer_outputs: Optional[List[BaseModel]] = None
    tagged_routes: Optional[List[str]] = []
    backup: bool = False
    is_geo_or_region: Optional[bool] = False

    def __hash__(self):
        return hash(make_hashable(self.dict()))


class QueryProcessorInput(BaseModel):
    llm_for_non_flex_synthesizer: str
    temperature_for_non_flex_synthesizer: float
    llm_for_flex_synthesizer: str
    temperature_for_flex_synthesizer: float
    llm_for_tool_classifier: str
    temperature_for_tool_classfifer: float
    llm_for_data_service: str
    temperature_for_data_service: float
    message: str
    chat_history: List[ChatMessage]
    streaming: bool
    analyzer_output: QueryAnalyzerOutput


class ComponentsOutput:
    def __init__(self, *types: Type):
        self.types = (ChatResponse,) + types

    def __call__(self, value: Any) -> bool:
        return isinstance(value, self.types)

    def get_union(self) -> Tuple[Type, ...]:
        """Returns the tuple of types that form the union."""
        return self.types
