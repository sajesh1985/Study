﻿// Copyright Notice! 
// This document is protected under the trade secret and copyright 
// laws as the property of Fidelity National Information Services, Inc. 
// Copying, reproduction or distribution should be limited and only to 
// employees with a “need to know” to do their job. 
// Any disclosure of this document to third parties is strictly prohibited.
// © 2018 Fidelity National Information Services.
// All rights reserved worldwide.

namespace Fis.Epp.Fusion.Auth.Common
{
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.AspNetCore.Mvc.Filters;
    using Microsoft.AspNetCore.Mvc.ModelBinding;
    using Microsoft.AspNetCore.Mvc.ViewFeatures;
    using Fis.Epp.Fusion.Auth.Models;

    /// <summary>Represents custom exception handler to handle all the exceptions occured in the controller.</summary>
    public class CustomExceptionFilterAttribute : ExceptionFilterAttribute
    {
        public override void OnException(ExceptionContext context)
        {
            ExceptionLoggerModel errorData = new ExceptionLoggerModel
            {
                CorrelationId = context.HttpContext.Items.ContainsKey(RequestHeader.Correlation_ID.GetEnumDescription()) ? context.HttpContext.Items[RequestHeader.Correlation_ID.GetEnumDescription()].ToString() : string.Empty,
                FeId = context.HttpContext.Items.ContainsKey(RequestHeader.FE_ID.GetEnumDescription()) ? context.HttpContext.Items[RequestHeader.FE_ID.GetEnumDescription()].ToString() : string.Empty,
                UserId = context.HttpContext.Items.ContainsKey(RequestHeader.USER_ID.GetEnumDescription()) ? context.HttpContext.Items[RequestHeader.USER_ID.GetEnumDescription()].ToString() : string.Empty,
                ErrorMessage = context.Exception.Message,
                ErrorStack = context.Exception.StackTrace,
                RequestUrl = context.HttpContext.Request.Path,
                MemberId = string.Empty
            };
            AppDiagnostics.RecordException(errorData);

            var viewResult = new ViewResult { ViewName = "Error" };
            var modelMetadata = new EmptyModelMetadataProvider();
            viewResult.ViewData = new ViewDataDictionary(modelMetadata, context.ModelState);
            viewResult.ViewData.Add("Exception", context.Exception);
            context.Result = viewResult;
            context.ExceptionHandled = true;
        }
    }
}