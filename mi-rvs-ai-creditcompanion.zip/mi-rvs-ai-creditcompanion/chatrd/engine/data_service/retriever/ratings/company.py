import json
import logging
from typing import Dict, List, Optional

import pandas as pd

from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.data_service.kpqi import KPQI, KPQIPayload
from chatrd.engine.data_service.kpqi.base import DEFAULT_GLOBAL_RATING_FAMILY
from chatrd.engine.data_service.postprocessing import postprocess_cells_view
from chatrd.engine.data_service.retriever import BaseRetriever
from chatrd.engine.data_service.retriever.utils import (
    DEFAULT_POST_PROCESS_RETURN,
    PERSPECTIVE_MAPPING,
    create_dynamic_column_header,
    get_payload_path,
    post_process_data,
    update_query_field,
)
from chatrd.engine.data_service.schema import (
    Analyzer,
    ProcessorInput,
    Retriever,
    ScreenerPayload,
)
from chatrd.engine.data_service.synthesizer.query.data.criteria_arguments import (
    INSURANCE_SECTOR_CODES,
)
from chatrd.engine.data_service.utils import get_rd_sector
from chatrd.engine.screener_api import ScreenerAPI

logger = logging.getLogger(__name__)


config_machinery = get_config_machinery()

with open(get_payload_path(Constants.PayLoad.DATASERVICE_PAYLOAD_PATH)) as fp:
    DATASERVICE_PAYLOAD = json.load(fp)
DEFAULT_PAYLOAD = DATASERVICE_PAYLOAD["DEFAULT_PAYLOAD"]
GLOBAL_CREDIT_RATING_BASE = DATASERVICE_PAYLOAD["GLOBAL_CREDIT_RATING_BASE"]
GLOBAL_CREDIT_RATING_FSR = DATASERVICE_PAYLOAD["GLOBAL_CREDIT_RATING_FSR"]


class CompanyRatingsRetriever(BaseRetriever):
    def _update_tertiary_value_for_credit_actions(
        self, functions: List[Dict], k: int = KPQI.RD_RATING_ACTION_GLOBAL.value
    ):
        for function in functions:
            # update the tertiary value for credit actions
            if function["primary"] == k:
                # Update the tertiary value to replace 0 with 4
                function["tertiary"] = function["tertiary"].replace("|0", "|4")
        return functions

    def _insurance_function_update(self, queries: List[Dict], key_value_pairs: Dict) -> List[Dict]:
        """
        This function updates the column fields for insurance sector.
        If the user selects the insurance sector, the function will update the
        function fields to include the Local Currency LT rating.
        Args:
            functions (List[Dict]): The list of function fields.
            key_value_pairs (Dict): The dictionary that contains users' input.

        Returns: A list of updated function fields.

        """
        key_value = KPQI.RD_SECTOR.value
        credit_rating_global = KPQI.RD_CREDIT_RATING_GLOBAL.value
        rating_action_global = KPQI.RD_RATING_ACTION_GLOBAL.value
        if key_value in key_value_pairs:
            codes_to_check = [code.strip() for code in key_value_pairs[key_value]["value"].split(",")]
            if all(code in INSURANCE_SECTOR_CODES for code in codes_to_check):
                for query in queries:
                    if query["field"]["fieldKey"] in [credit_rating_global, rating_action_global]:
                        for secondary in query["field"]["secondaryKeys"]:
                            if secondary["displayValue"] == "Foreign Currency LT":
                                secondary["key"] = "Local Currency LT"
                                secondary["value"] = "Local Currency LT"
                                secondary["displayValue"] = "Local Currency LT"
                                secondary["mask"] = "Local Currency LT"
        return queries

    def _build_value_pairs(self, entities) -> Dict:
        mi_id = entities["companies"][0].get("mi_id")
        entity_name = entities["companies"][0].get("name")
        logger.info(f"The company is {entity_name} with entity id is {mi_id}.")

        if mi_id:
            mi_key = KPQI.MI_KEY.value  # 267964

            default_payload_dict = {
                mi_key: {
                    "value": mi_id,
                    "connector": 0,
                    "operator": 0,
                    "data_type": "nstring",
                },
            }
        else:
            company_name = KPQI.Company_Name.value  # 275884

            default_payload_dict = {
                company_name: {
                    "value": entity_name,
                    "connector": 0,
                    "operator": 9,
                    "data_type": "nstring",
                },
            }
        return default_payload_dict

    def _payload_build(
        self, entities, key_value_pairs: dict, key_perspective: Optional[int] = 266637, max_results: int = 15
    ):
        functions = []
        queries = []
        for k, v in key_value_pairs.items():
            default_function_dict = KPQIPayload(KPQI(k)).default_func_field()
            default_query_dict = KPQIPayload(KPQI(k)).default_query_field()
            # default function
            functions.append(default_function_dict)
            # default query
            query_field_updated = update_query_field(v, default_query_dict)
            queries.append(query_field_updated)

            rd_sector = get_rd_sector(entities)
            if rd_sector and "Insurance" in rd_sector:
                functions.extend(GLOBAL_CREDIT_RATING_FSR)

            for default_k in DEFAULT_GLOBAL_RATING_FAMILY:
                functions.append(KPQIPayload(KPQI(default_k)).default_func_field())
            functions.extend(GLOBAL_CREDIT_RATING_BASE)

        queries = self._insurance_function_update(queries, key_value_pairs)
        functions = self._update_tertiary_value_for_credit_actions(functions)

        payload = DEFAULT_PAYLOAD
        payload["functionRequests"][0]["perspective"] = key_perspective
        payload["functionRequests"][0]["requestedPerspective"] = key_perspective
        payload["functionRequests"][0]["query"]["keyPerspective"] = key_perspective

        payload["functionRequests"][0]["fields"] = functions
        payload["functionRequests"][0]["pagingInfo"]["pageSize"] = max_results
        payload["functionRequests"][0]["query"]["queryLineGroups"][0]["queryLines"] = queries

        return payload

    def _post_process(
        self,
        response,
        entities,
        key_value_pairs,
        key_perspective: Optional[int] = 266637,
        key_perspective_str: Optional[str] = "companies",
        uc_type: str = "ratings",
        total_count: int = 1,
    ):
        try:
            response = response.json()
            columns, column_key = create_dynamic_column_header(
                response, key_perspective=key_perspective, uc_type=uc_type
            )
            df = pd.DataFrame(response["functionResponses"][0]["results"], columns=columns)
        except Exception as e:
            logger.error(f"Error happened and here is the " f"message: {e}.")
            return DEFAULT_POST_PROCESS_RETURN

        env = config_machinery.get_config_value(Constants.DataService.DATASERVICE_SCREENER_ENV)

        df = postprocess_cells_view(key_perspective, env, df)
        df = df.loc[:, ~df.columns.duplicated()]

        # create ScreenerPayload object as part of standard output
        kpqi = next(iter(key_value_pairs))
        entity_name = entities[key_perspective_str][0].get("name")
        # 267964 is the MI_KEY KPQI
        if kpqi == KPQI.MI_KEY.value:
            text_operator = "equal"
        else:
            text_operator = "includes"

        screener_payload_dict = {"key": kpqi, "value": key_value_pairs}
        screener_text_dict = {
            "key": "company name",
            "value": {
                "value": entity_name,
                "connector": "and",
                "operator": text_operator,
            },
        }
        screener_payload_object = ScreenerPayload(
            key_perspective=key_perspective,
            key_perspective_str=key_perspective_str,
            payload_dict=screener_payload_dict,
            text_dict=screener_text_dict,
            magnitude_dict={},
            model_response_text="",
        )

        df = post_process_data(screener_payload_object, df)

        return (df, total_count, screener_payload_object)

    def retrieve(
        self,
        processor: ProcessorInput = None,
        analyzer: Optional[Analyzer] = None,
        api_method: str = "POST",
        api_type: str = "screener",
    ) -> Retriever:
        entities = processor.entities
        key_perspective = PERSPECTIVE_MAPPING["company"]

        # Key value dictonary from entities
        key_value_pairs = self._build_value_pairs(entities)

        # Payload Build
        payload = self._payload_build(
            entities=entities,
            key_value_pairs=key_value_pairs,
            max_results=config_machinery.get_config_value(Constants.GeneralConstants.NUM_ROWS_TO_DISPLAY),
        )

        # Endpoint Call
        response, url = ScreenerAPI().get_results_from_screener_api(payload=payload)

        # Post Processing
        df, total_count, screener_payload_object = self._post_process(
            response=response,
            entities=entities,
            key_value_pairs=key_value_pairs,
            key_perspective=key_perspective,
        )

        return Retriever(
            api_data=df.to_dict(),
            screener_payload=payload,
            screener_payload_object=screener_payload_object,
            url=url,
            total_count=total_count,
            api_method=api_method,
            api_type=api_type,
        )
