// Copyright Notice!
// This document is protected under the trade secret and copyright
// laws as the property of Fidelity National Information Services, Inc.
// Copying, reproduction or distribution should be limited and only to
// employees with a “need to know” to do their job.
// Any disclosure of this document to third parties is strictly prohibited.
// © 2016 Fidelity National Information Services.
// All rights reserved worldwide.


package com.fis.digitalpayments.sdk.core;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Map;

/**
 * Represents a response from a bridge request.
 */
public class BridgeResponse {

    private final Boolean mIsSuccessful;
    private final String mJavascriptCallback;
    private final BridgeMessage mBridgeMessage;

    /**
     * Constructs a successful BridgeResponse without custom client attributes for messages.
     * @param callbackMethod Callback method.
     * @param data Requested data to return as json.
     * @param callbackKey Uniquely identifies a request.
     */
    public BridgeResponse(final String callbackMethod, JSONObject data, final String callbackKey) {
        this(callbackMethod, data, null, callbackKey, true, null);
    }

    /**
     * Constructs a BridgeResponse.
     * @param callbackMethod Callback method.
     * @param data Requested data to return as json.
     * @param clientAttributes Can contain metadata about a response. For example, the version of a library that was used.
     * @param callbackKey Uniquely identifies a request.
     * @param isSuccessful Flag indicating whether the request was fulfilled.
     * @param bridgeMessage BridgeMessage related to the response, typically used to describe errors.
     */
    public BridgeResponse(final String callbackMethod, JSONObject data, Map<String, String> clientAttributes, final String callbackKey, final boolean isSuccessful, final BridgeMessage bridgeMessage) {
        mIsSuccessful = isSuccessful;
        mJavascriptCallback = String.format("javascript: %s(%s);", callbackMethod, createJSONResponse(data, clientAttributes, callbackKey, mIsSuccessful, bridgeMessage));
        mBridgeMessage = bridgeMessage;
    }

    /**
     * Gets a representation of the response as a javascript callback.
     * @return String that can be executed to invoke a javascript callback.
     */
    public String getJavascriptCallback() {
        return mJavascriptCallback;
    }

    /**
     * Creates JSONObject representation of this classes data.
     * @param data Requested data to return as json.
     * @param clientAttributes Can contain metadata about a response. For example, the version of a library that was used.
     * @param callbackKey Uniquely identifies a request.
     * @param isSuccessful Flag indicating whether the request was fulfilled.
     * @param bridgeMessage BridgeMessage related to the response, typically used to describe errors.
     * @return JSONObject representing this classes data.
     */
    static JSONObject createJSONResponse(JSONObject data, Map<String, String> clientAttributes, final String callbackKey, final boolean isSuccessful, final BridgeMessage bridgeMessage) {
        JSONObject jsonResponse = new JSONObject();

        try {
            jsonResponse.put("data", data);
            jsonResponse.put("clientProfile", getClientProfile(clientAttributes));
            jsonResponse.put("callbackKey", callbackKey);
            jsonResponse.put("isSuccessful", isSuccessful);
            jsonResponse.put("bridgeMessage", getMessageJSON(bridgeMessage));
        } catch (JSONException e) {
            jsonResponse = new JSONObject();

            try {
                BridgeMessage errorBridgeMessage = BridgeMessage.CreateError(BridgeMessageCode.BRIDGE_RESPONSE_PROCESSING_FAILED, BridgeMessageCode.BRIDGE_RESPONSE_PROCESSING_FAILED.toString());

                jsonResponse.put("callbackKey", callbackKey);
                jsonResponse.put("isSuccessful", false);
                jsonResponse.put("bridgeMessage", getMessageJSON(errorBridgeMessage));
            } catch (JSONException unrecoverable) {
                jsonResponse = null;
            }
        }

        return jsonResponse;
    }

    private static JSONObject getClientProfile(Map<String, String> clientAttributes) throws JSONException {
        JSONObject clientProfile = new JSONObject();

        // Determine what properties are safe to collect
        //clientProfile.put("deviceId", "990000862471854");
        //clientProfile.put("userAgent", "Android 5.0.2");

        if (clientAttributes != null) {
            for (String key : clientAttributes.keySet()) {
                clientProfile.put(key, clientAttributes.get(key));
            }
        }

        return clientProfile;
    }

    private static JSONObject getMessageJSON(BridgeMessage bridgeMessage) throws JSONException {
        JSONObject messageJSON = null;

        if (bridgeMessage != null) {
            messageJSON = new JSONObject();
            messageJSON.put("type", bridgeMessage.getMessageType());
            messageJSON.put("code", bridgeMessage.getMessageCode());
            messageJSON.put("text", bridgeMessage.getMessageText());
        }

        return messageJSON;
    }

    boolean getIsSuccessful()
    {
        return mIsSuccessful;
    }

    BridgeMessage getMessage() { return mBridgeMessage; }
}
