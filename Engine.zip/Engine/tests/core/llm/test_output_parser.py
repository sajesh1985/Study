import json
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

import pytest
from pydantic import BaseModel, Field

from chatrd.core.llm.components.generation import Generation
from chatrd.core.llm.parsers import OutputParserException, PydanticOutputParser


# Test Models
class UserStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"


class Address(BaseModel):
    street: str
    city: str
    zipcode: str
    country: str = "USA"


class User(BaseModel):
    name: str
    age: int
    email: str
    status: UserStatus = UserStatus.ACTIVE
    address: Optional[Address] = None
    tags: List[str] = Field(default_factory=list)
    metadata: Dict[str, Any] = Field(default_factory=dict)


class SimpleModel(BaseModel):
    value: str
    count: int


class NestedModel(BaseModel):
    user: User
    created_at: datetime
    is_verified: bool = False


class EmptyModel(BaseModel):
    pass


class ModelWithValidation(BaseModel):
    email: str = Field(..., pattern=r"^[^@]+@[^@]+\.[^@]+$")
    score: float = Field(..., ge=0.0, le=100.0)


class TestPydanticOutputParser:
    """Test suite for PydanticOutputParser."""

    def setup_method(self):
        """Setup method to initialize parsers."""
        self.simple_parser = PydanticOutputParser(pydantic_object=SimpleModel)
        self.user_parser = PydanticOutputParser(pydantic_object=User)
        self.nested_parser = PydanticOutputParser(pydantic_object=NestedModel)
        self.empty_parser = PydanticOutputParser(pydantic_object=EmptyModel)
        self.validation_parser = PydanticOutputParser(pydantic_object=ModelWithValidation)

    def test_parse_simple_valid_json(self):
        """Test parsing simple valid JSON."""
        json_str = '{"value": "test", "count": 42}'
        result = self.simple_parser.parse(json_str)

        assert isinstance(result, SimpleModel)
        assert result.value == "test"
        assert result.count == 42

    def test_parse_complex_valid_json(self):
        """Test parsing complex nested JSON."""
        user_data = {
            "name": "John Doe",
            "age": 30,
            "email": "john@example.com",
            "status": "active",
            "address": {"street": "123 Main St", "city": "Anytown", "zipcode": "12345"},
            "tags": ["developer", "python"],
            "metadata": {"level": "senior", "years": 5},
        }
        json_str = json.dumps(user_data)
        result = self.user_parser.parse(json_str)

        assert isinstance(result, User)
        assert result.name == "John Doe"
        assert result.age == 30
        assert result.email == "john@example.com"
        assert result.status == UserStatus.ACTIVE
        assert result.address.street == "123 Main St"
        assert result.tags == ["developer", "python"]
        assert result.metadata["level"] == "senior"

    def test_parse_with_defaults(self):
        """Test parsing with default values."""
        json_str = '{"name": "Jane", "age": 25, "email": "jane@example.com"}'
        result = self.user_parser.parse(json_str)

        assert result.status == UserStatus.ACTIVE  # default value
        assert result.address is None  # default None
        assert result.tags == []  # default empty list
        assert result.metadata == {}  # default empty dict

    def test_parse_empty_model(self):
        """Test parsing empty model."""
        json_str = "{}"
        result = self.empty_parser.parse(json_str)

        assert isinstance(result, EmptyModel)

    def test_parse_invalid_json(self):
        """Test parsing invalid JSON string."""
        invalid_json = '{"value": "test", "count":}'

        with pytest.raises(OutputParserException) as exc_info:
            self.simple_parser.parse(invalid_json)
            assert exc_info.type == OutputParserException, "Expected OutputParserException for invalid JSON"

        assert "Failed to parse" in str(exc_info.value), (
            "Exception should indicate parsing failure" "with message containing: 'Failed to parse'"
        )

    def test_parse_missing_required_field(self):
        """Test parsing JSON missing required fields."""
        json_str = '{"value": "test"}'  # missing "count"

        with pytest.raises(OutputParserException) as exc_info:
            self.simple_parser.parse(json_str)

        assert "Failed to parse" in str(exc_info.value)

    def test_parse_wrong_type(self):
        """Test parsing with wrong data types."""
        json_str = '{"value": "test", "count": "not_a_number"}'

        with pytest.raises(OutputParserException) as exc_info:
            self.simple_parser.parse(json_str)

        assert "Failed to parse" in str(exc_info.value)

    def test_parse_invalid_enum_value(self):
        """Test parsing with invalid enum value."""
        json_str = '{"name": "John", "age": 30, "email": "john@example.com", "status": "unknown"}'

        with pytest.raises(OutputParserException) as exc_info:
            self.user_parser.parse(json_str)

        assert "Failed to parse" in str(exc_info.value)

    def test_parse_result_valid(self):
        """Test parse_result method with valid generation."""
        json_str = '{"value": "test", "count": 42}'
        generation = Generation(text=json_str)
        result = self.simple_parser.parse_result([generation])

        assert isinstance(result, SimpleModel)
        assert result.value == "test"
        assert result.count == 42

    def test_parse_result_partial_valid(self):
        """Test parse_result with partial=True and valid JSON."""
        json_str = '{"value": "test", "count": 42}'
        generation = Generation(text=json_str)
        result = self.simple_parser.parse_result([generation], partial=True)

        assert isinstance(result, SimpleModel)
        assert result.value == "test"

    def test_parse_result_partial_invalid(self):
        """Test parse_result with partial=True and invalid JSON."""
        invalid_json = '{"value": "test"'  # incomplete JSON
        generation = Generation(text=invalid_json)
        result = self.simple_parser.parse_result([generation], partial=True)

        assert result is None

    def test_parse_result_multiple_generations(self):
        """Test parse_result uses only first generation."""
        json_str1 = '{"value": "first", "count": 1}'
        json_str2 = '{"value": "second", "count": 2}'
        generations = [Generation(text=json_str1), Generation(text=json_str2)]
        result = self.simple_parser.parse_result(generations)

        assert result.value == "first"  # Should use first generation only
        assert result.count == 1

    def test_get_format_instructions(self):
        """Test format instructions generation."""
        instructions = self.simple_parser.get_format_instructions()

        assert isinstance(instructions, str)
        assert "json" in instructions.lower()
        assert "SimpleModel" not in instructions  # title should be removed
        assert "value" in instructions  # field should be present
        assert "count" in instructions  # field should be present

    def test_format_instructions_complex_model(self):
        """Test format instructions for complex model."""
        instructions = self.user_parser.get_format_instructions()

        assert "name" in instructions
        assert "age" in instructions
        assert "email" in instructions
        assert "address" in instructions

    def test_output_type_property(self):
        """Test OutputType property."""
        assert self.simple_parser.OutputType == SimpleModel
        assert self.user_parser.OutputType == User

    def test_parse_with_validation_rules(self):
        """Test parsing with validation rules."""
        valid_json = '{"email": "test@example.com", "score": 85.5}'
        result = self.validation_parser.parse(valid_json)

        assert result.email == "test@example.com"
        assert result.score == 85.5

    def test_parse_validation_failure_email(self):
        """Test parsing with invalid email format."""
        invalid_json = '{"email": "invalid-email", "score": 85.5}'

        with pytest.raises(OutputParserException):
            self.validation_parser.parse(invalid_json)

    def test_parse_validation_failure_score(self):
        """Test parsing with score out of range."""
        invalid_json = '{"email": "test@example.com", "score": 150.0}'

        with pytest.raises(OutputParserException):
            self.validation_parser.parse(invalid_json)

    def test_parse_nested_model(self):
        """Test parsing deeply nested model."""
        nested_data = {
            "user": {"name": "John Doe", "age": 30, "email": "john@example.com"},
            "created_at": "2023-01-01T12:00:00",
            "is_verified": True,
        }
        json_str = json.dumps(nested_data)
        result = self.nested_parser.parse(json_str)

        assert isinstance(result, NestedModel)
        assert result.user.name == "John Doe"
        assert result.is_verified is True
        assert isinstance(result.created_at, datetime)

    def test_parse_with_extra_fields(self):
        """Test parsing JSON with extra fields (should be ignored)."""
        json_str = '{"value": "test", "count": 42, "extra_field": "ignored"}'
        result = self.simple_parser.parse(json_str)

        assert result.value == "test"
        assert result.count == 42
        # extra_field should be ignored

    def test_parse_unicode_content(self):
        """Test parsing with unicode characters."""
        json_str = '{"value": "café ñoño", "count": 42}'
        result = self.simple_parser.parse(json_str)

        assert result.value == "café ñoño"
        assert result.count == 42

    def test_parse_large_numbers(self):
        """Test parsing with large numbers."""
        json_str = '{"value": "test", "count": 999999999}'
        result = self.simple_parser.parse(json_str)

        assert result.count == 999999999

    def test_parse_negative_numbers(self):
        """Test parsing with negative numbers."""
        json_str = '{"value": "test", "count": -42}'
        result = self.simple_parser.parse(json_str)

        assert result.count == -42

    def test_parse_empty_string_value(self):
        """Test parsing with empty string values."""
        json_str = '{"value": "", "count": 0}'
        result = self.simple_parser.parse(json_str)

        assert result.value == ""
        assert result.count == 0

    def test_parser_exception_contains_llm_output(self):
        """Test that OutputParserException contains the original LLM output."""
        invalid_json = '{"invalid": json}'

        with pytest.raises(OutputParserException) as exc_info:
            self.simple_parser.parse(invalid_json)

        assert invalid_json in str(exc_info.value)

    def test_parse_result_empty_generation_list(self):
        """Test parse_result with empty generation list."""
        with pytest.raises(IndexError):
            self.simple_parser.parse_result([])

    def test_parse_boolean_values(self):
        """Test parsing boolean values."""
        user_data = {"name": "John", "age": 30, "email": "john@example.com"}
        nested_data = {"user": user_data, "created_at": "2023-01-01T12:00:00", "is_verified": False}
        json_str = json.dumps(nested_data)
        result = self.nested_parser.parse(json_str)

        assert result.is_verified is False

    def test_parse_null_values(self):
        """Test parsing null values for optional fields."""
        json_str = '{"name": "John", "age": 30, "email": "john@example.com", "address": null}'
        result = self.user_parser.parse(json_str)

        assert result.address is None

    @pytest.mark.parametrize(
        "invalid_input",
        [
            "",  # empty string
            "not json at all",  # plain text
            "123",  # just a number
            '"just a string"',  # just a string
            "[]",  # array instead of object
            '{"incomplete": }',  # malformed JSON
        ],
    )
    def test_parse_various_invalid_inputs(self, invalid_input):
        """Test parsing various invalid inputs."""
        with pytest.raises(OutputParserException):
            self.simple_parser.parse(invalid_input)

    def test_parse_whitespace_handling(self):
        """Test parsing with extra whitespace."""
        json_str = '\n  \t  {"value": "test", "count": 42}  \n\t  '
        result = self.simple_parser.parse(json_str)

        assert result.value == "test"
        assert result.count == 42


class TestErrorHandling:
    """Test error handling scenarios."""

    def test_unsupported_model(self):
        """Test error with unsupported model."""

        class InvalidModel:
            pass

        parser = PydanticOutputParser(pydantic_object=InvalidModel)

        with pytest.raises(OutputParserException) as exc_info:
            parser.parse("{}")

        assert "Unsupported model" in str(exc_info.value)
        assert "InvalidModel" in str(exc_info.value)

    def test_parser_exception_details(self):
        """Test OutputParserException contains proper details."""
        parser = PydanticOutputParser(pydantic_object=SimpleModel)
        json_str = '{"value": "test"}'  # missing required field

        with pytest.raises(OutputParserException) as exc_info:
            parser.parse(json_str)

        exception = exc_info.value
        assert "SimpleModel" in str(exception)
        assert json_str in str(exception)
