import datetime
from typing import Any, Dict, List, Tuple, Type

from pydantic import BaseModel, Field


class Property(BaseModel):
    """Defines a property with name, type, and description."""

    name: str
    type: Any
    description: str


class ToolSchema(BaseModel):
    """Base class for creating tool schemas with dynamic properties and tool_spec."""

    tool_spec: Dict[str, Any]

    @classmethod
    def create_tool_schema(
        cls,
        name: str,
        description: str,
        properties: List[Property],
        required: List[str],
    ) -> Type[BaseModel]:
        """Creates a tool schema with metadata and input schema."""
        fields = cls._create_fields(properties, required)
        model = cls._create_dynamic_model(name, properties, fields)
        cls._attach_tool_spec(model, name, description, properties, required)
        return model

    @staticmethod
    def _create_fields(properties: List[Property], required: List[str]) -> Dict[str, Tuple[Any, Field]]:
        """Generates fields for the schema based on properties and required fields."""
        return {
            prop.name: (
                prop.type,
                (
                    Field(..., description=prop.description)
                    if prop.name in required
                    else Field(None, description=prop.description)
                ),
            )
            for prop in properties
        }

    @staticmethod
    def _create_dynamic_model(
        name: str, properties: List[Property], fields: Dict[str, Tuple[Any, Field]]
    ) -> Type[BaseModel]:
        """Dynamically creates the Pydantic model."""
        model = type(
            name,
            (BaseModel,),
            {
                "__annotations__": {prop.name: prop.type for prop in properties},
                **fields,
            },
        )
        return model

    @staticmethod
    def _attach_tool_spec(
        model: Type[BaseModel], name: str, description: str, properties: List[Property], required: List[str]
    ) -> None:
        """Attach tool_spec and schema to the dynamically created model."""
        model.tool_spec = {
            "toolSpec": {
                "name": name,
                "description": description,
                "inputSchema": {"json": ToolSchema._generate_input_schema(properties, required)},
            }
        }
        model.get_schema = classmethod(ToolSchema._get_full_schema)

    @staticmethod
    def _generate_input_schema(properties: List[Property], required: List[str]) -> Dict[str, Any]:
        """Generates the input schema in JSON Schema format."""
        formatted_properties = {
            prop.name: {
                "type": ToolSchema._convert_type_to_json_schema_type(prop.type),
                "description": prop.description,
            }
            for prop in properties
        }

        return {
            "type": "object",
            "properties": formatted_properties,
            "required": required,
        }

    @staticmethod
    def _convert_type_to_json_schema_type(python_type: Any) -> str:
        """Converts Python types to JSON Schema types."""

        type_mapping = {
            str: "string",
            int: "integer",
            float: "number",
            bool: "boolean",
            list: "array",
            dict: "object",
            None: "null",
            datetime.date: "string",
            datetime.datetime: "string",
        }
        return type_mapping.get(python_type, "string")

    @staticmethod
    def _get_full_schema(cls: Type[BaseModel]) -> dict:
        """Returns the full tool_spec, including name, description, and inputSchema."""
        return cls.tool_spec


class ToolChoice:
    def __init__(self, choice: str, tool_name: str = ""):
        self.choice = choice
        self.tool_name = tool_name

        # Define schema based on the choice
        self.schema = self._get_schema()

    def __repr__(self):
        return f"ToolChoice(choice={self.choice}, schema={self.schema})"

    def _get_schema(self) -> Dict[str, Any]:
        """Generate the schema based on the selected tool choice."""
        if self.choice == "tool":
            if not self.tool_name:
                raise ValueError("Tool name must be provided when the choice is 'tool'")
            return {"tool": {"name": self.tool_name}}
        elif self.choice == "any":
            return {"any": {}}
        elif self.choice == "auto":
            return {"auto": {}}
        else:
            raise ValueError("Invalid tool choice")


class ToolRequestQutput(BaseModel):
    """Represents the output of a tool request."""

    id: str
    name: str
    parameters: Dict[str, Any]

    def __repr__(self):
        return f"ToolRequestQutput(id={self.id}, name={self.name}, parameters={self.parameters})"
