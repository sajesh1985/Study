import logging
from typing import Any, List, Tuple, Union

import pandas as pd

from chatrd.core.document import (
    CSDTableResponse,
    Document,
    ParentChildTableResponse,
    TableDocument,
    TableResponse,
)
from chatrd.core.synthesizer import BaseResponseSynthesizer
from chatrd.core.synthesizer.structured import StructuredSynthesizer
from chatrd.core.thread_utils import submit_to_shared_thread_pool
from chatrd.core.utils import ChatMessage
from chatrd.engine.components.query_analyzer.guideline_generator import (
    GuidelineGenerator,
)
from chatrd.engine.components.query_processor.query_synthesizer.utils import (
    criteria_link,
    get_next_untitled_table_name,
    research_link,
    split_documents,
)
from chatrd.engine.components.schema import QueryProcessorInput
from chatrd.engine.components.state_machine import StateMachine
from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.prompts import EXPERT_GUIDELINES
from chatrd.engine.responses import get_default_answer
from chatrd.engine.utils import ChatResponse

logger = logging.getLogger(__name__)

config_machinery = get_config_machinery()


class QuerySynthesizer(StateMachine):
    def __init__(self):
        super().__init__(
            machine_role="QuerySynthesizer",
            failure_response="Query Synthesizer Failed.",
            success_response="Query Synthesizer Success.",
        )

    def _execute_internal(
        self,
        message: ChatMessage,
        chat_history: List[ChatMessage],
        documents: List[Union[Document, TableDocument]],
        text_synthesizer: BaseResponseSynthesizer,
        structured_synthesizer: StructuredSynthesizer,
        query_processor_input: QueryProcessorInput,
    ) -> Tuple[str, str]:
        """
        Synthesize documents split by table/non-table type.
        Returns: (table_response, non_table_response)
        """

        # Split documents
        table_documents, non_table_documents = split_documents(documents)

        structured_response = None
        text_response = None
        selected_table_documents = None

        # Synthesize table documents
        if table_documents:
            logger.info(f"Synthesizing {len(table_documents)} table documents")
            structured_response, selected_table_documents = structured_synthesizer.synthesize(
                message, table_documents, chat_history
            )

            logger.info(f"structured_response in synthesizer is  {structured_response} ")

        # Synthesize text documents
        if non_table_documents:
            logger.info(f"Synthesizing {len(non_table_documents)} text documents")
            if not text_synthesizer.exclude_llm_metadata_super_list:
                text_synthesizer.exclude_llm_metadata_super_list = config_machinery.get_config_value(
                    Constants.GeneralConstants.EXCLUDE_LLM_METADATA_SUPER_LIST
                )
            structured_response_str = ""
            if structured_response:
                for r in structured_response:
                    if r["type"] == "text":
                        structured_response_str += r["content"] + "\n"
                    elif r["type"] == "table":
                        if isinstance(r["content"], TableResponse):
                            structured_response_str += pd.DataFrame(r["content"].rows).to_markdown(index=False) + "\n"
                        elif isinstance(r["content"], CSDTableResponse) or isinstance(
                            r["content"], ParentChildTableResponse
                        ):
                            structured_response_str += pd.DataFrame(r["content"].data).to_markdown(index=False) + "\n"
                        elif isinstance(r["content"], pd.DataFrame):
                            structured_response_str += r["content"].to_markdown(index=False) + "\n"
                        else:
                            logger.info(
                                "Some issue occured with expected data format from structured synthesizer: \n" + str(r)
                            )
                            structured_response_str += str(r["content"]) + "\n"
                    else:
                        logger.info(
                            "Some issue occured with expected data format from structured synthesizer: \n" + str(r)
                        )
                        structured_response_str += str(r["content"]) + "\n"

            # Updating guidelines and company info
            structured_data_exists = True if structured_response else False
            future_guideline = submit_to_shared_thread_pool(
                self.generate_guideline, query_processor_input, structured_data_exists
            )
            guideline_result = future_guideline.result()
            guidelines = getattr(guideline_result, "guidelines", "")
            guidelines = guidelines if guidelines else EXPERT_GUIDELINES
            text_synthesizer.update_prompt_templates({"guidelines": guidelines})
            text_synthesizer.update_prompt_templates(
                {"language": query_processor_input.analyzer_output.original_language}
            )
            text_response = text_synthesizer.synthesize(
                message, non_table_documents, chat_history, structured_response=structured_response_str
            )

        return (self.post_processed_structured_response_documents(structured_response, selected_table_documents)), (
            text_response,
            non_table_documents,
        )

    def post_processed_structured_response_documents(
        self, structured_response: Any, structured_synthesize_docs: List[Document]
    ):
        if structured_response is None:
            return [], []

        response = ""
        for res in structured_response:
            if res["type"] == "text":
                response = response + res["content"] + "\n\n"
            elif res["type"] == "table":
                if isinstance(res["content"], pd.DataFrame):
                    response = response + res["content"].to_markdown(index=False) + "\n\n"
                elif isinstance(res["content"], TableResponse):
                    response = response + pd.DataFrame(res["content"].rows).to_markdown(index=False) + "\n\n"

        metadata = {}
        metadata["response_payload"] = None
        source_descriptions = []
        for doc in structured_synthesize_docs:
            if "source_description" in doc.metadata and doc.metadata["source_description"] is not None:
                for source in doc.metadata["source_description"]:
                    source_descriptions.append(source)
            elif doc.metadata is not None and "articleID" in doc.metadata:
                table_title = doc.metadata.get("table_title", None)
                article_title = doc.metadata.get("PreferredTitle", doc.metadata.get("SourceTitle"))
                if table_title is None:
                    table_title = get_next_untitled_table_name(source_descriptions)
                if not ("Untitled table" in table_title):
                    table_title = f"'{table_title}'" + " Table"
                source_name = table_title + ", " + article_title
                source_url = ""
                if doc.metadata["articleSubType"] in ["CRITERIA", "CRITERIA_GUIDANCE"]:
                    source_url = criteria_link.substitute(id=doc.metadata.get("SourceObjectID", ""))
                else:
                    source_url = research_link.substitute(id=doc.metadata.get("articleID", ""))
                source_descriptions.append((source_name, source_url))

        metadata["source_description"] = source_descriptions
        metadata["response_type"] = "text"

        doc = Document(content=response, metadata=metadata, synthesize=False)

        return [{"type": "text", "content": response}], [doc]

    def generate_guideline(self, inputs: QueryProcessorInput, structured_data_exists: bool) -> ChatResponse:
        guideline_generator = GuidelineGenerator(
            model_name=inputs.llm_for_non_flex_synthesizer, temperature=inputs.temperature_for_non_flex_synthesizer
        )

        # flex_arch logic
        if inputs.analyzer_output.uc_type == "multi":

            guidelines_result = guideline_generator.run(
                query=inputs.analyzer_output.rephrased_query,
                uc_type="flex_arch",
                entity_type=None,
                original_message=inputs.analyzer_output.original_query,
            )
            return guidelines_result
        # end flex_arch logic
        elif inputs.analyzer_output.uc_type == "selected_article":
            guidelines_result = guideline_generator.run(
                query=inputs.analyzer_output.rephrased_query,
                uc_type="general",
                entity_type=None,
                original_message=inputs.analyzer_output.original_query,
            )
        elif inputs.analyzer_output.uc_type == "outlook":
            guidelines_result = guideline_generator.run(
                query=inputs.analyzer_output.rephrased_query,
                uc_type=inputs.analyzer_output.uc_type,
                entity_type=inputs.analyzer_output.entity_type,
                original_message=inputs.analyzer_output.original_query,
                subrouting_result=inputs.analyzer_output.subrouting_result,
            )
            if isinstance(guidelines_result, ChatResponse):
                return get_default_answer(
                    original_language=inputs.analyzer_output.original_language,
                    original_query=inputs.analyzer_output.original_query,
                )
        elif inputs.analyzer_output.uc_type in [
            "macro",
            "general",
        ]:
            guidelines_result = guideline_generator.run(
                query=inputs.analyzer_output.rephrased_query,
                uc_type="general",
                entity_type=None,
                original_message=inputs.analyzer_output.original_query,
                structured_data_exists=structured_data_exists,
            )
        elif inputs.analyzer_output.uc_type == "criteria":
            guidelines_result = guideline_generator.run(
                query=inputs.analyzer_output.rephrased_query,
                uc_type="criteria",
                entity_type=None,
                original_message=inputs.analyzer_output.original_query,
                structured_data_exists=structured_data_exists,
            )
        else:
            guidelines_result = guideline_generator.run(
                query=inputs.analyzer_output.rephrased_query,
                uc_type=inputs.analyzer_output.uc_type,
                entity_type=inputs.analyzer_output.entity_type,
                original_message=inputs.analyzer_output.original_query,
            )
            if isinstance(guidelines_result, ChatResponse):
                return get_default_answer(
                    original_language=inputs.analyzer_output.original_language,
                    original_query=inputs.analyzer_output.original_query,
                )
        return guidelines_result
