from typing import Any, Dict, Optional, List, Union

from pydantic import BaseModel, Field

from datetime import datetime

from src.synthia.utils.source import Source


class MCPResponse(BaseModel):
    sources: (Source | List[Source] | None) = Field(None, description="Source in form of title and URL for MCP tool.")
    data: Optional[Any] = Field(None, description="data of MCP tool.")
    isError: Optional[bool] = Field(False, description="Flag indicating if the response is an error.")
    message: Optional[str] = Field(None, description="Optional message providing additional information about the response or error.")

class ErrorResponse(BaseModel):
    error: str = Field(description="Error message describing the failure.")


class QuarterInfo(BaseModel):
    name: str = Field(
        description="Name of the quarter or period, e.g., '2024 FQ2' or 'LTM'."
    )
    value: str = Field(
        description="Value for the specified quarter or period."
    )
    periodEndDate: Optional[str] = Field(
        None, description="End date of the period, if available."
    )
    LastUpdateDate: Optional[str] = Field(
        None, description="Last update date for the data, if available."
    )


class MetricEntry(BaseModel):
    CreditStatsMetricCaption: str = Field(
        description="Caption describing the credit stats metric."
    )
    Threshold: str = Field(
        description="Threshold value for the metric, e.g., '<18%' or '>16%'.",
        examples=['<18%', '>16%']
    )
    LatestQuarter: QuarterInfo = Field(
        description="Information about the latest quarter for the metric."
    )
    Ltm: QuarterInfo = Field(
        description="Information about the last twelve months (LTM) \
            for the metric."
    )
    ReportedCurrency: str = Field(
        description="Currency in which the metric is reported."
    )


class TransformedOutlook(BaseModel):
    downside: List[MetricEntry] = Field(
        [], description="List of downside metric entries."
    )
    upside: List[MetricEntry] = Field(
        [], description="List of upside metric entries."
    )


class FinancialOutlookThresholdResponse(BaseModel):
    sources: Source | None = Field(
        None, description="Source URL of the financial outlook data."
    )
    value: TransformedOutlook | ErrorResponse = Field(
        description="Company financial outlook threshold current data or error response."
    )


class MoodyLatestRating(BaseModel):
    KeyInstn: int = Field(
        ..., description="The company or institution identifier."
    )
    CreditRating: Optional[str] = Field(
        None, description="The Moody's credit rating (e.g., 'A1', 'WR')."
    )
    RatingsAsOf: Optional[str] = Field(
        None, description="The date and time the rating was assigned (ISO 8601 format)."
    )
    CreditWatchOutlook: Optional[str] = Field(
        None, description="The outlook or watch status for the rating."
    )
    RatingType: Optional[str] = Field(
        None, description="The type of Moody's rating (e.g., 'Long Term Rating')."
    )
    GroupType: Optional[str] = Field(
        None, description="The group type for the rating (optional)."
    )

class MoodyHistRating(BaseModel):
    KeyInstn: int = Field(
        ..., description="The company or institution identifier."
    )
    CreditRating: Optional[str] = Field(
        None, description="The Moody's credit rating (e.g., 'A1', 'WR')."
    )
    RatingsAsOf: Optional[str] = Field(
        None, description="The date and time the rating was assigned (ISO 8601 format)."
    )
    CreditWatchOutlook: Optional[str] = Field(
        None, description="The outlook or watch status for the rating."
    )
    RatingType: Optional[str] = Field(
        None, description="The type of Moody's rating (e.g., 'Long Term Rating')."
    )
    GroupType: Optional[str] = Field(
        None, description="The group type for the rating (optional)."
    )


class FitchLatestRating(BaseModel):
    KeyInstn: int = Field(
        ..., description="The company or institution identifier."
    )
    CreditRating: Optional[str] = Field(
        None, description="The Fitch credit rating (e.g., 'A1', 'WR')."
    )
    RatingsAsOf: Optional[str] = Field(
        None, description="The date and time the rating was assigned (ISO 8601 format)."
    )
    CreditWatchOutlook: Optional[str] = Field(
        None, description="The outlook or watch status for the rating."
    )
    RatingType: Optional[str] = Field(
        None, description="The type of Fitch's rating (e.g., 'Long Term Rating')."
    )
    GroupType: Optional[str] = Field(
        None, description="The group type for the rating (optional)."
    )

class FitchHistRating(BaseModel):
    KeyInstn: int = Field(
        ..., description="The company or institution identifier."
    )
    CreditRating: Optional[str] = Field(
        None, description="The Fitch credit rating (e.g., 'A1', 'WR')."
    )
    RatingsAsOf: Optional[str] = Field(
        None, description="The date and time the rating was assigned (ISO 8601 format)."
    )
    CreditWatchOutlook: Optional[str] = Field(
        None, description="The outlook or watch status for the rating."
    )
    RatingType: Optional[str] = Field(
        None, description="The type of Fitch's rating (e.g., 'Long Term Rating')."
    )
    GroupType: Optional[str] = Field(
        None, description="The group type for the rating (optional)."
    )

class MoodyRatingsResponse(BaseModel):
    sources: List[Source] = Field(
        ..., description="Metadata and source URL for traceability."
    )
    data: Dict[str, List[MoodyLatestRating]] = Field(
        ..., description="Dictionary containing MoodyRating list."
    )


class CompanyDescriptionDataModel(BaseModel):
    description: Optional[str] = Field(
        "", description="The brief business description of the company."
    )
    long_description: Optional[str] = Field(
        "", description="The long business description of the company."
    )
    country_short_name: Optional[str] = Field(
        "", description="The short name of the country where the company is headquartered."
    )
    date_incorporated_year: Optional[str] = Field(
        "", description="The year the company was incorporated."
    )
    sic_code_display: Optional[str] = Field(
        "", description="The SIC code display for the company."
    )
    nace_code_display: Optional[str] = Field(
        "", description="The NACE code display for the company."
    )
    naics_code_display: Optional[str] = Field(
        "", description="The NAICS code display for the company."
    )
    activity_code_display: Optional[str] = Field(
        "", description="The activity code display for the company."
    )
    keyInstn: str = Field(
        None, description="S&P's unique key to identify institutions."
    )
    Headcount: Optional[int] = Field(None, description="Number of employees in the company.")
    FloatPercent: Optional[str] = Field("", description="The float percent of the company.")
    InstOwnershipPercent: Optional[str] = Field("", description="The institutional ownership percent of the company.")
    countryKeyInstn: Optional[int] = Field(None, description="The country key institution ID.")
    KeyCountry: Optional[str] = Field("", description="The key country code.")

class CompanyOfficerItem(BaseModel):
    title: Optional[str] = Field(None, description="The title of the officer.")
    biography: Optional[str] = Field(None, description="The biography of the officer.")
    name: Optional[str] = Field(None, description="The name of the officer.")
    keyPersonUrl: Optional[str] = Field(None, description="The URL to the officer's profile on the CIQPro site.")

class OwnershipSummaryItem(BaseModel):
    LenderType: str = Field(..., description="Type of owner (e.g., Institutions, Individuals/Insiders).")
    CommonStockEquivalentHeld: Optional[str] = Field(None, description="Number of shares held (as string).")
    MarketValueOfOwnership: str = Field(..., description="Market value of the holding (as string, usually in millions).")
    CommonSharesOutstandingPercent: Optional[str] = Field(None, description="Percentage of total shares outstanding (as string).")    
    PricingAsof: datetime = Field(..., description="Date the data is as of (ISO format string).")
    

class TopHoldersActivityChartDataItem(BaseModel):
    FactSetCompanyID: int = Field(..., description="Unique ID for the company/holder (integer).")
    FndgNameOfHolder: str = Field(..., description="Name of the holder.")
    CommonStockEquivalentHeld: str = Field(..., description="Number of shares held at the given date (as string).")
    DateEndedStandard: datetime = Field(..., description="Date of the holding (ISO format string).")

class TopHoldersItem(BaseModel):
    FndgNameOfHolder: str = Field(..., description="Name of the holder.")
    CommonStockEquivalentHeld: str = Field(..., description="Number of shares held (as string).")
    MarketValueOfOwnership: str = Field(..., description="Market value of the holding (as string).")
    CommonSharesOutstandingPercent: str = Field(..., description="Percentage of total shares outstanding (as string).")
    OwnershipInformationDate: datetime = Field(..., description="Date the ownership info was reported (ISO format string).")
    DateEndedStandard: datetime = Field(..., description="Period end date (ISO format string).")
    KeyCurrency: str = Field(..., description="Currency code (e.g., 'USD').")
    KeyInstnOwner: Optional[int] = Field(None, description="Unique key for the institution owner (integer, may be null).")

class ResponseModel(BaseModel):
    OwnershipSummary: List[OwnershipSummaryItem] = Field(..., description="Breakdown of ownership by lender type.")
    TopHoldersActivityChartData: List[TopHoldersActivityChartDataItem] = Field(..., description="Historical holding data for top holders.")
    TopHolders: List[TopHoldersItem] = Field(..., description="List of top holders with details.")
    KeyCurrency: str = Field(..., description="Currency code for the ownership values (e.g., 'USD').")
    PricingAsof: str = Field(..., description="Date as of which the pricing and ownership data is reported (ISO format string).")

class KeyDevelopmentItem(BaseModel):
    KeyDevelopmentTypeName: Optional[str] = Field(None, description="Key Development Type Name.")
    KeyDevelopmentHeadline: Optional[str] = Field(None, description="Headline of the key development.")
    CIQDevelopmentDateBestUTC: Optional[str] = Field(None, description="The date on which the key development was best recorded in UTC format.")
    DevelopmentAbstract: Optional[str] = Field(None, description="A brief summary of the key development.")

class CompanyKeyDevelopmentsResponse(BaseModel):
    sources: List[Source] = Field(..., description="List of sources for each key development.")
    data: List[KeyDevelopmentItem] = Field(..., description="List of key development items.")


class SpLatestCreditRating(BaseModel):
    RatingDate: datetime = Field(..., description="Date when the rating was assigned (ISO format string).")
    RatingType: str = Field(..., description="Type of rating (e.g., 'Foreign Currency LT', 'Local Currency ST').")
    DebtType: str = Field(..., description="Type of debt instrument being rated (e.g., 'Issuer Credit Rating', 'Bond Rating').")
    RatingSymbol: str = Field(..., description="The actual credit rating symbol (e.g., 'AA-', 'BBB+', 'A1').")
    CreditWatchOutlook: Optional[str] = Field(None, description="Credit watch or outlook status (e.g., 'Watch Neg', 'Stable', 'Positive').")
    CreditWatchOutlookDate: Optional[datetime] = Field(None, description="Date when the credit watch or outlook was assigned (ISO format string).")
    LastReviewDate: Optional[datetime] = Field(None, description="Date when the rating was last reviewed (ISO format string).")

class SpHistCreditRating(BaseModel):
    RT_RATING_TYPE_CODE: Optional[str] = Field(None, description="Rating type code (e.g., Foreign Currency LT).")
    RT_DEBT_TYPE_CODE: Optional[str] = Field(None, description="Debt type code (e.g., Issuer Credit Rating).")
    RT_CURRENT_RATING_SYMBOL: Optional[str] = Field(None, description="Current rating symbol.")
    RT_RATING_DATE: Optional[str] = Field(None, description="Rating date in ISO format.")
    RT_CURRENT_CW_OL: Optional[str] = Field(None, description="Current Credit Watch/Outlook.")
    RT_CURRENT_CW_OL_DATE: Optional[str] = Field(None, description="Current Credit Watch/Outlook date in ISO format.")
    RT_CURRENT_CW_OL_ACTION_WORD: Optional[str] = Field(None, description="Current CW/OL action word.")
    
class CorporateStructureItem(BaseModel):
    PercentOwned: Optional[float] = Field(None, description="Percentage of ownership stake.")
    InstnName: Optional[str] = Field(None, description="Name of the institution/company.")
    IndustryLongName: Optional[str] = Field(None, description="Full industry classification name.")
    Country: Optional[str] = Field(None, description="Country where the entity is located.")
    CompanyRelationshipType: Optional[str] = Field(None, description="Type of corporate relationship.")
    KeyInstn: Optional[int] = Field(None, description="Unique key identifier for the institution.")
    KeyInstnParent: Optional[int] = Field(None, description="Unique key identifier for the parent institution.")
    SortOrder: int = Field(0, description="Sort order based on the Id field from the response.")

class DenimResponseType(BaseModel):
    Symbol: str = Field(None, description="Company symbol")
    Metric: str = Field(None, description="Metric name")
    date: Optional[str] = Field(None, description="Date of the metric value")
    value: Optional[str] = Field(None, description="Metric value")
    CurrencyId: Optional[str] = Field(None, description="Currency code")

class ReducedDenimResponse(BaseModel):
    date: Optional[str] = Field(None, description="Date of the metric value")
    value: Optional[str] = Field(None, description="Metric value")
    CurrencyId: Optional[str] = Field(None, description="Currency code")
    display_name: Optional[str] = Field(None, description="Display name")

class RDIndustryDataModel(BaseModel):
    sector: Optional[Union[str, List[str]]] = Field(None, description="RD sector(s) or None.")
    sub_sector: Optional[Union[str, List[str]]] = Field(None, description="RD sub-sector(s) or None.")
    industry: Optional[Union[str, List[str]]] = Field(None, description="RD industry/industries or None.")
    is_rd_entity: bool = Field(..., description="True if 'RDIndustries' is present, else False.")

class MIIndustryDataModel(BaseModel):
    mi_industry: Optional[Union[str, List[str]]] = Field(None, description="MI industry/industries or None.")
    is_rd_entity: bool = Field(..., description="True if 'RDIndustries' is present, else False.")

class CIQIndustryDataModel(BaseModel):
    ciq_industry: Optional[Union[str, List[str]]] = Field(None, description="CIQ industry/industries or None.")
    is_rd_entity: bool = Field(..., description="True if 'RDIndustries' is present, else False.")

class NewsArticleItem(BaseModel):
    headline: Optional[str] = Field(None, description="Headline of the news article.")
    published: Optional[str] = Field(None, description="Published date/time of the article.")
    abstract: Optional[str] = Field(None, description="Abstract/summary of the article.")
    key: Optional[int] = Field(None, description="Unique key for the article.")

class CompanyNewsResponse(BaseModel):
    newsArticle: List[NewsArticleItem] = Field(default_factory=list, description="List of news articles.")
    base_article_url: Optional[str] = Field(None, description="Base URL for viewing full articles.")

class CompanyEsgScoreResponse(BaseModel):
    year: int = Field(None, description="Represent the data of particular year")
    score_type: str = Field(None, description="Represent the company score type, Eg. ESG Score, Environmental Score, Social Score, Governance & Economic Score")
    company_score: int = Field(None, description="Represent company score")
    industry_avg_score: int = Field(None, description="Represent industry average score")
    industry_min_score: int = Field(None, description="Represent min score for the year")
    industry_max_score: int = Field(None, description="Represent max score for the year")
    dimension: str = Field(None, description="Represent mapping of score type")
    weight_in_percentage: int = Field(None, description="Represent the weight percentage")

class EquityStat(BaseModel):
    value: Optional[float | int] = Field(None, description="Value of the equity statistic.")
    asOf: Optional[str] = Field(None, description="Date the statistic is as of (ISO format).")

class MarketCapEquityStats(BaseModel):
    marketCap: Optional[EquityStat] = Field(..., description="Market capitalization statistic.")
    avg3MDailyVolume: Optional[EquityStat] = Field(None, description="Average 3-month daily volume statistic.")
    beta3Y: Optional[EquityStat] = Field(None, description="3-year beta statistic.")
    divYield: Optional[EquityStat] = Field(None, description="Dividend yield statistic.")
    sharesOutstanding: Optional[EquityStat] = Field(None, description="Shares outstanding statistic.")
    sharesSoldShort: Optional[EquityStat] = Field(None, description="Shares sold short statistic.")
    shortInShOut: Optional[EquityStat] = Field(None, description="Short interest in shares outstanding statistic.")
    totalEnterpriseValue: Optional[EquityStat] = Field(None, description="Total enterprise value statistic.")

class MarketCapData(BaseModel):
    currency: Optional[str] = Field(None, description="Currency code for the market cap value.")
    exchange: Optional[str] = Field(None, description="Exchange short name.")
    equityStats: Optional[MarketCapEquityStats] = Field(None, description="Detailed equity statistics.")

class MarketCapDataResponse(BaseModel):
    data: Optional[MarketCapData] = Field(None, description="Market cap response data.")
    error: Optional[str] = Field(None, description="Error message if the request failed.")

class MarketExchangeData(BaseModel):
    name: Optional[str] = Field(None, description="Name of the exchange.")
    exchangeCode: Optional[str] = Field(None, description="Exchange code (e.g., 'XNYS').")

class MarketEquityLatestPrice(BaseModel):
    price: Optional[EquityStat] = Field(None, description="Latest price metric.")
    open: Optional[EquityStat] = Field(None, description="Open price metric.")
    close: Optional[EquityStat] = Field(None, description="Close price metric.")
    high: Optional[EquityStat] = Field(None, description="High price metric.")
    low: Optional[EquityStat] = Field(None, description="Low price metric.")
    volume: Optional[EquityStat] = Field(None, description="Volume metric.")
    vwap: Optional[EquityStat] = Field(None, description="Volume-weighted average price metric.")
    bid: Optional[EquityStat] = Field(None, description="Bid price metric.")
    ask: Optional[EquityStat] = Field(None, description="Ask price metric.")
    changePrice: Optional[EquityStat] = Field(None, description="Change in price metric.")
    changePercentage: Optional[EquityStat] = Field(None, description="Change in price percentage metric.")

class MarketEquityCurrency(BaseModel):
    name: str = Field(..., description="Name of the currency.")
    symbol: str = Field(..., description="Symbol of the currency.")

class MarketEquityInstn(BaseModel):
    name: str = Field(..., description="Name of the institution.")
    websiteUrl: str = Field(..., description="Website URL of the institution.")

class MarketEquityData(BaseModel):
    keyFndg: int = Field(..., description="Unique identifier for the equity.")
    keyUniversalEntity: str = Field(..., description="Universal entity key for the equity.")
    symbol: str = Field(..., description="Ticker symbol of the equity.")
    dividend: Optional[float] = Field(None, description="Dividend value if available.")
    exchange: Optional[MarketExchangeData] = Field(None, description="Exchange details.")
    latestPrice: Optional[MarketEquityLatestPrice] = Field(None, description="Latest price metrics.")
    currency: Optional[MarketEquityCurrency] = Field(None, description="Currency details.")
    instn: Optional[MarketEquityInstn] = Field(None, description="Institution details.")

class MarketEquityDataResponse(BaseModel):
    data: Optional[MarketEquityData] = Field(None, description="Market equity details response data.")
    error: Optional[str] = Field(None, description="Error message if the request failed.")

class SeriesResponse(BaseModel):
    currency: Optional[str] = Field(None, description="Currency code for the series data.") 
    data: Optional[Dict[str, Optional[float]]] = Field(default_factory=dict, description="Dictionary with date as key and a float or None as value.")

class StockChartResponse(BaseModel):
    benchmark: Optional[str] = Field(None, description="Name of the benchmark index or security.")
    currency: Optional[Dict[str, Optional[str]]] = Field(
        default_factory=dict,
        description=(
            "Dictionary with metric keys and their corresponding currency codes. "
            "Example: {'closing_price': 'USD', 'trading_volume': 'USD', 'closing_index_value': 'USD'}"
        ),
    )
    datapoint: Optional[Dict[str, Dict[str, Optional[float]]]] = Field(
        default_factory=dict,
        description=(
            "Dictionary with date as key and a dict of metric keys and values. "
            "Example: {'2024-09-17': {'closing_price': 39.55, 'trading_volume': 27769380.0, 'closing_index_value': 1234.56}, ...}"
        ),
    )

class CDSParSpreadValue(BaseModel):
    parSpreadMidIn: float = Field(..., description="CDS par spread (mid) value.")

class CDSParSpreadMap(BaseModel):
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Identifier metadata from CDSCurveIdentifiers (e.g., tier, docClause, currency).")
    series: Dict[str, CDSParSpreadValue] = Field(default_factory=dict, description="Date-keyed map (DD-MM-YYYY) of CDS par spread mid values.")
      
class ArticleItem(BaseModel):
    article_id: int = Field(..., description="Article ID of the article.")
    content: str = Field(..., description="Main content of the article.")

class MacroEconomicStandardDataRecord(BaseModel):
    KeyECRMacroPeriod: Optional[int] = None
    DataSourcePeriodDisplay: Optional[str] = None
    RealGDPGrowthAR: Optional[float] = None
    RealGDPLCUAR: Optional[float] = None
    NominalGDPAR: Optional[float] = None
    RealGDPAR: Optional[float] = None
    NominalGDPLCUAR: Optional[float] = None
    ConsumerPriceInflationAR: Optional[float] = None
    ProducerPriceInflationAR: Optional[float] = None
    IndustrialProductionGrowthAR: Optional[float] = None
    ECRUnemploymentRateAR: Optional[float] = None
    CurrentAccountBalanceAR: Optional[float] = None
    ImportedGoodsAR: Optional[float] = None
    ExportedGoodsAR: Optional[float] = None
    TradeBalanceAR: Optional[float] = None
    AverageExchangeRateAR: Optional[float] = None
    ExchangeRateEndAR: Optional[float] = None
    KeyCurrency: Optional[str] = None
    DateBegun: Optional[str] = None

class EconomyInPerspectiveRecord(BaseModel):
    """Data model for a single record from the Economy In Perspective endpoint."""
    Country: Optional[str] = Field(None, description="Country code (e.g., 'US', 'CN')")
    CountryRegion: Optional[str] = Field(None, description="Formal English name of the country or region")
    NominalGDP: Optional[float] = Field(None, description="Nominal gross domestic product (GDP) by expenditure in billions USD. Includes consumption, investment, government spending and net exports.")
    RealGDPGrowth: Optional[float] = Field(None, description="Percent change in Real Gross Domestic Product (RGDP) by expenditure, over previous year")
    GDPPerCapita: Optional[float] = Field(None, description="Nominal gross domestic product (GDP) divided by population in USD")
    BudgetBalanceGDP: Optional[float] = Field(None, description="General government revenue minus expenditure as percent of GDP; central government used where general is unavailable")
    PublicDebtGDP: Optional[float] = Field(None, description="Public debt to gross domestic product (GDP) represents general government debt, both domestic and foreign; central government used where general is unavailable, as percent of GDP")
    RealGrossFixedInvestmentGrowth: Optional[float] = Field(None, description="Percent change in real residential and non-residential fixed investment expenditure, over previous year")
    ConsumerPriceInflation: Optional[float] = Field(None, description="Percent change in consumer price index, over previous year")

class CompanyEstimatesConsensusRecord(BaseModel):
    """
    Data model for a single consensus estimate record from the AIReportBuilder endpoint.
    This reflects the long-format data returned by the API.
    """
    EstimatePeriod: Optional[str] = Field(None, description="The specific estimate period, e.g., 'FY 2023 - Jun 2023'.")
    EstimateOf: Optional[str] = Field(None, description="The metric code for the estimate, e.g., 'REV '.")
    ProductCaption: Optional[str] = Field(None, description="The type of data, e.g., 'Actuals/Estimates' or 'Median'.")
    EstimateConsensusMedian: Optional[float] = Field(None, description="The median value of the consensus estimate.")
    EstimateConsensusDeviation: Optional[float] = Field(None, description="The standard deviation of the consensus estimate.")
    EstimatesActual: Optional[float] = Field(None, description="The actual reported value for the period, if available.")
    AccountingPrincipleShort: Optional[str] = Field(None, description="The accounting standard, e.g., 'IFRS'.")
    EstimateOfDescription: Optional[str] = Field(None, description="The human-readable description of the metric, e.g., 'Revenue'.")
    Year: Optional[int] = Field(None, description="The fiscal year of the estimate.")
    Definition: Optional[str] = Field(None, description="The definition of the estimated metric.")
