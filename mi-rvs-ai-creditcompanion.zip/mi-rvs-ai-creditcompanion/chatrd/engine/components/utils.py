from enum import Enum


class RetrieverType(Enum):
    CRIETRIA = "criteria"
    RESEARCH = "research"
    DATA_SERVICE = "data_service"
