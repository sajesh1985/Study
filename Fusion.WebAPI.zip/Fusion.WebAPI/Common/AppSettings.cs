﻿using Fis.Epp.Fusion.Auth.Common;

namespace Fis.Epp.Fusion.WebAPI.Common
{
    public class AppSettings
    {
        public string ResourcesPath { get; set; }
        public string CorsAllowedOrigins { get; set; }
        public string CorsAllowedMethods { get; set; }
        public string CorsAllowedHeaders { get; set; }
        public bool EnableCorsPolicy { get; set; }
        public string _TokenSigningKey;
        public string TokenSigningKey
        {
            get { return _TokenSigningKey; }
            set
            {
                _TokenSigningKey = EncryptDecryptHelper.DecryptStringFromBytes_Aes(value);
            }
        }
    }
}
