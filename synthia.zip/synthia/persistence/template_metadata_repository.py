from psycopg.rows import dict_row
from typing import List
from uuid import UUID


class DatabaseTemplateMetadataRepository:
    class Columns:
        Id = 'id'
        CompanyName = 'company_name'
        TemplateName = 'template_name'
        TemplateDescription = 'template_description'
        TemplateConfigFileName = 'template_config_file_name'

    def __init__(self):
        self.table_name = 'product.templates'
        self.columns = DatabaseTemplateMetadataRepository.Columns

        # this import fixes the exceptions when importing anything from the services module, because importing database_manager requires aws credentials...
        from src.synthia.persistence.database_manager import get_connection_pool
        self.get_connection_pool = get_connection_pool

    async def get_templates_metadata(self, company_name: str | None) -> List[dict]:
        async with self.get_connection_pool().connection() as connection:
            async with connection.cursor(row_factory=dict_row) as cursor:
                if company_name:
                    sql = f"""SELECT * FROM {self.table_name}
                              WHERE {self.columns.CompanyName}=%s"""
                    params = (company_name,)
                else:
                    sql = f"""SELECT * FROM {self.table_name}"""
                    params = ()
                await cursor.execute(sql, params)
                return await cursor.fetchall()

    async def get_template_metadata_by_id(self, company_name: str, template_id: UUID) -> dict | None:
        async with self.get_connection_pool().connection() as connection:
            async with connection.cursor(row_factory=dict_row) as cursor:
                sql = f"""SELECT * FROM {self.table_name}
                          WHERE {self.columns.CompanyName}=%s 
                            AND {self.columns.Id}=%s"""
                params = (company_name, template_id)
                await cursor.execute(sql, params)
                return await cursor.fetchone()

    async def get_template_metadata_by_template_name(self, company_name: str, template_name: str) -> dict | None:
        async with self.get_connection_pool().connection() as connection:
            async with connection.cursor(row_factory=dict_row) as cursor:
                sql = f"""SELECT * FROM {self.table_name}
                          WHERE {self.columns.CompanyName}=%s 
                            AND {self.columns.TemplateName}=%s"""
                params = (company_name, template_name)
                await cursor.execute(sql, params)
                return await cursor.fetchone()

    async def create_template_metadata(self, company_name: str, template_name: str, template_description: str, template_config_file_name:str):
        async with self.get_connection_pool().connection() as connection:
            async with connection.cursor(row_factory=dict_row) as cursor:
                sql = f"""INSERT INTO {self.table_name} (
                            {self.columns.CompanyName}, 
                            {self.columns.TemplateName}, 
                            {self.columns.TemplateDescription}, 
                            {self.columns.TemplateConfigFileName}
                          )
                          VALUES (%s, %s, %s, %s)"""
                params = (company_name, template_name, template_description, template_config_file_name)
                await cursor.execute(sql, params)

    async def update_template_metadata(self, company_name: str, template_id: UUID, template_name: str, template_description: str, template_config_file_name: str):
        async with self.get_connection_pool().connection() as connection:
            async with connection.cursor(row_factory=dict_row) as cursor:
                sql = f"""UPDATE {self.table_name} 
                          SET {self.columns.TemplateName} = %s, 
                              {self.columns.TemplateDescription} = %s, 
                              {self.columns.TemplateConfigFileName} = %s
                          WHERE {self.columns.CompanyName}=%s
                            AND {self.columns.Id}=%s"""
                params = (template_name, template_description, template_config_file_name, company_name, template_id)
                await cursor.execute(sql, params)

    async def delete_template_metadata(self, company_name: str, template_id: UUID):
        async with self.get_connection_pool().connection() as connection:
            async with connection.cursor(row_factory=dict_row) as cursor:
                sql = f"""DELETE FROM {self.table_name} 
                          WHERE {self.columns.CompanyName}=%s 
                            AND {self.columns.Id}=%s"""
                params = (company_name, template_id)
                await cursor.execute(sql, params)
