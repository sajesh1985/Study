import styled from "@emotion/styled";

export const BubblePromptContainer = styled.div`
    display: inline-block;
    background-color: #f0f0f0;
    border-radius: 20px;
    padding: 8px 15px;
    margin: 5px;
    cursor: pointer;
    transition: background-color 0.3s ease;

    &:hover {
      background-color: #0056b3;
    }
  
}
`;