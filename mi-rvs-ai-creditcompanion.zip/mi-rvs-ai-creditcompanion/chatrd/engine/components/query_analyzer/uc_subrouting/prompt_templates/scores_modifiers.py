from typing import Literal, Optional, Union

from pydantic import BaseModel, Field

from chatrd.core.llm.parsers import PydanticOutputParser
from chatrd.core.llm.prompt.template import SimplePromptTemplate

METRICS_LIST = (
    "Additional Support",
    "ALAC Support",
    "Anchor",
    "BICRA",
    "Budget Performance",
    "Business Position",
    "Business Risk",
    "Business Risk Profile",
    "Capital & Earnings",
    "Capital Structure",
    "Captive Finance",
    "Captive Finance/Modifier",
    "Cash flow",
    "CICRA",
    "Comparable Rating Analysis",
    "Comparable Ratings Analysis",
    "Competitive Position",
    "Country Risk",
    "Credit Risk",
    "Debt",
    "Diversification",
    "Diversification / Portfolio Effect",
    "Economic Risk",
    "Economic Risk Rnd",
    "Financial Policy",
    "Financial Policy",
    "Financial Risk",
    "Financial Risk Profile",
    "Financial Risk Profile / Cash Flow & Leverage",
    "Funding & Liquidity",
    "Funding Structure",
    "Governance",
    "Government Support",
    "GRE Support",
    "Group Support",
    "Guarantee Support",
    "IICRA",
    "Industry Risk",
    "Industry Risk Score for Domiciled Country",
    "Industry Risk Trend",
    "Leverage",
    "Liquidity",
    "Management & Governance",
    "Management and governance",
    "Overall Additional Factors",
    "Overall Support Name",
    "Overall Support Value",
    "Portfolio effect",
    "Risk Exposure",
    "Risk Position",
    "SACP",
    "Sovereign Constraint",
    "Stand Alone Credit Profile",
)


TRIGGERS_LIST = (
    "Factor",
    "Modifier",
    "Score",
)


IMPACT_LIST = (
    "Affecting",
    "Driving",
    "Having Effect",
    "Impacting",
    "Prompting",
    "Guiding",
    "Cause",
    "Influencing",
)

METRICS_EXCLUDE_EXAMPLES = [
    "BICRA Group",
    "Economic Assessment",
    "Indicative Rating",
    "Institutional Assessment",
    "Operational Risk",
    "Insured Risk",
    "Competitive Dynamics",
]


class ScoresModifiersTriggers(BaseModel):
    Metric: Optional[Union[Literal[METRICS_LIST], None]] = Field(
        default=None,
        description=f"""Financial metric referenced by the user. Value can be None, when no metric from the list is mentioned: <METRICS_LIST>{", ".join(METRICS_LIST)}</METRICS_LIST>""",
    )
    Trigger: Optional[Union[Literal[TRIGGERS_LIST], None]] = Field(
        default=None,
        description=f"""Additional trigger mentioned by the user, asking for more specifics. Value can be None, when no trigger from the list is mentioned: <TRIGGERS_LIST>{", ".join(TRIGGERS_LIST)}</TRIGGERS_LIST>""",
    )
    Impact: Optional[Union[Literal[IMPACT_LIST], None]] = Field(
        default=None,
        description=f"""Additional word indicating that user asks about factors driving economic events or metrics.  Value can be None, when no word from the list is mentioned: <IMPACT_LIST>{", ".join(IMPACT_LIST)}</IMPACT_LIST>""",
    )
    AnyMetric: Optional[Union[str, None]] = Field(
        default=None,
        description="""Any metric (a quantitative measure, financial or not) referenced by the user. Value can be None, when no metric at all is mentioned, the same as the value of Metric, when the metric comes from METRICS_LIST, or other string value, when the metric does not come from METRICS_LIST""",
    )
    ChainOfThought: Optional[Union[str, None]] = Field(
        default="",
        description="""Step-by-step logic which led you to the answer. If any of the keywords from METRICS_LIST, TRIGGERS_LIST and IMPACT_LIST triggered, output it in the logic""",
    )


parser_scores_modifiers_subrouting = PydanticOutputParser(pydantic_object=ScoresModifiersTriggers)


SCORES_MODIFIERS_TRIGGERS_TEMPLATE = """
You are a financial advisor, whose goal is to retrieve keywords from user's question.

<instructions>
Your goal is to scan the question to find one of three types of keywords:
    - Metric, representing a financial information requested by the user. Output Metric only if it comes from METRICS_LIST: {metrics_list_input}. Otherwise, output Metric: null
    - Trigger, representing request for a more detailed information. Output Trigger only if it comes from TRIGGERS_LIST: {triggers_list_input}. Otherwise, output Trigger: null
    - Impact, representing user's request to justify financial metrics or economic events. Output Impact only if it comes from IMPACT_LIST: {impact_list_input}. Otherwise, output Impact: null
    - AnyMetric, representing a specific information requested by the user. Output AnyMetric only if such information is mentioned by the user. Output the same value, as Metric, when the request comes from METRICS_LIST. Otherwise, output AnyMetric: null

Follow these rules:
    - Check each keyword independently
    - Output keyword only, when it precisely matches one of the elements on the list, or it was slightly modified (lower or upper case, abbreviation or order of words changed)
    - Do not accept synonyms, while looking for keywords. For example in question "Describe factors driving Competitive Dynamics" the phrase Competitive Dynamics does not match Competitive Position from the keywords list. Output Metric: null
    - Per each output field (Metric, Trigger and Impact) output one null or one element from the keywords list
    - If multiple similar keywords are present, output the longest one (for example for question "Describe xys's financial risk profile output Metric: Financial Risk Profile rather than 'Financial Risk')
    - If multiple different keywords are present, output the first one (for example for question "Show me scores & modifiers for xyz" output Trigger: Score)
    - If a keyword is not found, output null{entities_input}
    - Do not mix company name with metric name from COMPANY_NAMES. In question 'What are the scores of Apple?' there is no metric, Apple is a company name
    - If you find a metric, pass it to AnyMetric. If that metric is not on METRICS_LIST, you MUST set Metric: null
    - If a metric from AnyMetric is on METRICS_LIST, AnyMetric and Metric will be the same. If the metric is not on METRICS_LIST, Metric will be null
    - Keywords from TRIGGERS_LIST MUST NOT be output to AnyMetric field
    - Keywords from IMPACT_LIST MUST NOT be output to AnyMetric field
    - Company name MUST NOT be output to AnyMetric field
    - This factors are not accepted for Metric: <NOT_ACCEPTED_METRICS>{different_metrics_list_input}</NOT_ACCEPTED_METRICS>. If you identify one of these, output Metric: null
    - If a phrase matches a keyword from NOT_ACCEPTED_METRICS you MUST output Metric: null, even if you find a suitable keyword in METRICS_LIST
</instructions>

<formatting>
This information is to be output only when mentioned in the question. Format the output following these guidelines:

<format_guidelines>
{format_instructions}
</format_guidelines>

You MUST follow these rules:
    - Do not add anything other than the defined JSON schema
    - Do not say, this is the JSON output I requested
    - Do not justify your answer
    - Provide only the JSON
    - Follow closely the formatting instructions
    - Do not add other fields, than defined in format_guidelines
</formatting>

Follow these examples, format them according to the format_guidelines
<examples>
{examples}
</examples>

Apply these instructions to this question
{question}
"""


SCORES_MODIFIERS_TRIGGERS_EXAMPLES = [
    [
        "Which is UNACEM's Financial Risk Profile Score",
        "Metric: 'Financial Risk Profile', Trigger: 'Score', Impact: null, AnyMetric: 'Financial Risk Profile', ChainOfThought: 'The question mentions 'Financial Risk Profile' and 'Score', which match the keywords in the METRICS_LIST and TRIGGERS_LIST respectively. AnyMetric takes the same value as Metric, as keyword from METRICS_LIST was found. Therefore, the output is Metric: Financial Risk Profile, Trigger: Score, Impact: null, AnyMetric: Financial Risk Profile.'",
    ],
    [
        "What is the industry risk score for Holiday Park in the United Kingdom",
        "Metric: 'Industry Risk', Trigger: 'Score', Impact: null, AnyMetric: 'Industry Risk', ChainOfThought: 'The question mentions 'industry risk score' which matches the keyword 'Industry Risk' from the METRICS_LIST, and 'Score' which matches the keyword 'Score' from the TRIGGERS_LIST. AnyMetric takes the same value as Metric, as keyword from METRICS_LIST was found.'",
    ],
    [
        "What is the Financial Risk Modifier for IBM?",
        "Metric: 'Financial Risk', Trigger: 'Modifier', Impact: null, AnyMetric: 'Financial Risk', ChainOfThought: 'The question mentions 'Financial Risk Modifier' which matches the keyword 'Financial Risk' from the METRICS_LIST, and 'Modifier' which matches the keyword 'Modifier' from the TRIGGERS_LIST. AnyMetric takes the same value as Metric, as keyword from METRICS_LIST was found.'",
    ],
    [
        "What is the business risk factor that is impacting apples credit rating the most?",
        "Metric: 'Business Risk', Trigger: 'Factor', Impact: 'Impacting', AnyMetric: 'Business Risk', ChainOfThought: 'The question mentions 'business risk factor' and 'impacting', which match the keywords 'Business Risk' from the METRICS_LIST and 'Factor' from the TRIGGERS_LIST, as well as 'Impacting' from the IMPACT_LIST. AnyMetric takes the same value as Metric, as keyword from METRICS_LIST was found.'",
    ],
    [
        "Show me scores & modifiers xyz",
        "Metric: null, Trigger: 'Score', Impact: null, AnyMetric: null, ChainOfThought: 'The question mentions 'scores & modifiers', which match the keywords 'Score' and 'Modifier' from the TRIGGERS_LIST, so Trigger is set to the first of them 'Score'. No metric was specified, 'Modifier' is on TRIGGER_LIST (as stated in the instructions: Keywords from TRIGGERS_LIST MUST NOT be output to AnyMetric field), Company name (xyz) is not a metric (as stated in instructions: Company name MUST NOT be output to AnyMetric field). setting AnyMetric to null.'",
    ],
    [
        "What are the factors for xyz",
        "Metric: null, Trigger: 'Factor', Impact: null, AnyMetric: null, ChainOfThought: 'The question mentions 'factors for Bank of Ireland', which matches the keyword 'Factor' from the TRIGGERS_LIST, outputting Trigger: 'Factor'. No other keywords from the METRICS_LIST or IMPACT_LIST were found, hence outputting Metric: null and Impact: null. No metric was specified, 'Factor' is on TRIGGER_LIST (as stated in the instructions: 'Keywords from TRIGGERS_LIST MUST NOT be output to AnyMetric field'), company name (xyz) is not a metric (as stated in instructions: Company name MUST NOT be output to AnyMetric field), setting AnyMetric to null.'",
    ],
    [
        "What are the factors for (NYSE:ABC) ABC Corporation",
        "Metric: null, Trigger: 'Factor', Impact: null, AnyMetric: null, ChainOfThought: 'The question mentions 'factors for (NYSE:ABC) ABC Corporation', which matches the keyword 'Factor' from the TRIGGERS_LIST, outputting Trigger: 'Factor'. No other keywords from the METRICS_LIST or IMPACT_LIST were found, hence outputting Metric: null and Impact: null. No metric was specified, 'Factor' is on TRIGGER_LIST (as stated in the instructions: 'Keywords from TRIGGERS_LIST MUST NOT be output to AnyMetric field'), company name (ABC Corporation) is not a metric (as stated in instructions: 'Company name MUST NOT be output to AnyMetric field'), setting AnyMetric to null.'",
    ],
    [
        "what are the factor & Modifier of IDK SA",
        "Metric: null, Trigger: 'Factor', Impact: null, AnyMetric: null, ChainOfThought: 'The question mentions 'factors and modifiers', which match the keywords 'Factor' and 'Modifier' from the TRIGGERS_LIST, so Trigger is set to the first of them 'Score'. No metric was specified, and no keywords from IMPACT_LIST (setting Impact to null.), company name (IDK SA) is not a metric (as stated in instructions: 'Company name MUST NOT be output to AnyMetric field'), setting AnyMetric to null.'",
    ],
    [
        "What is xyz's Business Risk?",
        "Metric: 'Business Risk', Trigger: null, Impact: null, AnyMetric: 'Business Risk', ChainOfThought: 'The question mentions 'Business Risk' which is a keyword from the METRICS_LIST, so I output 'Business Risk' as the Metric. AnyMetric takes the same value as Metric, as keyword from METRICS_LIST was found.'",
    ],
    [
        "Tell me about xyz's financial risk",
        "Metric: 'Financial Risk', Trigger: null, Impact: null, AnyMetric: 'Financial Risk', ChainOfThought: 'The question mentions 'xyz's financial risk', which matches the keyword 'Financial Risk' from the METRICS_LIST. Therefore, the output for the 'Metric' field is 'Financial Risk' and AnyMetric takes the same value as Metric. No other keywords from the TRIGGERS_LIST or IMPACT_LIST were found, so the 'Trigger' and 'Impact' fields are set to null.'",
    ],
    [
        "Credit Rating factors for XYZ",
        "Metric: null, Trigger: 'Factor', Impact: null, AnyMetric: 'Credit Rating', ChainOfThought: 'The question mentions 'Credit Rating factors for XYZ', which matches the keyword 'Factor' from the TRIGGERS_LIST. Therefore, the output for Trigger is 'Factor'. 'Credit Rating' is not on METRICS_LIST, so I output Metric: null. AnyMetric value set to 'Credit Rating'.'",
    ],
    [
        "What is impacting Economic Risk?",
        "Metric: 'Economic Risk', Trigger: null, Impact: 'Impacting', AnyMetric: 'Economic Risk', ChainOfThought: 'The question contains the keyword 'Impacting' which is part of the IMPACT_LIST, and 'Economic Risk' which is a part of METRICS_LIST, no keywords from TRIGGERS_LIST were identified. AnyMetric takes the same value as Metric, as keyword from METRICS_LIST was found. I output Metric: 'Economic Risk', Impact: 'Impacting', Trigger: null.'",
    ],
    [
        "What is the business risk factor that is impacting apples credit rating the most?",
        "Metric: 'Business Risk', Trigger: 'Factor', Impact: 'Impacting', AnyMetric: 'Business Risk', ChainOfThought: 'The question mentions 'business risk factor' and 'impacting', which match the keywords 'Business Risk' from the METRICS_LIST and 'Factor' from the TRIGGERS_LIST, as well as 'Impacting' from the IMPACT_LIST. AnyMetric takes the same value as Metric, as keyword from METRICS_LIST was found.'",
    ],
    [
        "What is the liquidity score which has the most severe effect on cost of financing for xyz?",
        "Metric: 'Liquidity', Trigger: 'Score', Impact: Having Effect, AnyMetric: 'Liquidity', ChainOfThought: 'The question mentions 'liquidity score' which matches the 'Liquidity' metric from the METRICS_LIST and 'Score' from the TRIGGERS_LIST. It also mentions 'effect on cost of financing', which matches the 'Having Effect' keyword from the IMPACT_LIST. Therefore, the output is Metric: Liquidity, Trigger: Score, Impact: Having Effect. AnyMetric takes the same value as Metric, as keyword from METRICS_LIST was found.'",
    ],
    [
        "Summarize BICRA Group score for Greece",
        "Metric: null, Trigger: 'Score', Impact: null, AnyMetric: 'BICRA Group', ChainOfThought: 'The question mentions 'BICRA Group score' which best matches the 'BICRA Group' metric from the NOT_ACCEPTED_METRICS, and it is not a valid metric, so I output Metric: null. There are no such restrictions bounding for AnyMetric, so I output AnyMetric: 'BICRA Group'. The question mentions 'score', which matches the keyword 'Score' from the TRIGGERS_LIST.'",
    ],
    [
        "What types of risks is xyz insured against?",
        "Metric: null, Trigger: null, Impact: null, AnyMetric: 'Risk', ChainOfThought: 'The question does not contain any keywords from the METRICS_LIST, TRIGGERS_LIST, or IMPACT_LIST, so the output is Metric: null, Trigger: null, Impact: null. Risk may be considered a metric, so I'm outputting AnyMetric: 'Risk'.'",
    ],
    [
        "What are the key factors driving operational risk?",
        "Metric: null, Trigger: 'Factor', Impact: 'Driving', AnyMetric: 'Operational Risk', ChainOfThought: 'The question mentions 'key factors' and 'operational risk'. Phrase 'key factors' matches the keywords 'Factor' from the TRIGGERS_LIST and 'Driving' from the IMPACT_LIST. 'Operational Risk' is not on METRICS_LIST, but it can be considered a metric. Therefore, the output is Metric: null, Trigger: Factor, Impact: Driving., AnyMetric: 'Operational Risk'.'",
    ],
    [
        "Perform institutional assessment for xyz",
        "Metric: null, Trigger: null, Impact: null, AnyMetric: 'Institutional Assessment', ChainOfThought: 'The question mentions 'institutional assessment' which is not on METRICS_LIST, but it can be considered a metric for AnyMetric. No keywords from TRIGGERS_LIST, or IMPACT_LIST were mentioned, so the output is Metric: null, Trigger: null, Impact: null, AnyMetric: 'Institutional Assessment'.'",
    ],
    [
        "Perform Fiscal Assessment for Debt for Germany",
        "Metric: 'Debt', Trigger: null, Impact: null, AnyMetric: 'Debt', ChainOfThought: 'The question mentions 'Fiscal Assessment' which is not on METRICS_LIST and 'Debt' which matches the keyword 'Debt' on METRICS_LIST, so the output is Metric: Debt, Trigger: null, Impact: null, AnyMetric: Debt.'",
    ],
    [
        "Give me a current economic assessment of LATAM",
        "Metric: null, Trigger: null, Impact: null, AnyMetric: 'Economic Assessment', ChainOfThought: 'The question mentions an 'economic assessment', which best matches 'Economic Assessment' metric from the NOT_ACCEPTED_METRICS, and it is not a valid metric, so I output Metric: null. There are no such restrictions bounding for AnyMetric, so I output AnyMetric: 'Economic Assessment'.'",
    ],
    [
        "Summarize Credit Rating factors for German USD denominated bonds",
        "Metric: null, Trigger: 'Factor', Impact: null, AnyMetric: 'Credit Rating', ChainOfThought: 'The question asks for 'Credit Rating factors'. However, 'Credit Rating' is not a metric from the METRICS_LIST, so I output Metric: null. There are no such restrictions bounding for AnyMetric, so I output AnyMetric: 'Credit Rating'. The question mentions 'factors' which matches 'Factor' keyword from the TRIGGERS_LIST, therefore I output Trigger: Factor.'",
    ],
    [
        "What is Tesla's BICRA Group score?",
        "Metric: null, Trigger: null, Impact: null, AnyMetric: 'BICRA Group', ChainOfThought: 'The question mentions 'BICRA Group score' which best matches the 'BICRA Group' metric from the NOT_ACCEPTED_METRICS, and it is not a valid metric, so I output Metric: null. There are no such restrictions bounding for AnyMetric, so I output AnyMetric: 'BICRA Group'. The question mentions 'score', which matches the keyword 'Score' from the TRIGGERS_LIST.'",
    ],
    [
        "Show me financial modifiers for xyz?",
        "Metric: null, Trigger: 'Modifier', Impact: null, AnyMetric: 'Financial', ChainOfThought: 'The question mentions 'BICRA Group score' which best matches the 'BICRA Group' metric from the NOT_ACCEPTED_METRICS, and it is not a valid metric, so I output Metric: null. There are no such restrictions bounding for AnyMetric, so I output AnyMetric: 'BICRA Group'. The question mentions 'score', which matches the keyword 'Score' from the TRIGGERS_LIST.'",
    ],
    [
        "Describe factors driving Competitive Dynamics for Australia",
        "Metric: null, Trigger: 'Factor', Impact: 'Driving', AnyMetric: 'Competitive Dynamics', 'The question mentions 'Competitive Dynamics' from the NOT_ACCEPTED_METRICS, and it is not a valid metric, so I output Metric: null. There are no such restrictions bounding for AnyMetric, so I output AnyMetric: 'Competitive Dynamics'. The question mentions the keyword 'Factor' from the TRIGGERS_LIST and 'Driving' from IMPACT_LIST.'",
    ],
    [
        "List factors impacting rating of xyz",
        "Metric: null, Trigger: 'Factor', Impact: 'Impacting', AnyMetric: 'Rating', 'The question mentions 'Rating' which is not on the METRICS_LIST, so I output Metric: null, but it can be considered a metric so I output AnyMetric: 'Rating'. The question mentions the keyword 'Factor' from the TRIGGERS_LIST and 'Impacting' from IMPACT_LIST.'",
    ],
    [
        "What scores are impacting IBM?",
        "Metric: null, Trigger: 'Score', Impact: Impacting, AnyMetric: null, ChainOfThought: 'The question mentions 'scores & modifiers', which match the keywords 'Score' and 'Modifier' from the TRIGGERS_LIST, so Trigger is set to the first of them 'Score'. No metric was specified, 'Impacting' is on IMPACT_LIST (cannot be output to AnyMetric, as stated in the instructions: Keywords from IMPACT_LIST MUST NOT be output to AnyMetric field), company name (IBM) is not a metric (as stated in instructions: Company name MUST NOT be output to AnyMetric field). setting AnyMetric to null.'",
    ],
    [
        "Show me the Score & Modifiers for AMD",
        "Metric: null, Trigger: 'Score', Impact: null, AnyMetric: null, ChainOfThought: 'The question mentions 'scores & modifiers', which match the keywords 'Score' and 'Modifier' from the TRIGGERS_LIST, so Trigger is set to the first of them 'Score'. No metric was specified, 'Modifier' is on TRIGGER_LIST (as stated in the instructions: Keywords from TRIGGERS_LIST MUST NOT be output to AnyMetric field), company name (AMD) is not a metric (as stated in instructions: Company name MUST NOT be output to AnyMetric field). setting AnyMetric to null.'",
    ],
    [
        "What are the scores of Apple?",
        "Metric: null, Trigger: 'Score', Impact: null, AnyMetric: null, ChainOfThought: 'The question mentions 'scores' keyword 'Score' from the TRIGGERS_LIST. No metrics and other keywords were mentioned, 'Modifier' is not a metric as it is on TRIGGER_LIST (as stated in the instructions: Keywords from TRIGGERS_LIST MUST NOT be output to AnyMetric field), company name (Apple) is not a metric (as stated in instructions: Company name MUST NOT be output to AnyMetric field). setting AnyMetric to null.",
    ],
    [
        "Show me modifies for NVIDIA Corporation",
        "Metric: null, Trigger: 'Modifier', Impact: null, AnyMetric: null, ChainOfThought: 'The question mentions 'modifies' keyword 'Modifier' from the TRIGGERS_LIST. No metrics and other keywords were mentioned, 'Modifier' is not a metric as it is on TRIGGER_LIST (as stated in the instructions: Keywords from TRIGGERS_LIST MUST NOT be output to AnyMetric field), company name (NVIDIA Corporation) is not a metric (as stated in instructions: Company name MUST NOT be output to AnyMetric field). setting AnyMetric to null.",
    ],
]

SCORES_MODIFIERS_TRIGGERS_EXAMPLES_FORMATTED = "\n\n________\n\n".join(
    [f"""Question: {question} \nOutput: {response}""" for question, response in SCORES_MODIFIERS_TRIGGERS_EXAMPLES]
)

scores_modifiers_triggers_input = {
    "metrics_list_input": ", ".join(METRICS_LIST),
    "triggers_list_input": ", ".join(TRIGGERS_LIST),
    "impact_list_input": ", ".join(IMPACT_LIST),
    "different_metrics_list_input": ", ".join(METRICS_EXCLUDE_EXAMPLES),
    "format_instructions": parser_scores_modifiers_subrouting.get_format_instructions(),
    "examples": SCORES_MODIFIERS_TRIGGERS_EXAMPLES_FORMATTED,
}

SCORES_MODIFIERS_TRIGGERS_PROMPT = SimplePromptTemplate(
    template=SCORES_MODIFIERS_TRIGGERS_TEMPLATE,
    partial_variables=scores_modifiers_triggers_input,
)


def add_company_name_to_prompt(entities):
    output = ""
    if entities:
        if entities != "":
            output = (
                f"""\n    - Company name mentioned in this question is: <COMPANY_NAMES>{entities}</COMPANY_NAMES>"""
            )
    return output
