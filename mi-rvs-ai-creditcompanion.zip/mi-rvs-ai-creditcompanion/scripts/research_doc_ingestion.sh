#!/bin/bash

set -e

PROJ_FOLDER=$( dirname -- "$0"; )

# python ${PROJ_FOLDER}/open_search_ingestion.py \
#         --index-name "chatrd-research-dev" \
#         --input-file-path "s3://sagemaker.us-east-1.mi-ds-chatrd-dev/tmp/dataset_big.csv" \
#         --text-col-name "CLOB_DATA" \
#         --metadata-col-names "ARTICLE_ID,PREFERRED_TITLE,ABSTRACT,ARTICLE_DATE,SOURCE_SECTOR,ENTITY_LEGAL_NAME,ENTITY_ID,ARTICLE_TYPE,PRIMARY_SECTOR_CODE,PRIMARY_SUB_SECTOR_CODE" \
#         --output-file-path "s3://sagemaker.us-east-1.mi-ds-chatrd-dev/dev/splitted_research_docs.parquet" \
#         --n-samples 5

python ${PROJ_FOLDER}/open_search_ingestion.py \
        --index-name "chatrd-research-dev" \
        --input-file-path "s3://sagemaker.us-east-1.mi-crs-chatrd-dev/dev/dataset/dataset_big.csv" \
        --text-col-name "CLOB_DATA" \
        --metadata-col-names "ARTICLE_ID,PREFERRED_TITLE,ABSTRACT,ARTICLE_DATE,SOURCE_SECTOR,ENTITY_LEGAL_NAME,ENTITY_ID,ARTICLE_TYPE,PRIMARY_SECTOR_CODE,PRIMARY_SUB_SECTOR_CODE" \
        --output-file-path "s3://sagemaker.us-east-1.mi-crs-chatrd-dev/dev/processed/splitted_research_docs.parquet"