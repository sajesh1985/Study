import json
import logging

import numpy as np
import pandas as pd
from Levenshtein import distance

from chatrd.core.aws_utils.s3 import load_data_from_s3
from chatrd.core.aws_utils.sagemaker import get_assumed_sagemaker_llm_client
from chatrd.core.embedding.semantic_utils import semantic_search
from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.data_service.kpqi import KPQI

logger = logging.getLogger(__name__)

config_machinery = get_config_machinery()

DATA_SERVICE_EMBEDDING_CLIENT = None


def initialize_client():
    global DATA_SERVICE_EMBEDDING_CLIENT
    if DATA_SERVICE_EMBEDDING_CLIENT is not None:
        return

    DATA_SERVICE_EMBEDDING_CLIENT = get_assumed_sagemaker_llm_client(
        role_arn=config_machinery.get_config_value(Constants.SageMaker.SAGEMAKER_ROLE_ARN),
        region_name=config_machinery.get_config_value(Constants.SageMaker.SAGEMAKER_REGION_NAME),
    )["sagemaker-runtime"]


def load_and_format_KPQI_data(data_path: str) -> pd.DataFrame:
    """
    Load the KPQI data from a given path and reformat by filling the Na's in with empty string ("")
    and creating a new column named "Embedding Column" which is a combinaton of "Caption", "Tag1", "Tag2",
    "Tag3", "Tag4", "Tag5", and "EnglishValues". This column should match the original embedded data.


    Args:
        data_path (str): The path to the parquet file containing the KPQI data.

    Returns:
        KPQI_data (pd.DataFrame): A formatted DataFrame containing the KPQI data.
    """

    KPQI_data = load_data_from_s3(
        data_path, role_arn=config_machinery.get_config_value(Constants.Bedrock.BEDROCK_ROLE_ARN)
    )
    KPQI_data = KPQI_data.replace("None", np.NaN)
    KPQI_data_empty_strings = KPQI_data.replace({np.NaN: ""})
    KPQI_data_empty_strings["Embedding Column"] = (
        KPQI_data_empty_strings["Caption"]
        + " "
        + KPQI_data_empty_strings["Tag1"]
        + " "
        + KPQI_data_empty_strings["Tag2"]
        + " "
        + KPQI_data_empty_strings["Tag3"]
        + " "
        + KPQI_data_empty_strings["Tag4"]
        + " "
        + KPQI_data_empty_strings["Tag5"]
        + " "
        + KPQI_data_empty_strings["EnglishValues"]
    )
    KPQI_data["Embedding Column"] = KPQI_data_empty_strings["Embedding Column"]
    return KPQI_data


def custom_patch(input_text: str) -> str:
    """
    Quick fixes for correct disambiguation.

    TODO: Fix query to the database.
    Currently the closest filed for 'ratings' is now RD_SERVICER_EVALUATIONS_RANKING.
    It should be RD_CREDIT_RATING_GLOBAL.
    """
    if input_text in ["ratings", "rating"]:
        input_text = "S&P Credit Rating"
    return input_text


def similarity_filter(df: pd.DataFrame, target_column: str, model, threshold: float = 0.98) -> pd.DataFrame:
    """
    Filter the DataFrame based on the similarity of the values in the column with the input text.

    Args:
        df (pd.DataFrame): The DataFrame to filter
        column (str): The column to filter on
        threshold (float): The threshold for filtering
        model_name (str): The model name to use for filtering

    Returns:
        df (pd.DataFrame): The filtered DataFrame
    """

    # Create embeddings
    documents = df[target_column].apply(lambda x: x.lower() if pd.notnull(x) else "null").tolist().copy()
    list_embeddings = model.embed_list(documents)
    embed_search = np.array(list_embeddings, dtype=np.float32)

    # Perform semantic search
    scores = semantic_search(embed_search[0], embed_search)
    scores = scores[0]

    # Filter the results
    df_scores = pd.DataFrame(scores)
    df_scores["score"] = df_scores["score"].round(2)
    df_scores[target_column] = df_scores["corpus_id"].apply(lambda x: documents[x])

    position_idx = df_scores[(df_scores["score"] >= threshold) & (df_scores[target_column] != "null")].corpus_id.values
    idx = df.index[position_idx]
    return df.loc[idx]


def call_data_sevice_embedding_service(query_embedding, key_perspective_str, top_k=100):
    """
    Call the data service embedding service to get the top_k results for the query_embedding.

    Args:
        query_embedding (np.ndarray): The query embedding
        key_perspective_str (str): The key perspective string
        top_k (int): The number of top results to return

    Returns:
        hits (List[Dict[str, Union[int, float]]]): The top_k hits
    """
    initialize_client()
    logger.info(f"Calling data service embedding endpoint.")
    outputs = DATA_SERVICE_EMBEDDING_CLIENT.invoke_endpoint(
        EndpointName=config_machinery.get_config_value(
            Constants.SageMaker.SAGEMAKER_DATASERVICE_EMBEDDING_ENDPOINT_NAME
        ),
        Body=json.dumps({"query": query_embedding, "perspective": key_perspective_str, "top_k": top_k}),
        ContentType="application/json",
    )
    hits = json.loads(outputs["Body"].read().decode("utf-8"))
    return hits


def field_search(
    input_text: str,
    key: str,
    model,
    key_perspective_str: str,
    KPQI_data: pd.DataFrame,
    top_n: int = 5,
    top_n_candidates: int = 10,
) -> pd.DataFrame:
    """
    Perform a samantic search on the input text using the provided model, embeddings, and KPQI data.
    Results are reranked based on frequency and Levenshtein distance.

    Args:
        input_text (str): The input text to search for
        model: The cohere model
        embeddings: The embeddings to search in. (can be loaded in with load_vector_database())
        KPQI_data (pd.DataFrame): The KPQI data DataFrame
        top_n (int, optional): The number of top results to return. Defaults to 5
        top_n_candidates (int, optional): The number of top candidates to consider. Defaults to 10

    Returns:
        df_result (pd.DataFrame): A DataFrame containing the search results.
    """
    input_text = custom_patch(input_text)
    logger.info(f"model used is  {model}")
    query_embedding = model.embed_query(input_text)
    hits = call_data_sevice_embedding_service(query_embedding, key_perspective_str, top_k=100)
    hits = hits[0]  # Get the hits for the first query
    idx = []
    scores = []
    for hit in hits:
        if hit["score"] > 0.5:
            idx.append(hit["corpus_id"])
            scores.append(hit["score"])
    df_result = KPQI_data.iloc[idx].copy()
    df_result["scores"] = scores
    df_result = df_result[df_result["QueryItemAlias"] != "SP_INDUSTRY"]

    # TODO: update the line below when we increase the KPQI coverage.
    if "industry: " in input_text:
        df_result = df_result.loc[df_result["KPQI"].isin(KPQI.values())].head(top_n_candidates)
    else:
        # Ignore MI Industries for the non industry use cases.abs
        kpqi_list = KPQI.values() - set([KPQI.IndustryClassification.value])
        df_result = df_result.loc[df_result["KPQI"].isin(kpqi_list)].head(top_n_candidates)

    # the field Count tracks the frequency of KQOI usage based on a static usage log
    # however, we may not have this or require this for all use cases/perspectives
    # so, we use count if available, else, we sort just based on semantic match score
    try:
        df_result = df_result.sort_values(by=["scores", "Count"], ascending=[False, False])
    except KeyError:
        df_result = df_result.sort_values(by=["scores"], ascending=[False])

    # Apply Levenshtein Distance for lookup values.
    if df_result["SearchLookupValue"].any():
        df_result_update = df_result[~df_result["EnglishValues"].isna()].copy()
        df_result_update["levenshtein_distance"] = df_result_update["EnglishValues"].apply(
            lambda x: distance(x, input_text)
        )
        df_result_update = df_result_update.loc[df_result_update["levenshtein_distance"] < 3, :]
        if not df_result_update.empty:
            return df_result_update.sort_values(by=["levenshtein_distance", "Count"], ascending=[True, False]).head(
                top_n
            )

    if key == "industry":
        try:
            df_result = similarity_filter(df_result, "Embedding Column", model=model, threshold=0.9)
            if (
                "MI_INDUSTRY_CLASSIFICATION" in df_result.QueryItemAlias.unique()
                and "RD_SECTOR" in df_result.QueryItemAlias.unique()
                and len(df_result) >= 2
            ):
                df_result_industry = pd.DataFrame()
                for qia in ["MI_INDUSTRY_CLASSIFICATION", "RD_SECTOR"]:
                    df_result_qia = df_result[df_result["QueryItemAlias"] == qia]
                    df_result_qia = similarity_filter(df_result_qia, "Embedding Column", model=model)

                    df_result_industry = pd.concat([df_result_industry, df_result_qia], ignore_index=True)
                df_result = df_result_industry
            else:
                df_result = similarity_filter(df_result, "Embedding Column", model=model)
        except Exception as e:
            logger.error(f"Error in similarity_filter: {e}")
            df_result = df_result.head(top_n)
    else:
        df_result = df_result.head(top_n)
    return df_result
