﻿// Copyright Notice! 
// This document is protected under the trade secret and copyright 
// laws as the property of Fidelity National Information Services, Inc. 
// Copying, reproduction or distribution should be limited and only to 
// employees with a “need to know” to do their job. 
// Any disclosure of this document to third parties is strictly prohibited.
// © 2018 Fidelity National Information Services.
// All rights reserved worldwide.

namespace Fis.Epp.Fusion.Auth
{
    using Fis.Epp.Fusion.Auth.Models;
    using Microsoft.IdentityModel.Tokens;
    using System;
    using System.Collections.Generic;
    using System.IdentityModel.Tokens.Jwt;
    using System.Security.Claims;

    /// <summary>Represents <see cref="System.IdentityModel.Tokens.Jwt"/> that helps to create and validate JWT tokens.</summary>
    public class JwtHelper
    {
        #region Fields
        // Certificate generated using RSA algorithm. Holds private and public key.
        // private const string CERTIFICATE_PATH = @"Keys\jwtCertificate.p12";
        // private const string CERTIFICATE_PWD = "test";
        #endregion

        #region Symmetric JWT Token Generation

        /// <summary>Generate and returns JWT token using secret.</summary>
        /// <param name="tokenValidationKey">Key to validate the token.</param>
        /// <param name="claims">List of data in key value pairs.</param>
        /// <param name="tokenExpiry">Expiry of jwt token, default is 900 seconds.</param>
        /// <returns>Token in JWT format.</returns>
        /// <exception cref="System.ArgumentNullException">Throw if <paramref name="claims"/> is <see langword="null"/>.</exception>
        public static string GenerateSymmetricToken(string tokenValidationKey, Dictionary<string, string> claims, int tokenExpiry = 900)
        {
            try
            {
                if (string.IsNullOrEmpty(tokenValidationKey))
                    throw new ArgumentNullException(ExceptionEnum.validationKey.GetEnumDescription());
                if (claims == null)
                    throw new ArgumentNullException(ExceptionEnum.claims.GetEnumDescription());

                var symmetricKey = Convert.FromBase64String(tokenValidationKey);
                var now = DateTime.Now;
                List<Claim> claimList = new List<Claim>();
                if (claims.Count > 0)
                {
                    foreach (var claim in claims)
                    {
                        claimList.Add(new Claim(claim.Key, claim.Value));
                    }
                }
                var tokenDescriptor = new SecurityTokenDescriptor
                {
                    Subject = new ClaimsIdentity(claimList),
                    Expires = now.AddSeconds(Convert.ToInt32(tokenExpiry)),
                    SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(symmetricKey), SecurityAlgorithms.HmacSha256Signature)
                };

                JwtSecurityTokenHandler tokenHandler = new JwtSecurityTokenHandler
                {
                    // Removes default flag from token payload.
                    SetDefaultTimesOnTokenCreation = false
                };
                var stoken = tokenHandler.CreateToken(tokenDescriptor);
                var token = tokenHandler.WriteToken(stoken);
                return token;
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>Validates token using secret and returns set of claims.</summary>
        /// <param name="tokenValidationKey">Key to validate the token.</param>
        /// <param name="token">Token in JWT format.</param>
        /// <returns>Set of claims.</returns>
        /// <exception cref="System.ArgumentNullException">Throw if<paramref name="tokenValidationKey"/> is <see langword="null"/>.</exception>
        /// <exception cref="System.ArgumentNullException">Throw if<paramref name="token"/> is <see langword="null"/>.</exception>
        public static ClaimsPrincipal ValidateSymmetricToken(string tokenValidationKey, string token, bool validateLifeTime = true)
        {
            try
            {
                if (string.IsNullOrEmpty(tokenValidationKey))
                    throw new ArgumentNullException(ExceptionEnum.validationKey.GetEnumDescription());

                if (string.IsNullOrEmpty(token))
                    throw new ArgumentNullException(ExceptionEnum.token.GetEnumDescription());

                var symmetricKey = Convert.FromBase64String(tokenValidationKey);
                var validationParameters = new TokenValidationParameters()
                {
                    RequireExpirationTime = true,
                    RequireSignedTokens = true,
                    ValidateAudience = false,
                    ValidateIssuer = false,
                    ValidateLifetime = validateLifeTime,
                    IssuerSigningKey = new SymmetricSecurityKey(symmetricKey),
                    ClockSkew = TimeSpan.Zero
                };

                var tokenHandler = new JwtSecurityTokenHandler();
                var principal = tokenHandler.ValidateToken(token, validationParameters, out SecurityToken securityToken);

                return principal;
            }
            catch (Exception)
            {
                throw;
            }
        }

        #endregion

        #region Asymmetric JWT Token Generation

        /* /// <summary>Generates and returns JWT token using certificate.</summary>
        /// <param name="claims">List of data in key value pairs.</param>
        /// <param name="tokenExpiry">Expiry of jwt token, default is 900 seconds.</param>
        /// <returns>Token in JWT format.</returns>
        /// <exception cref="System.ArgumentNullException">Throw if <paramref name="claims"/> is <see langword="null"/>.</exception>
        public static string GenerateAsymmetricToken(Dictionary<string, string> claims, int tokenExpiry = 900)
        {
            try
            {
                if (claims == null)
                    throw new ArgumentNullException(ExceptionEnum.claims.GetEnumDescription());

                var tokenHandler = new JwtSecurityTokenHandler();
                var now = DateTime.UtcNow;
                var certPath = File.ReadAllBytes(CERTIFICATE_PATH);

                tokenHandler.SetDefaultTimesOnTokenCreation = false; // Removes default flags from token payload.
                //TODO : For testing the certificate has been generated using password but need to check the real certificate.
                var cert = new X509Certificate2(certPath, CERTIFICATE_PWD, X509KeyStorageFlags.Exportable);

                List<Claim> claimList = new List<Claim>();
                if (claims.Count > 0)
                {
                    foreach (var claim in claims)
                    {
                        claimList.Add(new Claim(claim.Key, claim.Value));
                    }
                }

                var tokenDescriptor = new SecurityTokenDescriptor
                {
                    Subject = new ClaimsIdentity(claimList),
                    Expires = now.AddSeconds(Convert.ToInt32(tokenExpiry)),
                    SigningCredentials = new SigningCredentials(new X509SecurityKey(cert), SecurityAlgorithms.RsaSha256)
                };

                var stoken = tokenHandler.CreateToken(tokenDescriptor);
                var token = tokenHandler.WriteToken(stoken);
                return token;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        /// <summary>Validates token using certificate and returns set of claims.</summary>
        /// <param name="token">Token in JWT format.</param>
        /// <returns>Set of claims.</returns>
        /// <exception cref="System.ArgumentNullException">Throw if <paramref name="token"/> is <see langword="null"/>.</exception>
        public static ClaimsPrincipal ValidateAsymmetricToken(string token)
        {
            try
            {
                if (string.IsNullOrEmpty(token))
                    throw new ArgumentNullException(ExceptionEnum.token.GetEnumDescription());

                var tokenHandler = new JwtSecurityTokenHandler();
                JwtSecurityToken jwtToken = tokenHandler.ReadToken(token) as JwtSecurityToken;

                if (jwtToken == null)
                    return null;

                var certPath = File.ReadAllBytes(CERTIFICATE_PATH);
                var cert = new X509Certificate2(certPath, CERTIFICATE_PWD, X509KeyStorageFlags.Exportable);
                var securityKey = new X509SecurityKey(cert);

                var validationParameters = new TokenValidationParameters()
                {
                    RequireExpirationTime = true,
                    RequireSignedTokens = true,
                    ValidateAudience = false,
                    ValidateIssuer = false,
                    ValidateLifetime = true,
                    IssuerSigningKey = securityKey
                };

                SecurityToken securityToken;
                var principal = tokenHandler.ValidateToken(token, validationParameters, out securityToken);

                return principal;
            }
            catch (Exception ex)
            {
                throw;
            }
        }*/

        #endregion
        /// <summary>Reads token and returns an object of JWT.</summary>
        /// <param name="token">Token in JWT string format.</param>
        /// <returns>JWT object.</returns>
        /// <exception cref="System.ArgumentNullException">Throw if<paramref name="token"/> is <see langword="null"/>.</exception>
        public static JwtSecurityToken ReadToken(string token)
        {
            if (string.IsNullOrEmpty(token))
                throw new ArgumentNullException(ExceptionEnum.token.GetEnumDescription());

            var tokenHandler = new JwtSecurityTokenHandler();
            var jwtToken = tokenHandler.ReadToken(token) as JwtSecurityToken;
            return jwtToken;
        }
    }
}
