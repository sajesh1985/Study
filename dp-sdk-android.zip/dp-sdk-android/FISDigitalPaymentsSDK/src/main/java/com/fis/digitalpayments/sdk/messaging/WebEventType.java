// Copyright Notice!
// This document is protected under the trade secret and copyright
// laws as the property of Fidelity National Information Services, Inc.
// Copying, reproduction or distribution should be limited and only to
// employees with a “need to know” to do their job.
// Any disclosure of this document to third parties is strictly prohibited.
// © 2017 Fidelity National Information Services.
// All rights reserved worldwide.

package com.fis.digitalpayments.sdk.messaging;

/**
 * @author e1035413 on 1/20/2017.
 */

@SuppressWarnings("ALL")
public enum WebEventType {
    ERROR,
    STARTED,
    COMPLETED,
    INFORMATION,
    ENROLLMENT_COMPLETED,
    PAYMENT_ADDED,
    PAYMENT_MODIFIED,
    PAYMENT_DELETED,
    PAYEE_ADDED,
    PAYEE_MODIFIED,
    PAYEE_DELETED,
    BACK_BUTTON,
    UNSPECIFIED,
    NOT_RECOGNIZED
}