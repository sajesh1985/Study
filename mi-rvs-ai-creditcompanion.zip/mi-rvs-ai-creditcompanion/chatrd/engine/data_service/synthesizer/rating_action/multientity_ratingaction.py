import logging
from typing import Optional

from chatrd.engine.data_service.schema import (
    Analyzer,
    ProcessorInput,
    Retriever,
    Synthesizer,
)
from chatrd.engine.data_service.synthesizer.base import BaseSynthesizer
from chatrd.engine.data_service.synthesizer.rating_action.utils import (
    create_multientityrating_action_table,
    source_description,
    template_leading_line,
)
from chatrd.engine.data_service.synthesizer.utils import (
    full_response,
    get_api_info,
    make_source_description,
    rating_history_url,
    text_response,
)

logger = logging.getLogger(__name__)


def rating_history_source_description(entity_name, entity_id):
    sep = ": "
    info = "Ratings & History Page"
    sources = make_source_description(entity_name, entity_id, sep, info, rating_history_url)

    return sources


class MultiEntityRatingActionSynthesizer(BaseSynthesizer):
    def synthesize(
        self,
        processor: Optional[ProcessorInput] = None,
        analyzer: Optional[Analyzer] = None,
        retriever: Retriever = None,
    ) -> Synthesizer:
        """
        Synthesizes a response based on the provided processor, analyzer, and retriever.

        Args:
            processor (Optional[ProcessorInput]): An object containing entity data.
            analyzer (Optional[Analyzer]): An optional analyzer object.
            retriever (Retriever): An object to retrieve API data.

        Returns:
            Synthesizer: An instance of Synthesizer containing the response and source description.
        """
        entities = processor.entities
        entity_name = ", ".join(company["name"] for company in entities["companies"])
        entity_id = ", ".join(str(company["mi_id"]) for company in entities["companies"])
        url = entities["companies"][0]["url"]
        filters = analyzer.response
        action_type = filters.get("MoveDirection", None)

        df_rating_action, has_valid_rows = create_multientityrating_action_table(
            retriever.api_data, filters, processor.entities["companies"]
        )
        count = df_rating_action.shape[0]
        if (len(entities["companies"]) > 0) & (
            entities["companies"][0]["type"] in ["Public Company", "Private Company"]
        ):
            private_company_bool = True
        else:
            private_company_bool = False
        template = template_leading_line(has_valid_rows, action_type, entity_name, entity_id, url, private_company_bool)
        FOOTNOTE_TEMPLATE = "For more information, please go to "
        footnote = (
            FOOTNOTE_TEMPLATE
            + f"""<a href="{rating_history_url(entity_id)}" target="_blank">{entity_name} | Ratings & History</a>"""
        )

        response = []
        if has_valid_rows:
            response = full_response(
                template=template,
                data=df_rating_action,
                data_type="table",
                count=count,
                footnote=footnote,
            )
        else:
            response = [text_response(template=template)]

        list_of_entities_with_ids = [(company["name"], company["mi_id"]) for company in entities.get("companies", [])]
        source_url = []
        ratings_source_url = []
        for name, entity_id in list_of_entities_with_ids:
            source_url_entity = source_description(name, entity_id)
            source_url.extend(source_url_entity)
            ratings_source_url_entity = rating_history_source_description(name, entity_id)
            ratings_source_url.extend(ratings_source_url_entity)
        source_url.extend(ratings_source_url)
        api_info = get_api_info(api_method=retriever.api_method, api_type=retriever.api_type, url=retriever.url)
        return Synthesizer(data_service_response=response, source_description=source_url, api_info=api_info)
