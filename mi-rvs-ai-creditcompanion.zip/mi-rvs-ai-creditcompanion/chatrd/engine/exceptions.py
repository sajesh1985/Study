from chatrd.engine.utils import ChatResponse


class RDException(Exception):
    def __init__(self, response: ChatResponse, message: str, inner_exception: Exception):
        super().__init__(message)

        self.response: ChatResponse = response
        self.inner_exception: Exception = inner_exception


class RDQueryBooleanException(Exception):
    def __init__(self, message: str):
        super().__init__(message)
