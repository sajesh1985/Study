// Copyright Notice!
// This document is protected under the trade secret and copyright
// laws as the property of Fidelity National Information Services, Inc.
// Copying, reproduction or distribution should be limited and only to
// employees with a “need to know” to do their job.
// Any disclosure of this document to third parties is strictly prohibited.
// © 2016 Fidelity National Information Services.
// All rights reserved worldwide.

package com.fis.digitalpayments.sdk.messaging;

import com.fis.digitalpayments.sdk.core.BridgeMessage;

import java.util.Map;

/**
 * @author e1035413 on 12/13/2016.
 */

public class WebEvent {

    public final static String INTERNAL_ERROR_EVENT_ID = "INTERNAL_ERROR";

    private final String mEventId;
    private final Map<String, String> mEventParams;
    private final WebEventType mWebEventType;
    private final ProductType mEventProduct;
    private final BridgeMessage mBridgeMessage;
    private static final String EVENT_TYPE_KEY = "eventType";
    private static final String PRODUCT_TYPE_KEY = "eventProduct";

    public WebEvent(String eventId, WebEventType webEventType, ProductType eventProduct, BridgeMessage bridgeMessage, Map<String, String> eventParams) {
        mEventId = eventId;
        mWebEventType = webEventType;
        mEventProduct = eventProduct;
        mBridgeMessage = bridgeMessage;
        mEventParams = eventParams;
    }

    public String getEventId() {
        return mEventId;
    }

    public WebEventType getEventType() { return mWebEventType; }

    public ProductType getEventProduct() { return mEventProduct; }

    @SuppressWarnings("unused")
    public BridgeMessage getMessage() { return mBridgeMessage; }

    public Map<String, String> getEventParams() {
        return mEventParams;
    }

    public static WebEventType parseWebEventType(Map<String, String> map) {
        WebEventType webEventType = WebEventType.UNSPECIFIED;
        if (map != null && map.containsKey(EVENT_TYPE_KEY)) {
            String eventTypeString = map.get(EVENT_TYPE_KEY);
            try {
                webEventType = WebEventType.valueOf(eventTypeString);
            }
            catch (IllegalArgumentException e) {
                webEventType = WebEventType.NOT_RECOGNIZED;
            }
        }

        return webEventType;
    }

    public static ProductType parseProductType(Map<String, String> map) {
        ProductType productType = ProductType.UNSPECIFIED;
        if (map != null && map.containsKey(PRODUCT_TYPE_KEY)) {
            String productTypeString = map.get(PRODUCT_TYPE_KEY);
            try {
                productType = ProductType.valueOf(productTypeString);
            }
            catch (IllegalArgumentException e) {
                productType = ProductType.NOT_RECOGNIZED;
            }
        }

        return productType;
    }

    @SuppressWarnings("NullableProblems")
    @Override
    public String toString() {
        String params = "";
        if (mEventParams != null) {
            StringBuilder paramsBuilder = new StringBuilder();
            for (String key : mEventParams.keySet()) {
                paramsBuilder.append(key);
                paramsBuilder.append("=");
                paramsBuilder.append(mEventParams.get(key));
                paramsBuilder.append(";");
            }
            params = paramsBuilder.toString();
        }

        return String.format("%s|%s|%s|%s|%s", mEventProduct, mWebEventType, mEventId, params, mBridgeMessage);
    }
}
