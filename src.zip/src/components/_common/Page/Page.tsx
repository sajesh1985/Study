import React from 'react';
import { Container, MainContent } from './Page.styles';

interface PageProps {
  header?: React.ReactNode;
  footer?: React.ReactNode;
  children?: React.ReactNode;
}

export const Page: React.FC<PageProps> = ({ header, footer, children }) => {
  return (
    <Container>
      {header}
      <MainContent>{children}</MainContent>
      {footer}
    </Container>
  );
};
