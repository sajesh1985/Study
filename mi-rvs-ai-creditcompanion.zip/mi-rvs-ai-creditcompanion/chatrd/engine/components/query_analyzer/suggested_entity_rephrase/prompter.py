import logging
import re
from typing import List, Optional

from chatrd.core.llm import LCLLMFactory
from chatrd.core.llm.components.message import AIMessage
from chatrd.core.llm.parsers import OutputParserException, PydanticOutputParser
from chatrd.core.llm.prompt.template import SimplePromptTemplate
from chatrd.engine.components.query_analyzer.suggested_entity_rephrase.prompts import (
    REPHRASE_WITH_ENTITY_EXAMPLES,
    REPHRASE_WITH_ENTITY_PROMPTER_PROMPT,
    EntityRephraseOutput,
)

logger = logging.getLogger(__name__)


class SuggestedEntityRephrasePrompter:
    def __init__(self, model_name: str, temperature: Optional[float] = 0.0):
        self.model = LCLLMFactory().get_llm(
            deployment_name_or_model_id=model_name,
            temperature=temperature,
        )

    def run(self, query: str, extracted_entity: str, suggested_entities: List[str]):
        prompt, parser = self.get_prompt(query, extracted_entity, suggested_entities)
        logger.debug(f"Generated RephraseWithEntity Prompter prompt: {prompt}")
        response = self.model.invoke(prompt)
        if isinstance(response, AIMessage):
            # remove non-printable characters and control characters
            response = re.sub(r"[^\x20-\x7E]", " ", response.content)
        try:
            response = parser.parse(response)
            logger.info(f"Generated RephraseWithEntity Prompter result: {response}")
            return response
        except OutputParserException as e:
            logger.error(f"Validation error at RephraseWithEntity Prompter LLM extraction {e}.")
            raise e

    def get_prompt(self, query: str, extracted_entity: str, suggested_entities: List[str]):
        prompt_template = SimplePromptTemplate(REPHRASE_WITH_ENTITY_PROMPTER_PROMPT)
        prompt = prompt_template.format(
            **{
                "question": query,
                "extracted_entity": extracted_entity,
                "rephrase_entities": suggested_entities,
                "examples": REPHRASE_WITH_ENTITY_EXAMPLES,
            }
        )
        parser = PydanticOutputParser(pydantic_object=EntityRephraseOutput)
        return prompt, parser
