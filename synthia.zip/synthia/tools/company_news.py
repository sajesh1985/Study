from mcp.server.fastmcp import FastMCP, Context
from fastapi import FastAPI, APIRouter
from fastapi import Request
import logging
import httpx
from . import auth
from contextlib import asynccontextmanager
import contextlib
from datetime import datetime, timedelta, timezone
from src.synthia.utils.logging_config import configure_logging
from src.synthia.utils.source import Source
from src.synthia.config.api_config import get_config

# Configure logging
configure_logging(log_file='company_news.log')
logger = logging.getLogger(__name__)

mcp: FastMCP = FastMCP("Company News MCP", stateless_http=True)
cfg = get_config()

NEWS_URL = cfg["capitaliq_graphql_url"]
base_article_url = cfg["news_article_url"]

logger.info("News MCP Server starting up...")
router = APIRouter()

# Create a single AsyncClient instance for reuse (performance optimization for Lambda)
async_client: httpx.AsyncClient = None


@mcp.tool()
async def get_company_news(instId: int, startDate: str = None, endDate: str = None) -> dict:
    """
    Fetch Instn news articles for a given Inst ID/KeyInstn/MI Key (instId) and date range.

    Args:
        instId (int): The Inst ID to get news for also called as Instn ID, MI Key, KeyInstn.
        startDate (str, optional): Start date in 'YYYY-MM-DD' format. Defaults to 6 months ago.
        endDate (str, optional): End date in 'YYYY-MM-DD' format. Defaults to today.

    Returns:
        dict: A dictionary containing news articles for the given company and date range.
        Each news article will have a 'key' field. To view the full article, append the key to: base_article_url
    """
    logger.info(f"get_company_news called for: {instId}, startDate: {startDate}, endDate: {endDate}")

    # Set default dates if not provided
    today = datetime.now(timezone.utc).date()
    default_start = today - timedelta(days=30)
    startDate = startDate or default_start.strftime("%Y-%m-%d")
    endDate = endDate or today.strftime("%Y-%m-%d")

    payload = {
        "extensions": {
            "persistedQuery": {
                "version":1,
                "sha256Hash":"9bc18c64ff18a1cba69d125508e57d7e7c90f3fc59cda0063f55aac1253b9191"
            }
        },
        "variables": {
            "category": "COMPANY_NEWS",
            "filter": {
                "source": "0", 
                "primaryCompany": True, 
                "instns": [instId], 
                "startDate": startDate,
                "endDate": endDate
            }
        }
    }

    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    headers = {
        "Content-Type": "application/json",
        **auth.build_auth_headers(raw_request)
    }
    logger.info(f"get_company_news payload: {payload}")

    try:
        global async_client
        response = await async_client.post(NEWS_URL, headers=headers, json=payload)
        source = Source(title="Company News", url=NEWS_URL)
        if response.status_code == 200:
            news_data = response.json()
            
            articles = (
                news_data.get("data", {})
                .get("newsArticles", [])
            )
            processed_news = []
            for article in articles:
                processed_article = {k: v for k, v in article.items() if k in ['headline', 'published', 'abstract', 'key']}
                processed_news.append(processed_article)
            
            logger.info(f"Final News data: {processed_news}")
            
            return {"sources": source, "data": processed_news, "base_article_url": base_article_url}
        elif response.status_code == 204:
            logger.info(f"No news data found for the given company : {instId} from {startDate} to {endDate}")
            return {"sources": source, "data": [{"message":"No news data found for the given company."}], "base_article_url": base_article_url}
        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return {"error": f"{response.status_code} - {response.text}"}
    except Exception as e:
        logger.error(f"Request failed: {e}")
        return {"error": f"Request failed: {e}"}

# Define a custom lifespan for FastAPI with a task to manage MCP

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Initializing MCP server task group...")
    global async_client
    async_client = httpx.AsyncClient(timeout=10)
    async with contextlib.AsyncExitStack() as stack:
        await stack.enter_async_context(mcp.session_manager.run())
        yield
    await async_client.aclose()

@router.get("/company-news/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "ok"}


# Create FastAPI app with lifespan
app = FastAPI(lifespan=lifespan)
app.mount("/company-news", mcp.streamable_http_app())
app.include_router(router)