package com.fis.digitalpayments.sdk.core;

import org.junit.Test;
import static com.google.common.truth.Truth.assertThat;

@SuppressWarnings("SpellCheckingInspection")
public class BridgeJavascriptInterfaceTest {

    @Test
    public void verifyWhiteList_MixedCase_ReturnsTrue() {

        String domain = "www.google.com";
        String[] whitelist = {"WWW.googLe.com"};
        String[] cleansedWhitelist = BridgeJavascriptInterface.cleanupDomainWhitelist(whitelist);

        assertThat(cleansedWhitelist).asList().contains(domain);
    }
}