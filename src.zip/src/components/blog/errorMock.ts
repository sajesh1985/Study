import { detailExtractor } from '@spglobal/error';
export const data = {
  type: 'snap_resp',
  correlationId: '+5ovw',
  securities: [
    {
      id: '4546783',
      snap: 1,
      marketClosed: 1,
      fields: {},
    },
  ],
  status: {
    statusCode: 106,
    statusMessage: 'MSL Error - Unresolved Identifier',
  },
};
export const dataDetailExtractor: detailExtractor = (data: any) => {
  return {
    type: data.type,
    correlationId: data.correlationId,
    securities: JSON.stringify(data.securities),
    statusCode: data.status.statusCode.toString(),
    statusMessage: data.status.statusMessage,
  };
};
