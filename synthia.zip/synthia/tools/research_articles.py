from mcp.server.fastmcp import FastMCP
import asyncio
import contextlib
import json
import logging
from contextlib import asynccontextmanager
from datetime import datetime
from datetime import timedelta
from typing import Any, Dict

import httpx
import pandas as pd
from fastapi import FastAPI, APIRouter
from mcp.server.fastmcp import FastMCP

from src.synthia.aws_utils.aws_client import (
    get_aws_client,
    get_secret,
    get_env_specific_secret_key,
)
from src.synthia.config.api_config import get_config
from src.synthia.schemas.search_request import *
from src.synthia.tools.mcp_responses import (
    MCPResponse, ArticleItem
)
from src.synthia.tools.mcp_utils import get_article_document_mapping
from src.synthia.utils.logging_config import configure_logging
from src.synthia.utils.source import Source

# Configure logging
logger = configure_logging(logger_name=__name__, log_file='research_articles.log')

logger.info("Opensearch MCP Server starting up...")
mcp: FastMCP = FastMCP("Opensearch MCP Server", stateless_http=True)

router = APIRouter()

uc_types_require_entity = []
uc_types_require_article_list = []
index_require_article_list = ['research']

# Create a single AsyncClient instance for reuse (performance optimization for Lambda)
async_client: httpx.AsyncClient = None


async def get_secrets():
    cfg = get_config()
    secrets_manager_client = get_aws_client("secretsmanager")
    synthia_secret = await asyncio.to_thread(get_secret, secrets_manager_client, cfg.get("secrets_name"))
    return synthia_secret


def get_search_entity(entity: Entity):
    entity_type = "company"
    if "Structured Finance" in entity.sector:
        entity_type = "sf"
    elif "U.S. Public Finance" in entity.sector:
        entity_type = "uspf"
    elif entity.asid:
        entity_type = "revenue_source"

    return SearchEntity(entity_id=entity.entity_id, entity_type=entity_type, asid=entity.asid)


def get_date_range_filter(year: int, date: str = None, processed_dates: ProcessedRetrieverDates = None):
    logger.info(f"date: {date}")
    if processed_dates:
        start_date, end_date = processed_dates.start_date, processed_dates.end_date
    elif date:
        specified_date = datetime.strptime(date, "%m/%d/%Y")
        start_date = specified_date.replace(hour=0, minute=0, second=0)
        end_date = (start_date + timedelta(days=7)).replace(hour=23, minute=59, second=59)
    else:
        end_date = datetime.now()
        start_date = end_date - timedelta(days=year * 365)
        start_date = start_date.strftime("%Y-%m-%d %H:%M:%S")
        end_date = end_date.strftime("%Y-%m-%d %H:%M:%S")

    return start_date, end_date


def get_research_article_query(entity_id_key: str, entity_id: int, secondary_entity_id_key: Union[str, None]):
    should_clauses = [
        {"match": {f"metadata.{entity_id_key}": f"{entity_id}"}},
        {"wildcard": {f"metadata.{entity_id_key}": {"value": f"{entity_id};*"}}},
        {"wildcard": {f"metadata.{entity_id_key}": {"value": f"*;{entity_id};*"}}},
        {"wildcard": {f"metadata.{entity_id_key}": {"value": f"*;{entity_id}"}}},
    ]
    sources = [
        {"metadata.articleID": {"terms": {"field": "metadata.articleID"}}},
        {"metadata.articleType": {"terms": {"field": "metadata.articleType.keyword"}}},
        {"metadata.articleSubType": {"terms": {"field": "metadata.articleSubType.keyword"}}},
        {"metadata.articleReleaseDate": {"terms": {"field": "metadata.articleReleaseDate"}}},
        {"metadata.slug": {"terms": {"field": "metadata.slug.keyword"}}},
        {
            "metadata.aggLegalEntityName": {
                "terms": {"field": "metadata.aggLegalEntityName.keyword"}
            }
        },
        {"metadata.SourceTitle": {"terms": {"field": "metadata.SourceTitle.keyword"}}},
        {f"metadata.{entity_id_key}": {"terms": {"field": f"metadata.{entity_id_key}.keyword"}}},
    ]

    query = {
        "size": 0,
        "query": {
            "bool": {
                "should": should_clauses
            }
        },
        "aggs": {
            "results": {
                "composite": {
                    "size": 10000,
                    "sources": sources
                }
            }
        },
    }

    if secondary_entity_id_key:
        should_clauses += [
            {"match": {f"metadata.{secondary_entity_id_key}": f"{entity_id}"}},
            {"wildcard": {f"metadata.{secondary_entity_id_key}": {"value": f"{entity_id};*"}}},
            {"wildcard": {f"metadata.{secondary_entity_id_key}": {"value": f"*;{entity_id};*"}}},
            {"wildcard": {f"metadata.{secondary_entity_id_key}": {"value": f"*;{entity_id}"}}},
        ]
        sources.append({f"metadata.{secondary_entity_id_key}": {
            "terms": {"field": f"metadata.{secondary_entity_id_key}.keyword"}}})

    return query


def fuzzy_substring_match(major: str, minor: str, threshold: float = 0.7, ) -> bool:
    from rapidfuzz.fuzz import partial_token_set_ratio
    exclude = ["", "#", "#1", "&", "(", "(1)", "(charter", "(city", "(city)", "(finance", "(finance)",
               "(group)", "(holding)", "(holdings)", "(international)", "(new", "(no.", "(north",
               "(state", "(the)", "+", ",", "-", "/", "1", "1,", "2022-1", "2022-1,", "@", "[the]", "a",
               "a.g.", "about", "above", "after", "ag", "again", "against", "ain", "all", "am", "an",
               "and", "any", "are", "aren", "aren't", "as", "at", "auth", "authority", "authority,",
               "bank", "bank,", "be", "because", "been", "before", "being", "below", "between", "both",
               "but", "by", "can", "capital", "capital,", "charter", "city", "city)", "clo", "clo,",
               "cnty", "cnty)", "co", "co,", "co.", "co.,", "college", "college)", "college,",
               "community", "comnty", "company", "company,", "corp", "corp)", "corp.", "corp.,",
               "corporation", "corporation,", "couldn", "couldn't", "county", "county)", "d", "d.a.c.",
               "dac", "de", "development", "development,", "did", "didn", "didn't", "dist", "dist,",
               "district", "district,", "do", "does", "doesn", "doesn't", "doing", "don", "don't",
               "down"]

    """Indicates if minor string is present in major string

    Args:
        major: String to be searched
        minor: String to search for
        threshold: Threshold for determining if fuzzy matching was a success
        exclude: Words to exclude from minor string

    Returns:
        match: Whether the major string has the minor string
    """
    major = major.lower()
    minor_words = minor.lower().strip().split(" ")
    minor_keywords = [word for word in minor_words if word not in exclude]
    if len(minor_keywords) == 0:
        minor_keywords = minor_words
    return (partial_token_set_ratio(major, " ".join(minor_keywords)) / 100) >= threshold


async def get_research_article_list(
        entity: SearchEntity,
        index: str,
        year: int = 1,
        date: str = None,
        uc_type: str = None,
        article_type: Optional[str] = None,
        processed_dates: Optional[ProcessedRetrieverDates] = None,
):
    entity_id = entity.entity_id
    entity_type = entity.entity_type
    year = 3
    entity_id_key = "aggPrimarykeyInstn"
    secondary_entity_id_key = None

    if entity_type == "revenue_source":
        entity_id = entity.asid
        entity_id_key = "aggRevenueSourceId"
        if uc_type == "research":
            year = 2
    if entity_type == "uspf":
        if uc_type == "research":
            year = 2
    if entity_type == "company":
        if uc_type == "research":
            year = 1
    if entity_type == "sf":
        secondary_entity_id_key = "aggsecondaryKeyInstn"

    start_date, end_date = get_date_range_filter(
        year=year,
        date=date,
        processed_dates=processed_dates,
    )
    logger.info(f"start_date, end_date {start_date, end_date}")

    query_error_msg = ""
    query = get_research_article_query(entity_id_key, entity_id, secondary_entity_id_key)
    response = await query_opensearch(query, index)

    df = pd.DataFrame()
    if response["timed_out"] is False:
        if len((response["aggregations"]["results"]["buckets"])) != 0:
            df = pd.DataFrame(
                data=[list(bucket["key"].values()) for bucket in response["aggregations"]["results"]["buckets"]],
                columns=list(response["aggregations"]["results"]["buckets"][0]["key"].keys()),
            )
            df["metadata.articleReleaseDate"] = df["metadata.articleReleaseDate"].apply(
                lambda x: datetime.fromtimestamp(x / 1000).strftime("%Y-%m-%dT%H:%M:%S")
            )
            logger.info(f"Number of articles in opensearch database for given entity: {len(df)}")
        else:
            logger.error("No documents in vector db for given entity: " + query_error_msg)
            return []
    else:
        logger.error(f"Some error occured with status code : {response['status']} while fetching relevant article ids.")
        return []

    if entity_type == "revenue_source" or entity_type == "uspf":
        primary_entity_name = ""
        singular_eid = ~df[f"metadata.{entity_id_key}"].str.contains(";")
        if singular_eid.any():
            primary_entity_name = df[singular_eid]["metadata.aggLegalEntityName"].unique()[0]
        else:
            primary_entity_name = df["metadata.aggLegalEntityName"].replace("", None).dropna().value_counts().idxmax()
        if primary_entity_name == "":
            logger.error("No primary entity name found for given entity: " + query_error_msg)
            return []

        titles = df["metadata.SourceTitle"].to_list()
        if len(titles) != 0:
            relevant_articles = [fuzzy_substring_match(title, primary_entity_name, threshold=0.5) for title in titles]
            df = df[relevant_articles]
        if len(df) == 0:
            logger.info("No documents in vector db for given entity after fuzzy matching: " + query_error_msg)
            return []

        logger.info(
            f"Number of articles in opensearch database for given entity {query_error_msg} after fuzzy matching: {len(df)}"
        )

    df["metadata.articleReleaseDate"] = pd.to_datetime(df["metadata.articleReleaseDate"])
    df = df.sort_values(by="metadata.articleReleaseDate", ascending=False)

    logger.info(f"df : {df}")
    logger.info(f"Date range applied to filter the documents - start_date: {start_date}, end_date: {end_date}")
    if start_date and end_date:
        df = df.loc[(df["metadata.articleReleaseDate"] >= start_date) & (df["metadata.articleReleaseDate"] <= end_date)]

    top_n = 6
    if uc_type == "research" and not article_type:
        selected_ids = df["metadata.articleID"].unique()[:top_n].tolist()
    elif uc_type == "research" and article_type == "full":
        full_articles = df[df["metadata.articleType"] == "FULL"]
        selected_ids = full_articles["metadata.articleID"].unique()[:top_n].tolist()
    else:
        (
            selected_full_article,
            selected_tear_sheet_article,
            selected_rating_action_news_article,
            selected_research_update_article,
            selected_bulletin_article,
            selected_summary_article,
        ) = ([], [], [], [], [], [])
        if entity_type in ["company", "uspf", "revenue_source", "sf"] or uc_type == "rating_action":
            full_articles = df[df["metadata.articleType"] == "FULL"]
            if len(full_articles):
                for idx, row in full_articles.iterrows():
                    if (
                            ("Tear Sheet" == row["metadata.slug"])
                            and (len(selected_tear_sheet_article) == 0)
                            and (entity_type == "company")
                    ):
                        selected_tear_sheet_article.append(row)
                    else:
                        selected_full_article.append(row)
                        break

            rating_action_news_articles = df[
                (df["metadata.articleType"] == "NEWS") & (df["metadata.articleSubType"] == "RATING_ACTION")
                ]
            if len(rating_action_news_articles):
                selected_rating_action_news_article.append(rating_action_news_articles.iloc[0])

        if entity_type == "sf" or uc_type == "rating_action":
            presale_reports = df[df["metadata.articleSubType"] == "PRESALE"]
            if len(presale_reports):
                selected_full_article.append(presale_reports.iloc[0])

        if entity_type == "company" or uc_type == "rating_action":
            research_update_articles = df[df["metadata.articleType"] == "RESUPD"]
            if len(research_update_articles):
                selected_research_update_article.append(research_update_articles.iloc[0])

            bulletin_news_articles = df[
                (df["metadata.articleType"] == "NEWS") & (df["metadata.articleSubType"] == "BULLETIN")
                ]
            if len(bulletin_news_articles):
                selected_bulletin_article.append(bulletin_news_articles.iloc[0])

        if entity_type == "uspf" or entity_type == "revenue_source" or uc_type == "rating_action":
            summary_articles = df[df["metadata.articleType"] == "SUMMARY"]
            if len(summary_articles):
                selected_summary_article.append(summary_articles.iloc[0])

        selected_all_article = (
                selected_full_article
                + selected_tear_sheet_article
                + selected_rating_action_news_article
                + selected_research_update_article
                + selected_bulletin_article
                + selected_summary_article
        )

        selected_df = pd.DataFrame(selected_all_article)
        selected_ids = selected_df["metadata.articleID"].unique().tolist() if not selected_df.empty else []

    if len(selected_ids) == 0:
        logger.error("No documents in vector db for given entity after time filtering: " + query_error_msg)
        return []

    return selected_ids


def get_efficient_filter(article_list: List[int], uc_type: str, processed_dates: ProcessedRetrieverDates):
    efficient_filter = None
    must_clauses = None
    if article_list:
        must_clauses = [
            {"terms": {"metadata.articleID": article_list}}
        ]
        if uc_type == "peer":
            must_clauses += [{"match": {"metadata.chunk_title": "Peer Comparison"}}]
    if article_list is None and processed_dates.start_date and processed_dates.end_date:
        must_clauses = [{"range": {"metadata.articleReleaseDate": {
            "gte": processed_dates.start_date, "lte": processed_dates.end_date}}}]

    if must_clauses:
        efficient_filter = {
            "bool": {
                "must": must_clauses,
            }
        }

    return efficient_filter


def get_hybrid_search_query(k: int, model_id: str, efficient_filter: dict, user_query: str):
    query = {
        "_source": {"exclude": "vector_field"},
        "size": k,
        "query": {
            "hybrid": {
                "queries": [
                    {
                        "bool": {
                            "must": {
                                "match": {
                                    "text": {
                                        "query": user_query,
                                    }
                                },
                            },
                            "filter": (
                                (
                                    efficient_filter["bool"]["must"]
                                    if "must" in efficient_filter["bool"]
                                    else efficient_filter["bool"]["should"]
                                )
                                if efficient_filter
                                else []
                            ),
                        }
                    },
                    {
                        "neural": {
                            "vector_field": {
                                "query_text": user_query,
                                "model_id": model_id,
                                "k": k,
                                "filter": (efficient_filter if efficient_filter else {"bool": {"must": []}}),
                            }
                        }
                    },
                ]
            }
        },
    }
    return query


async def query_opensearch(query: dict, index: str, search_pipeline: str = None):
    # Get configuration
    cfg = get_config()
    opensearch_url = cfg["opensearch_url"]
    opensearch_username_key = cfg["opensearch_username_key"]
    opensearch_password_key = cfg["opensearch_password_key"]

    index_name = cfg[f"opensearch_{index}_index"]
    search_url = f"{opensearch_url}/{index_name}/_search"
    if search_pipeline:
        search_url += f"?search_pipeline={search_pipeline}"
    headers = {"Content-Type": "application/json"}
    global async_client
    synthia_secret = await get_secrets()
    opensearch_auth = (
        synthia_secret[get_env_specific_secret_key(opensearch_username_key)],
        synthia_secret[get_env_specific_secret_key(opensearch_password_key)]
    )
    response = await async_client.post(search_url, json=query, auth=opensearch_auth, headers=headers)
    return response.json()


def get_documents_with_scores(search_results: dict):
    documents = []
    scores = []
    for result in search_results["hits"]["hits"]:
        text = result["_source"]["text"]
        metadata = result["_source"]["metadata"]
        documents.append(Document(content=text, metadata=metadata))
        scores.append(result["_score"])
    logger.info(f"{len(documents)} documents found")
    return documents, scores


def remove_duplicates(documents: List[Document]):
    seen = {}
    unique_documents = []
    for doc in documents:
        if doc.content not in seen:
            seen[doc.content] = True
            unique_documents.append(doc)
    return unique_documents


def dict_coalesce(data_source: Dict, keys: List[str], default: Optional[Any] = None) -> Any:
    values = [data_source.get(key) for key in keys]
    try:
        return next(item for item in values if item is not None)
    except StopIteration:
        return default


def get_reranked_documents(
        query: str,
        retrieved_documents: List[Document],
        entity_name: Union[str, None],
        reranker_k: int,
        reranker_threshold: Optional[float] = None,
) -> MCPResponse:
    # Get configuration
    cfg = get_config()
    ratings_article_base_url = cfg["ratings_article_base_url"]

    reranker_client = get_aws_client("sagemaker-runtime")
    reranker_endpoint_name = cfg["reranker_endpoint_name"]
    retrieved_documents = remove_duplicates(retrieved_documents)
    sources = []
    contents = []
    seen_contents = set()
    if len(retrieved_documents) > 1:
        pairs = []
        for doc in retrieved_documents:
            text = (
                    "# Document Title : "
                    + dict_coalesce(doc.metadata, ["PreferredTitle", "SourceTitle"], default="")
                    + "\n"
                    + "# Section Title : "
                    + (doc.metadata.get("chunk_title") or "")
                    + "\n"
                    + (("# Entity Names : " + entity_name) if entity_name else "")
                    + "\n"
                    + "# Text : "
                    + (doc.content or "")
            )
            pairs.append([query, text])

        outputs = reranker_client.invoke_endpoint(
            EndpointName=reranker_endpoint_name,
            Body=json.dumps({"pairs": pairs}),
            ContentType="application/json",
        )
        reranked_scores = json.loads(outputs["Body"].read().decode("utf-8"))

        if reranker_threshold is not None:
            reranked_scores_documents = [
                (score, obj)
                for score, obj in zip(reranked_scores["scores"], retrieved_documents)
                if score >= reranker_threshold
            ]
            if len(reranked_scores_documents) == 0:
                return retrieved_documents[: reranker_k // 2]
        else:
            reranked_scores_documents = [
                (score, obj) for score, obj in zip(reranked_scores["scores"], retrieved_documents)
            ]
        sorted_data = sorted(reranked_scores_documents, key=lambda k: k[0], reverse=True)[:reranker_k]
        scores, retrieved_documents = zip(*sorted_data)
        logger.info(f"Number of retrieved documents after reranking: {len(retrieved_documents)}")
    for document in retrieved_documents[:5]:
        content = document.content
        article_id = document.metadata.get("articleID")
        article_title = document.metadata.get("PreferredTitle")
        article_release_date = document.metadata.get("articleReleaseDate")
        formatted_release_date = datetime.fromisoformat(article_release_date).strftime("%B %d, %Y")
        document_type = get_article_document_mapping(document.metadata.get("articleType", None),
                                                     document.metadata.get("articleSubType", None))
        article_full_title = f"{article_title} | {document_type} | {formatted_release_date}"
        source = Source(title=article_full_title,
                        url=f"{ratings_article_base_url}?target=ratingsdirect%2FcreditResearch%3Frid%3D{article_id}")
        sources.append(source)
        if content not in seen_contents:
            contents.append(ArticleItem(
                article_id=article_id,
                content=content
            ))
        seen_contents.add(content)

    logger.info(f"source: {sources},\ndata: {contents}")
    return MCPResponse(
        sources=sources,
        data=contents,
        isError=False,
        message="Documents retrieved successfully."
    )


async def get_documents(search_request: SearchRequest) -> MCPResponse:
    # Get configuration
    cfg = get_config()

    logger.info(f"search_request : {search_request}")
    k = search_request.k
    index = search_request.index
    year = search_request.yr
    uc_type = search_request.uc_type
    entity = search_request.entity
    if entity is None and uc_type in uc_types_require_entity:
        raise Exception(f"No entity found for {uc_type}")
    search_entity = get_search_entity(search_request.entity)
    logger.info(f"search_entity : {search_entity}")
    date = search_request.dt
    article_type = search_request.article_type
    processed_dates = search_request.processed_dates
    search_algo = search_request.search_algo
    reranker_k = search_request.reranker_k
    user_query = search_request.user_query
    entity_name = entity.entity_name
    logger.info(f"entity_name : {entity_name}")
    article_list = await get_research_article_list(search_entity, index, year, date, uc_type, article_type,
                                                   processed_dates)
    if article_list is None and uc_type in uc_types_require_article_list:
        logger.error(f"No article found for {uc_type}")
    efficient_filter = None
    if article_list or index not in index_require_article_list:
        logger.info(f"Articles found in {index} : {article_list}")
        if article_list:
            efficient_filter = get_efficient_filter(article_list, uc_type, processed_dates)
            logger.info(f"efficient_filter : {efficient_filter}")
        model_id = cfg["neural_search_model_id"]
        search_pipeline = cfg["search_pipeline_name"]
        query = get_hybrid_search_query(k, model_id, efficient_filter, user_query)
        logger.info(f"query : {query}")
        if search_algo == "hybrid":
            results = await query_opensearch(query, index, search_pipeline)
            documents, scores = get_documents_with_scores(results)
            reranked_documents = get_reranked_documents(user_query, documents, entity_name, reranker_k)
            return reranked_documents
        else:
            return MCPResponse(
                sources=None,
                data=None,
                isError=True,
                message=f"Search algorithm {search_algo} is not implemented"
            )
    else:
        logger.error(f"No article found in {index}")
        return MCPResponse(
            sources=None,
            data=None,
            isError=True,
            message=f"No article found in {index} for the given entity."
        )


@mcp.tool()
async def get_documents_from_research_articles(query: str, entity_name: str, keyInstn: int, sector: list[str],
                                               vectorstore_index: str) -> MCPResponse:
    """
    Retrieve relevant S&P ratings credit research content from OpenSearch vectorstore

    Args:
        query (str):
            A natural language question.
        entity_name (str):
            Name of the company.
        keyInstn (int):
            Institution ID of the company.
        sector (list[str]):
            List of sectors the company belongs to.If the company is part of the RD Universe, use RDSectors; otherwise, use [].
        vectorstore_index (str):
            The OpenSearch index to query.Available indexes are:
                1.research : Contains articles with following credit aspects of a company :
                             - company description
                             - latest news
                             - current and historical credit ratings
                             - credit outlook
                             - strengths, weaknesses, opportunities, and threats (SWOT)
                             - sector/industry risks faced by the company
                             - peer comparison
                             - financial highlights
                             - ESG factors
                             Sample queries->
                                 • "What is <company>'s current credit rating?"
                                 • "Tell me about <company>'s financial performance and outlook"
                                 • "How does <company> compare to its peers"
                2.commentary:Contains article with commentary on broader industry/sector/geography.
                These can be used to:
                             - Interpret developments in industry/sector/geography
                             - Highlight trends in industry/sector/geography
                             - Provide forward-looking views on industry/sector/geography
                             Sample queries->
                                 • "What are the current trends in the <industry> industry?"
                                 • "What's the outlook for the <industry> industry?"
                                 • "How is inflation affecting <geography> market?"
                3.criteria:Contains article with following analytical frameworks, credit factors, and assumptions
                           S&P Global uses when assigning credit ratings :
                             - rating criteria  such as WARF,key business and financial risks,core and
                               supplemental ratios,SACP which are used to rate a company or sector
                             - rating methodologies
                           Sample queries->
                                 • "How does S&P calculate SACP for <sector> entities such as <company>?"
                                 • "What are the key rating criteria for <sector> companies?"
                                 • "Explain the methodology for <company>"
                                 • "Explain the supplemental ratios used in <sector>'s ratings"
    Returns:
        MCPResponse: The response containing retrieved document content and source URLs.
        
    """
    documents = []
    try:
        entity = Entity(entity_name=entity_name, entity_id=keyInstn, sector=sector)
        logger.info(f"entity is {entity}")
        search_request = SearchRequest(entity=entity, user_query=query,
                                       index=vectorstore_index)
        documents = await get_documents(search_request)
    except Exception as e:
        logger.error(f"Some error happened in research_articles MCP:{e}")
    return documents


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Initialize MCP server task group
    logger.info("Initializing MCP server task group...")
    global async_client
    async_client = httpx.AsyncClient(timeout=10)
    async with contextlib.AsyncExitStack() as stack:
        await stack.enter_async_context(mcp.session_manager.run())
        yield
    await async_client.aclose()


@router.get("/research-articles/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "ok"}


# Create FastAPI app with lifespan
app = FastAPI(lifespan=lifespan)
app.mount("/research-articles", mcp.streamable_http_app())
app.include_router(router)
