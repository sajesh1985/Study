from typing import Any, Sequence, Union

from chatrd.core.llm.components.message import BaseMessage, MessageLikeRepresentation
from chatrd.core.llm.prompt import PromptValue

LanguageModelInput = Union[PromptValue, str, Sequence[MessageLikeRepresentation]]
LanguageModelOutput = Union[BaseMessage, str]
MessageLikeRepresentation = Union[BaseMessage, str, list[str], tuple[str, str], dict[str, Any]]
