"""Test cases for the new SourceExtractor classes from source_generator.py."""

import json
from unittest.mock import Mock, patch

from chatrd.core.document.schema import Document, TableDocument
from chatrd.engine.app.source_extractor import (
    RESEARCH_TYPE_MAPPING,
    TEMPLATED_SOURCE,
    DetailedSourceExtractor,
    DocumentMetadata,
    MarkdownSourceExtractor,
    StructuredData,
    UnstructuredData,
)
from chatrd.engine.configuration.config_key import ConfigKey, Constants

EXPECTED_LINK_PATTERN = "BASE_URL/RESEARCH?auth=inherit#ratingsdirect/creditResearch"


def create_metadata(
    article_id: int,
    article_type: str = "FULL",
    article_sub_type: str = "RESEARCH",
    preferred_title: str = None,
    release_date: str = None,
) -> dict:
    """Helper method to create a sample metadata dictionary."""
    return {
        "articleID": str(article_id),
        "articleType": article_type,
        "articleSubType": article_sub_type,
        "PreferredTitle": preferred_title or "Test Article",
        "articleReleaseDate": release_date or "2023-10-01T00:00:00Z",
    }


def create_document_metadata(id, doc_type, article_type, article_sub_type, source_object_id=None) -> DocumentMetadata:
    """Helper method to create a DocumentMetadata instance."""
    return DocumentMetadata(
        document_type=doc_type,
        document_title="Test",
        date="2023-10-01",
        id=id,
        article_id=id,
        source_object_id=source_object_id or id,
        article_type=article_type,
        article_sub_type=article_sub_type,
        release_date="2023-10-01",
    )


def create_unstructured_data(
    id, title, article_type, article_sub_type, source_object_id=None, date=None
) -> UnstructuredData:
    """Helper method to create an UnstructuredData instance."""
    if "CRITERIA" in article_sub_type:
        doc_type = "criteria"
        doc_type_name = "Criteria Article"
    else:
        doc_type = RESEARCH_TYPE_MAPPING.get(article_type, "research article").lower()
        doc_type_name = "Research Article"
    return UnstructuredData(
        article_id=id,
        title=title or "Test Article",
        date=date if date is not None else "October 01, 2023",
        raw_date="2023-10-01T00:00:00Z",
        article_type=article_type,
        document_type=doc_type,
        document_type_name=doc_type_name,
        url=f"http://test.com/article/{id}",
        source_object_id=source_object_id or id,
        is_criteria=True if article_type == "CRITERIA" else False,
    )


def create_document(content: str = None, metadata: dict = None) -> Document:
    """Helper method to create a document with given metadata."""
    return Document(content=content or "Sample content", metadata=metadata or {})


def create_table_document(content: str = None, metadata: dict = None) -> TableDocument:
    """Helper method to create a table document."""
    return TableDocument(content=content or "Sample table content", metadata=metadata or {})


class TestSourceExtractorCommon:
    """Test cases for the common functionality of all SourceExtractors."""

    def setup_method(self):
        """Set up test fixtures before each test method."""
        with patch(
            "chatrd.engine.configuration.config_machinery.ConfigMachinery.get_config_value"
        ) as mock_config_value:

            def side_effect(arg: ConfigKey):
                if arg == Constants.SourceGeneration.BASE_URL:
                    return "BASE_URL"
                elif arg == Constants.SourceGeneration.RESEARCH_ARTICLE_URL_SLUG:
                    return "/RESEARCH"
                else:
                    return f"<{arg.value}>"

            mock_config_value.side_effect = side_effect
            self.extractor = DetailedSourceExtractor()

    def test_filter_documents_by_type(self):
        """Test _filter_documents_by_type method."""
        structured_doc = create_document(metadata={"response_payload": {"key": "value"}})
        unstructured_doc = create_document(metadata={"articleID": "12345"})

        structured, unstructured = self.extractor._filter_documents_by_type([structured_doc, unstructured_doc])

        assert len(structured) == 1
        assert len(unstructured) == 1

    def test_is_structured_source(self):
        """Test is_structured_source method."""
        structured_doc = create_document(metadata={"response_payload": {"key": "value"}})
        unstructured_doc = create_document(metadata={"articleID": "12345"})

        assert self.extractor._is_structured_source(structured_doc) is True
        assert self.extractor._is_structured_source(unstructured_doc) is False

    def test_is_unstructured_source(self):
        """Test is_unstructured_source method."""
        structured_doc = create_document(metadata={"response_payload": {"key": "value"}})
        unstructured_doc = create_document(metadata={"articleID": "12345"})

        assert self.extractor._is_unstructured_source(structured_doc) is False
        assert self.extractor._is_unstructured_source(unstructured_doc) is True

    def test_is_criteria_document(self):
        """Test is_criteria_document method."""
        criteria_metadata = create_document_metadata(123, "criteria", "CRITERIA", "CRITERIA")
        research_metadata = create_document_metadata(123, "research", "FULL", "RESEARCH")

        assert self.extractor._is_criteria_document(criteria_metadata) is True
        assert self.extractor._is_criteria_document(research_metadata) is False

    def test_extract_various_doc_types(self):
        """Test extract method with different document types."""
        doc_metadata = create_metadata(123)
        docs = [
            create_document(content="Test document", metadata=doc_metadata),
            create_table_document(content="Test table document", metadata=doc_metadata),
        ]
        for doc in docs:
            result = self.extractor.extract([doc])
            assert isinstance(result, list) and len(result) == 1
            src_detail = result[0]
            assert isinstance(src_detail, dict)
            assert src_detail["id"] == "123"
            assert src_detail["title"] == doc_metadata.get("PreferredTitle")
            assert src_detail["link"] == f"{EXPECTED_LINK_PATTERN}?rid=123"
            assert src_detail["type"] == doc_metadata.get("articleType")
            assert src_detail["name"] == "Research Article"

    def test_structured_source_with_source_description(self):
        """Test extraction of structured sources with source_description."""
        metadata = {"response_payload": {"key": "value"}, "source_description": [["Test Title", "http://example.com"]]}
        doc = create_document(metadata=metadata)

        result = self.extractor.extract([doc])

        assert len(result) == 1
        # Find the structured source
        structured_source = next((s for s in result if s["name"] == "Data API Services"), None)
        assert structured_source is not None
        assert structured_source["title"] == "Test Title"
        assert structured_source["link"] == "http://example.com"
        assert structured_source["details"] == json.dumps(metadata["response_payload"])

    def test_structured_source_without_source_description(self):
        """Test extraction of structured sources without source_description."""
        metadata = {"response_payload": {"key": "value"}, "source_description": None}
        doc = create_document(metadata=metadata)

        result = self.extractor.extract([doc])

        assert len(result) >= 1
        # Find the structured source
        structured_source = next((s for s in result if s["name"] == "Data API Services"), None)
        assert structured_source is not None
        assert structured_source["title"] is None
        assert structured_source["link"] is None

    def test_research_article_extraction(self):
        """Test extraction of research articles."""
        metadata = create_metadata(12345, preferred_title="Test Research Article")
        doc = create_document(metadata=metadata)

        result = self.extractor.extract([doc])

        assert len(result) >= 1
        research_source = next((s for s in result if s["name"] == "Research Article"), None)
        assert research_source is not None
        assert research_source["id"] == "12345"
        assert research_source["title"] == "Test Research Article"
        assert research_source["type"] == "FULL"

    def test_criteria_article_extraction(self):
        """Test extraction of criteria articles."""
        metadata = create_metadata(
            67890, article_type="CRITERIA", article_sub_type="CRITERIA", preferred_title="Test Criteria Article"
        )
        doc = create_document(metadata=metadata)

        result = self.extractor.extract([doc])

        assert len(result) >= 1
        criteria_source = next((s for s in result if s["name"] == "Criteria Article"), None)
        assert criteria_source is not None
        assert criteria_source["id"] == "67890"
        assert criteria_source["title"] == "Test Criteria Article"

    def test_extract_document_metadata(self):
        """Test _extract_document_metadata method."""
        metadata = create_metadata(12345, preferred_title="Test Article")
        metadata["SourceObjectID"] = "98765"
        doc = create_document(metadata=metadata)

        result = self.extractor._extract_document_metadata(doc)

        assert result.article_id == 12345
        assert result.source_object_id == 98765
        assert result.article_type == "FULL"
        assert result.document_title == "Test Article"

    def test_generate_url_research_article(self):
        """Test URL generation for research articles."""
        metadata = create_document_metadata(123, "research article", "FULL", "RESEARCH")
        url = self.extractor._generate_url(metadata)
        assert url == f"{EXPECTED_LINK_PATTERN}?rid=123"

    def test_generate_url_criteria_article(self):
        """Test URL generation for criteria articles."""
        metadata = create_document_metadata(123, "criteria", "CRITERIA", "CRITERIA", 456)
        url = self.extractor._generate_url(metadata)
        assert url == f"{EXPECTED_LINK_PATTERN}?artObjectId=456&html=true"

    def test_extract_structured_data_empty_list(self):
        """Test extract_structured_data with empty list."""
        result = self.extractor._extract_structured_data([])
        assert result == []

    def test_extract_unstructured_data_empty_list(self):
        """Test extract_unstructured_data with empty list."""
        result = self.extractor._extract_unstructured_data([])
        assert result == []


class TestDetailedSourceExtractor:
    """Test cases for the new DetailedSourceExtractor class."""

    def setup_method(self):
        """Set up test fixtures before each test method."""
        with patch(
            "chatrd.engine.configuration.config_machinery.ConfigMachinery.get_config_value"
        ) as mock_config_value:

            def side_effect(arg: ConfigKey):
                if arg == Constants.SourceGeneration.BASE_URL:
                    return "BASE_URL"
                elif arg == Constants.SourceGeneration.RESEARCH_ARTICLE_URL_SLUG:
                    return "/RESEARCH"
                else:
                    return f"<{arg.value}>"

            mock_config_value.side_effect = side_effect
            self.extractor = DetailedSourceExtractor()

    def test_extract_fallback_to_default_value(self):
        """Test extract method with empty document list."""
        result = self.extractor.extract([])
        assert result == TEMPLATED_SOURCE

    def test_extract_returns_list_of_dicts(self):
        """Test that extract method returns list of dictionaries."""
        docs = [create_document(metadata=create_metadata(id)) for id in range(1, 4)]

        result = self.extractor.extract(docs)

        assert isinstance(result, list)
        assert len(result) == 3

    def test_format_structured_source(self):
        """Test format_structured_source method."""
        structured_data = StructuredData(
            title="Test Title", link="http://test.com", details={"test": "data"}, source_type="Data API Services"
        )

        result = self.extractor._format_structured_source(structured_data)

        assert result["title"] == "Test Title"
        assert result["link"] == "http://test.com"
        assert result["name"] == "Data API Services"
        assert "id" in result
        assert result["date"] is None
        assert result["type"] is None

    def test_format_unstructured_source(self):
        """Test format_unstructured_source method."""
        unstructured_data = create_unstructured_data(12345, "Test Article", "FULL", "RESEARCH")
        result = self.extractor._format_unstructured_source(unstructured_data)

        assert result["id"] == "12345"
        assert result["title"] == "Test Article"
        assert result["type"] == "FULL"
        assert result["name"] == "Research Article"
        assert result["link"] == "http://test.com/article/12345"

    # Duplicate removal tests
    def test_remove_duplicates(self):
        """Test duplicate removal based on link URLs."""
        sources = [
            {"id": "1", "title": "Article 1", "link": "http://same.com", "name": "Test"},
            {"id": "2", "title": "Article 2", "link": "http://same.com", "name": "Test"},
            {"id": "3", "title": "Article 3", "link": "http://different.com", "name": "Test"},
        ]

        result = self.extractor.remove_duplicates(sources)

        assert len(result) == 2
        links = [s["link"] for s in result]
        assert "http://same.com" in links
        assert "http://different.com" in links
        # Should keep the first occurrence
        titles = [s["title"] for s in result]
        assert "Article 1" in titles
        assert "Article 2" not in titles

    def test_no_duplicates_preserved(self):
        """Test that sources with different links are all preserved."""
        sources = [
            {"id": "1", "title": "Article 1", "link": "http://first.com", "name": "Test"},
            {"id": "2", "title": "Article 2", "link": "http://second.com", "name": "Test"},
            {"id": "3", "title": "Article 3", "link": "http://third.com", "name": "Test"},
            {"id": "4", "title": "Article 4", "link": "http://third.com", "name": "Test"},
        ]

        result = self.extractor.remove_duplicates(sources)

        assert len(result) == 3

    def test_mixed_structured_and_unstructured_sources(self):
        """Test handling of mixed structured and unstructured sources."""
        structured_metadata = {
            "response_payload": {"key": "value"},
            "source_description": [["Structured Title", "http://structured.com"]],
        }
        unstructured_metadata = create_metadata(12345, preferred_title="Unstructured Article")

        structured_doc = create_document(metadata=structured_metadata)
        unstructured_doc = create_document(metadata=unstructured_metadata)

        result = self.extractor.extract([structured_doc, unstructured_doc])

        assert len(result) >= 2
        source_names = [s["name"] for s in result]
        assert "Data API Services" in source_names
        assert "Research Article" in source_names


class TestMarkdownSourceExtractor:
    """Test cases for the new MarkdownSourceExtractor class."""

    def setup_method(self):
        """Set up test fixtures before each test method."""
        with patch(
            "chatrd.engine.configuration.config_machinery.ConfigMachinery.get_config_value"
        ) as mock_config_value:

            def side_effect(arg: ConfigKey):
                if arg == Constants.SourceGeneration.BASE_URL:
                    return "BASE_URL"
                elif arg == Constants.SourceGeneration.RESEARCH_ARTICLE_URL_SLUG:
                    return "/RESEARCH"
                else:
                    return f"<{arg.value}>"

            mock_config_value.side_effect = side_effect
            self.extractor = MarkdownSourceExtractor()

    def create_mock_document(self, metadata=None):
        """Helper method to create a mock document with given metadata."""
        mock_doc = Mock()
        mock_doc.metadata = metadata or {}
        return mock_doc

    def test_extract_empty_document_list(self):
        """Test extract method with empty document list."""
        result = self.extractor.extract([])
        assert result == []

    def test_extract_returns_list_of_strings(self):
        """Test that extract method returns list of strings."""
        doc = create_document(metadata=create_metadata(12345))

        result = self.extractor.extract([doc])

        assert isinstance(result, list)
        if len(result) > 0:
            assert isinstance(result[0], str)

    def test_research_article_markdown_generation(self):
        """Test Markdown link generation for research articles."""
        title = "Test Research Article"
        doc = create_document(metadata=create_metadata(12345, "FULL", "RESEARCH", preferred_title=title))

        result = self.extractor.extract([doc])

        if len(result) > 0:
            link = result[0]
            expected_extra_info = "full analysis document from October 01, 2023"
            assert link == f"[{title}]({EXPECTED_LINK_PATTERN}?rid=12345), {expected_extra_info}"

    def test_criteria_article_markdown_generation(self):
        """Test Markdown link generation for criteria articles."""
        title = "Test Criteria Article"
        metadata = create_metadata(67890, article_type="CRITERIA", article_sub_type="CRITERIA", preferred_title=title)
        doc = create_document(metadata=metadata)

        result = self.extractor.extract([doc])

        if len(result) > 0:
            link = result[0]
            expected_extra_info = "criteria document from October 01, 2023"
            assert link == f"[{title}]({EXPECTED_LINK_PATTERN}?artObjectId=67890&html=true), {expected_extra_info}"

    def test_format_structured_source_returns_empty(self):
        """Test that format_structured_source returns empty string."""
        structured_data = StructuredData(
            title="Test", link="http://test.com", details={}, source_type="Data API Services"
        )
        result = self.extractor._format_structured_source(structured_data)
        assert result == ""

    def test_format_unstructured_source_research(self):
        """Test format_unstructured_source for research articles."""
        unstructured_data = create_unstructured_data(12345, "Test Article", "FULL", "RESEARCH")
        result = self.extractor._format_unstructured_source(unstructured_data)
        assert result == (
            f"[Test Article]({EXPECTED_LINK_PATTERN}?rid=12345), full analysis document from October 01, 2023"
        )

    def test_format_unstructured_source_criteria(self):
        """Test format_unstructured_source for criteria articles."""
        unstructured_data = create_unstructured_data(67890, "Test Criteria", "CRITERIA", "CRITERIA")
        result = self.extractor._format_unstructured_source(unstructured_data)
        assert result == (
            f"[Test Criteria]({EXPECTED_LINK_PATTERN}?artObjectId=67890&html=true), criteria document from October 01, 2023"
        )

    def test_extract_categorized_all_categories(self):
        """Test extract_categorized method with all document categories."""
        source_doc = create_document(metadata=create_metadata(111, "FULL", "RESEARCH", "Source Article"))
        cited_doc = create_document(metadata=create_metadata(222, "NEWS", "RESEARCH", "Cited Article"))
        unauthorized_doc = create_document(
            metadata=create_metadata(333, "CRITERIA", "RESEARCH", "Unauthorized Article")
        )

        result = self.extractor.extract_categorized(
            source_docs=[source_doc], cited_docs=[cited_doc], unauthorized_docs=[unauthorized_doc]
        )

        for category, title in [
            ("source_links", "Source Article"),
            ("cited_links", "Cited Article"),
            ("unauthorized_links", "Unauthorized Article"),
        ]:
            assert category in result
            assert isinstance(result[category], list)
            assert result[category][0].startswith(f"[{title}]")

    def test_date_fallback(self):
        """Test fallback behavior for missing title and date."""
        unstructured_data = create_unstructured_data(12345, "Test Article", "FULL", "RESEARCH", date="")
        result = self.extractor._format_unstructured_source(unstructured_data)

        assert "Test Article" in result
        assert unstructured_data.raw_date in result
