import logging
from typing import Dict

logger = logging.getLogger(__name__)

from src.synthia.persistence.report_monitor import get_monitor
from src.synthia.workflows.workflow_helper import ReportWorkflow


async def handle_generate_report(payload: Dict) -> None:
    job_id = payload["job_id"]
    token = payload["token"]

    logger.info("Handling generate_report job=%s", job_id)

    status_tracker = get_monitor(token)
    report_status = await status_tracker.get_job(job_id)
    if not report_status:
        raise ValueError(f"Job {job_id} not found in database")

    config = dict(report_status.report_config)
    config["outline_only"] = True
    config["auth_token"] = token

    workflow = await ReportWorkflow.create_workflow(config)
    await workflow.start_workflow(status_tracker)


async def handle_outline_approval(payload: Dict) -> None:
    job_id = payload["job_id"]
    approved = payload["approved"]
    token = payload["token"]

    logger.info("Handling outline approval job=%s approved=%s", job_id, approved)

    status_tracker = get_monitor(token)
    report_status = await status_tracker.get_job(job_id)
    if not report_status:
        raise ValueError(f"Job {job_id} not found in database")

    config = dict(report_status.report_config)
    config["job_id"] = job_id
    config["auth_token"] = token

    if approved:
        config["approved_outline"] = report_status.outline
        workflow = await ReportWorkflow.create_workflow(config)
        await workflow.resume_workflow(user_input=True, approved=True, status_tracker=status_tracker)
    else:
        if payload.get("revised_sections") is not None:
            config["num_sections"] = int(payload["revised_sections"])
        if payload.get("revised_depth") is not None:
            config["depth"] = int(payload["revised_depth"])
        if payload.get("user_sections") is not None:        # <-- added
            config["user_sections"] = payload["user_sections"]

        workflow = await ReportWorkflow.create_workflow(config)
        await workflow.resume_workflow(user_input=False, approved=False, status_tracker=status_tracker)


ACTION_HANDLERS = {
    "generate_report": handle_generate_report,
    "process_outline_approval": handle_outline_approval,
}
