from chatrd.engine.components.query_analyzer.guideline_generator.guidelines import (
    GuidelineTemplate,
)
from chatrd.engine.components.query_analyzer.guideline_generator.prompt_templates.credit_memo import (
    creditmemo_guidelines,
)
from chatrd.engine.components.query_analyzer.guideline_generator.prompt_templates.criteria import (
    criteria_guidelines,
)
from chatrd.engine.components.query_analyzer.guideline_generator.prompt_templates.deals_tranche import (
    deals_tranche_guidelines,
)
from chatrd.engine.components.query_analyzer.guideline_generator.prompt_templates.definition import (
    definition_guidelines,
)
from chatrd.engine.components.query_analyzer.guideline_generator.prompt_templates.esg import (
    esg_guidelines,
)
from chatrd.engine.components.query_analyzer.guideline_generator.prompt_templates.financials import (
    financials_guidelines,
)
from chatrd.engine.components.query_analyzer.guideline_generator.prompt_templates.flex_arch import (
    flex_arch_guidelines,
)
from chatrd.engine.components.query_analyzer.guideline_generator.prompt_templates.general import (
    general_guidelines,
)
from chatrd.engine.components.query_analyzer.guideline_generator.prompt_templates.macro import (
    macro_guidelines,
)
from chatrd.engine.components.query_analyzer.guideline_generator.prompt_templates.outlook import (
    outlook_guidelines,
)
from chatrd.engine.components.query_analyzer.guideline_generator.prompt_templates.peers import (
    peers_guidelines,
)
from chatrd.engine.components.query_analyzer.guideline_generator.prompt_templates.rating_action import (
    rating_action_guidelines,
)
from chatrd.engine.components.query_analyzer.guideline_generator.prompt_templates.ratings import (
    ratings_guidelines,
)
from chatrd.engine.components.query_analyzer.guideline_generator.prompt_templates.research import (
    research_guidelines,
)
from chatrd.engine.components.query_analyzer.guideline_generator.prompt_templates.swot import (
    swot_guidelines,
)
from chatrd.engine.components.query_analyzer.utils import UCType

MAPPED_UC_GUIDELINES_TEMPLATE = {
    UCType.CREDIT_MEMO.value: GuidelineTemplate(
        prompt=creditmemo_guidelines["prompt"], examples=creditmemo_guidelines["examples"]
    ),
    UCType.RATINGS.value: GuidelineTemplate(
        prompt=ratings_guidelines["prompt"], examples=ratings_guidelines["examples"]
    ),
    UCType.PEERS.value: GuidelineTemplate(prompt=peers_guidelines["prompt"], examples=peers_guidelines["examples"]),
    UCType.ESG.value: GuidelineTemplate(prompt=esg_guidelines["prompt"], examples=esg_guidelines["examples"]),
    UCType.RESEARCH.value: GuidelineTemplate(
        prompt=research_guidelines["prompt"], examples=research_guidelines["examples"]
    ),
    UCType.OUTLOOK.value: GuidelineTemplate(
        prompt=outlook_guidelines["prompt"], examples=outlook_guidelines["examples"]
    ),
    UCType.FINANCIALS.value: GuidelineTemplate(
        prompt=financials_guidelines["prompt"], examples=financials_guidelines["examples"]
    ),
    UCType.CRITERIA.value: GuidelineTemplate(
        prompt=criteria_guidelines["prompt"], examples=criteria_guidelines["examples"]
    ),
    UCType.DEFINITION.value: GuidelineTemplate(
        prompt=definition_guidelines["prompt"], examples=definition_guidelines["examples"]
    ),
    UCType.SWOT.value: GuidelineTemplate(prompt=swot_guidelines["prompt"], examples=swot_guidelines["examples"]),
    UCType.SECURITIES.value: GuidelineTemplate(
        prompt=ratings_guidelines["prompt"], examples=ratings_guidelines["examples"]
    ),
    UCType.GENERAL.value: GuidelineTemplate(
        prompt=general_guidelines["prompt"], examples=general_guidelines["examples"]
    ),
    UCType.MACRO.value: GuidelineTemplate(prompt=macro_guidelines["prompt"], examples=macro_guidelines["examples"]),
    UCType.DEALS_TRANCHE.value: GuidelineTemplate(
        prompt=deals_tranche_guidelines["prompt"], examples=deals_tranche_guidelines["examples"]
    ),
    UCType.RATING_ACTION.value: GuidelineTemplate(
        prompt=rating_action_guidelines["prompt"], examples=rating_action_guidelines["examples"]
    ),
    UCType.FLEX_ARCH.value: GuidelineTemplate(
        prompt=flex_arch_guidelines["prompt"], examples=flex_arch_guidelines["examples"]
    ),
}
