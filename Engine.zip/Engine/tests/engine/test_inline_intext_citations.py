from unittest.mock import MagicMock, patch

import pytest

from chatrd.core.document import Document
from chatrd.core.llm.components.message import AIMessage
from chatrd.engine.components.query_processor.utils import (
    fix_wrong_bracket,
    inline_citations_formatter,
    sort_citations,
    split_multiple_citations,
)
from chatrd.engine.configuration import ConfigKey


@pytest.fixture
def resource_url_config_mock():
    with patch("chatrd.engine.components.query_processor.utils.config_machinery.get_config_value") as mock_config_value:

        def side_effect(arg: ConfigKey):
            return f"<{arg.value}>"

        mock_config_value.side_effect = side_effect
        yield mock_config_value


@pytest.mark.parametrize(
    "text, expected",
    [
        ("[SOURCE 1, SOURCE 3]", "[SOURCE 1], [SOURCE 3]"),
        ("[SOURCE 1, SOURCE 2, SOURCE 3]", "[SOURCE 1], [SOURCE 2], [SOURCE 3]"),
        ("[SOURCE 1, SOURCE 2, SOURCE 3, SOURCE 4]", "[SOURCE 1], [SOURCE 2], [SOURCE 3], [SOURCE 4]"),
        (
            "[SOURCE 1, SOURCE 2, SOURCE 3, SOURCE 4, SOURCE 5]",
            "[SOURCE 1], [SOURCE 2], [SOURCE 3], [SOURCE 4], [SOURCE 5]",
        ),
        (
            "[SOURCE 1, SOURCE 2, SOURCE 3, SOURCE 4, SOURCE 5, SOURCE 6]",
            "[SOURCE 1], [SOURCE 2], [SOURCE 3], [SOURCE 4], [SOURCE 5], [SOURCE 6]",
        ),
        ("test [SOURCE 1, SOURCE 2]text", "test [SOURCE 1], [SOURCE 2]text"),
    ],
)
def test_fix_wrong_bracket(text, expected):
    result = fix_wrong_bracket(text)
    assert result == expected


@pytest.mark.parametrize(
    "text, expected",
    [
        (
            '<a href="https://example.com">[1]</a>,<a href="https://example2.com">[2]</a>',
            ['<a href="https://example.com">[1]</a>', ',<a href="https://example2.com">[2]</a>'],
        ),
        (
            'test text <a href="https://example.com">[1]</a>,<a href="https://example2.com">[2]</a>',
            ['test text <a href="https://example.com">[1]</a>', ',<a href="https://example2.com">[2]</a>'],
        ),
    ],
)
def test_split_multiple_citations(text, expected):
    result = split_multiple_citations(text)
    assert result == expected


def test_inline_citations_formatter(resource_url_config_mock):
    # Mock token generator
    mock_token_generator = MagicMock()
    mock_token_generator.__iter__.return_value = iter(
        [
            AIMessage(content="Test"),
            AIMessage(content="abcd [SOURCE 1234],[SOURCE 1235] "),
            AIMessage(content="here [SOURCE "),
            AIMessage(content="1236],[SOURCE 1"),
            AIMessage(content="235] klf "),
            AIMessage(content="This hi [SOURCE 1235, SOURCE 1234] "),  # wrong format citations
            AIMessage(content="here is  source"),
            AIMessage(content="here is [SOURCE 1234] test"),
        ]
    )
    # create a synthesized documents
    testing_synthesized_docs = [
        Document(
            content="Doc 1",
            synthesize=True,
            metadata={
                "articleID": "1234",
                "source": "test_source1",
                "articleSubType": "RATING_ACTION",
                "PreferredTitle": "doc 1",
            },
        ),
        Document(
            content="Doc 2",
            synthesize=True,
            metadata={
                "articleID": "1235",
                "source": "test_source2",
                "articleSubType": "RATING_ACTION",
                "PreferredTitle": "doc 2",
            },
        ),
        Document(
            content="Doc 3",
            synthesize=True,
            metadata={
                "articleID": "1236",
                "source": "test_source3",
                "articleSubType": "RATING_ACTION",
                "PreferredTitle": "doc 3",
            },
        ),
        Document(
            content="Doc 4",
            synthesize=True,
            metadata={
                "articleID": "1237",
                "source": "test_source4",
                "articleSubType": "RATING_ACTION",
                "PreferredTitle": "doc 4",
            },
        ),
    ]

    expected_result = (
        'Testabcd <a href="<SOURCE_GENERATION_BASE_URL><RESEARCH_ARTICLE_URL_SLUG>?auth=inherit#ratingsdirect/creditResearch?rid=1234" '
        'title="doc 1" class="ccInTextCitation" target="_blank">[1]</a>,<a href="<SOURCE_GENERATION_BASE_URL><RESEARCH_ARTICLE_URL_SLUG>?auth=inherit#ratingsdirect/creditResearch?rid=1235" '
        'title="doc 2" class="ccInTextCitation" target="_blank">[2]</a> here <a href="<SOURCE_GENERATION_BASE_URL><RESEARCH_ARTICLE_URL_SLUG>?auth=inherit#ratingsdirect/creditResearch?rid=1236" '
        'title="doc 3" class="ccInTextCitation" target="_blank">[3]</a>,<a href="<SOURCE_GENERATION_BASE_URL><RESEARCH_ARTICLE_URL_SLUG>?auth=inherit#ratingsdirect/creditResearch?rid=1235" '
        'title="doc 2" class="ccInTextCitation" target="_blank">[2]</a> klf This hi <a href="<SOURCE_GENERATION_BASE_URL><RESEARCH_ARTICLE_URL_SLUG>?auth=inherit#ratingsdirect/creditResearch?rid=1235" '
        'title="doc 2" class="ccInTextCitation" target="_blank">[2]</a>, <a href="<SOURCE_GENERATION_BASE_URL><RESEARCH_ARTICLE_URL_SLUG>?auth=inherit#ratingsdirect/creditResearch?rid=1234" '
        'title="doc 1" class="ccInTextCitation" target="_blank">[1]</a> here is  sourcehere is <a href="<SOURCE_GENERATION_BASE_URL><RESEARCH_ARTICLE_URL_SLUG>?auth=inherit#ratingsdirect/creditResearch?rid=1234" '
        'title="doc 1" class="ccInTextCitation" target="_blank">[1]</a> test'
    )

    response = inline_citations_formatter(mock_token_generator, synthesized_docs=testing_synthesized_docs)

    sources = []
    content = ""
    for resp in response:
        if isinstance(resp, str):
            content += resp
        else:
            sources = resp.sources
    assert content == expected_result and all(
        doc == source for doc, source in zip(testing_synthesized_docs[:3], sources)
    )


def test_sort_citations(resource_url_config_mock):
    # Mock token generator
    mock_token_generator = MagicMock()
    mock_token_generator.__iter__.return_value = iter(
        [
            AIMessage(content="Test"),
            AIMessage(content="here is [SOURCE 1234],[SOURCE 1234] test"),  # remove duplicates
            AIMessage(content="here is [SOURCE 1235],[SOURCE 1236] test"),
            AIMessage(content="here is [SOURCE 1236],[SOURCE 1235],[SOURCE 1234] test"),  # sort citations
        ]
    )
    # create a synthesized documents
    testing_synthesized_docs = [
        Document(
            content="Doc 1",
            synthesize=True,
            metadata={
                "articleID": "1234",
                "source": "test_source1",
                "articleSubType": "RATING_ACTION",
                "PreferredTitle": "doc 1",
            },
        ),
        Document(
            content="Doc 2",
            synthesize=True,
            metadata={
                "articleID": "1235",
                "source": "test_source2",
                "articleSubType": "RATING_ACTION",
                "PreferredTitle": "doc 2",
            },
        ),
        Document(
            content="Doc 3",
            synthesize=True,
            metadata={
                "articleID": "1236",
                "source": "test_source3",
                "articleSubType": "RATING_ACTION",
                "PreferredTitle": "doc 3",
            },
        ),
        Document(
            content="Doc 4",
            synthesize=True,
            metadata={
                "articleID": "1237",
                "source": "test_source4",
                "articleSubType": "RATING_ACTION",
                "PreferredTitle": "doc 4",
            },
        ),
    ]

    # Expected result after sorting
    expected_result = (
        'Testhere is <a href="<SOURCE_GENERATION_BASE_URL><RESEARCH_ARTICLE_URL_SLUG>?auth=inherit#ratingsdirect/creditResearch?rid=1234" '
        'title="doc 1" class="ccInTextCitation" target="_blank">[1]</a> testhere is <a href="<SOURCE_GENERATION_BASE_URL><RESEARCH_ARTICLE_URL_SLUG>?auth=inherit#ratingsdirect/creditResearch?rid=1235" '
        'title="doc 2" class="ccInTextCitation" target="_blank">[2]</a>, <a href="<SOURCE_GENERATION_BASE_URL><RESEARCH_ARTICLE_URL_SLUG>?auth=inherit#ratingsdirect/creditResearch?rid=1236" '
        'title="doc 3" class="ccInTextCitation" target="_blank">[3]</a> testhere is <a href="<SOURCE_GENERATION_BASE_URL><RESEARCH_ARTICLE_URL_SLUG>?auth=inherit#ratingsdirect/creditResearch?rid=1234" '
        'title="doc 1" class="ccInTextCitation" target="_blank">[1]</a>, <a href="<SOURCE_GENERATION_BASE_URL><RESEARCH_ARTICLE_URL_SLUG>?auth=inherit#ratingsdirect/creditResearch?rid=1235" title="doc 2" class="ccInTextCitation" '
        'target="_blank">[2]</a>, <a href="<SOURCE_GENERATION_BASE_URL><RESEARCH_ARTICLE_URL_SLUG>?auth=inherit#ratingsdirect/creditResearch?rid=1236" title="doc 3" class="ccInTextCitation" target="_blank">[3]</a> test'
    )
    # Call the function under test
    response = inline_citations_formatter(mock_token_generator, synthesized_docs=testing_synthesized_docs)

    magic_mock_for_sort_citations = MagicMock()
    magic_mock_for_sort_citations.__iter__.return_value = response

    response2 = sort_citations(magic_mock_for_sort_citations)

    sources = []
    content = ""
    for resp in response2:
        if isinstance(resp, str):
            content += resp
        else:
            sources = resp.sources
    assert content == expected_result and all(
        doc == source for doc, source in zip(testing_synthesized_docs[:3], sources)
    )
