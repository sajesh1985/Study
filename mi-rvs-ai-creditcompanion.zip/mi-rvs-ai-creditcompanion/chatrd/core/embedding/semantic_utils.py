import heapq
import logging
from typing import Callable, Dict, List, Type, Union

import numpy as np
from numpy.typing import NDArray

from chatrd.core.embedding.numpy_utils import np_normalize, np_topk

logger = logging.getLogger(__name__)

ArrayLike = Union[NDArray, list, tuple]
ARRAYLIKE_TYPE_ERROR = "Input must be a list, tuple, or sequence that can be interpreted as a numpy ndarray."


def _convert_to_batch_array(arr: ArrayLike) -> NDArray:
    """
    Convert to numpy array with a batch dimension.
    If the np.ndarray is 1-dimensional, this adds a batch dimension.

    Args:
        arr (ArrayLike): The input array, which can be a python list, tuple or numpy array.

    Returns:
        NDArray: The array with a batch dimension.
    """
    try:
        arr = np.asarray(arr)
    except TypeError as e:
        logger.error(f"Failed to convert array input to numpy array with type: {type(arr)}. Error: {e}")
        raise ValueError(ARRAYLIKE_TYPE_ERROR) from e

    if arr.ndim == 1:
        arr = arr[np.newaxis, :]

    return arr


def normalize_embeddings(embeddings: NDArray) -> NDArray:
    """
    Normalizes the embeddings matrix, so that each sentence embedding has unit length.

    Args:
        embeddings (NDArray): The input embeddings matrix.

    Returns:
        NDArray: The normalized embeddings matrix.
    """
    return np_normalize(embeddings, p=2, axis=1)


def cos_sim(a: ArrayLike, b: ArrayLike) -> NDArray:
    """
    Computes the cosine similarity between two numpy array or list.

    Args:
        a (Union[list, NDArray]): The first array.
        b (Union[list, NDArray]): The second array.

    Returns:
        NDArray: Numpy array with res[i][j] = cos_sim(a[i], b[j])
    """
    arr_a: NDArray = _convert_to_batch_array(a)
    arr_b: NDArray = _convert_to_batch_array(b)

    a_normalized: NDArray = normalize_embeddings(arr_a)
    b_normalized: NDArray = normalize_embeddings(arr_b)

    return np.matmul(a_normalized, b_normalized.T)


def semantic_search(
    query_embeddings: ArrayLike,
    corpus_embeddings: ArrayLike,
    query_chunk_size: int = 100,
    corpus_chunk_size: int = 500000,
    top_k: int = 10,
    score_function: Callable[[ArrayLike, ArrayLike], NDArray] = cos_sim,
) -> List[List[Dict[str, Union[int, float]]]]:
    """
    This function performs a cosine similarity search between a list of query embeddings  and a list of corpus embeddings.
    It can be used for Information Retrieval / Semantic Search for corpora up to about 1 Million entries.

    Args:
        query_embeddings (ArrayLike): A 2 dimensional array with the query embeddings.
        corpus_embeddings (ArrayLike): A 2 dimensional array with the corpus embeddings.
        query_chunk_size (int, optional): Process 100 queries simultaneously. Increasing that value increases the speed, but requires more memory. Defaults to 100.
        corpus_chunk_size (int, optional): Scans the corpus 100k entries at a time. Increasing that value increases the speed, but requires more memory. Defaults to 500000.
        top_k (int, optional): Retrieve top k matching entries. Defaults to 10.
        score_function (Callable[[ArrayLike, ArrayLike], np.ndarray], optional): Function for computing scores. By default, cosine similarity.
    # Where ArrayLike = Union[NDArray, list, tuple]

    Returns:
        List[List[Dict[str, Union[int, float]]]]: A list with one entry for each query. Each entry is a list of dictionaries with the keys 'corpus_id' and 'score', sorted by decreasing cosine similarity scores.
    """

    try:
        query_embeddings = np.asarray(query_embeddings)
    except TypeError as e:
        logger.error(f"Failed to convert array input to numpy array with type: {type(arr)}. Error: {e}")
        raise ValueError(ARRAYLIKE_TYPE_ERROR)
    if len(query_embeddings.shape) == 1:
        query_embeddings = query_embeddings[np.newaxis, :]

    try:
        corpus_embeddings = np.asarray(corpus_embeddings)
    except TypeError as e:
        logger.error(f"Failed to convert array input to numpy array with type: {type(arr)}. Error: {e}")
        raise ValueError(ARRAYLIKE_TYPE_ERROR)

    queries_result_list = [[] for _ in range(len(query_embeddings))]

    for query_start_idx in range(0, len(query_embeddings), query_chunk_size):
        # Iterate over chunks of the corpus
        for corpus_start_idx in range(0, len(corpus_embeddings), corpus_chunk_size):
            # Compute cosine similarities
            cos_scores = score_function(
                query_embeddings[query_start_idx : query_start_idx + query_chunk_size],
                corpus_embeddings[corpus_start_idx : corpus_start_idx + corpus_chunk_size],
            )

            # Get top-k scores
            num_of_top_elements = min(top_k, len(cos_scores[0]))
            cos_scores_top_k_values, cos_scores_top_k_idx = np_topk(
                input_array=cos_scores,
                k=num_of_top_elements,
                axis=1,
                largest=True,
                sorted=False,
            )
            cos_scores_top_k_values = cos_scores_top_k_values.tolist()
            cos_scores_top_k_idx = cos_scores_top_k_idx.tolist()

            for query_itr in range(len(cos_scores)):
                for sub_corpus_id, score in zip(cos_scores_top_k_idx[query_itr], cos_scores_top_k_values[query_itr]):
                    corpus_id = corpus_start_idx + sub_corpus_id
                    query_id = query_start_idx + query_itr
                    if len(queries_result_list[query_id]) < top_k:
                        heapq.heappush(
                            queries_result_list[query_id], (score, corpus_id)
                        )  # heaqp tracks the quantity of the first element in the tuple
                    else:
                        heapq.heappushpop(queries_result_list[query_id], (score, corpus_id))

    # change the data format and sort
    for query_id in range(len(queries_result_list)):
        for doc_itr in range(len(queries_result_list[query_id])):
            score, corpus_id = queries_result_list[query_id][doc_itr]
            queries_result_list[query_id][doc_itr] = {"corpus_id": corpus_id, "score": score}
        queries_result_list[query_id] = sorted(queries_result_list[query_id], key=lambda x: x["score"], reverse=True)

    return queries_result_list
