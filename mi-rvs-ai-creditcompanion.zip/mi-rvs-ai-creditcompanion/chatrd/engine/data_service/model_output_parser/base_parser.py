import abc
import json
import logging
import traceback
from typing import Dict, List, Optional, Tuple

import pandas as pd

from chatrd.core.embedding import embedding_factory
from chatrd.core.utils import df_safe_get, safe_get
from chatrd.engine.data_service.kpqi import KPQI
from chatrd.engine.data_service.locator import main_directory
from chatrd.engine.data_service.model_output_parser.utils import (
    check_dynamic_time_window,
    update_unit_scale,
)
from chatrd.engine.data_service.model_output_parser.variables import (
    CONNECTOR_MAPPING,
    ENTITY_KEY_MAPPING,
    OPERATOR_MAPPING,
)
from chatrd.engine.data_service.vector_database import vector_database

logger = logging.getLogger(__name__)

CREDIT_ACTIONS = {"DOWNGRADE": "3605525", "UPGRADE": "3605529", "NEW RATING": "3605526"}


def convert_codes(input_string):
    mapping_file_path = "model_output_parser/data/industry_code_map.json"
    with open(main_directory(mapping_file_path), "rt") as f:
        sector_code_mapping = json.load(f)

    converted = [sector_code_mapping.get(code.strip(), code.strip()) for code in input_string.split(",")]
    return ", ".join(converted)


def get_default_dict_payload_for_company(
    entities: dict, key_perspective_str: str, index: Optional[int] = 0
) -> Tuple[dict]:
    """
    Find the best MI id for the entity name.

    If no mi_id or as_id is found, use entity name instead.
    Args:
        entities (Entities): The entities object.
        key_perspective_str: (str): The perspective name.
        index (int): Index position to look for entities dict.

    Returns: A tuple of dictionaries with default values.

    """
    mi_id = None
    entity_name = None
    if key_perspective_str == "company" and "companies" in entities and entities["companies"]:
        mi_id = entities["companies"][index].get("mi_id")
        entity_name = entities["companies"][index].get("name")
        logger.info(f"The company is {entity_name} with entity id is {mi_id}.")
    elif key_perspective_str == "revenue_sources" and "revenue_sources" in entities and entities["revenue_sources"]:
        asid_id = entities["revenue_sources"][index].get("asid")
        revenue_source_name = entities["revenue_sources"][index].get("name")

        logger.info(f"The revenue source is {revenue_source_name} with ASIDiD {asid_id}.")
    else:
        raise Exception(
            f"Something occurred with given key_perspective_str: {key_perspective_str} and entities : {entities}"
        )

    if mi_id:
        kpqi = ENTITY_KEY_MAPPING[key_perspective_str]
        # TODO: MI Key. This may change when entitlement is required.
        payload_value = mi_id
        text_value = entity_name
        text_operator = "equal"
        payload_operator = 0
    elif asid_id:
        kpqi = ENTITY_KEY_MAPPING[key_perspective_str]
        payload_value = revenue_source_name
        text_value = revenue_source_name
        text_operator = "equal"
        payload_operator = 0
    else:
        # Fall back to Company Name includes
        # TODO: how to handle for other perspectives
        kpqi = 275884  # Company name
        payload_value = entity_name
        text_value = entity_name
        text_operator = "includes"
        payload_operator = 9
    default_payload_dict = {
        "key": kpqi,
        "value": {
            "value": payload_value,
            "connector": 0,
            "operator": payload_operator,
            "data_type": "nstring",
        },
    }
    default_text_dict = {
        "key": "company name",
        "value": {
            "value": text_value,
            "connector": "and",
            "operator": text_operator,
        },
    }
    default_magnitude_dict = {}
    logger.info("default payload dict %s", default_payload_dict)
    return default_payload_dict, default_text_dict, default_magnitude_dict


class BaseItemParser(abc.ABC):
    def __init__(self, model_name: Optional[str] = "cohere-multi"):
        # self.perspective = perspective
        self.fields_using_entity_search = {
            "company name",
            "company",
            "corporation",
            "entity",
            "entity name",
            "issuer",
            "ratings participants",
            "revenue source identifier",
        }  # TODO: update this for each perspective.
        self.model_name = {"company": "cohere-multi", "securities": "cohere-multi", "revenue_sources": "cohere-multi"}
        self.empty_result = ({}, {}, {})

    @abc.abstractmethod
    def custom_logic_before_field_search(self, key, value_str): ...

    @abc.abstractmethod
    def map_look_values(self, kpqi, value_str, operator_payload, operator_text): ...

    def convert_string_to_numeric(self, input_string):
        split_values = [value.strip().upper() for value in input_string.split(",")]
        numeric_representations = []

        for value in split_values:
            if value in CREDIT_ACTIONS:
                numeric_representations.append(CREDIT_ACTIONS[value])
            else:
                numeric_representations.append(value)
        return ", ".join(numeric_representations)

    def post_process_dataframe_from_field_search(
        self,
        value_str: str,
        value_dict: dict,
        df_result: pd.DataFrame,
        tmp_magnitude_dict: dict,
    ):
        # Verify that key values exist in the DataFrame
        kpqi = df_safe_get(df_result, "KPQI", df_result.index[0])
        text_kpqi = df_safe_get(df_result, "Caption", df_result.index[0])
        if not kpqi or not text_kpqi:
            logger.error(f"Kpqi or text_kpqi is missing. DF result: {df_result.to_dict()}")
            return ({}, {})

        # Checking required fields exist and are valid in the value_dict
        if not (isinstance(value_dict, dict) and "operator" in value_dict):
            logger.error(
                "Value_dict is not a dictionary or missing required fields. Type: {}, value: {value_dict}".format(
                    type(value_dict), value_dict
                )
            )
            return ({}, {})
        connector_text = value_dict.get("connector")
        operator_text = value_dict.get("operator")
        if (
            not connector_text
            or connector_text not in CONNECTOR_MAPPING
            or not operator_text
            or operator_text not in OPERATOR_MAPPING
        ):
            logger.error(
                "Value_dict is missing required fields or it has unsupported values. Connector: {}, Operator: {}, value_dict: {}".format(
                    value_dict.get("connector"), value_dict.get("operator"), value_dict
                )
            )
            return ({}, {})

        connector_payload = CONNECTOR_MAPPING[connector_text]
        operator_payload = OPERATOR_MAPPING[operator_text]
        logger.debug(f"We passed the mapping steps {df_result}")

        if _get_wrapped_value(value_dict) == "view only":
            lookup_value = "view only"
            lookup_value_text = "view only"
            if df_result["Type"].item().strip() in {
                "float",
                "number",
            }:
                tmp_magnitude_dict[text_kpqi] = df_result["Magnitude"].item().strip()
        else:
            if df_result["Codes"].isna().any():
                (
                    lookup_value,
                    lookup_value_text,
                    operator_payload,
                    operator_text,
                ) = self.map_look_values(kpqi, value_str, operator_payload, operator_text)
                if text_kpqi == "S&P Credit Rating Action":
                    lookup_value = self.convert_string_to_numeric(lookup_value)
                logger.debug(
                    f"Here are the mapped results: {lookup_value}, "
                    f"{lookup_value_text}, {operator_payload}, {operator_text}"
                )
            else:  # There are lookup values.
                lookup_value = ",".join(df_result["Codes"].values)
                lookup_value_text = ", ".join(df_result["EnglishValues"].values)
            if kpqi == KPQI.RD_SECTOR.value or kpqi == KPQI.IndustryClassification.value:
                # Map 3-Digit Sector Codes to 7-Digit Sector Codes
                lookup_value = convert_codes(lookup_value)
                # Order the codes
                sorted_codes = sorted(map(int, (code.strip() for code in lookup_value.split(","))))
                lookup_value = ",".join(map(str, sorted_codes))

            is_numerical_field = df_result["Type"].isin(["float", "number"]).any()
            # logger.debug(f"Lookup values are {lookup_value} and {
            # lookup_value_text}.")
            if operator_payload in {23, 24, 29, 30} and is_numerical_field is False:
                logger.error(f"""The filter {text_kpqi} doesn't support ranking.""")
                return self.empty_result
            elif df_result["Type"].str.contains("date").any():
                logger.debug(f"We are in the date, {kpqi}, {lookup_value}, {operator_payload}")
                (
                    lookup_value,
                    operator_payload,
                ) = check_dynamic_time_window(kpqi, lookup_value, operator_payload)
            elif is_numerical_field:
                logger.debug("We are in the number")
                # Check if there is rank condition.
                if operator_payload in {23, 24, 29, 30}:
                    tmp_magnitude_dict[text_kpqi] = " ".join(df_result["Magnitude"].apply(lambda x: x.strip()).unique())
                else:  # Not rank criteria.
                    logger.debug(f"operator payload is {operator_payload}")
                    # Unit scale processing
                    if df_result["Magnitude"].isin(["$000"]).any():
                        magnitude = 1000
                    elif df_result["Magnitude"].isin(["$M"]).any():
                        magnitude = 1000_000
                    else:  # Magnitude is %.
                        magnitude = 1
                    lookup_value = update_unit_scale(lookup_value, magnitude)
                    tmp_magnitude_dict[text_kpqi] = " ".join(df_result["Magnitude"].apply(lambda x: x.strip()).unique())
            logger.debug("We passed the unit scale and date steps")

        display_column = value_dict.get("display_column", False)

        tmp_payload_dict = {
            "key": kpqi,
            "value": {
                "value": lookup_value,
                "connector": connector_payload,
                "operator": operator_payload,
                "display_column": display_column,
                "data_type": " ".join(df_result["Type"].apply(lambda x: x.strip()).unique()),
            },
        }
        tmp_text_dict = {
            "key": text_kpqi,
            "value": {
                "value": lookup_value_text,
                "connector": connector_text,
                "operator": operator_text,
                "display_column": display_column,
            },
        }
        return tmp_payload_dict, tmp_text_dict

    def parse(
        self,
        key: str,
        value: dict,
        perspectives_dict: dict,
        key_perspective_str: str,
        entities: dict,
    ):
        value_str = _get_wrapped_value(value).replace("'", "")
        if not value_str:
            return self.empty_result

        tmp_magnitude_dict = {}
        if key in ("industry", "geography"):
            value_str_list = [item.strip() for item in value_str.split(",")]
        else:
            value_str_list = [value_str]
        df_result = pd.DataFrame()
        for value_str in value_str_list:
            if key in self.fields_using_entity_search and value_str != "view only":
                # Use company entity search and skip vector database.
                return get_default_dict_payload_for_company(
                    entities=entities,
                    key_perspective_str=key_perspective_str,
                )

            # Call special method before vector database
            key, value_str = self.custom_logic_before_field_search(key, value_str)

            if key != value_str and _get_wrapped_value(value) != "view only":
                if key == "industry":
                    input_text = key + ": " + value_str
                elif key == "credit watch outlook":
                    input_text = "CreditWatch/Outlook " + value_str
                elif key in ["credit rating", "last review date", "credit rating date", "credit watch outlook date"]:
                    input_text = key
                else:
                    input_text = key + " " + value_str
            else:
                input_text = key
            logger.debug(f"The input text is {input_text}")
            # TODO: change the vector database to the field_search API in the
            #  future.
            best_match_df = vector_database.field_search(
                input_text,
                key,
                embedding_factory(model_name=self.model_name[key_perspective_str], input_type="search_document"),
                key_perspective_str,
                perspectives_dict[key_perspective_str].kpqi_data,
                top_n=1,  # Get the top one result.
            )
            df_result = pd.concat([df_result, best_match_df])
        df_result = df_result.drop_duplicates().reset_index(drop=True)
        logger.debug(f"The result from vector database for {key} is {df_result}.")
        # TODO: Do we need to raise different exception if the dataframe
        #  is empty? For example, unsupported leverage ratio for company.
        if df_result.empty:
            return self.empty_result

        try:
            if all(item in df_result["QueryItemAlias"].values for item in ["RD_SECTOR", "MI_INDUSTRY_CLASSIFICATION"]):
                tmp_payload_dict_list, tmp_text_dict_list = [], []
                for qia in ["RD_SECTOR", "MI_INDUSTRY_CLASSIFICATION"]:
                    df_result_qia = df_result[df_result["QueryItemAlias"] == qia]
                    (
                        tmp_payload_dict,
                        tmp_text_dict,
                    ) = self.post_process_dataframe_from_field_search(
                        value_str=value_str,
                        value_dict=value,
                        df_result=df_result_qia,
                        tmp_magnitude_dict=tmp_magnitude_dict,
                    )

                    tmp_payload_dict_list.append(tmp_payload_dict)
                    tmp_text_dict_list.append(tmp_text_dict)

                return tmp_payload_dict_list, tmp_text_dict_list, tmp_magnitude_dict
            else:
                (
                    tmp_payload_dict,
                    tmp_text_dict,
                ) = self.post_process_dataframe_from_field_search(
                    value_str=value_str,
                    value_dict=value,
                    df_result=df_result,
                    tmp_magnitude_dict=tmp_magnitude_dict,
                )
                return tmp_payload_dict, tmp_text_dict, tmp_magnitude_dict
        except Exception as err:
            logger.error(
                "Error occured during post processing. Error: {}.\nStacktrace: {}".format(err, traceback.format_exc())
            )
            return {}, {}, {}


def _get_wrapped_value(value_container) -> str:
    """Safely extract value attribute"""
    if isinstance(value_container, Dict):
        return str(safe_get(value_container, ["value"], ""))
    elif isinstance(value_container, List):
        return ", ".join([safe_get(item, ["value"], "") for item in value_container if isinstance(item, Dict)])
    else:
        return str(value_container)
