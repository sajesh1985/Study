import logging
from typing import Dict, Union

from botocore.client import BaseClient
from pydantic import BaseModel

from chatrd.core.vectorstore import OpenSearch
from chatrd.engine.components.query_analyzer.entity_extractor.utils import (
    Companies,
    Entities,
    RevenueSource,
)
from chatrd.engine.components.query_processor.query_retriever.reranker import (
    get_reranked_documents,
)
from chatrd.engine.components.query_processor.query_retriever.uc_retrievers.base import (
    UCRetriever,
)
from chatrd.engine.components.query_processor.query_retriever.uc_retrievers.criteria import (
    CriteriaRetriever,
)
from chatrd.engine.components.query_processor.query_retriever.uc_retrievers.definition import (
    DefinitionRetriever,
)
from chatrd.engine.components.query_processor.query_retriever.utils import (
    add_unstructured_source,
    get_filters_for_research,
)
from chatrd.engine.configuration import Constants, get_config_machinery

config_machinery = get_config_machinery()
logger = logging.getLogger(__name__)


class MacroRetriever(UCRetriever):
    def __init__(self, vector_stores_dict: Dict[str, OpenSearch], reranker_client: BaseClient):
        self.vector_stores_dict = vector_stores_dict
        self.reranker_client = reranker_client
        self.reranker_endpoint_name = config_machinery.get_config_value(
            Constants.SageMaker.SAGEMAKER_RERANKER_ENDPOINT_NAME
        )
        self.top_k_text_research = config_machinery.get_config_value(Constants.GeneralConstants.TOP_K_TEXT_RESEARCH)
        self.top_k_text_research_rerank = config_machinery.get_config_value(
            Constants.GeneralConstants.TOP_K_TEXT_RESEARCH_RERANK
        )

    def retrieve(
        self,
        query: str,
        entities: Entities,
        model_name_for_data_service: str,
        temperature_for_data_service: float,
        uc_type: str,
        sectors: BaseModel,
    ):

        all_documents = []
        all_entities = entities.companies + entities.revenue_sources
        if all_entities:
            for entity in all_entities:
                retrieved_documents = self.vector_db_retrieval(query=query, entity=entity, uc_type=uc_type)
                all_documents.extend(retrieved_documents)

        retrieved_documents = self.vector_db_retrieval(query=query, entity=None, uc_type=uc_type)
        all_documents.extend(retrieved_documents)

        retrieved_documents = get_reranked_documents(
            query=query,
            retrieved_documents=all_documents,
            entity=None,
            reranker_client=self.reranker_client,
            reranker_endpoint_name=self.reranker_endpoint_name,
            reranker_threshold=None,
            top_k_text_chunks=self.top_k_text_research_rerank,
        )
        logger.info(f"Total number of documents: {len(retrieved_documents)}")

        retrieved_documents = add_unstructured_source(retrieved_documents)
        return retrieved_documents

    def vector_db_retrieval(self, query: str, entity: Union[Companies, RevenueSource], uc_type: str):
        query = self.rephrased_query(query, entity)
        if entity:
            filters, relevant_article_ids = get_filters_for_research(
                vector_stores_dict=self.vector_stores_dict, entity=entity, uc_type=uc_type
            )
            if not relevant_article_ids:
                filters = None

        else:
            filters = None
        index_name = "commentary" if entity is None else "research"
        logger.info(f"filter applied for research docs : {filters}")
        retrieved_documents, scores = self.vector_stores_dict[index_name].get_relevant_documents(
            query,
            efficient_filter=filters,
            model_id=config_machinery.get_config_value(Constants.OpenSearch.NEURAL_SEARCH_MODEL_ID),
            search_pipeline=config_machinery.get_config_value(Constants.OpenSearch.HYBRID_SEARCH_SEARCH_PIPELINE_ID),
            top_k_text_chunks=self.top_k_text_research,
        )
        for doc in retrieved_documents:
            if doc.metadata.get("chunk_title") is None:
                doc.metadata["chunk_title"] = ""

        retrieved_documents = get_reranked_documents(
            query=query,
            retrieved_documents=retrieved_documents,
            entity=entity,
            reranker_client=self.reranker_client,
            reranker_endpoint_name=self.reranker_endpoint_name,
            reranker_threshold=None,
            top_k_text_chunks=self.top_k_text_research_rerank,
        )

        retrieved_documents = self.add_additional_metadata_to_documents(
            uc_type=uc_type, user_query=query, entity=entity, documents=retrieved_documents
        )

        return retrieved_documents
