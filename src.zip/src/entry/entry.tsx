import { Suspense } from 'react';
import {
  LoadingIndicator,
  LoaderOverlay,
  LoaderPosition,
  LoaderType,
  NotificationProvider,
} from '@spglobal/react-components';


const DashboardSuspense = () => {
  return (
    <Suspense
      fallback={
        <LoadingIndicator
          type={LoaderType.TOP}
          overlay={LoaderOverlay.BLURRED}
          position={LoaderPosition.FIXED}
        />
      }
    >
      <NotificationProvider>
        
      </NotificationProvider>
    </Suspense>
  );
};

export default DashboardSuspense;
