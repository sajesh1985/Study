import styled from '@emotion/styled';
import { DARK } from '@spglobal/koi-helpers';

export const ModalOverlay = styled.div`
   position:fixed;
   top:25px;
   left:0;
   right:0;
   background:rgba(0,0,0,0.5);
   display:flex;
   align-items:center;
   justify-content:center;
   height:100%;
   .${DARK} & {
      border: 1px solid #3b3b3b;
   }
  
`;

export const ModalContent = styled.div`
   background:white;
   padding:20px 20px 50px 20px;
   border-radius:5px;
   max-width:880px;
   width:100%;
   height:85%;
   overflow-x:hidden;
   .${DARK} & {
      background: #272727;
      border: 1px solid #3b3b3b;
   }

`;

export const Unarchival = styled.div`
   overflow: hidden;
   max-width : 92%;
   display: -webkit-box;
   -webkit-line-clamp: 2;
   -webkit-box-orient: vertical;
   padding-bottom: 1px;
   color: var(--color-text-link);
   font-family: Akkurat;
   font-size: 12px;
   font-style: normal;
   font-weight: 400;
   line-height: 19px;
   text-overflow: ellipsis;
   cursor:pointer;
`;

export const ArchivalCloseButton = styled.button`
      padding: 10px 20px;
      font-size: 16px;
      cursor: pointer;
      float: right;
      margin-right: 5px;
      background-color: #3D6DAC;
      border-radius: var(--size-radius-1);
      font-family: var(--font-family-base);
      font-size: var(--size-font-3);
      color: white;
      border:1px solid var(--color-base-gray-30);
      .${DARK} & {
        background-color: #3D6DAC;
      }

`;




