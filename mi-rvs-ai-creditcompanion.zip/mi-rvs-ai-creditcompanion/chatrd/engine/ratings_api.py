import logging
from typing import Any, Dict, Optional, Tuple

import pandas as pd
from requests import Session

from chatrd.core.contextvar_utils import user_ctx_var
from chatrd.engine.auth_api import AuthAPI
from chatrd.engine.configuration import Constants, ratings_api_ctx

logger = logging.getLogger(__name__)

API_TYPE = "ratings"


class RatingsAPI(AuthAPI):
    def __init__(self):
        super().__init__(api_name="RatingsAPI", api_ctx=ratings_api_ctx)

    def get_company_info(self, mi_id: int) -> Tuple[Any, str, str]:
        """Get company information for a given MI ID."""
        endpoint = self.get_config(Constants.RatingsAPI.RATINGS_API_COMPANY_INFO_ENDPOINT_PATH)
        return self.get_response(endpoint, parameter=mi_id)

    def check_creditmemo(self, mi_id: int, entity_type: str) -> Tuple[Any, str, str]:
        """Check if a credit memo exists for a given MI ID and entity type (Company or Sovereign)."""
        endpoint = self.get_config(Constants.RatingsAPI.RATINGS_API_CREDITMEMO_ENDPOINT_PATH)

        if entity_type.lower() == "company":
            url_entity = "company"
        elif entity_type.lower() == "sovereign":
            url_entity = "country"
        else:
            raise ValueError(f"Invalid type '{entity_type}'. Please provide either 'Company' or 'Sovereign'")
        return self.get_response(endpoint, parameter=f"{mi_id}/-1/-1/{url_entity}")

    def get_sf_tranches(self, instrument_id: int) -> Tuple[pd.DataFrame, str]:
        """Get SF Tranche information for a given instrument ID."""
        endpoint = self.get_config(Constants.RatingsAPI.RATINGS_API_SF_TRANCHE_ENDPOINT_PATH)
        response, url, _ = self.get_response(endpoint, instrument_id)
        return (pd.DataFrame(response), url)

    def get_research_kos_access_info(self, article_id) -> Tuple[Any, str, str]:
        """Get Research KOS access information for a given article ID."""
        endpoint = self.get_config(Constants.RatingsAPI.RATINGS_API_RESEARCH_KOS_ENDPOINT_PATH)

        article_id_str = ",".join(article_id)

        return self.get_response(
            endpoint,
            cookie_auth=True,
            api_method="POST",
            data=article_id_str,
        )

    def get_response(
        self,
        endpoint: str = "",
        parameter: Optional[str] = "",
        api_method: str = "GET",
        data: dict = {},
        cookie_auth: bool = False,
    ) -> Tuple[Any, str, str]:
        """Call the Ratings API to retrieve data and returns a python object from the JSON string."""
        url = self._get_full_url(endpoint, parameter)
        headers = self._get_headers(cookie_authentication=True)
        logger.info(f"Calling RatingsAPI on {self._env.upper()} with the URL: {url}")

        with Session() as session:
            if api_method == "GET":
                response = session.get(url, headers=headers)
            else:
                response = session.post(url, headers=headers, json=data)

            if response.status_code == 200:
                logger.info("Call to Ratings API EndPoint was successful.")
                result = response.json()
            else:
                logger.error(f"Error calling Ratings API: Status code {response.status_code} for url: {url}")
                response.raise_for_status()
        return result, url, API_TYPE

    def _get_full_url(self, endpoint: str, parameter: Optional[str] = "") -> str:
        base_url = self.get_config(Constants.APIServiceURL.BASE_URL)
        ratings_api_url = self.get_config(Constants.APIServiceURL.RATINGS_API_URL_SLUG)
        if not str(endpoint).startswith("/"):
            endpoint = f"/{endpoint}"
        if parameter and not str(parameter).startswith("/"):
            parameter = f"/{parameter}"
        return base_url + ratings_api_url + endpoint + parameter

    def _get_headers(self, cookie_authentication: bool = False) -> Dict[str, str]:
        if cookie_authentication:
            ctx_value: dict = user_ctx_var.get()
            cookie = ctx_value.get("cookie", None)
            if cookie:
                return {
                    "Content-Type": "application/json",
                    "Cookie": cookie,
                }
            else:
                logger.info("No cookie found in context, fetching token from service account")

        return {
            "Content-Type": "application/json",
            "Authorization": self.get_service_token(),
        }
