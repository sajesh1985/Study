import logging
from concurrent.futures import as_completed
from copy import deepcopy
from typing import Dict, List, Union

from botocore.client import BaseClient
from pydantic import BaseModel

from chatrd.core.document import Document, TableDocument
from chatrd.core.llm import LCLLMFactory
from chatrd.core.llm.components.message import AIMessage
from chatrd.core.llm.parsers import OutputParserException, PydanticOutputParser
from chatrd.core.llm.prompt.template import SimplePromptTemplate
from chatrd.core.thread_utils import submit_to_shared_thread_pool
from chatrd.core.vectorstore import OpenSearch
from chatrd.engine.components.query_analyzer.entity_extractor.utils import (
    Companies,
    Entities,
    RevenueSource,
)
from chatrd.engine.components.query_analyzer.utils import EntityType
from chatrd.engine.components.query_processor.query_retriever.data_service_retriever import (
    call_data_service,
)
from chatrd.engine.components.query_processor.query_retriever.reranker import (
    get_reranked_documents,
)
from chatrd.engine.components.query_processor.query_retriever.uc_retrievers.base import (
    UCRetriever,
)
from chatrd.engine.components.query_processor.query_retriever.uc_retrievers.prompt_templates import (
    FINANCIAL_EXAMPLES,
    FINANCIAL_PROMPTS,
    OUTPUT_FORMAT,
)
from chatrd.engine.components.query_processor.query_retriever.uc_retrievers.prompt_templates.financial import (
    FINANCIAL_EXAMPLES,
    FINANCIAL_PROMPTS,
)
from chatrd.engine.components.query_processor.query_retriever.uc_retrievers.utils import (
    RetrieverModel,
    get_date_values,
)
from chatrd.engine.components.query_processor.query_retriever.utils import (
    add_structured_source,
    add_unstructured_source,
    get_filters_for_research,
    get_sorted_docs_by_date,
)
from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.responses import get_default_answer

logger = logging.getLogger(__name__)

config_machinery = get_config_machinery()


class FinancialRetriever(UCRetriever):
    def __init__(self, vector_stores_dict: Dict[str, OpenSearch], reranker_client: BaseClient):
        self.vector_stores_dict = vector_stores_dict
        self.reranker_client = reranker_client
        self.reranker_endpoint_name = config_machinery.get_config_value(
            Constants.SageMaker.SAGEMAKER_RERANKER_ENDPOINT_NAME
        )
        self.top_k_text_research = config_machinery.get_config_value(Constants.GeneralConstants.TOP_K_TEXT_RESEARCH)
        self.top_k_text_research_double_rerank = config_machinery.get_config_value(
            Constants.GeneralConstants.TOP_K_TEXT_RESEARCH_DOUBLE_RERANK
        )
        self.top_k_text_research_recency_bias_final = config_machinery.get_config_value(
            Constants.GeneralConstants.TOP_K_TEXT_RESEARCH_RECENCY_BIAS_FINAL
        )

    def retrieve(
        self,
        query: str,
        entities: Entities,
        model_name_for_tool_classifier: str,
        temperature_for_tool_classfifer: float,
        model_name_for_data_service: str,
        temperature_for_data_service: float,
        sectors: BaseModel,
        original_language: str,
        original_query: str,
        multi_uc_type: bool = False,
    ):
        financial_retriever = self.get_retrieval_path(
            query=query, model_name=model_name_for_tool_classifier, temperature=temperature_for_tool_classfifer
        )
        vector_db_retrieved_documents, data_service_documents = [], []
        futures = {}
        all_entities = entities.companies + entities.revenue_sources
        if True:
            futures = {
                submit_to_shared_thread_pool(
                    self.vector_db_retrieval,
                    query=query,
                    entity=entity,
                    original_language=original_language,
                    financial_retriever=financial_retriever,
                ): entity
                for entity in all_entities
            }
        future_data_service_documents = None
        if entities.companies and entities.companies[0].subsector_code != "SOV" and financial_retriever.summary:
            future_data_service_documents = submit_to_shared_thread_pool(
                call_data_service,
                query=query,
                model_name_for_data_service=model_name_for_data_service,
                entities=entities,
                uc_type="financial",
                sectors=sectors,
                original_language=original_language,
                original_query=original_query,
                multi_uc_type=multi_uc_type,
            )

        for future in as_completed(futures):
            retrieved_documents = future.result()
            vector_db_retrieved_documents.extend(retrieved_documents)

        if future_data_service_documents:
            data_service_documents = future_data_service_documents.result()

        data_service_documents_2 = []
        if multi_uc_type:
            for doc in data_service_documents:
                if isinstance(doc, TableDocument) and len(data_service_documents_2) == 0:
                    new_doc = deepcopy(doc)
                    new_doc.synthesize = True
                    data_service_documents_2.append(new_doc)
        else:
            data_service_documents_2 = data_service_documents

        data_service_documents_2 = add_structured_source(data_service_documents_2)
        vector_db_retrieved_documents = add_unstructured_source(vector_db_retrieved_documents)

        query_documents = self._combine_documents(
            structured_documents=data_service_documents_2, unstructured_documents=vector_db_retrieved_documents
        )
        logger.info(f"Total number of retrieved documents : {len(query_documents)}")
        return query_documents

    def vector_db_retrieval(
        self,
        query: str,
        entity: Union[Companies, RevenueSource],
        original_language: str,
        financial_retriever: BaseModel,
    ):
        query = self.rephrased_query(query, entity)
        filters, relevant_article_ids = get_filters_for_research(
            vector_stores_dict=self.vector_stores_dict,
            entity=entity,
            uc_type="financials" if financial_retriever.forecast else None,
        )

        if not relevant_article_ids:
            return get_default_answer(
                entity=entity, reason="no_relevant_articles", original_language=original_language, query=query
            )

        logger.info(f"filter applied for research docs : {filters}")
        retrieved_documents, scores = self.vector_stores_dict["research"].get_relevant_documents(
            query,
            efficient_filter=filters,
            model_id=config_machinery.get_config_value(Constants.OpenSearch.NEURAL_SEARCH_MODEL_ID),
            search_pipeline=config_machinery.get_config_value(Constants.OpenSearch.HYBRID_SEARCH_SEARCH_PIPELINE_ID),
            top_k_text_chunks=self.top_k_text_research,
        )

        retrieved_documents = get_reranked_documents(
            query=query,
            retrieved_documents=retrieved_documents,
            entity=entity,
            reranker_client=self.reranker_client,
            reranker_endpoint_name=self.reranker_endpoint_name,
            reranker_threshold=(
                None
                if isinstance(entity, RevenueSource)
                else config_machinery.get_config_value(Constants.GeneralConstants.DEFAULT_RERANKER_THRESHOLD)
            ),
            top_k_text_chunks=self.top_k_text_research_double_rerank,
        )
        retrieved_documents = self.add_additional_metadata_to_documents(
            uc_type="financials", user_query=query, entity=entity, documents=retrieved_documents
        )
        retrieved_documents = self._post_process_retrieved_docs(retrieved_documents)
        retrieved_documents = get_sorted_docs_by_date(retrieved_documents, self.top_k_text_research_recency_bias_final)
        if not retrieved_documents:
            return get_default_answer(
                entity=entity, reason="no_relevant_articles", original_language=original_language, query=query
            )
        retrieved_documents_with_tags = []
        entity_name = retrieved_documents[0].metadata.get("aggLegalEntityName", "").partition(";")[0].strip()
        retrieved_documents_with_tags.append(
            Document(
                content=(f"<{entity_name}>"),
            ),
        )
        retrieved_documents_with_tags.extend(retrieved_documents)
        retrieved_documents_with_tags.append(
            Document(
                content=(f"</{entity_name}>"),
            ),
        )
        return retrieved_documents_with_tags

    def _post_process_retrieved_docs(self, retrieved_documents: List[Document]):
        for doc in retrieved_documents:
            doc.content = doc.content.replace(" or Downgrade Triggers", "").replace(" or Upgrade Triggers", "")
        return retrieved_documents

    def _combine_documents(
        self, structured_documents: Union[Document, TableDocument], unstructured_documents: List[Document]
    ) -> Union[List[Document], TableDocument]:
        if structured_documents and unstructured_documents:
            combined_result_document = []
            combined_result_document.extend(structured_documents)
            combined_result_document.extend(unstructured_documents)
            return combined_result_document
        elif structured_documents:
            return structured_documents
        elif unstructured_documents:
            return unstructured_documents
        else:
            return []

    def get_retrieval_path(self, query: str, model_name: str, temperature: float) -> BaseModel:
        llm = LCLLMFactory().get_llm(
            deployment_name_or_model_id=model_name,
            temperature=temperature,
        )
        date_values = get_date_values()
        prompt_template = SimplePromptTemplate(FINANCIAL_PROMPTS)
        prompt = prompt_template.format(
            **{
                "question": query,
                "examples": FINANCIAL_EXAMPLES,
                "current_date": date_values["current_date"],
                "current_quarter": date_values["current_quarter"],
                "current_quarter_range": date_values["current_quarter_range"],
                "output_format": OUTPUT_FORMAT,
            }
        )
        parser = PydanticOutputParser(pydantic_object=RetrieverModel)

        logger.debug(f"Financial's finding retriever's path for LLM : {prompt}")
        response = llm.invoke(prompt)

        if isinstance(response, AIMessage):
            response = response.content

        try:
            parsed_query = parser.parse(response)
            logger.info(f"Parsed Query for Financial retriever path LLM's parsed query : {parsed_query}")
            return parsed_query
        except OutputParserException as e:
            logger.error(f"Validation error at from Financial retriever path's llm extraction {e}.")
            raise e
