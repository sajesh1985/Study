from pydantic import BaseModel


class CreateCompanyTemplateRequest(BaseModel):
    company_name: str
    tile_name: str
    tile_description: str
    template_config_file_name: str


class UpdateCompanyTemplateRequest(BaseModel):
    tile_name: str
    tile_description: str
    template_config_file_name: str