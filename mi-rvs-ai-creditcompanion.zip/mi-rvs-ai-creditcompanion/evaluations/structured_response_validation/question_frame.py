import pandas as pd
import os
from tqdm import tqdm
from xeger import Xeger
from concurrent.futures import ThreadPoolExecutor
from chatrd.core.aws_utils.s3 import load_data_from_s3
from chatrd.engine.configuration import Constants, get_config_machinery

config_machinery = get_config_machinery()

data_path = "s3://chatrd-assets.us-east-1.mi-crs-chatrd-dev/dev/data_service/vectors/company_embedding_data.parquet"
folder_path = "/home/sagemaker-user/creditcompanion/evaluations/data/questioner_input"
file_path = os.path.join(folder_path, "list_questioner.txt")

# Ensure the directory exists
os.makedirs(folder_path, exist_ok=True)


def generate_rating_questions():
    """
    Generates rating-related questions for various sectors and geographies based on predefined templates.

    This function reads company metadata from a Parquet file, extracts relevant data such as sectors, geographies, 
    ratings, and timeframes, and uses these to generate questions based on predefined templates. The questions 
    are written to a text file (`list_questioner.txt`).

    Steps:
    1. Reads metadata from `company_metadata.parquet`.
    2. Extracts sectors, geographies, ratings, and other criteria.
    3. Generates questions in parallel for each sector using the `xeger` library.
    4. Writes the generated questions to a text file.

    Returns:
        None
    """
    xeger_obj = Xeger(limit=10)
    print("Reading company metadata...")
    try:
        df = load_data_from_s3(
                    data_path, role_arn=config_machinery.get_config_value(Constants.Bedrock.BEDROCK_ROLE_ARN)
                )
        country = df[df["QueryItemAlias"] == "SP_GEOGRAPHY"]["EnglishValues"].tolist()
        MI_sector = df[df["QueryItemAlias"] == "SP_INDUSTRY"]["EnglishValues"].tolist()
        rd_sector = df[df["QueryItemAlias"] == "RD_SECTOR"]["EnglishValues"].tolist()
        ratings = [
            "AAA", "AA\\+", "AA", "AA\\-", "A\\+", "A", "A\\-", "BBB\\+",
            "BBB", "BBB\\-", "BB\\+", "BB", "BB\\-", "B\\+", "B", "B\\-",
            "CCC\\+", "CCC", "CCC\\-", "CC", "C", "D", "speculative",
        ]
        ratingaction = ["downgraded", "upgraded", "newly rated", "creditrating actions"]
        geographies = country
        sectors = MI_sector + rd_sector
        timeframe = ["last 2 years", "6 months", "2021"]
        sectors = [x.lower() for x in sectors[:100]]
        geographies_string = "|".join(x.lower() for x in geographies)
        ratings_string = "|".join(x.upper() for x in ratings)
        specificTime_string = "|".join(timeframe)
        ratingaction_string = "|".join(x.lower() for x in ratingaction)
        # sectors_string = "|".join(x.lower() for x in sectors)
    except Exception as e:
        print(f"Error reading parquet file: {e}")
        return

    question1 = f"(Provide me with a list of all|Generate a list of|show me all) (_sector_) companies ((in|within) ({geographies_string}) )?((that have|with) a ({ratings_string}) credit score |with ({ratings_string}) credit rating)?"
    question2 = f"(Provide me with a list of all|Generate a list of|show me all) (_sector_) companies (({ratingaction_string}) in ({specificTime_string}) )?(from ({geographies_string}) )?having rating (greater than|less than) or equal to ({ratings_string})?"
    question3 = f"Show me list of ({ratings_string}) rated (entities |((_sector_) companies ))?(With (negative|positive) outlook in ({geographies_string}) )?(including their EBITDA and Sales or Revenue(Net) (?:for ({specificTime_string})))"
    question4 = f"Give me a list of (companies with a (negative|positive|stable) outlook|companies with a ({ratings_string}) rating|(_sector_) companies|companies in ({geographies_string}))"
    question5 = f"Identify ({ratings_string}) (_sector_) with a (negative|positive) outlook ?( and the country they're based in ({geographies_string}))"

    question_template = f"{question1}|{question2}|{question3}|{question4}|{question5}"
      
    def generate_question(sector):
        """
        Generates a question for a specific sector using the predefined question template.

        Args:
            sector (str): The sector for which the question is to be generated.

        Returns:
            str: The generated question, or None if an error occurs.
        """
        try:
            return xeger_obj.xeger(question_template.replace("_sector_", sector))
        except Exception as e:
            print(f"Error generating question for sector {sector}: {e}")
            return None
    
    print("Generating questions in parallel...")
    with ThreadPoolExecutor() as executor:
        rating_qns = list(tqdm(executor.map(generate_question, sectors), total=len(sectors), desc="Processing"))

    print("Writing to list_question.txt...")
    with open(file_path, "w") as f:
        for qns in rating_qns:
            if qns:  # Skip None values
                f.write(f"{qns}\n")
    print("Completed...")


def main():
    """
    Main function to execute the script.

    This function calls `generate_rating_questions` to generate and save rating-related questions.
    """
    generate_rating_questions()


if __name__ == "__main__":
    main()
