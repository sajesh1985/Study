const DoubleStarsIcon = (props:any) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="12" height="13" viewBox="0 0 12 13" fill="none">
    <path
      fillRule="evenodd"
      clipRule="evenodd"
      d="M5.6377 5.89795L7.22828 2.7168L8.81886 5.89795L12 7.48853L8.81886 9.07911L7.22828 12.2603L5.6377 9.07911L2.45654 7.48853L5.6377 5.89795Z"
      fill={props.fill}
    />
    <path
      fillRule="evenodd"
      clipRule="evenodd"
      d="M1.4494 2.18915L2.1741 0.739746L2.8988 2.18915L4.34821 2.91385L2.8988 3.63855L2.1741 5.08795L1.4494 3.63855L0 2.91385L1.4494 2.18915Z"
      fill={props.fill}
    />
  </svg>
);

export default DoubleStarsIcon;
