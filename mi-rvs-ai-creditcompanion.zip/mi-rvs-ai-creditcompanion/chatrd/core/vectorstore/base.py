from abc import ABC, abstractmethod
from typing import Any


class VectorStore(ABC):
    @abstractmethod
    def add_documents(self) -> Any:
        pass

    @abstractmethod
    def get_relevant_documents(self) -> Any:
        pass

    @abstractmethod
    def delete_documents(self) -> Any:
        pass
