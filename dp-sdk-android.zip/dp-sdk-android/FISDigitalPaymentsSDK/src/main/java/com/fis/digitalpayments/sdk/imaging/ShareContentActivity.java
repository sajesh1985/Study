package com.fis.digitalpayments.sdk.imaging;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.ResultReceiver;
import android.util.Base64;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

// Extending Activity instead of AppCompatActivity for Cordova support
public class ShareContentActivity extends Activity {

    public static final int SHARE_CONTENT_REQUEST_CODE = 1;
    public static final String SHARE_CONTENT_RESULT_RECEIVER_NAME = "SHARE_CONTENT_RESULT_RECEIVER_NAME";
    public static final String SHARE_CONTENT_RESULT_NAME = "SHARE_CONTENT_RESULT_NAME";
    public static final String SHARE_CONTENT_REQUEST_PARAM = "SHARE_CONTENT_REQUEST_PARAM";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getResultReceiver() != null) {
            String imageBase64Content = "";
            Bundle parameters = getIntent().getExtras();
            if (parameters != null && parameters.containsKey(SHARE_CONTENT_REQUEST_PARAM)) {
                imageBase64Content = parameters.getString(SHARE_CONTENT_REQUEST_PARAM);
            }
            saveImage(this, imageBase64Content);
            Uri contentUri = getContentUri(this);

            if (contentUri != null) {
                Intent shareIntent = new Intent();
                shareIntent.setAction(Intent.ACTION_SEND);
                shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); // temp permission for receiving app to read this file
                shareIntent.setDataAndType(contentUri, getContentResolver().getType(contentUri));
                shareIntent.putExtra(Intent.EXTRA_STREAM, contentUri);
                startActivityForResult(Intent.createChooser(shareIntent,"Share"), SHARE_CONTENT_REQUEST_CODE);
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == SHARE_CONTENT_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                ResultReceiver resultReceiver = getResultReceiver();
                Bundle resultData = new Bundle();
                resultData.putString(SHARE_CONTENT_RESULT_NAME, "Success!");
                resultReceiver.send(RESULT_OK, resultData);
            }
        }
        finish();
    }

    private ResultReceiver getResultReceiver() {
        return getIntent().getParcelableExtra(SHARE_CONTENT_RESULT_RECEIVER_NAME);
    }

    private void saveImage(final Context context, final String imageBase64Content){
        byte[] decodedString = Base64.decode(imageBase64Content, Base64.DEFAULT);
        Bitmap bitmap = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);

        try {
            File cachePath = new File(context.getCacheDir(), "images");
            cachePath.mkdirs(); // don't forget to make the directory
            FileOutputStream stream = new FileOutputStream(cachePath + "/image.png"); // overwrites this image every time
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
            stream.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private Uri getContentUri(final Context context){
        File imagePath = new File(context.getCacheDir(), "images");
        File newFile = new File(imagePath, "image.png");
        return FileProvider.getUriForFile(context, "com.fis.digitalpayments.sdk.fileprovider", newFile);
    }
}
