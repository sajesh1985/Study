import React, { MutableRefObject } from 'react';
import { faThumbsUp, faThumbsDown, faClone } from '@fortawesome/free-solid-svg-icons';
import { Purpose } from '@spglobal/koi-helpers';

import { Feedback, Interaction, Sentiment } from '../../../types/interaction';
import { useChatRD } from '../../../context/chatrd';
import { interactionFeedback } from '../../../services/api';
import { FeedbackModal } from '../../../components/FeedbackModal/FeedbackModal';
import { CurrentUserAvatar } from './CurrentUserAvatar';
import {
  FeedbackContainer,
  Item,
  Avatar,
  Body,
  FeedbackIcon,
  QuestionBody,
  Dot,
  ChatResponseContent,
  ChatResponseContentDefault
} from './ChatMessage.styles';
import { H5, Tooltip, TooltipPlacement } from '@spglobal/react-components';
import { GridExport, KnowledgeDiscoveryDocuments, KnowledgeDiscoveryResponseNode, PayloadDetails, TableResponseNode, TextResponseNode } from '@root/types/api';
import { ResponseView } from '../../../components/_common/ResponseView/ResponseView';
import { DocumentListStream } from '../../../components/_common/KnowledgeDiscoveryView/KnowledgeDiscoveryView.styles';
import { RESEARCH_MAPPING } from '../../../constants/constants';
import moment from 'moment';
import { getLocalizedDate } from '../../../utils/dateLocalization';
import { useUserTraits } from '@spglobal/userprofileservice';
import { isStreamingEnabled } from '../../../utils/urlUtilities';
import SuggestionBar from '../../../components/_common/Suggestion/Suggestion';

interface ChatMessageProps {
  interaction: Interaction;
  clicked?: (...args: any) => void;
}

export const ChatMessage: React.FC<ChatMessageProps> = ({ interaction,clicked }) => {
  const { updateInteraction,session,copyToClipBoard,chatHistory,payLoad,setPayloadDetails } = useChatRD();
  let isStreamEnabled = isStreamingEnabled();
  const userInformation = useUserTraits(['keyOnlineUser','timeZoneAbbreviation', 'culture', 'mSTimeZoneID']);
  
  const { id,date,interactionId, req,responseBody, res, loading, feedback, feedbackEnabled,responseTimestamp } = interaction;
  const respBody = loading ? <Dot /> : res;
  const responseRef = React.useRef<HTMLDivElement>(null);
  const sendFeedback = async (feedback: Feedback) => {
    updateInteraction(id || interactionId, { feedback });
    try {
      await interactionFeedback(session,id || interactionId, {
        sentiment: feedback.sentiment,
        text: feedback.text,
        tags: feedback.tags,
      });
    } catch (e) {
      updateInteraction(id || interactionId, {
        feedback: undefined,
      });
    }
  };
  const [isOpen, setIsOpen] = React.useState(false);
  //const [selectedSuggestion, setSelectedSuggestion] = useState<string | null>(null);

  //const suggestions = ["What's the most recent action for Apple?", "What ratings criteria is applied to Exxon?", "Show me the latest S&P Research on Aerospace"];

  const handleSelect = (suggestion: string) => {
        clicked(suggestion);
        //setSelectedSuggestion(suggestion);
  };

  

  const [copyText, setCopyText] = React.useState<string>('Copy Response');
  let temp:KnowledgeDiscoveryDocuments[]=[];
  let tempSugg : string[]=[];
  const copyDivToClipboard = (ref: MutableRefObject<HTMLDivElement>,interactionId:string) => {
    window.getSelection()?.removeAllRanges(); 
    const fragment = document.createDocumentFragment();
    if (ref.current) {
      ref.current.childNodes.forEach((node:any) =>{
          if(node.tagName == "DIV") 
          {
            if(node.className !== "")
              {
                fragment.appendChild(node.cloneNode(true));
              }
              else
              {
                let gridAPI:GridExport = copyToClipBoard(id!=='' ? id:interactionId);
                let headers:any[] =[];
                if(gridAPI)
                  {
                    const table=document.createElement('table');
                    table.style.fontSize = '9px';
                    table.border = '1';
                    const thead= document.createElement('thead');
                    const headerRow = document.createElement('tr');
                    headers = Object.keys(gridAPI.rowData[0]).filter(x=>!(x == 'itemName' || x == 'sort_Order' || x == 'csD_SubSector' || x == 'definition'));
                    headers.forEach(headerText =>{
                      const th=document.createElement('th');
                      th.textContent =  headerText[0].toUpperCase() + headerText.substring(1);
                      
                      headerRow.appendChild(th);
                    });
                    thead.appendChild(headerRow);
                    table.appendChild(thead);
          
                    const tbody = document.createElement('tbody');
                    gridAPI.rowData.forEach(rowData =>{
                      const tr=document.createElement('tr');
                      headers.forEach(header =>{
                        const td=document.createElement('td');
                        if(rowData[header] != null && rowData[header].toString().includes('<a '))
                        {
                          td.textContent = rowData[header].toString().split('>')[1].split('<')[0];
                        }
                        else
                        {
                          let txtCont = rowData[header];
                          td.textContent = txtCont && txtCont.replace('&nbsp;',' ');
                        }
                        tr.appendChild(td);
                      });
                      tbody.appendChild(tr); 
                    });
                    table.appendChild(tbody);
                    fragment.appendChild(table);
                  }
              }
            
          }
          else
          {
            fragment.appendChild(node.cloneNode(true));
          }
        
      });

      const tempDiv = document.createElement('div');
      tempDiv.appendChild(fragment);
      document.body.appendChild(tempDiv);
      const range = document.createRange();
      range.selectNodeContents(tempDiv);

      window.getSelection()?.removeAllRanges(); // clear current selection
      window.getSelection()?.addRange(range);
      document.execCommand('copy');
      window.getSelection().removeAllRanges(); // to deselect
          document.body.removeChild(tempDiv);
      setCopyText('Copied!');
      setTimeout(() => setCopyText('Copy Response'), 1000);
    }
  };
  return (
    <>
     {interaction.req &&(
      <Item>
        <CurrentUserAvatar />
        <QuestionBody>
          <span dangerouslySetInnerHTML={{ __html: req }}></span>
        </QuestionBody>
        <div className='date'><span>{date}</span></div>
      </Item>
       )}
       {((!interaction.req && isStreamEnabled) || !isStreamEnabled || interaction.feedbackEnabled == false || chatHistory == 'History'|| interaction.type=="his")&& (
      <Item>
        <div>
          <Avatar src={require('../../../assets/images/chatRDAI.svg')}/>
        </div>
        <Body>
          {(isStreamEnabled && !(chatHistory == 'History' || interaction.type == "his") && 
              (feedbackEnabled == false || feedbackEnabled==undefined)) && (<ChatResponseContent ref={responseRef}>{respBody}</ChatResponseContent>)
          }
          {(isStreamEnabled && !(chatHistory == 'History' || interaction.type == "his") && 
              feedbackEnabled == true) && <></>
          }
          {(isStreamEnabled && (chatHistory == 'History' || interaction.type == "his") && 
              feedbackEnabled == true) && (<ChatResponseContentDefault ref={responseRef}>{respBody}</ChatResponseContentDefault>)
          }
          {feedbackEnabled && (
            <FeedbackContainer>
              <Tooltip
                close={false}
                placement={TooltipPlacement.LEFT}
                triggerElement={
                  <FeedbackIcon className="initial" icon={faClone} purpose={Purpose.NONE} />
                }
                onTriggerClick={() => copyDivToClipboard(responseRef,interactionId)}
                width={'auto'}
                contentPadding={5}
              >
                {copyText}
              </Tooltip>

              {!feedback?.sentiment && (
                <>
                  <FeedbackIcon
                    className="initial"
                    icon={faThumbsUp}
                    onClick={() =>
                      sendFeedback({ sentiment: Sentiment.Positive, text: '', tags: [] })
                    }
                  />
                  <FeedbackIcon
                    className="initial"
                    icon={faThumbsDown}
                    onClick={() => setIsOpen(true)}
                  />
                </>
              )}
              {feedback?.sentiment == Sentiment.Positive && (
                <FeedbackIcon
                  className="setUp"
                  icon={faThumbsUp}
                  purpose={Purpose.NONE}
                  color={'var(--color-text-link)'}
                />
              )}
              {feedback?.sentiment == Sentiment.Negative && (
                <FeedbackIcon
                  className="setUp"
                  icon={faThumbsDown}
                  purpose={Purpose.NONE}
                  color={'var(--color-text-link)'}
                />
              )}
            </FeedbackContainer>
          )}
          {feedbackEnabled == true && <FeedbackModal isOpen={isOpen} onClose={() => setIsOpen(false)} interactionId={id !=='' ? id:interactionId} />}
          { isStreamEnabled && chatHistory !== 'History' && interaction.type == 'user' &&  
            interactionId && interactionId !== '' && 
            (<ChatResponseContentDefault ref={responseRef}>
            {responseBody && <ResponseView data={responseBody} interactionId={interactionId} interactionType={interaction.type}/>
            }
            {feedbackEnabled == true && responseTimestamp &&
              <div className="responseDate" style={{display:'flex',marginLeft:'auto',marginRight:'-51px'}}>
              <span>{getLocalizedDate(
              responseTimestamp,
              true,
              userInformation.culture,
              userInformation.mSTimeZoneID
                )}</span>
              </div>
            }
            { responseBody &&
              responseBody.map((value: TextResponseNode | TableResponseNode | KnowledgeDiscoveryResponseNode)=>{
                if(value?.documents!=null && value?.documents.length > 0)
                  for(var k=0;k<value?.documents.length;k++)
                  {
                    if(value?.type == 'Text' && value?.documents[0].details && value?.documents[0].details !== "null"){
                      let payLoadLocal: PayloadDetails = { interactionId: '', payload: '' };
                      let payLoadDetails: PayloadDetails[] = [];
                      payLoadLocal.interactionId = interactionId;
                      payLoadLocal.payload = value?.documents[0].details;
                      
                      if(payLoad && payLoad.length == 0)
                      {
                        payLoadDetails.push(payLoadLocal);
                        setPayloadDetails(payLoadDetails);
                      }
                      else
                      {
                        let pay = payLoad.find(x=>x.interactionId == interactionId)
                        if(!pay)
                        {
                          payLoad.push(payLoadLocal);
                          setPayloadDetails(payLoad);
                        }
                      }
                    }
                    if(value.documents[k].title)
                      {
                        temp.push(value.documents[k]);
                      }
                  }
                  if(value?.suggestedPrompts !=null && value?.suggestedPrompts.length > 0)
                  {
                    for(var i=0;i<value?.suggestedPrompts.length;i++)
                    {
                      
                          if(value?.suggestedPrompts[i].text)
                          {
                            tempSugg.push(value?.suggestedPrompts[i].text);
                          }
                    }
                  }
                  
              })
            }

            { tempSugg.length > 0 &&
              <SuggestionBar suggestions={tempSugg} onSelect={handleSelect} />
            }

            {temp.length > 0 && 
            
            <ul style={{listStyleType: 'none'}}>
            <H5 style={{marginLeft: '-40px',paddingBottom: '6px'}}>Sources:</H5> 
            { 
              
              temp.length && temp.map((doc:KnowledgeDiscoveryDocuments,index:any)=>(
                <div>
                <span style={{fontSize:'13px',paddingRight:'2px',fontWeight:'500'}}>{index + 1}.</span>
                <DocumentListStream>
                <a href={doc.url} target="_blank">{doc.title}</a>
                <span>{doc.date !=null ? " " + RESEARCH_MAPPING[doc.type as keyof typeof RESEARCH_MAPPING] + " published " + moment(doc.date).format('MMMM Do, YYYY') :''}</span>
              </DocumentListStream>
              </div>
              )
              
            )
             
            }
            </ul>
            }
            </ChatResponseContentDefault>)
          }
          {(!isStreamEnabled && ((chatHistory == 'History' || interaction.type == "his") && 
              feedbackEnabled == true)) && (<ChatResponseContentDefault ref={responseRef}>{respBody}</ChatResponseContentDefault> )}
	            
          {(!isStreamEnabled && !((chatHistory == 'History' || interaction.type == "his") && 
              feedbackEnabled == true)) && (<ChatResponseContentDefault ref={responseRef}>{respBody}</ChatResponseContentDefault>)
          }

          {(!isStreamEnabled && feedbackEnabled == false && loading == false) && (<ChatResponseContentDefault ref={responseRef}>{respBody}</ChatResponseContentDefault>)
          }
        </Body>
      </Item>
       )}
    </>
  );
};
