import logging
from typing import TypedDict, List, Optional
import httpx
from src.synthia.config.api_config import get_config
from src.synthia.utils.logging_config import configure_logging

logger = configure_logging(
    log_file="synthia.log",
    module_levels={__name__: logging.DEBUG},  # Set this module to DEBUG
)

class UserProfileData(TypedDict):
    """TypedDict for user profile data from Capital IQ API."""

    KeyOnlineUser: int
    Email: str
    KeyOnlineServices: List[int]


async def fetch_user_profile_data(auth_token: str) -> UserProfileData:
    """
    Fetch user profile data from Capital IQ API.

    Returns:
        UserProfileData: A dictionary containing user profile information.

    Raises:
        httpx.HTTPError: If the API request fails.
        KeyError: If expected data structure is not found.
        ValueError: If data doesn't match expected format.
    """
    config = get_config()
    url = config["capitaliq_kou_url"]

    # Use timeout and connection pooling for better performance
    async with httpx.AsyncClient(timeout=30.0) as client:
        response = await client.get(
            url + ",KeyOnlineServices", headers={"Authorization": f"{auth_token}"}
        )
        response.raise_for_status()
        data = response.json()

    # Get user data efficiently
    user_data = data.get("value", data)

    # Validate and extract in one pass - avoid extra dictionary creation
    try:
        return UserProfileData(
            KeyOnlineUser=user_data["KeyOnlineUser"],
            Email=user_data["Email"],
            KeyOnlineServices=user_data["KeyOnlineServices"],
        )
    except KeyError as e:
        raise ValueError(f"Missing required field: {e.args[0]}") from e
