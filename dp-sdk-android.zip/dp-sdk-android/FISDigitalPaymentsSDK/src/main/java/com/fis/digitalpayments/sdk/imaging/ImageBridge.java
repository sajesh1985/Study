// Copyright Notice!
// This document is protected under the trade secret and copyright
// laws as the property of Fidelity National Information Services, Inc.
// Copying, reproduction or distribution should be limited and only to
// employees with a “need to know” to do their job.
// Any disclosure of this document to third parties is strictly prohibited.
// © 2016 Fidelity National Information Services.
// All rights reserved worldwide.

package com.fis.digitalpayments.sdk.imaging;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.ResultReceiver;

import com.fis.digitalpayments.sdk.core.Bridge;
import com.fis.digitalpayments.sdk.core.BridgeException;
import com.fis.digitalpayments.sdk.core.BridgeMessage;
import com.fis.digitalpayments.sdk.core.BridgeRequest;
import com.fis.digitalpayments.sdk.core.BridgeRequestCallback;
import com.fis.digitalpayments.sdk.core.BridgeResponse;
import com.fis.digitalpayments.sdk.core.BridgeMessageCode;
import com.fis.digitalpayments.sdk.core.RestrictedOperation;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * @author e1035413 on 2/21/2017.
 */

public class ImageBridge extends Bridge {

    public ImageBridge() {
        super();
    }

    @Override
    public String getBridgeId() {
        return "deviceImageBridge";
    }

    @Override
    public void handleRequest(final BridgeRequest bridgeRequest, final BridgeRequestCallback bridgeRequestCallback, final Context context) {
        final Bridge bridge = this;
        switch (bridgeRequest.getMethod()) {
            case "getImage":
                RestrictedOperation restrictedOperation = new RestrictedOperation(bridgeRequest, bridgeRequestCallback) {
                    @Override
                    public void onPermissionGranted() {
                        handleCameraPermission(bridgeRequest, bridgeRequestCallback, context);
                    }
                };
                    executeWithPermission(Manifest.permission.CAMERA, restrictedOperation, context,true);
                    break;
            case "selectImage":
                RestrictedOperation restrictedImageOperation = new RestrictedOperation(bridgeRequest, bridgeRequestCallback) {
                    @Override
                    public void onPermissionGranted() {
                        selectImage(bridgeRequest, bridgeRequestCallback, context);
                    }
                };
                executeWithPermission(Manifest.permission.READ_EXTERNAL_STORAGE, restrictedImageOperation, context,true);
                break;
            case "shareImage":
                String shareContentParam = bridgeRequest.getParams().get("shareContent");
                Intent shareIntent = new Intent(context, ShareContentActivity.class);
                shareIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                shareIntent.putExtra(ShareContentActivity.SHARE_CONTENT_REQUEST_PARAM, shareContentParam);
                shareIntent.putExtra(ShareContentActivity.SHARE_CONTENT_RESULT_RECEIVER_NAME, new ResultReceiver(new Handler()) {
                    @Override
                    protected void onReceiveResult(int resultCode, final Bundle resultData) {
                        createShareContentResponse(bridgeRequest, bridgeRequestCallback, context);
                    }
                });
                context.startActivity(shareIntent);
                break;
            case "printImage":
                String printContentParam = bridgeRequest.getParams().get("printContent");
                Intent printIntent = new Intent(context, PrintContentActivity.class);
                printIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                printIntent.putExtra(PrintContentActivity.PRINT_CONTENT_REQUEST_PARAM, printContentParam);
                printIntent.putExtra(PrintContentActivity.PRINT_CONTENT_RESULT_RECEIVER_NAME, new ResultReceiver(new Handler()) {
                    @Override
                    protected void onReceiveResult(int resultCode, final Bundle resultData) {
                        createPrintContentResponse(bridgeRequest, bridgeRequestCallback, context);
                    }
                });
                context.startActivity(printIntent);
                break;
        }
    }

    private void createShareContentResponse(final BridgeRequest bridgeRequest, final BridgeRequestCallback bridgeRequestCallback, final Context context) {
        new Thread(new Runnable() {
            @Override
            public void run() {

                BridgeResponse bridgeResponse;
                JSONObject shareContentResult = new JSONObject();
                try {
                    shareContentResult.put("isShared", true);
                    bridgeResponse = new BridgeResponse(bridgeRequest.getCallbackMethod(), shareContentResult, bridgeRequest.getCallbackKey());
                }
                catch (JSONException e)
                {
                    BridgeException bridgeException = new BridgeException("Failed to return json response.", e);
                    BridgeMessage bridgeMessage = BridgeMessage.CreateError(BridgeMessageCode.BRIDGE_EXECUTION_FAILED, bridgeException.getMessage());
                    bridgeResponse = new BridgeResponse(bridgeRequest.getCallbackMethod(), null, null, bridgeRequest.getCallbackKey(), false, bridgeMessage);
                }

                bridgeRequestCallback.onRequestComplete(bridgeResponse);
            }
        }).start();
    }
    private void createPrintContentResponse(final BridgeRequest bridgeRequest, final BridgeRequestCallback bridgeRequestCallback, final Context context) {
        new Thread(new Runnable() {
            @Override
            public void run() {

                BridgeResponse bridgeResponse;
                JSONObject printContentResult = new JSONObject();
                try {
                    printContentResult.put("isPrinted", true);
                    bridgeResponse = new BridgeResponse(bridgeRequest.getCallbackMethod(), printContentResult, bridgeRequest.getCallbackKey());
                }
                catch (JSONException e)
                {
                    BridgeException bridgeException = new BridgeException("Failed to return json response.", e);
                    BridgeMessage bridgeMessage = BridgeMessage.CreateError(BridgeMessageCode.BRIDGE_EXECUTION_FAILED, bridgeException.getMessage());
                    bridgeResponse = new BridgeResponse(bridgeRequest.getCallbackMethod(), null, null, bridgeRequest.getCallbackKey(), false, bridgeMessage);
                }

                bridgeRequestCallback.onRequestComplete(bridgeResponse);
            }
        }).start();
    }

    private void handleCameraPermission(final BridgeRequest bridgeRequest, final BridgeRequestCallback bridgeRequestCallback, final Context context)
    {
        new Thread(new Runnable() {
            @Override
            public void run() {
                BridgeResponse bridgeResponse;
                JSONObject cameraResult = new JSONObject();
                try {
                    cameraResult.put("isCameraPermissionGranted", true);
                    bridgeResponse = new BridgeResponse(bridgeRequest.getCallbackMethod(), cameraResult, bridgeRequest.getCallbackKey());
                }
                catch (JSONException e)
                {
                    BridgeException bridgeException = new BridgeException("Failed to return json response.", e);
                    BridgeMessage bridgeMessage = BridgeMessage.CreateError(BridgeMessageCode.BRIDGE_EXECUTION_FAILED, bridgeException.getMessage());
                    bridgeResponse = new BridgeResponse(bridgeRequest.getCallbackMethod(), null,null, bridgeRequest.getCallbackKey(), false, bridgeMessage);
                }
                bridgeRequestCallback.onRequestComplete(bridgeResponse);
            }
        }).start();
    }

    private void selectImage(final BridgeRequest bridgeRequest, final BridgeRequestCallback bridgeRequestCallback, final Context context) {
        Intent intent = new Intent(context, SelectImageActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        final Bridge bridge = this;
        intent.putExtra(SelectImageActivity.IMAGE_RESULT_RECEIVER_NAME, new ResultReceiver(new Handler()) {
            @Override
            protected void onReceiveResult(int resultCode, final Bundle resultData) {
                BridgeResponse bridgeResponse;
                if (resultCode == SelectImageActivity.RESULT_CANCELED) {
                    return;
                }
                if (resultCode == SelectImageActivity.RESULT_OK) {
                    JSONObject imageJson = new JSONObject();
                    try {
                        imageJson.put("base64Image", resultData.getString(SelectImageActivity.BASE64_IMAGE_RESULT_NAME));
                        bridgeResponse = new BridgeResponse(bridgeRequest.getCallbackMethod(), imageJson, bridgeRequest.getCallbackKey());
                    } catch (JSONException e) {
                        BridgeException bridgeException = new BridgeException("Failed to return Base64 image.", e);
                        BridgeMessage bridgeMessage = BridgeMessage.CreateError(BridgeMessageCode.BRIDGE_EXECUTION_FAILED, bridgeException.getMessage());
                        bridgeResponse = new BridgeResponse(bridgeRequest.getCallbackMethod(), null, null, bridgeRequest.getCallbackKey(), false, bridgeMessage);
                    }
                    bridgeRequestCallback.onRequestComplete(bridgeResponse);
                }
            }
        });
        context.startActivity(intent);
    }


}
