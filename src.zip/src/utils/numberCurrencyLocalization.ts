import { CultureConst, minusZero } from '../constants/dateConstants';
import { Cultures, getLanguageLocaleNameForNumbers } from './localization';

export const NullValueText = '';
//const defaultCurrency = 'USD';
const defaultmaxFractionDigits = 2;
const defaultminimumFractionDigits = 2;
//// Function for use format number or currency
//// Params: cultureFormat = Selected culture of User i.e 'en-US'
//// formatType: decimal/currency
//// maxFractionDigits : 2
//// minimumFractionDigits: 2
//// value: actual number or currency
export const getDisplayableNumber = (
  value: number | string,
  culture?: string,
  options?: {
    formatType?: string;
    currency?: string;
    maxFractionDigits?: number;
    minimumFractionDigits?: number;
    nullValueText?: string;
    formatNegative?: boolean;
    isPercentage?: boolean;
    currencySign?: string;
    currencyDisplay?: string;
    useParenthesesFormatting?: boolean;
  }
): string => {
  const updatedCulture = getLanguageLocaleNameForNumbers(culture ?? Cultures.DEFAULT_CULTURE);

    if (value === minusZero) {
        value = 0;
  }
  if (value === undefined || value === null || isNaN(parseFloat(value.toString()))) {
    return options?.nullValueText ?? NullValueText;
  }
  //const num: number = +value;
  const isNeg = isNegative(value.toString());
  const maxFD = options?.maxFractionDigits ?? defaultmaxFractionDigits;
  let minFD = options?.minimumFractionDigits ?? defaultminimumFractionDigits;
  if (minFD > maxFD) {
    minFD = maxFD;
  }
  /*const numberFormat = new Intl.NumberFormat(updatedCulture, {
    style: options?.formatType ?? formatTypes.decimalNumber,
    currency: options?.currency ?? defaultCurrency,
    maximumFractionDigits: maxFD,
    minimumFractionDigits: minFD,
    currencySign: options?.currencySign,
    currencyDisplay: options?.currencyDisplay,
  }).format(num);*/

  return formatCurrency(
    value.toString(),
    isNeg,
    updatedCulture,
    options?.formatNegative,
    options?.isPercentage,
    options?.useParenthesesFormatting ?? false
  );
};

//// after Intl Format needs to change format for specific culture like CA and FR, if any same case comes in future we will add here
const formatCurrency = (
  value: string,
  isNeg: boolean,
  culture: string,
  formatNegative?: boolean,
  isPercentage?: boolean,
  useParenthesesFormatting?: boolean
): string => {
  if (isNeg) {
    if (value[value.length - 1] === CultureConst.euroSign) {
      //// Remove Euro sign
      const strValue = `${replaceAt(value.trim(), value.length - 1, '')}`;
      //// Add ( Euro sign & )
      value = `${replaceAt(strValue.trim(), 0, `(${CultureConst.euroSign}`)})`;

      return value.trim();
    }
    if (culture === CultureConst.cultureCanada) {
      return (value = `${replaceAt(value.trim(), 0, `(${CultureConst.dollarCASign}`)}${')'}`);
    }
    const culturesWithParentheses = [
      CultureConst.cultureAmericas,
      CultureConst.cultureCanada,
      CultureConst.cultureHongKong,
      CultureConst.cultureIndonesia,
      CultureConst.culturePhiliphines,
      CultureConst.cultureSingapore,
    ];
    if (isPercentage === true) {
      return formatNegative === true
        ? `${replaceAt(value.trim(), 0, '(')}${'%)'}`
        : `${value.trim()}%`;
    } else {
      if (formatNegative === true) {
        if (useParenthesesFormatting == true) {
          if (culturesWithParentheses.includes(culture)) {
            return `${replaceAt(value.trim(), 0, '(')}${')'}`;
          } else {
            return value.trim();
          }
        } else {
          return `${replaceAt(value.trim(), 0, '(')}${')'}`;
        }
      } else {
        return value.trim();
      }
    }
  } else {
    if (value[value.length - 1] === CultureConst.euroSign) {
      const str = value;
      value = `${CultureConst.euroSign}${str.substring(0, str.length - 1)}`;
      return value.trim();
    }
  }
  return culture === CultureConst.cultureCanada
    ? `${CultureConst.dollarCASign}${value}`
    : isPercentage === true
    ? value + '%'
    : value;
};

const replaceAt = (str: string, index: number, ch: string): string => {
  return str.replace(/./g, (c, i) => (i == index ? ch : c));
};
export const isNegative = (num: string): boolean => {
  if (!isNaN(parseFloat(num)) && Math.sign(parseFloat(num)) === -1) {
    return true;
  }
  return false;
};