import json
from importlib.resources import files
from typing import Optional

from chatrd.core.llm import LCLLMFactory
from chatrd.core.llm.components.message import AIMessage, BaseMessage
from chatrd.engine.components.query_analyzer.guardrail.prompts.templates import (
    MODERATION_PROMPT_TEMPLATE,
)
from chatrd.engine.configuration import Constants, get_config_machinery

config_machinery = get_config_machinery()


class InputModerationGuardrail:
    def __init__(self, model_name: str = Constants.Bedrock.GUARDRAIL_MODEL, temperature: Optional[float] = 0.0):

        self.model_name = model_name

        self.model = LCLLMFactory(
            region_name=config_machinery.get_config_value(Constants.Bedrock.GUARDRAIL_REGION_NAME)
        ).get_llm(
            deployment_name_or_model_id=config_machinery.get_config_value(self.model_name),
            temperature=temperature,
        )

        self.moderation_prompt = self._create_moderation_prompt()

    def run(self, user_input: str):

        query = self._process_user_input_into_moderation_prompt(user_input)

        model_response = self.model.invoke(query)

        if isinstance(model_response, (AIMessage, BaseMessage)):
            model_response = model_response.content

        answer = self._postprocess_model_response_text(model_response)

        return json.loads(answer)

    def _concatenate_blocked_topics(self):

        path = (
            files("chatrd.engine.components.query_analyzer.guardrail.prompts").joinpath("blocked_topics.json").resolve()
        )

        with open(path, "r") as f:
            topics_dict = json.load(f)

        topics = [topics_dict[k] for k in topics_dict.keys()]

        return "\n\n".join(topics)

    def _create_moderation_prompt(self):

        return MODERATION_PROMPT_TEMPLATE.replace("[[blocked_topics]]", self._concatenate_blocked_topics())

    def _process_user_input_into_moderation_prompt(self, user_input):
        return self.moderation_prompt.replace("[[user_question]]", user_input)

    def _postprocess_model_response_text(self, text):
        return text.replace("```json", "").replace("```", "").strip()
