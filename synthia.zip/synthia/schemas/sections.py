# """Schema definitions for section structures in reports."""

# from typing import List, Optional
# from pydantic import BaseModel, Field


# class ReportSection(BaseModel):
#     """Schema for a report section with hierarchical structure."""
    
#     id: Optional[str] = Field(default="", description="Unique identifier for the section")
#     name: str = Field(..., description="Name of the section")
#     description: Optional[str] = Field(default="", description="Description of the section")
#     content: Optional[str] = Field(default="", description="Content of the section")
#     tools: Optional[List[str]] = Field(default_factory=list, description="Tools used in this section")
#     sources: Optional[List[str]] = Field(default_factory=list, description="Sources used in this section")
#     sections: Optional[List['ReportSection']] = Field(default_factory=list, description="List of child sections")
    
#     class Config:
#         """Configuration for ReportSection model."""
#         extra = "forbid"
#         validate_assignment = True
#         json_schema_extra = {
#             "example": {
#                 "id": "intro",
#                 "name": "Introduction",
#                 "description": "This section introduces the topic...",
#                 "content": "Detailed introduction content...",
#                 "tools": ["research_tool"],
#                 "sources": ["source1.pdf"]
#             }
#         }


# class Report(BaseModel):
#     """Schema for a complete report with sections."""
    
#     title: str = Field(..., description="Title of the report")
#     description: Optional[str] = Field(default="", description="Description of the report")
#     sections: List[ReportSection] = Field(default_factory=list, description="List of sections in the report")
    
#     class Config:
#         """Configuration for Report model."""
#         extra = "forbid"
#         validate_assignment = True

# # Enable forward references for nested sections
# ReportSection.model_rebuild()