# !/bin/bash
set -e

/home/sagemaker-user/.conda/envs/chatrd/bin/python evaluations/sector_extractor/generate_data.py \
    --template-entities-path evaluations/data/sector_extraction/template_entities/ \
    --template-questions-path evaluations/data/sector_extraction/template_questions/ \
    --output-path evaluations/data/sector_extraction/generated_data/evaluation_questions.json \
    --num-runs 2
    
/home/sagemaker-user/.conda/envs/chatrd/bin/python evaluations/sector_extractor/run_evaluation.py \
    --input-template-questions-path evaluations/data/sector_extraction/generated_data/evaluation_questions.json \
    --output-path evaluations/sector_extractor/evaluation_results \
    --models-list haiku,sonnet \
    --select-keys sector,subsector,industry \
    --prompt-id v1 \
    --class-id sector \
    --samples_per_class -1
