GEOGRAPHY_EXTRACTION_PROMPT = """USER QUESTION is mentioning one or more geography.
The USER QUESTION may mention other attributes, but you should only extract the geography names.
The geography names can be countries, regions, continents, or specific locations.
Pay attention the name of geography mentioned in the USER QUESTION and extract the names.
Return the names as a lower case, normalized, comma separated single string value.
Do not make any additional explanations or comments.
If there are multiple names of geography, they should be separated by commas.
If the name of geography is mentioned in USER QUESTION between quotation marks (e.g., "United States", "Europe", "Asia-Pacific"), you MUST extract the it as a single name without any modification.
If there is no special geography mentioned in the USER QUESTION, return an empty string.

Here are some examples of how to extract geography names from the question:
{geography_extraction_examples}

USER QUESTION: {user_question}"""

GEOGRAPHY_EXTRACTION_EXAMPLES = [
    ("What are the companies located in US and Canada?", "united states, canada"),
    (
        "Give me the firms in 'United States and Canada'",
        "united states, canada",
        "The geography names in quotation marks ('') should be treated as a single, exact geography name.",
        "united states and canada",
    ),
    ("Provide a list of entities in UK.", "united kingdom"),
    ("List the top ten companies in europe and middle east.", "europe, middle east"),
    ("What are the corporates in 'Asia-Pacific'?", "asia-pacific"),
    ("What are the banking companies in asia?", "asia"),
    ("Give me all the companies in latin america and caribbean.", "latin america, caribbean"),
    (
        "Provide me a list of companies defaulted in last year",
        "AI: ",
        "The question is not mentioning any geography. The answer should be an empty string.",
        "",
    ),
    (
        "What are the chemical companies with their geography?",
        "AI: ",
        """You must return empty string thus there is no specific geography mentioned in the question. 
     Do not add anything else like 'AI: '.""",
        "",
    ),
]
