import pytest

from chatrd.engine.data_service import utils
from chatrd.engine.data_service.perspectives import default_perspectives


@pytest.fixture()
def get_default_perspectives_and_entities():
    return default_perspectives(vectors_path=None)


def test_convert_response_to_dict_for_screener():
    test_response = """{"type": "company", "private company": {"value": "\'private company\'", "connector": "and", "operator": "in" }, "germany": {"value": "\'germany\'", "connector": "and", "operator": "in" }, "status": {"value": "\'ongoing\'", "connector": "and", "operator": "in" },}"""

    result = utils.convert_response_to_dict_for_screener(test_response)
    expected_result = {
        "type": "company",
        "private company": {
            "value": "'private company'",
            "connector": "and",
            "operator": "in",
        },
        "germany": {"value": "'germany'", "connector": "and", "operator": "in"},
        "status": {"value": "'ongoing'", "connector": "and", "operator": "in"},
    }

    assert result == expected_result


# def test_parse_one_item_from_llm_output(get_default_perspectives_and_entities):
#     default_perspectives, default_entities = get_default_perspectives_and_entities
#     perspectives_dict = {p.name: p for p in default_perspectives}
#     key = "security identifier"
#     value = {"value": "459200ld1", "connector": "and", "operator": "equal"}
#     key_perspective_str = "securities"
#
#     (
#         payload_dict,
#         text_dict,
#         magnitude_dict,
#     ) = app_helper.parse_one_item_from_llm_output(
#         key=key,
#         value=value,
#         perspectives_dict=perspectives_dict,
#         key_perspective_str=key_perspective_str,
#         entities=default_entities,
#     )
#
#     expected_payload_dict = {
#         "key": 321280,
#         "value": {
#             "value": "459200ld1",
#             "connector": 0,
#             "operator": 0,
#             "data_type": "string",
#         },
#     }
#     expected_text_dict = {
#         "key": "CUSIP",
#         "value": {"value": "459200ld1", "connector": "and", "operator": "equal"},
#     }
#
#     assert payload_dict == expected_payload_dict
#     assert text_dict == expected_text_dict
#     assert magnitude_dict == {}
