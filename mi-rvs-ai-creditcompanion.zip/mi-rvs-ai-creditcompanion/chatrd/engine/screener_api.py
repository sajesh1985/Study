import json
import logging
from typing import Dict

import numpy as np
from requests import Session

from chatrd.core.contextvar_utils import user_ctx_var
from chatrd.engine.auth_api import AuthAPI
from chatrd.engine.configuration import Constants, screener_api_ctx

logger = logging.getLogger(__name__)


class NpEncoder(json.JSONEncoder):
    """This class is to handle errors when converting payload to JSON.
    https://stackoverflow.com/a/57915246"""

    def default(self, obj):
        if isinstance(obj, np.integer):
            return int(obj)
        if isinstance(obj, np.floating):
            return float(obj)
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        return super(NpEncoder, self).default(obj)


class ScreenerAPI(AuthAPI):
    def __init__(self):
        super().__init__(api_name="ScreenerAPI", api_ctx=screener_api_ctx)

    def get_results_from_screener_api(self, payload: dict):
        """Get results from the SNL Data Service API."""
        url = self.get_url()
        logger.debug(f"Start calling screener endpoint with the payload {payload}")
        try:
            response = self._call_screener_api(url=url, payload=payload)
            response_data = response.json()  # Avoid redundant calls to `response.json()`
            response_exception = response_data["functionResponses"][0].get("responseException")
            if response_exception is None:
                return response, url
            else:
                error_message = f"Screener API returned an error: {response_exception}"
                logger.error(error_message)
                raise RuntimeError(error_message)  # Use a more specific exception type
        except KeyError as e:
            error_message = "The response structure from Screener API is invalid"
            logger.error(f"{error_message}: {e}")
            raise ValueError(error_message) from e
        except Exception as e:
            logger.error(f"An error occurred while calling the Screener API: {e}")
            raise

    def get_url(self):
        base_url = self.get_config(Constants.APIServiceURL.BASE_URL)
        search_api_url = self.get_config(Constants.APIServiceURL.SCREENER_API_URL_SLUG)
        return base_url + search_api_url

    def _get_headers(self, cookie_authentication: bool = False) -> Dict[str, str]:
        if cookie_authentication:
            ctx_value: dict = user_ctx_var.get()
            auth_token = ctx_value.get("auth_token", None)
            if auth_token:
                logger.info("Using auth token from user")
                return {
                    "Content-Type": "application/json",
                    "Authorization": auth_token,
                    "Accept": "application/json",
                }
            else:
                logger.info("No auth_token found in context, fetching token from service account")

        return {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Authorization": self.get_service_token(),
            "Cookie": "SNLSite=Cloud; SNLStack=STACK1; SNLServer_www=AV1SOADATD838",
        }

    def _call_screener_api(self, url: str, payload: Dict) -> str:
        """Call the Data Service API to retrieve data.
        Args:
            url (str): The URL of the Data Service.
            payload (Dict): Payload details.

        Returns: The output from the Data Service Endpoint as JSON string.
        """

        headers = self._get_headers(cookie_authentication=True)

        logger.info(f"Calling ScreenerAPI on {self._env.upper()} with the URL: {url}")
        try:
            with Session() as s:
                response = s.post(url, headers=headers, data=json.dumps(payload, cls=NpEncoder))
            if response.status_code == 200:
                logger.debug("Received response from screener")
                logger.debug(f"the response json file is {response.json()}")
            else:
                logger.error(
                    f"Some error occurred with querying on screener api with status code : {response.status_code}"
                )
                response.raise_for_status()
        except Exception as e:
            logger.error(f"Error happened to the data service API call: {e}")

        return response
