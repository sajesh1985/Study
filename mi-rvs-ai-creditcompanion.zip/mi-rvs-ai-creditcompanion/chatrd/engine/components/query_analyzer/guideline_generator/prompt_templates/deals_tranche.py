DEALS_TRANCHE_GUIDELINES_EXAMPLES = """
{
    "question": What are the active deals for xyz?",
    "guidelines": "1. Write a summary that will overview all of the keypoints. Format the summary part strictly as a single paragraph with no header and start with 'S&P Global Rating's research '. Summary MUST contain the dates, ratings, conclusions and insights.\n2. You should only use information in the reports to answer the query.\n3. Only return summary as paragraphs, DO NOT write any title and bulletpoints. Do not start the answer with a bold header or title, start directly with summary content with 'S&P Global Rating's research ' in the beginning."
}
__________________
{
    "question": "How many active deals are there for xyz?",
    "guidelines": "1. Write a summary that will overview all of the keypoints. Format the summary part strictly as a single paragraph with no header and start with 'S&P Global Rating's research '. Summary MUST contain the dates, ratings, conclusions and insights.\n2. You should only use information in the reports to answer the query.\n3. You CAN NOT know the number of deals or active deals, so DO NOT mention anything about the number of deals. Only generate summary of the information in the reports.\n4. Only return summary as paragraphs, DO NOT write any title and bulletpoints. Do NOT start the answer with a bold header or title, start directly with summary paragraph with 'S&P Global Rating's research ' in the beginning."
}
__________________
{
    "question": "What are the deals of xyz?",
    "guidelines": "1. Write a summary that will overview all of the keypoints. Format the summary part strictly as a single paragraph with no header and start with 'S&P Global Rating's research '. Summary MUST contain the dates, ratings, conclusions and insights.\n2. You should only use information in the reports to answer the query.\n3. You CAN NOT know the number of deals or active deals, so DO NOT mention anything about the number of deals. Only generate summary of the information in the reports.\n4. Only return summary as paragraphs, DO NOT write any title and bulletpoints. Do NOT start the answer with a bold header or title, start directly with summary paragraph with 'S&P Global Rating's research ' in the beginning."
}
__________________
{
    "question": "What is the recent activity for xyz?",
    "guidelines": "1. Write a summary that will overview all of the keypoints. Format the summary part strictly as a single paragraph with no header and start with 'S&P Global Rating's research '. Summary MUST contain the dates, ratings, conclusions and insights.\n2. You should only use information in the reports to answer the query.\n3. Only return summary as paragraphs, DO NOT write any title and bulletpoints. Do not start the answer with a bold header or title, start directly with summary content with 'S&P Global Rating's research ' in the beginning."
}
__________________
{
    "question": "Summary/updates about xyz?",
    "guidelines": "1. Write a summary that will overview all of the keypoints. Format the summary part strictly as a single paragraph with no header and start with 'S&P Global Rating's research '. Summary MUST contain the dates, ratings, conclusions and insights.\n2. You should only use information in the reports to answer the query.\n3. Only return summary as paragraphs, DO NOT write any title and bulletpoints. Do not start the answer with a bold header or title, start directly with summary content with 'S&P Global Rating's research ' in the beginning."
}
"""

DEALS_TRANCHE_GUIDELINES_PROMPTS = """
You are an excellent financial credit analyst and you will be given a question from the user.
Your task will be to extract information regarding user question:
* Guidelines highlighting relevant factors when answering the question. (key: guidelines)

Examples pairs of question (key: question) and guidelines (key: guidelines) are given below in JSON format:
<examples>
{examples}
</examples>

Take a deep breath and understand that these examples should not affect the extractions for any other keys.

Answer JSON object which should contain following properties:
* "guidelines"

<question>
{question}
</question>

Just return an guidelines JSON object. Do not say: Here are the guidelines to answer the question "{question}", return the JSON only.
"""

deals_tranche_guidelines = {"prompt": DEALS_TRANCHE_GUIDELINES_PROMPTS, "examples": DEALS_TRANCHE_GUIDELINES_EXAMPLES}
