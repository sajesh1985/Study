// Copyright Notice! 
// This document is protected under the trade secret and copyright 
// laws as the property of Fidelity National Information Services, Inc. 
// Copying, reproduction or distribution should be limited and only to 
// employees with a “need to know” to do their job. 
// Any disclosure of this document to third parties is strictly prohibited.
// © 2018 Fidelity National Information Services.
// All rights reserved worldwide.

namespace Fis.Epp.Fusion.Auth.Controllers
{
    using Fis.Epp.Fusion.Auth.Models;
    using Microsoft.AspNetCore.Mvc;
    using Newtonsoft.Json;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Security.Claims;
    using System.Threading.Tasks;

    /// <summary>Represents controller that host angular ui.</summary>    
    public class FusionAuthControllerBase : Controller
    {
        #region Fields

        protected readonly AppConfiguration configuration;
        private readonly WSO2AccessHandler _wso2AccessHandler;
        private readonly RESTAccessHandler _restAccessHandler;

        #endregion

        #region Ctor

        public FusionAuthControllerBase(
            AppConfiguration appConfigurations,
            WSO2AccessHandler wso2AccessHandler,
            RESTAccessHandler restAccessHandler)
        {
            configuration = appConfigurations;
            _wso2AccessHandler = wso2AccessHandler;
            _restAccessHandler = restAccessHandler;
        }

        #endregion

        #region Protected methods

        /// <summary>Validate JwtAccess Token recieved from SSO.</summary>
        /// <param name="token"></param>
        /// <returns>Whether token is valid or not.</returns>
        protected bool ValidateJwtAccessToken(string token)
        {
            bool isTokenValid = false;
            ClaimsPrincipal claimsPrincipal = new ClaimsPrincipal();
            if (!string.IsNullOrEmpty(token))
            {
                claimsPrincipal = JwtHelper.ValidateSymmetricToken(configuration.TokenSigningKey, token);
            }
            if (claimsPrincipal != null && claimsPrincipal.Claims.Count() > 0)
            {
                isTokenValid = true;
            }
            return isTokenValid;
        }

        /// <summary>Resolve balances from SSO.</summary>
        /// <param name="accountList"></param>
        /// <returns>string of balances.</returns>
        protected string ResolveFundingAccountBalance(List<Claim> accountList)
        {
            string balances = string.Empty;
            balances = "(";
            accountList.ToList().ForEach(x =>
            {
                FABalanceList account = JsonConvert.DeserializeObject<FABalanceList>(x.Value);
                balances += "[" + account.FundingAccountIdentity.FundingAccountId + "]";
                balances += "[" + account.Label + "]";
                balances += "[" + account.Balance.Amount + "]";

                balances += ":";
            });
            balances = balances.Remove(balances.Length - 1, 1) + ")";
            return balances;
        }

        /// <summary>
        /// Resolves the user session based on user data passed and current environment.
        /// </summary>
        /// <param name="userDataModel">User detail</param>
        /// <returns>Boolean value indicating success or failure </returns>
        protected async Task<bool> ResolveUserSession(UserDataModel userDataModel)
        {
            if (!string.IsNullOrEmpty(userDataModel.FeId) && !string.IsNullOrEmpty(userDataModel.UserId))
            {
                FillHttpContextItems(userDataModel);
                WSO2TokenModel wso2Token = new WSO2TokenModel();
                // Fetch access token from WSO2 api manager.
                wso2Token = await _wso2AccessHandler.GetAccessToken();
                userDataModel.AccessToken = wso2Token.Access_Token;
                if (!string.IsNullOrEmpty(userDataModel.AccessToken))
                {
                    int sessionTimeout = userDataModel.SessionTimeout == 0 ? configuration.SessionTimeout : userDataModel.SessionTimeout;
                    Dictionary<string, string> sessionTokenClaims = new Dictionary<string, string>
                    {
                        { JWTEnum.sessionTimeout.GetEnumDescription(), sessionTimeout.ToString() },
                        { JWTEnum.FeId.GetEnumDescription(), userDataModel.FeId.ToString() },
                        { JWTEnum.KeepAliveURL.GetEnumDescription(),userDataModel.KeepAliveURL??string.Empty}
                    };
                    // Generates JWT signout token again with fresh expiry time so as to track timeout.
                    userDataModel.SessionToken = JwtHelper.GenerateSymmetricToken(configuration.TokenSigningKey, sessionTokenClaims, sessionTimeout);
                    if (configuration.EnableDebugAccess && (string.IsNullOrEmpty(userDataModel.ContextToken) || string.IsNullOrEmpty(userDataModel.CorrelationId)))
                    {
                        ContextTokenRequestModel contextTokenRequestModel = new ContextTokenRequestModel
                        {
                            ApplicationId = userDataModel.ApplicationId,
                            Authorization = "Bearer " + userDataModel.AccessToken,
                            Locale = userDataModel.Locale,
                            SourceId = userDataModel.SourceId,
                            UserId = userDataModel.UserId,
                            Uuid = Guid.NewGuid().ToString(),
                            FeId = userDataModel.FeId
                        };

                        ContextTokenModel contextTokenModel = new ContextTokenModel();
                        contextTokenModel = await _restAccessHandler.GetContextToken(contextTokenRequestModel);
                        if (contextTokenModel != null && contextTokenModel.data != null && !string.IsNullOrEmpty(contextTokenModel.data.contextToken))
                        {
                            userDataModel.ContextToken = contextTokenModel.data.contextToken;
                        }

                        var jwtToken = JwtHelper.ReadToken(userDataModel.ContextToken);
                        if (jwtToken != null)
                        {
                            var claim = jwtToken.Claims.SingleOrDefault(x => x.Type == JWTEnum.correlationId.GetEnumDescription());
                            if (claim != null)
                            {
                                userDataModel.CorrelationId = claim.Value;
                            }
                        }
                    }
                    else
                    {
                        AuditSignOnRequestModel auditSignOnDetail = new AuditSignOnRequestModel
                        {
                            IpAddress = HttpContext.Connection.RemoteIpAddress.ToString(),
                            UserHeaderAgent = HttpContext.Request.Headers[RequestHeader.User_Agent.GetEnumDescription()].ToString(),
                            FeId = userDataModel.FeId,
                            UserId = userDataModel.UserId,
                            Uuid = Guid.NewGuid().ToString(),
                            ContextToken = userDataModel.ContextToken,
                            Authorization = "Bearer " + userDataModel.AccessToken,
                            CorrelationId = userDataModel.CorrelationId
                        };
                        return await _restAccessHandler.AuditSignOn(auditSignOnDetail);
                    }
                }
            }
            else
            {
                throw new Exception("Invalid Token");
            }

            return false;
        }
        #endregion

        #region private methods

        private void FillHttpContextItems(UserDataModel userDataModel)
        {
            HttpContext.Items.Add(RequestHeader.Correlation_ID.GetEnumDescription(), userDataModel.CorrelationId ?? string.Empty);
            HttpContext.Items.Add(RequestHeader.USER_ID.GetEnumDescription(), userDataModel.UserId ?? string.Empty);
            HttpContext.Items.Add(RequestHeader.FE_ID.GetEnumDescription(), userDataModel.FeId ?? string.Empty);
        }

        #endregion

        #region Subclasses
        // TODO : object to parse the balances..
        class FABalanceList
        {
            public FAIdentity FundingAccountIdentity { get; set; }
            public string Label { get; set; }
            public FABalance Balance { get; set; }

            public class FABalance
            {
                public string Amount;
                public string CurrencyCode;

            }
            public class FAIdentity
            {
                public string FundingAccountId;
                public string Nickname;
                public string AccountNumber;

            }
        }
        #endregion
    }
}
