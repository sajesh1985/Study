from typing import List, Optional
from pydantic import BaseModel, Field

class TemplateSection(BaseModel):
    """Represents a section within a template."""
    id: Optional[str] = Field(default="", description="Unique identifier for the section")
    section_title: Optional[str] = Field(default="", description="Title of the section")
    description: Optional[str] = Field(default="", description="Description of the section")
    prompt: Optional[str] = Field(default="", description="Prompt text for the section")
    sections: Optional[List['TemplateSection']] = Field(default_factory=list, description="List of child sections")
    tools: Optional[List[str]] = Field(default_factory=list, description="List of tools available for this section")

class Template(BaseModel):
    """Represents a complete template with metadata and sections."""
    template_name: Optional[str] = Field(default="", description="Name of the template")
    template_description: Optional[str] = Field(default="", description="Description of the template")
    template_version: Optional[str] = Field(default="", description="Version of the template")
    template_prompt: Optional[str] = Field(default="", description="Main prompt for the template")
    sections: Optional[List[TemplateSection]] = Field(default_factory=list, description="List of sections in the template")
    
    class Config:
        """Pydantic configuration."""
        extra = "forbid"
        validate_assignment = True

# Enable forward references for nested sections
TemplateSection.model_rebuild()