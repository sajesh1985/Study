FINANCIAL_EXAMPLES = """
{
    "question": "What's the financial performance been for XYZ over the past few years",
    "answer": {
        "summary": true,
        "forecast": false,
    }
}
__________________
{
    "question": "What is the financial forecast for XYZ?",
    "answer": {
        "summary": false,
        "forecast": true,
    }
}
__________________
{
    "question": "What is the financial forecast and financial summary/highlights for XYZ?",
    "answer": {
        "summary": true,
        "forecast": true,
    }
}
__________________
{
    "question": "Show me XYZ's Revenue for 2021 q1 and q2.",
    "answer": {
        "summary": true,
        "forecast": false,
    }
}
__________________
{
    "question": "How does the XYZ currency effect XYZ's revenue?",
    "answer": {
        "summary": true,
        "forecast": false,
    }
}
__________________
{
    "question": "what are the financial trends/highlights of XYZ",
    "answer": {
        "summary": true,
        "forecast": false,
    }
}
__________________
{
    "question": "show me the ebita forecast of XYZ",
    "answer": {
        "summary": false,
        "forecast": true,
    }
}
"""

OUTPUT_FORMAT = """
{
  "summary": boolean,
  "forecast": boolean
}
"""

FINANCIAL_PROMPTS = """
You are a financial query classifier. Given the current date of {current_date}, and a user question about a company's financials, determine whether the query is requesting:

1. Historical financial summary/performance data (summary = true) - for data before the current quarter
2. Financial forecasts or future projections (forecast = true) - for data beyond the current quarter

A query can request both types of information (both flags true) or just one type.

USER QUERY: {question}

Analyze the query for:
- Time references relative to today ({current_date})
- Current quarter is {current_quarter} ({current_quarter_range})
- References to past quarters/years (summary)
- References to future quarters/years (forecast)
- Keywords like "forecast," "projection," "outlook," "expected," "will be" (forecast)
- Keywords like "performance," "results," "trends," "highlights," "was," "has been" (summary)
- Queries about "current" performance or "this quarter" refer to {current_quarter} data (summary)

Examples:
{examples}

Return your classification as a JSON object with two boolean fields:
{output_format}

Do not include any explanations, just the JSON response.
"""
