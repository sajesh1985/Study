﻿// Copyright Notice! 
// This document is protected under the trade secret and copyright 
// laws as the property of Fidelity National Information Services, Inc. 
// Copying, reproduction or distribution should be limited and only to 
// employees with a “need to know” to do their job. 
// Any disclosure of this document to third parties is strictly prohibited.
// © 2018 Fidelity National Information Services.
// All rights reserved worldwide.

namespace Fis.Epp.Fusion.Auth.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Fis.Epp.Fusion.Auth.Models;
    using System.Linq;
    using Fis.Epp.Fusion.Auth.Common;

    /// <summary>Api for refreshing, revoking WSO2 access token and context token.</summary>
    [ApiController]
    public class AuthApiController : ControllerBase
    {
        #region Fields

        private readonly ILogger<AuthApiController> _logger;
        private readonly AppConfiguration _configuration;
        private readonly WSO2AccessHandler _wso2AccessHandler;
        private readonly RESTAccessHandler _restAccessHandler;

        #endregion

        #region Ctor

        public AuthApiController(
            ILogger<AuthApiController> logger,
            AppConfiguration appConfiguration,
            WSO2AccessHandler wso2AccessHandler,
            RESTAccessHandler restAccessHandler)
        {
            _logger = logger;
            _configuration = appConfiguration;
            _wso2AccessHandler = wso2AccessHandler;
            _restAccessHandler = restAccessHandler;
        }

        #endregion

        #region Public Methods

        #region Refresh Access Token

        /// <summary>Validates session token expiry, gets new access token from code connect and refresh session token.</summary>        
        /// <returns>Returns new access token fetched from WSO2.</returns>               
        [Produces("application/json")]
        [Route("AuthApi/RefreshAccessToken")]
        [HttpPost]
        [TypeFilter(typeof(ValidateSessionTokenAttribute))]
        public async Task<IActionResult> RefreshAccessToken()
        {
            WSO2TokenModel wsO2Token = new WSO2TokenModel();
            Dictionary<string, string> sessionTokenClaims = new Dictionary<string, string>();
            string sessionToken = string.Empty;

            var jwtSessionToken = JwtHelper.ReadToken(Request.Headers[RequestHeader.SessionToken.GetEnumDescription()]);
            if (jwtSessionToken != null)
            {
                foreach (var claim in jwtSessionToken.Claims)
                {
                    sessionTokenClaims.Add(claim.Type, claim.Value);
                }
            }

            // Fetch access token from WSO2 api manager.
            wsO2Token = await _wso2AccessHandler.GetAccessToken();
            if (!string.IsNullOrEmpty(wsO2Token.Access_Token))
            {
                int tokenExpiry = _configuration.SessionTimeout;
                tokenExpiry = sessionTokenClaims.ContainsKey(JWTEnum.sessionTimeout.GetEnumDescription()) ? Convert.ToInt32(sessionTokenClaims[JWTEnum.sessionTimeout.GetEnumDescription()]) : tokenExpiry;
                // Create new JWT session token to refresh timeout.
                sessionToken = JwtHelper.GenerateSymmetricToken(_configuration.TokenSigningKey, sessionTokenClaims, tokenExpiry);
            }
            return Ok(new { AccessToken = wsO2Token.Access_Token, SessionToken = sessionToken });
        }

        #endregion

        #region Refresh Context Token

        /// <summary>Refresh context token.</summary>
        /// <param name="model"></param>
        /// <returns>New context token.</returns>
        /// <exception cref="System.ArgumentNullException">throws null if <paramref name="contextToken"/> is <see langword="null"/>.</exception>
        [Produces("application/json")]
        [Route("AuthApi/RefreshContextToken")]
        [HttpPost]
        [TypeFilter(typeof(ValidateSessionTokenAttribute))]
        public async Task<IActionResult> RefreshContextToken([FromBody] ContextTokenRequestModel model)
        {
            if (string.IsNullOrEmpty(model.ContextToken))
            {
                throw new ArgumentNullException(ExceptionEnum.ContextToken.GetEnumDescription());
            }

            ContextTokenModel contextToken = new ContextTokenModel();
            Dictionary<string, string> sessionTokenClaims = new Dictionary<string, string>();

            var jwtSessionToken = JwtHelper.ReadToken(Request.Headers[RequestHeader.SessionToken.GetEnumDescription()]);
            if (jwtSessionToken != null)
            {
                foreach (var claim in jwtSessionToken.Claims)
                {
                    sessionTokenClaims.Add(claim.Type, claim.Value);
                }
            }

            ContextTokenRequestModel contextTokenRequestModel = new ContextTokenRequestModel
            {
                Authorization = Request.Headers[RequestHeader.Authorization.GetEnumDescription()],
                FeId = Request.Headers[RequestHeader.FE_ID.GetEnumDescription()],
                UserId = Request.Headers[RequestHeader.USER_ID.GetEnumDescription()],
                Uuid = Request.Headers[RequestHeader.UUID.GetEnumDescription()],
                CorrelationId = Request.Headers[RequestHeader.Correlation_ID.GetEnumDescription()],
                ContextToken = model.ContextToken,
                Locale = Request.Headers[RequestHeader.Locale.GetEnumDescription()],
                ApplicationId = Request.Headers[RequestHeader.Application_ID.GetEnumDescription()],
                SourceId = Request.Headers[RequestHeader.Source_ID.GetEnumDescription()]
            };
            contextToken = await _restAccessHandler.RefreshContextToken(contextTokenRequestModel);

            var result = new { ContextToken = contextToken.data.contextToken };
            return Ok(result);
        }

        #endregion

        #region Keep Alive Session

        /// <summary>Validates session token expiry and gets new session token with fresh expiry time.</summary>        
        /// <returns>Session token with slide expiry time.</returns>        
        [Produces("application/json")]
        [Route("AuthApi/KeepAliveSession")]
        [HttpPost]
        [TypeFilter(typeof(ValidateSessionTokenAttribute))]
        public IActionResult KeepAliveSession()
        {
            Dictionary<string, string> sessionTokenClaims = new Dictionary<string, string>();
            var jwtSessionToken = JwtHelper.ReadToken(Request.Headers[RequestHeader.SessionToken.GetEnumDescription()]);
            if (jwtSessionToken != null)
            {
                foreach (var claim in jwtSessionToken.Claims)
                {
                    sessionTokenClaims.Add(claim.Type, claim.Value);
                }
            }

            int tokenExpiry = _configuration.SessionTimeout;
            tokenExpiry = sessionTokenClaims.ContainsKey(JWTEnum.sessionTimeout.GetEnumDescription()) ? Convert.ToInt32(sessionTokenClaims[JWTEnum.sessionTimeout.GetEnumDescription()]) : tokenExpiry;
            // Create new JWT session token to refresh session timeout.          
            string sessionToken = JwtHelper.GenerateSymmetricToken(_configuration.TokenSigningKey, sessionTokenClaims, tokenExpiry);
            var data = new { SessionToken = sessionToken };
            return Ok(data);
        }

        #endregion

        #region Revoke Context Token

        /// <summary>Revoke context token.</summary>
        /// <param name="model"></param>
        /// <returns>Whether context token revoked or not.</returns>
        /// <exception cref="System.ArgumentNullException">throws null if <paramref name="contextToken"/> is <see langword="null"/>.</exception>
        [Produces("application/json")]
        [Route("AuthApi/RevokeContextToken")]
        [HttpPost]
        [TypeFilter(typeof(ValidateSessionTokenAttribute), Arguments = new object[] { false })]
        public async Task<IActionResult> RevokeContextToken([FromBody]ContextTokenRequestModel model)
        {
            bool isTokenRevoked = false;
            if (string.IsNullOrEmpty(model.ContextToken))
            {
                throw new ArgumentNullException(ExceptionEnum.ContextToken.GetEnumDescription());
            }
            ContextTokenRequestModel contextTokenRequestModel = new ContextTokenRequestModel
            {
                Authorization = Request.Headers[RequestHeader.Authorization.GetEnumDescription()],
                FeId = Request.Headers[RequestHeader.FE_ID.GetEnumDescription()],
                UserId = Request.Headers[RequestHeader.USER_ID.GetEnumDescription()],
                Uuid = Request.Headers[RequestHeader.UUID.GetEnumDescription()],
                CorrelationId = Request.Headers[RequestHeader.Correlation_ID.GetEnumDescription()],
                ContextToken = model.ContextToken,
                Locale = Request.Headers[RequestHeader.Locale.GetEnumDescription()],
                ApplicationId = Request.Headers[RequestHeader.Application_ID.GetEnumDescription()],
                SourceId = Request.Headers[RequestHeader.Source_ID.GetEnumDescription()]
            };
            isTokenRevoked = await _restAccessHandler.RevokeContextToken(contextTokenRequestModel);

            if (isTokenRevoked)
                return Ok();
            else
                return BadRequest();
        }

        #endregion        

        #endregion
        
    }
}