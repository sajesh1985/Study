import logging
from typing import Optional

import pandas as pd

from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.data_service.schema import (
    Analyzer,
    ProcessorInput,
    Retriever,
    Synthesizer,
)
from chatrd.engine.data_service.synthesizer.base import BaseSynthesizer
from chatrd.engine.data_service.synthesizer.financial.utils import (
    assign_citations,
    clean_metric_names,
    detect_format,
    filter_financial_year_data,
    get_synthesizer_llm_response_text,
    prepare_metric_categories_from_metric_type,
    source_description,
    template_error_leading_line,
    text_with_table,
)
from chatrd.engine.data_service.synthesizer.utils import (  # table_response,
    full_response,
    get_api_info,
    text_response,
)

logger = logging.getLogger(__name__)
config_machinery = get_config_machinery()


logger = logging.getLogger(__name__)


class FinancialMetricsSynthesizer(BaseSynthesizer):
    def synthesize(
        self,
        processor: Optional[ProcessorInput] = None,
        analyzer: Optional[Analyzer] = None,
        retriever: Retriever = None,
        multi_uc_type: Optional[bool] = False,
    ) -> Synthesizer:
        """
        Synthesizes a response based on the provided processor, analyzer, and retriever.
        """
        companies = [company["name"] for company in processor.entities.get("companies", [{}])]
        use_single_template = len(companies) == 1
        multi_uc_type = processor.multi_uc_type
        all_res_data = []
        url_citation_map = {}
        citation_counter = 1
        citation_map_per_entry = {}
        result_companies = analyzer.response.get("result", [])
        metrics = analyzer.response.get("metrics", [])
        metrics_list = analyzer.response.get("metricsList", [])
        time_periods = analyzer.response.get("time", [])
        _sourcing_base_url = config_machinery.get_config_value(Constants.SourceGeneration.BASE_URL)
        _footnote_url_slug = config_machinery.get_config_value(Constants.SourceGeneration.FOOTNOTE_URL_SLUG)
        base_url = _sourcing_base_url + _footnote_url_slug

        result_companies = sorted(result_companies, key=lambda d: d["company"])
        for idx, company_info in enumerate(result_companies):
            company_name = company_info.get("company", "")
            rd_sector = company_info.get("rd_sector", "")
            entity_id = company_info.get("keyInstn", "")
            company_data = [entry for entry in retriever.api_data if str(entry.get("KeyInstn", "")) == entity_id]

            if not company_data:
                continue  # Skip this company if no data found

            for entry in company_data:
                entry["Company"] = company_name
            response_data = filter_financial_year_data(company_data, time_periods)

            extracted_metrics = (
                list(dict.fromkeys(i["MetricName"] for i in response_data)) if response_data else metrics
            )

            metric_categories = prepare_metric_categories_from_metric_type(metrics_list)
            response_data, citation_counter = assign_citations(
                response_data,
                analyzer.response,
                base_url,
                citation_counter,
                url_citation_map,
                citation_map_per_entry,
            )
            preprocess_response = clean_metric_names(response_data)
            source_url = source_description(company_name, entity_id, rd_sector, metric_categories, preprocess_response)

            all_res_data.append(
                {
                    "sector": rd_sector,
                    "metrics": extracted_metrics,
                    "preprocess_response": preprocess_response,
                    "source_url": source_url,
                    "entity_name": company_name,
                    "entity_id": entity_id,
                }
            )
        # Extracting all response data (only from the companies that have data)
        response_data = [item for res in all_res_data for item in (res["preprocess_response"] or [])]
        company_list = sorted(set(d["Company"] for d in response_data))
        metrics_list = sorted(set(d["MetricName"] for d in response_data))
        period_list = sorted(set(d["Period"] for d in response_data))
        output_format = detect_format(processor.user_input, company_list, processor.llm)
        source_url = [item for res in all_res_data for item in res["source_url"]]

        error_flag = False

        if len(response_data):
            if multi_uc_type is True:
                df_tabular = pd.DataFrame(response_data)
                response = full_response(
                    template="",
                    data=df_tabular,
                    data_type="table",
                    count=len(df_tabular),
                )

            elif output_format == "TABLE":
                response = text_with_table(company_list, period_list, response_data)

            elif output_format == "TEXT":
                response_text = get_synthesizer_llm_response_text(
                    processor.llm, response_data, original_language=processor.original_language
                )
                response = [text_response(response_text)]
            api_info = get_api_info(
                api_method=retriever.api_method,
                api_type=retriever.api_type,
                url=retriever.url,
                screener_payload=retriever.screener_payload,
            )
            return Synthesizer(
                data_service_response=response,
                source_description=source_url,
                api_info=api_info,
                error_flag=error_flag,
            )

        else:
            if use_single_template:
                error_flag = True
                if result_companies:
                    single_company = result_companies[0]
                    company_name = [single_company.get("company", "")]
                    rd_sector = single_company.get("rd_sector", "")
                    entity_id = single_company.get("keyInstn", "")
                    # entity_id = entity_ids[0] if entity_ids else ""
                else:
                    company_name = entity_id = rd_sector = ""
            else:
                error_flag = False
                company_name = [comp["company"] for comp in result_companies]

            template = template_error_leading_line(metrics, company_name, entity_id, rd_sector)
            response = [text_response(template)]
            source_url = []
            api_info = get_api_info(api_method=retriever.api_method, api_type=retriever.api_type, url=retriever.url)
            return Synthesizer(
                data_service_response=response,
                source_description=source_url,
                api_info=api_info,
                error_flag=error_flag,
                template=template,
            )
