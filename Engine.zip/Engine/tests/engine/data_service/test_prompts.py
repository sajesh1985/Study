#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Copyright (C) S&P Global. All Rights Reserved.
NOTICE: All information contained herein is, and remains the  property of S&P Global and its suppliers,
if any. The intellectual and technical concepts contained herein are  proprietary to S&P Global and its suppliers and
may be covered by U.S. and Foreign Patents, patents in process,  and are protected by trade secret or copyright law.
Dissemination of this information or reproduction of this  material is strictly forbidden unless prior written
permission is obtained from S&P Global.
"""

from chatrd.engine.data_service.perspectives import Perspective
from chatrd.engine.data_service.analyzer.prompts.prompts import prompt_from_perspectives

TEST_PROMPT_TEMPLATE = """{examples}
{operators}
{connectors}
{input}"""


def test_generation_of_prompt():
    p1 = Perspective(name="X", examples=[])
    p1.examples = [{"prompt": "A", "payload": {"B": "C"}}]

    p2 = Perspective(name="Y", examples=[])
    p2.examples = [{"prompt": "D", "payload": {}}]

    expected_prompt = """Examples for X:\nA -> {"B": "C"}\nExamples for Y:\nD -> {}\nequal\nnot equal\nless than\ngreater than\nbegin with\nless than or equal\ngreater than or equal\nin\nnot in\nincludes\nnot includes\ncontains\nis\nbetween\nnot begin with\nis null\nis not null\nis na\nnot na\nfrom\nexists\nexclude from\nnot between\nnot contains\nnot exists\ntop n order by ascending\ntop n order by descending\nor\nand\nuser says"""
    real_prompt = prompt_from_perspectives([p1, p2], "user says", prompt_template=TEST_PROMPT_TEMPLATE)

    assert real_prompt == expected_prompt
