import logging
from typing import Dict, Optional, List
from functools import lru_cache

from src.synthia.queue.queue_backend import get_queue_backend

logger = logging.getLogger(__name__)

class ReportPublisher:
    """Publish messages to a single queue (local or SQS), using only fields your original code handled + user_sections."""

    def __init__(self):
        self.backend = get_queue_backend()

    @staticmethod
    def _env(action: str, payload: Dict) -> Dict:
        return {"action": action, "payload": payload}

    async def publish_generate_report(self, *, job_id: str, token: str) -> str:
        body = self._env("generate_report", {"job_id": job_id, "token": token})
        mid = await self.backend.send_message(body)
        logger.info("Published generate_report id=%s job=%s", mid, job_id)
        return mid

    async def publish_outline_approval(
        self,
        *,
        job_id: str,
        approved: bool,
        token: str,
        revised_sections: Optional[int] = None,
        revised_depth: Optional[int] = None,
        user_sections: Optional[list] = None,
    ) -> str:
        payload: Dict = {
            "job_id": job_id,
            "approved": bool(approved),
            "token": token,
        }
        if revised_sections is not None:
            payload["revised_sections"] = int(revised_sections)
        if revised_depth is not None:
            payload["revised_depth"] = int(revised_depth)
        if user_sections is not None:
            payload["user_sections"] = list(user_sections)  # <-- added

        body = self._env("process_outline_approval", payload)
        mid = await self.backend.send_message(body)
        logger.info("Published process_outline_approval id=%s job=%s approved=%s", mid, job_id, approved)
        return mid

@lru_cache(maxsize=1)
def get_publisher() -> ReportPublisher:
    return ReportPublisher()
