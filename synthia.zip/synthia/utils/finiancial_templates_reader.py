import json

from pathlib import Path

class FinancialTemplatesLoader:
    def __init__(self, path=None):
        if path is None:
            # Default path relative to this file
            path = Path(__file__).parent.parent / "resources" / "templates" / "financial_templates.json"
        with open(path, "r", encoding="utf-8") as f:
            self.data = json.load(f)

    def get_section_names(self):
        # Returns all top-level section names
        sections = set()
        if "Sections" in self.data:
            sections.update(self.data["Sections"].keys())
        if "FinancialHighlights" in self.data:
            sections.update(self.data["FinancialHighlights"].keys())
        return list(sections)

    def get_metrics_for_section(self, section):
        # Returns metrics for a given section
        metrics = []
        # Try both keys for compatibility
        for key in ["Sections"]:
            if key in self.data and section in self.data[key]:
                metrics.extend(self.data[key][section])
        return metrics

    def get_all_financial_highlights_metrics(self):
        """
        Returns a flat list of all metrics under FinancialHighlights.
        """
        metrics = []
        highlights = self.data.get("FinancialHighlights", {})
        for section_metrics in highlights.values():
            metrics.extend(section_metrics)
        return metrics
