from typing import Optional

from pydantic import BaseModel

from chatrd.core.llm.parsers import PydanticOutputParser
from chatrd.core.llm.prompt.template import BasePromptTemplate
from chatrd.engine.components.query_analyzer.faulttolerantexecutor import (
    FaultTolerantExecutor,
)
from chatrd.engine.components.query_analyzer.filter_retrievers.base import (
    BaseFilter,
    FiltersInput,
)
from chatrd.engine.components.query_analyzer.filter_retrievers.prompts import (
    QuestionIntentClass,
    TimeOutputDates,
)


class TimeThresholdFilter(BaseFilter, FaultTolerantExecutor):
    def __init__(
        self,
        uc_specific_prompt: BasePromptTemplate,
        output_parser: PydanticOutputParser,
        specific_instructions_fn,
        examples_fn,
        filters_input: Optional[FiltersInput] = None,
    ):
        if filters_input:
            super().__init__(filters_input=filters_input)
        else:
            super().__init__()
        self.prompt_template = uc_specific_prompt
        self.output_parser = output_parser
        self.specific_instructions_fn = specific_instructions_fn
        self.examples_fn = examples_fn

    def invoke(self, user_input: str, today_date, **kwargs) -> BaseModel:
        user_input_prompt = self.prompt_template.format(
            question=user_input,
            today_date=today_date,
            task_specific_instructions=self.specific_instructions_fn(today_date),
            examples=self.examples_fn(today_date),
            **kwargs,
        )
        output = self.model_for_data_service.invoke(user_input_prompt)
        output_parsed = self.output_parser.invoke(output)
        return output_parsed

    run = invoke

    def get_default_value(self) -> BaseModel:
        return TimeOutputDates(
            PeriodType=QuestionIntentClass.UNSPECIFIED,
            PeriodsList=None,
            ChainOfThought="Default response due to failure in time threshold filter.",
        )
