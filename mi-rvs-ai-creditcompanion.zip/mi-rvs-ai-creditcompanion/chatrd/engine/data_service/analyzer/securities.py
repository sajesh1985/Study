import logging
import re
from typing import Optional

from chatrd.core.llm import LCLLMFactory
from chatrd.engine.configuration import get_config_machinery
from chatrd.engine.data_service.analyzer.base import BaseAnalyzer
from chatrd.engine.data_service.analyzer.prompts.prompts import PROMPT_SECURITIES
from chatrd.engine.data_service.schema import Analyzer, ProcessorInput

logger = logging.getLogger(__name__)

config_machinery = get_config_machinery()


class ListofSecuritiesAnalyzer(BaseAnalyzer):
    """
    Query Analyzer for Securities use case
    """

    def __init__(self, vector_database_path: Optional[str] = None):
        self.vector_database_path = vector_database_path

    def analyze(self, processor: ProcessorInput) -> Analyzer:

        num_trials = 3
        pipes_count = 0
        modified_input = processor.user_input
        pattern = r"\bs\s*&\s*p(\s*global)?\b"
        modified_input = re.sub(pattern, "", modified_input, flags=re.IGNORECASE)
        pattern = r"\brated\b"
        modified_input = re.sub(pattern, "", modified_input, flags=re.IGNORECASE)

        prompt = PROMPT_SECURITIES + "\n" + modified_input
        logger.info(f"Securities Analyzer Modified User Input: {modified_input}")
        while pipes_count != 2 and num_trials > 0:
            llm = LCLLMFactory().get_llm(deployment_name_or_model_id="claude-3-haiku", temperature=0.0)
            response = llm.invoke(prompt)
            pipes_count = response.content.count("|")
            num_trials = num_trials - 1
            prompt = prompt + "\n" + "Reminding again, the number of pipes can never be more than 2 in your response."

        pattern = r"\*{4}(.*?)\*{4}"
        matches = re.findall(pattern, response.content)
        logger.info(f"Securities Analyzer regex matches: {matches}")
        if matches:
            [debt_type, rating_type, date_range] = matches[0].strip('"').split("|")
        else:
            logger.error("Unable to decipher response from LLM call in ListofSecuritiesAnalyzer")
            debt_type = rating_type = date_range = ""

        date_start = date_end = ""
        if date_range:
            [date_start, date_end] = date_range.split("-")

        analyzer_output = dict()
        analyzer_output["DebtType"] = debt_type
        analyzer_output["RoleType"] = rating_type
        analyzer_output["MaturityStartDate"] = date_start
        analyzer_output["MaturityEndDate"] = date_end
        return Analyzer(
            user_input=processor.user_input,
            uc_type=processor.uc_type,
            response=analyzer_output,
        )
