MAIN_EXTRACTION_PROMPT = """You are an expert credit analyst assistant specialized in decomposing complex queries into structured attribute-based sub-queries.Your task is to break down the USER QUESTION into its main attributes as listed under ATTRIBUTES.  

**OBJECTIVE**: 
Analyze the USER QUESTION and extract relevant attributes to generate focused, actionable sub-queries for each component.

**CORE INSTRUCTIONS**:
1. **Identify Attributes**: Scan the USER QUESTION for mentions of the seven key attributes listed below
2. **Generate Sub-queries**: For each identified attribute, create a clear, targeted sub-query that isolates that specific aspect
3. **Preserve Intent**: Maintain the original question's action verbs, structure, and semantic meaning
4. **Handle Temporality**: Include time-based qualifiers ONLY when explicitly stated by the user
5. **Complete Coverage**: Return all seven attributes in the dictionary, using empty strings for unmentioned ones
6. **Avoid Assumptions**: Do NOT inject temporal words ('recently', 'latest', 'lately', 'last') unless explicitly present

**QUALITY STANDARDS**:
- Sub-queries should be grammatically correct and naturally readable
- Maintain consistency in question formatting and style
- Preserve specific technical terms, rating symbols, and proper nouns exactly as mentioned
- Each sub-query should focus on exactly one attribute

**OUTPUT REQUIREMENT**: Return ONLY a valid Python dictionary without explanations or comments.

**ATTRIBUTES DEFINITIONS**:
- **industry**: Industry sector, business line, or corporate type mentioned in the question
  Examples: 'entertainment', 'financial', 'energy', 'corporates', 'technology', 'healthcare', 'corporate', 'sovereign'
  
- **geography**: Geographic location including continents, countries, regions, or cities
  Examples: 'United States', 'China', 'Europe', 'Asia-Pacific', 'Germany', 'North America'
  
- **credit_rating**: S&P credit ratings, rating levels, or rating qualifiers mentioned
  Examples: 'AAA', 'BB-', 'CCC', 'speculative grade', 'investment grade', 'top rated', 'high yield'
  
- **credit_action_type**: S&P credit rating actions or changes mentioned
  Examples: 'downgrade', 'upgrade', 'new rating'
  
- **creditwatch_outlook_actions**: S&P CreditWatch or Outlook designations mentioned  
  Examples: 'positive', 'developing', 'stable', 'negative', 'watch pos', 'watch dev', 'watch neg', 'nm', 'nr'
  
- **financial_metrics**: Financial data, ratios, or performance indicators mentioned
  Examples: 'revenue', 'EBITDA', 'net income', 'debt', 'cash flow', 'FFO', 'working capital'
  
- **sorting**: Ranking, ordering, or quantity specifications mentioned
  Examples: 'top 10', 'bottom 5'

**EXAMPLES**:
{main_extraction_examples}

**BEST PRACTICES**:
- Keep sub-queries concise and focused on single attributes
- Preserve the original question's action verbs and structure
- Include specific timeframes only when explicitly mentioned
- Maintain the logical flow and context from the original question
- Must use uppercase for the specific credit rating ("AA", "BB-", "CCC" etc.) in the sub-queries

`USER QUESTION`:
{user_question}
"""

MAIN_EXTRACTION_SAMPLES = [
    (
        "Identify A rated companies in the automotive sector in Japan with positive outlook.",
        """{'industry': "Identify companies in the automotive sector.",
      'geography': "Identify companies in Japan.",
      'credit_rating': "Identify A rated companies.",
      'credit_action_type': "",
      'creditwatch_outlook_actions': "Identify companies with positive outlook.",
      'financial_metrics': "",
      'sorting': ""}""",
    ),
    (
        "What are the top 20 automotive companies with positive outlook in Japan?",
        """{'industry': "What are automotive companies?", 
      'geography': "What are the companies in Japan?", 
      'credit_rating': "", 
      'credit_action_type': "", 
      'creditwatch_outlook_actions': "What are the companies with positive outlook?",
      'financial_metrics': "",
      'sorting': "What are the top 20 companies?"}""",
    ),
    (
        "Give me top ten sovereign companies in France with AA- rating and stable outlook.",
        """{'industry': "Give me sovereign companies.",
      'geography': "Give me companies in France.",
      'credit_rating': "Give me companies with AA- rating.",
      'credit_action_type': "",
      'creditwatch_outlook_actions': "Give me companies with stable outlook.",
      'financial_metrics': "",
      'sorting': "Give me top ten companies."}""",
    ),
    (
        "Provide a list of recently downgraded insurance issuers in Europe and their ratings?",
        """{'industry': "Provide a list of insurance issuers.",
      'geography': "Provide a list of issuers in Europe.",
      'credit_rating': "Provide a list of issuers with their ratings.",
      'credit_action_type': "Provide a list of recently downgraded issuers.",
      'creditwatch_outlook_actions': "",
      'financial_metrics': "",
      'sorting': ""}""",
    ),
    (
        "Give me a list of companies that received BB+ or higher credit ratings in the last 6 months.",
        """{'industry': "",
        'geography': "",
        'credit_rating': "Give me a list of companies that received BB+ or higher credit ratings in the last 6 months.",
        'credit_action_type': "",
        'creditwatch_outlook_actions': "",
        'financial_metrics': "",
        'sorting': ""}""",
    ),
    (
        "Provide me a list of rated entities in the Europe region that have received positive outlook in the last quarter including their industry.",
        """{'industry': "Provide me a list of entities with their industry.",
        'geography': "Provide me a list of entities in the Europe region.",
        'credit_rating': "Provide me a list of rated entities.",
        'credit_action_type': "",
        'creditwatch_outlook_actions': "Provide me a list of entities that have received positive outlook in the last quarter.",
        'financial_metrics': "",
        'sorting': ""}""",
    ),
    (
        "Show me downgraded issuers in China with a positive outlook in 2023 and BB or above credit rating.",
        """{'industry': "",
        'geography': "Show me issuers in China.",
        'credit_rating': "Show me issuers with BB or above credit rating.",
        'credit_action_type': "Show me downgraded issuers.",
        'creditwatch_outlook_actions': "Show me issuers with a positive outlook in 2023.",
        'financial_metrics': "",
        'sorting': ""}""",
    ),
    (
        "What are the entities in energy sector having credit rating of A- or below?",
        """{'industry': "What are the entities in energy sector?",
        'geography': "",
        'credit_rating': "What are the entities having credit rating of A- or below?",
        'credit_action_type': "",
        'creditwatch_outlook_actions': "",
        'financial_metrics': "",
        'sorting': ""}""",
    ),
    (
        "List the top 10 corporates in the US with a credit rating of A- or above.",
        """{'industry': "List the corporates.",
         'geography': "List the companies in the US.",
         'credit_rating': "List the companies with a credit rating of A- or above.",
         'credit_action_type': "",
         'creditwatch_outlook_actions': "",
         'financial_metrics': "",
         'sorting': "List the top 10 companies."}""",
    ),
    (
        "What are the recently downgraded companies with their industry, credit rating and geography?",
        """{'industry': "What are the companies with their industry?",
        'geography': "What are the companies with their geography?",
        'credit_rating': "What are the companies with their credit rating?",
        'credit_action_type': "What are the recently downgraded companies?",
        'creditwatch_outlook_actions': "",
        'financial_metrics': "",
        'sorting': ""}""",
    ),
    (
        "Show me the above A- entities that have been downgraded in the last quarter, including their financial summary.",
        """{'industry': "",
        'geography': "",
        'credit_rating': "Show me the entities that are above A-.",
        'credit_action_type': "Show me the entities that have been downgraded in the last quarter.",
        'creditwatch_outlook_actions': "",
        'financial_metrics': "Show me the entities, including their financial summary.",
        'sorting': ""}""",
    ),
    (
        "List the BBB rated retail companies with watch neg values for 2024 in the UK, including their credit watch actions in the last 24 months.",
        """{'industry': "List the retail companies.",
       'geography': "List companies in the UK.",
       'credit_rating': "List the BBB rated companies",
       'credit_action_type': "list companies, including their credit watch actions in the last 24 months.",
       'creditwatch_outlook_actions': "List the companies with watch neg values for 2024",
       'financial_metrics': "",
       'sorting': ""}""",
    ),
    (
        "Can you provide the latest credit actions for financial institutions in Canada with their credit rating for the last 6 months?",
        """{'industry': "Can you provide the financial institutions?",
      'geography': "Can you provide the institutions in Canada?",
      'credit_rating': "can you provide companies with their credit rating for the last 6 months?",
      'credit_action_type': "Can you provide the latest credit actions?",
      'creditwatch_outlook_actions': "",
      'financial_metrics': "",
      'sorting': ""}""",
    ),
    (
        "Show me the revenue figures for technology and computer gaming firms in Germany with their change in CreditWatch and Outlook since May 2025.",
        """{'industry': "Show me the technology and computer gaming firms.",
      'geography': "Show me the firms in Germany.",
      'credit_rating': "",
      'credit_action_type': "",
      'creditwatch_outlook_actions': "Show me the firms with their change in CreditWatch and Outlook since May 2025.",
      'financial_metrics': "Show me the revenue figures for the firms.",
      'sorting': ""}""",
    ),
    (
        "Which companies in the energy sector who had outlook change in 2022 have an A+ or above credit rating?",
        """{'industry': "Which companies in the energy sector?", 
      'geography': "", 
      'credit_rating': "Which companies have an A+ or above credit rating?", 
      'credit_action_type': "", 
      'creditwatch_outlook_actions': "Which companies had outlook change in 2022?",
      'financial_metrics': "",
      'sorting': ""}""",
    ),
    (
        "What is the credit rating in 2024 for top 20 healthcare companies in Australia with positive or developing outlook?",
        """{'industry': "What are the healthcare companies?", 
      'geography': "What are the companies in Australia?", 
      'credit_rating': "What is the credit rating in 2024 for the companies?", 
      'credit_action_type': "", 
      'creditwatch_outlook_actions': "What are the companies with positive or developing outlook?",
      'financial_metrics': "",
      'sorting': "What are the top 20 companies?"}""",
    ),
    (
        "Find the EBITDA for Q1 for the top rated telecom companies that have had an outlook change, including their geography.",
        """{'industry': "Find the telecom companies.", 
      'geography': "Find the companies with their geography.", 
      'credit_rating': "Find the top rated companies.", 
      'credit_action_type': "", 
      'creditwatch_outlook_actions': "Find the companies that have had an outlook change.",
      'financial_metrics': "Find the EBITDA for Q1.",
      'sorting': ""}""",
    ),
    (
        "What are the recent credit actions for mining companies in South Africa that rated BB or above in the last 6 months with their financial highlights and credit watch changes?",
        """{'industry': "What are the mining companies?", 
      'geography': "What are the companies in South Africa?", 
      'credit_rating': "What are the companies rated BB or above in the last 6 months?", 
      'credit_action_type': "What are the recent credit actions for the companies?", 
      'creditwatch_outlook_actions': "What are the companies with credit watch changes?",
      'financial_metrics': "What are the companies with their financial highlights?",
      'sorting': ""}""",
    ),
    (
        "List the top-rated consumer goods and hardware companies in the last 12 months in France with their recent credit actions, credit watch changes, and net income values for Q1 and Q2.",
        """{'industry': "List the consumer goods and hardware companies.", 
      'geography': "List the companies in France.", 
      'credit_rating': "List the top-rated companies in the last 12 months.", 
      'credit_action_type': "List the companies with their recent credit actions.", 
      'creditwatch_outlook_actions': "List the companies with credit watch changes.",
      'financial_metrics': "List the net income values for Q1 and Q2.",
      'sorting': ""}""",
    ),
    (
        "What is the credit ratings of 2024 for newly rated utilities, energy or industrial sectors in India?",
        """{'industry': "What is the utilities, energy or industrial sectors?",
      'geography': "What is the sectors in India?", 
      'credit_rating': "What is the credit ratings of 2024 for the sectors?", 
      'credit_action_type': "What are the newly rated sectors?",
      'creditwatch_outlook_actions': "", 
      'financial_metrics': "",
      'sorting': ""}""",
    ),
    (
        "Provide the FFO consolidation for the last quarter for tourism and entertainment companies in the Netherlands that have been downgraded in the past 12 months.",
        """{'industry': "Provide the tourism and entertainment companies.", 
      'geography': "Provide the companies in the Netherlands.", 
      'credit_rating': "", 
      'credit_action_type': "Provide the companies that have been downgraded in the past 12 months.", 
      'creditwatch_outlook_actions': "",
      'financial_metrics': "Provide the FFO consolidation for the last quarter.",
      'sorting': ""}""",
    ),
    (
        "Can you list the bottom ten health and medical reinsurance companies globally that received a speculative or lower rating and watch positive outlook in the last quarter with their net income values?",
        """{'industry': "Can you list the health and medical reinsurance companies?", 
      'geography': "Can you list the companies globally?", 
      'credit_rating': "Can you list the companies that received a speculative or lower rating in the last quarter?", 
      'credit_action_type': "", 
      'creditwatch_outlook_actions': "Can you list the companies with watch positive outlook in the last quarter?",
      'financial_metrics': "Can you list the net income values for the companies?",
      'sorting': "Can you list the bottom ten companies?"}""",
    ),
    (
        "What are the most recent credit actions for software companies that have a BB+ or higher credit rating and developing or stable outlook in the past 6 months with their geography and working capital taxed of 2024?",
        """{'industry': "What are the software companies?", 
      'geography': "What are the companies with their geography?", 
      'credit_rating': "What are the companies with a BB+ or higher credit rating in the past 6 months?", 
      'credit_action_type': "What are the most recent credit actions for the companies?", 
      'creditwatch_outlook_actions': "What are the companies with developing or stable outlook in the past 6 months?",
      'financial_metrics': "What are the working capital taxed of 2024 for the companies?",
      'sorting': ""}""",
    ),
    (
        "List the construction businesses with their geography, ratings, rating actions, inventory increases and decreases over the past year.",
        """{'industry': "List the construction businesses.", 
      'geography': "List the businesses with their geography.", 
      'credit_rating': "List the businesses with their ratings.", 
      'credit_action_type': "List the businesses with their rating actions.", 
      'creditwatch_outlook_actions': "",
      'financial_metrics': "List the inventory increases and decreases over the past year.",
      'sorting': ""}""",
    ),
    (
        "What are the newly rated US companies from 2022 that received a BB+ or higher credit score in the last 6 months, along with their industry, working capital for the last month?",
        """{'industry': "What are the companies with their industry?", 
      'geography': "What are the companies in the US?", 
      'credit_rating': "What are the companies that received a BB+ or higher credit score in the last 6 months?", 
      'credit_action_type': "What are the newly rated companies from 2022?", 
      'creditwatch_outlook_actions': "",
      'financial_metrics': "What are the working capital for the last month?",
      'sorting': ""}""",
    ),
    (
        "Provide the capital, debt levels, and loans for the last 3 months for pharmaceutical companies in Switzerland that have defaulted in the past 12 months with their recent rating actions.",
        """{'industry': "Provide the pharmaceutical companies.", 
      'geography': "Provide the companies in Switzerland.", 
      'credit_rating': "Provide the companies that have defaulted in the past 12 months.", 
      'credit_action_type': "Provide the companies with their recent rating actions.", 
      'creditwatch_outlook_actions': "",
      'financial_metrics': "Provide the capital, debt levels, and loans for the last 3 months.",
      'sorting': ""}""",
    ),
    (
        "What were the credit actions in 2021 for banking and financial companies in the Middle East that currently have a BB- or higher rating and change in CreditWatch and Outlook in the last 6 months?",
        """{'industry': "What were the banking and financial companies?", 
      'geography': "What were the companies in the Middle East?", 
      'credit_rating': "What were the companies that currently have a BB- or higher rating?", 
      'credit_action_type': "What were the credit actions in 2021 for the companies?", 
      'creditwatch_outlook_actions': "What were the companies with change in CreditWatch and Outlook in the last 6 months?",
      'financial_metrics': "",
      'sorting': ""}""",
    ),
    (
        "List the top 15 positive or developing companies and include their industry, geography and ratings",
        """{'industry': "List the companies with their industry.",
      'geography': "List the companies with their geography.",
      'credit_rating': "List the companies with their ratings.",
      'credit_action_type': "",
      'creditwatch_outlook_actions': "List the companies with positive or developing outlook.",
      'financial_metrics': "",
      'sorting': "List the top 15 companies."}""",
    ),
    (
        "Which telecommunication companies are in negative or stable with credit ratings of BBB- or lower?",
        """{'industry': "Which telecommunication companies?",
      'geography': "",
      'credit_rating': "Which companies have credit ratings of BBB- or lower?",
      'credit_action_type': "",
      'creditwatch_outlook_actions': "Which companies are in negative or stable outlook?",
      'financial_metrics': "",
      'sorting': ""}""",
    ),
]
