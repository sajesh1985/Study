﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace Fis.Epp.Fusion.WebAPI.Models
{
    enum RequestHeader
    {
        [Description("Fe-ID")]
        Fe_Id,
        [Description("User-ID")]
        User_Id,
        [Description("Correlation-ID")]
        Correlation_Id,
        [Description("SessionToken")]
        SessionToken,
        [Description("User-Agent")]
        User_Agent,
        [Description("Accept-Encoding")]
        Accept_Encoding
    }
    public static class EnumExtension
    {
        public static string GetEnumDescription(this Enum enumValue)
        {
            var fieldInfo = enumValue.GetType().GetField(enumValue.ToString());

            var descriptionAttributes = (DescriptionAttribute[])fieldInfo.GetCustomAttributes(typeof(DescriptionAttribute), false);

            return descriptionAttributes.Length > 0 ? descriptionAttributes[0].Description : enumValue.ToString();
        }
    }
}
