package com.fis.digitalpayments.sdk.contacts;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.ResultReceiver;
import android.provider.ContactsContract;

// Extending Activity instead of AppCompatActivity for Cordova support
public class PickContactActivity extends Activity {

    public static final int PICK_CONTACT_REQUEST_CODE = 1;
    public static final String PICK_CONTACT_RESULT_RECEIVER_NAME = "PICK_CONTACT_RESULT_RECEIVER";
    private static final String mURI_KEY = "uri";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getResultReceiver() != null) {
            Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI);
            startActivityForResult(intent, PICK_CONTACT_REQUEST_CODE);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
            sendResult(resultCode, data);
        }
    }

    private void sendResult(int resultCode, Intent data) {
        ResultReceiver resultReceiver = getResultReceiver();

        Uri contactUri = data.getData();
        if (contactUri != null) {
            data.putExtra(mURI_KEY, data.getData().toString());
            resultReceiver.send(resultCode, data.getExtras());
        }
        finish();
        overridePendingTransition(0,0);
    }

    private ResultReceiver getResultReceiver() {
        return getIntent().getParcelableExtra(PICK_CONTACT_RESULT_RECEIVER_NAME);
    }

    public static Uri getContactUriFromBundle(Bundle bundle) {
        return Uri.parse(bundle.getString(mURI_KEY));
    }
}
