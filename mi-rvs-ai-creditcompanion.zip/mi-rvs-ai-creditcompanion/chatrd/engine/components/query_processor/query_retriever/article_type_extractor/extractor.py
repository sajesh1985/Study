from typing import Optional

from chatrd.core.llm import LCLLMFactory
from chatrd.core.llm.parsers import PydanticOutputParser
from chatrd.core.llm.prompt.template import SimplePromptTemplate
from chatrd.engine.components.query_processor.query_retriever.article_type_extractor.prompts import (
    ARTICLE_TYPE_EXTRACTOR_OUTPUT_PARSER_TEMPLATE,
    ArticleTypeValues,
)


class ArticleTypeExtractor:
    def __init__(self, model_name: str, temperature: Optional[float] = 0.0):
        self.model = LCLLMFactory().get_llm(
            deployment_name_or_model_id=model_name,
            temperature=temperature,
        )

        self.output_parser = PydanticOutputParser(pydantic_object=ArticleTypeValues)
        self.prompt_template = SimplePromptTemplate(
            template=ARTICLE_TYPE_EXTRACTOR_OUTPUT_PARSER_TEMPLATE,
            partial_variables={"format_instructions": self.output_parser.get_format_instructions()},
        )

    def get(self, question: str) -> str:
        question_prompt = self.prompt_template.format(question=question)
        output = self.model.invoke(question_prompt)
        result = self.output_parser.invoke(output)
        if not result.ArticleType:
            raise ValueError("No article type found in the response of ArticleTypeExtractor.")
        return result.ArticleType.value
