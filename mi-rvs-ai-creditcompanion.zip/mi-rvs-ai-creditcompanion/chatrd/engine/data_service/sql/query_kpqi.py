"""This module includes all the SQL queries to pull KPQIs and Lookup values about
screener"""

query_to_pull_company_KPQI = f"""WITH SearchTag_Cte AS 
 
(
 
    SELECT 
 
        keyproductQUeryItem as KPQI, [Tag1], [Tag2], [Tag3], [Tag4], [Tag5] 
 
    FROM
 
        (
 
            SELECT 
 
                keyproductQUeryItem, 
 
                ProductQueryItemSearchAlias, 
 
                'Tag' + CAST(ROW_NUMBER() OVER(PARTITION BY keyproductQUeryItem ORDER BY ProductQueryItemSearchAlias DESC) AS nvarchar) AS TAG 
 
            FROM 
 
                ObjectViews..LiveMetadataQueryItemSrch
 
        ) P
 
        PIVOT(
 
            MIN(ProductQueryItemSearchAlias) FOR TAG IN ([Tag1], [Tag2], [Tag3], [Tag4], [Tag5])
 
        ) AS Tags
 
)
 
SELECT
 
    COALESCE(t0_0.ProductCaptionOverride, t0_0.ProductCaption, t7_0.ProductCaption, t9_0.ProductCaptionOverride, t9_0.ProductCaption,t10_0.ProductCaption) AS Caption,
    t0_0.KeyItem, t0_0.SearchLookupValue, ST.Tag1, ST.Tag2, ST.Tag3, ST.Tag4, ST.Tag5, t8_0.QueryItemAlias, 
 
    ISNULL(t0_0.SearchRelevancyWeight, 0) as SearchRelevancyWeight, t0_0.KeyProductQueryItem as [KPQI]
 
 
        from dba..productqueryitems t0_0
 
        left JOIN SearchTag_Cte ST
 
        ON ST.KPQI = t0_0.keyProductQueryItem
 
        left JOIN DBA..ItemMaster t7_0 
 
        ON t7_0.KeyItem = t0_0.KeyItem and t7_0.UpdOperation < 2
        left JOIN DBA..QueryItemAlias t8_0
        ON t8_0.KeyProductQueryItem = t0_0.KeyProductQueryItem  and t8_0.UpdOperation < 2
        LEFT JOIN DBA..productqueryitems t9_0
        ON t9_0.KeyProductQueryItem = t0_0.KeyProductQueryItemCrossData
        LEFT JOIN DBA..ItemMaster t10_0 
        ON t10_0.KeyItem = t9_0.KeyItem and t10_0.UpdOperation < 2
WHERE
 
    t0_0.TreeId = {key_perspective} AND
    t0_0.UpdOperation < 2 AND 
    t0_0.MaskProductQueryItemDisplay & POWER(2,1) = 0    AND 
    t0_0.keyproductqueryitemdisplay is null  """
