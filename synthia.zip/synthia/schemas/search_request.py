from typing import List, Optional, Union
from pydantic import BaseModel, Field


class ProcessedRetrieverDates(BaseModel):
    """Schema for extracted dates from user query"""
    start_date: Union[str, None]
    end_date: Union[str, None]


class SearchEntity(BaseModel):
    """Schema for search entity"""
    entity_id: Optional[int] = None
    entity_type: str
    asid: Optional[int] = None


class Entity(BaseModel):
    """Schema for entity"""
    entity_name: str
    entity_id: Optional[int] = None
    asid: Optional[int] = None
    sector: Optional[list[str]] = None
    #is_rd_entity: Optional[bool] = None


class SearchRequest(BaseModel):
    """Schema for document search request"""
    user_query: str
    entity: Optional[Entity]
    yr: Optional[int] = 1
    dt: Optional[str] = None
    processed_dates: Optional[ProcessedRetrieverDates] = None
    uc_type: Optional[str] = "general"
    article_type: Optional[str] = None
    index: str
    search_algo: Optional[str] = "hybrid"
    k: Optional[int] = 32
    reranker_k: Optional[int] = 20


class Document(BaseModel):
    """Schema for document"""
    content: str = ""
    metadata: dict = Field(default_factory=dict)
    synthesize: bool = True
