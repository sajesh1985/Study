"""LLM configuration and initialization."""

import logging
import os
from enum import Enum
from typing import Any, List, Optional, Union

from dotenv import load_dotenv
from langchain_aws import ChatBedrockConverse
from langchain_core.language_models import BaseChatModel, BaseLLM
from langchain_openai import AzureChatOpenAI

from src.synthia.aws_utils.aws_client import get_aws_client
from src.synthia.config.api_config import get_config

logger = logging.getLogger(__name__)
load_dotenv(override=True)

cfg = None


class LLMType(Enum):
    """Enum for supported LLM types."""

    CLAUDE_SONNET_3_7 = "bedrock_inference_profile_claude_3_7"
    CLAUDE_SONNET_3_5 = "bedrock_inference_profile_claude_3_5"
    CLAUDE_SONNET_4 = "bedrock_inference_profile_claude_4"
    CLAUDE_HAIKU_4_5 = "bedrock_inference_profile_claude_haiku_4_5"


def get_llm(
        temperature: float = 0.1,
        streaming: bool = False,
        callbacks: Optional[List[Any]] = None,
        llm_type: Optional[LLMType] = LLMType.CLAUDE_SONNET_3_7,
        use_llm_cache: bool = False,
) -> Union[BaseLLM, BaseChatModel]:
    """
    Initialize and return an LLM based on the configuration.

    Args:
        model_type: Type of model to use (openai, anthropic, ollama)
        temperature: Temperature setting for generation
        streaming: Whether to enable streaming responses
        callbacks: List of callbacks to use with the LLM

    Returns:
        Initialized LLM instance
    """

    try:
        global cfg
        if cfg is None:
            cfg = get_config(parameter_name="llm-config")
        
        use_spark = os.getenv("SPARK_LLM", "false").lower() in ("true", "1", "yes")
        use_bedrock = os.getenv("BEDROCK_LLM", "false").lower() in ("true", "1", "yes")
        logger.debug(f"Using Bedrock LLM: {use_bedrock}")
        logger.debug(f"Using Spark LLM: {use_spark}")
        if use_spark:
            # Initialize LLM
            logger.debug("Using Spark LLM with AzureChatOpenAI")
            llm = AzureChatOpenAI(
                azure_endpoint="https://sparkapi.spglobal.com/v1/sparkassist",  # Replace with your environment URL
                azure_deployment="gpt-4o-mini",  # Specify the deployment model
                openai_api_version="2024-02-01",  # API version
                api_key=os.getenv(
                    "SPARK_API_KEY", "SPARK KEY REQUIRED!!!"
                ),  # Replace with your actual API key,
                temperature=temperature,
                cache=use_llm_cache,
            )
        elif use_bedrock:
            model_id = cfg["bedrock_inference_profile_claude_3_7"]
            max_tokens = cfg["bedrock_claude_3_7_max_tokens"]
            if llm_type == LLMType.CLAUDE_SONNET_3_7:
                logger.debug("Using Bedrock LLM with Claude 3.7")
                model_id = cfg["bedrock_inference_profile_claude_3_7"]
                max_tokens = cfg["bedrock_claude_3_7_max_tokens"]
            elif llm_type == LLMType.CLAUDE_SONNET_3_5:
                logger.debug("Using Bedrock LLM with Claude 3.5")
                model_id = cfg["bedrock_inference_profile_claude_3_5"]
                max_tokens = cfg["bedrock_claude_3_5_max_tokens"]
                # additional_model_request_fields={
                #     "anthropic_beta": ["token-efficient-tools-2025-02-19"]
                # }
            elif llm_type == LLMType.CLAUDE_SONNET_4:
                logger.debug("Using Bedrock LLM with Claude 4")
                model_id = cfg["bedrock_inference_profile_claude_4"]
                max_tokens = cfg["bedrock_claude_4_max_tokens"]
            elif llm_type == LLMType.CLAUDE_HAIKU_4_5:
                logger.debug("Using Bedrock LLM with Claude Haiku 4")
                model_id = cfg["bedrock_inference_profile_claude_haiku_4_5"]
                max_tokens = cfg["bedrock_claude_haiku_4_5_max_tokens"]
            else:
                logger.debug("Using Bedrock LLM with Claude 3.7")

            bedrock_client = {
                "bedrock": get_aws_client("bedrock"),
                "bedrock-runtime": get_aws_client("bedrock-runtime"),
            }
            llm = ChatBedrockConverse(
                model_id=model_id,
                client=bedrock_client["bedrock-runtime"],
                temperature=temperature,
                provider="anthropic",
                cache=use_llm_cache,
                max_tokens=max_tokens,
            )
        else:
            api_key = os.getenv("OPENAI_API_KEY", "OPENAI KEY REQUIRED!!!")
            logger.debug(f"Using OpenAI LLM with api_key {api_key}")
            llm = AzureChatOpenAI(
                azure_endpoint="https://mi-di-ai-prod-01.openai.azure.com/",
                azure_deployment="gpt-4.1",
                openai_api_version="2024-12-01-preview",
                api_key=api_key,
                max_tokens=32768,
                temperature=temperature,
                max_retries=2,
                cache=use_llm_cache,
            )
        logger.info(f"llm is {llm}")

        return llm
    except Exception as e:
        logger.error(f"Error initializing LLM: {str(e)}")
        raise RuntimeError(f"Failed to initialize LLM: {str(e)}")
