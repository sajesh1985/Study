import json
import logging
from typing import List, Optional, Union

from botocore.client import BaseClient

from chatrd.core.document import Document
from chatrd.core.utils import dict_coalesce
from chatrd.engine.components.query_analyzer.entity_extractor.utils import (
    Companies,
    RevenueSource,
)
from chatrd.engine.components.query_processor.entitlements import (
    set_authorized_flag_on_documents,
)
from chatrd.engine.configuration import Constants, get_config_machinery

logger = logging.getLogger(__name__)

config_machinery = get_config_machinery()

DEFAULT_RERANKER_THRESHOLD = config_machinery.get_config_value(Constants.GeneralConstants.DEFAULT_RERANKER_THRESHOLD)
ENTITLEMENT_ACTIVE = config_machinery.get_config_value(Constants.GeneralConstants.ENTITLEMENT_ACTIVE)
BASE_ENVIRONMENT = config_machinery.get_config_value(Constants.GeneralConstants.BASE_ENVIRONMENT)


def remove_duplicates(documents: List[Document]):
    seen = {}
    unique_documents = []
    for doc in documents:
        if doc.content not in seen:
            seen[doc.content] = True
            unique_documents.append(doc)
    return unique_documents


def get_reranked_documents(
    query: str,
    retrieved_documents: List[Document],
    entity: Union[Companies, RevenueSource],
    reranker_client: BaseClient,
    reranker_endpoint_name: str,
    reranker_threshold: Optional[float] = DEFAULT_RERANKER_THRESHOLD,
    top_k_text_chunks: int = 15,
):
    retrieved_documents = remove_duplicates(retrieved_documents)

    # Separate table and non-table documents
    table_docs = [
        doc for doc in retrieved_documents if dict_coalesce(doc.metadata, ["chunk_type"], default="") == "table"
    ]
    non_table_docs = [
        doc for doc in retrieved_documents if dict_coalesce(doc.metadata, ["chunk_type"], default="") != "table"
    ]

    # rerank non-table documents only and keep top_k_text_chunks of them
    if len(non_table_docs) > 1:
        pairs = []
        for doc in non_table_docs:
            text = (
                "# Document Title : "
                + dict_coalesce(doc.metadata, ["PreferredTitle", "SourceTitle"], default="")
                + "\n"
                + "# Section Title : "
                + dict_coalesce(doc.metadata, ["chunk_title"], default="")
                + "\n"
                + (("# Entity Names : " + entity.name) if entity else "")
                + "\n"
                + "# Text : "
                + doc.content
            )
            pairs.append([query, text])

        outputs = reranker_client.invoke_endpoint(
            EndpointName=reranker_endpoint_name,
            Body=json.dumps({"pairs": pairs}),
            ContentType="application/json",
        )
        reranked_scores = json.loads(outputs["Body"].read().decode("utf-8"))

        if reranker_threshold is not None:
            reranked_scores_documents = [
                (score, obj)
                for score, obj in zip(reranked_scores["scores"], non_table_docs)
                if score >= reranker_threshold
            ]
            if len(reranked_scores_documents) == 0:
                reranked_non_table_docs = non_table_docs[: top_k_text_chunks // 2]
            else:
                sorted_data = sorted(reranked_scores_documents, key=lambda k: k[0], reverse=True)
                reranked_non_table_docs = [doc for _, doc in sorted_data]
        else:
            reranked_scores_documents = [(score, obj) for score, obj in zip(reranked_scores["scores"], non_table_docs)]
            sorted_data = sorted(reranked_scores_documents, key=lambda k: k[0], reverse=True)
            reranked_non_table_docs = [doc for _, doc in sorted_data]
    else:
        reranked_non_table_docs = non_table_docs

    # Combine untouched table docs with top_k_text_chunks reranked non-table docs
    retrieved_documents = (
        table_docs + reranked_non_table_docs[:top_k_text_chunks]
        if len(reranked_non_table_docs) > top_k_text_chunks
        else table_docs + reranked_non_table_docs
    )

    logger.info(
        f"Reranker - Number of chunks after reranker: {len(retrieved_documents)} => table chunks: {len(table_docs)} --- text chunks: {len(reranked_non_table_docs[:top_k_text_chunks]) if len(reranked_non_table_docs) > top_k_text_chunks else len(reranked_non_table_docs)}"
    )
    set_authorized_flag_on_documents(retrieved_documents, ENTITLEMENT_ACTIVE, BASE_ENVIRONMENT)

    return retrieved_documents
