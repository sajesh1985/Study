import boto3
from botocore.config import Config

from chatrd.core.aws_utils.common import assumed_session

# Cache dictionary to store clients
_sagemaker_client_cache = {}


def get_assumed_sagemaker_llm_client(role_arn: str, region_name: str):
    """
    Get a cached SageMaker runtime client using an assumed role.
    """
    cache_key = f"assumed::{role_arn}::{region_name}"
    if cache_key in _sagemaker_client_cache:
        return _sagemaker_client_cache[cache_key]

    session = assumed_session(
        role_arn=role_arn,
        session_name="AssumeRoleSession-" + region_name,
        region_name=region_name,
    )

    retry_config = Config(
        region_name=region_name,
        retries={
            "max_attempts": 10,
            "mode": "standard",
        },
        max_pool_connections=50,
    )

    sagemaker_runtime_client = session.client(
        service_name="sagemaker-runtime", config=retry_config, region_name=region_name
    )

    _sagemaker_client_cache[cache_key] = {"sagemaker-runtime": sagemaker_runtime_client}
    return _sagemaker_client_cache[cache_key]


def get_sagemaker_llm_client(region_name: str):
    """
    Get a cached SageMaker runtime client without assuming a role.
    """
    cache_key = f"default::{region_name}"
    if cache_key in _sagemaker_client_cache:
        return _sagemaker_client_cache[cache_key]

    session = boto3.Session()

    retry_config = Config(
        region_name=region_name,
        retries={
            "max_attempts": 10,
            "mode": "standard",
        },
        max_pool_connections=50,
    )

    sagemaker_runtime_client = session.client(
        service_name="sagemaker-runtime", config=retry_config, region_name=region_name
    )

    _sagemaker_client_cache[cache_key] = {"sagemaker-runtime": sagemaker_runtime_client}
    return _sagemaker_client_cache[cache_key]
