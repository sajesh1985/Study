from typing import Any, Dict, List, NamedTuple, Optional, Tuple, Union

from pydantic import BaseModel


class ScreenerPayload(NamedTuple):
    """The expected output from parsing users questions using LLMs."""

    key_perspective_str: str  # UI and QA purposes.
    key_perspective: int  # For building payload.
    payload_dict: dict  # Payload used for Data Service Endpoint.
    text_dict: dict  # Processed text for UI and QA.
    magnitude_dict: dict  # Magnitudes of numerical outputs. Returned from vector DB
    model_response_text: str  # Original model outputs.


class Analyzer(BaseModel):
    user_input: Optional[str] = ""
    uc_type: Optional[str] = ""
    ds_tag: Optional[str] = ""
    error_message: Optional[str] = ""
    response: Optional[Dict[str, Any]] = {}


class Retriever(BaseModel):
    api_data: Union[List[Dict[str, Any]], Dict] = []
    screener_payload: Dict = {}
    screener_payload_object: Optional[ScreenerPayload] = None
    url: Optional[str] = ""
    total_count: Optional[int] = 0
    api_method: Optional[str] = ""
    api_type: Optional[str] = ""


class Synthesizer(BaseModel):
    data_service_response: List[dict] = []
    source_description: List[Tuple[str, str]] = [("", "")]
    api_info: Optional[Dict[str, Any]] = {}
    error_flag: Optional[bool] = False
    template: Optional[str] = ""
    metrics_status: Optional[str] = None


class ProcessorInput(BaseModel):
    user_input: str
    uc_type: str
    entities: dict
    llm: str
    temperature: Optional[float] = 0.0
    template: Optional[str] = ""
    error_flag: Optional[bool] = False
    multi_uc_type: Optional[bool] = False
    original_language: Optional[str] = ""
    original_query: Optional[str] = ""


class ProcessorOutput(BaseModel):
    data: List[dict] = []
    filter_details: Optional[Dict[str, Any]] = {}
    key_perspective_str: Optional[str] = None
    key_perspective: Optional[int] = None
    payload_dict: Optional[Dict] = {}
    source_description: List[Tuple[str, str]] = []
    url: Optional[str] = ""
    api_info: dict = {}

    def __init__(
        self,
        retriever_output: Optional[Retriever] = None,
        synthesizer_output: Optional[Synthesizer] = None,
    ):
        if retriever_output is None and synthesizer_output is None:
            super().__init__()
            return
        elif retriever_output and retriever_output.screener_payload_object:
            filter_details = retriever_output.screener_payload_object.text_dict
            key_perspective_str = retriever_output.screener_payload_object.key_perspective_str
            key_perspective = retriever_output.screener_payload_object.key_perspective
            payload_dict = retriever_output.screener_payload_object.payload_dict

            super().__init__(
                data=synthesizer_output.data_service_response,
                filter_details=filter_details,
                key_perspective_str=key_perspective_str,
                key_perspective=key_perspective,
                payload_dict=payload_dict,
                source_description=synthesizer_output.source_description,
                url=retriever_output.url,
                api_info=synthesizer_output.api_info,
            )
        else:
            super().__init__(
                data=synthesizer_output.data_service_response,
                source_description=synthesizer_output.source_description,
                api_info=synthesizer_output.api_info,
            )
