import logging
from typing import Dict, List, Optional

from chatrd.engine.data_service.retriever import BaseRetriever
from chatrd.engine.data_service.retriever.ratings.utils import RatingsUtils
from chatrd.engine.data_service.retriever.utils import PERSPECTIVE_MAPPING
from chatrd.engine.data_service.schema import Analyzer, ProcessorInput, Retriever
from chatrd.engine.screener_api import ScreenerAPI

logger = logging.getLogger(__name__)


class RevenueSourceRatingsRetriever(RatingsUtils, BaseRetriever):
    def retrieve(
        self,
        processor: ProcessorInput = None,
        analyzer: Optional[Analyzer] = None,
        api_method: str = "POST",
        api_type: str = "screener",
    ) -> Retriever:
        entities = processor.entities
        uc_type = processor.uc_type
        key_perspective = PERSPECTIVE_MAPPING["revenue_sources"]
        key_value_pairs = self._build_value_pairs(entities, "revenue_sources")

        payload = self._payload_build(entities, key_value_pairs, key_perspective)
        response, url = ScreenerAPI().get_results_from_screener_api(payload=payload)

        df, total_count, screener_payload_object = self._post_process(
            response, entities, key_perspective, "revenue_sources", uc_type
        )

        return Retriever(
            api_data=df.to_dict(),
            screener_payload=payload,
            screener_payload_object=screener_payload_object,
            url=url,
            total_count=total_count,
            api_method=api_method,
            api_type=api_type,
        )
