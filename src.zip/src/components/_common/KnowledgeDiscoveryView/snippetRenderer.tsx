import React from 'react';
import { Snippet } from 'types/api';
import { Link } from '@spglobal/react-components';
import { ICellRendererParams } from 'ag-grid-enterprise';
import {
  SnippetGapStyle,
  SnippetStyle,
  SnippetExpandCollapseStyle,
} from './KnowledgeDiscoveryView.styles';

export const SnippetRenderer = (props: ICellRendererParams) => {
  const [expand, setExpand] = React.useState<boolean>(false);

  const snips = props.data.snippets?.map(
    (item: Snippet, index: number) =>
      (index == 0 || expand) && (
        <>
          <SnippetGapStyle />
          <SnippetStyle key={index}>{item.text}</SnippetStyle>
        </>
      )
  );

  return (
    <>
      <Link href={`${props.data.url}`} target="_blank">
        {props.value}
      </Link>
      {snips}
      {props.data.snippets.length > 1 && (
        <SnippetExpandCollapseStyle
          onClick={() => {
            setExpand(!expand);
            // expand && props.api.resetRowHeights();
          }}
        >
          {expand ? '...less' : `+ ${parseInt(props.data.snippets.length) - 1} more`}
        </SnippetExpandCollapseStyle>
      )}
    </>
  );
};
