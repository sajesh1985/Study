﻿namespace Fis.Epp.Fusion.WebAPI.Controllers
{
    using Carbon.Branding;
    using Fis.Epp.Fusion.WebAPI.Common;
    using Fis.Epp.Fusion.WebAPI.Models;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Options;
    using System.IdentityModel.Tokens.Jwt;
    using System.Linq;
    using System.Security.Claims;
    public abstract class BaseController : Controller
    {
        #region Private Properties
        /// <summary>
        /// Gets or sets the AppSettings configurations.
        /// </summary>
        private AppSettings AppSettings;
        #endregion
        public BaseController(IOptions<AppSettings> settings)
        {
            AppSettings = settings.Value;
        }

        #region Protected methods
        /// <summary>Validate JwtAccess Token recieved from SSO.</summary>
        /// <param name="token"></param>
        /// <returns>Whether token is valid or not.</returns>
        protected bool ValidateJwtAccessToken(string token)
        {
            ClaimsPrincipal claimsPrincipal = new ClaimsPrincipal();
            if (!string.IsNullOrEmpty(token))
            {
                claimsPrincipal = JwtHelper.ValidateSymmetricToken(AppSettings.TokenSigningKey, token);
            }
            return claimsPrincipal != null && claimsPrincipal.Claims.Count() > 0;


        }

        protected string ResolveJwtTokenValue(string token)
        {
            JwtSecurityToken jwtSecurityToken = new JwtSecurityToken();
            if (!string.IsNullOrEmpty(token))
            {
                if (ValidateJwtAccessToken(token))
                {
                    jwtSecurityToken = JwtHelper.ReadToken(token);
                    if (jwtSecurityToken != null && jwtSecurityToken.Claims.Count() > 0)
                    {
                        return jwtSecurityToken.Claims.First(claim => claim.Type == "FeId").Value;
                    }
                }
            }
            return string.Empty;
        }
        protected ResourceContext ResourceContext
        {
            get
            {
                BrandingContext brandingContext = new BrandingContext(HttpContext);
                if (BrandingManager.Brands.Contains(BrandValue))
                {
                    brandingContext.SetBrand(BrandValue);
                }
                else
                {
                    Brand brand = BrandingManager.Brands.Lookup(BrandValue).FirstOrDefault();
                    if (brand != null)
                    {
                        brandingContext.SetBrand(brand);
                    }
                }

                var resourceContext = new ResourceContext(ResourceNamespace, brandingContext);
                resourceContext.Items.Add("ResourcesBasePath", AppSettings.ResourcesPath);

                return resourceContext;
            }
        }

        protected string ResourceNamespace
        {
            get
            {
                if (ControllerContext.RouteData.Values["name"] == null)
                {
                    return string.Empty;
                }
                return string.Format("{0}", ControllerContext.RouteData.Values["name"].ToString());
            }
        }

        protected string ResolveBrandFilter(ProductCode productCode)
        {
            switch (productCode)
            {
                case ProductCode.BillPay:
                    return "PP_";
                case ProductCode.PeoplePay:
                    return "BP_";
                default:
                    return string.Empty;
            }
        }

        protected string BrandValue
        {
            get
            {
                string brandValue = string.Empty;
                if (ControllerContext.HttpContext.Request.Headers[RequestHeader.SessionToken.GetEnumDescription()] != string.Empty)
                {
                    brandValue = ResolveJwtTokenValue(ControllerContext.HttpContext.Request.Headers[RequestHeader.SessionToken.GetEnumDescription()]);
                    return brandValue;
                }
                return brandValue;
            }
        }

        protected string ProductValue
        {
            get
            {
                if (ControllerContext.RouteData.Values["product"] == null)
                {
                    return string.Empty;
                }
                return string.Format("{0}", ControllerContext.RouteData.Values["product"].ToString());
            }
        }
        #endregion
    }
}