import logging
from typing import Dict, List, Union

from botocore.client import BaseClient
from pydantic import BaseModel

from chatrd.core.document import Document, TableDocument
from chatrd.core.vectorstore import OpenSearch
from chatrd.engine.components.query_analyzer.entity_extractor.utils import (
    Companies,
    Entities,
    RevenueSource,
)
from chatrd.engine.components.query_processor.query_retriever.data_service_retriever import (
    call_data_service,
)
from chatrd.engine.components.query_processor.query_retriever.uc_retrievers.base import (
    UCRetriever,
)
from chatrd.engine.components.query_processor.query_retriever.utils import (
    add_structured_source,
)
from chatrd.engine.configuration import Constants, get_config_machinery

logger = logging.getLogger(__name__)

config_machinery = get_config_machinery()


class ScoresModifierRetriever(UCRetriever):
    def __init__(self, vector_stores_dict: Dict[str, OpenSearch], reranker_client: BaseClient):
        self.vector_stores_dict = vector_stores_dict
        self.reranker_client = reranker_client

    def retrieve(
        self,
        query: str,
        entities: Entities,
        model_name_for_data_service: str,
        temperature_for_data_service: float,
        sectors: BaseModel,
        original_language: str,
        original_query: str,
        multi_uc_type: bool = False,
    ):
        data_service_documents = []
        data_service_documents = call_data_service(
            query=query,
            model_name_for_data_service=model_name_for_data_service,
            entities=entities,
            uc_type="scores&modifiers",
            sectors=sectors,
            multi_uc_type=multi_uc_type,
            original_language=original_language,
            original_query=original_query,
        )
        data_service_documents = add_structured_source(data_service_documents)
        query_documents = self._combine_documents(
            structured_documents=data_service_documents, unstructured_documents=[]
        )
        logger.info(f"Total number of retrieved documents : {len(query_documents)}")
        return query_documents

    def vector_db_retrieval(self, query: str, entity: Union[Companies, RevenueSource]):
        pass

    def _combine_documents(
        self, structured_documents: Union[Document, TableDocument], unstructured_documents: List[Document]
    ) -> Union[List[Document], TableDocument]:
        if structured_documents and unstructured_documents:
            combined_result_document = []
            combined_result_document.extend(structured_documents)
            combined_result_document.extend(unstructured_documents)
            return combined_result_document
        elif structured_documents:
            return structured_documents
        elif unstructured_documents:
            return unstructured_documents
        else:
            return []
