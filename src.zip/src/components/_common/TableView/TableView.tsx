import React from 'react';
import { AgGridStyle, ExportWrapperStyle } from './TableView.styles';
import { GetContextMenuItemsParams, ITooltipParams, LicenseManager } from 'ag-grid-enterprise';
import { config } from '@spglobal/spa';
import { TableColumnNode, TableResponseNode } from 'types/api';
import { Button, NotificationType, useNotification } from '@spglobal/react-components';
import { Purpose, Size } from '@spglobal/koi-helpers';
import { exportResult } from '../../../services/api';
import { useChatRD } from '../../../context/chatrd';
const AG_GRID_LICENSE_KEY = config('agGridLicenseKey');
LicenseManager.setLicenseKey(AG_GRID_LICENSE_KEY);

interface TableViewProps extends React.ComponentPropsWithoutRef<'div'> {
  columns: TableResponseNode['columns'];
  rows: TableResponseNode['rows'];
  interactionId:string;
  totalcount:string;
  isSFDeal?:boolean;
}

export const TableView: React.FC<TableViewProps> = ({ columns, rows,interactionId,totalcount,isSFDeal}:TableViewProps) => {
  const [gridApi, setGridApi] = React.useState(null);
  let { setGridContext,payLoad } = useChatRD();
  const onGridReady = (params: any) => {
    setGridApi(params.api);
    if(params.api.context)
    {
        setGridContext(params.api,interactionId);
    }
    
  };

  function headerHeightGetter() {
    var columnHeaderTexts = [
        ...document.querySelectorAll('.ag-header-cell-text'),
    ];
    var clientHeights = columnHeaderTexts.map(
        headerText => headerText.clientHeight
    );
    var tallestHeaderTextHeight = Math.max(...clientHeights);

    return tallestHeaderTextHeight;
  }

  const headerHeightSetter = (params: any) => {
    var padding = 20;
    var height = headerHeightGetter() + padding;
    params.api.setHeaderHeight(height);
  };

  var headerComponentParams = {
    template:
      '<div class="ag-cell-label-container" role="presentation">' +
      '  <span ref="eMenu" class="ag-header-icon ag-header-cell-menu-button"></span>' +
      '  <div ref="eLabel" class="ag-header-cell-label" role="presentation">' +
      '    <span ref="eSortOrder" class="ag-header-icon ag-sort-order"></span>' +
      '    <span ref="eSortAsc" class="ag-header-icon ag-sort-ascending-icon"></span>' +
      '    <span ref="eSortDesc" class="ag-header-icon ag-sort-descending-icon"></span>' +
      '    <span ref="eSortNone" class="ag-header-icon ag-sort-none-icon"></span>' +
      '    <span ref="eText" class="ag-header-cell-text" role="columnheader" style="white-space: normal;"></span>' +
      '    <span ref="eFilter" class="ag-header-icon ag-filter-icon"></span>' +
      '  </div>' +
      '</div>',
  };

  const { addNotification } = useNotification() || {};

  
  const exlExport = async (interactionId:any,totalcount:any) => {
    addNotification("Export started: may take more than 2 mins", NotificationType.INFO);
    let payInt = payLoad.find(x=>x.interactionId == interactionId);
    if(payInt)
    {
      if(parseInt(totalcount) < 15)
        {
          gridApi.exportDataAsExcel();
        }
        else
        {
          var resp =await exportResult(payInt.payload);
          addNotification("Export completed", NotificationType.SUCCESS);
          if(resp)
          {
            window.open(resp.message,"_blank");
          }
          else
          {
            gridApi.exportDataAsExcel();
          }
        }
    }
    else
    {
      gridApi.exportDataAsExcel();
    }
    
  };

  return (
    <div>
      <ExportWrapperStyle>
        { !isSFDeal ? (<Button size={Size.MEDIUM} purpose={Purpose.SECONDARY} onClick={() => exlExport(interactionId,totalcount)}>
          Excel Export
        </Button>): ''}
      </ExportWrapperStyle>
      <AgGridStyle
        enableRangeSelection={true}
        suppressContextMenu={false}
        isAutoHeight={true}
        onColumnResized={() => {
          document.body.classList.remove('chatRDCustom');
          setTimeout(() => document.body.classList.add('chatRDCustom'), 2000);
        }}
        defaultCsvExportParams={{
          fileName: 'TableCsvExport',
        }}
        defaultExcelExportParams={{
          fileName: 'TableExlExport',
          processCellCallback: params => {
            if(params.value != null && params.value.toString().includes('<a '))
            {
                return params.value.toString().split('>')[1].split('<')[0];
            }
            else
            {
               return params.value;
            }
          }
        }}
        getContextMenuItems={(params: GetContextMenuItemsParams) => {
          return [
            'copy',
            'copyWithHeaders',
            'separator',
            {
              name: 'Excel Export',
              action: () => params.api.exportDataAsExcel(),
            },
          ];
        }}
        defaultColDef={{
          sortable: true,
          wrapText: true,
          autoHeight: true,
          resizable: true,
          filter: true,
          headerComponentParams: headerComponentParams,
        }}
        columnDefs={columns.map((data: TableColumnNode,index:number) => {
          const headerName = data.name.toUpperCase();
          const defaultOptions = {
            field: data.name in rows[0] ? data.name: data.name[0].toLowerCase() + data.name.substring(1),
            cellRenderer: function(params:any) {
              return params.value;
            },
            headerName: headerName,
            tooltipValueGetter: (p: ITooltipParams) => {
              if(p.value != null && p.value.toString().includes('<a '))
                {
                    return p.value.toString().split('>')[1].split('<')[0];
                }
                else 
                {
                  return p.value;
                }
            },
            headerTooltip: headerName,
            minWidth:index == 0 ? 300:150,
            pinned:index==0?true:false,
            type: data.type == 'date' || data.type == 'number' ? 'rightAligned' : 'leftAligned',
            filter:
              data.type == 'number'
                ? 'agNumberColumnFilter'
                : data.type == 'date'
                ? 'agDateColumnFilter'
                : 'agTextColumnFilter',
          };
          return defaultOptions;
        })}
        onGridReady={onGridReady}
        onFirstDataRendered = {headerHeightSetter}
        isMobileAutoSize
        rowData={rows}
      />
    </div>
  );
};
