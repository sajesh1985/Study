"""Document service for handling S3 uploads, deletions, and knowledge base synchronization."""
import asyncio
import os
import time
import boto3
import io
import json
import logging
from typing import Dict, Any, BinaryIO
from fastapi import UploadFile

from src.synthia.aws_utils.aws_client import (
    get_aws_client,
    get_secret,
    get_env_specific_secret_key,
)
from src.synthia.config.api_config import get_config
from src.synthia.excel_prop_data.extraction.extractor import extract
from src.synthia.persistence import document_queries, excel_queries
from src.synthia.utils.aws_secrets import get_secrets
from src.synthia.utils.logging_config import configure_logging

logger = configure_logging(logger_name=__name__)

class DocumentService:
    def __init__(self):
        self.cfg = get_config()
        self.bedrock_kb_id_key = self.cfg["bedrock_kb_id_key"]
        self.bedrock_kb_datasource_id_key = self.cfg["bedrock_kb_datasource_id_key"]
        self.propdata_s3_bucket_key = self.cfg["propdata_s3_bucket_key"]
        self.template_s3_bucket_key = self.cfg["template_s3_bucket_key"]
        self.ALLOWED_EXTENSIONS = {".pdf", ".docx", ".txt", ".xlsx"}

    async def _get_secrets(self) -> Dict[str, Any]:
        """Get secrets from AWS Secrets Manager."""
        return await asyncio.to_thread(get_secrets)

    async def validate_and_get_s3_details(self, filename: str, file_size: int) -> (str, str):
        """
        Validate the document and determine S3 bucket and prefix.

        Returns:
            tuple: (bucket_name, s3_prefix)
        """
        ext = self.validate_document(filename, file_size)
        bucket_key = self.propdata_s3_bucket_key
        s3_prefix = "report_documents/"

        if ext == ".xlsx":
            logger.info("Excel file detected, checking for template match.")
            templates = await document_queries.get_template_metadata(filename)
            logger.info("Template metadata fetched: %s", len(templates))
            if templates:
                bucket_key = self.template_s3_bucket_key
                s3_prefix = "template_documents/"

        synthia_secret = await self._get_secrets()
        bucket_name = synthia_secret[get_env_specific_secret_key(bucket_key)]

        return bucket_name, s3_prefix

    async def upload_document(
        self,
        file: UploadFile,
        file_id: str,
        keyonlineuser: int,
        section_title: list,
        job_id: str,
    ) -> Dict[str, Any]:
        try:
            ext = self.validate_document(file.filename, file.size)
            is_excel = False

            if ext == ".xlsx":
                logger.info("Excel file detected, checking for template match.")
                is_excel = await self.check_and_extract_excel(file.filename, file.file, file_id, job_id)

            s3_status = await self.upload_document_to_s3(file, file_id, job_id, keyonlineuser, section_title, is_excel)
            logger.info(f"S3 upload status: {s3_status}")
            if not s3_status['success']:
                raise ValueError(f"File upload failed: {s3_status.get('error')}")

            doc = {
                "file_name": file.filename,
                "s3_uri": s3_status['s3_uri'],
                "keyonlineuser": keyonlineuser,
                "section_title": json.dumps(section_title),
                "id": file_id,
                "file_size": file.size,
                "file_type": ext,
                "job_id": job_id,
                "status": "completed",
            }
            query_status = await document_queries.save_document_record(doc)
            logger.info(f"Document record save status: {query_status}")

            if not is_excel:
                kb_status = await self.synchronize_knowledge_base()
                if not kb_status['success']:
                    logger.error(f"Knowledge base synchronization failed: {kb_status.get('error')}")
            else:
                logger.info("Skipping knowledge base synchronization for Excel template.")

            return {"success": True, "message": f"Successfully uploaded {file.filename} file."}

        except Exception as e:
            logger.error(f"Error uploading document: {str(e)}")
            return {"success": False, "error": str(e)}

    async def check_and_extract_excel(self, filename: str, file: BinaryIO, file_id: str, job_id: str):
        """
        Check if the Excel file matches a template then extract and save data if it does exist.

        Returns:
            bool: True if the file is a recognized Excel template and data extraction was performed, False
        """
        templates = await document_queries.get_template_metadata(filename)
        logger.info("Template metadata fetched: %s", len(templates))
        is_excel = False
        if templates:
            logger.info("excel file matches with excel template metadata in database.")
            is_excel = True
            logger.info("templates data from db: %s", templates)
            config_path = templates[0][5]
            logger.info("config filename from db: %s", config_path)
            config = await self.get_config_file(config_path)
            logger.info("running data extraction for excel template.")
            file.seek(0)  # Reset file pointer to the beginning
            extracted_data = extract(config, file)
            logger.info("Data extraction completed. sheets extracted: %s", len(extracted_data) if extracted_data else 0)
            if extracted_data:
                records = []
                for sheet in extracted_data:
                    logger.debug("sheet name %s", sheet.get("sheet_name"))
                    for table in sheet.get("tables", []):
                        logger.debug("table_name name %s", table.get("table_name"))
                        table_name = table.get("table_name")
                        table_data = table.get("metrics")
                        records.append({
                            "jobid": job_id,
                            "fileid": file_id,
                            "table_name": table_name,
                            "table_json": table_data,
                        })

                await excel_queries.save_job_file_map_record(records)
            logger.info("successfully extracted data from excel file")
        return is_excel

    async def upload_document_to_s3(
        self,
        file: UploadFile,
        file_id: str,
        job_id: str,
        username: int,
        section_title: list,
        is_excel: bool = False,
        s3_prefix: str = "report_documents/",
    ) -> Dict[str, Any]:
        """
        Upload a document to S3 and return its S3 URI.
        """
        if is_excel:
            bucket_key = self.template_s3_bucket_key
            s3_prefix = "template_documents/"
        else:
            bucket_key = self.propdata_s3_bucket_key

        s3 = boto3.client("s3", region_name="us-east-1")
        s3_key = f"{s3_prefix}{file_id}_{file.filename}"
        metadata_json_key = s3_key + ".metadata.json"
        ext = os.path.splitext(file.filename)[1].lower()

        synthia_secret = await self._get_secrets()
        propdata_s3_bucket = synthia_secret[get_env_specific_secret_key(bucket_key)]
        bucket = propdata_s3_bucket

        try:
            # Prepare metadata for S3 object
            metadata = {
                "userId": username,
                "fileId": str(file_id),
                "jobId": str(job_id),
                "type": ext,
                "sectionTitle": section_title
            }

            # S3 metadata keys must be lowercase strings
            metadata = {str(k).lower(): str(v) for k, v in metadata.items()}

            file.file.seek(0)  # Ensure the file pointer is at the start
            s3.upload_fileobj(file.file, bucket, s3_key, ExtraArgs={"Metadata": metadata})

            # Prepare metadata JSON
            metadata_json = {
                "metadataAttributes": {
                    "userId": username,
                    "fileId": str(file_id),
                    "jobId": str(job_id),
                    "type": ext,
                    "sectionTitle": section_title
                }
            }

            metadata_bytes = io.BytesIO(json.dumps(metadata_json).encode("utf-8"))

            # Upload the metadata JSON file
            s3.upload_fileobj(metadata_bytes, bucket, metadata_json_key, ExtraArgs={"Metadata": metadata})

            return {"success": True, "s3_uri": f"s3://{bucket}/{s3_key}"}
        except Exception as e:
            logger.error(f"Failed to upload document: {str(e)}")
            return {"success": False, "error": str(e)}

    async def update_document_complete(self, keyonlineuser, file_data):
        try:
            s3_uri = file_data["s3_uri"]
            s3_uri = s3_uri.replace("s3://", "")
            bucket, path = s3_uri.split("/", 1)

            s3 = boto3.client("s3", region_name="us-east-1")

            response = s3.get_object(Bucket=bucket, Key=path)
            file = response['Body'].read()

            ext = os.path.splitext(file_data["file_name"])[1].lower()
            is_excel = False

            if ext == ".xlsx":
                file = io.BytesIO(file)
                is_excel = await self.check_and_extract_excel(file_data["file_name"], file, file_data["id"], file_data['job_id'])

            if not is_excel:
                s3_status = await self.update_metadata_file(
                    file_data['id'], file_data['job_id'], keyonlineuser, json.loads(file_data["section_title"]), path,
                    file_data["file_type"])

                if not s3_status['success']:
                    logger.error(f"Failed to update metadata for file_id {file_data['id']}: {s3_status.get('error')}")

            return {"success": True, "message": f"Document processing complete for file id {file_data['id']}.", "is_excel": is_excel}
        except Exception as e:
            logger.error(f"Error updating document complete: {str(e)}")
            return {"success": False, "error": str(e)}

    async def get_config_file(self, path: str):
        s3 = boto3.client("s3")
        logger.info("Fetching config file from S3")

        synthia_secret = await self._get_secrets()
        propdata_s3_bucket = synthia_secret[get_env_specific_secret_key(self.template_s3_bucket_key)]
        bucket = propdata_s3_bucket

        try:
            response = s3.get_object(Bucket=bucket, Key=path)
            logger.info("Config file fetched from S3, decoding content")
            json_content = json.loads(response['Body'].read().decode('utf-8'))
            logger.info("Config file converted to JSON")
        except Exception as e:
            logger.error(f"Failed to fetch config file from S3: {str(e)}")
            raise

        return json_content

    async def update_metadata_file(
            self,
            file_id: str,
            job_id: str,
            username: int,
            section_title: list,
            s3_key: str,
            ext: str,
    ) -> Dict[str, Any]:
        """
        Upload a document to S3 and return its S3 URI.
        """
        s3 = boto3.client("s3", region_name="us-east-1")
        metadata_json_key = s3_key + ".metadata.json"

        synthia_secret = await self._get_secrets()
        propdata_s3_bucket = synthia_secret[get_env_specific_secret_key(self.propdata_s3_bucket_key)]
        bucket = propdata_s3_bucket

        try:
            metadata = {
                "userId": username,
                "fileId": str(file_id),
                "jobId": str(job_id),
                "type": ext,
                "sectionTitle": section_title
            }

            metadata_json = {
                "metadataAttributes": metadata
            }

            metadata = {str(k).lower(): str(v) for k, v in metadata.items()}

            metadata_bytes = io.BytesIO(json.dumps(metadata_json).encode("utf-8"))

            # Upload the metadata JSON file
            s3.upload_fileobj(metadata_bytes, bucket, metadata_json_key, ExtraArgs={"Metadata": metadata})

            return {"success": True}
        except Exception as e:
            logger.error(f"Failed to upload document: {str(e)}")
            return {"success": False, "error": str(e)}

    async def delete_documents_by_username(
        self,
        username: str,
        aws_region: str
    ) -> Dict[str, Any]:
        """
        Delete all documents from S3 that have metadata attribute userId equal to the given username.
        """
        synthia_secret = await self._get_secrets()
        propdata_s3_bucket = synthia_secret[get_env_specific_secret_key(self.propdata_s3_bucket_key)]
        bucket = propdata_s3_bucket
        s3 = boto3.client("s3", region_name=aws_region)

        try:
            # List all objects in the bucket
            objects = s3.list_objects_v2(Bucket=bucket)
            deleted_keys = []

            contents = objects.get("Contents", [])
            if contents:
                for obj in contents:
                    key = obj["Key"]
                    # Get object metadata
                    head = s3.head_object(Bucket=bucket, Key=key)
                    logger.info(f"S3 Key: {key}, Metadata: {head.get('Metadata', {})}")
                    metadata = head.get("Metadata", {})
                    # S3 metadata keys are lowercase
                    if metadata.get("userid") == username:
                        s3.delete_object(Bucket=bucket, Key=key)
                        deleted_keys.append(key)

            return {
                "success": True,
                "deleted_keys": deleted_keys,
                "message": f"Deleted {len(deleted_keys)} objects for username={username}"
            }
        except Exception as e:
            logger.error(f"Failed to delete documents: {str(e)}")
            return {"success": False, "error": str(e)}

    async def synchronize_knowledge_base(self) -> Dict[str, Any]:
        """
        Synchronize the knowledge base by uploading documents to S3.
        """
        bedrock_client = get_aws_client("bedrock-agent")
        synthia_secret = await self._get_secrets()

        bedrock_kb_id = synthia_secret[get_env_specific_secret_key(self.bedrock_kb_id_key)]
        bedrock_kb_datasource_id = synthia_secret[get_env_specific_secret_key(self.bedrock_kb_datasource_id_key)]
        data_source_id = bedrock_kb_datasource_id

        logger.info("Starting knowledge base synchronization bedrock_kb_id: %s, data_source_id: %s", bedrock_kb_id, data_source_id)

        try:
            response = bedrock_client.start_ingestion_job(
                dataSourceId=data_source_id,
                knowledgeBaseId=bedrock_kb_id
            )
            ingestion_job_id = response["ingestionJob"]["ingestionJobId"]

            # Poll the ingestion job status every 10 seconds until it completes or fails
            while True:
                status_response = bedrock_client.get_ingestion_job(
                    dataSourceId=data_source_id,
                    ingestionJobId=ingestion_job_id,
                    knowledgeBaseId=bedrock_kb_id
                )
                status = status_response["ingestionJob"]["status"]
                if status in ["COMPLETE", "FAILED", "STOPPED"]:
                    break
                time.sleep(10)

            if status == "COMPLETE":
                logger.info(f"Knowledge base synchronized successfully with job ID: {ingestion_job_id}")
                return {"success": True, "message": "Knowledge base synchronized successfully"}
            else:
                raise Exception("Document was uploaded but embedding process failed")
        except Exception as e:
            logger.error(f"Failed to synchronize knowledge base: {str(e)}")
            return {"success": False, "error": str(e)}

    def validate_document(self, filename: str, file_size: int) -> str:
        """
        Validates the file's name, type, and size.

        Raises ValueError on any validation failure.
        """
        if not filename:
            raise ValueError("Filename must be provided.")

        ext = os.path.splitext(filename)[1].lower()
        if ext not in self.ALLOWED_EXTENSIONS:
            raise ValueError(f"Unsupported file extension: {ext}")

        max_file_size = self.cfg.get("max_file_size_mb")
        max_file_size = max_file_size if max_file_size else 20  # Default to 20 MB if not set

        if file_size > max_file_size * 1024 * 1024:
            raise ValueError(f"File size exceeds limit of {max_file_size} MB.")

        return ext