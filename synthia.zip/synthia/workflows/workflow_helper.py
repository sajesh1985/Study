import os
import asyncio
from typing import Any, List, Optional
import traceback
from langgraph.types import Command
import logging
from datetime import datetime
from src.synthia.agents.agent_factory import AgentFactory
from src.synthia.schemas.workflow import ReportConfig, ReportStatus, ReportStatusEnum, ReportSection
from src.synthia.utils.logging_config import configure_logging
from src.synthia.workflows.simple_graph import create_report_graph
from src.synthia.agents.report_builder import ReportBuilder
from src.synthia.persistence.report_monitor import ReportMonitor
from src.synthia.aws_utils.aws_client import get_aws_client, get_secret, get_env_specific_secret_key
from src.synthia.config.api_config import get_config
from src.synthia.utils.helper import renew_access_token
from src.synthia.persistence.prompt_monitor import get_prompt_monitor
from src.synthia.persistence.report_monitor import get_monitor
from src.synthia.schemas.workflow import PromptStatusEnum
from decimal import Decimal
from langgraph.types import Interrupt
from src.synthia.config.api_config import get_config
from langfuse.langchain import CallbackHandler

# Initialize logger using centralized configuration
logger = configure_logging(
    logger_name=__name__,
    log_file="synthia.log",
    module_levels={__name__: logging.DEBUG},  # Set this module to DEBUG
)


class ReportWorkflow:
    def __init__(self, graph, initial_state, agent_factory: AgentFactory, config=None):
        self.graph = graph
        self.initial_state = initial_state
        self.agent_factory = agent_factory
        self.config = config
        self.thread_id = None

    @classmethod
    async def create_workflow(
        cls, data: ReportConfig, callbacks: Optional[List[Any]] = None, status_tracker: Optional[ReportMonitor] = None
    ):
        job_id = data["job_id"]
        logger.info(f"[job_id={job_id}] Creating LangGraph report for report config: {data}")

        if callbacks is None:
            callbacks = []

        thread_id = data["job_id"]
        config = {"configurable": {"thread_id": thread_id}, "callbacks": callbacks}

        if data["auth_token"]:
            auth_token = data["auth_token"]
        else:
            auth_token = os.getenv("MCP_AUTH_TOKEN")

        
        cfg = get_config()
        langfuse_enabled = cfg.get("langfuse_enabled_env_var")
        if isinstance(langfuse_enabled, bool):
            is_lf_enabled = langfuse_enabled
        elif isinstance(langfuse_enabled, str):
            is_lf_enabled = langfuse_enabled.lower() == "true"
        else:
            is_lf_enabled = False
        if is_lf_enabled:
            # centralise callbacks later
            langfuse_handler = CallbackHandler()
            callbacks.append(langfuse_handler)

        agent_factory = AgentFactory(auth_token, callbacks=callbacks)
        thread_config = {"callbacks": callbacks, "thread_id": thread_id}
        thread_config.update({"metadata": {"langfuse_session_id": thread_id}})
        report_builder = ReportBuilder(agent_factory, thread_config)
        graph = await create_report_graph(report_builder=report_builder, report_monitor=status_tracker)

        # Initialize the graph with the starting state
        initial_state = {
            "report_config": data,
            "current_section_idx": 0 if data.get("approved_outline") else None,
            "status": "initializing",
            "progress": 0.0,
            "error": None,
            "human_approved_outline": (True if data.get("approved_outline") else False),
            "human_approved_report": False,
            "human_feedback_report": None,
            "job_id": data["job_id"],
            "report_outline": [],
            "all_sections": [],
            "prompt_mode": False,
            "current_edit_request": None,
            "current_target_section_name": None,
            "current_edited_section": None,
            "current_user_action": None,
            "current_prompt_id": None,
            "current_user_section_prompt": None,
        }
        return cls(graph, initial_state, agent_factory, config)

    async def _get_secrets(self):
        secrets_manager_client = get_aws_client("secretsmanager")
        cfg = get_config()
        synthia_secret = await asyncio.to_thread(get_secret, secrets_manager_client, cfg.get("secrets_name"))
        return synthia_secret

    async def _renew_access_token(self, refresh_token: str, job_id: str = "unknown") -> str:
        synthia_secret = await self._get_secrets()
        cfg = get_config()
        client_secret = synthia_secret.get(
            get_env_specific_secret_key(cfg.get("oauth_client_secret_key"))
        )
        client_id = synthia_secret.get(
            get_env_specific_secret_key(cfg.get("oauth_client_id_key"))
        )
        logger.info(f"[job_id={job_id}] Fetched client_id :: {client_id} and client_secret :: {client_secret}")
        token = await renew_access_token(
            refresh_token=refresh_token,
            client_id=client_id,
            client_secret=client_secret,
        )
        logger.info(f"[job_id={job_id}] New token obtained :: {str(token)[:50]}")
        return token

    async def start_workflow(self, status_tracker: Optional[ReportMonitor] = None):
        """Start the workflow and handle all initial scenarios."""
        self.thread_id = self.config["configurable"]["thread_id"]
        job_id = self.thread_id

        try:
            logger.info(f"[job_id={job_id}] Starting workflow with thread_id: {self.thread_id}")

            # Renew the access token if refresh_token is available
            if self.initial_state["report_config"].get("refresh_token") is not None:
                auth_token = await self._renew_access_token(
                    refresh_token=self.initial_state["report_config"].get("refresh_token"),
                    job_id=job_id
                )
                self.initial_state["report_config"]["auth_token"] = auth_token
            
            if status_tracker:
                await status_tracker.update_job_status(job_id, ReportStatusEnum.CREATING_OUTLINE)
             
              

            result = await self.graph.ainvoke(self.initial_state, config=self.config)

            logger.info(f"[job_id={job_id}] Detected outline approval interrupt")
            report = ReportStatus(outline=result["report_outline"], job_id=job_id, status=ReportStatusEnum.AWAITING_APPROVAL)
            if status_tracker:
                await status_tracker.update_job(job_id, report)
            logger.info(f"[job_id={job_id}] Outline generated, awaiting user approval")
            
            return result
            
        except Exception as e:
            logger.error(f"[job_id={job_id}] Error starting workflow: {str(e)}", exc_info=True)
            
            if status_tracker:
                tb = traceback.format_exc()
                await status_tracker.set_job_error(job_id, f"{str(e)}\n\nStack trace:\n{tb}")
            
            return {"error": str(e)}

    async def resume_workflow(self, user_input: Any = None, approved: bool = True, status_tracker: Optional[ReportMonitor] = None):
        """Resume workflow after any type of human input."""
        if not self.config:
            raise ValueError("Workflow not started. Call start_workflow() first.")

        self.thread_id = self.config["configurable"]["thread_id"]
        job_id = self.thread_id

        try:
            logger.info(f"[job_id={job_id}] Resuming workflow with input: {user_input}, approved: {approved}")

            if status_tracker:
                await status_tracker.update_job_status(job_id, ReportStatusEnum.CREATING_REPORT)

            if not approved and status_tracker:
                # Handle rejection - restart workflow
                logger.info(f"[job_id={job_id}] Outline rejected, restarting workflow")
                report_state = await status_tracker.get_job(job_id)
                await status_tracker.restart_job(job_id)
                
                # Create new workflow with updated config
                config = report_state.report_config
                config["job_id"] = job_id
                new_workflow = await self.create_workflow(config)
                return await new_workflow.start_workflow(status_tracker)

            use_langfuse = os.getenv("LANGFUSE_TRACING", "FALSE").upper() == "TRUE"
            if use_langfuse:
                from langfuse.langchain import CallbackHandler
                langfuse_handler = CallbackHandler()
                self.config.update({"callbacks": [langfuse_handler]})
                self.config.update({"metadata": {"langfuse_session_id": self.thread_id}})      
            
            # Renew the access token if refresh_token is available
            if self.initial_state["report_config"].get("refresh_token") is not None:
                auth_token = await self._renew_access_token(
                    refresh_token=self.initial_state["report_config"].get("refresh_token"),
                    job_id=job_id
                )
                self.initial_state["report_config"]["auth_token"] = auth_token

            result = await self.graph.ainvoke(Command(resume=user_input), config=self.config)

            logger.info(f"[job_id={job_id}] Detected chat interrupt")
            report = ReportStatus(sections=result["final_report"], job_id=job_id, status=ReportStatusEnum.COMPLETED)

            if status_tracker:
                await status_tracker.update_job(job_id, report)
            
            logger.info(f"[job_id={job_id}] Final Report generated and completed")
            
            return result

        except Exception as e:
            logger.error(f"[job_id={job_id}] Error resuming workflow: {str(e)}", exc_info=True)
            
            if status_tracker:
                tb = traceback.format_exc()
                await status_tracker.set_job_error(job_id, f"{str(e)}\n\nStack trace:\n{tb}")
            
            return {"error": str(e)}


    async def section_edit(self, user_input: Any = None, prompt_monitor = None):
        """Handle section edit prompts."""
        if not self.config:
            raise ValueError("Workflow not started. Call start_workflow() first.")

        self.thread_id = self.config["configurable"]["thread_id"]
        job_id = self.thread_id

        try:
            logger.info(f"[job_id={job_id}] Handling section edit prompt with input: {user_input}")

            prompt_id = user_input.get("prompt_id") if isinstance(user_input, dict) else None
            
            if prompt_monitor and prompt_id:
                logger.info(f"[job_id={job_id}] Updating prompt {prompt_id} to SECTION_EDIT_PROCESSING")
                await prompt_monitor.update_prompt_edit(
                    prompt_id,
                    {
                        "status": PromptStatusEnum.SECTION_EDIT_PROCESSING.value,
                        "progress": Decimal("0.5"),
                        "started_at": datetime.now(),
                    }
                )

            # Pass the input to the graph - ensure it has the action field
            if isinstance(user_input, dict):
                user_input["action"] = "edit"  # Add action for graph routing
            
            result = await self.graph.ainvoke(Command(resume=user_input), config=self.config)

            if prompt_monitor and prompt_id:
                # Extract the edited section from the result
                edited_section = None
                if isinstance(result, dict) and "__interrupt__" in result and result["__interrupt__"] and len(result["__interrupt__"]) > 0:
                     
                    interrupt_data: Interrupt = result["__interrupt__"][0]
                    if interrupt_data and interrupt_data.value["status"] == "guardrail_blocked":
                        # If blocked by guardrail, update prompt status accordingly
                        logger.info(f"[job_id={job_id}] Updating prompt {prompt_id} to SECTION_EDIT_GUARDRAIL_DECLINED")
                        await prompt_monitor.update_prompt_edit(
                            prompt_id,
                            {
                                "status": PromptStatusEnum.SECTION_EDIT_GUARDRAIL_DECLINED.value,
                                "progress": Decimal("1.0"),
                                "response": {
                                    "message": interrupt_data.value["message"],
                                    "question": interrupt_data.value["question"],
                                },
                            }
                        )
                        result_declined = await self.graph.ainvoke(Command(resume="decline"), config=self.config)
                        return {**result, **result_declined}
                    else:
                        # section edited successfully
                        edited_section = result.get("current_edited_section")
                        if edited_section:
                            logger.info(f"[job_id={job_id}] Updating prompt {prompt_id} to SECTION_EDIT_AWAITING_APPROVAL")
                            await prompt_monitor.update_prompt_edit(
                                prompt_id,
                                {
                                "status": PromptStatusEnum.SECTION_EDIT_AWAITING_APPROVAL.value,
                                "progress": Decimal("0.9"),
                                "response": {"edited_section": edited_section.model_dump() if edited_section else None},
                            }
                        )
                        else:
                            logger.warning(f"[job_id={job_id}] edited_section is empty, possibly invalid graph resume for prompt edit. {prompt_id}")
            
            return result

        except Exception as e:
            logger.error(f"[job_id={job_id}] Error handling section edit prompt: {str(e)}", exc_info=True)
            
            if prompt_monitor and prompt_id:
                await prompt_monitor.update_prompt_edit(
                    prompt_id,
                    {
                        "status": "failed",
                        "response": {"error": str(e)},
                        "completed_at": datetime.now(),
                    }
                )
            
            return {"error": str(e)}

    def replace_section_by_id(self, sections, section_id, new_section):
        """Recursively replace a section by id in a list of sections."""
        updated = []
        for section in sections:
            # If this is the section to replace
            if getattr(section, "id", None) == section_id or (isinstance(section, dict) and section.get("id") == section_id):
                updated.append(new_section)
            else:
                # If this section has nested sections, recurse
                if hasattr(section, "sections") and section.sections:
                    # For Pydantic models
                    section.sections = self.replace_section_by_id(section.sections, section_id, new_section)
                    updated.append(section)
                elif isinstance(section, dict) and section.get("sections"):
                    section["sections"] = self.replace_section_by_id(section["sections"], section_id, new_section)
                    updated.append(section)
                else:
                    updated.append(section)
        return updated

    def merge_sources(self, existing_sections: List[ReportSection], new_sources) -> List[ReportSection]:
        """
        Merge new sources into a sources list, avoiding duplicates.
        Only updates sections that already have a non-empty sources list.
        """

        def update_sources_section_with_new_sources(_sections: List[ReportSection], merged_sources):
            """Update Sources section where they are non-empty."""
            for section in _sections:
                # Only return if sources list is not empty
                sources = section.sources or []
                if sources and merged_sources:
                    section.sources = merged_sources
            return _sections

        # Find the section to get its existing sources
        def find_existing_sources(_sections: List[ReportSection]):
            """Search only at depth 1 for sections with non-empty sources."""
            for section in _sections:
                # Only return if sources list is not empty
                sources = section.sources or []
                if sources:
                    return sources

            return None

        existing_sources = find_existing_sources(existing_sections) or []

        # Merge sources: keep existing + add new ones that don't exist
        merged_sources = list(existing_sources)
        for new_source in new_sources:
            if not any(s.id == new_source.get("id") for s in merged_sources):
                merged_sources.append(new_source)

        # Update the section with merged sources
        return update_sources_section_with_new_sources(existing_sections, merged_sources)

    async def section_edit_approval(
        self,
        prompt_id: str,
        status_enum: Any,
        prompt_monitor = None,
        status_tracker=None,
    ) -> Any:
        """Handle section edit approval/decline/retry decisions."""
        if not self.config:
            raise ValueError("Workflow not started. Call start_workflow() first.")

        self.thread_id = self.config["configurable"]["thread_id"]
        job_id = self.thread_id

        try:
            logger.info(
                f"[job_id={job_id}] Handling section edit approval for prompt {prompt_id} with status {status_enum.value}"
            )

            if not prompt_monitor:
                prompt_monitor = get_prompt_monitor(self.config.get("auth_token"))
            if not status_tracker:
                status_tracker = get_monitor(self.config.get("auth_token"))
                
            prompt_edit = await prompt_monitor.get_prompt_edit(prompt_id, job_id)

            if not prompt_edit:
                logger.error(f"[job_id={job_id}] Prompt edit {prompt_id} not found")
                raise ValueError(f"Prompt edit {prompt_id} not found for job {job_id}")

            # Handle based on the approval status
            if status_enum == PromptStatusEnum.SECTION_EDIT_APPROVED:
                # Get the edited section from the prompt_edit response
                edited_section = None
                if prompt_edit.get("response") and prompt_edit.get("response", {}).get("edited_section"):
                    edited_section = prompt_edit["response"]["edited_section"]
                
                # Update the relevant section in report_jobs table
                if edited_section and status_tracker:
                    report_status = await status_tracker.get_job(job_id)
                    if report_status and hasattr(report_status, "sections") and report_status.sections:
                        if "sources" in edited_section and edited_section.get("sources", []):
                            # Merge sources into existing sources section
                            report_status.sections = self.merge_sources(report_status.sections, edited_section.get("sources", []))
                            edited_section["sources"] = []

                        # Find and replace the section by section_id
                        section_id = edited_section.get("id")
                        report_status.sections = self.replace_section_by_id(report_status.sections, section_id, edited_section)
                        report_status.report_config = report_status.report_config.model_dump()
                        await status_tracker.update_job(job_id, report_status)
                
                # Resume workflow with "accept" action
                logger.info(f"[job_id={job_id}] Section edit {prompt_id} approved")
                result = await self.graph.ainvoke(Command(resume="accept"), config=self.config)
                return result

            elif status_enum == PromptStatusEnum.SECTION_EDIT_DECLINED:
                # Resume workflow with "decline" action
                logger.info(f"[job_id={job_id}] Section edit {prompt_id} declined")
                result = await self.graph.ainvoke(Command(resume="decline"), config=self.config)
                return result

            elif status_enum == PromptStatusEnum.SECTION_EDIT_RETRY:
                # Resume workflow with retry action containing the original request
                original_request = prompt_edit.get("request")
                if not original_request:
                    logger.error(f"[job_id={job_id}] No original request found for retry of prompt {prompt_id}")
                    raise ValueError("No original request found for retry")

                logger.info(f"[job_id={job_id}] Retrying section edit {prompt_id}")

                # Resume with the retry action - the graph will use existing state
                retry_input = {
                    "action": "retry",
                    "new_edit_request": original_request.get("prompt"),
                }
                
                result = await self.graph.ainvoke(
                    Command(resume=retry_input), config=self.config
                )

                return result

            else:
                logger.error(f"[job_id={job_id}] Unsupported approval status: {status_enum}")
                raise ValueError(f"Unsupported approval status: {status_enum}")

        except Exception as e:
            logger.error(f"[job_id={job_id}] Error handling section edit approval: {str(e)}", exc_info=True)

            if prompt_monitor:
                await prompt_monitor.update_prompt_edit(
                    prompt_id,
                    {
                        "status": "failed",
                        "response": {
                            "error": str(e),
                            "edited_section": prompt_edit.get("response", {}).get("edited_section"),
                        },
                        "completed_at": datetime.now(),
                    }
                )

            return {"error": str(e)}


