import React, { useState } from 'react';
//import { useTranslation } from 'react-i18next';
import { Button, Icon, IconSize } from '@spglobal/react-components';
import { ANGLE_RIGHT } from '@spglobal/koi-icons';

import { Logo } from '../_common/Logo/Logo';
import { Page } from '../_common/Page/Page';
import { QuestionInput } from '../_common/QuestionInput/QuestionInput';
import { useChatRD } from '../../context/chatrd';
import {
  ExampleBox,
  ExampleBoxHead,
  ExampleBoxLists,
  ExampleBoxWrapper,
  ExampleList,
  FaqDesclimer,
  Header,
  NewContent,
  Status,
  Title,
} from './Landing.styles';
import { Purpose, Size } from '@spglobal/koi-helpers';
import { SplashScreen } from '../_common/Splashscreen/Splashscreen';
import { isStreamingEnabled } from '@root/utils/urlUtilities';

export const Landing: React.FC = () => {
  //const { t } = useTranslation(['chatiq_main']);
  const [hasAccepted, setHasAccepted] = useState(false);
  const { newInteraction,askQuestion } = useChatRD();

  const header = (
    <Header>
      <Logo />
      <Status>STATUS: IN TRAINING</Status>
      <Title>Here are some ways I can help you today:</Title>
    </Header>
  );

  const footer = isStreamingEnabled() ? <QuestionInput onSearch={askQuestion} /> : <QuestionInput onSearch={newInteraction} />;

  return (
    <div className="App">
      {!hasAccepted ? (
        <SplashScreen onAccept={() => setHasAccepted(true)} />
      ):(
        <Page header={header} footer={footer}>
      <NewContent>
        
        <ExampleBoxWrapper>
          <ExampleBox>
            <ExampleBoxHead>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="37"
                height="37"
                viewBox="0 0 37 37"
                fill="none"
              >
                <circle cx="18.4443" cy="18.4043" r="17.5" stroke="#525252" />
                <path
                  fillRule="evenodd"
                  clipRule="evenodd"
                  d="M18.4299 10.2441L27.7371 14.498L27.292 15.4719L26.5776 15.1454V24.6581H25.5068V16.2123H22.779V24.6581H21.7082V16.2123H18.9804V24.6581H17.9096V16.2123H15.1818V24.6581H14.111V16.2123H11.3832V24.6581H10.3124V15.1443L9.59865 15.4716L9.15234 14.4983L18.4299 10.2441ZM10.3185 15.1415H26.5692L18.4307 11.4218L10.3185 15.1415ZM27.4262 26.5628H9.47856V25.492H27.4262V26.5628Z"
                  fill="#BFBFBF"
                />
              </svg>
              <span>Analyze Markets</span>
            </ExampleBoxHead>
            <ExampleBoxLists>
              <ExampleList
                onClick={() =>
                  newInteraction(
                    'How has Microsoft stock performed YTD? How does this compare to Apple and Alphabet?'
                  )
                }
              >
                <span>
                  How has Microsoft stock performed YTD? How does this compare to Apple and
                  Alphabet?
                </span>
                <Icon icon={ANGLE_RIGHT} size={IconSize.XXXSMALL} />
              </ExampleList>
              <ExampleList
                onClick={() =>
                  newInteraction('What is the average price of Apple stock since October 2022?')
                }
              >
                <span>What is the average price of Apple stock since October 2022?</span>
                <Icon icon={ANGLE_RIGHT} size={IconSize.XXXSMALL} />
              </ExampleList>
              <ExampleList
                onClick={() =>
                  newInteraction('Summarize the most recent key development about Microsoft.')
                }
              >
                <span>Summarize the most recent key development about Microsoft.</span>
                <Icon icon={ANGLE_RIGHT} size={IconSize.XXXSMALL} />
              </ExampleList>
            </ExampleBoxLists>
          </ExampleBox>
          <ExampleBox>
            <ExampleBoxHead>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="37"
                height="37"
                viewBox="0 0 37 37"
                fill="none"
              >
                <circle cx="18.876" cy="18.4043" r="17.5" stroke="#525252" />
                <path
                  fillRule="evenodd"
                  clipRule="evenodd"
                  d="M20.3427 9.32227H25.1657V14.1453H20.3427V12.2338H18.0077V16.4922H17.0078V11.2338H20.3427V9.32227ZM21.3427 10.3223V13.1453H24.1657V10.3223H21.3427ZM9.87012 15.9922H14.6931V17.9037H20.3427V15.9922H25.1657V20.8152H20.3427V18.9037H14.6931V20.8152H9.87012V15.9922ZM10.8701 16.9922V19.8152H13.6931V16.9922H10.8701ZM21.3427 16.9922V19.8152H24.1657V16.9922H21.3427ZM17.0078 20.3152H18.0077V24.5736H20.3427V22.6621H25.1657V27.4851H20.3427V25.5736H17.0078V20.3152ZM21.3427 23.6621V26.4851H24.1657V23.6621H21.3427Z"
                  fill="#BFBFBF"
                />
              </svg>
              <span>Discover Documents</span>
            </ExampleBoxHead>
            <ExampleBoxLists>
              <ExampleList
                onClick={() =>
                  newInteraction(
                    'What are the core drivers of market growth for the EV market and Auto Industry as a whole?'
                  )
                }
              >
                <span>
                  What are the core drivers of market growth for the EV market and Auto Industry as
                  a whole?
                </span>
                <Icon icon={ANGLE_RIGHT} size={IconSize.XXXSMALL} />
              </ExampleList>
              <ExampleList
                onClick={() =>
                  newInteraction("Can you tell me more about Tesla's long term goals?")
                }
              >
                <span>Can you tell me more about Tesla&apos;s long term goals?</span>
                <Icon icon={ANGLE_RIGHT} size={IconSize.XXXSMALL} />
              </ExampleList>
              <ExampleList
                onClick={() =>
                  newInteraction(
                    "Can you tell me the strengths and risk factors in Tesla's supply chain?"
                  )
                }
              >
                <span>
                  Can you tell me the strengths and risk factors in Tesla&apos;s supply chain?
                </span>
                <Icon icon={ANGLE_RIGHT} size={IconSize.XXXSMALL} />
              </ExampleList>
            </ExampleBoxLists>
          </ExampleBox>
          <ExampleBox>
            <ExampleBoxHead>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="37"
                height="37"
                viewBox="0 0 37 37"
                fill="none"
              >
                <circle cx="18.876" cy="18.4043" r="17.5" stroke="#525252" />
                <path
                  fillRule="evenodd"
                  clipRule="evenodd"
                  d="M19.3657 10.9275L21.5378 8.05566L22.3354 8.6589L19.3657 12.5852V16.6631H18.3657V12.5843L15.4157 8.65761L16.2152 8.05696L18.3657 10.9195V8.79009H19.3657V10.9275ZM13.9326 12.754L13.4244 9.21145L14.4143 9.06946L15.112 13.9335L18.0033 16.8248L17.2962 17.5319L14.4049 14.6406L9.5409 13.9429L9.68289 12.953L13.2255 13.4612L11.7315 11.9672L12.4386 11.2601L13.9326 12.754ZM22.6401 13.9335L23.3378 9.06946L24.3277 9.21145L23.8195 12.754L25.3135 11.2601L26.0206 11.9672L24.5266 13.4612L28.0692 12.953L28.2112 13.9429L23.3472 14.6406L20.4559 17.5319L19.7488 16.8248L22.6401 13.9335ZM24.6963 17.8943L28.6231 14.9443L29.2237 15.7438L26.3612 17.8943H28.4906V18.8943H26.3532L29.225 21.0664L28.6218 21.864L24.6954 18.8943H21.9366V17.8943H24.6963ZM9.13033 14.9453L13.7195 18.4163L9.12904 21.8649L8.52839 21.0654L11.4183 18.8943H9.26152V17.8943H11.3717L8.5271 15.7428L9.13033 14.9453ZM17.1551 18.8943H14.2285V17.8943H17.1551V18.8943ZM13.9326 24.0552L12.4386 25.5491L11.7315 24.842L13.2255 23.3481L9.68289 23.8562L9.5409 22.8664L14.4049 22.1687L17.3168 19.2567L18.0239 19.9638L15.112 22.8758L14.4143 27.7398L13.4244 27.5978L13.9326 24.0552ZM24.5266 23.3481L26.0206 24.842L25.3135 25.5491L23.8195 24.0552L24.3277 27.5978L23.3378 27.7398L22.6401 22.8758L19.7488 19.9845L20.4559 19.2773L23.3472 22.1687L28.2112 22.8664L28.0692 23.8562L24.5266 23.3481ZM19.3657 25.8817V28.0191H18.3657V25.8898L16.2152 28.7523L15.4157 28.1516L18.3657 24.2249V20.1255H19.3657V24.224L22.3354 28.1503L21.5378 28.7536L19.3657 25.8817Z"
                  fill="#BFBFBF"
                />
              </svg>
              <span>Find M&A Targets</span>
            </ExampleBoxHead>
            <ExampleBoxLists>
              <ExampleList
                onClick={() =>
                  newInteraction(
                    'Find me M&A deals in the technology industry that took place in Germany in 2021.'
                  )
                }
              >
                <span>
                  Find me M&A deals in the technology industry that took place in Germany in 2021.
                </span>
                <Icon icon={ANGLE_RIGHT} size={IconSize.XXXSMALL} />
              </ExampleList>
              <ExampleList
                onClick={() =>
                  newInteraction('Describe the transactions Alphabet has made in the last 3 years')
                }
              >
                <span>Describe the transactions Alphabet has made in the last 3 years</span>
                <Icon icon={ANGLE_RIGHT} size={IconSize.XXXSMALL} />
              </ExampleList>
              <ExampleList
                onClick={() => newInteraction('List JP Morgan buybacks in the last 5 years.')}
              >
                <span>List JP Morgan buybacks in the last 5 years.</span>
                <Icon icon={ANGLE_RIGHT} size={IconSize.XXXSMALL} />
              </ExampleList>
            </ExampleBoxLists>
          </ExampleBox>
        </ExampleBoxWrapper>
        <FaqDesclimer>
          <Button
            size={Size.MEDIUM}
            purpose={Purpose.LINK}
            onClick={() => newInteraction('How to use CreditCompanion')}
            leftIcon={
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="14"
                height="19"
                viewBox="0 0 14 19"
                fill="none"
              >
                <path
                  fillRule="evenodd"
                  clipRule="evenodd"
                  d="M0 0H10.9767V7.61783C10.9767 7.913 10.7374 8.15229 10.4423 8.15229C10.1471 8.15229 9.90779 7.913 9.90779 7.61783V1.06893H1.06893V14.8077H2.91527C3.21045 14.8077 3.44974 15.047 3.44974 15.3422C3.44974 15.6374 3.21045 15.8766 2.91527 15.8766H0V0Z"
                  fill="var(--color-text-link)"
                />
                <path
                  fillRule="evenodd"
                  clipRule="evenodd"
                  d="M2.36841 3.12473C2.36841 2.82956 2.6077 2.59027 2.90287 2.59027H8.07392C8.36909 2.59027 8.60838 2.82956 8.60838 3.12473C8.60838 3.41991 8.36909 3.6592 8.07392 3.6592H2.90287C2.6077 3.6592 2.36841 3.41991 2.36841 3.12473ZM2.36841 5.45598C2.36841 5.1608 2.6077 4.92151 2.90287 4.92151H8.07392C8.36909 4.92151 8.60838 5.1608 8.60838 5.45598C8.60838 5.75115 8.36909 5.99044 8.07392 5.99044H2.90287C2.6077 5.99044 2.36841 5.75115 2.36841 5.45598ZM2.36841 7.78722C2.36841 7.49204 2.6077 7.25275 2.90287 7.25275H8.07392C8.36909 7.25275 8.60838 7.49204 8.60838 7.78722C8.60838 8.0824 8.36909 8.32168 8.07392 8.32168H2.90287C2.6077 8.32168 2.36841 8.0824 2.36841 7.78722ZM2.36841 10.14C2.36841 9.84487 2.6077 9.60558 2.90287 9.60558H4.59626C4.89143 9.60558 5.13072 9.84487 5.13072 10.14C5.13072 10.4352 4.89143 10.6745 4.59626 10.6745H2.90287C2.6077 10.6745 2.36841 10.4352 2.36841 10.14Z"
                  fill="var(--color-text-link)"
                />
                <path
                  fillRule="evenodd"
                  clipRule="evenodd"
                  d="M9.15357 17.3441C10.9949 17.3441 12.4876 15.8514 12.4876 14.0101C12.4876 12.1688 10.9949 10.6761 9.15357 10.6761C7.31224 10.6761 5.81955 12.1688 5.81955 14.0101C5.81955 15.8514 7.31224 17.3441 9.15357 17.3441ZM9.15357 18.475C11.6194 18.475 13.6184 16.476 13.6184 14.0101C13.6184 11.5442 11.6194 9.54525 9.15357 9.54525C6.6877 9.54525 4.68872 11.5442 4.68872 14.0101C4.68872 16.476 6.6877 18.475 9.15357 18.475Z"
                  fill="var(--color-text-link)"
                />
                <path
                  fillRule="evenodd"
                  clipRule="evenodd"
                  d="M9.15394 13.1362C9.47717 13.1362 9.73921 13.3983 9.73921 13.7215V15.755C9.73921 16.0782 9.47717 16.3403 9.15394 16.3403C8.8307 16.3403 8.56866 16.0782 8.56866 15.755V13.7215C8.56866 13.3983 8.8307 13.1362 9.15394 13.1362Z"
                  fill="var(--color-text-link)"
                />
                <path
                  d="M9.7389 12.2652C9.7389 12.5884 9.47687 12.8504 9.15363 12.8504C8.83039 12.8504 8.56836 12.5884 8.56836 12.2652C8.56836 11.9419 8.83039 11.6799 9.15363 11.6799C9.47687 11.6799 9.7389 11.9419 9.7389 12.2652Z"
                  fill="var(--color-text-link)"
                />
              </svg>
            }
          >
            How to use CreditCompanion<sup>TM</sup>
          </Button>
          <Button
            size={Size.MEDIUM}
            purpose={Purpose.LINK}
            onClick={() => newInteraction('CreditCompanion<sup>TM</sup> Legal Disclaimer')}
            leftIcon={
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="15"
                height="15"
                viewBox="0 0 15 15"
                fill="none"
              >
                <path
                  fillRule="evenodd"
                  clipRule="evenodd"
                  d="M7.0786 12.7858C9.99786 12.7858 12.3644 10.4192 12.3644 7.49999C12.3644 4.58073 9.99786 2.21421 7.0786 2.21421C4.15935 2.21421 1.79282 4.58073 1.79282 7.49999C1.79282 10.4192 4.15935 12.7858 7.0786 12.7858ZM7.0786 14.5786C10.988 14.5786 14.1572 11.4094 14.1572 7.49999C14.1572 3.59059 10.988 0.421387 7.0786 0.421387C3.1692 0.421387 0 3.59059 0 7.49999C0 11.4094 3.1692 14.5786 7.0786 14.5786ZM7.07904 6.11451C7.5915 6.11451 8.00693 6.52994 8.00693 7.0424V10.2663C8.00693 10.7788 7.5915 11.1942 7.07904 11.1942C6.56658 11.1942 6.15115 10.7788 6.15115 10.2663V7.0424C6.15115 6.52994 6.56658 6.11451 7.07904 6.11451ZM7.07871 5.66144C7.59117 5.66144 8.0066 5.246 8.0066 4.73354C8.0066 4.22108 7.59117 3.80565 7.07871 3.80565C6.56625 3.80565 6.15082 4.22108 6.15082 4.73354C6.15082 5.246 6.56625 5.66144 7.07871 5.66144Z"
                  fill="var(--color-text-link)"
                />
              </svg>
            }
          >
            Legal Disclaimer
          </Button>
        </FaqDesclimer>
      </NewContent>
    </Page>
      )}
  </div>
    
  );
};
