// Copyright Notice!
// This document is protected under the trade secret and copyright
// laws as the property of Fidelity National Information Services, Inc.
// Copying, reproduction or distribution should be limited and only to
// employees with a “need to know” to do their job.
// Any disclosure of this document to third parties is strictly prohibited.
// © 2016 Fidelity National Information Services.
// All rights reserved worldwide.

package com.fis.digitalpayments.sdk.core;

import android.webkit.WebView;

import com.fis.digitalpayments.sdk.messaging.ProductType;
import com.fis.digitalpayments.sdk.messaging.WebEvent;
import com.fis.digitalpayments.sdk.messaging.WebEventListener;
import com.fis.digitalpayments.sdk.messaging.WebEventType;

import java.util.HashMap;
import java.util.Map;

/**
 * Implementation of BridgeRequestCallback for communicating responses back to javascript.
 */
class WebViewBridgeRequestCallback implements BridgeRequestCallback{

    private final WebView mWebView;
    private final WebEventListener mErrorListener;

    WebViewBridgeRequestCallback(WebView webView, WebEventListener errorListener)
    {
        mWebView = webView;
        mErrorListener = errorListener;
    }

    /**
     * Communicates request results back to javascript.
     * @param bridgeResponse Result of BridgeRequest
     */
    @Override
    public void onRequestComplete(final BridgeResponse bridgeResponse) {
        if(!bridgeResponse.getIsSuccessful() && mErrorListener != null)
        {
            Map<String, String> eventParams = new HashMap<>();
            mErrorListener.onEventReceived(new WebEvent(WebEvent.INTERNAL_ERROR_EVENT_ID, WebEventType.ERROR, ProductType.PLATFORM, bridgeResponse.getMessage(), eventParams));
        }
        mWebView.post(new Runnable() {
            @Override
            public void run() {
                mWebView.loadUrl(bridgeResponse.getJavascriptCallback());
            }
        });
    }
}
