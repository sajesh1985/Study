from anthropic import Anthropic

from chatrd.core.llm.models import BedrockChat


def get_num_tokens_bedrock_anthropic(text: str) -> int:
    """Get the number of tokens in a string of text."""
    client = Anthropic()
    return client.count_tokens(text=text)


class AnthropicBedrockChat(BedrockChat):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def get_num_tokens(self, text: str) -> int:
        if self._model_is_anthropic:
            return get_num_tokens_bedrock_anthropic(text)
        else:
            return super().get_num_tokens(text)

    def _model_is_anthropic(self) -> bool:
        return self.self.get_provider() == "anthropic"
