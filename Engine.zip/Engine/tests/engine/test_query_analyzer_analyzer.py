# tests/test_query_analyzer_analyzer.py

from unittest.mock import MagicMock, patch

import pytest

from chatrd.engine.components.query_analyzer import QueryAnalyzer
from chatrd.engine.components.query_analyzer.conversational.prompter import (
    DecisionOutput,
    RephrasingOutput,
)
from chatrd.engine.components.query_analyzer.entity_extractor.utils import Entities
from chatrd.engine.components.query_analyzer.utils import TaggedEntity
from chatrd.engine.components.schema import QueryAnalyzerInput, QueryAnalyzerOutput
from chatrd.engine.utils import ChatResponse


class TestQueryAnalyzer:
    @pytest.fixture
    def mock_analyzer(self):
        """Create a mock analyzer with dependencies mocked"""
        # Mock boto3 directly
        with patch("boto3.Session") as mock_session:
            # Mock the STS client
            mock_sts = MagicMock()
            mock_session.return_value.client.return_value = mock_sts

            # Mock the assume_role response
            mock_sts.assume_role.return_value = {
                "Credentials": {
                    "AccessKeyId": "mock-access-key",
                    "SecretAccessKey": "mock-secret-key",
                    "SessionToken": "mock-session-token",
                    "Expiration": "2023-12-31T23:59:59Z",
                }
            }

            # Mock the assumed_session function directly
            with patch("chatrd.core.aws_utils.common.assumed_session") as mock_assumed_session:
                mock_assumed_session.return_value = MagicMock()

                # Mock the bedrock client creation
                with patch(
                    "chatrd.engine.components.query_analyzer.analyzer.get_assumed_bedrock_llm_client"
                ) as mock_bedrock:
                    mock_bedrock.return_value = {"bedrock-runtime": MagicMock()}

                    # Mock the endpoint router
                    with patch(
                        "chatrd.engine.components.query_analyzer.analyzer.MultiTopicEndpointRouter"
                    ) as mock_router:
                        mock_router = MagicMock()
                        # mock_router.__init__.return_value = MagicMock()
                    with patch(
                        "chatrd.engine.components.query_analyzer.analyzer.MultiTopicEndpointRouter"
                    ) as mock_router:
                        mock_router = MagicMock()
                        # mock_router.__init__.return_value = MagicMock()
                        mock_router.return_value.run.return_value = ["general"]

                        # Mock numpy load
                        with patch("numpy.load") as mock_load:
                            # Mock the guardrail with proper return value
                            with patch(
                                "chatrd.engine.components.query_analyzer.analyzer.InputModerationGuardrail"
                            ) as mock_guardrail:
                                mock_guardrail_instance = MagicMock()
                                mock_guardrail.return_value = mock_guardrail_instance
                                # Add the question_blocked key to the guardrail output
                                mock_guardrail_instance.run.return_value = {
                                    "action": "PROCEED",
                                    "question_blocked": False,
                                    "blocked_categories": [],
                                    "blocked_reasons": [],
                                }

                                with patch(
                                "chatrd.engine.components.query_analyzer.analyzer.InputModerationTranslator"
                                ) as mock_translator:
                                    mock_translator_instance = MagicMock()
                                    mock_translator.return_value = mock_translator_instance
                                    mock_translator_instance.run.return_value = {
                                        "language": "Korean", 
                                        "translated_text": "What is rating for Tesla"
                                        }



                                    # Mock get_blocked_topic_message to avoid any other issues
                                    with patch(
                                        "chatrd.engine.components.query_analyzer.analyzer.get_blocked_topic_message"
                                    ) as mock_get_blocked:
                                        mock_get_blocked.return_value = None

                                        analyzer = QueryAnalyzer(
                                            embeddings_uc_type_path="mock_path", uc_embedding_model="mock_model"
                                        )

                                        # Mock the bedrock client
                                        analyzer.bedrock_client = MagicMock()
                                        analyzer.bedrock_client.apply_guardrail.return_value = {
                                            "action": "PROCEED",
                                            "outputs": [{"text": "mock output"}],
                                        }

                                        yield analyzer

    def test_article_entity_detection(self, mock_analyzer):
        """Test that article entities are properly detected and processed"""
        # Create test input with article entity
        article_entity = TaggedEntity(type="Articles", id="article123", name="Test Article")
        input_data = QueryAnalyzerInput(
            llm="test_llm",
            temperature=0.0,
            llm_for_entity_extractor="test_llm_entity_extractor",
            temperature_for_entity_extractor=0.0,
            llm_for_sector_extractor="test_llm_sector_extractor",
            temperature_for_sector_extractor=0.0,
            message="Tell me about this article",
            list_of_tagged_entities=[article_entity],
            chat_history=[],
        )

        # Create mocks for all required classes
        mock_prompter_class = MagicMock()
        mock_prompter_instance = mock_prompter_class.return_value
        mock_prompter_instance.run.return_value = MagicMock()
        mock_prompter_instance.run.return_value = (
            DecisionOutput(flag="rephrasing"),
            RephrasingOutput(
                initial_question="Tell me about this article",
                rephrased_initial_question="Tell me about this article.",
                subqueries={"Tell me about this article.": "general"},
            ),
        )

        # mock_generator_class = MagicMock()
        # mock_generator_instance = mock_generator_class.return_value
        # mock_generator_instance.run.return_value = MagicMock()
        # mock_generator_instance.run.return_value.guidelines = "Test guidelines"

        mock_entity_extractor_class = MagicMock()
        mock_entity_extractor_instance = mock_entity_extractor_class.return_value
        # Return a tuple of three Entities objects to match expected output
        mock_entity_extractor_instance.run.return_value = (Entities(), Entities(), Entities())

        # Apply all mocks
        with patch("chatrd.engine.components.query_analyzer.uc_router.MultiTopicEndpointRouter") as mock_router:
            mock_router.return_value.run.return_value = ["general"]
            with patch.multiple(
                "chatrd.engine.components.query_analyzer.analyzer",
                ConversationalPrompter=mock_prompter_class,
                # GuidelineGenerator=mock_generator_class,
                EntityExtractor=mock_entity_extractor_class,
                SectorExtractor=MagicMock(),  # <-- Add this line to mock SectorExtractor
            ):
                # Act
                result = mock_analyzer._execute_internal(input_data, tagged_routes=None)
        with patch("chatrd.engine.components.query_analyzer.uc_router.MultiTopicEndpointRouter") as mock_router:
            mock_router.return_value.run.return_value = ["general"]
            with patch.multiple(
                "chatrd.engine.components.query_analyzer.analyzer",
                ConversationalPrompter=mock_prompter_class,
                # GuidelineGenerator=mock_generator_class,
                EntityExtractor=mock_entity_extractor_class,
            ):
                # Act
                result = mock_analyzer._execute_internal(input_data, tagged_routes=None)

                # Assert
                assert isinstance(result, QueryAnalyzerOutput)
                assert result.uc_type == "selected_article"
                # assert result.guidelines == "Test guidelines"
                # Verify guideline generator was called with correct parameters
                # mock_generator_instance.run.assert_called_once_with(
                #     query="Tell me about this article",
                #     uc_type="general",
                #     entity_type=None
                # )

    def test_multiple_article_entities(self, mock_analyzer):
        """Test handling of multiple article entities"""
        # Create test input with multiple article entities
        article_entities = [
            TaggedEntity(type="Articles", id="article123", name="Test Article 1"),
            TaggedEntity(type="Articles", id="article456", name="Test Article 2"),
        ]
        input_data = QueryAnalyzerInput(
            llm="test_llm",
            temperature=0.0,
            llm_for_entity_extractor="test_llm_entity_extractor",
            temperature_for_entity_extractor=0.0,
            llm_for_sector_extractor="test_llm_sector_extractor",
            temperature_for_sector_extractor=0.0,
            message="Compare these articles",
            list_of_tagged_entities=article_entities,
            chat_history=[],
        )

        # Create mocks for all required classes
        mock_prompter_class = MagicMock()
        mock_prompter_instance = mock_prompter_class.return_value
        mock_prompter_instance.run.return_value = MagicMock()
        mock_prompter_instance.run.return_value = (
            DecisionOutput(flag="rephrasing"),
            RephrasingOutput(
                initial_question="Compare these articles",
                rephrased_initial_question="Compare these articles.",
                subqueries={"Compare these articles.": "general"},
            ),
        )

        # mock_generator_class = MagicMock()
        # mock_generator_instance = mock_generator_class.return_value
        # mock_generator_instance.run.return_value = MagicMock()
        # mock_generator_instance.run.return_value.guidelines = "Test guidelines"
        mock_entity_extractor_class = MagicMock()
        mock_entity_extractor_instance = mock_entity_extractor_class.return_value
        # Return a tuple of three Entities objects to match expected output
        mock_entity_extractor_instance.run.return_value = (Entities(), Entities(), Entities())

        # Apply all mocks
        with patch("chatrd.engine.components.query_analyzer.uc_router.MultiTopicEndpointRouter") as mock_router:
            mock_router.return_value.run.return_value = ["general"]
            with patch.multiple(
                "chatrd.engine.components.query_analyzer.analyzer",
                ConversationalPrompter=mock_prompter_class,
                # GuidelineGenerator=mock_generator_class,
                EntityExtractor=mock_entity_extractor_class,
                SectorExtractor=MagicMock(),  # Mock SectorExtractor to avoid ValueError
            ):
                # Act
                result = mock_analyzer._execute_internal(input_data, tagged_routes=None)
                result = mock_analyzer._execute_internal(input_data, tagged_routes=None)
        with patch("chatrd.engine.components.query_analyzer.uc_router.MultiTopicEndpointRouter") as mock_router:
            mock_router.return_value.run.return_value = ["general"]
            with patch.multiple(
                "chatrd.engine.components.query_analyzer.analyzer",
                ConversationalPrompter=mock_prompter_class,
                # GuidelineGenerator=mock_generator_class,
                EntityExtractor=mock_entity_extractor_class,
            ):
                # Act
                result = mock_analyzer._execute_internal(input_data, tagged_routes=None)

                # Assert
                assert isinstance(result, QueryAnalyzerOutput)
                assert result.uc_type == "selected_article"
                assert result.list_of_tagged_entities == article_entities

                # Check that both article IDs are present
                article_ids = [entity.id for entity in result.list_of_tagged_entities]
                assert "article123" in article_ids
                assert "article456" in article_ids
                # Check that both article IDs are present
                article_ids = [entity.id for entity in result.list_of_tagged_entities]
                assert "article123" in article_ids
                assert "article456" in article_ids
