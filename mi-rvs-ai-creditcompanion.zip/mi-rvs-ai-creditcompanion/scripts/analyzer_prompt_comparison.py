import logging
import time

import pandas as pd

from chatrd.core.llm import LCLLMFactory
from chatrd.engine.processors.query_analyzer import QueryAnalyzer
from chatrd.engine.utils import ChatMessage, MessageRole

logger = logging.getLogger(__name__)

MODEL_LIST = ["gpt-35-turbo-v0613", "claude-instant-v1", "gpt-4", "gpt-4-turbo", "claude-v2:1"]
QUESTION_LIST = [
    "what is the financial risk",
    "what is explain business risk",
    "explain business risk",
    "What is financial risk for corporates?",
    "What is business risk for autos company?",
    "what is risk for corporates.",
    "what is credit risk and explain in details?",
    "how in general the credit rating is assigned by credit analyst to the company.",
    "What is financial and business risk for corporates?",
    "What are the main factors that influence the credit ratings of sovereign entities?",
    "What is the basic methodology used to rate auto companies",
    "Explain business risk for corporates",
    "Summarise the methodology to rate a financial institution",
    "What is the latest rating of Tesla?",
    "What is the credit health of Black Knight?",
    "What are the financial trends of Tesla issuer according to S&P Global Ratings?",
    "What is the rating of Harley Davidson?",
    "What are Harley Davidson's strengths and weaknesses in 100 words or less?",
    "How do Harley Davidson compare to its peers?",
    "What is the expected impact of rising interest rates on auto sales in the next year or two?",
    "What is the basic methodology used to rate auto companies?",
    "What are the latest rating actions in autos?",
    "What are the typical constraints found in corporate cash flow CDOs?",
    "What is the basic methodology to rate Solar ABS Transactions?",
    "What are the types of types of treatment for insurance securitization?",
    "how could S&P lower the rating for RCH?",
]


for model_name in MODEL_LIST:
    print("Model executing : ", model_name)
    df = pd.DataFrame()
    llm = LCLLMFactory().get_llm(deployment_name_or_model_id=model_name, temperature=0.1)
    (
        questions,
        companies,
        industry_sector,
        is_methodology,
        require_documents,
        is_lookup,
        is_macro_industry_trends,
        criteria_type,
        time_executed,
    ) = ([], [], [], [], [], [], [], [], [])
    start_model_time = time.time()
    for question in QUESTION_LIST:
        message = ChatMessage(role=MessageRole.USER, content=question)
        try:
            start_time = time.time()
            parsed_query = QueryAnalyzer().execute(llm=llm, message=message, chat_history=[])
            end_time = time.time()
            questions.append(question)
            companies.append(parsed_query["companies"])
            industry_sector.append(parsed_query["industry_sector"])
            is_methodology.append(parsed_query["is_methodology"])
            require_documents.append(parsed_query["require_documents"])
            is_lookup.append(parsed_query["is_lookup"])
            is_macro_industry_trends.append(parsed_query["is_macro_industry_trends"])
            criteria_type.append(parsed_query["criteria_type"])
            time_executed.append(end_time - start_time)
        except Exception as e:
            logger.info(e)
            pass
    end_model_time = time.time()
    df["question"] = questions
    df["companies"] = companies
    df["industry_sector"] = industry_sector
    df["is_methodology"] = is_methodology
    df["require_documents"] = require_documents
    df["is_lookup"] = is_lookup
    df["is_macro_industry_trends"] = is_macro_industry_trends
    df["criteria_type"] = criteria_type
    df["time_executed"] = time_executed
    df.to_csv(f"scripts/{model_name}_v2.csv", index=False)
    print(
        f"""Total time executed : {end_model_time - start_model_time} and avg time for each question : {(end_model_time - start_model_time)/len(QUESTION_LIST)}"""
    )
