import React from 'react';
import { useTranslation } from 'react-i18next';

import { StyledSpeechIcon } from '../QuestionInput/QuestionInput.styles';
import { Icon } from '@spglobal/react-components';
import { faMicrophone } from '@fortawesome/free-solid-svg-icons';
import { Size } from '@spglobal/koi-helpers';

interface SpeechIconProps {
  allowSpeech: boolean;
  isListening: boolean;
  handleSpeechIconClick: () => void;
}

export const SpeechIcon: React.FC<SpeechIconProps> = ({
  allowSpeech,
  isListening,
  handleSpeechIconClick,
}) => {
  const { t } = useTranslation(['chatiq_main']);

  return (
    <StyledSpeechIcon
      title={!allowSpeech && t('microphone.permissionDenied')}
      className={isListening ? 'listening' : ''}
    >
      <Icon
        icon={faMicrophone}
        size={Size.MEDIUM}
        onClick={handleSpeechIconClick}
        color={
          !allowSpeech
            ? 'var(--color-icon-disabled)'
            : isListening
            ? 'var(--color-text-primary)'
            : 'var(--color-icon-primary)'
        }
      />
    </StyledSpeechIcon>
  );
};
