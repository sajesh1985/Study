from mcp.server.fastmcp import FastMCP, Context
from fastapi import FastAPI, APIRouter
from fastapi import Request
from fastapi import Depends
import logging
import httpx
from contextlib import asynccontextmanager
import contextlib
from src.synthia.config.api_config import get_config
from . import auth
from src.synthia.utils.logging_config import configure_logging
from src.synthia.utils.source import Source
import collections
import json
import re
import unicodedata
from bs4 import BeautifulSoup

def clean_plain_text(raw):
    if not raw:
        return ""
    soup = BeautifulSoup(raw, "html.parser")
    text = soup.get_text(separator=" ", strip=True)
    # Remove bullet points and non-breaking spaces
    text = text.replace('\u2022', '').replace('\u00a0', '').replace('\u2019', '')
    # Normalize unicode spaces
    text = ''.join(' ' if unicodedata.category(c) == 'Zs' else c for c in text)
    text = text.lstrip()
    # Remove leading headings with optional punctuation, whitespace, and case-insensitivity
    text = re.sub(
        r'^(Outlook|Downside scenario|Upside scenario)[\s:\-–—\.]*', '', text, flags=re.IGNORECASE
    )
    return text.strip()


# Configure logging
configure_logging(log_file='company_peerdetails.log')
logger = logging.getLogger(__name__)

mcp: FastMCP = FastMCP("Company Peer Details MCP", stateless_http=True)

cfg = get_config()

logger.info("Peer Details MCP Server starting up...")
capitaliq_base_url = cfg["capitaliq_base_url"]
peerdetails_url_infix = "chatrd/peerDetails/"

router = APIRouter()

# Create a single AsyncClient instance for reuse (performance optimization for Lambda)
async_client: httpx.AsyncClient = None



@mcp.tool()
async def get_company_peerdetails(inst_id: str) -> dict:
    """
        Retrieves peer company details for a given company ID using the Capital IQ API.

        Features:
            - Fetches peer company ratings, financial highlights, and market-derived signals.
            - Processes and structures peer data for analytics or downstream services.
            - Logs request and response details.

        Endpoint:
            GET /company-peerdetails/{inst_id}

        Args:
            inst_id (str): The unique identifier for the company (e.g., 4574287).

        Returns:
            dict: {
                sources (str): The URL used to fetch the peer company data.
                data (dict): {
                    <company_name> (dict): {
                        RT_ENTITY_NAME (str): The full legal name of the rated entity.
                        Institution Id (str): Unique identifier for the institution or company.
                        Issuer Credit Rating (Foreign Currency LT) (Optional[str]): Long-term issuer credit rating in foreign currency.
                        Rating Date (Optional[str]): Date when the current credit rating was assigned.
                        Last Review Date (Optional[str]): Date when the rating was last reviewed.
                        CreditWatch/Outlook (Optional[str]): Current outlook or watch status.
                        CreditWatch/Outlook Date (Optional[str]): Date when the outlook or watch status was last updated.
                        Scores & Modifiers (Optional[str]): Additional scores or rating modifiers, if any.
                        Scores & Modifiers Date (Optional[str]): Date when scores or modifiers were last updated.
                        Scores (Optional[str]): Detailed scoring information, if available.
                        Business Risk (Optional[str]): Assessment of the company's business risk profile.
                        Industry Risk (Optional[str]): Risk level associated with the industry.
                        Country Risk (Optional[str]): Risk level associated with the country of operation.
                        CICRA (Optional[str]): Composite Industry and Country Risk Assessment.
                        Competitive Position (Optional[str]): Evaluation of the company's competitive standing.
                        Financial Risk (Optional[str]): Assessment of the company's financial risk profile.
                        Anchor (Optional[str]): Baseline rating before applying modifiers.
                        Modifiers (Optional[str]): Additional rating modifiers, if any.
                        Diversification/ Portfolio Effect (Optional[str]): Impact of diversification or portfolio on the rating.
                        Capital Structure (Optional[str]): Assessment of the company's capital structure.
                        Financial Policy (Optional[str]): Evaluation of the company's financial policy.
                        Liquidity (Optional[str]): Assessment of the company's liquidity position.
                        Management And Governance (Optional[str]): Evaluation of management quality and governance.
                        Comparable Rating Analysis (Optional[str]): Impact of comparable rating analysis.
                        Captive Finance (Optional[str]): Information about captive finance operations, if any.
                        Stand Alone Credit Profile (Optional[str]): Stand-alone credit profile rating.
                        Fiscal Period (Optional[str]): Fiscal year or period for the financial data.
                        Period End Date (Optional[str]): End date of the fiscal period.
                        Currency Code (Optional[str]): Currency in which financials are reported.
                        Adjustment Status (Optional[str]): Status of the rating adjustment.
                        Key Figures (Optional[str]): Key financial figures, if available.
                        Revenue, Adjusted($M) (Optional[str]): Adjusted revenue in millions of USD.
                        EBITDA, Adjusted($M) (Optional[str]): Adjusted EBITDA in millions of USD.
                        Operating Income (After D&A), Adjusted($M) (Optional[str]): Adjusted operating income after depreciation and amortization, in millions.
                        EBIT, Adjusted($M) (Optional[str]): Adjusted earnings before interest and taxes, in millions.
                        FFO, Adjusted($M) (Optional[str]): Adjusted funds from operations, in millions.
                        Cash Flow from Ops, Adjusted (Pensions Normalized)($M) (Optional[str]): Adjusted cash flow from operations, pensions normalized, in millions.
                        Capital Expenditures, Adjusted($M) (Optional[str]): Adjusted capital expenditures, in millions.
                        Free Operating Cash Flow, Adjusted($M) (Optional[str]): Adjusted free operating cash flow, in millions.
                        Dividends, Adjusted($M) (Optional[str]): Adjusted dividends paid, in millions.
                        Share Repurchases($M) (Optional[str]): Value of share repurchases, in millions.
                        Discretionary Cash Flow, Adjusted($M) (Optional[str]): Adjusted discretionary cash flow, in millions.
                        Cash & Short-Term Investments, Adjusted($M) (Optional[str]): Adjusted cash and short-term investments, in millions.
                        Debt, Adjusted($M) (Optional[str]): Adjusted total debt, in millions.
                        Equity, Adjusted($M) (Optional[str]): Adjusted total equity, in millions.
                        Debt and Equity, Adjusted($M) (Optional[str]): Combined adjusted debt and equity, in millions.
                        Core Ratios (Optional[str]): Key financial ratios, if available.
                        Debt/ EBITDA, Adjusted(x) (Optional[str]): Adjusted debt to EBITDA ratio.
                        FFO/ Debt, Adjusted(%) (Optional[str]): Adjusted funds from operations to debt ratio, as a percentage.
                        Supplemental Ratios - Cash Flow Payback (Optional[str]): Additional cash flow payback ratios, if available.
                        Operating Cash Flow/ Debt, Adjusted(%) (Optional[str]): Adjusted operating cash flow to debt ratio, as a percentage.
                        Free Operating Cash Flow/ Debt, Adjusted(%) (Optional[str]): Adjusted free operating cash flow to debt ratio, as a percentage.
                        Discretionary Cash Flow/ Debt(%) (Optional[str]): Discretionary cash flow to debt ratio, as a percentage.
                        Supplemental Ratios - Interest Coverage (Optional[str]): Additional interest coverage ratios, if available.
                        EBITDA Interest Coverage, Adjusted(x) (Optional[str]): Adjusted EBITDA to interest coverage ratio.
                        FFO Cash Interest Coverage, Adjusted(x) (Optional[str]): Adjusted FFO to cash interest coverage ratio.
                        Profitability Metrics (Optional[str]): Key profitability metrics, if available.
                        EBITDA Margin, Adjusted(%) (Optional[str]): Adjusted EBITDA margin, as a percentage.
                        Return on Capital, Adjusted(%) (Optional[str]): Adjusted return on capital, as a percentage.
                        EBIT Margin(%) (Optional[str]): EBIT margin, as a percentage.
                        Other Sector Specific Ratios (Optional[str]): Other ratios specific to the sector, if available.
                        Debt/ Debt and Equity, Adjusted(%) (Optional[str]): Adjusted debt to debt and equity ratio, as a percentage.
                        Debt/ Debt and Equity Underpreciated Basis(%) (Optional[str]): Debt to debt and equity ratio on an underappreciated basis, as a percentage.
                        Debt Fixed Charge Coverage(%) (Optional[str]): Debt fixed charge coverage ratio, as a percentage.
                        Return on Common Equity Adj for AFUDC, Adjusted(%) (Optional[str]): Adjusted return on common equity, adjusted for AFUDC, as a percentage.
                        EBIT Interest Coverage, Adjusted(x) (Optional[str]): Adjusted EBIT to interest coverage ratio.
                        Other Operating Metrics (Optional[str]): Other operating metrics, if available.
                        Annual Revenue Growth, Adjusted(%) (Optional[str]): Adjusted annual revenue growth, as a percentage.
                        Operating Income (After D&A)/ Revenues, Adjusted(%) (Optional[str]): Adjusted operating income after D&A to revenues ratio, as a percentage.
                        Common Dividend Payout Ratio, Adjusted(%) (Optional[str]): Adjusted common dividend payout ratio, as a percentage.
                        Last Updated Date (Optional[str]): Date when the data was last updated.
                        OUTLOOK (Optional[str]): Internal or external outlook code or identifier.
                        Summary (Optional[str]): HTML-formatted summary of the rating rationale or outlook.
                        Downside Scenario (Optional[str]): HTML-formatted description of downside risks or scenarios.
                        Downside Financial Thresholds** (Optional[str]): Financial thresholds for downside scenarios, if any.
                        Upside Scenario (Optional[str]): HTML-formatted description of upside potential or scenarios.
                        Upside Financial Thresholds** (Optional[str]): Financial thresholds for upside scenarios, if any.
                        MARKET DERIVED SIGNALS (Optional[str]): Market-derived signals, if available.
                        Credit Default Swap Based Signal (Optional[str]): Signal based on credit default swap data, if available.
                        Signal (Optional[str]): Additional signal or rating indicator.
                        Signal Date (Optional[str]): Date when the signal was last updated.
                        Spread (bps) (Optional[str]): Credit spread in basis points.
                        Z-Score (Optional[str]): Z-score, a statistical measure of credit risk.
                        Probability of Default Based Signal (Optional[str]): Probability of default signal, if available.
                    }
                    ...
                }
            }

        Example:
            {
                "sources": "https://www.capitaliqdev.spglobal.com/apisv3/spg-ratingsresearch-service/api/v3/chatrd/peerDetails/4574287",
                "data": {
                    "Tesla, Inc.": {
                        "RT_ENTITY_NAME": "Tesla, Inc.",
                        "Institution Id": "4574287",
                        "Issuer Credit Rating (Foreign Currency LT)": "BBB",
                        "Rating Date": "10/7/2022",
                        "Last Review Date": "3/19/2025"
                    },
                    "Aston Martin Holdings (UK) Limited": {
                        "RT_ENTITY_NAME": "Aston Martin Holdings (UK) Limited",
                        "Institution Id": "1234567",
                        "Issuer Credit Rating (Foreign Currency LT)": null,
                        "Rating Date": "5/12/2021",
                        "Last Review Date": "2/15/2024"
                    }
                }
            }

        Error Handling:
            - 200 OK: Successful request
            - 204 No Content: No peer details found for the given company
            - 400 Bad Request: Invalid parameters
            - 404 Not Found: Resource not found
            - 500 Internal Server Error: Server error
        """

    logger.info(f"Peer Details request for inst_id: {inst_id}")

    # Simulate a request to the peerdetails URL
    logger.info(f"get_company_peerdetails called for : {inst_id}")
    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    url = f"{capitaliq_base_url}{peerdetails_url_infix}{inst_id}"
    global async_client
    try:
        response = await async_client.get(url, headers=auth.build_auth_headers(raw_request))
        source = Source(title="Company Peer Details", url=url)
        if response.status_code == 200:
            peerdetails_data = response.json()

            mnemonics_list = peerdetails_data["CompanyAnalystRatingsPeerResult"][
                "CompanyAnalystPeerRatingMnemonicsList"]
            company_names = {}

            # First, find the row with DataField == "RT_ENTITY_NAME" to get company names
            for item in mnemonics_list:
                if item.get("DataField") == "RT_ENTITY_NAME":
                    for company_field in [k for k in item if k.startswith("Company")]:
                        company_names[company_field] = item[company_field]
                    break

            company_data = collections.defaultdict(dict)

            for item in mnemonics_list:
                mnemonic_name = item.get("MnemonicName")
                if mnemonic_name == "FINANCIAL HIGHLIGHTS" or mnemonic_name == "":
                    continue  # Skip this item
                key = "Institution Id" if mnemonic_name == "RATINGS & SCORES" else (mnemonic_name or item.get("DataField"))

                for company_field, company_name in company_names.items():
                    value = item.get(company_field)
                    if company_name:
                        company_data[company_name][key] = value

            company_data = dict(company_data)

            # Strip HTML from specific fields
            for company, details in company_data.items():
                for field in ["Summary", "Downside Scenario", "Upside Scenario"]:
                    if field in details and details[field]:
                        details[field] = clean_plain_text(details[field])

            logger.info(f"Processed company peers data: {len(company_data)} records")
            return {"sources": source, "data": company_data}

        elif response.status_code == 204:
            logger.info(f"No peer details found for the given Inst ID: {inst_id}")
            return {"sources": source, "data": "No peer details found for the given company."}
        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return f"Error: {response.status_code} - {response.text}"
    except httpx.RequestError as e:
        logger.error(f"Request failed: {e}")
        return f"Request failed: {e}"


# Define a custom lifespan for FastAPI with a task to manage MCP
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Initialize MCP server task group
    logger.info("Initializing MCP server task group...")
    global async_client
    async_client = httpx.AsyncClient(timeout=10)
    async with contextlib.AsyncExitStack() as stack:
        await stack.enter_async_context(mcp.session_manager.run())
        yield
    await async_client.aclose()


@router.get("/company-peerdetails/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "ok"}


# Create FastAPI app with lifespan
app = FastAPI(lifespan=lifespan)
app.mount("/company-peerdetails", mcp.streamable_http_app())
app.include_router(router)
logger.info("Company Peer Details MCP Server started successfully.")