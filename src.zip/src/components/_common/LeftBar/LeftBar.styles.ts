import styled from '@emotion/styled';
import { DARK } from '@spglobal/koi-helpers';

export const AccordionList = styled.div`
  padding-bottom: var(--size-space-md);
  listStyleType:none;
  padding:0;
  margin:0;
  
  .${DARK} & {
    border-color: #3b3b3b;
    background-color: #272727;
  }
`;


export const ChatHistoryHeader = styled.div`
  &:hover {
    background-color: var(--color-bg-hover);
  }
  &:hover div:nth-child(2) {
    display: block;
  }
  &:hover {
    background-color: var(--color-bg-hover);
  }
  &.chatactive{
    background-color: #e0e7ef !important;
    svg{
      background-color: #e0e7ef !important;
    }
  }
.${DARK} & {
  background-color: #272727;
}
.${DARK} &:hover {
  background-color: var(--color-bg-hover) !important;
}
.${DARK} &.chatactive {
  background-color: #3f3f3f !important;
  svg{
    background-color: #3f3f3f!important;
  }
}


`;

export const ListHeader = styled.div`
  font-style: italic;
  padding: 2px 2px 2px 16px;
  font-family: "Akkurat";
  font-size: 10px;
  font-weight: 400;
  line-height: 13px;
  .${DARK} & {
    color: White;
    background-color: #272727;
  }
`;

export const ListText = styled.div`
    color: var(--color-text-link);
    cursor:pointer;
    padding: 5px 2px 1px 16px;
    text-overflow: ellipsis;
    font-family: "Akkurat";
    font-size: 12px;
    font-style: normal;
    font-weight: 400;
    line-height: 19px;
    &.chat{
      overflow: hidden;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
    }
  
    &.chatactive{
      overflow: hidden;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
    }
  
`;

export const LeftSideBar = styled.div`
    background-color: #f0f0f0;
    border-right: '1px solid #ccc';
    margin-left: -16px;
    padding-left: 16px;
    transition: 'transform 0.3s ease';
    position: fixed;
    z-index:103;
    height: 100%;
    top:45px;
    [data-testid="accordion"] div.css-cssveg button>span span
    {
      text-transform:inherit !important;
    }
    [data-testid="accordion"] [data-testid="icon"]
    {
      left: 214px;
    }
    [data-icon="angle-up"]
    {
      position:absolute;
    }
    [data-icon="box-archive"]
    {
      margin-top:-10px;
    }
    [id^="accordion-content-id"] {
      padding: 3px 0px 16px 0px;
    }
    .${DARK} & {
      background-color: #272727;
      border-right:#3b3b3b;
    }

`;

export const LeftSideBarHeader = styled.div`
    padding:14px;
    border-bottom: 1px solid var(--color-border-primary);
    .${DARK} & {
      border-bottom: 1px solid var(--color-base-gray-80);
    }

`;

export const styles = {
  leftBar: {
    width: '240px', 
  },

  iconcontent:{
    display:'none'
  },

  leftBarOpen:{
    width: '60px',
  },
  
  togglebtn: {
    position: 'absolute',
    right: '-3px',
    top:'9px',
    width:'7px',
    cursor:'pointer',
    border: '2px solid #4527a0',
    borderRadius: '50%',
    transition: 'transform 0.3s ease',
  },

  togglebtnRotate:{
    transform: 'rotate(180deg)'
  },

  titlehide: {
    transform: 'scale(0)'
  },
  
  newChat:{
    color: 'var(--color-text-link)',
    cursor:'pointer',
    fontFamily: "Akkurat",
    fontSize: "14px",
    fontStyle: "normal",
    fontWeight: "700",
    lineHeight: "normal",
    letterSpacing: "-0.42px",
  },
  
 

};






