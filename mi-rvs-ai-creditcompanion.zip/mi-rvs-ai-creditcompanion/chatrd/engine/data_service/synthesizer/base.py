from abc import ABC, abstractmethod


class BaseSynthesizer(ABC):
    @abstractmethod
    def synthesize(self):
        pass
