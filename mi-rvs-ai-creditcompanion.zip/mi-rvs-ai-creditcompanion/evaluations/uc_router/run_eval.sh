# !/bin/bash
set -e

python evaluations/uc_router/eval.py --embedding-file-path chatrd/engine/data/use_case_embeddings.npz \
    --question-file-path evaluations/data/uc_router/test_questions.json \
    --result-file-path evaluations/data/uc_router/latest_new_test_error.csv \
