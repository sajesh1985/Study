import operator
import os
import traceback
from typing import Annotated, List, Optional
from typing_extensions import TypedDict
from langgraph.graph import StateGraph
from langgraph.constants import START, END
from langgraph.types import Send
from typing import Literal
from langgraph.types import interrupt, Command
import logging
from src.synthia.schemas.workflow import ReportConfig, ReportSection
from src.synthia.utils.logging_config import configure_logging
from src.synthia.agents.report_builder import ReportBuilder, SectionGenerationModeEnum
from src.synthia.persistence.database_manager import  get_checkpointer, get_store
from src.synthia.persistence.report_monitor import ReportMonitor
from src.synthia.schemas.template import TemplateSection
from src.synthia.utils.tree_utils import TreeUtils
from src.synthia.guardrails.custom_guardrails import Guardrails

# Initialize logger using centralized configuration
logger = configure_logging(
    logger_name=__name__,
    log_file="synthia.log",
    module_levels={__name__: logging.DEBUG},  # Set this module to DEBUG
)


class OverallState(TypedDict):
    report_config: ReportConfig
    report_outline: List[TemplateSection]
    report_sections_tree: List[ReportSection]
    all_sections: Annotated[List[ReportSection], operator.add]
    final_report: List[ReportSection]

    # Human interaction state
    human_approved_outline: bool
    human_approved_report: bool
    human_feedback_report: Optional[str]

    # Workflow control
    job_id: str
    current_section_idx: Optional[int]  # Index of the current section being processed
    status: Optional[str]
    progress: Annotated[Optional[float], operator.add]  # Must be None in initial state!
    error: Optional[str]

    # Chat functionality state - minimal fields needed for section editing
    prompt_mode: bool
    current_edit_request: Optional[str]  # Current edit instruction
    current_target_section_name: Optional[str]  # Section being edited
    current_edited_section: Optional[ReportSection]  # Result of edit
    current_prompt_id: Optional[str]  # Track current prompt
    current_user_section_prompt: Optional[str]  # Original user prompt
    current_user_action: Optional[str]  # "accept", "decline", "retry"
    current_guardrail_pass: Optional[bool]  # Track if guardrail check passed
    current_guardrail_message: Optional[str]  # Guardrail block message


class SectionState(TypedDict):
    report_config: ReportConfig
    curr_section: TemplateSection  # Current section being processed
    progress: Annotated[Optional[float], operator.add]


async def create_report_graph(report_builder: ReportBuilder, report_monitor: ReportMonitor) -> StateGraph:
    """Create the main report generation graph."""

    # Initialize guardrails
    guardrails = Guardrails()

    async def create_outline(
        state: OverallState,
    ) -> Command[Literal["human_review_of_outline"]]:
        report_outline: List[TemplateSection] = await report_builder.generate_outline(
            state["report_config"]
        )
        #num_sections = state["report_config"]["num_sections"]
        #report_outline = report_outline[0:num_sections]

        await report_monitor.update_job_progress(
            job_id=state['report_config']["job_id"],
            progress=0.1
        )

        return Command(
            update={"report_outline": report_outline, "progress": 0.1},
            goto="human_review_of_outline",
        )

    async def human_review_of_outline(
        state: OverallState,
    ) -> Command[Literal["section_parallelizer", "create_outline"]]:
        """Wait for human approval of the outline."""
        outline_for_review: List[TemplateSection] = state["report_outline"]
        state["status"] = "awaiting_approval"

        # Create the interrupt with the outline data
        is_approved = interrupt(
            {
                "question": "Please approve the outline.",
                "report_outline": outline_for_review,
                "status": "awaiting_approval",
            }
        )

        # Build a ReportSection tree mirroring the template outline (content initially template descriptions)
        def template_to_report_section(t: TemplateSection) -> ReportSection:
            return ReportSection(
                id=getattr(t, "id", "") or "",
                name=getattr(t, "section_title", "") or "",
                sections=[template_to_report_section(st) for st in (t.sections or [])]
                if getattr(t, "sections", None)
                else [],
            )

        report_sections_tree = [template_to_report_section(t) for t in outline_for_review]


        # Return based on approval
        if is_approved or state.get("human_approved_outline"):
            await report_monitor.update_job_progress(
                job_id=state['report_config']["job_id"],
                progress=0.2
            )
            return Command(update={"progress": 0.2, "report_sections_tree": report_sections_tree}, goto="section_parallelizer")
        else:
            return Command(goto="create_outline")

    async def section_parallelizer(state: OverallState) -> Command[Literal["section_writer"]]:
        """Parallelize section generation."""
        sends = []
        outline: List[TemplateSection] = state["report_outline"]
        
        leaf_nodes = TreeUtils.collect_leaf_nodes(outline)
        
        for section in leaf_nodes:
            sends.append(Send(
                    "section_writer",
                    {
                        "report_config": state["report_config"],
                        "curr_section": section,
                    },
                ))
        await report_monitor.update_job_progress(
            job_id=state['report_config']["job_id"],
            progress=0.3
        )
        return Command(update={"progress": 0.3}, goto=sends)

    async def section_writer(
        state: SectionState,
    ) -> Command[Literal["synthesizer"]]:
        job_id = state["report_config"].get("job_id", "unknown")
        try:
            outline_section = state["curr_section"]
            #read content from file otherwise call generate_section_content

            # section_id = outline_section.id
            # file_path = f"sections/{section_id}.json"

            # for local testing with a file cache
            # try:
            #     # Ensure the directory exists
            #     os.makedirs(os.path.dirname(file_path), exist_ok=True)

            #     with open(file_path, "r", encoding="utf-8") as file:
            #         logger.info(f"[job_id={job_id}] Reading section content from file: {file_path}")
            #         content = file.read()
            #         leaf_section_result = ReportSection.model_validate_json(content)
            # except FileNotFoundError:
            #     logger.info(f"[job_id={job_id}] File not found for section {section_id}, generating content.")
            #     # Generate content for the leaf section
            #     leaf_section_result: ReportSection = (
            #         await report_builder.generate_section_content(
            #             config=state["report_config"],
            #             section=outline_section,
            #         )
            #     )
            #     # Save generated content to file
            #     with open(file_path, "w", encoding="utf-8") as file:
            #         logger.info(f"[job_id={job_id}] Writing generated content to file: {file_path}")
            #         file.write(leaf_section_result.model_dump_json())

            # Generate content for the leaf section
            leaf_section_result: ReportSection = (
                await report_builder.generate_section_content(
                    config=state["report_config"],
                    section=outline_section,
                )
            )

          
            await report_monitor.update_job_progress(
                job_id=state['report_config']["job_id"],
                progress=0.5
            )
            
            return Command(
                update={"all_sections": [leaf_section_result], "progress": 0.5},
                goto="synthesizer",
            )
        except Exception as e:
            logger.error(f"[job_id={job_id}] Error processing section {outline_section.section_title}: {e}", exc_info=True)
            error_section = ReportSection(
                name=outline_section.section_title,
                content=f"Error processing section: {outline_section.section_title} - {str(e)}",
            )
            await report_monitor.update_job_progress(
                job_id=state['report_config']["job_id"],
                progress=0.5
            )
            return Command(
                update={"all_sections": [error_section], "progress": 0.5},
                goto="synthesizer",
            )

    async def synthesizer(
        state: OverallState,
    ) -> Command[Literal["chat_interface"]]:
        """Finalize the report using the report agent wrapper function."""

        job_id = state["report_config"].get("job_id", "unknown")
        try:

            if "report_sections_tree" in state and state.get("all_sections"):
                generated_by_name = {s.name: s for s in state["all_sections"] if getattr(s, "name", None)}

                def update_tree(nodes: List[ReportSection]) -> None:
                    for node in nodes:
                        if node.name in generated_by_name:
                            gen = generated_by_name[node.name]
                            # Copy over content (and any generated subsections if present)
                            node.content = gen.content
                            node.sources = gen.sources
                            node.chart_data = gen.chart_data
                            if getattr(gen, "sections", None):
                                node.sections = gen.sections
                        if getattr(node, "sections", None):
                            update_tree(node.sections)

                update_tree(state["report_sections_tree"])

            report_sections_tree = state["report_sections_tree"] or []

            finalized_sections = await report_builder.finalize_report(
                sections=report_sections_tree,
                report_template=state["report_config"].get("style", ""),
            )
            await report_monitor.update_job_progress(
                job_id=state['report_config']["job_id"],
                progress=1.0
            )

            return Command(
                update={
                    "final_report": finalized_sections,
                    "status": "completed",
                    "progress": 1.0,
                    "prompt_mode": True,
                },
                goto="chat_interface",
            )
        except Exception as e:
            logger.error(f"[job_id={job_id}] Error finalizing report: {e}", exc_info=True)
            state["error"] = str(e)
            state["status"] = "failed"
            return Command(goto=END)

    async def chat_interface(
        state: OverallState,
    ) -> Command[Literal["guardrails_check", "__end__"]]:
        """Interactive chat interface for section editing."""

        final_report = state["final_report"] if state.get("final_report") else []

        user_input = interrupt({
            "question": "Report generation complete! You can now edit any section by specifying the section name and your edit request, or type 'exit' to finish.",
            "final_report": final_report,
            "status": "prompt_mode",
        })
        
        # Parse user input - handle both dict format from API and direct commands
        if user_input and isinstance(user_input, dict):
            if user_input.get("action") == "exit":
                return Command(goto=END)
            
            # Handle API request format with all required fields
            edit_request = user_input.get("prompt") or user_input.get("edit_request", "")
            target_section = user_input.get("section_name") or user_input.get("target_section", "")
            prompt_id = user_input.get("prompt_id", "")
            user_section_prompt = user_input.get("user_section_prompt", edit_request)
            
            if edit_request and target_section:
                return Command(
                    update={
                        "current_edit_request": edit_request,
                        "current_target_section_name": target_section,
                        "current_user_section_prompt": user_section_prompt,
                        "current_prompt_id": prompt_id,
                        "current_guardrail_pass": None,
                        "current_guardrail_message": None,
                    },
                    goto="guardrails_check"
                )
        
        # If no valid input, stay in chat
        return Command(goto="chat_interface")

    async def guardrails_check(
        state: OverallState,
    ) -> Command[Literal["section_editor", "human_review_edit"]]:
        """Check user input against guardrails before processing edit request."""
        
        job_id = state["report_config"].get("job_id", "unknown")
        current_prompt_id = state.get("current_prompt_id")
        edit_request = state["current_edit_request"]
        
        try:
            # Run guardrails check on the edit request
            guardrail_result = await guardrails.input_guardrail(edit_request)
            
            if guardrail_result.get("blocked", False):
                # If blocked, return to human_review_edit with error info
                logger.warning(f"[job_id={job_id}], [prompt_id={current_prompt_id}] Edit request blocked by guardrails: {guardrail_result.get('blocked_categories')}##{guardrail_result.get('message')}")
                
                return Command(
                    update={
                        "current_guardrail_pass": False,
                        "current_guardrail_message": guardrail_result.get("message"),
                        "current_edited_section": None,  # No edited section to show
                    },
                    goto="human_review_edit"
                )
            
            # If passed, proceed to section editor
            logger.info(f"[job_id={job_id}], [prompt_id={current_prompt_id}] Edit request passed guardrails check")
            return Command(
                update={"current_guardrail_pass": True, "current_guardrail_message": None},
                goto="section_editor"
            )
            
        except Exception as e:
            logger.error(f"[job_id={job_id}], [prompt_id={current_prompt_id}] Error in guardrails check: {e}", exc_info=True)
            # On error, allow the request to proceed but log the issue
            return Command(
                update={
                    "current_guardrail_pass": False,
                    "current_guardrail_message": "Content moderation service unavailable. Please try again.",
                },
                goto="human_review_edit"
            )

    async def section_editor(
        state: OverallState,
    ) -> Command[Literal["human_review_edit"]]:
        """Edit a specific section based on user request."""
        
        job_id = state["report_config"].get("job_id", "unknown")
        try:
            target_section_name = state["current_target_section_name"]
            edit_request = state["current_edit_request"]
            
            # Find the target section in the final report
            def find_section(sections: List[ReportSection], name: str) -> Optional[ReportSection]:
                for section in sections:
                    if section.name == name:
                        return section
                    if hasattr(section, 'sections') and section.sections:
                        found = find_section(section.sections, name)
                        if found:
                            return found
                return None
            
            target_section = find_section(state["final_report"], target_section_name)
            
            if not target_section:
                return Command(
                    update={"error": f"Section '{target_section_name}' not found"},
                    goto="chat_interface"
                )

            # get outline section from report_outline by matching the section title
            outline_section = next((s for s in TreeUtils.collect_leaf_nodes(state["report_outline"]) 
                                    if s.section_title == target_section_name), None)

            if not outline_section:
                return Command(
                    update={"error": f"Template section '{target_section_name}' not found in outline"},
                    goto="chat_interface"
                )

            # Generate edited content using the report builder
            edited_section = await report_builder.generate_section_content(
                config=state["report_config"],
                section=outline_section,
                mode=SectionGenerationModeEnum.Edit,
                user_prompt=edit_request,
                existing_section_content=target_section
            )

            final_report = state["final_report"]
            
            # Add sources from edited section to the "Sources & References" section
            if edited_section.sources:
                # Find the "Sources & References" section (usually the last one)
                sources_section = next(
                    (s for s in final_report if s.name == "Sources & References"),
                    None
                )
                
                if sources_section:
                    # Get existing sources or initialize empty list
                    existing_sources = sources_section.sources or []
                    
                    # Create a set of existing source identifiers for deduplication
                    existing_source_keys = set()
                    for src in existing_sources:
                        key = src.url or src.name or src.id or ""
                        if key:
                            existing_source_keys.add(key.strip().lower())
                    
                    # Add new sources if they don't already exist
                    new_sources = []
                    for src in edited_section.sources:
                        key = src.url or src.name or src.id or ""
                        normalized_key = key.strip().lower() if key else ""
                        
                        if normalized_key and normalized_key not in existing_source_keys:
                            new_sources.append(src)
                            existing_source_keys.add(normalized_key)
                    
                    # Update sources section with combined sources
                    if new_sources:
                        sources_section.sources = existing_sources + new_sources
                        logger.info(f"[job_id={job_id}] Added {len(new_sources)} new sources from edited section '{target_section_name}'")
            
            return Command(
                update={"current_edited_section": edited_section, "final_report": final_report},
                goto="human_review_edit"
            )
            
        except Exception as e:
            logger.error(f"[job_id={job_id}] Error editing section: {e}", exc_info=True)
            return Command(
                update={"error": f"Error editing section: {str(e)}"},
                goto="chat_interface"
            )

    async def human_review_edit(
        state: OverallState,
    ) -> Command[Literal["chat_interface", "guardrails_check"]]:
        """Human review of the edited section."""
        
        # Check if this is a guardrail block scenario
        if state.get("current_guardrail_pass") is False:
            user_action = interrupt({
                "question": "Your edit request was blocked by content policy. Please provide different instructions or decline.",
                "message": state.get("current_guardrail_message"),
                "status": "guardrail_blocked",
                "prompt_id": state.get("current_prompt_id"),
            })
        else:
            user_action = interrupt({
                "question": "Please review the edited section. Choose: accept, decline, or retry with different instructions.",
                "original_section": next(
                    (s for s in TreeUtils.collect_leaf_nodes(state["final_report"]) 
                     if s.name == state["current_target_section_name"]), 
                    None
                ),
                "edited_section": state["current_edited_section"],
                "status": "review_edit",
                "prompt_id": state.get("current_prompt_id"),
            })
        
        # Handle string actions directly
        action = user_action
        if isinstance(user_action, dict):
            action = user_action.get("action", "")
        
        if action == "accept":
            # Apply the edit to the final report
            def update_section(sections: List[ReportSection]) -> bool:
                for i, section in enumerate(sections):
                    if section.name == state["current_target_section_name"]:
                        sections[i] = state["current_edited_section"]
                        return True
                    if hasattr(section, 'sections') and section.sections:
                        if update_section(section.sections):
                            return True
                return False
            
            update_section(state["final_report"])
            
            return Command(
                update={
                    "current_user_action": "accept",
                    "current_edit_request": None,
                    "current_target_section_name": None,
                    "current_edited_section": None,
                    "current_prompt_id": None,
                    "current_guardrail_pass": None,
                    "current_guardrail_message": None,
                },
                goto="chat_interface"
            )
        
        elif action == "decline":
            return Command(
                update={
                    "current_user_action": "decline",
                    "current_edit_request": None,
                    "current_target_section_name": None,
                    "current_edited_section": None,
                    "current_prompt_id": None,
                    "current_guardrail_pass": None,
                    "current_guardrail_message": None,
                },
                goto="chat_interface"
            )
        
        elif action == "retry":
            # Treat retry as end of current prompt workflow and handle that with a separate prompt request from the UI.
             return Command(
                update={
                    "current_user_action": "retry",
                    "current_edit_request": None,
                    "current_target_section_name": None,
                    "current_edited_section": None,
                    "current_prompt_id": None,
                    "current_guardrail_pass": None,
                    "current_guardrail_message": None,
                },
                goto="chat_interface"
            )
        else:
            # Invalid action, return to chat interface
            return Command(
                update={
                    "error": "Invalid action. Please choose accept, decline, or retry.",
                    "current_user_action": None,
                    "current_edit_request": None,
                    "current_target_section_name": None,
                    "current_edited_section": None,
                    "current_prompt_id": None,
                    "current_guardrail_pass": None,
                    "current_guardrail_message": None,
                },
                goto="chat_interface"
            )

    # def human_review_of_final_report(
    #     state: OverallState,
    # ) -> Command[Literal[END, "section_parallelizer"]]:  # type: ignore
    #     """Wait for human approval of the final report."""
    #     state["status"] = "awaiting_final_approval"

    #     is_approved = True

    #     # is_approved = interrupt(
    #     #     {
    #     #         "question": "Please approve the final report.",
    #     #         "final_report": state["final_report"],
    #     #         "status": "awaiting_final_approval",
    #     #     }
    #     # )

    #     if is_approved or state.get("human_approved_report"):
    #         return Command(update={"progress": 1.0}, goto=END)
    #     else:
    #         return Command(goto="section_parallelizer")

    builder = StateGraph(OverallState)
    # Add nodes with dependency injection
    builder.add_node("create_outline", create_outline)
    builder.add_node("human_review_of_outline", human_review_of_outline)

    builder.add_node("section_parallelizer", section_parallelizer)
    builder.add_node("section_writer", section_writer)
    builder.add_node("synthesizer", synthesizer)
    builder.add_node("chat_interface", chat_interface)
    builder.add_node("guardrails_check", guardrails_check)
    builder.add_node("section_editor", section_editor)
    builder.add_node("human_review_edit", human_review_edit)

    # Add edges
    builder.add_edge(START, "create_outline")
    # builder.add_edge("section_parallelizer", "synthesizer")

    #conn = await AsyncConnection.connect(postgres_connection_string, **connection_kwargs)

    # storage = StorageProvider()
    # await storage.initialize()

    checkpointer = get_checkpointer()
    store = get_store()

    graph = builder.compile(
        checkpointer=checkpointer,
        store=store,
        debug=False,
        name="report_workflow",
    )

    return graph
