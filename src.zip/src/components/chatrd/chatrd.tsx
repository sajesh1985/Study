import { NotificationProvider, NotificationStyle, useIsBreakpoint } from '@spglobal/react-components';
import React, { useEffect} from 'react';
import { Chat } from '../../components/ChatScreen/Chat';
import { LeftBar } from '../_common/LeftBar/LeftBar';
import { useState } from 'react';
import { getChatHistory, getUserPreferences, updateUserPreferences } from '../../services/api';
import { BreakPoint } from '@spglobal/koi-helpers';
import { ChatHistoryRequestPayload } from '@root/types/api';
import { SplashScreen } from '../_common/Splashscreen/Splashscreen';
import { useUserTraits } from '@spglobal/userprofileservice';
import { ChatHistoryGroup, groupChatHistoryOption } from '../../utils/chatHistoryManager';
import { styles } from './chatrd.styles';



export const App: React.FC = () => {
  const userInformation = useUserTraits(['keyOnlineUser']);
  const [chatHistoryList, setchatHistory] = useState<ChatHistoryGroup>({});
  const [hasAccepted, setHasAccepted] = useState(false);
  const [isLoading, setLoading] = useState(true);
  useEffect(() => { 
    const loadChatHistory = async () => { 
       
        let  args: ChatHistoryRequestPayload = {
          keyonlineuser:userInformation?.keyOnlineUser,
        };
        // Await make wait until that 
        // promise settles and return its result 
        let response = await getChatHistory(args);
        let chatGroups: ChatHistoryGroup = groupChatHistoryOption(response);

        // After fetching data stored it in posts state. 
        setchatHistory(chatGroups); 

    }; 

    const isDisclaimerAcknowledged   = async () => {
        let isAck = await getUserPreferences();
        isAck ? setHasAccepted(true):setHasAccepted(false);
        setLoading(false);
    };

    // Call the function 
    
    isDisclaimerAcknowledged();
    loadChatHistory(); 
}, []); 

  const isLeftArrowVisible = useIsBreakpoint(BreakPoint.MD) ? true:false;
  const [isLeftMenuExpanded, setLeftMenuExpanded] = useState(!isLeftArrowVisible);
  const [mainWidth, setMainWidth] = useState('80%');

  const toggleSidebar = () => {
    setLeftMenuExpanded(!isLeftMenuExpanded);
    setMainWidth(isLeftMenuExpanded ? '95%':'80%');
  };

  const handleProceed = () =>{
    const updateDisclaimer = async () => {
      //addNotification("Export started: may take more than 2 mins", NotificationType.INFO);
    
    
      //var resp =await exportResult();
      await updateUserPreferences();
      //addNotification("Export completed", NotificationType.SUCCESS); 
      //window.open(resp.message,"_blank");
    };
    setHasAccepted(true);
    updateDisclaimer(); 
  };

  useEffect(() => {
    function handler() {
      (isLeftArrowVisible == false)
        ? setLeftMenuExpanded(true)
        : isLeftMenuExpanded;
      setMainWidth('80%');
    }
    
    window.addEventListener('resize', handler);
    
    return () => {
      window.removeEventListener('resize', handler);
    };
  }, []);

  if (isLoading) {
    return <div className="App ChatRd-App">Loading...</div>;
  }
  
  return (
    <NotificationProvider closable toastBottomOffset={20} type={NotificationStyle.TOAST}>
      <div className="App ChatRd-App">
        {console.log(mainWidth)}
        {(
          <div css={hasAccepted ? styles.nodisclaimer:styles.disclaimer}>
            <LeftBar 
              chatHistory={chatHistoryList}
              isLeftArrowVisible={isLeftArrowVisible}
              isLeftMenuExpanded={isLeftMenuExpanded}
              expanded={toggleSidebar}
            />
            
            <div style={{
                transition:'width 0.3s ease',
                marginLeft: '240px',
                paddingLeft: '16px',
                }} >
              <Chat />
            </div>
          </div>
        )}
        {!hasAccepted && <SplashScreen onAccept={() => handleProceed()} />}
      </div>
    </NotificationProvider>
  );
};