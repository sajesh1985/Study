Running test_response_with_retrieved_using_ragas.py

    python evaluations/test_response_with_retrieved_using_ragas.py --questions-csv evaluations/questions.csv --report-file-path comparison.csv  --analyzer claude-instant-v1 --synthesizer claude-3-haiku