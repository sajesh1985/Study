﻿// Copyright Notice! 
// This document is protected under the trade secret and copyright 
// laws as the property of Fidelity National Information Services, Inc. 
// Copying, reproduction or distribution should be limited and only to 
// employees with a “need to know” to do their job. 
// Any disclosure of this document to third parties is strictly prohibited.
// © 2017 Fidelity National Information Services.
// All rights reserved worldwide.
namespace Fis.Epp.Fusion.WebAPI.Controllers
{
    using Carbon.Branding;
    using Carbon.ComponentModel;
    using Fis.Epp.Fusion.WebAPI.Common;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Options;
    using Models;
    using Newtonsoft.Json;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;

    /// <summary>
    /// Resources controller serving RESTful requests for brandable external resources.
    /// </summary>
    public class ResourcesController : BaseController
    {
        #region Public Constructors
        public ResourcesController(IOptions<AppSettings> settings) : base(settings)
        {
        }
        #endregion

        #region Private properties
        /// <summary>
        /// Gets or sets the Properties resource.
        /// </summary>
        [ResourceBinding("Properties")]
        private IResourceReader<string> Properties { get; set; }

        /// <summary>
        /// Gets or sets the Settings resource.
        /// </summary>
        [ResourceBinding("Settings")]
        private IResourceReader<string> Settings { get; set; }

        /// <summary>
        /// Gets or sets the Theme resource.
        /// </summary>
        [ResourceBinding("Theme")]
        private IResourceReader<string> Theme { get; set; }

        /// <summary>
        /// Gets or sets the Text resource.
        /// </summary>
        [ResourceBinding("Text")]
        private IResourceReader<string> Text { get; set; }

        /// <summary>
        /// Gets or sets the Formats resource.
        /// </summary>
        [ResourceBinding("Formats")]
        private IResourceReader<string> Formats { get; set; }

        /// <summary>
        /// Gets or sets the external resource.
        /// </summary>
        [ResourceBinding("ExternalResources")]
        private IResourceReader<object> ExternalResourcesDefinitions { get; set; }

        /// <summary>
        /// Gets or sets the menu items.
        /// </summary>
        [ResourceBinding("Properties", "FusionMenuItems")]
        [TypeConverter(typeof(StringArrayConverter))]
        protected string[] FusionMenuItems { get; set; }

        /// <summary>
        /// Gets or sets the Menu Items resource.
        /// </summary>
        [ResourceBinding("MenuItems")]
        protected IResourceReader<object> MenuItemDefinitions { get; set; }

        #endregion

        #region Public methods

        /// <summary>
        /// Get all the dependent resources for a brand
        /// </summary>        
        /// <returns>json data with dependant external resources</returns>
        [HttpGet]
        [Route("api/Resources/All/{name}/{product}")]
        [Route("api/Resources/All/{name}")]
        [Route("api/Resources/All")]
        public IActionResult GetResources()
        {
            var resourceContext = ResourceContext;
            if (string.IsNullOrEmpty(resourceContext.Brand.ToString()))
                return NotFound();
            BrandingManager.BindResources(this, resourceContext);
            if (!string.IsNullOrEmpty(ProductValue))
            {
                ProductCode productCode;
                Enum.TryParse(Convert.ToString(ProductValue), true, out productCode);
                return Json(new { Text = FilterResources(Text, productCode), Properties = FilterResources(Properties, productCode) });
            }
            else
            {
                var TextResources = GetTextItems(Text);
                var PropertyResources = GetPropertyItems(Properties);
                var resourceCollection = new { Text = TextResources, Properties = PropertyResources };
                return Json(new { data = JsonConvert.SerializeObject(resourceCollection) });
            }
        }

        /// <summary>
        /// Get all the dependent text resources for a brand
        /// </summary>        
        /// <returns>json data with dependant external resources</returns>
        [HttpGet]
        [Route("api/Resources/Text/{name}/{product}")]
        [Route("api/Resources/Text/{name}")]
        [Route("api/Resources/Text")]
        public IActionResult GetResourcesText()
        {
            var resourceContext = ResourceContext;
            if (string.IsNullOrEmpty(resourceContext.Brand.ToString()))
                return NotFound();
            BrandingManager.BindResources(this, resourceContext);
            if (!string.IsNullOrEmpty(ProductValue))
            {
                ProductCode productCode;
                Enum.TryParse(Convert.ToString(ProductValue), true, out productCode);
                return Json(new { Text = FilterResources(Text, productCode) });
            }
            else
            {
                return Json(new { data = JsonConvert.SerializeObject(GetTextItems(Text)) });
            }
        }

        /// <summary>
        /// Get all the dependent properties resources for a brand
        /// </summary>        
        /// <returns>json data with dependant external resources</returns>
        [HttpGet]
        [Route("api/Resources/Properties/{name}/{product}")]
        [Route("api/Resources/Properties/{name}")]
        [Route("api/Resources/Properties")]
        public IActionResult GetResourcesProperties()
        {
            var resourceContext = ResourceContext;
            if (string.IsNullOrEmpty(resourceContext.Brand.ToString()))
                return NotFound();
            BrandingManager.BindResources(this, resourceContext);
            if (!string.IsNullOrEmpty(ProductValue))
            {
                ProductCode productCode;
                Enum.TryParse(Convert.ToString(ProductValue), true, out productCode);
                return Json(new { Properties = FilterResources(Properties, productCode) });
            }
            else
            {
                return Json(Properties);
            }
        }

        /// <summary>
        /// Get all the dependent external resources respective
        /// </summary>        
        /// <returns>json data with dependant external resources</returns>
        [HttpGet("api/Resources/GetExternalResources")]
        public IActionResult GetExternalResources()
        {
            var resourceContext = ResourceContext;
            if (string.IsNullOrEmpty(resourceContext.Brand.ToString()))
                return NotFound();
            BrandingManager.BindResources(this, resourceContext);
            return Json(ResolveExternalResources());
        }


        /// <summary>
        /// Get all the dependent base resources
        /// </summary>        
        /// <returns>json data with all resources</returns>
        [HttpGet("api/Resources/GetBrandingResources")]
        public IActionResult GetBrandingResources()
        {
            var resourceContext = ResourceContext;
            if (string.IsNullOrEmpty(resourceContext.Brand.ToString()))
                return NotFound();
            BrandingManager.BindResources(this, resourceContext);
            var BrandId = resourceContext.Brand.Id;
            var MenuItems = GetMenuItems(FusionMenuItems, "").MenuItemList.ToArray();
            var resourceCollection = new { BrandId, Settings, MenuItems, Theme };
            return Json(resourceCollection);
        }
        #endregion


        #region Private methods

        private ResourcesAggregatorModel ResolveExternalResources()
        {
            var resourcesAggregatorModel = new ResourcesAggregatorModel();
            var externalResources = ExternalResourcesDefinitions.ToList();
            var keys = ExternalResourcesDefinitions.Keys;
            foreach (string key in keys)
            {
                var resourceData = externalResources.Where(x => x.Key == key).FirstOrDefault();
                switch (key)
                {
                    case "Text":
                        var textResources = resourceData.Value.ToString().Split(',');
                        if (textResources.Any())
                        {
                            foreach (var resourceKey in textResources)
                            {
                                if (!string.IsNullOrEmpty(resourceKey))
                                    resourcesAggregatorModel.Text.Add(resourceKey, Text[resourceKey]);
                            }
                        }
                        break;
                    case "Properties":
                        var propertyResources = resourceData.Value.ToString().Split(',');
                        foreach (var resourceKey in propertyResources)
                        {
                            if (!string.IsNullOrEmpty(resourceKey))
                                resourcesAggregatorModel.Properties.Add(resourceKey, Properties[resourceKey]);
                        }

                        break;
                    case "Formats":
                        var formatResources = resourceData.Value.ToString().Split(',');
                        if (formatResources.Any())
                        {
                            foreach (var resourceKey in formatResources)
                            {
                                if (!string.IsNullOrEmpty(resourceKey))
                                    resourcesAggregatorModel.Formats.Add(resourceKey, Formats[resourceKey]);
                            }
                        }
                        break;
                    default:
                        break;
                }
            }
            return resourcesAggregatorModel;
        }

        private MenuModel GetMenuItems(string[] menuItemsToRender, string activeItemId)
        {
            var menuItems = new MenuModel();
            var menuItemList = new List<MenuModel.MenuItem>();
            foreach (var key in menuItemsToRender)
            {
                if (MenuItemDefinitions.ContainsKey(key))
                {
                    var attributes = MenuItemDefinitions.GetAttributes(key);
                    var menuItem = new MenuModel.MenuItem
                    {
                        Id = attributes["Id"],
                        Text = attributes["Text"],
                        TooltipText = attributes["TooltipText"],
                        RouterLink = attributes["RouterLink"],
                        HasCounter = attributes["HasCounter"]
                    };
                    menuItemList.Add(menuItem);
                }
            }
            menuItems.MenuItemList = menuItemList;

            if (!string.IsNullOrEmpty(activeItemId))
            {
                menuItems.ActiveMenu = menuItems.MenuItemList.FirstOrDefault(p => p.Id == activeItemId);
            }

            return menuItems;
        }
        private object FilterResources(IResourceReader<string> resource, ProductCode productCode)
        {
            string filterKey = ResolveBrandFilter(productCode);
            if (!string.IsNullOrEmpty(filterKey))
            {
                return resource.Where(x => !x.Key.Contains(filterKey));
            }
            return Text;
        }

        private Dictionary<string, string> GetTextItems(IResourceReader<string> textItemsToRender)
        {
            Dictionary<string, string> textItems = new Dictionary<string, string>();
            foreach (var key in textItemsToRender)
            {
                if (Text.ContainsKey(key.Key))
                {
                    textItems.Add(Convert.ToString(key.Key), Convert.ToString(key.Value));
                }
            }
            return textItems;
        }

        private Dictionary<string, string> GetPropertyItems(IResourceReader<string> propertyItemsToRender)
        {
            Dictionary<string, string> propertyItems = new Dictionary<string, string>();
            foreach (var key in propertyItemsToRender)
            {
                if (Properties.ContainsKey(key.Key))
                {
                    propertyItems.Add(Convert.ToString(key.Key), Convert.ToString(key.Value));
                }
            }
            return propertyItems;
        }
        #endregion
    }
}
