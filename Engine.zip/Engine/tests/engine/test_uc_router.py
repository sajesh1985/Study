import numpy as np

from chatrd.engine.components.query_analyzer.uc_router.utils import cosine_similarity


def test_cosine_similarity():
    # Test case 1: Basic functionality
    query_vector = np.array([0.5, 0.3, 0.8])
    document_matrix = np.array([[0.1, 0.9, 0.4], [0.2, 0.5, 0.7], [0.8, 0.1, 0.5]])
    expected_result = np.array([0.65306122, 0.92645575, 0.88377925])
    np.testing.assert_allclose(cosine_similarity(query_vector, document_matrix), expected_result, atol=1e-7)

    # Test case 2: Handling zero vectors
    zero_query_vector = np.array([0.0, 0.0, 0.0])
    zero_document_matrix = np.array([[0.0, 0.0, 0.0], [0.1, 0.1, 0.1], [0.0, 0.0, 0.0]])
    expected_result_zero = np.array([0.0, 0.0, 0.0])
    result = cosine_similarity(zero_query_vector, zero_document_matrix)
    np.testing.assert_allclose(result, expected_result_zero[~np.isnan(result)], atol=1e-7)

    # Test case 3: Large random vectors
    large_query_vector = np.random.rand(100)
    large_document_matrix = np.random.rand(10, 100)
    assert cosine_similarity(large_query_vector, large_document_matrix).shape == (10,)
