import os
import sys
import asyncio
import logging
import signal
from functools import lru_cache
from src.synthia.persistence.database_manager import initialize_connection_pool, close_connection_pool

from typing import Dict, Any

from src.synthia.queue.queue_backend import get_queue_backend, InboundMessage, BaseQueueBackend
from src.synthia.queue.queue_handler import ACTION_HANDLERS
import traceback
from langfuse import Langfuse
from src.synthia.config.api_config import get_config
from src.synthia.aws_utils.aws_client import (
    get_aws_client,
    get_secret,
)
from src.synthia.utils.logging_context import set_correlation_id_logging_context, set_action_handler_logging_context

logger = logging.getLogger(__name__)
cfg = get_config()

MAX_CONCURRENCY      = cfg.get("QUEUE_CONCURRENCY")
BATCH_SIZE           = int(os.getenv("BATCH_SIZE", "10"))
WAIT_TIME_SECONDS    = int(os.getenv("WAIT_TIME_SECONDS", "20"))
HEARTBEAT_EVERY_SEC  = int(os.getenv("HEARTBEAT_EVERY_SEC", "30"))
HEARTBEAT_EXTEND_BY  = int(os.getenv("HEARTBEAT_EXTEND_BY", "60"))
MAX_RETRIES_PER_MSG  = int(os.getenv("MAX_RETRIES_PER_MSG", "3"))

class ReportQueueConsumer:
    def __init__(self):
        self.backend: BaseQueueBackend = get_queue_backend()
        self._stop = asyncio.Event()
        self._sem = asyncio.Semaphore(MAX_CONCURRENCY)
        self._pending: set[asyncio.Task] = set()
        self.langfuse = None
       
    def _init_langfuse(self):
        """Initialize Langfuse client. Never raises exceptions."""
        try:
            
            langfuse_enabled = cfg.get("langfuse_enabled_env_var")
            
            # Handle both boolean and string values
            if isinstance(langfuse_enabled, bool):
                is_enabled = langfuse_enabled
            elif isinstance(langfuse_enabled, str):
                is_enabled = langfuse_enabled.lower() == "true"
            else:
                is_enabled = False
            
            if not is_enabled:
                logger.info("Langfuse is disabled (langfuse_enabled=%s)", langfuse_enabled)
                self.langfuse = None
                return

            logger.info("Langfuse is enabled, initializing client...")
            secrets_manager_client = get_aws_client("secretsmanager")
            secrets = get_secret(secrets_manager_client, cfg.get("secrets_name"))

            p_k = secrets.get(cfg.get("langfuse_public_key_env_var"))
            s_k = secrets.get(cfg.get("langfuse_secret_key_env_var"))
            host = cfg.get("langfuse_host_env_var")

            self.langfuse = Langfuse(
                public_key=p_k,
                secret_key=s_k,
                host=host,
                debug=secrets.get(cfg.get("langfuse_debug_env_var"), "false").lower() == "true",
            )

            logger.debug(f"Langfuse client created: {self.langfuse}")
            
            if self.langfuse.auth_check():
                logger.info("Langfuse client is authenticated and ready!")
            else:
                logger.warning("Langfuse authentication failed. Please check your credentials and host.")
                self.langfuse = None
        except Exception as e:
            logger.error(f"Error initializing Langfuse: {e}", exc_info=True)
            self.langfuse = None

    def _cleanup_langfuse(self):
        """Flush Langfuse traces. Never raises exceptions."""
        if self.langfuse is None:
            logger.debug("Langfuse cleanup skipped (client not initialized)")
            return
        
        try:
            logger.info("Flushing Langfuse traces...")
            self.langfuse.flush()
            logger.info("Langfuse traces flushed successfully")
        except Exception as e:
            logger.error(f"Error flushing Langfuse traces: {e}", exc_info=True)

    async def _heartbeat(self, msg: InboundMessage):
        """Extend visibility for in-flight work (no-op on in-memory)."""
        try:
            while not self._stop.is_set():
                await asyncio.sleep(HEARTBEAT_EVERY_SEC)
                await self.backend.extend_visibility(msg, HEARTBEAT_EXTEND_BY)
                logger.debug("Extended visibility id=%s by %ss", msg.id, HEARTBEAT_EXTEND_BY)
        except asyncio.CancelledError:
            try:
                await self.backend.extend_visibility(msg, 10)
            except Exception:
                pass
            raise

    async def _handle_one(self, msg: InboundMessage):
        async with self._sem:
            env = msg.payload or {}
            action = env.get("action") or env.get("type")
            inner = env.get("payload", env)
            set_correlation_id_logging_context(inner.get("correlation_id"))
            set_action_handler_logging_context(action)

            handler = ACTION_HANDLERS.get(action)
            if not handler:
                logger.error("Unknown action '%s' id=%s; acking to drop.", action, msg.id)
                await self.backend.ack(msg)
                return

            hb = asyncio.create_task(self._heartbeat(msg))
            try:
                await handler(inner)
            except Exception as e:
                import traceback
                logger.error("Exception occurred while handling message id=%s:\n%s", msg.id, traceback.format_exc())
                hb.cancel()
                logger.error(f"Error in handling job {msg.id}: {e}", exc_info=True)
                await asyncio.gather(hb, return_exceptions=True)

                if msg.retry_count >= MAX_RETRIES_PER_MSG:
                    logger.exception("Permanent failure after %s tries id=%s; leaving for redrive. err=%s",
                                     msg.retry_count, msg.id, e)
                    await self.backend.nack(msg, error=str(e), retry_in_seconds=None)
                    return

                backoff = min(2 ** max(1, msg.retry_count), 60)
                logger.info("Retry=%s id=%s; requeue in %ss;", msg.retry_count, msg.id, backoff)
                await self.backend.nack(msg, error=str(e), retry_in_seconds=backoff)
                return

            hb.cancel()
            await asyncio.gather(hb, return_exceptions=True)
            await self.backend.ack(msg)

    async def run_forever(self):
        logger.info("Consumer starting (backend=%s)…", os.getenv("QUEUE_BACKEND", "local"))
        try:
            self._init_langfuse()
            while not self._stop.is_set():
                # how many handlers can we start right now?
                inflight = len(self._pending)
                available = MAX_CONCURRENCY - inflight

                if available <= 0:
                    # All slots are busy — don't pull more messages. Back off a bit.
                    await asyncio.sleep(10)
                    continue

                # Request at most `available` messages (and at most BATCH_SIZE)
                to_receive = min(BATCH_SIZE, available)
                # logger.info(f"Trying to get next {to_receive} messages from queue")
                batch = await self.backend.receive_batch(max_messages=to_receive, wait_time_seconds=WAIT_TIME_SECONDS)

                if not batch:
                    # no messages currently; tiny sleep to avoid busy-loop
                    await asyncio.sleep(0.01)
                    continue

                for m in batch:
                    if self._stop.is_set():
                        break
                    t = asyncio.create_task(self._handle_one(m))
                    self._pending.add(t)
                    t.add_done_callback(self._pending.discard)

        finally:
            logger.info("Draining %s in-flight tasks…", len(self._pending))
            await asyncio.gather(*self._pending, return_exceptions=True)
            logger.info("Consumer stopped.")

    async def stop(self):
        self._stop.set()
        self._cleanup_langfuse()

@lru_cache(maxsize=1)
def get_consumer() -> ReportQueueConsumer:
    return ReportQueueConsumer()


# async def _main():
#     logger.info("Initializing connection pool...")
#     await initialize_connection_pool()
#     logger.info("Connection pool initialized successfully")
#     consumer = ReportQueueConsumer()
#     loop = asyncio.get_running_loop()
#
#     def _sig():
#         logger.warning("Shutdown signal received. Draining…")
#         asyncio.create_task(consumer.stop())
#         logger.info("Closing connection pool...")
#         asyncio.create_task(close_connection_pool())
#         logger.info("Connection pool closed successfully")
#
#     for sig in (signal.SIGINT, signal.SIGTERM):
#         try:
#             loop.add_signal_handler(sig, _sig)
#         except NotImplementedError:
#             pass  # Windows
#
#     await consumer.run_forever()
#
# if __name__ == "__main__":
#     if sys.platform == "win32":
#         asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
#     asyncio.run(_main())
