import pandas as pd
import pytest

from chatrd.core.utils import safe_get, dict_coalesce, df_safe_get


# Testing "safe_get" function
nested_list = [[[], ["a", "b", "c"]], [1, 2, 3]]
nested_dict = {"name": "test-data", "data": {"a": 1, "b": 2, "c": 3}}
list_of_dicts = [{"name": "empty-data", "data": []}, {"name": "test-data", "data": {"a": 1, "b": 2}}]
list_and_dict_mix = {"name": "test-data", "data": [{"id": 1, "value": 10}, {"id": 2, "value": 20}]}

test_data_collection = [
    (nested_list, [0, 1, 2], "c"),
    (nested_dict, ["data", "a"], 1),
    (list_of_dicts, [1, "data", "a"], 1),
    (list_and_dict_mix, ["data", 1, "value"], 20),
]

test_data_collection_with_defaults = [
    (None, [0, 1, 2], None),
    (nested_list, [1, 2, 3], None),
    (nested_list, [1, 2, 3], 0),
    (nested_dict, ["data", "d"], None),
    (list_of_dicts, [1, "data", "value"], None),
    (list_of_dicts, [1, "data", "value"], "test-default"),
    (list_and_dict_mix, ["data", 3, "value"], None),
]


@pytest.mark.parametrize("source, keys, expected_result", test_data_collection)
def test_safe_get(source, keys, expected_result):
    """Test safe_get function with various data structures."""
    assert safe_get(source, keys) == expected_result


@pytest.mark.parametrize("source, invalidkeys, expected_result", test_data_collection_with_defaults)
def test_safe_get_with_defaults(source, invalidkeys, expected_result):
    """Test safe_get function with invalid keys and default values."""
    if expected_result is None:
        assert safe_get(source, invalidkeys) == expected_result
    else:
        assert safe_get(source, invalidkeys, default=expected_result) == expected_result


test_data_for_error_check = [
    (nested_list, [3, 2, 1], IndexError),
    (nested_dict, ["data", "d"], KeyError),
    (42, ["data", "id"], TypeError),
]


@pytest.mark.parametrize("source, keys, avoided_exception", test_data_for_error_check)
def test_safe_get_not_raise_error(source, keys, avoided_exception):
    """Test safe_get function not raise error when invalid keys are provided."""
    try:
        result = safe_get(source, keys)
    except avoided_exception as error:
        raise AssertionError(f"Expected no error, but got: {error}") from error
    assert result is None, f"Expected None, but got: {result}"


# Testing "dict_coalesce" function
test_data_dict = {"name": "test-data", "type": "dict", "data": {"1A": "A", "2B": "BB", "3C": "CCC"}}

test_data_nested_dicts = [
    (test_data_dict, ["id", "name"], "test-data"),
    (test_data_dict, ["name", "type"], "test-data"),
    (test_data_dict, ["id", "type"], "dict"),
]

test_data_nested_dicts_with_defaults = [
    (test_data_dict, ["id", "identifier"], None),
    (test_data_dict, ["id", "identifier"], "N/A"),
]


@pytest.mark.parametrize("source, keys, expected_result", test_data_nested_dicts)
def test_dict_coalesce(source, keys, expected_result):
    """Test dict_coalesce function with various data structures."""
    assert dict_coalesce(source, keys) == expected_result


@pytest.mark.parametrize("source, keys, expected_result", test_data_nested_dicts_with_defaults)
def test_dict_coalesce_with_defaults(source, keys, expected_result):
    """Test dict_coalesce function to return default values when none of keys are valid/exists in the dictionary."""
    if expected_result is None:
        assert dict_coalesce(source, keys) == expected_result
    else:
        assert dict_coalesce(source, keys, default=expected_result) == expected_result


# Testing "df_safe_get" function
test_df = pd.DataFrame({
    "id": ["test1", "test2"],
    "value": [100, 200],
})

df_test_data = [
    [test_df, "id", 0, "test1"],
    [test_df, "value", 1, 200],
]

@pytest.mark.parametrize("df, column, row, expected_result", df_test_data)
def test_df_safe_get(df, column, row, expected_result):
    """Test df_safe_get function with DataFrame."""
    result = df_safe_get(df, column, row)
    assert result == expected_result, f"Expected {expected_result}, but got {result}"


test_df2 = pd.DataFrame({
    "id": ["TDF1", "TDF2"],
    "value": [100, 200],
    "name": ["test1", None],
})

df_test_data_with_defaults_and_null = [
    [test_df2, "id", 2, None, None],
    [test_df2, "id", 2, "N/A", "N/A"],
    [test_df2, "missing_col", 0, None, None],
    [test_df2, "missing_col", 0, "N/A", "N/A"],
]

@pytest.mark.parametrize("df, column, row, default, expected_result", df_test_data_with_defaults_and_null)
def test_df_safe_get_with_defaults(df, column, row, default, expected_result):
    """Test df_safe_get function with DataFrame and default values."""
    if default is None:
        assert df_safe_get(df, column, row) == expected_result
    else:
        assert df_safe_get(df, column, row, default=default) == expected_result
