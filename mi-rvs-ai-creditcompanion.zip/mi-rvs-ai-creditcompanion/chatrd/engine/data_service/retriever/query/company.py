import json
import logging
import re
from copy import deepcopy
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd

from chatrd.engine.components.query_analyzer.filter_retrievers.base import FiltersInput
from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.data_service.kpqi import KPQI, KPQIPayload
from chatrd.engine.data_service.kpqi.base import (
    ALL_RD_SECTORS,
    DEFAULT_CREDIT_RATING_ACTION_FAMILY,
    DEFAULT_CREDIT_RATING_FAMILY,
    DEFAULT_CREDIT_WATCH_OUTLOOK_FAMILY,
    DEFAULT_GLOBAL_RATING_FAMILY,
    DEFAULT_TRANSACTION_FUNCTION_FIELDS,
)
from chatrd.engine.data_service.model_output_parser import company_parser
from chatrd.engine.data_service.postprocessing import (
    postprocess_cells_view,
    postprocess_table_for_query,
)
from chatrd.engine.data_service.retriever import BaseRetriever
from chatrd.engine.data_service.retriever.query.utils import (
    build_payload_for_count_query,
    get_full_payload,
    get_payload_path,
    map_metrics_to_field,
    rename_duplicated_columns,
    transform_time_periods,
    update_query_field,
)
from chatrd.engine.data_service.retriever.utils import (
    DEFAULT_POST_PROCESS_RETURN,
    FINANCIAL_METRIC_DICT,
    FINANCIAL_METRICSECTOR_DICT,
    PERSPECTIVE_MAPPING,
    change_to_supported,
    create_dynamic_column_header,
    field_search,
    get_period_description,
    post_process_data,
)
from chatrd.engine.data_service.schema import (
    Analyzer,
    ProcessorInput,
    Retriever,
    ScreenerPayload,
)
from chatrd.engine.data_service.synthesizer.query.data.criteria_arguments import (
    INSURANCE_SECTOR_CODES,
)
from chatrd.engine.screener_api import ScreenerAPI

logger = logging.getLogger(__name__)


config_machinery = get_config_machinery()


with open(get_payload_path(Constants.PayLoad.DATASERVICE_PAYLOAD_PATH)) as fp:
    DATASERVICE_PAYLOAD = json.load(fp)
DEFAULT_PAYLOAD = DATASERVICE_PAYLOAD["DEFAULT_PAYLOAD"]
GLOBAL_CREDIT_RATING_BASE = DATASERVICE_PAYLOAD["GLOBAL_CREDIT_RATING_BASE"]


class CompanyQueryRetriever(BaseRetriever):
    def _insurance_function_update(
        self, functions: List[Dict], queries: List[Dict], key_value_pairs: Dict
    ) -> List[Dict]:
        """
        This function updates the column fields for insurance sector.
        If the user selects the insurance sector, the function will update the
        function fields to include the Local Currency LT rating.
        Args:
            functions (List[Dict]): The list of function fields.
            key_value_pairs (Dict): The dictionary that contains users' input.

        Returns: A list of updated function fields.

        """
        insurance_credit_question = False
        key_values = [KPQI.RD_SECTOR.value, KPQI.IndustryClassification.value]
        credit_rating_global = KPQI.RD_CREDIT_RATING_GLOBAL.value
        rating_action_global = KPQI.RD_RATING_ACTION_GLOBAL.value
        cwol_global = KPQI.RD_CWOL_GLOBAL.value
        codes_to_check = []
        for key_value in key_values:
            if key_value in key_value_pairs:
                if key_value_pairs[key_value].get("display_column") == False:
                    codes_to_check.extend(code.strip() for code in key_value_pairs[key_value]["value"].split(","))

        if all(code in INSURANCE_SECTOR_CODES for code in codes_to_check) and codes_to_check:
            for query in queries:
                if query["field"]["fieldKey"] in [credit_rating_global, rating_action_global, cwol_global]:
                    insurance_credit_question = True
                    for secondary in query["field"]["secondaryKeys"]:
                        if secondary["displayValue"] == "Foreign Currency LT":
                            secondary["key"] = "Local Currency LT"
                            secondary["value"] = "Local Currency LT"
                            secondary["displayValue"] = "Local Currency LT"
                            secondary["mask"] = "Local Currency LT"
                        if secondary["displayValue"] == "Issuer Credit Rating":
                            secondary["key"] = "Financial Strength Rating"
                            secondary["value"] = "Financial Strength Rating"
                            secondary["displayValue"] = "Financial Strength Rating"
                            secondary["mask"] = "Financial Strength Rating"
            if insurance_credit_question:
                for function in functions:
                    if function["secondary"] == "Issuer Credit Rating":
                        function["secondary"] = "Financial Strength Rating"
                        function["tertiary"] = function["tertiary"].replace(
                            "Foreign Currency LT|", "Local Currency LT|"
                        )
                logger.info(
                    f"User Prompt includes only the 'Insurance' sectors: {codes_to_check}. 'query' and 'function' fields changed from ICR to FSR, FCLT to LCLT."
                )
        else:
            logger.info(
                f"User Prompt includes not only 'Insurance' sectors: {codes_to_check}. No update to function and query fields."
            )

        return functions, queries

    def _queries_date_modifier(self, queries: List[Dict]) -> List[Dict]:
        mapping = {
            KPQI.RD_CREDIT_RATING_DATE_GLOBAL.value: KPQI.RD_RATING_ACTION_GLOBAL.value,
            KPQI.RD_CREDIT_WATCH_OUTLOOK_DATE_GLOBAL.value: KPQI.RD_CWOL_GLOBAL.value,
            KPQI.RD_LAST_REVIEW_DATE_GLOBAL.value: KPQI.RD_CREDIT_RATING_GLOBAL.value,
        }
        # Create a lookup for fieldKey to dictionary index
        field_key_to_index = {query["field"]["fieldKey"]: i for i, query in enumerate(queries)}

        # Iterate over the mapping keys
        for key, mapped_key in mapping.items():
            if key in field_key_to_index and mapped_key in field_key_to_index:
                # Get the indices of the dictionaries
                key_index = field_key_to_index[key]
                mapped_key_index = field_key_to_index[mapped_key]

                # Extract the value from the dictionary with `key`
                value_to_update = queries[key_index]["value"]

                # Update the third secondaryKeys entry in the dictionary with `mapped_key`
                if len(queries[mapped_key_index]["field"]["secondaryKeys"]) >= 3:
                    queries[mapped_key_index]["field"]["secondaryKeys"][2].update(
                        {
                            "key": value_to_update,
                            "value": value_to_update,
                            "displayValue": value_to_update,
                            "mask": value_to_update,
                        }
                    )

                # Remove the dictionary with `key`
                queries.pop(key_index)

                # Rebuild the field_key_to_index map after removal
                field_key_to_index = {query["field"]["fieldKey"]: i for i, query in enumerate(queries)}
            logger.info(f"Queries after _queries_date_modifier: {queries}")

        return queries

    def update_connector_value(self, data: List[Dict]) -> List[Dict]:
        # Track occurrences of fieldKey 342649 and 321213
        occurrences = []
        for index, item in enumerate(data):
            field_key = item["field"]["fieldKey"]
            if field_key == KPQI.IndustryClassification.value:
                occurrences.append(index)
            elif field_key == KPQI.RD_SECTOR.value and item["value"] != ALL_RD_SECTORS:
                occurrences.append(index)
        # If both fieldKeys exist, update the connector of the second dictionary
        if len(occurrences) >= 2:
            # Connect two sectors (RD Sector & MI Industry) with 'or' connector
            data[occurrences[1]]["connector"] = 1
            # Create a group for the two sectors (RD Sector & MI Industry)
            data[occurrences[0]]["beginGroup"] = True
            data[occurrences[1]]["endGroup"] = True
        return data

    def _drop_duplicate_functions(self, functions: List[Dict]) -> List[Dict]:
        unique_dicts = []
        seen = set()

        for d in functions:
            # Create a unique identifier for the dictionary
            primary = d["primary"]
            exportPrimary = d["exportPrimary"]
            secondary = d["secondary"]

            # Normalize the tertiary field for comparison, ensuring it's not None
            tertiary = d["tertiary"]
            if tertiary is not None and tertiary.endswith("|0"):
                normalized_tertiary = tertiary[:-2]  # Strip the '|0'
            else:
                normalized_tertiary = tertiary  # Keep as is if None or doesn't end with '|0'

            # Create a tuple of the unique identifier
            dict_tuple = (primary, exportPrimary, secondary, normalized_tertiary)

            if dict_tuple not in seen:
                seen.add(dict_tuple)
                unique_dicts.append(d)

        if len(unique_dicts) < len(functions):
            n_removed = len(functions) - len(unique_dicts)
            logger.info(f"Duplicate functions found and removed ({n_removed})")

        return unique_dicts

    def _payload_build_field_updates(
        self, key_value_pairs: dict, key_perspective: int = 266637
    ) -> Tuple[List[Dict], List[Dict]]:
        """
        Main function to update the two main parts of payload based on users' input.
        The two main parts are function field and query fields.
        Args:
            key_value_pairs (Dict): A dictionary that contains users' input, processed
            outcome from LLMs.
            key_perspective (Int):  The numerical value for each perspective.

        Returns: A tuple of two lists that includes the updated function and query fields.

        """
        queries = []
        functions = []

        key_value_pairs = change_to_supported(key_value_pairs)

        # Order key_value_pairs
        order = [
            KPQI.RD_RATING_ACTION_GLOBAL.value,  # 333832
            KPQI.RD_CREDIT_RATING_GLOBAL.value,  # 334045
            KPQI.RD_CWOL_GLOBAL.value,  # 334235
            KPQI.Geography.value,  # 321214
            KPQI.RD_SECTOR.value,  # 342649
            KPQI.IndustryClassification.value,  # 321213
        ]
        ordered_key_value_pairs = {key: key_value_pairs[key] for key in order if key in key_value_pairs}
        remaining_keys = {key: key_value_pairs[key] for key in key_value_pairs if key not in order}
        ordered_key_value_pairs.update(remaining_keys)

        if all(value.get("value") is None for key, value in ordered_key_value_pairs.items() if isinstance(value, dict)):
            query_field = KPQIPayload(KPQI(KPQI.RD_SECTOR.value)).default_query_field()
            query_field["value"] = ALL_RD_SECTORS
            queries.append(query_field)

        for k, v in ordered_key_value_pairs.items():
            if k not in [
                KPQI.RD_CREDIT_RATING_DATE_GLOBAL.value,
                KPQI.RD_CREDIT_RATING_GLOBAL.value,
                KPQI.RD_RATING_ACTION_GLOBAL.value,
                KPQI.RD_CWOL_GLOBAL.value,
                KPQI.RD_CREDIT_WATCH_OUTLOOK_DATE_GLOBAL.value,
                KPQI.RD_LAST_REVIEW_DATE_GLOBAL.value,
                KPQI.Geography.value,
                KPQI.RD_SECTOR.value,
                KPQI.IndustryClassification.value,
            ]:
                continue
            try:
                if k in DEFAULT_TRANSACTION_FUNCTION_FIELDS:
                    query_field = KPQIPayload(KPQI(k)).default_query_field()
                elif v["data_type"] in {"float", "number"}:
                    functions.append(KPQIPayload(KPQI(k)).default_num_func_field())
                    query_field = KPQIPayload(KPQI(k)).default_num_query_field()
                elif k in KPQI.rating_values():  # Rating under Company screen.
                    # Check if it's global rating or national rating and add the
                    # corresponding default values.
                    if k == KPQI.RD_CREDIT_RATING_GLOBAL.value:
                        temp_function = []
                        for default_k in DEFAULT_CREDIT_RATING_FAMILY:
                            temp_function.append(KPQIPayload(KPQI(default_k)).default_func_field())
                        # Tertiary field update
                        if KPQI.RD_LAST_REVIEW_DATE_GLOBAL.value in ordered_key_value_pairs:
                            credit_rating_date = ordered_key_value_pairs.get(KPQI.RD_LAST_REVIEW_DATE_GLOBAL.value).get(
                                "value"
                            )
                        else:
                            credit_rating_date = None
                        if credit_rating_date:
                            for func in temp_function:
                                parts = func["tertiary"].split("|")
                                func["tertiary"] = f"{parts[0]}|{credit_rating_date}"
                        functions.extend(temp_function)
                    elif k == KPQI.RD_RATING_ACTION_GLOBAL.value:
                        temp_function = []
                        for default_k in DEFAULT_CREDIT_RATING_ACTION_FAMILY:
                            temp_function.append(KPQIPayload(KPQI(default_k)).default_func_field())
                        # Tertiary field update
                        if KPQI.RD_CREDIT_RATING_DATE_GLOBAL.value in ordered_key_value_pairs:
                            credit_action_date = ordered_key_value_pairs.get(
                                KPQI.RD_CREDIT_RATING_DATE_GLOBAL.value
                            ).get("value")
                        else:
                            credit_action_date = None
                        if credit_action_date:
                            temp_function = [
                                item
                                for item in temp_function
                                if item["primary"] != KPQI.RD_RATING_ACTION_DATE_GLOBAL.value
                            ]

                            start_date, end_date = re.findall(r"\[(.*?)\]", credit_action_date)
                            # If end_date is today, set it to "0" ("Current") to match the screener logic.
                            try:
                                if datetime.now().date() == datetime.strptime(end_date, "%m/%d/%Y").date():
                                    end_date = "0"
                            except ValueError as e:
                                logger.warning(f"Malformed end_date '{end_date}' in credit_action_date: {e}")
                            for func in temp_function:
                                if KPQI.RD_RATING_ACTION_GLOBAL.value == func["primary"]:
                                    parts = func["tertiary"].split("|")
                                    func["tertiary"] = f"{parts[0]}|{credit_action_date}"
                                if func["primary"] in [
                                    KPQI.RD_CREDIT_RATING_GLOBAL.value,
                                    KPQI.RD_CWOL_GLOBAL.value,
                                ]:
                                    parts = func["tertiary"].split("|")
                                    func["tertiary"] = f"{parts[0]}|{end_date}"

                        last_two_func = deepcopy(temp_function[-2:])
                        for func in last_two_func:
                            parts = func["tertiary"].split("|")
                            if credit_action_date:
                                func["tertiary"] = f"{parts[0]}|{start_date}"
                            else:
                                func["tertiary"] = f"{parts[0]}|1"
                        temp_function.extend(last_two_func)
                        functions.extend(temp_function)
                    elif k == KPQI.RD_CWOL_GLOBAL.value:
                        temp_function = []
                        for default_k in DEFAULT_CREDIT_WATCH_OUTLOOK_FAMILY:
                            temp_function.append(KPQIPayload(KPQI(default_k)).default_func_field())
                        # Tertiary field update
                        if KPQI.RD_CREDIT_WATCH_OUTLOOK_DATE_GLOBAL.value in ordered_key_value_pairs:
                            cwol_date = ordered_key_value_pairs.get(KPQI.RD_CREDIT_WATCH_OUTLOOK_DATE_GLOBAL.value).get(
                                "value"
                            )
                        else:
                            cwol_date = None
                        if cwol_date:
                            for func in temp_function:
                                parts = func["tertiary"].split("|")
                                func["tertiary"] = f"{parts[0]}|{cwol_date}"
                        functions.extend(temp_function)
                    elif k in KPQI.national_rating_values():
                        pass  # TODO: handle this later.
                    if v.get("display_column", False):
                        continue
                    query_field = KPQIPayload(KPQI(k)).default_query_field()
                else:
                    if k not in [d["primary"] for d in functions]:
                        functions.append(KPQIPayload(KPQI(k)).default_func_field())
                    if v.get("display_column", False):
                        continue
                    query_field = KPQIPayload(KPQI(k)).default_query_field()

                # Add queryline value.
                query_field_updated = update_query_field(v, query_field)
                if k == KPQI.RD_RATING_ACTION_GLOBAL.value:
                    list_of_rating_action = [item.strip() for item in query_field_updated["value"].split(",")]
                    list_count = len(list_of_rating_action)
                    if list_count > 1:
                        for i, rating_action in enumerate(list_of_rating_action):
                            separate_rating_action_field = query_field_updated.copy()
                            separate_rating_action_field["value"] = rating_action
                            if i == 0:
                                separate_rating_action_field["connector"] = 0
                                separate_rating_action_field["beginGroup"] = True
                            else:
                                separate_rating_action_field["connector"] = 1
                                if i == list_count - 1:
                                    separate_rating_action_field["endGroup"] = True
                            queries.append(separate_rating_action_field)
                    else:
                        queries.append(query_field_updated)
                else:
                    queries.append(query_field_updated)
                if k == KPQI.IndustryClassification.value:
                    query_field = KPQIPayload(KPQI(KPQI.RD_SECTOR.value)).default_query_field()
                    query_field["value"] = ALL_RD_SECTORS
                    queries.append(query_field)

            except Exception:
                logging.error(f"The KPQI {k} is not supported")
        functions, queries = self._insurance_function_update(functions, queries, key_value_pairs)
        queries = self._queries_date_modifier(queries)
        queries = self.update_connector_value(queries)
        functions = self._drop_duplicate_functions(functions)
        return functions, queries

    def _payload_build(self, key_value_pairs, key_perspective: int = 266637, max_results: int = 15):
        # Update the default payload with the key perspective
        payload = DEFAULT_PAYLOAD
        payload["functionRequests"][0]["perspective"] = key_perspective
        payload["functionRequests"][0]["requestedPerspective"] = key_perspective
        payload["functionRequests"][0]["query"]["keyPerspective"] = key_perspective

        if "displayFields" in key_value_pairs:
            display_dict = key_value_pairs.pop("displayFields")
        else:
            display_dict = None

        # Update the field and query of the payload
        functions, queries = self._payload_build_field_updates(
            key_value_pairs=key_value_pairs,
            key_perspective=key_perspective,
        )

        keys_to_check = [KPQI.Geography.value, KPQI.RD_SECTOR.value, KPQI.IndustryClassification.value]
        if display_dict and isinstance(display_dict, list):
            insert_index = len(functions)
            for key in keys_to_check:
                for i, item in enumerate(functions):
                    if item["primary"] == key:
                        insert_index = i
                        break
                if insert_index != len(functions):
                    break
            for item in reversed(display_dict):
                functions.insert(insert_index, item)
                insert_index += 1

        payload["functionRequests"][0]["fields"] = functions
        payload["functionRequests"][0]["pagingInfo"]["pageSize"] = max_results
        payload["functionRequests"][0]["query"]["queryLineGroups"][0]["queryLines"] = queries
        logger.info(f"Default screener payload updated with functions and queries: {payload}")

        return payload

    def _post_process(
        self,
        response,
        payload: dict,
        analyzer_response: Dict[str, Any],
        screener_payload_object: ScreenerPayload,
        key_perspective: int = 266637,
        uc_type: str = "query",
    ):
        try:
            response = response.json()
            financial_metrics_list = analyzer_response.get("financialMetricsList", None)
            columns, column_key = create_dynamic_column_header(
                response,
                key_perspective=key_perspective,
                uc_type=uc_type,
                financial_metrics_list=financial_metrics_list,
            )
            df = pd.DataFrame(response["functionResponses"][0]["results"], columns=columns)
            logger.info(f"Dataframe recieved with shape: {df.shape}, and columns: {df.columns.tolist()}")
        except Exception as e:
            logger.error(f"Error happened and here is the " f"message: {e}.")
            return DEFAULT_POST_PROCESS_RETURN

        env = config_machinery.get_config_value(Constants.DataService.DATASERVICE_SCREENER_ENV)

        df = rename_duplicated_columns(
            df
        )  # rename duplicated columns to avoid generate more duplicate in postprocess_table_for_query and post_process_data

        df = postprocess_table_for_query(df)
        df = postprocess_cells_view(key_perspective, env, df)
        financial_columns = [
            values[0] for values in column_key.values() if isinstance(values, list) and len(values) > 0
        ]
        numeric_columns = [
            values[0]
            for values in column_key.values()
            if isinstance(values, list) and len(values) > 0 and values[1] == "numeric"
        ]
        df = post_process_data(screener_payload_object, df, analyzer_response, numeric_columns)
        df.columns = [re.sub(r"_\d+$", "", col) for col in df.columns]  # revert the effect of rename_duplicated_columns
        # Remove duplicate columns except Financial columns

        non_financial_columns = [item for item in df.columns if item not in financial_columns]
        df = df[~df.duplicated(subset=non_financial_columns)]
        logger.info(f"Dataframe post-processed with shape: {df.shape}, and columns: {df.columns.tolist()}")

        count_payload = build_payload_for_count_query(payload=payload)
        full_payload = get_full_payload(payload=payload)

        count_response, url = ScreenerAPI().get_results_from_screener_api(payload=count_payload)

        total_count = count_response.json()["functionResponses"][0]["results"][0][0]
        logger.info(f"Total count recieved from screener: {total_count}")

        return (df, total_count, full_payload, url)

    def retrieve(
        self,
        processor: ProcessorInput = None,
        analyzer: Optional[Analyzer] = None,
        api_method: str = "POST",
        api_type: str = "screener",
    ) -> Retriever:
        # Read Arguments
        if analyzer.error_message is not None:
            logger.error("Bypassing retriever due to error in analyzer")
            return Retriever(
                api_data=pd.DataFrame().to_dict(),
                screener_payload={},
                screener_payload_object=None,
                url=None,
                total_count=0,
                api_method=api_method,
                api_type=api_type,
            )
        entities = processor.entities
        user_input = processor.user_input
        key_perspective = PERSPECTIVE_MAPPING["company"]
        financial_metrics_list = analyzer.response.get("financialMetricsList")
        financial_time_period = analyzer.response.get("financialTime")
        financial_time_period = transform_time_periods(financial_time_period)
        filters_input = FiltersInput(
            llm=processor.llm,
            temperature=processor.temperature,
        )

        # Field Search
        screener_payload_object = field_search(
            response_dict=analyzer.response,
            entities=entities,
            key_perspective=key_perspective,
            key_perspective_str="company",
            user_input=user_input,
            perspective_parser=company_parser.CompanyItemParser(),
            filters_input=filters_input,
        )

        # Payload Build
        if analyzer.response.get("order") and analyzer.response["order"] is not None:
            max_results = config_machinery.get_config_value(Constants.GeneralConstants.MAX_ROWS_LIMIT)
        else:
            max_results = config_machinery.get_config_value(Constants.GeneralConstants.NUM_ROWS_TO_DISPLAY)

        # For financial metrics only
        if financial_metrics_list and len(financial_metrics_list) > 0:
            # Generate the metrics list as a display column
            key_value_metrics = map_metrics_to_field(financial_metrics_list, financial_time_period)
            screener_payload_object.payload_dict.update(key_value_metrics)
            screener_payload_object.text_dict["CreditStats Direct Period"] = [
                get_period_description(time) for time in financial_time_period
            ]

        payload = self._payload_build(
            key_value_pairs=screener_payload_object.payload_dict,
            key_perspective=key_perspective,
            max_results=max_results,
        )

        # Endpoint Call Screener
        if payload["functionRequests"][0]["query"]["queryLineGroups"][0]["queryLines"]:
            response, url = ScreenerAPI().get_results_from_screener_api(payload=payload)
        else:
            df = pd.DataFrame()
            total_count = 0
            scrn_payload = payload
            response = None
            url = None
            logger.info("Empty criteria provided, no API call made.")

        if response and response.json()["functionResponses"][0]["results"]:
            # Post Process
            df, total_count, scrn_payload, url = self._post_process(
                response=response,
                payload=payload,
                analyzer_response=analyzer.response,
                screener_payload_object=screener_payload_object,
                key_perspective=key_perspective,
            )
            logger.info(f"Response received from screener API for List Query: {response}")
            # For financial metrics only
            if financial_metrics_list and len(financial_metrics_list) > 0:
                fields = payload["functionRequests"][0]["fields"]
                invalid_response_kpqi = []
                extracted_metric_names_type = []
                for metric in financial_metrics_list:
                    metric_name = metric.get("MetricName", "")
                    metric_sector = metric.get("MetricSector", "")
                    metric_type = metric.get("MetricType", "")
                    metric_sub_type = metric.get("MetricSubType", "")
                    metric_kpqi = metric.get("MetricKPQI", "")
                    headerItem = next(
                        (
                            item
                            for item in response.json()["functionResponses"][0]["headerInformation"]
                            if item["keyProductQueryItem"] == metric_kpqi
                        ),
                        None,
                    )
                    if metric_kpqi == headerItem["keyProductQueryItem"]:
                        metric_name_type = f"{FINANCIAL_METRICSECTOR_DICT[metric_sector]} -- {FINANCIAL_METRIC_DICT[metric_type]} -- {metric_sub_type} -- {metric_name} -- {metric_kpqi}"
                        extracted_metric_names_type.append(metric_name_type)

                payload["functionRequests"][0]["fields"] = [
                    field for field in fields if field.get("primary") not in invalid_response_kpqi
                ]
                # If there are no valid financial metrics, we will not add the financial metrics to the text_dict
                if extracted_metric_names_type:
                    screener_payload_object.text_dict["CreditStats Direct Sector"] = extracted_metric_names_type
        else:
            df = pd.DataFrame()
            total_count = 0
            scrn_payload = payload
            logger.info("Empty results retrieved from screener API.")

        return Retriever(
            api_data=df.to_dict(),
            screener_payload=scrn_payload,
            screener_payload_object=screener_payload_object,
            url=url,
            total_count=total_count,
            api_method=api_method,
            api_type=api_type,
        )
