import logging

from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.data_service.schema import Synthesizer

logger = logging.getLogger(__name__)
config_machinery = get_config_machinery()
RDKOS_SF = config_machinery.get_config_value(Constants.GeneralConstants.RDKOS_SF)


def merge_synthesizer_outputs(screener_output, ratings_api):

    if ratings_api.source_description == []:
        return screener_output

    merged_data_service_response = screener_output.data_service_response + ratings_api.data_service_response
    merged_source_description = screener_output.source_description + ratings_api.source_description

    merged_output = Synthesizer(
        data_service_response=merged_data_service_response,
        source_description=merged_source_description,
        api_info=ratings_api.api_info,
    )

    return merged_output


def get_total_count(ratings_output, screener_output):
    rating_count = 0
    screener_count = 0

    # Extract count for ratingsAPI
    for response in ratings_output.data_service_response:
        if response["type"] == "table":
            rating_count = response["count"]

    # Extract count for screenerAPI
    for response in screener_output.data_service_response:
        if response["type"] == "table":
            screener_count = response["count"]

    # Calculate total count
    total_count = rating_count + screener_count

    # Create the result dictionary
    result = {"screener": screener_count, "rating": rating_count, "total_count": total_count}

    return result
