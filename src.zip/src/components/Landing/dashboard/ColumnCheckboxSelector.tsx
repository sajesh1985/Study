import React from 'react';
// import {
  // FilterBox,
  // FilterRow,
  // FilterColumn,
  // FormGroup,
  // useFilterBoxContext,
  // SelectOnChange,
// } from '@spglobal/react-components';
import { IOption, Select } from '@spglobal/koi-select';
import {
  defaultSelectFiltersOptions,
  selectFiltersConfig,
} from './ColumnCheckboxSelector.model';

interface ColumnCheckboxSelectorProps {
  handleOptionChange?: (values: IOption[]) => void;
  selectOnChange?:(key: string) => (values: IOption[]) => void;
  getFilter: (arg0: string) => any;
  // applyFilters: (data: any) => Promise<void>;
  // restoreDefaults: () => void;
}

export const ColumnCheckboxSelector: React.FC<ColumnCheckboxSelectorProps> = ({
  selectOnChange,
  getFilter,
  // applyFilters,
  // restoreDefaults,
}) => {

  return (
    <div style={{ width: '201px' }}>
      <Select
        inFieldLabel="View: "
        isConfirmationRequired={true}
        isControlButtons={true}
        customId="searchOptions"
        isMulti={true}
        isSearchable={false}
        options={selectFiltersConfig.filter1.value}
        values={getFilter('filter1')}
        defaultValue={defaultSelectFiltersOptions.filter1}
        label={'Search'}
        placeholder={'Select option'}
        searchPlaceholder={'Search'}
        maxOptionsToSelect={0}
        initialExpandDepth={0}
        // closeOnSelection
        isMobileMenu={false}
        isDropOpenOnClick
        closeOnTriggerClick
        isAutoFocusMenu
        preventScroll
        skeletonConfig={{
          animation: true,
          loading: false,
        }}
        tabIndex={0}
        onChange={selectOnChange('filter1')}
      />
    </div>
  );
};
