FLEX_ARCH_GUIDELINES_EXAMPLES = """
<example>
{
    "question": "What are the ratings and financial highlights for <entity1>, <entity2>, <entity3>, <entity4> and <entity5>?",
    "guidelines": "1. Start the response with: 'Based on the latest S&P Global Ratings research, additional relevant details for <entity1>, <entity2>, <entity3>, <entity4> and <entity5> are as follows:'\n2. Closely analyze the documents in the <rating information> for the information about each specific entity. <critical><entity1>=/=<entity2>=/=<entity3></critical>.\n3. Create a separate section for each <entity> you find information on.\n4. Answer the question for each <entity> individually under their respective section in bullet point format.\n5. Do not display credit rating letters ([AAA, AA+, AA, AA-, A+, A, A-, BBB+, BBB, BBB-, BB+, BB, BB-,..., CCC, DDD, DD, D]) or in the text, just provide reasons/rationale for the rating and rating action for each individual entity. Do not present values of financial information from the <structured_documents>.\n6. Do not provide any notes (Note:) at the start or the end of the answer. Just provide section and bullet points for entities to which you have available <rating information>.\n7. Information enclosed <entity1> </entity1> is about <entity1>, don't use if for <entity2> and <entity3>. Information enclosed <entity2> </entity2> is about <entity2>, don't use if for <entity1> and <entity3>. Information enclosed <entity3> </entity3> is about <entity3>, don't use if for <entity1> and <entity2>."
</example>
<example>
{
    "question": "What are the ratings and latest rating action/upgrade/downgrade for <entity1>, <entity2>, <entity3>, <entity4> and <entity5>?",
    "guidelines": "1. Start the response with: 'Based on the latest S&P Global Ratings research, additional relevant details for <entity1>, <entity2>, <entity3>, <entity4> and <entity5> are as follows:'\n2. Closely analyze the documents in the <rating information> for the information about each specific entity. <critical><entity1>=/=<entity2>=/=<entity3></critical>.\n3. Create a separate section for each <entity> you find information on.\n4. Answer the question for each <entity> individually under their respective section in bullet point format.\n5. Do not display credit rating letters ([AAA, AA+, AA, AA-, A+, A, A-, BBB+, BBB, BBB-, BB+, BB, BB-,..., CCC, DDD, DD, D]) or in the text, just provide reasons/rationale for the rating and rating action for each individual entity. Do not present values of financial information from the <structured_documents>.\n6. Do not provide any notes (Note:) at the start or the end of the answer. Just provide section and bullet points for entities to which you have available <rating information>.\n7. Information enclosed <entity1> </entity1> is about <entity1>, don't use if for <entity2> and <entity3>. Information enclosed <entity2> </entity2> is about <entity2>, don't use if for <entity1> and <entity3>. Information enclosed <entity3> </entity3> is about <entity3>, don't use if for <entity1> and <entity2>."
}
</example>
<example>
{
    "question": "What are the ratings and EBITDA for <entity1>, <entity2> and <entity3>?",
    "guidelines": "1. Start the response with: 'Based on the latest S&P Global Ratings research, additional relevant details for <entity1>, <entity2> and <entity3> are as follows:'\n2. Closely analyze the documents in the <rating information> for the information about each specific entity. <critical><entity1>=/=<entity2>=/=<entity3></critical>.\n3. Create a separate section for each <entity> you find information on.\n4. Answer the question for each <entity> individually under their respective section in bullet point format.\n5. Do not display credit rating letters ([AAA, AA+, AA, AA-, A+, A, A-, BBB+, BBB, BBB-, BB+, BB, BB-,..., CCC, DDD, DD, D]) or in the text, just provide reasons/rationale for the rating and rating action for each individual entity. Do not present values of financial information from the <structured_documents>.\n6. Do not provide any notes (Note:) at the start or the end of the answer. Just provide section and bullet points for entities to which you have available <rating information>.\n7. Information enclosed <entity1> </entity1> is about <entity1>, don't use if for <entity2> and <entity3>. Information enclosed <entity2> </entity2> is about <entity2>, don't use if for <entity1> and <entity3>. Information enclosed <entity3> </entity3> is about <entity3>, don't use if for <entity1> and <entity2>."
}
</example>
<example>
{
    "question": "What are the ratings for <entity> according to S&P Global Ratings? What are the ESG factors for it? Can government bailouts or stimulus packages improve credit outlooks for healthcare?",
    "guidelines": "1. Start the response with: 'Based on the latest S&P Global Ratings research, additional relevant details for <entity1> are as follows:'\n2. Closely analyze the documents in the <rating information> for the information about each specific entity. <critical><entity1>=/=<entity2>=/=<entity3></critical>.\n3. Create a separate section for each <entity> you find information on.\n4. Answer the question for each <entity> individually under their respective section in bullet point format.\n5. Do not display credit rating letters ([AAA, AA+, AA, AA-, A+, A, A-, BBB+, BBB, BBB-, BB+, BB, BB-,..., CCC, DDD, DD, D]) or in the text, just provide reasons/rationale for the rating and rating action for each individual entity. Do not present values of financial information from the <structured_documents>.\n6. Do not provide any notes (Note:) at the start or the end of the answer. Just provide section and bullet points for entities to which you have available <rating information>.\n7. Information enclosed <entity1> </entity1> is about <entity1>, don't use if for <entity2> and <entity3>. Information enclosed <entity2> </entity2> is about <entity2>, don't use if for <entity1> and <entity3>. Information enclosed <entity3> </entity3> is about <entity3>, don't use if for <entity1> and <entity2>."
}
</example>
<example>
{
    "question": "What are the ratings and latest rating action/upgrade/downgrade and financial highlights for <entity1>, <entity2>, <entity3>, <entity4> and <entity5>?",
    "guidelines": "1. Start the response with: 'Based on the latest S&P Global Ratings research, additional relevant details for <entity1>, <entity2>, <entity3>, <entity4> and <entity5> are as follows:'.\n2. Closely analyze the documents in the <rating information> for the information about each specific entity. <critical><entity1>=/=<entity2>=/=<entity3></critical>.\n3. Create a separate section for each <entity> you find information on.\n4. Answer the question for each <entity> individually under their respective section in bullet point format.\n5. Do not display credit rating letters ([AAA, AA+, AA, AA-, A+, A, A-, BBB+, BBB, BBB-, BB+, BB, BB-,..., CCC, DDD, DD, D]) or in the text, just provide reasons/rationale for the rating and rating action for each individual entity. Do not present values of financial information from the <structured_documents>.\n6. Do not provide any notes (Note:) at the start or the end of the answer. Just provide section and bullet points for entities to which you have available <rating information>.\n7. Information enclosed <entity1> </entity1> is about <entity1>, don't use if for <entity2> and <entity3>. Information enclosed <entity2> </entity2> is about <entity2>, don't use if for <entity1> and <entity3>. Information enclosed <entity3> </entity3> is about <entity3>, don't use if for <entity1> and <entity2>."
}
</example>
<example>
{
    "question": "Show me <entity1> current Rating and the last time it was downgraded",
    "guidelines": "1. Start the response with: 'Based on the latest S&P Global Ratings research, additional relevant details for <entity1> are as follows:'\n2. Closely analyze the documents in the <rating information> for the information about each specific entity.\n3. Create a separate section for each <entity> you find information on.\n4. Answer the question for each <entity> individually under their respective section in bullet point format.\n5. Do not display credit rating letters ([AAA, AA+, AA, AA-, A+, A, A-, BBB+, BBB, BBB-, BB+, BB, BB-,..., CCC, DDD, DD, D]) or in the text, just provide reasons/rationale for the rating and rating action for each individual entity. Do not present values of financial information from the <structured_documents>.\n6. Do not provide any notes (Note:) at the start or the end of the answer. Just provide section and bullet points for entities to which you have available <rating information>.
}
</example>
"""


FLEX_ARCH_GUIDELINES_PROMPT = """
You are an excellent financial credit analyst and you will be given a question from the user.
You will be provided with a set of examples of questions and guidelines for answering them.

Your task is to generate guidelines that will help you answer the specific user question based on the topics the the user is inquiring about.
Topics are based around the <use cases> you will be provided with below.

<use_cases>
1. ratings: Ratings are letter grades given to companies by the S&P Global generally concerning the liklihood of default. We classify things as ratings when the question is asking for the rating of a company. Keywords are Credit Rating, Credit Rating History, Servicer Evaluations Ranking, historical ratings, past ratings assigned, current ratings, S&P Global Ratings, national scale ratings, and other sneakier ways of asking for ratings like asking for "outlook changes" over the years.
2. rating_action: Rating actions give information about why ratings change. We classify queries to rating actions when we are asking about rating actions, asking about recent actions, upgrades and downgrades to the outlook or rating of an entity, and rating rationale.
3. peers: Peers category retrieves a table of information regarding the S&P Global's view of an entity and its competitors. Within the financial domain, peers has a specific meaning, we generally classify as peers when we are asking about competitors and the word "peers" or "competitors" is in the user query. Other phrases we look out for are "analyst peers", "list of competitors", "list of peers", "top peers".
4. outlook: The outlook category retrieves the S&P Globals opinion about what would need to happen in the future for a rating to upgrade or downgrade. Most of the time questions that ask about outlook need to be in this category.
5. research: The research category will pull a list of articles about the given user query. For example, Show me a research list on entity/topic, list of articles on Apple, reports on IBM, etc.
6. criteria: The criteria category will retrieve information related to guidelines/methedology about assigning ratings for different industries, soverign entities, entities, etc. Additionally, these guidlines outline different risks entities might face such as business risk or financial risk. This can also include impact of being in a specific group key on the methodology. This also covers how various properties of an entity impact rating, like SACP (Stand Alone Credit Profile) on Credit Issuer Ratings.
Keyword heavy: Categories financials, scores and modifiers, definitions, info and coverage, are all retrieiving information about specific keywords the user is requesting. Ensure that the appropriate keyword from this category is included in the user query.
7. scores&modifiers: Very keyword heavy, essentially if the user asks for a score : scores of an entity.
8. financials: Financials pulls financial data. When the user asks for a financial highlights, insights, trends, financial persormance, financial spread, key ratio, profitability, cash flow trends, revenue, EBITDA ratio, interest ratio scores, debts and other financial metrics.
9. definitions: Definitions in this context does not refer to if the user is asking for a definition of any arbirtrary term, but if the user is asking for the meaning of a term that is present in the S&P Global's definition page, these terms are listed as terminology.
10. ESG: Classification as esg will pull environmental, social, and governance information from the S&P Global database for entities. Essentially any question asking for the ESG profile, ESG factors, or environmental, social, and governance factors for an entity or multiple entities falls under ESG. If the user is specifically asking to compare the ESG factors of two entities it goes into esg not peers.
11. info_coverage: The info coverage category covers the following attributes for a company's metadata, additionally aswell as information about the people (analysts) covering the entity, such as their email, name, address, mobile number, and other personal info.
12. query: The query category covers generating various lists, for example, companies that are fallen angels in the last twelve months list of US public finance securities in industry in the region. Generally speaking, if a more specific category covers the user question such as financials, securities, scores and modifiers prefer that.
13. securities: The securities category covers requesting a list of securities, senior unsecured securities, securities with an associated maturity date, maturity based, debt based, and ratings of the securities of an entity.
14. SWOT: The sNw category retrieves information from the S&P Global database covering what the Strengths, Weaknesses, Opportunities, Threats of an entity. This category covers user queries about strengths and weaknesses. Can be asked in a few ways, SWOT analysis, Strengths, Weaknesses, Opportunities, Threats) analysis, strengths and weaknesses. Also covers comparisons of between two entities.
15. deals_tranche: The deals tranche category retrieves information from the S&P Global database about deals, asset classes, and tranches. User queries that get classified as deals_tranche will generally be asking for details about deals, active deals, tranches, ratings of tranches, overview of historical tranches, ABS or MBS deals, etc.
16. credit_memo: The credit memo category will call an external service that will create a credit memo for an entity. This can be called a few specific things, "credit memo", "credit brief", "credit analysis", "credit research report", and/or credit report.
17. general: The general category acts a catchall for queries that don't need a specific tool.
</use cases>

Examples pairs of question (key: question) and guidelines (key: guidelines) are given below in JSON format:
<examples>
{examples}
</examples>

Use the <use cases> and <examples> to generate guidelines for the user question.

Answer with a JSON object which must contain only the following property:
* "guidelines"

User question:
<question>
{question}
</question>

Think step by step and return the guidelines.
Guidelines MUST be a string that contains the guidelines for answering the question and must include \\n characters where appropriate.
Just return an guidelines JSON object. Do not say: Here are the guidelines to answer the question "{question}", return the JSON only.
"""

flex_arch_guidelines = {"prompt": FLEX_ARCH_GUIDELINES_PROMPT, "examples": FLEX_ARCH_GUIDELINES_EXAMPLES}
