// Copyright Notice!
// This document is protected under the trade secret and copyright
// laws as the property of Fidelity National Information Services, Inc.
// Copying, reproduction or distribution should be limited and only to
// employees with a “need to know” to do their job.
// Any disclosure of this document to third parties is strictly prohibited.
// © 2016 Fidelity National Information Services.
// All rights reserved worldwide.

package com.fis.digitalpayments.app;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.view.KeyEvent;
import android.widget.Toast;

import com.fis.digitalpayments.sdk.SDKManager;
import com.fis.digitalpayments.sdk.messaging.ProductType;
import com.fis.digitalpayments.sdk.messaging.WebEventType;
import com.fis.digitalpayments.sdk.mobile_payments.R;

import com.microsoft.appcenter.AppCenter;
import com.microsoft.appcenter.analytics.Analytics;
import com.microsoft.appcenter.crashes.Crashes;
import com.microsoft.appcenter.distribute.Distribute;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class MainActivity extends AppCompatActivity implements
        WebViewFragment.OnFragmentInteractionListener,
        BalanceFragment.OnFragmentInteractionListener {

    private static final String webViewFragmentTag = "WEBVIEW_FRAGMENT";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        AppCenter.start(getApplication(), "8904d024-759b-4069-b1a7-973578bfc40c",
                Analytics.class, Crashes.class, Distribute.class);

        setContentView(R.layout.activity_main);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        WebViewFragment mWebViewFragment = new WebViewFragment();

        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.add(R.id.fragment_container, mWebViewFragment, webViewFragmentTag);
        transaction.commit();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {

        Fragment fragment = getSupportFragmentManager().findFragmentByTag(webViewFragmentTag);
        if (fragment instanceof WebViewFragment) {
            WebViewFragment webViewFragment = (WebViewFragment)fragment;
            SDKManager sdkManager = webViewFragment.sdkManager;
            sdkManager.checkNavigateBack(keyCode, event);
        }

        return false;
    }

    @Override
    public void onWebViewFragmentInteraction() {
        restart();
    }

    @Override
    public void onBalanceFragmentInteraction(Uri uri) {
        restart();
    }

    public void toastEvent(Context context, String eventId, WebEventType eventType, ProductType eventProduct, HashMap<String, String> params) {
        StringBuilder toastMessage = new StringBuilder();
        eventId = eventId != null ? eventId : "NULL";
        toastMessage.append("Event ID: ").append(eventId);
        toastMessage.append("\nEvent Type: ").append(eventType.toString());
        toastMessage.append("\nEvent Product: ").append(eventProduct.toString());

        if (params != null) {
            Iterator iterator = params.entrySet().iterator();
            while (iterator.hasNext()) {
                Map.Entry pair = (Map.Entry) iterator.next();
                toastMessage.append("\n").append(pair.getKey()).append(": ").append(pair.getValue());
                iterator.remove();
            }
        }

        Toast toast = Toast.makeText(context, toastMessage, Toast.LENGTH_LONG);
        toast.show();
    }

    private void restart() {
        // Restart everything
        Intent intent = getIntent();
        overridePendingTransition(0,0);
        intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        finish();
        overridePendingTransition(0,0);
        startActivity(intent);
    }
}
