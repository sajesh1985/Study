RESEARCH_EXAMPLES = """
<example>
<paragraph><sentence>Key points discussed in this research revolve around xyz's evolving business segments and major factors influencing its credit outlook. </sentence> xyz's electric vehicle (EV) business is still in the early stages, with shipments only beginning in April 2024. The company seems on track to meet its 2024 delivery target of 100,000 units, but more clarity is needed on the sustainability of EV demand. xyz's smartphone business is expected to see faster shipment growth of 12% in 2024, though rising component costs may offset profit gains. The company's governance structure, with the founders maintaining significant control, is a moderately negative consideration in the credit analysis. Xyz's ability to maintain its global smartphone market share and internet services performance will be key to its stable credit outlook, along with its capacity to manage EV investments while maintaining positive free cash flow.</paragraph>
</example>

<example>
<paragraph><sentence>This document outlines xyz's progress in expanding its fiber broadband services amidsts competitive challenges. </sentence> Xyz is increasing its fiber penetration rates in upgraded markets, adding about 96,000 fiber customers in 2023 and reaching 26% overall consumer fiber penetration. The company expects to continue increasing fiber subscribers at a healthy rate in 2024, with a longer-term opportunity to reach the mid-30% penetration area by 2027. However, near-term competition from fixed wireless access (FWA) limits opportunities to convert existing digital subscriber line (DSL) subscribers to fiber. Longer term, xyz believes consumers will opt for fiber broadband service over FWA due to rising data consumption and the advantages of fiber-based technology.</paragraph>
</example>

<example>
<paragraph><sentence>The article reports xyz's latest credit rating announcements and its related financial outlook. </sentence> The company's credit rating and negative outlook are unchanged, as S&P expects xyz's credit measures to remain weak through next year. The proceeds from the proposed notes will be used to enhance liquidity and provide cushion ahead of upcoming debt maturities. Xyz is also in discussions to acquire abc, which could result in weaker financial measures but would still be within S&P's tolerance for the rating.</paragraph>
</example>

<example>
<paragraph><sentence>This article evaluates xyz’s management and governance framework, its stable credit outlook, and the potential for future rating changes. </sentence> S&P Global Ratings has assigned a new positive Management & Governance (M&G) assessment to Mexico-based global branded food company xyz, reflecting the company's experienced management team, disciplined financial policies, and the formation of an advisory board with a good level of independence and diversity. Xyz has a stable outlook, based on the company's solid operating and financial performance, including net debt to EBITDA below 3x and strong liquidity position.</paragraph>
</example>

<example>
<paragraph><sentence>According to this report, xyz shows strong financial performance, stable revenue growth, and resilient risk profile, haviing competitive advantage through a unique fee-based business model and high-quality customer base.</sentence> Xyz has demonstrated excellent financial performance compared to the overall U.S. banking sector, thanks to its unique fee-based business model and resilient risk profile supported by its affluent and high-spending customer base. The company maintains a strong common equity Tier 1 (CET1) ratio, consistently ranks as the most profitable firm under the Federal Reserve's stress tests, and generates consistent revenue growth from its stable noninterest income sources. Xyz's focus on prime customers has also led to better asset quality performance than its peers.</paragraph>
</example>
"""


RESEARCH_PROMPT = """You are an excellent financial credit analyst and you will write a short abstract based on the document, also referred to as article or report.
Carefully read the following document and generate a concise text using only the information given there.
When generating the text, focus on the topic raised by the user, if any.

User's query:
<query>
{query_str}
</query>

The article to generate the abstract from:
<document>
{context_str}
</document>

Below are examples of such abstracts in response to the user query, to give you an idea of the introductory sentence format, as well as the desired length, shape and tone of an abstract body:
<examples>
{examples}
</examples>

<instructions>
Follow these rules when generating the introductory phrase and main content of abstract:
1. INTRODUCTION RULES: 
- Begin the abstract with a single introductory sentence that starts with an opening phrase and then outlines the article content, relevant to the user's query. See <examples>.
- Note that the opening phrases with which the introductory sentences start in the <examples> are diverse ("Key points discussed in this article are", "This document outlines", "The article reports", "This article evaluates", "According to this report,").
- Feel free to come up with any other opening phrase of similar sound, but NEVER say "The/This document provides" as this phrase is too common.
2. MAIN CONTENT RULES: 
- After the introductory sentence, present a concise summary of the key points, findings or discussions presented in the article, relevant to the user's query. 
- AFTER the introductory sentence, do not include any phrases that reference the article and do not mention that this is a summary of a document or article.
3. GENERAL RULES:
- In generated introduction and main content of the abstract, use your own wording instead of copying the one from the <document>.
- Avoid using bullet point lists, numbering, or any special formatting. The abstract should be a coherent paragraph.
- If the user asks about a list of available research/articles/documents, you should simply ignore that part of query and proceed with summarizing sigle article.
- Follow the formatting example strictly.
</instructions>

FORMATTING EXAMPLE:
<paragraph><sentence>[Opening phrase other than "The/This document provides"] [the rest of the introductory sentence]</sentence> [Abstract main content]</paragraph>

Do NOT comment on the generated abstract or article. Generate only the abstract - introduction and main content - based on the instructions above.
Remember to start your answer with <paragraph><sentence> tags.
Don't forget that your answer must be in {original_language} language.
"""

OPENING_PROMPT = """Your job is to generate an opening line, that will preceed a list of articles and their summaries generated by some other source.

To generate this opening, simply rephrase the user's query. You can adjust it to sound more natural if needed.
See the examples below:
- query: "What kind of reports are available for xyz?", opening: "Based on the latest S&P Global Ratings research, here are the available reports:"
- query: "Summarize xyz latest publication", opening: "Based on the latest S&P Global Ratings research, here is the summary of the latest publication about xyz:"
- query: "According to the latest research for Apple, when will the company become carbon-neutral?", opening: "Based on the latest S&P Global Ratings research, here is the summary on Apple's environmental strategy:"

User's query:
<query>
{query_str}
<query>
Do not forget that your answer must be in {original_language} language.
Do NOT comment on the generated line or document. Generate only the opening line and end it with ":".
"""
