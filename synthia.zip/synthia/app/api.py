"""FastAPI implementation for Synthia's API endpoints."""
# Add to your imports
import asyncio
from src.synthia.aws_utils.aws_client import get_aws_client
from fastapi import UploadFile, File, Form
import traceback
from typing import Dict, List, Optional, Any
import logging
from fastapi import FastAPI, HTTPException, Depends, Header, APIRouter
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, TypeAdapter

from src.synthia.aws_utils.aws_client import get_aws_client, get_secret
from src.synthia.config.api_config import get_config
from src.synthia.services.document_service import DocumentService

from src.synthia.config.settings import get_settings
from src.synthia.schemas.sections import Section
from src.synthia.utils.logging_config import configure_logging
from src.synthia.persistence.database_manager import initialize_connection_pool, close_connection_pool
from dotenv import load_dotenv
from contextlib import asynccontextmanager
from src.synthia.persistence.report_monitor import get_monitor
from src.synthia.schemas.workflow import ReportConfig, ReportStatus, ReportStatusEnum
# from src.synthia.queue.queue_consumer import get_queue_consumer
from src.synthia.queue.queue_consumer import ReportQueueConsumer
from src.synthia.queue.queue_publisher import get_publisher
# from src.synthia.queue.report_queue import get_report_queue_service
load_dotenv(override=True)

# Configure logging
configure_logging("synthia.log")

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

logging.getLogger("httpcore.http11").setLevel(logging.WARNING)
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("urllib3").setLevel(logging.WARNING)
logging.getLogger("mcp.client.streamable_http").setLevel(logging.WARNING)
logging.getLogger("httpcore").setLevel(logging.WARNING)

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    logger.info("Initializing connection pool...")
    await initialize_connection_pool()
    logger.info("Connection pool initialized successfully")

    logger.info("Starting queue consumer...")
    consumer = ReportQueueConsumer()
    task = asyncio.create_task(consumer.run_forever())
    logger.info("Queue consumer started successfully")

    yield
    # Shutdown
    logger.info("Closing connection pool...")
    await close_connection_pool()
    logger.info("Connection pool closed successfully")

    logger.info("Shutting queue consumer ...")
    await consumer.stop()
    logger.info("Consumer Shut successfully...")

app = FastAPI(
    title="Synthia API",
    description="API for generating structured reports with LangGraph workflows",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

router = APIRouter()

# Initialize document service
document_service = DocumentService()


class ReportRequest(BaseModel):
    topic: str
    style: Optional[str] = "business"
    depth: Optional[int] = 3
    sections: Optional[int] = 5
    input_section_title: Optional[str] = ""

class ReportResponse(BaseModel):
    job_id: str
    status: str
    message: str


class OutlineApprovalRequest(BaseModel):
    approved: bool
    feedback: Optional[str] = None
    revised_sections: Optional[int] = None
    revised_depth: Optional[int] = None
    user_sections: Optional[List[Dict[str, Any]]] = None


def get_token(authorization: str = Header(None)):
    return authorization

cfg = get_config()

bedrock_kb_id_key = cfg["bedrock_kb_id_key"]
bedrock_kb_datasource_id_key = cfg["bedrock_kb_datasource_id_key"]
propdata_s3_bucket_key = cfg["propdata_s3_bucket_key"]


@router.get("/")
async def root():
    return {"status": "online", "message": "Synthia API is running"}

@router.get("/health")
async def health_check():
    return {"status": "ok"}

@router.post("/upload-document")
async def upload_document(
    file: UploadFile = File(...),
    aws_region: str = Form("us-east-1"),
    username: str = Form(...),
    section_title: str = Form("General"),
):
    """
    Upload a document to S3 and return its S3 URI.
    """
    return await document_service.upload_document(file, aws_region, username, section_title)

@router.delete("/delete-document")
async def delete_document_by_username(
    username: str = Form(...),
    aws_region: str = Form("us-east-1"),
):
    """
    Delete all documents from S3 that have metadata attribute userId equal to the given username.
    """
    return await document_service.delete_documents_by_username(username, aws_region)

@router.post("/synchronize-kb")
async def synchronize_kb():
    """
    Synchronize the knowledge base by uploading documents to S3.
    """
    return await document_service.synchronize_knowledge_base()

@router.post("/reports/{job_id}/approve-outline")
async def approve_outline(
    job_id: str,
    request: OutlineApprovalRequest,
    token: str = Depends(get_token)
):
    status_tracker = get_monitor(token)
    state: ReportStatus = await status_tracker.get_job(job_id)
    if not state:
        raise HTTPException(status_code=404, detail="Job not found")
    
    if state.status != "awaiting_approval":
        raise HTTPException(
            status_code=400,
            detail=f"Job is not awaiting approval. Current status: {state.status}"
        )
    
    # report_queue_service = get_report_queue_service()
    
    if request.approved:
        logger.info(f"Outline for job {job_id} approved. Continuing with report generation.")

        outline_adapter = TypeAdapter(List[Section])
        outline = outline_adapter.validate_python(request.user_sections) if request.user_sections else None

        update_report = ReportStatus(
            job_id=job_id,
            status=ReportStatusEnum.OUTLINE_APPROVED,
            outline=outline,
            progress=0.1,
        )
        await status_tracker.update_job(job_id, update_report)
        
        await get_publisher().publish_outline_approval(
            job_id=job_id,
            approved=True,
            user_sections=request.user_sections,
            token=token
        )
        return {"status": "approved", "message": "Report generation continuing"}
    else:
        logger.info(f"Outline for job {job_id} rejected. Starting over with new parameters.")
        await status_tracker.reject_outline(job_id, request.revised_sections, request.revised_depth)
        
        await get_publisher().publish_outline_approval(
            job_id=job_id,
            approved=False,
            revised_sections=request.revised_sections,
            revised_depth=request.revised_depth,
            token=token
        )
        return {"status": "rejected", "message": "Report generation restarting with new parameters"}

@router.post("/reports", response_model=ReportResponse)
async def create_report(
    request: ReportRequest, token: str = Depends(get_token)
):
    settings = get_settings()
    try:
        import uuid
        job_id = str(uuid.uuid4())
        
        status_tracker = get_monitor(token)
        # report_queue_service = get_report_queue_service()

        # Create report configuration
        report_config = ReportConfig(
            topic=request.topic,
            style=request.style,
            depth=request.depth,
            num_sections=request.sections,
            input_section_title=request.input_section_title
        )

        await status_tracker.create_job(
            job_id=job_id,
            report_config=report_config,
        )
        
        # Queue the report generation instead of using background tasks
        await get_publisher().publish_generate_report(
            job_id=job_id,
            token=token
        )
        
        return {
            "job_id": job_id,
            "status": "accepted",
            "message": "Report generation started"
        }
    except Exception as e:
        logger.error(f"Failed to start report generation: {str(e)}")
        logger.error(traceback.format_exc())
        raise HTTPException(
            status_code=500, detail=f"Failed to start report generation: {str(e)}")
        
@router.get("/reports/jobs")
async def fetchJobs(
    token: str = Depends(get_token)
):
    """
    Query a PostgreSQL table and return results.
    """
    try:
        
        monitor = get_monitor(token)  # Pass None for token since this is a general query
        jobs = await monitor.list_job_ids()
        
        return jobs
            
    except Exception as e:
        logger.error(f"Database query failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Database query failed: {str(e)}")


@router.get("/reports/{job_id}")
async def get_report_status(job_id: str, token: str = Depends(get_token)):
    status_tracker = get_monitor(token)
    if not await status_tracker.job_exists(job_id):
        raise HTTPException(status_code=404, detail="Job not found")
    state = await status_tracker.get_job(job_id)
    if not state:
        raise HTTPException(status_code=404, detail="Report not found")
    return state
    # return {
    #     "job_id": job_id,
    #     "status": state.status,
    #     "progress": state.progress or 0,
    #     "sections": state.sections,
    #     "outline": state.outline,
    #     "current_section_idx": getattr(state, 'current_section_idx', 0),
    #     "completed_at": state.completed_at,
    #     "awaiting_approval": state.status == 'awaiting_approval',
    #     "final_report": state.sections,
    #     "awaiting_final_approval": state.status == 'awaiting_final_approval',
    #     "error": state.error,
    #     "started_at": state.started_at,
    # }

@router.get("/reports", response_model=List[str])
async def list_active_jobs(token: str = Depends(get_token)):
    status_tracker = get_monitor(token)
    return await status_tracker.list_job_ids()

app.include_router(router)
app.include_router(router, prefix="/synthia-agent")
async def list_active_jobs(token: str = Depends(get_token)):
    status_tracker = get_monitor(token)
    return await status_tracker.list_job_ids()

app.include_router(router)
app.include_router(router, prefix="/synthia-agent")


