"""
Analyzer Pydantic models for extraction result validation.

This module provides type-safe validation for prompt extraction outputs
with a common base model and specific implementations for different extraction types.
"""

import json
import logging
import re
from typing import Any, Dict, Optional, Union

from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator

logger = logging.getLogger(__name__)


class ExtractionResultBase(BaseModel):
    """
    Base Pydantic model for all extraction results.

    Provides common fields and validation for credit rating and creditwatch outlook extractions.
    All extraction models should inherit from this base class.
    """

    value: Optional[str] = Field(None, description="Extracted value(s) as comma-separated string or None")
    time_frame: Optional[str] = Field(None, description="Time frame in MM/DD/YYYY-MM/DD/YYYY format or None")
    display_column: bool = Field(False, description="Whether to display/include the column in results")

    @field_validator("time_frame")
    @classmethod
    def validate_time_frame_format(cls, v):
        """Validate time frame format: MM/DD/YYYY-MM/DD/YYYY"""
        if v is None:
            return v

        # Remove any square brackets (legacy format support)
        cleaned_v = v.strip().replace("[", "").replace("]", "")

        # Pattern for MM/DD/YYYY-MM/DD/YYYY format
        time_frame_pattern = r"^\d{2}/\d{2}/\d{4}-\d{2}/\d{2}/\d{4}$"

        if not re.match(time_frame_pattern, cleaned_v):
            raise ValueError(f"Time frame must be in MM/DD/YYYY-MM/DD/YYYY format, got: {v}")

        return cleaned_v

    @field_validator("display_column")
    @classmethod
    def validate_display_column(cls, v):
        """Ensure display_column is a boolean"""
        if not isinstance(v, bool):
            raise ValueError("display_column must be a boolean value")
        return v

    def to_dict(self) -> Dict[str, Any]:
        """Convert model to dictionary."""
        return self.model_dump()

    def to_json(self) -> str:
        """Convert model to JSON string."""
        return self.model_dump_json()

    @classmethod
    def from_dict(cls, data: Dict[str, Any]):
        """Create model instance from dictionary."""
        return cls(**data)

    @classmethod
    def from_json(cls, json_str: str):
        """Create model instance from JSON string."""
        return cls.model_validate_json(json_str)

    model_config = ConfigDict(
        json_encoders={
            # Custom encoders if needed
        },
        json_schema_extra={
            "example": {"value": "example_value", "time_frame": "01/01/2024-12/31/2024", "display_column": False}
        },
    )


class CreditRatingExtractionResult(ExtractionResultBase):
    """
    Pydantic model for credit rating extraction results.

    Validates S&P credit rating extraction outputs with specific validation
    for credit rating formats and values.
    """

    value: Optional[str] = Field(
        None,
        description="S&P credit rating(s) as quoted comma-separated string (e.g., \"'AAA','AA+','AA'\") or traditional format (e.g., 'AA+, BBB-') or None",
    )

    @field_validator("value")
    @classmethod
    def validate_credit_rating(cls, v):
        """Validate S&P credit rating format"""
        if v is None:
            return v

        # Handle new quoted format for multiple ratings (e.g., "'AAA','AA+','AA'")
        # or traditional format (e.g., "AAA, AA+, AA")
        # S&P rating pattern: AAA, AA+, AA, AA-, A+, A, A-, BBB+, BBB, BBB-, BB+, BB, BB-, B+, B, B-, CCC+, CCC, CCC-, CC, C, D, SD, NR

        # Pattern for individual ratings
        individual_rating = r"(AAA|AA[+-]?|A[+-]?|BBB[+-]?|BB[+-]?|B[+-]?|CCC[+-]?|CC|C|D|SD|NR)"

        # Pattern for quoted format: "'AAA','AA+','AA'"
        quoted_pattern = f"^'{individual_rating}'(,'{individual_rating}')*$"

        # Pattern for traditional format with optional operators: ">=BBB-, AA+"
        traditional_pattern = f"^(>=|<=|>|<|=)?\\s*{individual_rating}(,\\s*(>=|<=|>|<|=)?\\s*{individual_rating})*$"

        cleaned_v = v.strip()

        if not (re.match(quoted_pattern, cleaned_v) or re.match(traditional_pattern, cleaned_v)):
            logger.warning(f"Credit rating format validation failed for: {v}")
            # Don't raise error, just log warning to allow flexibility

        return cleaned_v

    model_config = ConfigDict(
        json_encoders={
            # Custom encoders if needed
        },
        json_schema_extra={
            "examples": [
                {
                    "description": "Single credit rating with time frame",
                    "value": {"value": "BBB+", "time_frame": "01/01/2024-12/31/2024", "display_column": False},
                },
                {
                    "description": "Multiple credit ratings (new quoted format)",
                    "value": {"value": "'AAA','AA+','AA'", "time_frame": None, "display_column": False},
                },
                {
                    "description": "Multiple credit ratings (traditional format)",
                    "value": {"value": "AA-, BBB+", "time_frame": None, "display_column": False},
                },
                {
                    "description": "Credit rating with operator",
                    "value": {"value": ">=BBB-", "time_frame": "06/01/2024-12/31/2024", "display_column": False},
                },
                {
                    "description": "Defaulted companies",
                    "value": {"value": "'D','SD'", "time_frame": None, "display_column": False},
                },
                {
                    "description": "Display column scenario",
                    "value": {"value": None, "time_frame": None, "display_column": True},
                },
            ]
        },
    )


class CreditWatchOutlookExtractionResult(ExtractionResultBase):
    """
    Pydantic model for creditwatch outlook extraction results.

    Validates S&P CreditWatch and Outlook action extraction outputs with specific
    validation for outlook/watch action formats.
    """

    value: Optional[str] = Field(
        None,
        description="CreditWatch/Outlook actions as quoted comma-separated string (e.g., \"'watch pos','positive','NM'\") or traditional format (e.g., 'watch pos, developing') or None",
    )

    @field_validator("value")
    @classmethod
    def validate_creditwatch_outlook(cls, v):
        """Validate CreditWatch/Outlook action format"""
        if v is None:
            return v

        # Valid CreditWatch/Outlook values
        valid_actions = {
            # CreditWatch actions
            "watch pos",
            "watch neg",
            "watch dev",
            # Outlook actions
            "positive",
            "negative",
            "stable",
            "developing",
            # Special statuses
            "NM",
            "NR",
        }

        cleaned_v = v.strip()

        # Handle new quoted format for multiple values (e.g., "'watch pos','positive','NM'")
        # or traditional format (e.g., "watch pos, positive, NM")

        # Pattern for individual actions
        individual_action = r"(watch pos|watch neg|watch dev|positive|negative|stable|developing|NM|NR)"

        # Pattern for quoted format: "'watch pos','positive','NM'"
        quoted_pattern = f"^'{individual_action}'(,'{individual_action}')*$"

        # Pattern for traditional format: "watch pos, positive, NM"
        traditional_pattern = f"^{individual_action}(,\\s*{individual_action})*$"

        # Check if it matches either format
        if re.match(quoted_pattern, cleaned_v):
            # Parse quoted format
            actions = [action.strip("'") for action in cleaned_v.split("','")]
            actions[0] = actions[0].lstrip("'")  # Remove leading quote from first item
            actions[-1] = actions[-1].rstrip("'")  # Remove trailing quote from last item
        elif re.match(traditional_pattern, cleaned_v):
            # Parse traditional format
            actions = [action.strip().lower() for action in cleaned_v.split(",")]
        else:
            # Single value
            actions = [cleaned_v.lower()]

        # Validate each action
        for action in actions:
            if action not in [va.lower() for va in valid_actions]:
                logger.warning(f"Unknown creditwatch/outlook action: {action}")
                # Don't raise error, just log warning to allow flexibility

        return cleaned_v

    model_config = ConfigDict(
        json_encoders={
            # Custom encoders if needed
        },
        json_schema_extra={
            "examples": [
                {
                    "description": "Single CreditWatch action",
                    "value": {"value": "watch pos", "time_frame": "01/01/2024-12/31/2024", "display_column": False},
                },
                {
                    "description": "Multiple outlook actions (new quoted format)",
                    "value": {"value": "'positive','developing'", "time_frame": None, "display_column": False},
                },
                {
                    "description": "Multiple outlook actions (traditional format)",
                    "value": {"value": "'positive','developing'", "time_frame": None, "display_column": False},
                },
                {
                    "description": "Mixed CreditWatch and Outlook actions",
                    "value": {
                        "value": "'watch pos','watch neg','positive','stable'",
                        "time_frame": "06/01/2024-12/31/2024",
                        "display_column": False,
                    },
                },
                {
                    "description": "Special status explicitly mentioned",
                    "value": {"value": "'NM','NR'", "time_frame": None, "display_column": False},
                },
                {
                    "description": "Display column scenario",
                    "value": {"value": None, "time_frame": None, "display_column": True},
                },
            ]
        },
    )


class CreditActionExtractionResult(BaseModel):
    """
    Pydantic model for credit action extraction results.

    Validates S&P credit rating action extraction outputs with specific validation
    for credit action formats and values.
    """

    value: Optional[str] = Field(
        None,
        description='Credit rating action(s) as comma-separated string (e.g., "upgrade, downgrade") or single action (e.g., "upgrade") or None',
    )

    # Define time_frame field with bracket format validation
    time_frame: Optional[str] = Field(None, description="Time frame in [MM/DD/YYYY]-[MM/DD/YYYY] format or None")
    display_column: bool = Field(False, description="Whether to display/include the column in results")

    @field_validator("time_frame", mode="before")
    @classmethod
    def validate_time_frame_format_with_brackets(cls, v):
        """Validate and ensure time frame format: [MM/DD/YYYY]-[MM/DD/YYYY] for credit actions"""
        if v is None:
            return v

        cleaned_v = v.strip()

        # Pattern for [MM/DD/YYYY]-[MM/DD/YYYY] format with brackets
        bracket_pattern = r"^\[\d{2}/\d{2}/\d{4}\]-\[\d{2}/\d{2}/\d{4}\]$"

        # Pattern for MM/DD/YYYY-MM/DD/YYYY format without brackets
        no_bracket_pattern = r"^\d{2}/\d{2}/\d{4}-\d{2}/\d{2}/\d{4}$"

        if re.match(bracket_pattern, cleaned_v):
            # Already has brackets, return as is
            return cleaned_v
        elif re.match(no_bracket_pattern, cleaned_v):
            # Add brackets to format
            start_date, end_date = cleaned_v.split("-")
            return f"[{start_date}]-[{end_date}]"
        else:
            raise ValueError(f"Time frame must be in MM/DD/YYYY-MM/DD/YYYY format, got: {v}")

    def to_dict(self) -> Dict[str, Any]:
        """Convert model to dictionary."""
        return self.model_dump()

    def to_json(self) -> str:
        """Convert model to JSON string."""
        return self.model_dump_json()

    @classmethod
    def from_dict(cls, data: Dict[str, Any]):
        """Create model instance from dictionary."""
        return cls(**data)

    @classmethod
    def from_json(cls, json_str: str):
        """Create model instance from JSON string."""
        return cls.model_validate_json(json_str)

    @field_validator("value")
    @classmethod
    def validate_credit_action(cls, v):
        """Validate credit rating action format"""
        if v is None:
            return v

        # Valid credit actions
        valid_actions = {"upgrade", "downgrade", "new rating"}

        cleaned_v = v.strip()

        # Handle comma-separated actions
        if "," in cleaned_v:
            actions = [action.strip().lower() for action in cleaned_v.split(",")]
        else:
            actions = [cleaned_v.lower()]

        # Validate each action
        for action in actions:
            if action not in [va.lower() for va in valid_actions]:
                logger.warning(f"Unknown credit action: {action}")
                # Don't raise error, just log warning to allow flexibility

        return cleaned_v

    model_config = ConfigDict(
        json_encoders={
            # Custom encoders if needed
        },
        json_schema_extra={
            "examples": [
                {
                    "description": "Single credit action with time frame",
                    "value": {"value": "upgrade", "time_frame": "[01/01/2024]-[12/31/2024]"},
                },
                {
                    "description": "Multiple credit actions",
                    "value": {"value": "upgrade, downgrade", "time_frame": None},
                },
                {
                    "description": "General rating actions",
                    "value": {"value": "rating actions", "time_frame": None},
                },
                {
                    "description": "New rating action",
                    "value": {
                        "value": "new rating",
                        "time_frame": "[01/01/2024]-[12/31/2024]",
                    },
                },
                {
                    "description": "Display column scenario",
                    "value": {"value": None, "time_frame": None},
                },
            ]
        },
    )


class StringExtractionResult(BaseModel):
    """
    Pydantic class for extracted string results.

    Validates string outputs with specific validation.
    """

    value: Optional[str] = Field(
        None,
        description="""The extracted name(s) must be a string or None.
        If there are multiple names, they should be provided as a comma-separated string (e.g., 'name1, name2').
        If there is only one name, it should be provided as a single string (e.g., 'name1').
        """,
    )

    @field_validator("value")
    @classmethod
    def validate_industry(cls, v):
        """Validate industry format"""
        if v is None:
            return v

        # Allow any non-empty string for industry names
        cleaned_v = v.strip()

        if not cleaned_v:
            raise ValueError("Industry value cannot be an empty string")

        # Split by commas, lower each value, and join with a space after the comma
        formatted_industries = ", ".join([industry.strip().lower() for industry in cleaned_v.split(",")])

        if formatted_industries in ["ai:", "none"]:
            formatted_industries = ""

        return formatted_industries


# Convenience type alias for any extraction result
ExtractionResult = Union[
    StringExtractionResult,
    CreditRatingExtractionResult,
    CreditWatchOutlookExtractionResult,
    CreditActionExtractionResult,
]


def validate_extraction_output(response: str, extraction_type: str) -> Union[
    StringExtractionResult,
    CreditRatingExtractionResult,
    CreditWatchOutlookExtractionResult,
    CreditActionExtractionResult,
]:
    """
    Validate and parse extraction output using appropriate Pydantic model.

    Args:
        response: Raw LLM response string
        extraction_type: Type of extraction ("credit_rating", "creditwatch_outlook", "credit_action")

    Returns:
        Validated extraction result model instance

    Raises:
        ValidationError: If response doesn't match expected format
        ValueError: If extraction_type is invalid
    """

    if extraction_type not in ["industry", "credit_rating", "creditwatch_outlook", "credit_action", "geography"]:
        raise ValueError(f"Invalid extraction_type: {extraction_type}")

    try:
        # Parse JSON response
        if isinstance(response, str) and extraction_type in ["credit_rating", "creditwatch_outlook", "credit_action"]:
            # Handle both JSON string and Python dict string formats
            try:
                data = json.loads(response)
            except json.JSONDecodeError:
                # Try to evaluate as Python dict if JSON parsing fails
                data = eval(response)
        else:
            data = response

        # Validate using appropriate model
        if extraction_type in ["industry", "geography"]:
            return StringExtractionResult(value=data)
        elif extraction_type == "credit_rating":
            return CreditRatingExtractionResult(**data)
        elif extraction_type == "credit_action":
            return CreditActionExtractionResult(**data)
        else:
            return CreditWatchOutlookExtractionResult(**data)

    except (json.JSONDecodeError, SyntaxError, TypeError) as e:
        raise ValidationError(f"Invalid response format: {e}", model=ExtractionResultBase)
    except ValidationError as e:
        logger.error(f"Validation failed for {extraction_type}: {e}")
        raise


def convert_to_output_format(validated_result: ExtractionResult, extraction_type: str) -> Dict[str, Any]:
    """
    Convert validated Pydantic model to legacy dictionary format.

    This function provides backward compatibility for existing code that expects
    the old dictionary format.

    Args:
        validated_result: Validated extraction result model

    Returns:
        Dictionary in legacy format
    """

    if extraction_type in ["credit_rating", "creditwatch_outlook", "credit_action"]:
        return {
            "value": validated_result.value,
            "time_frame": validated_result.time_frame,
            "display_column": validated_result.display_column,
        }
    elif extraction_type in ["industry", "geography"]:
        return {"value": validated_result.value}
    else:
        raise ValueError(f"Invalid extraction_type: {extraction_type}")


def validate_and_convert_response(response: str, extraction_type: str) -> Dict[str, Any]:
    """
    Validate response using Pydantic and convert to legacy dictionary format.

    This is a convenience function for drop-in replacement of existing parsing logic.

    Args:
        response: Raw LLM response string
        extraction_type: Type of extraction ("credit_rating", "creditwatch_outlook", "credit_action")

    Returns:
        Dictionary in legacy format with validated data
    """
    try:
        validated_result = validate_extraction_output(response, extraction_type)
        return convert_to_output_format(validated_result, extraction_type)

    except ValidationError as e:
        logger.error(f"Validation failed, returning minimal structure: {e}")
        return {"value": None, "time_frame": None, "display_column": False}


# Export all models and functions
__all__ = [
    "ExtractionResultBase",
    "StringExtractionResult",
    "CreditRatingExtractionResult",
    "CreditWatchOutlookExtractionResult",
    "CreditActionExtractionResult",
    "ExtractionResult",
    "validate_extraction_output",
    "convert_to_output_format",
    "validate_and_convert_response",
]
