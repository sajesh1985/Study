import contextlib
import logging
from contextlib import asynccontextmanager
from datetime import datetime, timedelta

import httpx
from fastapi import FastAPI, APIRouter
from fastapi import Request
from mcp.server.fastmcp import FastMCP, Context

from src.synthia.config.api_config import get_config
from src.synthia.tools.mcp_responses import KeyDevelopmentItem, MCPResponse
from src.synthia.utils.logging_config import configure_logging
from . import auth
from .mcp_utils import get_mcp_tool_source

# Configure logging
logger = configure_logging(logger_name=__name__, log_file='company_keydevelops.log')

mcp: FastMCP = FastMCP("Company Key Developments MCP", stateless_http=True)

logger.info("Key Developments MCP Server starting up...")

router = APIRouter()

key_development_body = {
    "entityList": None,
    "startDate": "",
    "endDate": ""
}

# Create a single AsyncClient instance for reuse (performance optimization for Lambda)
async_client: httpx.AsyncClient = None


@mcp.tool()
async def get_company_keydevelopments(keyInstn: str, startDate: str = "", endDate: str = "") -> MCPResponse:
    """
    Get Fetch Instn Key Developments for a given Inst ID/KeyInstn/MI Key (keyInstn) and date range.
    Args:
        keyInstn (str):
            The Inst ID to get key developments for, also called as Instn ID, MI Key, KeyInstn.
        startDate (str, optional):
            Start date in 'MM/DD/YYYY' format. Defaults to 6 months ago.
        endDate (str, optional):
            End date in 'MM/DD/YYYY' format. Defaults to today.


    Returns:
        MCPResponse: Data containing key developments for the given company and date range.

        The response will have the following attributes for the company:
            MCPResponse:
                sources (Source): Source for the key developments.
                data (list[KeyDevelopmentItem]): A list of key development items.
                isError (bool): Flag indicating if the response is an error.
                message (str): Optional message providing additional information about the response or error.

            source (Source): Information about the data source, including title and link.
                title (str): The title of the data source
                url (str): The URL of the data source

            KeyDevelopmentItem:
           - KeyDevelopment: The identifier for the key development.
           - KeyDevelopmentTypeName: Key Development Type Name.
           - KeyDevelopmentHeadline: Headline of the key development.
           - CIQDevelopmentDateBestUTC:  The date on which the key development was best recorded in UTC format.
           - DevelopmentAbstract: A brief summary of the key development.

    Example Response:
            [
                {
                    "KeyDevelopment": -2125656276,
                    "KeyDevelopmentTypeName": "Credit Rating: S&P: New Rating",
                    "KeyDevelopmentHeadline": "Issuer Credit Rating: raA; Positive from New: Argentina National Scale LT",
                    "CIQDevelopmentDateBestUTC": "2024-05-14T09:56:00",
                    "DevelopmentAbstract": "S&P Global Ratings assigned its 'raA' Argentina national scale long-term issuer credit rating to International Business Machines Corporation (IBM). The outlook is positive. The rating reflects our view of IBM's strong business position, solid financial profile, and the positive outlook on the company."
                }
            ]  
    """
    logger.info(f"Latest for key devlopments for keyInstn: {keyInstn}")

    # Get configuration
    cfg = get_config()
    capitaliq_base_url = cfg["capitaliq_base_url"]
    key_developments_url_infix = "AIReportBuilder/keyDevelopments"
    capitaliq_base_inherit_auth_url = cfg["capitaliq_base_inherit_auth_url"]

    # Set default startDate to 6 months ago if not provided
    if startDate == "" or startDate is None:
        default_start = datetime.now() - timedelta(days=90)
        startDate = default_start.strftime('%m/%d/%Y')

    # Set default endDate to today if not provided
    if endDate == "" or endDate is None:
        endDate = datetime.now().strftime('%m/%d/%Y')

    key_development_body["entityList"] = keyInstn
    if startDate:
        key_development_body["startDate"] = startDate
    if endDate:
        key_development_body["endDate"] = endDate

    logger.info(f"get_company_keydevelopments called for : {keyInstn}")
    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    url = f"{capitaliq_base_url}{key_developments_url_infix}"
    headers = {
        "Content-Type": "application/json",
        **auth.build_auth_headers(raw_request)
    }

    global async_client
    try:
        response = await async_client.post(url,
                                           headers=headers, json=key_development_body)
        if response.status_code == 200:
            key_development_data = response.json()

            logger.info(f"key Development Data : {len(key_development_data)} records")
            processed_data = []
            for item in key_development_data:
                processed_item = KeyDevelopmentItem(
                    KeyDevelopmentTypeName=item.get("KeyDevelopmentTypeName"),
                    KeyDevelopmentHeadline=item.get("KeyDevelopmentHeadline"),
                    CIQDevelopmentDateBestUTC=item.get("CIQDevelopmentDateBestUTC"),
                    DevelopmentAbstract=item.get("DevelopmentAbstract"),
                )
                processed_data.append(processed_item)
            source = await get_mcp_tool_source(
                mcp_tool_name=get_company_keydevelopments.__name__,
                source_url=f"{capitaliq_base_inherit_auth_url}#company/keyDevelopments?ID={keyInstn}",
                institution_id=str(keyInstn),
                headers=auth.build_auth_headers(raw_request),
                default_title="Key Developments",
            )
            logger.info(f"key Development Processed Data: {len(processed_data)} records")
            return MCPResponse(
                sources=source,
                data=processed_data,
                isError=False,
                message=None
            )
        elif response.status_code == 204:
            logger.info(f"No key developments found for the given company: {keyInstn}")
            return MCPResponse(
                sources=None,
                data=None,
                isError=False,
                message=None
            )
        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return MCPResponse(
                sources=None,
                data=None,
                isError=True,
                message=f"Error: {response.status_code} - {response.text}"
            )
    except httpx.RequestError as e:
        logger.error(f"Request failed: {e}")
        return MCPResponse(
            sources=None,
            data=None,
            isError=True,
            message=f"Request failed: {e}"
        )


# Define a custom lifespan for FastAPI with a task to manage MCP

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Initialize MCP server task group
    logger.info("Initializing MCP server task group...")
    global async_client
    async_client = httpx.AsyncClient(timeout=10)
    async with contextlib.AsyncExitStack() as stack:
        await stack.enter_async_context(mcp.session_manager.run())
        yield
    await async_client.aclose()


@router.get("/company-keydevs/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "ok"}


# Create FastAPI app with lifespan
app = FastAPI(lifespan=lifespan)
app.mount("/company-keydevs", mcp.streamable_http_app())
app.include_router(router)
logger.info("Key Developments MCP Server started successfully.")
