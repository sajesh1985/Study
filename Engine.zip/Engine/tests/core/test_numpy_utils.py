import numpy as np
import pytest

from chatrd.core.embedding.numpy_utils import np_normalize, np_topk

TEST_DTYPE = np.float16


class TestNpNormalize(object):
    def test_normalize_l2_axis_0(self):
        input_array = np.array([[1, 2], [3, 4]], dtype=TEST_DTYPE)
        expected_l2_0 = np.array([[0.3162, 0.4473], [0.9487, 0.8945]], dtype=TEST_DTYPE)

        result = np_normalize(input_array, axis=0)
        np.testing.assert_array_almost_equal(result, expected_l2_0, decimal=4)

    def test_normalize_l2_axis_1(self):
        input_array = np.array([[1, 2], [3, 4]], dtype=TEST_DTYPE)
        expected_l2_1 = np.array([[0.4472, 0.8944], [0.6, 0.8]], dtype=TEST_DTYPE)

        result = np_normalize(input_array, axis=1)
        np.testing.assert_array_almost_equal(result, expected_l2_1, decimal=4)

    def test_normalize_with_zero_values(self):
        input_array = np.array([[0, 0], [3, 4]], dtype=TEST_DTYPE)
        expected_zeros = np.array([[None, None], [0.6, 0.8]], dtype=TEST_DTYPE)

        result = np_normalize(input_array, axis=1)
        np.testing.assert_almost_equal(result, expected_zeros, decimal=4)

    def test_normalize_based_on_zero_values(self):
        input_array = np.array([[0, 0], [3, 4]], dtype=TEST_DTYPE)
        expected_zeros = np.array([[0.0, 0.0], [1.0, 1.0]], dtype=TEST_DTYPE)

        result = np_normalize(input_array, axis=0)
        np.testing.assert_almost_equal(result, expected_zeros, decimal=4)

    def test_normalize_with_different_p(self):
        input_array = np.array([[1, 2], [3, 4]], dtype=TEST_DTYPE)
        expected_p_diff = np.array([[0.3333, 0.6666], [0.4285, 0.5714]], dtype=TEST_DTYPE)

        result = np_normalize(input_array, p=1, axis=1)
        np.testing.assert_almost_equal(result, expected_p_diff, decimal=4)

    def test_empty_array(self):
        input_array = np.array([])
        expected_empty = np.array([])

        result = np_normalize(input_array, axis=0)
        np.testing.assert_array_equal(result, expected_empty)

    def test_all_zeros_array(self):
        input_array = np.array([[0, 0], [0, 0]], dtype=TEST_DTYPE)
        expected_all_nan = np.full_like(input_array, np.nan, dtype=TEST_DTYPE)

        result = np_normalize(input_array, axis=1)
        np.testing.assert_array_equal(result, expected_all_nan)

    def test_output_shape(self):
        input_array = np.random.rand(3, 4)
        result = np_normalize(input_array, axis=1)
        assert result.shape == input_array.shape

    @pytest.mark.parametrize("int_dtype", [np.int8, np.int16, np.int32, np.int64])
    def test_int_dtypes(self, int_dtype):
        input_array = np.array([[1, 2], [3, 4]], dtype=int_dtype)
        result = np_normalize(input_array, axis=1)
        assert result.dtype == np.float64  # Normalization results in float type

    @pytest.mark.parametrize("float_dtype", [np.float16, np.float32, np.float64])
    def test_float_dtypes(self, float_dtype):
        input_array = np.array([[1, 2], [3, 4]], dtype=float_dtype)
        result = np_normalize(input_array, axis=1)
        assert result.dtype == float_dtype


class TestNpTopk(object):
    def test_topk_largest_1d(self):
        input_array = np.array([10, 20, 5, 40, 30])
        k = 3
        values, indices = np_topk(input_array, k, largest=True, sorted=True)
        assert np.array_equal(values, np.array([40, 30, 20]))
        assert np.array_equal(indices, np.array([3, 4, 1]))

    def test_topk_smallest_1d(self):
        input_array = np.array([10, 20, 5, 40, 30])
        k = 2
        values, indices = np_topk(input_array, k, largest=False, sorted=True)
        assert np.array_equal(values, np.array([5, 10]))
        assert np.array_equal(indices, np.array([2, 0]))

    data_2d = [
        [42, 21, 36, 9, 20],
        [6, 29, 53, 81, 49],
        [26, 63, 24, 4, 37],
        [98, 72, 65, 40, 19],
    ]

    # 2D test data for working along axis 0
    test_data_2d_ax0_largest = [
        [1, data_2d, [[98, 72, 65, 81, 49]], [[3, 3, 3, 1, 1]]],
        [2, data_2d, [[98, 72, 65, 81, 49], [42, 63, 53, 40, 37]], [[3, 3, 3, 1, 1], [0, 2, 1, 3, 2]]],
        [
            3,
            data_2d,
            [[98, 72, 65, 81, 49], [42, 63, 53, 40, 37], [26, 29, 36, 9, 20]],
            [[3, 3, 3, 1, 1], [0, 2, 1, 3, 2], [2, 1, 0, 0, 0]],
        ],
    ]

    @pytest.mark.parametrize("topk, input_data, expected_data, expected_indices", test_data_2d_ax0_largest)
    def test_topk_largest_2d_axis_0(self, topk, input_data, expected_data, expected_indices):
        input_array = np.array(input_data)
        expected_result_values = np.array(expected_data)
        expected_result_indices = np.array(expected_indices)

        values, indices = np_topk(input_array, k=topk, axis=0, largest=True, sorted=True)
        assert np.array_equal(values, expected_result_values)
        assert np.array_equal(indices, expected_result_indices)

    # 2D test data for working along axis 1
    test_data_2d_ax1_largest = [
        [1, data_2d, [[42], [81], [63], [98]], [[0], [3], [1], [0]]],
        [2, data_2d, [[42, 36], [81, 53], [63, 37], [98, 72]], [[0, 2], [3, 2], [1, 4], [0, 1]]],
        [
            3,
            data_2d,
            [[42, 36, 21], [81, 53, 49], [63, 37, 26], [98, 72, 65]],
            [[0, 2, 1], [3, 2, 4], [1, 4, 0], [0, 1, 2]],
        ],
    ]

    @pytest.mark.parametrize("topk, input_data, expected_data, expected_indices", test_data_2d_ax1_largest)
    def test_topk_largest_2d_axis_1(self, topk, input_data, expected_data, expected_indices):
        input_array = np.array(input_data)
        expected_result_values = np.array(expected_data)
        expected_result_indices = np.array(expected_indices)

        values, indices = np_topk(input_array, k=topk, axis=1, largest=True, sorted=True)
        assert np.array_equal(values, expected_result_values)
        assert np.array_equal(indices, expected_result_indices)

    def test_topk_unsorted(self):
        input_array = np.array([10, 20, 5, 40, 30])
        sorted_top_values = np.array([40, 30, 20])
        k = 3
        values, indices = np_topk(input_array, k, largest=True, sorted=False)
        assert len(values) == k
        assert len(indices) == k
        assert not np.array_equal(values, sorted_top_values)
        assert set(values).issubset(input_array)
        assert set(input_array[indices]).issubset(values)

    def test_topk_zero(self):
        input_array = np.array([10, 20, 5, 40, 30])
        # k = 0
        values, indices = np_topk(input_array, k=0, largest=True, sorted=True)
        assert values.size == 0
        assert indices.size == 0

    def test_topk_greater_than_array_size(self):
        input_array = np.array([10, 20, 5, 40, 30])
        # k > array size

        with pytest.raises(ValueError, match="out of bounds"):
            values, indices = np_topk(input_array, k=10, largest=True, sorted=True)
