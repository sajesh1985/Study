import concurrent.futures
import json
import logging
import math
import re
import time
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd

from chatrd.core.code_generation.code_executor import CodeExecutor
from chatrd.core.code_generation.metadata import TABLE_METADATA
from chatrd.core.code_generation.prompt_processor import PromptProcessor
from chatrd.core.code_generation.schema import DataFrame
from chatrd.core.document import Document, TableResponse
from chatrd.core.llm import LCLLMFactory
from chatrd.core.llm.components import BaseLanguageModel
from chatrd.core.synthesizer import BaseResponseSynthesizer
from chatrd.core.synthesizer.utils import (
    check_combine_ratings_rating_actions,
    output_dataframe_combined_ratings_rating_actions,
)
from chatrd.core.thread_utils import submit_to_shared_thread_pool
from chatrd.engine.components.query_processor.query_retriever.uc_retrievers.utils import (
    get_date_values,
)

logger = logging.getLogger(__name__)


class StructuredSynthesizer(BaseResponseSynthesizer):

    def __init__(
        self,
        model_name: str,
        temperature: float,
        llm: BaseLanguageModel,
    ):
        self.llm = llm
        if not llm:
            self.llm = LCLLMFactory().get_llm(
                deployment_name_or_model_id=model_name,
                temperature=temperature,
            )
        self.batch_llm = LCLLMFactory().get_llm(
            deployment_name_or_model_id="anthropic.claude-3-5-sonnet-20241022-v2:0", temperature=0
        )

        self.prompt_processor = PromptProcessor()
        self.code_executor = CodeExecutor(self.prompt_processor)

    def get_response(self, message_str: str, chat_str: str, documents: List[Document], **kwargs: Dict[str, Any]) -> Any:
        article_tables, api_tables = self.get_article_api_table(documents)

        """
        chat_str - is an actual question, query from user
        message_str - None in my use cases as of now
        """

        logger.info(f"message_str is a {message_str}, chat_str is a {chat_str}")

        result = []
        selected_tables = []

        if api_tables:
            code_generation_futures = submit_to_shared_thread_pool(
                self.call_code_generation, message_str, chat_str, api_tables
            )
            selected_tables.extend(api_tables)

        if article_tables:
            table_synthesizer_futures = submit_to_shared_thread_pool(
                self.call_table_synthesizer, message_str, chat_str, article_tables
            )

        if api_tables:
            result.extend(code_generation_futures.result())

        if article_tables:
            article_response, article_selected_tables = table_synthesizer_futures.result()
            result.extend(article_response)
            selected_tables.extend(article_selected_tables)

        return result, selected_tables

    def get_article_api_table(self, documents: List[Document]):
        article_tables = []
        api_tables = []

        for doc in documents:
            chunk_type = doc.metadata.get("chunk_type", "")
            if chunk_type == "table":
                article_tables.append(doc)
            else:
                api_tables.append(doc)

        logger.info(
            f"Split documents: {len(article_tables)} article table documents, {len(api_tables)} API table documents"
        )
        return article_tables, api_tables

    def _create_relevance_prompt(self, query: str, document: Document) -> str:
        """Create a prompt to check if table is relevant to user query."""
        current_date = get_date_values()

        prompt = f"""<task_description>
You are tasked with determining if a table is relevant to a user's query. Please analyze if the table contains information that would be useful to answer the user's query based on the <table_metadata> provided and adhere to <relevance_instructions> to accomplish this task.
</task_description>

<context>
<input_query>{query}</input_query>
<current_date>{current_date["current_date"]}</current_date>
<current_quarter>{current_date["current_quarter"]}</current_quarter>
<table_metadata>
<article_title>{document.metadata.get("PreferredTitle", document.metadata.get("SourceTitle", ""))}</article_title>
<article_date>{document.metadata.get("articleReleaseDate")}</article_date>
<table_name>{document.metadata.get("table_title", "")}</table_name>
<table_description>{document.metadata.get("table_description", "")}</table_description>
<table_content>{document.content if isinstance(document.content, str) else ""}</table_content>
</table_metadata>
</context>

<relevance_instructions>
Take into account the following factors to determine the relevance of the table to the <input_query>:
- <context> includes all the important table and corresponding article metadata that should be both evaluated for relevance to the query.
- There have to be specific rows, columns, cells, or data points in <table_content> that provide direct response to the question posed.
- <table_name>, <table_description>, and <article_title> should be used to provide additional context about the table's content and its relevance to the query. If any of these fields contradict the input query, the table is NOT relevant.
- Account for specific timeframes, entities, industries/sectors, geographical areas, and performance indicators referenced in the input query. <table_content> must match all these criteria to be considered relevant. Incomplete data is not considered relevant.
</relevance_instructions>

<output_format>
Respond with "YES" if the table is relevant to the query, or "NO" if it is not relevant at all.
</output_format>

<examples>
----------------------------------
- User Query: What is the latest sample_metric for sample_country?
- Explanation: Table is relevant if it contains data about sample_metric for sample_country with the most recent date.
----------------------------------
- User Query: What are the trends in sample_country's sample_industry?
- Explanation: Table is relevant if it provides the latest trend data related to sample_industry in sample_country. If the table focus is too generic and does not specifically address both sample_industry and sample_country, it is not relevant.
----------------------------------
- User Query: Elaborate on potential future impact of sample_event on sample_sector.
- Explanation: Table is relevant if it contains projections, forecasts, or analyses about how sample_event may affect sample_sector in the future. Historical data or lack of specific focus on sample_event and sample_sector makes the table not relevant.
----------------------------------
- User Query: Give me a succinct report on the sample_market
- Explanation: Table is relevant if it provides a concise overview or key metrics about sample_market including recent data points. If only a specific subsector is present without broader market context, it is not relevant.
----------------------------------
- User Query: Impact of sample_policy on sample_economy in sample_country?
- Explanation: Table is relevant if it presents data on how exact sample_policy has influenced sample_economy in sample_country. If the table lacks any of these specific elements (sample_policy, sample_economy, sample_country), it is not relevant.
----------------------------------
- User Query: Any important updates about major sample_region automotive companies?
- Explanation: Table is relevant if it contains recent data points specifically about major automotive companies in sample_region. It has to be focused on countries from a sample_region. If it only discusses a single company or a single country or the recent updates are missing, it is not relevant.
----------------------------------
- User Query: Any important updates about sample_industry_or_sector? 
- Explanation: Table is relevant if it contains recent data points specifically about sample_industry_or_sector. If the table focus is generic and does not specifically address sample_industry_or_sector, it is not relevant.
----------------------------------
</examples>
"""

        return prompt

    def _create_combined_extraction_synthesis_prompt(self, query: str, relevant_tables: List[Document]) -> str:
        """Create a combined prompt to select relevant tables AND generate synthesized response."""

        current_date = get_date_values()

        tables_info = ""
        for i, document in enumerate(relevant_tables):
            tables_info += f"""<table_{i+1}>
<article_title>{document.metadata.get("PreferredTitle", document.metadata.get("SourceTitle", ""))}</article_title>
<table_id>{document.metadata.get('id', '')}</table_id>
<table_name>{document.metadata.get('table_title', '')}</table_name>
<table_content>{document.content if isinstance(document.content, str) else ""}</table_content>
</table_{i+1}>"""

        prompt = f"""<task_description>Your task is to select relevant tables from available ones provided in <context> and synthesize a response to the user's query using only the selected tables. Follow the instructions in <table_selection_instructions> for table selection and <response_synthesis_instructions> for response synthesis. Adhere to all requirements and format rules to ensure clarity and relevance in your output. Provide your final answer in the specified JSON format.</task_description>

<context>
<input_query>{query}</input_query>
<current_date>{current_date["current_date"]}</current_date>
<current_quarter>{current_date["current_quarter"]}</current_quarter>
<tables_metadata>{tables_info}</tables_metadata>
</context>

<table_selection_instructions>
- Select the most relevant tables from <tables_metadata> containing information that address the query's requirements and include them in the final response.
- Choose only tables that provide direct answers to the question, eliminating any repetitive data (such as entities, time periods, or metrics) already covered by previously selected tables.
- Account for specific timeframes, entities, industries/sectors, geographical areas, and performance indicators referenced in the input query. Selected tables must match all these criteria to be considered relevant.
- Tables in context are sorted by their release date with the newest table at the top. <critical>When answering, prioritize tables that are both new (higher-ranked) and relevant.</critical>
- If no relevant tables are found, return an empty list for extracted_data and an empty string for synthesized_response.
</table_selection_instructions>

<response_synthesis_instructions>
Use the selected relevant tables to generate an appropriate response to the user query. Response synthesis guidelines:
- Multiple tables may be used to construct the response if they collectively provide a comprehensive answer. No table merging is allowed - each table should be treated as a separate source of information.
- Include supporting elements (headers, labels) for clarity. Preserve column order as in the original table. If a column name is missing, keep it empty as it is. Do not replace it with other column names. 
- Time-specific data handling:
    -- For forecast queries, include only future projections, and exclude historical data prior to {current_date["current_date"]}.
    -- For historical queries, include only past data up to the current date {current_date["current_date"]}.
    -- Match query time periods precisely to table data.
    -- Adjust your language to treat {current_date["current_date"]} as the present, and avoid describing past years as if they are still ongoing or in the future.
<critical>No rephrasing of the table content is allowed. Even the punctuation marks should be preserved as in the original table.</critical>
</response_synthesis_instructions>

<response_structure>
Response requirements:
- Preserve markdown formatting in both table extraction and answer synthesis
- Provide response without additional comments, explanations, or extraneous text
- No rephrasing of content is allowed
- If there are no relevant tables, response should be an empty string
- Response must be a valid JSON object

Response structure:
- Utilize textual output to enhance readability when the query pertains to a single or specific value, or a straightforward analysis that yields a single cell value, single row, or brief summary. 
<examples>
- What is the latest sample_metric for sample_country?
- How likely is an sample_rating-rated entity in sample_country to be upgraded to sample_rating in the next quarter?
</examples>
- Utilize markdown output when the question pertains to multiple metrics or demands complex data extraction, leading to a structured table format, several rows/columns, or a more detailed analysis that requires a tabular representation.
<examples>
- How does the transition rate from sample_rating_1 to sample_rating_2 differ between sample_country_1 and sample_country_2?
- Summarize the methodology to rate sample_entity?
</examples>
- You may combine textual and tabular outputs when appropriate for comprehensive response.
- Ensure that the final response is accompanied by a descriptive leading sentence to help the user comprehend what the response is all about. Leading sentence has to be based exclusively on <table_name> used for response generation. It should precisely reflect the content of <article_title> and synthesized_response as well. Do not mention table names directly. Make sure that the leading sentence is short, concise and precise, and ends with a colon.
<leading_sentence_examples>
- sample_country has the following sample_metric:
- Here's the methodology used to rate sample_entity:
- Company XYZ has the following metrics:
</leading_sentence_examples>

Return ONLY a valid JSON object with this exact structure:
{{
  "extracted_data": [
    {{
      "document_id": "table_id from context tables",
      "table_name": "table_name from context tables"
    }},
    {{
      "document_id": "table_id from context tables",
      "table_name": "table_name from context tables"
    }}
  ],
  "leading_sentence": '''generated leading sentence''',
  "synthesized_response": '''final response'''
}}
</response_structure>

<output_examples>
User Query: 
What is the latest sample_metric for sample_country?
Output:
`{{
  "extracted_data": [
    {{
      "document_id": "sample_table_id_1",
      "table_name": "sample_table_name_1"
    }},
    {{
      "document_id": "sample_table_id_2",
      "table_name": "sample_table_name_2"
    }}
  ],
  "leading_sentence": '''Here's the report for sample_country:''',
  "synthesized_response": '''sample_country's latest sample_metric is moderately low.'''
}}`
----------------------------------------
User Query: 
What is the methodology used to rate sample_industry?
Output:
`{{
  "extracted_data": [
    {{
      "document_id": "sample_table_id_1",
      "table_name": "sample_table_name_1"
    }},
    {{
      "document_id": "sample_table_id_2",
      "table_name": "sample_table_name_2"
    }},
    {{
      "document_id": "sample_table_id_3",
      "table_name": "sample_table_name_3"
    }}
  ],
  "leading_sentence": '''The sample_industry is rated using the following key assumptions:''',
  "synthesized_response": '''| Stress | During an industry downturn | Outside an industry downturn |
  |:--------|:---------------------------|:----------------------------|
  | Lessee defaults | Yes | No |
  | Lease rate stress | Yes (only in the first two downturns) | No |
  | Residual value stress | Yes | No |
  | TOG | Yes | Yes (shorter TOG than during an industry downturn) |
  | RRR costs | Yes | Yes (lower RRR costs than during an industry downturn) |
  | Depreciation and useful life (aircraft-level assumption) | Yes (same assumptions apply during and outside a downturn) | Yes (same assumptions apply during and outside a downturn) |
  | Re-lease terms | Yes | Yes (longer term than during an industry downturn) |'''
}}`
----------------------------------------
</output_examples>
"""

        return prompt

    def _process_tables_and_synthesize(self, query: str, relevant_tables: List[Document]) -> Tuple[List[dict], str]:
        """Process tables and synthesize response in a single LLM call."""
        if not relevant_tables:
            return [], "No relevant tables found to answer the query."

        logger.info(f"Structured synthesizer - Synthesizing {len(relevant_tables)} relevant tables")
        prompt = self._create_combined_extraction_synthesis_prompt(query, relevant_tables)

        try:
            response = self.batch_llm.invoke(prompt)
            response_text = response.content if hasattr(response, "content") else str(response)
            # remove non-printable characters and control characters
            response_text = re.sub(r"[^\x20-\x7E\n]", " ", response_text)
            logger.info(f"Structured synthesizer - Response: {response_text}")

            # Parse JSON response
            try:
                # Extract JSON from response (in case there's extra text)
                start_idx = response_text.find("{")
                end_idx = response_text.rfind("}") + 1

                if start_idx != -1 and end_idx != 0:
                    json_str = response_text[start_idx:end_idx]
                    parsed_data = json.loads(json_str)

                    # Validate structure
                    if "extracted_data" in parsed_data and "synthesized_response" in parsed_data:
                        extracted_tables = parsed_data["extracted_data"]
                        leading_sentence = ""
                        if "leading_sentence" in parsed_data:
                            leading_sentence = parsed_data["leading_sentence"]
                        synthesized_response = (
                            leading_sentence + "\n\n" + parsed_data["synthesized_response"]
                            if leading_sentence
                            else parsed_data["synthesized_response"]
                        )

                        # Validate extracted data format
                        valid_tables = []
                        for table in extracted_tables:
                            if all(key in table for key in ["document_id", "table_name"]):
                                valid_tables.append(table)

                        logger.info(
                            f"Structured synthesizer - Filtered {len(valid_tables)} table(s) out of {len(relevant_tables)} relevant tables"
                        )
                        return valid_tables, synthesized_response
                    else:
                        logger.error("Structured prompt malfunction: Missing required fields in generated response")
                        return self._parse_response_manually(response_text, relevant_tables)
                else:
                    logger.error("Structured synthesizer prompt malfunction: No valid JSON found in generated response")
                    return self._parse_response_manually(response_text, relevant_tables)

            except json.JSONDecodeError as e:
                logger.error(
                    f"Structured synthesizer prompt malfunction: Failed to parse JSON from generated response: {e}"
                )
                logger.debug(f"Raw response: {response_text}")
                return self._parse_response_manually(response_text, relevant_tables)

        except Exception as e:
            logger.error(
                f"Structured synthesizer prompt malfunction and manual processing failed: Error in generated response: {e}"
            )
            return self._fallback_combined_processing(query, relevant_tables)

    def _fallback_combined_processing(
        self, query: str, relevant_tables: List[Document]
    ) -> Tuple[List[Dict[str, Any]], str]:
        """Fallback to basic processing if combined approach fails."""
        logger.info("Using fallback combined processing - selecting all relevant tables")

        try:
            # Select all relevant tables
            selected_tables = [
                {
                    "document_id": table.metadata.get("id"),
                    "table_name": table.metadata.get("table_title"),
                }
                for table in relevant_tables
            ]

            # Generate basic synthesized response
            synthesized_response = self._generate_fallback_response(query, relevant_tables)

            return selected_tables, synthesized_response

        except Exception as e:
            logger.error(f"Fallback processing also failed: {e}")
            # Ultimate fallback
            fallback_tables = [
                {
                    "document_id": table.metadata.get("id"),
                    "table_name": table.metadata.get("table_title"),
                }
                for table in relevant_tables
            ]
            return fallback_tables, ""

    def _generate_fallback_response(self, query: str, relevant_tables: List[Document]) -> str:
        """Generate a basic fallback response using available table data."""
        if not relevant_tables:
            return ""

        # Create a simple response using available table content
        response_parts = []
        for table in relevant_tables:
            table_name = table.metadata.get("table_title", "Unknown Table")
            table_content = table.content if isinstance(table.content, str) else ""
            if table_content:
                response_parts.append(f"{table_name}:\n{table_content}")

        if response_parts:
            return "\n\n".join(response_parts[:3])  # Limit to first 3 tables
        else:
            tables_info = ""
            for i, table in enumerate(relevant_tables):
                tables_info += (
                    f"Table Name: {table.metadata.get('table_title', 'Unknown Table')}\n"
                    f"Table content: {table.content if isinstance(table.content, str) else ''}\n"
                )
            return f"Following tables can answer your question: {tables_info}"

    def _is_table_relevant(self, query: str, document: Document) -> bool:
        """Check if a single table document is relevant to the user query using LLM."""
        prompt = self._create_relevance_prompt(query, document)
        try:
            response = self.llm.invoke(prompt)
            response_text = response.content if hasattr(response, "content") else str(response)
            # remove non-printable characters and control characters
            response_text = re.sub(r"[^\x20-\x7E\n]", " ", response_text)
            is_relevant = "YES" in response_text.strip().upper()
            logger.debug(f"Table '{document.metadata.get('table_title', '')}' relevance check: {is_relevant}")
            return is_relevant

        except Exception as e:
            logger.error(f"Error checking table relevance for document {document.metadata.get('id')}: {e}")
            # In case of error, include the table (fail-safe approach)
            return True

    def _process_single_document(self, query: str, document: Document) -> Optional[Document]:
        """Process a single document and return formatted result if relevant."""
        try:
            if self._is_table_relevant(query, document):
                return document
            return None
        except Exception as e:
            logger.error(f"Error processing document {document.metadata.get('id')}: {e}")
            return None

    def check_table_relevance(self, query: str, documents: List[Document]) -> List[Dict[str, Any]]:
        """Filter and return only tables relevant to the user query with parallel processing."""
        if not documents:
            return []
        logger.info(f"Structured synthesizer - Processing {len(documents)} tables for relevance to query: '{query}'")
        relevant_tables = []
        # Process documents in parallel using shared thread pool
        # Submit all document processing tasks to the shared pool
        future_to_doc = {
            submit_to_shared_thread_pool(self._process_single_document, query, doc): doc for doc in documents
        }
        # Collect results as they complete
        for future in concurrent.futures.as_completed(future_to_doc):
            try:
                result = future.result()
                if result is not None:
                    relevant_tables.append(result)
            except Exception as e:
                doc = future_to_doc[future]
                logger.error(f"Error processing document {doc.metadata.get('id', 'unknown')}: {e}")
        return relevant_tables

    def log_docs_info(
        self, documents: List[Document] = [], document_ids: List[str] = [], print_only_ids: bool = False
    ) -> None:
        """Log information about the documents being processed."""
        if print_only_ids:
            doc_ids = [doc.metadata.get("id", "") for doc in documents]
            doc_names = [doc.metadata.get("table_title", "") for doc in documents]
            for doc_id, doc_name in zip(doc_ids, doc_names):
                logger.info(f"Chunk ID: {doc_id}, Table Title: {doc_name}")
            return

        selected_docs = []
        for doc_id in document_ids:
            selected_docs.extend([doc for doc in documents if doc.metadata.get("id") == doc_id])
        if not selected_docs:
            selected_docs = documents
        for doc in selected_docs:
            logger.info(
                f"\n=========================================================\n"
                f"Table chunk ID: {doc.metadata.get('id', '')}\n"
                f"=========================================================\n"
            )

    def call_table_synthesizer(
        self, message_str: str, chat_str: str, documents: List[Document]
    ) -> List[Dict[str, Any]]:
        """Filter and process tables to return only relevant parts with combined extraction and synthesis."""
        logger.info(f"Structured synthesizer - Count input table chunks: {len(documents)}")
        self.log_docs_info(documents=documents, print_only_ids=False)

        # Step 1: Get relevant tables
        start_time = time.perf_counter()
        logger.info(f"Start of call_table_synthesizer with message_str: {chat_str}")
        relevant_tables = self.check_table_relevance(chat_str, documents)

        logger.info(
            f"Structured synthesizer - Relevant table chunks {len(relevant_tables)} out of total {len(documents)} chunks."
        )
        self.log_docs_info(documents=relevant_tables, print_only_ids=True)

        if not relevant_tables:
            return [], []

        # Step 2: Process tables and synthesize response in single call
        selected_tables, synthesized_response = self._process_tables_and_synthesize(chat_str, relevant_tables)

        # Step 3: Remove duplicates and ensure uniqueness
        unique_tables = []
        seen = set()

        for table in selected_tables:
            # Create a key based on document_id and table_name
            key = f"{table['document_id']}_{table['table_name']}"
            if key not in seen:
                seen.add(key)
                unique_tables.append(table)

        logger.info(
            f"Structured synthesizer - Selected final table chunks {len(unique_tables)} out of {len(relevant_tables)} relevant chunks.\nFinal chunks => {unique_tables}"
        )
        logger.info(f"Structured synthesizer - Synthesized response: {synthesized_response}")

        # Map selected tables back to original documents
        selected_docs = []
        for doc in documents:
            for selected_table in unique_tables:
                if doc.metadata["id"] == selected_table["document_id"]:
                    selected_docs.append(doc)
                    break

        end_time = time.perf_counter()
        execution_time = end_time - start_time
        logger.info(f"the execution_time: {execution_time}")

        return [{"type": "text", "content": synthesized_response}], selected_docs

    def call_code_generation(self, query: str, chat_str: str, documents: List[Document]) -> Any:
        dataframes, uc_specific_examples = self.get_code_generation_compatible_data(documents)
        generated_code = self.prompt_processor.process_prompt(chat_str, dataframes, examples_text=uc_specific_examples)

        result = self.code_executor.execute_code(generated_code, chat_str, dataframes)
        response = []
        if result["type"] == "table_text_list":
            for item in result["content"]:
                key = list(item.keys())[0]
                if isinstance(item[key], pd.DataFrame) and len(item[key]) > 0:
                    try:
                        item_dict = self._replace_none_with_empty(item[key].to_dict())
                    except Exception as e:
                        logger.info(f"_replace_none_with_empty function failed: {e}")
                        item_dict = item[key].to_dict()
                    response.extend(
                        [
                            {"type": "text", "content": key},
                            {
                                "type": "table",
                                "content": TableResponse(rows=item_dict, column_schema={}),
                            },
                        ]
                    )
                elif isinstance(item[key], str) and len(item[key]) > 0:
                    response.extend(
                        [
                            {"type": "text", "content": key},
                            {"type": "text", "content": item[key]},
                        ]
                    )
                elif len(item[key]) == 0:
                    logger.info(f"Code generator - empty value for key: {key}")
        return response

    def get_code_generation_compatible_data(self, documents):
        dataframes = list()
        uc_specific_examples_list = list()

        combine_ratings_rating_actions = check_combine_ratings_rating_actions(documents)
        ratings_df = pd.DataFrame()
        ratings_actions_df = pd.DataFrame()
        for doc in documents:
            uc_type = doc.uc_type
            table_metadata = TABLE_METADATA[uc_type]
            # table_key = table_metadata.table_key
            df_modified = table_metadata.transform_data(
                pd.DataFrame(doc.content.rows if isinstance(doc.content, TableResponse) else doc.content.data)
            )
            match combine_ratings_rating_actions, uc_type:
                case True, "ratings":
                    ratings_df = df_modified
                    continue
                case True, "rating_action":
                    ratings_actions_df = df_modified
                    continue
            description = table_metadata.table_description
            special_instructions = ""
            special_instructions += table_metadata.prompt_keep_columns()
            table_key_text = table_metadata.list_table_key()
            # if len(table_key) > 0:
            #     table_key_values = df_modified[table_key].drop_duplicates().sort_values(by=table_key)
            # else:
            #     table_key_values = pd.DataFrame()

            examples = table_metadata.get_examples()
            uc_specific_examples_list = uc_specific_examples_list + examples

            dataframes.append(
                DataFrame(df_modified, uc_type + "_df", description, {}, special_instructions, table_key_text)
            )
            # dataframes.append(DataFrame(df_modified, uc_type + "_df", description, {}, "", table_key_values))

        if combine_ratings_rating_actions and (not ratings_df.empty) and (not ratings_actions_df.empty):
            combined_ratings_rating_actions_df, examples = output_dataframe_combined_ratings_rating_actions(
                ratings_df, ratings_actions_df
            )
            uc_specific_examples_list = uc_specific_examples_list + examples
            dataframes.append(combined_ratings_rating_actions_df)
            logger.info("Combined ratings and rating_action into uc_type = ratings_rating_action_combined")

        uc_specific_examples = "\n\n*****\n\n".join(uc_specific_examples_list)

        return dataframes, uc_specific_examples

    def _replace_none_with_empty(self, data):
        replace_values = ["none", "nan", "na", "null", "<na>", "<null>", "<none>", "<nan>"]
        for key, sub_dict in data.items():
            for sub_key, value in sub_dict.items():
                if isinstance(value, str):
                    for replace_value in replace_values:
                        # Use regex to match whole words only
                        value = (
                            re.sub(rf"\b{replace_value}\b", "", value, flags=re.IGNORECASE)
                            .replace("()", "")
                            .replace("  ", " ")
                        )
                    sub_dict[sub_key] = value.strip()
                if value is None or (isinstance(value, float) and math.isnan(value)):
                    sub_dict[sub_key] = ""
        return data

    def _parse_response_manually(
        self, response_text: str, relevant_tables: List[Document]
    ) -> Tuple[List[Dict[str, Any]], str]:
        """Manually parse response text when JSON parsing fails."""
        try:
            leading_sentence, before_colon, after_colon = "", "", ""
            if "leading_sentence" in response_text:
                leading_sentence_match = re.search(r'"leading_sentence":\s*"([^"]*)"', response_text)
                leading_sentence = leading_sentence_match.group(1) if leading_sentence_match else ""

            if "synthesized_response" in response_text:
                parts = response_text.split("synthesized_response")

                after_colon = ""
                if len(parts) > 1:
                    generated_content = parts[1]
                    # Find the first colon and take everything after it
                    if ":" in generated_content:
                        after_colon = generated_content.split(":", 1)[1].strip()
                        # Clean up quotes and formatting
                        after_colon = after_colon.strip('"').strip("'").strip()
                        # Remove trailing closing braces/brackets if present
                        after_colon = after_colon.rstrip('"}]').strip()
                    else:
                        after_colon = generated_content.strip()

                synthesized_response = leading_sentence + "\n\n" + after_colon if leading_sentence else after_colon

                before_colon = parts[0]
                extracted_tables = []
                try:
                    # Look for document_id and table_name patterns in the extracted part
                    doc_id_pattern = r'"document_id":\s*"([^"]+)"'
                    table_name_pattern = r'"table_name":\s*"([^"]+)"'
                    doc_ids = re.findall(doc_id_pattern, before_colon)
                    table_names = re.findall(table_name_pattern, before_colon)

                    # Match doc_ids with table_names
                    for i in range(min(len(doc_ids), len(table_names))):
                        extracted_tables.append({"document_id": doc_ids[i], "table_name": table_names[i]})

                    # If we couldn't extract properly, fall back to all relevant tables
                    if not extracted_tables:
                        extracted_tables = [
                            {
                                "document_id": table.metadata.get("id"),
                                "table_name": table.metadata.get("table_title"),
                            }
                            for table in relevant_tables
                        ]

                except Exception as e:
                    # Fallback to all relevant tables
                    logger.error(f"Error parsing extracted_data manually: {e}")
                    extracted_tables = [
                        {
                            "document_id": table.metadata.get("id"),
                            "table_name": table.metadata.get("table_title"),
                        }
                        for table in relevant_tables
                    ]
                logger.info(
                    f"Manually parsed response: {len(extracted_tables)} table(s), response length: {len(synthesized_response)}"
                )
                return extracted_tables, synthesized_response
            else:
                # If "synthesized_response" is not found, treat the whole response as synthesized_response
                logger.warning("'synthesized_response' keyword not found in response, using whole response")
                return [
                    {
                        "document_id": table.metadata.get("id"),
                        "table_name": table.metadata.get("table_title"),
                    }
                    for table in relevant_tables
                ], response_text.strip()

        except Exception as e:
            logger.error(f"Failed to manually parse response: {e}")
            return self._fallback_combined_processing(query, relevant_tables)
