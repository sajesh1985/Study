import logging
from types import GeneratorType
from typing import Any, Dict, Optional, Union

import pandas as pd
import streamlit as st
from pandas import json_normalize

from chatrd.core.document import (
    CSDTableResponse,
    ParentChildTableResponse,
    TableResponse,
)
from chatrd.core.llm.components.message import AIMessage
from chatrd.core.utils import ChatMessage, MessageRole
from chatrd.engine.app.config import ASSISTANT_ROLE
from chatrd.engine.app.utils import contains_a_tag
from chatrd.engine.callbacks import Callback
from chatrd.engine.utils import CitedSourceList

logger = logging.getLogger(__name__)


class StreamlitCallback(Callback):
    def execute_callback(self, callback_message: Any, callback_type: str = "message", mode: str = "generation") -> None:
        if isinstance(callback_message, str):
            self._update_status(callback_message, mode)
        elif isinstance(callback_message, GeneratorType):
            return self._update_status(callback_message, mode, "answer")
        elif isinstance(callback_message, AIMessage):
            self._update_status(callback_message.content, mode, "answer")
        elif isinstance(callback_message, pd.DataFrame):
            self._update_status(callback_message, mode, "answer")
        elif isinstance(callback_message, CSDTableResponse):
            self._update_status(callback_message, mode, "answer")
        elif isinstance(callback_message, ParentChildTableResponse):
            self._update_status(callback_message, mode, "answer")
        elif isinstance(callback_message, Dict):
            if callback_type == "describe_classification":
                updated_callback_message = self._describe_classification(callback_message)
                self._update_status(updated_callback_message, mode)
            elif callback_type == "data_service":
                self._update_status(callback_message, mode)
            else:
                raise NotImplementedError("Provided Callback is not implemented yet.")
        else:
            raise NotImplementedError("Provided Callback format is not implemented yet.")

    def _update_status(
        self,
        message: Union[str, GeneratorType, pd.DataFrame, Dict],
        mode: str,
        message_type: Optional[str] = "display_artifacts",
    ):
        msg = {"role": ASSISTANT_ROLE, "content": message}
        scitedSourceList = CitedSourceList(sources=[])
        if isinstance(message, GeneratorType):
            logger.info("Started streaming answer!")
            message_placeholder = st.empty()
            full_response = ""
            for m in message:
                if not isinstance(m, str):
                    if isinstance(m, CitedSourceList):
                        scitedSourceList = m
                    else:
                        full_response += contains_a_tag(m.content)
                else:
                    # full_response += m.replace(":", "\:").replace("$", "\$").replace("\n", "  \n")
                    full_response += contains_a_tag(m)
                message_placeholder.markdown(full_response + "▌")
            message_placeholder.write(full_response)
            msg["content"] = full_response
        elif isinstance(message, pd.DataFrame):
            st.dataframe(message)
        elif isinstance(message, CSDTableResponse) or isinstance(message, ParentChildTableResponse):
            st.dataframe(json_normalize(message.data))
        elif isinstance(message, Dict):
            st.json(message, expanded=False)
        else:
            st.markdown(contains_a_tag(msg["content"]), unsafe_allow_html=True)
        if mode == "generation":
            st.session_state.generation_messages.append(msg)
            if message_type == "answer":
                if (
                    isinstance(message, CSDTableResponse)
                    or isinstance(message, TableResponse)
                    or isinstance(message, ParentChildTableResponse)
                ):
                    st.session_state.chat_history.append(ChatMessage(role=MessageRole.ASSISTANT, content=message.data))
                else:
                    st.session_state.chat_history.append(
                        ChatMessage(role=MessageRole.ASSISTANT, content=msg["content"])
                    )
        else:
            st.session_state.retrieval_messages.append(msg)
        return scitedSourceList.sources

    def _describe_classification(self, processed: Optional[Dict] = None) -> str:
        if processed:
            message = "User request analysis:\n\n"
            if processed["is_lookup"]:
                message += "* Answer requires calling ⏳ __Data Service__\n"
            if processed["require_documents"]:
                message += (
                    f"* Answer requires search for ⏳ __"
                    f"{'Ratings Criteria' if processed['is_methodology'] else 'Ratings Research'} Documents__"
                )
                if processed["is_macro_industry_trends"] and (not processed["is_methodology"]):
                    message += " and __Macro / Industry Trends__ information"
            message += "\n\n"

            return message
