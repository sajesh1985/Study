﻿// Copyright Notice! 
// This document is protected under the trade secret and copyright 
// laws as the property of Fidelity National Information Services, Inc. 
// Copying, reproduction or distribution should be limited and only to 
// employees with a “need to know” to do their job. 
// Any disclosure of this document to third parties is strictly prohibited.
// © 2017 Fidelity National Information Services.
// All rights reserved worldwide.

namespace Fis.Epp.Fusion.WebAPI
{
    using Fis.Epp.Fusion.WebAPI.LoggerModels;
    using Fis.Epp.Fusion.WebAPI.Models;
    using Microsoft.AspNetCore.Http;

    /// <summary>
    /// Represents an application diagnostics utility.
    /// </summary>
    public class AppDiagnostics
    {
        #region Public Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="Fis.Epp.Fusion.UI.Resources.Rest.AppDiagnostics"/> class.
        /// </summary>
        /// <param name="context">The <see cref="Fis.Epp.Fusion.UI.Resources.Rest.AppContext"/>.</param>
        public AppDiagnostics(HttpContext context)
        {
            _appContext = context;
        }

        #endregion

        #region Protected Properties

        /// <summary>
        /// Gets the current <see cref="Fis.Epp.Fusion.UI.Resources.Rest.AppContext"/>.
        /// </summary>
        protected HttpContext Context
        {
            get { return _appContext; }
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Traces the current user information to the Fis.Epp.Fusion.UI.App.Users trace.
        /// </summary>
        public void RecordUser(AppUserLoggerModel userData)
        {
            if (userData != null)
            {
                string userAgent = Context.Request.Headers[RequestHeader.User_Agent.GetEnumDescription()].ToString();
                string userIpAddress = Context.Request.HttpContext.Connection.RemoteIpAddress.ToString();
                string userHostName = Context.Request.Host.Host;
                string acceptEncoding = Context.Request.Headers[RequestHeader.Accept_Encoding.GetEnumDescription()];

                NLog.LogEventInfo logUserEvent = new NLog.LogEventInfo(NLog.LogLevel.Info, "", "");
                logUserEvent.Properties[LoggerEnum.CorrelationId.GetEnumDescription()] = userData.CorrelationId;
                logUserEvent.Properties[LoggerEnum.BrandId.GetEnumDescription()] = userData.BrandId;
                logUserEvent.Properties[LoggerEnum.UserId.GetEnumDescription()] = userData.UserId;
                logUserEvent.Properties[LoggerEnum.MemberId.GetEnumDescription()] = userData.MemberId;
                logUserEvent.Properties[LoggerEnum.RequestorId.GetEnumDescription()] = userData.RequestorId;
                logUserEvent.Properties[LoggerEnum.UserAgent.GetEnumDescription()] = userAgent;
                logUserEvent.Properties[LoggerEnum.UserIpAddress.GetEnumDescription()] = userIpAddress;
                logUserEvent.Properties[LoggerEnum.UserHostName.GetEnumDescription()] = userHostName;
                logUserEvent.Properties[LoggerEnum.AcceptEncoding.GetEnumDescription()] = acceptEncoding;
                NLog.Logger _loggerUsers = NLog.LogManager.GetLogger("FusionUsers");
                _loggerUsers.Log(logUserEvent);
            }
        }

        /// <summary>
        /// Traces the current context error to the Fis.Epp.Fusion.UI.Resources trace.
        /// </summary>
        public void RecordResourcesException(AppExceptionLoggerModel errorData)
        {
            if (errorData != null)
            {
                NLog.LogEventInfo logErrorEvent = new NLog.LogEventInfo(NLog.LogLevel.Error, "", "");
                logErrorEvent.Properties[LoggerEnum.CorrelationId.GetEnumDescription()] = errorData.CorrelationId;
                logErrorEvent.Properties[LoggerEnum.BrandId.GetEnumDescription()] = errorData.BrandId;
                logErrorEvent.Properties[LoggerEnum.UserId.GetEnumDescription()] = errorData.UserId;
                logErrorEvent.Properties[LoggerEnum.MemberId.GetEnumDescription()] = errorData.MemberId;
                logErrorEvent.Properties[LoggerEnum.RequestorId.GetEnumDescription()] = errorData.RequestorId;
                logErrorEvent.Properties[LoggerEnum.RequestUrl.GetEnumDescription()] = errorData.RequestUrl;
                logErrorEvent.Properties[LoggerEnum.ErrorStack.GetEnumDescription()] = errorData.ErrorStack;
                logErrorEvent.Properties[LoggerEnum.ErrorMessage.GetEnumDescription()] = errorData.ErrorMessage;
                NLog.Logger _logger = NLog.LogManager.GetLogger("FusionResources");
                _logger.Log(logErrorEvent);
            }
        }

        /// <summary>
        /// Traces the current context error to the Fis.Epp.Fusion.UI.App trace.
        /// </summary>
        public void RecordException(AppExceptionLoggerModel errorData)
        {
            if (errorData != null)
            {
                NLog.LogEventInfo logUIErrorEvent = new NLog.LogEventInfo(NLog.LogLevel.Error, "", "");
                logUIErrorEvent.Properties[LoggerEnum.CorrelationId.GetEnumDescription()] = errorData.CorrelationId;
                logUIErrorEvent.Properties[LoggerEnum.BrandId.GetEnumDescription()] = errorData.BrandId;
                logUIErrorEvent.Properties[LoggerEnum.UserId.GetEnumDescription()] = errorData.UserId;
                logUIErrorEvent.Properties[LoggerEnum.MemberId.GetEnumDescription()] = errorData.MemberId;
                logUIErrorEvent.Properties[LoggerEnum.RequestorId.GetEnumDescription()] = errorData.RequestorId;
                logUIErrorEvent.Properties[LoggerEnum.RequestUrl.GetEnumDescription()] = errorData.RequestUrl;
                logUIErrorEvent.Properties[LoggerEnum.ErrorStack.GetEnumDescription()] = errorData.ErrorStack;
                logUIErrorEvent.Properties[LoggerEnum.ErrorMessage.GetEnumDescription()] = errorData.ErrorMessage;
                NLog.Logger _loggerUI = NLog.LogManager.GetLogger("FusionUI");
                _loggerUI.Log(logUIErrorEvent);
            }
        }

        /// <summary>
        /// Traces the service error to the Fis.Epp.Fusion.UI.App.Service trace.
        /// </summary>
        public void RecordServiceException(ServiceExceptionLoggerModel serviceError)
        {
            if (serviceError != null)
            {
                NLog.LogEventInfo logServiceErrorEvent = new NLog.LogEventInfo(NLog.LogLevel.Warn, "", "");

                if (!string.IsNullOrEmpty(serviceError.MessageSeverity))
                {
                    switch (serviceError.MessageSeverity.ToUpper())
                    {
                        case "CRITICAL":
                        case "ERROR":
                            logServiceErrorEvent = new NLog.LogEventInfo(NLog.LogLevel.Error, "", "");
                            break;
                        case "INFORMATION":
                            logServiceErrorEvent = new NLog.LogEventInfo(NLog.LogLevel.Info, "", "");
                            break;
                        default:
                            break;
                    }
                }

                logServiceErrorEvent.Properties[LoggerEnum.CorrelationId.GetEnumDescription()] = serviceError.CorrelationId;
                logServiceErrorEvent.Properties[LoggerEnum.BrandId.GetEnumDescription()] = serviceError.BrandId;
                logServiceErrorEvent.Properties[LoggerEnum.UserId.GetEnumDescription()] = serviceError.UserId;
                logServiceErrorEvent.Properties[LoggerEnum.MemberId.GetEnumDescription()] = serviceError.MemberId;
                logServiceErrorEvent.Properties[LoggerEnum.RequestorId.GetEnumDescription()] = serviceError.RequestorId;
                logServiceErrorEvent.Properties[LoggerEnum.ApplicationId.GetEnumDescription()] = serviceError.ApplicationId;
                logServiceErrorEvent.Properties[LoggerEnum.ServiceUuid.GetEnumDescription()] = serviceError.ServiceUuid;
                logServiceErrorEvent.Properties[LoggerEnum.MethodId.GetEnumDescription()] = serviceError.MethodId;
                logServiceErrorEvent.Properties[LoggerEnum.ClientId.GetEnumDescription()] = serviceError.ClientId;
                logServiceErrorEvent.Properties[LoggerEnum.Verb.GetEnumDescription()] = serviceError.Verb;
                logServiceErrorEvent.Properties[LoggerEnum.MessageSeverity.GetEnumDescription()] = serviceError.MessageSeverity;
                logServiceErrorEvent.Properties[LoggerEnum.HTTP_CODE.GetEnumDescription()] = serviceError.HTTP_CODE;
                logServiceErrorEvent.Properties[LoggerEnum.MessageCode.GetEnumDescription()] = serviceError.MessageCode;
                logServiceErrorEvent.Properties[LoggerEnum.Message.GetEnumDescription()] = serviceError.Message;


                NLog.Logger _loggerServices = NLog.LogManager.GetLogger("Services");
                _loggerServices.Log(logServiceErrorEvent);
            }
        }

        /// <summary>
        /// Traces a service performance in the Fis.Epp.Fusion.UI.App.Service.Performance trace.
        /// </summary>
        public void RecordServicePerformance(ServicePerformancLoggerModel serviceData)
        {
            if (serviceData != null)
            {
                RecordPerformance(serviceData, "ServicesPerformance");
            }
        }

        /// <summary>
        /// Traces a service performance in the Fis.Epp.Fusion.UI.App.Branding.Performance trace.
        /// </summary>
        public void RecordBrandingPerformance(ServicePerformancLoggerModel serviceData)
        {
            if (serviceData != null)
            {
                RecordPerformance(serviceData, "BrandingPerformance");
            }
        }

        /// <summary>
        /// Traces a service payload in the Fis.Epp.Fusion.UI.App.Service.Payload trace.
        /// </summary>
        public void RecordServicePayload(ServicePayloadLoggerModel serviceData)
        {
            if (serviceData != null)
            {
                NLog.LogEventInfo logServiceEvent = new NLog.LogEventInfo(NLog.LogLevel.Info, "", "");
                logServiceEvent.Properties[LoggerEnum.CorrelationId.GetEnumDescription()] = serviceData.CorrelationId;
                logServiceEvent.Properties[LoggerEnum.BrandId.GetEnumDescription()] = serviceData.BrandId;
                logServiceEvent.Properties[LoggerEnum.UserId.GetEnumDescription()] = serviceData.UserId;
                logServiceEvent.Properties[LoggerEnum.MemberId.GetEnumDescription()] = serviceData.MemberId;
                logServiceEvent.Properties[LoggerEnum.RequestorId.GetEnumDescription()] = serviceData.RequestorId;
                logServiceEvent.Properties[LoggerEnum.ApplicationId.GetEnumDescription()] = serviceData.ApplicationId;
                logServiceEvent.Properties[LoggerEnum.ServiceUuid.GetEnumDescription()] = serviceData.ServiceUuid;
                logServiceEvent.Properties[LoggerEnum.MethodId.GetEnumDescription()] = serviceData.MethodId;
                logServiceEvent.Properties[LoggerEnum.ClientId.GetEnumDescription()] = serviceData.ClientId;
                logServiceEvent.Properties[LoggerEnum.Verb.GetEnumDescription()] = serviceData.Verb;
                logServiceEvent.Properties[LoggerEnum.HTTP_CODE.GetEnumDescription()] = serviceData.HTTP_CODE;
                logServiceEvent.Properties[LoggerEnum.MessageCode.GetEnumDescription()] = serviceData.MessageCode;
                logServiceEvent.Properties[LoggerEnum.RequestJSON.GetEnumDescription()] = serviceData.RequestJSON;
                logServiceEvent.Properties[LoggerEnum.ResponseJSON.GetEnumDescription()] = serviceData.ResponseJSON;

                NLog.Logger _loggerServicePayload = NLog.LogManager.GetLogger("ServicesPayload");
                _loggerServicePayload.Log(logServiceEvent);
            }
        }

        #endregion

        private void RecordPerformance(ServicePerformancLoggerModel serviceData, string logger)
        {
            NLog.LogEventInfo logServiceEvent = new NLog.LogEventInfo(NLog.LogLevel.Info, "", "");
            logServiceEvent.Properties[LoggerEnum.CorrelationId.GetEnumDescription()] = serviceData.CorrelationId;
            logServiceEvent.Properties[LoggerEnum.BrandId.GetEnumDescription()] = serviceData.BrandId;
            logServiceEvent.Properties[LoggerEnum.UserId.GetEnumDescription()] = serviceData.UserId;
            logServiceEvent.Properties[LoggerEnum.MemberId.GetEnumDescription()] = serviceData.MemberId;
            logServiceEvent.Properties[LoggerEnum.RequestorId.GetEnumDescription()] = serviceData.RequestorId;
            logServiceEvent.Properties[LoggerEnum.ApplicationId.GetEnumDescription()] = serviceData.ApplicationId;
            logServiceEvent.Properties[LoggerEnum.ServiceUuid.GetEnumDescription()] = serviceData.ServiceUuid;
            logServiceEvent.Properties[LoggerEnum.MethodId.GetEnumDescription()] = serviceData.MethodId;
            logServiceEvent.Properties[LoggerEnum.ClientId.GetEnumDescription()] = serviceData.ClientId;
            logServiceEvent.Properties[LoggerEnum.Verb.GetEnumDescription()] = serviceData.Verb;
            logServiceEvent.Properties[LoggerEnum.HTTP_CODE.GetEnumDescription()] = serviceData.HTTP_CODE;
            logServiceEvent.Properties[LoggerEnum.MessageCode.GetEnumDescription()] = serviceData.MessageCode;
            logServiceEvent.Properties[LoggerEnum.Duration.GetEnumDescription()] = serviceData.Duration;

            NLog.Logger _loggerServicePerformance = NLog.LogManager.GetLogger(logger);
            _loggerServicePerformance.Log(logServiceEvent);
        }

        #region Private Fields

        private readonly HttpContext _appContext;

        #endregion

    }
}
