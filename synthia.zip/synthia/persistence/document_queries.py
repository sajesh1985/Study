import json
import logging
from types import NoneType
from typing import Dict, Type, LiteralString, Optional, Any, Literal, List, cast, Union
from psycopg_pool import AsyncConnectionPool
import psycopg
from psycopg import sql

from src.synthia.persistence.database_manager import get_connection_pool, initialize_connection_pool

logger = logging.getLogger(__name__)


class Query:
    def __init__(self, sql: LiteralString, schema: Dict[str, Type]):
        self.sql = sql
        self.schema = schema
        self.conn: AsyncConnectionPool | None = None

    def _validate_params(self, params: dict) -> dict:
        filtered = {}
        for key, expected_type in self.schema.items():
            if key not in params:
                raise ValueError(f"Missing required parameter: '{key}'")
            value = params[key]
            if not isinstance(value, expected_type):
                raise TypeError(
                    f"Parameter '{key}' must be of type {expected_type.__name__}, got {type(value).__name__}")
            filtered[key] = value
        return filtered

    async def _is_connection_healthy(self) -> bool:
        try:
            async with self.conn.connection() as aconn:
                async with aconn.cursor() as cur:
                    await cur.execute("SELECT 1")
                    logger.info("Database connection is healthy")
                return True
        except Exception as ex:
            logger.debug("Database connection health check failed: %s", ex)
            return False

    def build_params(self, params: dict) -> dict:
        return self._validate_params(params)

    async def execute(
            self,
            params: Union[dict, list[dict]],
            fetch: Optional[Literal["one", "all"]] = None,
            multiple_insert: bool = False
    ) -> Optional[Union[tuple, List[tuple], None]]:
        if multiple_insert and not isinstance(params, list):
            raise TypeError("For multiple_insert, params must be a list of dictionaries.")
        if not multiple_insert and not isinstance(params, dict):
            raise TypeError("For single insert, params must be a dictionary.")

        logger.info("Executing query: %s with params: %s", self.sql, params if not multiple_insert else f"List of {len(params)} items")
        self._validate_params(params[0] if multiple_insert else params)

        self.conn = get_connection_pool()
        if self.conn and not await self._is_connection_healthy():
            logger.warning("Database connection is unhealthy. Reinitializing connection pool.")
            await initialize_connection_pool()
            self.conn = get_connection_pool()

        return await execute_document_query(self.conn, self.sql, params, fetch, multiple_insert)


async def save_document_record(document: dict) -> bool:
    """Save document record to PostgreSQL database."""

    query = insert_document_query()
    params = query.build_params(document)

    try:
        await query.execute(params)
        logger.info("Document record saved successfully.")
        return True
    except Exception as e:
        logger.error(f"Failed to save document record: {e}", exc_info=True)
        raise

async def get_document_record(file_id: str, keyonlineuser: int) -> Optional[Dict[str, Any]]:
    """Retrieve a file record from the database."""
    try:
        query = fetch_single_document_query()
        params = query.build_params({"file_id": file_id, "keyonlineuser": keyonlineuser})

        # id, file_name, s3_uri, keyonlineuser, section_title, file_size, file_type, job_id, status
        row = await query.execute(params, "one")
        if row:
            return {
                "id": row[0],
                "file_name": row[1],
                "s3_uri": row[2],
                "keyonlineuser": row[3],
                "section_title": row[4],
                "file_size": row[5],
                "file_type": row[6],
                "job_id": row[7],
                "status": row[8]
            }

    except Exception as e:
        logger.error(f"Failed to retrieve file record: {e}", exc_info=True)
        raise

async def update_document_record(file_id: str, section_title: list) -> bool:
    """Update the section_title of a file record in the database."""
    try:
        query = update_section_title_query()
        params = query.build_params({'section_title': json.dumps(section_title), 'file_id': str(file_id)})

        await query.execute(params)

        logger.info("Document record updated successfully.")
        return True
    except Exception as e:
        logger.error(f"Failed to update document record: {e}", exc_info=True)
        raise

async def update_document_status(file_id: str, status: str) -> bool:
    """Update the status of a file record in the database."""
    try:
        query = _update_status_query()
        params = query.build_params({'status': status, 'file_id': str(file_id)})

        await query.execute(params)

        logger.info("Document record updated successfully.")
        return True
    except Exception as e:
        logger.error(f"Failed to update document record: {e}", exc_info=True)
        raise

async def list_document_records(keyonlineuser: int, job_id: str) -> List[Dict[str, Any]]:
    """List document records for a specific user."""
    try:
        query = list_documents_query()
        params = query.build_params({
            'keyonlineuser': keyonlineuser,
            'job_id': job_id
        })

        rows = await query.execute(params, "all")
        documents = []
        for row in rows:
            documents.append({
                "file_id": str(row[0]),
                "file_name": row[1],
                "section_title": json.loads(row[4]),
            })

        logger.info("Document records listed successfully.")
        return documents
    except Exception as e:
        logger.error(f"Failed to list document records: {e}", exc_info=True)
        raise

async def get_template_metadata(filename: str):
    """Retrieve a file record from the database."""
    try:
        query = get_template_metadata_query()
        params = query.build_params({'filename': filename})

        result = await query.execute(params, "all")

        logger.info("template metadata fetched successfully.")

        return result
    except Exception as e:
        logger.error(f"Failed to update document record: {e}", exc_info=True)
        raise

def insert_document_query() -> Query:
    query: LiteralString = """
        INSERT INTO product.documents (
            id, file_name, s3_uri, keyonlineuser, section_title, file_size, file_type, job_id, status
        ) VALUES (
            %(id)s, %(file_name)s, %(s3_uri)s, %(keyonlineuser)s, %(section_title)s,
            %(file_size)s, %(file_type)s, %(job_id)s, %(status)s
        )
    """

    schema = {
        "id": str,
        "file_name": str,
        "s3_uri": str,
        "keyonlineuser": int,
        "section_title": str,
        "file_size": int,
        "file_type": str,
        "job_id": str,
        "status": str,
    }
    
    return Query(query, schema)

def list_documents_query() -> Query:
    query: LiteralString = """
        SELECT id, file_name, s3_uri, keyonlineuser, section_title, file_size, file_type, job_id
        FROM product.documents
        WHERE keyonlineuser = %(keyonlineuser)s AND job_id = %(job_id)s AND status = 'completed'
        ORDER BY created_at DESC
    """

    schema = {
        "keyonlineuser": int,
        "job_id": str,
    }

    return Query(query, schema)

def fetch_single_document_query() -> Query:
    query: LiteralString = """
        SELECT id, file_name, s3_uri, keyonlineuser, section_title, file_size, file_type, job_id, status
        FROM product.documents
        WHERE id = %(file_id)s AND keyonlineuser = %(keyonlineuser)s
    """

    schema = {
        "file_id": str,
        "keyonlineuser": int,
    }

    return Query(query, schema)

def fetch_multiple_document_query() -> Query:
    query: LiteralString = """
        SELECT id, file_name, s3_uri, keyonlineuser, section_title, file_size, file_type, job_id
        FROM product.documents
        WHERE id = ANY(%(file_id)s) AND keyonlineuser = %(keyonlineuser)s
    """

    schema = {
        "file_id": list,
        "keyonlineuser": int,
    }

    return Query(query, schema)

def update_section_title_query() -> Query:
    query: LiteralString = """
        UPDATE product.documents
        SET section_title = %(section_title)s, updated_at = NOW()
        WHERE id = %(file_id)s
    """

    schema = {
        "file_id": str,
        "section_title": str,
    }

    return Query(query, schema)

def _update_status_query() -> Query:
    query: LiteralString = """
        UPDATE product.documents
        SET status = %(status)s, updated_at = NOW()
        WHERE id = %(file_id)s
    """

    schema = {
        "file_id": str,
        "status": str,
    }

    return Query(query, schema)

def get_template_metadata_query() -> Query:
    query: LiteralString = """
        SELECT * FROM product.templates_meta_data
        WHERE excelfilename = %(filename)s
    """

    schema = {
        "filename": str,
    }

    return Query(query, schema)

async def execute_document_query(
    conn: Union[AsyncConnectionPool, psycopg.Connection],
    query: Union[LiteralString, sql.Composed],
    params: Union[dict, list[dict]],
    fetch: Optional[Literal["one", "all"]] = None,
    multiple_insert: bool = False,
):
    if isinstance(conn, AsyncConnectionPool):
        async with conn.connection() as aconn:
            async with aconn.cursor() as cur:
                if multiple_insert:
                    await cur.executemany(query, params)
                else:
                    await cur.execute(query, params)

                if fetch == 'one':
                    return await cur.fetchone()
                elif fetch == 'all':
                    return await cur.fetchall()
                return None

    elif isinstance(conn, psycopg.Connection):
        with conn.cursor() as cur:
            if multiple_insert:
                cur.executemany(query, params)
            else:
                cur.execute(query, params)
            if fetch == 'one':
                return cur.fetchone()
            elif fetch == 'all':
                return cur.fetchall()
            return None
    else:
        raise TypeError("Unsupported connection type")