import contextlib
import logging
from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone

import httpx
from fastapi import FastAPI, APIRouter
from fastapi import Request
from mcp.server.fastmcp import FastMCP, Context

from src.synthia.config.api_config import get_config
from src.synthia.tools.mcp_responses import CompanyNewsResponse, MCPResponse, NewsArticleItem
from src.synthia.utils.logging_config import configure_logging
from . import auth
from .mcp_utils import get_mcp_tool_source

# Configure logging
logger = configure_logging(logger_name=__name__, log_file='company_news.log')

mcp: FastMCP = FastMCP("Company News MCP", stateless_http=True)

logger.info("News MCP Server starting up...")
router = APIRouter()

# Create a single AsyncClient instance for reuse (performance optimization for Lambda)
async_client: httpx.AsyncClient = None


# @mcp.tool()
async def get_company_news(keyInstn: int, startDate: str = None, endDate: str = None) -> MCPResponse:
    """
    Fetch Instn news articles for a given Inst ID/KeyInstn/MI Key (keyInstn) and date range.

    Args:
        keyInstn (int): The Inst ID to get news for also called as Instn ID, MI Key, KeyInstn.
        startDate (str, optional): Start date in 'YYYY-MM-DD' format. Defaults to 6 months ago.
        endDate (str, optional): End date in 'YYYY-MM-DD' format. Defaults to today.

    Returns:
        MCPResponse: A data containing news articles for the given company and date range.
            source (Source): Information about the data source, including title and link.
            data (CompanyNewsResponse): The news articles data.
                newsArticle (List[NewsArticleItem]): The list of news articles.
                    headline (str): The headline of the news article.
                    published (datetime): The published date of the news article.
                    abstract (str): The abstract of the news article.
                    key (int): The unique key identifier for the news article which can be append to the base_article_url.
                base_article_url (str): The base URL for the news articles.
            isError (bool): Flag indicating if the response is an error.
            message (str): Optional message providing additional information about the response or error.

        Each news article will have a 'key' field. To view the full article, append the key to: base_article_url
    """
    logger.info(f"get_company_news called for: {keyInstn}, startDate: {startDate}, endDate: {endDate}")

    # Set default dates if not provided
    today = datetime.now(timezone.utc).date()
    default_start = today - timedelta(days=30)
    start_dt = datetime.strptime(startDate, "%Y-%m-%d") if startDate else default_start
    end_dt = datetime.strptime(endDate, "%Y-%m-%d") if endDate else today

    startDate = start_dt.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
    endDate = end_dt.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"

    payload = {
        "extensions": {
            "persistedQuery": {
                "version": 1,
                "sha256Hash": "9bc18c64ff18a1cba69d125508e57d7e7c90f3fc59cda0063f55aac1253b9191"
            }
        },
        "variables": {
            "category": "COMPANY_NEWS",
            "filter": {
                "source": "0",
                "primaryCompany": True,
                "instns": [keyInstn],
                "startDate": startDate,
                "endDate": endDate
            }
        }
    }

    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    headers = {
        "Content-Type": "application/json",
        **auth.build_auth_headers(raw_request)
    }
    logger.info(f"get_company_news payload: {payload}")

    # Get configuration
    cfg = get_config()
    NEWS_URL = cfg["capitaliq_graphql_url"]
    base_article_url = cfg["news_article_url"]
    core_url = cfg["core_url"]

    try:
        global async_client
        response = await async_client.post(NEWS_URL, headers=headers, json=payload)
        source = await get_mcp_tool_source(
            mcp_tool_name=get_company_news.__name__,
            source_url=f'{core_url}news/briefingbook?id={keyInstn}',
            institution_id=str(keyInstn),
            headers=auth.build_auth_headers(raw_request),
            default_title="Company News",
        )
        if response.status_code == 200:
            news_data = response.json()
            articles_data = news_data.get("data", {})
            articles = articles_data.get("newsArticles", [])
            processed_news = [
                NewsArticleItem(
                    **{k: v for k, v in article.items() if k in ['headline', 'published', 'abstract', 'key']})
                for article in articles
            ]
            logger.info(f"Final News data records : {len(processed_news)}")
            result = CompanyNewsResponse(newsArticle=processed_news, base_article_url=base_article_url)
            return MCPResponse(
                sources=source,
                data=result,
                isError=False,
                message=None
            )
        elif response.status_code == 204:
            logger.info(f"No news data found for the given company : {keyInstn} from {startDate} to {endDate}")
            return MCPResponse(
                sources=source,
                data=None,
                isError=False,
                message="No news data found for the given company."
            )
        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return MCPResponse(
                sources=source,
                data=None,
                isError=True,
                message=f"{response.status_code} - {response.text}"
            )
    except Exception as e:
        logger.error(f"Request failed: {e}")
        return MCPResponse(
            sources=source,
            data=None,
            isError=True,
            message=f"Request failed: {e}"
        )


# Define a custom lifespan for FastAPI with a task to manage MCP

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Initializing MCP server task group...")
    global async_client
    async_client = httpx.AsyncClient(timeout=10)
    async with contextlib.AsyncExitStack() as stack:
        await stack.enter_async_context(mcp.session_manager.run())
        yield
    await async_client.aclose()


@router.get("/company-news/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "ok"}


# Create FastAPI app with lifespan
app = FastAPI(lifespan=lifespan)
app.mount("/company-news", mcp.streamable_http_app())
app.include_router(router)
