import logging
import threading
import time
from contextvars import ContextVar
from dataclasses import dataclass

from requests import Session

from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.patterns import RDSingleton

logger = logging.getLogger(__name__)


@dataclass
class ServiceToken:
    """Class for storing the service token and all the related information"""

    value: str
    token_duration: int
    TTL: int

    def __init__(self, token, duration=7000):
        current_time = int(time.time())
        self.value = token
        self.token_duration = int(duration)
        self.TTL = current_time + self.token_duration

    def is_valid_token(self) -> bool:
        return int(time.time()) < self.TTL

    def is_expiring_soon(self, buffer_sec=300) -> bool:
        return int(time.time()) > (self.TTL - buffer_sec)


def retry(timeout_ms, max_attempt=3):
    """Decorator factory for retrying a given function when failed (Exception raised)"""

    def decorator(func):
        def wrapper(*args, **kwargs):
            attempt = 1
            while True:
                try:
                    return func(*args, **kwargs)
                except Exception as err:
                    if attempt < max_attempt:
                        logger.warning(f"{func.__name__} failed. Attempt {attempt}. Error: {err}")
                        attempt += 1
                        time.sleep(timeout_ms / 1000)
                    else:
                        logger.error(f"{func.__name__} failed {attempt} times. Error: {err}")
                        raise err

        return wrapper

    return decorator


class AuthAPI(metaclass=RDSingleton):
    """Provides automatic background-refreshing service token authentication."""

    def __init__(self, api_name: str, api_ctx: ContextVar, auth_url_slug: str = None):
        self.name = api_name
        self._api_ctx = api_ctx
        self.config_machinery = get_config_machinery()

        ctx_dict = self._api_ctx.get()
        self._env = ctx_dict.get("api_env")
        self._token_duration = ctx_dict.get("token_duration")

        base_url = self.get_config(Constants.APIServiceURL.BASE_URL)
        if not auth_url_slug:
            auth_url_slug = self.get_config(Constants.APIServiceURL.AUTH_URL_SLUG)
        self._auth_url = base_url + auth_url_slug
        logger.info(f"Authentication URL for {self.name} on {self._env.upper()} is set to: {self._auth_url}")

        self._service_token: ServiceToken | None = None
        self._lock = threading.Lock()
        self._stop_event = threading.Event()
        self.__token_counter = 0

        self._refresh_token()  # Initial fetch
        self._refresh_thread = threading.Thread(target=self._refresh_loop, daemon=True)
        self._refresh_thread.start()

    def shutdown(self):
        """Stop background token refresher thread gracefully"""
        self._stop_event.set()
        self._refresh_thread.join()

    def get_config(self, config_key: str) -> str:
        return self.config_machinery.get_config_value(config_key)

    def get_service_token(self) -> str:
        with self._lock:
            if self._service_token and self._service_token.is_valid_token():
                return self._service_token.value
            else:
                return self._refresh_token()

    def _refresh_loop(self):
        """Background thread to refresh token 5 minutes before it expires"""
        while not self._stop_event.is_set():
            with self._lock:
                ttl = self._service_token.TTL if self._service_token else int(time.time()) + 60

            sleep_duration = ttl - int(time.time()) - 300

            if sleep_duration <= 0:
                logger.info(f"[{self.name}] TTL within 5 min. Refreshing token immediately.")
                with self._lock:
                    self._refresh_token()
                    # After refresh, TTL is reset
                    sleep_duration = self._service_token.TTL - int(time.time()) - 300

                logger.info(f"[{self.name}] Sleeping for {sleep_duration} seconds after refresh.")
                if self._stop_event.wait(timeout=sleep_duration):
                    break
                continue

            logger.info(f"[{self.name}] Sleeping for {sleep_duration} seconds until token refresh.")
            if self._stop_event.wait(timeout=sleep_duration):
                break

    def _refresh_token(self) -> str:
        try:
            token = self._fetch_auth_token()
            if not token:
                raise ValueError("Missing authentication token.")

            self.__token_counter += 1
            logger.info(f"New token generated for {self.name}. Count: {self.__token_counter}")
            self._service_token = ServiceToken(token, self._token_duration)
            return self._service_token.value
        except Exception as err:
            logger.error(f"Token generation error for {self.name}: {err}")
            self._service_token = None
            raise

    @retry(timeout_ms=1000)
    def _fetch_auth_token(self) -> str:
        """Fetch token from authentication service"""
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        ctx_dict = self._api_ctx.get()
        user_name = ctx_dict["service_username"]
        password = ctx_dict["service_password"]
        payload = f"username={user_name}&password={password}&scope=https%3A%2F%2Fwww.snl.com&grant_type=password"

        with Session() as session:
            token_response = session.post(self._auth_url, headers=headers, data=payload)
            if token_response.status_code == 200:
                logger.info(f"Token successfully fetched for {self.name}")
                response_data = token_response.json()
                return "Bearer " + response_data["access_token"]
            else:
                logger.warning(f"Token fetch failed for {self.name}: {token_response.status_code}")
                token_response.raise_for_status()
