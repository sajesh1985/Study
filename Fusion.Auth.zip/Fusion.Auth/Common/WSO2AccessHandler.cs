﻿﻿// Copyright Notice! 
// This document is protected under the trade secret and copyright 
// laws as the property of Fidelity National Information Services, Inc. 
// Copying, reproduction or distribution should be limited and only to 
// employees with a “need to know” to do their job. 
// Any disclosure of this document to third parties is strictly prohibited.
// © 2018 Fidelity National Information Services.
// All rights reserved worldwide.

namespace Fis.Epp.Fusion.Auth
{
    using Newtonsoft.Json;
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Net.Http.Headers;
    using System.Threading.Tasks;
    using Fis.Epp.Fusion.Auth.Models;
    using Fis.Epp.Fusion.Auth.Common;

    /// <summary>Represents handler class to interact with WS02 to get access token.</summary>
    public class WSO2AccessHandler : AccessHandlerBase
    {
        #region Ctor

        public WSO2AccessHandler(AppConfiguration appConfiguration) : base(appConfiguration)
        {
        }

        #endregion

        #region Get Access Token

        /// <summary>Call to WSO2 codeconnect to fetch access token.</summary>
        /// <returns>Returns access token.</returns>
        public async Task<WSO2TokenModel> GetAccessToken()
        {
            string baseUrl = AppConfiguration.CodeConnectApis.Endpoints.GetToken;

            var formVars = new Dictionary<string, string>
                {
                    { "grant_type", "client_credentials" },
                    { "validity_period", AppConfiguration.CodeConnectApis.TokenValidityPeriod.ToString() }
                };

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, baseUrl);
            request.Headers.Add(RequestHeader.Authorization.GetEnumDescription(), AppConfiguration.CodeConnectApis.AuthorizationCode);

            request.Content = new FormUrlEncodedContent(formVars);
            request.Content.Headers.ContentType = new MediaTypeHeaderValue("application/x-www-form-urlencoded");

            var response = await InvokeService(request);
            response.EnsureSuccessStatusCode();

            var stringResult = await response.Content.ReadAsStringAsync();
            WSO2TokenModel wSO2Token = JsonConvert.DeserializeObject<WSO2TokenModel>(stringResult);
            return wSO2Token;
        }

        #endregion

        #region Revoke Access Token

        /// <summary>Call to WSO2 codeconnect to revoke access token.</summary>
        /// <returns>Returns success or failure.</returns>
        public async Task<bool> RevokeAccessToken(string token)
        {
            bool isTokenRevoked = false;

            string baseUrl = AppConfiguration.CodeConnectApis.Endpoints.RevokeToken;

            var formVars = new Dictionary<string, string>
                {
                    { "token", token }
                };

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, baseUrl);
            request.Headers.Add(RequestHeader.Authorization.GetEnumDescription(), AppConfiguration.CodeConnectApis.AuthorizationCode);
            request.Content = new FormUrlEncodedContent(formVars);
            request.Content.Headers.ContentType = new MediaTypeHeaderValue("application/x-www-form-urlencoded");

            var response = await InvokeService(request);
            response.EnsureSuccessStatusCode();
            if (response.IsSuccessStatusCode)
                isTokenRevoked = true;
            return isTokenRevoked;
        }

        #endregion
    }
}