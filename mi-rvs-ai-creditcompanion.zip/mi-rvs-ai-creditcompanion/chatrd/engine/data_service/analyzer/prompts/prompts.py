from datetime import date, datetime
from enum import Enum
from typing import List, Optional

from dateutil.relativedelta import relativedelta
from pydantic import BaseModel, Field

from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.data_service.analyzer.utils import format_response
from chatrd.engine.data_service.model_output_parser.variables import (
    GLOBAL_CREDIT_RATING_MAPPING,
    SYNONYMS_CREDIT_RATING_MAPPING,
)
from chatrd.engine.data_service.perspectives import Perspective

config_machinery = get_config_machinery()
DEBT_TYPE_CSV_DATA = config_machinery.get_config_value(Constants.DataService.DEBT_TYPE_CSV_DATA)
RATING_TYPE_CSV_DATA = config_machinery.get_config_value(Constants.DataService.RATING_TYPE_CSV_DATA)

# --------------
# RATING ACTION
# --------------


class MoveDirection_type(Enum):
    RATING_CHANGE_DOWNGRADE = "downgrade"
    RATING_CHANGE_UPGRADE = "upgrade"
    RATING_CHANGE_UNSPECIFIED = None


class TableFiltersRatingActionValues(BaseModel):
    MoveDirection: Optional[MoveDirection_type] = Field(
        default=None,
        description="Does the question pertain to rating downgrade, upgrade, or the question doesn't specify it.",
    )


EXAMPLES_QUESTIONS_RATING_CHANGE = [
    ["What is the latest action rationale for XYZ?", None],
    ["Show me latest downgrade of XYZ?", "downgrade"],
    ["What was the most recent upgrade of XYZ's rating?", "upgrade"],
    ["When was the last time XYZ's rating improved?", "upgrade"],
    ["When did Ford's rating last deteriorated and what was the rationale?", "downgrade"],
    ["When was the last rating change?", None],
]

EXAMPLES_QUESTIONS_RATING_CHANGE_FORMATTED = "\n\n________\n\n".join(
    [
        f"""Question: {question} \nOutput: {format_response("MoveDirection", response)}"""
        for question, response in EXAMPLES_QUESTIONS_RATING_CHANGE
    ]
)


RATING_ACTION_OUTPUT_PARSER_TEMPLATE = (
    """
You are a financial advisor, trained to respond to questions about changes in risk ratings of financial debt instruments, such as securities.

<instructions>
Your goal is to retrieve information about question subject pertaining to rating move direction:
    - rating upgrade, when credit rating improves or gets better
    - rating downgrade, when credit rating drops down or deteriorates
    - None, when change direction is not specified, or the question pertains to all recent rating changes, actions or updates 
</instructions>

<formatting>
This information is to be output only when mentioned in the question. Format the output following these guidelines:

<format_guidelines>
{format_instructions}
</format_guidelines>

You MUST follow these rules:
    - Do not add anything other than the defined JSON schema
    - Do not say, this is the JSON output I requested
    - Do not justify your answer
    - Provide only the JSON
    - Follow closely the formatting instructions
    - Do not add other categories, than defined in format_guidelines
    - When move direction is not specified, or the question pertains to all rating changes or action, output None
    - When move direction is specified, return only two acceptable categories: downgrade or upgrade
</formatting>

Follow these examples, format them according to the format_guidelines
<examples>"""
    + f"""
{EXAMPLES_QUESTIONS_RATING_CHANGE_FORMATTED}
"""
    + """
</examples>

Apply these instructions to this question
{question}
"""
)

# -------------------
# ANALYST-SECTOR INFO
# -------------------

ANALYST_SECTOR_PROMPT = """
You are a classification model. Your task is to classify the following user question into one of two categories:
'analyst_sector' or 'sector_information'. Please respond with only the category name, without any additional comments.
If the question does not fit either category, respond with 'unrelated'.


Here are some examples to guide your classification:

"Question[1]:Who is the rating analyst for tesla?"
"Answer[1]": analyst_sector
"Question[2]:Give me the contacts for the analyst for xyz"
"Answer[2]": analyst_sector
"Question[3]:Who is the primary analyst of Apple"
"Answer[3]": analyst_sector
"Question[4]:Provide me all contacts of IBM's"
"Answer[4]": analyst_sector
"Question[5]:How many analysts does XYZ company has?"
"Answer[5]": analyst_sector
"Question[6]:Show me Anlayst coverage for Amazon and Google"
"Answer[6]": analyst_sector
"Question[7]:Provide me the contacts for the analyst for P&G"
"Answer[7]": analyst_sector
"Question[8]:What sector is UBER related to?"
"Answer[8]": sector_information
"Question[9]:Show me sectors for AARP"
"Answer[9]": sector_information
"Question[10]:Which industry does XYZ belong to?"
"Answer[10]": sector_information
"Question[11]:What's the headquarter is located for XYZ?"
"Answer[11]": sector_information
"Question[12]:Where is XYZ located?"
"Answer[12]": sector_information
"Question[13]:Show me sectors of Apple, Bank of America, City of New York"
"Answer[13]": sector_information
"Question[14]:What sub-sector does the XYZ company belong to?"
"Answer[14]": sector_information
"Question[15]:In which region does the XYZ company operate?"
"Answer[15]": sector_information
"Question[16]:In which country does the P&G company operate?"
"Answer[16]": sector_information
"Question[17]:Which NACE applies to the XYZ company?"
"Answer[17]": sector_information
"Question[18]:Which NAICS applies to the XYZ company?"
"Answer[18]": sector_information
"Question[19]:What is the rating for Apple?"
"Answer[19]": unrelated
"Question[20]:Give me the companies in technology sector"
"Answer[20]": unrelated

Now, classify the following user question:
USER QUESTION:"""

# -------
# SORTING
# -------


ORDER_PROMPT = """
Your task is to identify specific details from user inquiries and creating a dictionary with two keys: 'order' and 'limit'.
Do not include any other information in the output, or any additional text.
You must focus on keywords that indicate the type of information requested. 
Look for terms such as 'top x,' 'last x,' 'latest,' or 'most recent,' which suggest a 'descending' order for the information. 
If the question does not clearly specify an order, return 'None' for the order.
Similarly, if the question specifies a limit, like 'top n', 'latest n', or 'first n', extract that number 'n' as 'limit.'
If no limit is specified, return 'None' for the limit.

Below are some example questions along with their respective answers:

"Question[1]: What is the most recent corporate company default?"
"Answer[1]": {"order": "descending", "limit": None}
"Question[2]: What are the top 5 chemical companies that defaulted in 2024?"
"Answer[2]": {"order": "descending", "limit": 5}
"Question[3]: What are the last 20 food retail companies that have been downgraded recently?"
"Answer[3]": {"order": "descending", "limit": 20}
"Question[4]: List the latest 10 corporate companies with recent action changes."
"Answer[4]": {"order": "descending", "limit": 10}
"Question[5]: List entities downgraded in 2024."
"Answer[5]": {"order": None, "limit": None}
"Question[6]: Please provide the newly rated companies in the last 24 months."
"Answer[6]": {"order": None, "limit": None}
"Question[7]: Show me tech companies with a BB+ rating."
"Answer[7]": {"order": None, "limit": None}
"Question[8]: Give me a list of downgraded healthcare companies in Europe."
"Answer[8]": {"order": None, "limit": None}
"Question[9]: Show me the first 5 companies that have been upgraded in 2025."
"Answer[9]": {"order": "ascending", "limit": 5}

USER QUESTION:"""

# -------
# RATINGS
# -------


class CurrentOrHistoricalRatingType(Enum):
    RATINGS_CURRENT = "current"
    RATINGS_HISTORICAL = "historical"
    RATINGS_UNSPECIFIED = None


class RatingsQuestionFilters(BaseModel):
    CurrentOrHistoricalRating: Optional[CurrentOrHistoricalRatingType] = Field(
        default="current",
        description="Does the question pertain to recent or historical rating, or was it unspecified?",
    )


def examples_ratings_current_or_historical_formatted(current_year):
    """
    Generate formatted example questions and outputs for current or historical ratings.
    Args:
        current_year (int): The current year to be used in one of the example questions.
    Returns:
        str: A formatted string containing example questions and their corresponding outputs,
            separated by divider lines.
    """
    examples_list = [
        ["Show me IBM's rating history", "historical"],
        ["Show me all ratings for IBM", "current"],
        ["What is the credit rating history for apple?", "historical"],
        ["Show me ratings for apple from last year?", "historical"],
        ["Show me ratings for Tesla from last 3 years?", "historical"],
        ["What was IBM's rating in 2020?", "historical"],
        ["What is apple's rating?", "current"],
        ["Can you outline the rating changes for XYZ over the years and its current outlook?", "historical"],
        ["Show me current rating of Tesla Inc.", "current"],
        [f"""Show me Ford's rating from {current_year}?""", "current"],
        ["Show me the entire rating history of Adient plc", "historical"],
        ["Show me list of ratings for XYZ", "current"],
    ]
    examples_list_formatted = "\n\n________\n\n".join(
        [
            f"""Question: {question} \nOutput: {format_response("CurrentOrHistoricalRating", response)}"""
            for question, response in examples_list
        ]
    )
    return examples_list_formatted


RATINGS_CURRENT_OR_HISTORICAL_OUTPUT_PARSER_TEMPLATE = """
You are a financial advisor, trained to respond to questions about company credit ratings.

<instructions>
Your goal is to classify the provided query into two types.  You are provided the current calendar year which is {current_year}:
    - historical ratings, when the question is related to historical ratings, or refers to past or prior years, or trends, or changes in ratings, outlook or creditwatch
    - current ratings, when the question pertains to the current (or future) rating, outlook or creditwatch, or the current calendar year {current_year}
    - None, when it is not specified
</instructions>

<formatting>
This information is to be output only when mentioned in the question. Format the output following these guidelines:

<format_guidelines>
{format_instructions}
</format_guidelines>

You MUST follow these rules:
    - Do not add anything other than the defined JSON schema
    - Do not say, this is the JSON output I requested
    - Do not justify your answer
    - Provide only the JSON
    - Follow closely the formatting instructions
    - Do not add other categories, than defined in format_guidelines
    - Return only specified categories: historical, current or None
</formatting>

Follow these examples, format them according to the format_guidelines
<examples>
{examples_ratings_current_or_historical_formatted}
</examples>

Apply these instructions to this question
{question}
"""


# -------
# QUERY
# -------

# -------
# RATINGS
# -------

DEFAULT_PROMPT_TEMPLATE = """Perform the following actions:
1 - Classify the question delimited by <>. Only use the following values for question \
type: company, securities, revenue sources and irrelevant. Note that ratings, outlook \
related question should be classified as company. If ticker is mentioned in the question, then the question should \
be classified as company. If revenue source is mentioned in the question, then the question should be classified as \
revenue sources. Use 'irrelevant' if the query is \
not related to company, securities and revenue sources topics. \
2 - For any ratings based filtering question, use Foreign Currency LT rating for filtering unless the question specifically says otherwise. \
3 - For any industry or sector based filtering use RD Sector for the industry or sector filter. \
4 - Find key elements in the following JSON format. All the values must be string \
inside the JSON: {{"type": "question type", "key element": {{"value": "value(s)", \
"connector": "connector", "operator": "operator"}},}} \
5 - Only provide response in JSON format.
6- Handling Questions Involving Sequential Credit Ratings - If a question contains terms like \
"greater," "lower," "higher," "better," "worse," "above," or "below" in the context of credit ratings, \
use the following ordered list of credit ratings to determine their relative ranking:
CREDIT RATINGS: {credit_ratings} \
Your task is to: Extract all credit ratings mentioned in the question. Arrange them in the correct order \
based on their relative positions in the provided list. Ensure the returned ratings reflect the intended \
order implied by the question (e.g., ascending or descending).  Always rely on the CREDIT RATINGS \
list to establish the correct hierarchy between ratings. \
7- Here is the full list of synonyms for Credit Rating Scores. \
If the user question contains these similar expressions, you should determine your credit score according to the value in this list.
Credit Ratings Synonyms: {synonyms_credit_ratings} \
8- Handling Questions Involving Top-Rated vs. Top-N Entities: You must pay attention \
to the difference between 'top-rated' and 'top n' questions for accurate rating selection. \
If a question specifies 'top n' (e.g., top 5 companies), use the following logic for credit rating selection: 'credit rating': \
{{ 'value': 'r, sd, d, nr', 'connector': 'and', 'operator': 'not equal' }}. If the question mentions 'top-rated' \
(e.g., top-rated financial entities), apply the credit ratings from AAA to BBB- as follows: 'credit rating': \
{{ 'value': 'aaa, aa+, aa, aa-, a+, a, a-, bbb+, bbb, bbb-', 'connector': 'and', 'operator': 'in' }}. For questions \
specifically asking for a particular credit rating score (e.g., 'give me bb rated companies'), the dictionary should \
be: 'credit rating': {{ 'value': 'bb', 'connector': 'and', 'operator': 'in' }}. Additionally, if the user requests an \
ordered list (e.g., 'give me top 10 rated companies'), the credit rating should again be 'r, sd, d, nr': 'credit rating': \
{{ 'value': 'r, sd, d, nr', 'connector': 'and', 'operator': 'not equal' }}.

{examples}

Only use the following values for operator:
{operators}
Only use the following values for connector:
{connectors}

<"{input}"> ->
"""

MINIMAL_PROMPT_TEMPLATE = """{examples}
{operators}
{connectors}
{input}"""

DEFAULT_OPERATORS = [
    "equal",
    "not equal",
    "less than",
    "greater than",
    "begin with",
    "less than or equal",
    "greater than or equal",
    "in",
    "not in",
    "includes",
    "not includes",
    "contains",
    "is",
    "between",
    "not begin with",
    "is null",
    "is not null",
    "is na",
    "not na",
    "from",
    "exists",
    "exclude from",
    "not between",
    "not contains",
    "not exists",
    "top n order by ascending",
    "top n order by descending",
]

DEFAULT_CONNECTORS = ["or", "and"]


PROMPT_SECURITIES = f"""
You are a financial analyst specializing in credit ratings. Here are core guidelines before we proceed with describing your task.

**Core Guidelines**:
- Do not assume dates for "today" or "now", get the system date for current date.
- Do not assume random debt type or rating types. Be very precise in looking for these in the user question and match them in appropriate csv data to extract the corresponding codes.
- Analyze step by step and provide justification and your thought process.
- Populate each component (will describe later) *only* if the input contains relevant info.
- Finish with your final formatted string. Enclose the formatted string within "****" marker (4 stars at either ends).
- There should exactly be 2 pipes (|) inside the 4-star marker.
- The framework and examples below are sacrosanct.  You CANNOT deviate from those.

Based on the user's input, your task is to return a single string with three components separated by pipe characters (|), formatted as follows:

    "<debt type code(s)>|<rating type code(s)>|<start_date>-<end_date>"

- If any of these fields are missing in the user input, leave the corresponding component empty. Given in the framework below.
**Framework**
    - If no maturity is mentioned: "<debt type code(s)>|<rating type code(s)>|"
    - If no debt type is mentioned: "|<rating type code(s)>|<date range>"
    - If no rating type is mentioned: "<debt type code(s)>||<date range>"
    - If only maturity is present: "||<date range>"
    - If only debt type is present: "<debt type code(s)>||"
    - If only rating type is present: "|<rating type code(s)>|"
    - If none of maturity, debt type or rating type mentioned: "||"

**Date Format**: Use `MM/DD/YYYY` for all dates.  
**Maturity Date Handling**:
- If a year is mentioned, use 01/01/<year> to 12/31/<year>.
- If the user references a relative time (e.g., “next year”, “last month”), compute it based on the current date.
  Use the logic shown in the examples below.

### Relative Date Logic Examples:
- If today is April 14, 2025:
  - "next month" → 05/01/2025–05/31/2025
- If today is September 27, 2028:
  - "next year" → 01/01/2029–12/31/2029
- If today is March 31, 2026:
  - "last year" → 01/01/2025–12/31/2025
- If today is May 1, 2029:
  - "this month" → 05/01/2029–05/31/2029
- For phrases like "2 years ago" or "2 years from now", apply the same start-to-end logic using Jan 1 to Dec 31.
- Similarly, apply the same logic for months (e.g., "2 months ago", "3 months from now").
    - If current date is in March, two months from now will be 05/01/<year> to 05/31/<year>
    - If current date is in September, 3 months ago will be 06/01/<year> to 06/30/<year>

---

### Matching Codes from Data

**Debt Type Codes:**
- Match keywords from the *description* column (desc) first, then from the *abbreviation* column (abbr).
- If multiple debt types match, separate their codes (value in the first column) with commas.
Provided as CSV (first row is the table heading):  
{DEBT_TYPE_CSV_DATA}

**Rating Type Codes:**
- Match based on the *description* column (desc).
- If multiple rating types match, separate their codes (value in the first column) with commas.
Provided as CSV (first row is the table heading):
{RATING_TYPE_CSV_DATA}

---

**Format Reminder**: Always output exactly two pipe (|) characters, even if some fields are empty.

**Examples**: (XYZ and ABC are placeholder names)

- "Show me list of securities for Federal Home Loan Banks" → ||
- "Show me all securities for XYZ with maturity date in 2035" → ||01/01/2035-12/31/2035
- "List of securities for ABC with Senior Unsecured Debt Type" → 14||
- "Show me all rated securities for XYZ" → ||
- "List of all rated securities for ABC" -> ||
- "Show me all securities for ABC" → ||
- "What are active securities for XYZ" → ||
- "List of securities for ABC with Foreign Currency ST Rating Type and Local Currency LT Rating Type" → |FCSHORT,STDLONG|
- "List of securities for XYZ with Foreign Currency Preliminary LT Rating Type and Preference Stock and Preferred Stock debt types" → 8,10|PRLMFCLNG|
- "XYZ securities Foreign Currency LT and maturing in the year 2030" → |FCLONG|01/01/2030-12/31/2030
- "List of securities for AT&T" → ||

Now, use all the above logic and examples to process this user question:
"""


def prompt_from_perspectives(
    perspectives: List[Perspective],
    user_input: str,
    prompt_template: Optional[str] = None,
) -> str:
    """
    Function returns a LLM prompt given list of perspectives as well as optional prompt template:
     - If prompt template is omitted - DEFAULT_PROMPT_TEMPLATE is used
     - For perspectives if operators variable is not set -> DEFAULT_OPERATORS are used
     - For perspectives if connectors variable is not set -> DEFAULT_CONNECTORS are used
     - prompt_template string is either None or a string with the following parameters in it:
       - credit_ratings
       - few_shot_examples
       - operators
       - connectors
    Args:
        perspectives:  list of Perspective object
        user_input: string with user request
        prompt_template: optional template string

    Returns:
        LLM prompt string
    """
    prompt_template = prompt_template or DEFAULT_PROMPT_TEMPLATE
    few_shot_examples = [f"Examples for {p.name}:\n{p.examples_to_few_shot_format()}" for p in perspectives]
    # operators = chain(*[p.operators or DEFAULT_OPERATORS for p in perspectives])
    # connectors = chain(*[p.connectors or DEFAULT_CONNECTORS for p in perspectives])
    # Based on current understanding, there is only one set of operators and connectors
    # for all perspectives. If this changes, we need to update the logic here.
    operators = DEFAULT_OPERATORS
    connectors = DEFAULT_CONNECTORS
    credit_ratings = GLOBAL_CREDIT_RATING_MAPPING
    synonyms_credit_ratings = SYNONYMS_CREDIT_RATING_MAPPING

    return prompt_template.format(
        synonyms_credit_ratings=", ".join(f"{key} ({value})" for key, value in synonyms_credit_ratings.items()),
        credit_ratings=", ".join(credit_ratings),
        examples="\n".join(few_shot_examples),
        operators="\n".join(operators),
        connectors="\n".join(connectors),
        input=user_input,
    )
