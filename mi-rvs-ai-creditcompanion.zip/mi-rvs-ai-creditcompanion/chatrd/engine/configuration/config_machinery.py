import logging
import os
from typing import Optional

import yaml
from yaml.loader import SafeLoader

from chatrd.engine.configuration.config_key import ConfigKey
from chatrd.engine.patterns import RDSingleton

logger = logging.getLogger(__name__)


class ConfigMachinery(metaclass=RDSingleton):
    def __init__(self):
        my_path = os.path.abspath(os.path.dirname(__file__))
        self.base_path = os.path.join(my_path, "configs/")
        self.__load_config_file()

    # priority is given to OS, then file based configuration
    def get_config_value(self, key: ConfigKey, default_value: Optional[any] = None):
        if self._is_os_config_value_exist(key.value):
            return self.__get_os_config_value(key.value)
        return self.__get_file_based_config_value(key.value, default_value)

    def __load_config_file(self):
        # environment_name = self.__get_os_config_value("ENVIRONMENT_NAME", "dev")
        env_file = self.get_environment_config_filepath("local")
        application_file = self.get_environment_config_filepath("application")

        with open(env_file) as f:
            env_dict = yaml.load(f, Loader=SafeLoader)

        with open(application_file) as f:
            application_dict = yaml.load(f, Loader=SafeLoader)

        self.config_dict = self.merge_configs(application_dict, env_dict)

    def merge_configs(self, base_dict, extender_dict):
        if isinstance(base_dict, dict):
            composed_dict = base_dict.copy()
            for k, v in extender_dict.items():
                if k in base_dict:
                    composed_dict[k] = self.merge_configs(base_dict.get(k), v)
                else:
                    composed_dict[k] = v
            return composed_dict
        else:
            return extender_dict

    def get_environment_config_filepath(self, environment_name):
        return self.base_path + environment_name + ".yaml"

    def __get_file_based_config_value(self, key: str, default_value: Optional[any] = None):
        return self.config_dict.get(key, default_value) if self.config_dict else default_value

    def _is_os_config_value_exist(self, key: str):
        return True if key in os.environ else False

    def __get_os_config_value(self, key: str, default_value: Optional[any] = None):
        return os.environ.get(key, default_value)


config_machinery = ConfigMachinery()


def get_config_machinery():
    return config_machinery
