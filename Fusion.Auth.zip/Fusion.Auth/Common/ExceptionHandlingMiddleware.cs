﻿// Copyright Notice! 
// This document is protected under the trade secret and copyright 
// laws as the property of Fidelity National Information Services, Inc. 
// Copying, reproduction or distribution should be limited and only to 
// employees with a “need to know” to do their job. 
// Any disclosure of this document to third parties is strictly prohibited.
// © 2018 Fidelity National Information Services.
// All rights reserved worldwide.

namespace Fis.Epp.Fusion.Auth
{
    using Microsoft.AspNetCore.Http;
    using Newtonsoft.Json;
    using System;
    using System.Net;
    using System.Threading.Tasks;
    using Fis.Epp.Fusion.Auth.Models;

    /// <summary>Represents middleware for exception handler to handle all the exceptions occured in the application.</summary>
    public class ExceptionHandlingMiddleware
    {
        private readonly RequestDelegate next;

        public ExceptionHandlingMiddleware(RequestDelegate next)
        {
            this.next = next;
        }

        public async Task Invoke(HttpContext context)
        {
            try
            {
                await next(context);
            }
            catch (Exception ex)
            {
                await HandleExceptionAsync(context, ex);
            }
        }

        private static Task HandleExceptionAsync(HttpContext context, Exception exception)
        {
            // log the exception
            var headers = context.Request.Headers;

            string feId = string.Empty;
            string userId = string.Empty;
            string correlationId = string.Empty;

            if (!string.IsNullOrEmpty(headers[RequestHeader.FE_ID.GetEnumDescription()]))
            {
                feId = headers[RequestHeader.FE_ID.GetEnumDescription()];
            }

            if (!string.IsNullOrEmpty(headers[RequestHeader.USER_ID.GetEnumDescription()]))
            {
                userId = headers[RequestHeader.USER_ID.GetEnumDescription()];
            }

            if (!string.IsNullOrEmpty(headers[RequestHeader.Correlation_ID.GetEnumDescription().ToUpper()]))
            {
                correlationId = headers[RequestHeader.Correlation_ID.GetEnumDescription().ToUpper()];
            }

            ExceptionLoggerModel errorData = new ExceptionLoggerModel
            {
                FeId = feId,
                UserId = userId,
                ErrorMessage = exception.Message,
                ErrorStack = exception.StackTrace,
                RequestUrl = context.Request.Path,
                CorrelationId = correlationId
            };

            AppDiagnostics.RecordException(errorData);

            // Return error response
            context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
            context.Response.ContentType = "application/json";

            string errorCode = "GENF001"; // Returns custom error codes based on exception type            

            var result = JsonConvert.SerializeObject(new
            {
                type = "APPLICATION_ERROR",
                details = new[] {
                    new
                    {
                        code = errorCode,
                        message = exception.Message
                    }
                }
            });

            return context.Response.WriteAsync(result);
        }
    }
}
