from mcp.server.fastmcp import FastMCP, Context
from fastapi import FastAPI, APIRouter
from fastapi import Request
from fastapi import Depends
import logging
import httpx
from contextlib import asynccontextmanager
import contextlib
#from . import config
from src.synthia.config.api_config import get_config
from . import auth
from src.synthia.utils.logging_config import configure_logging
from src.synthia.utils.source import Source

# Configure logging
configure_logging(log_file='company_industry.log')
logger = logging.getLogger(__name__)

mcp: FastMCP = FastMCP("Company Industry MCP", stateless_http=True)

cfg = get_config()

logger.info("Industry MCP Server starting up...")
capitaliq_base_url = cfg["capitaliq_base_url"]
industry_url_infix = "AIReportBuilder/companyIndustry/"

router = APIRouter()


# Create a single AsyncClient instance for reuse (performance optimization for Lambda)
async_client: httpx.AsyncClient = None


@mcp.tool()
async def get_company_RD_industry(inst_id: str) -> dict:
    """
        Retrieve RD industry classification information for a given company ID.

        Args:
            inst_id (str): The company ID for which to fetch RD industry data.

        Returns:
            dict: {
                sources (str): The URL used to fetch the data.
                data (dict): {
                    sector (Optional[str or List[str]]): RD sector(s) or None.
                    sub_sector (Optional[str or List[str]]): RD sub-sector(s) or None.
                    industry (Optional[str or List[str]]): RD industry/industries or None.
                    is_rd_entity (bool): True if 'RDIndustries' is present, else False.
                }
            }

        Raises:
            requests.exceptions.RequestException: If the HTTP request fails.

        Note:
            The returned data structure is determined by the external API and may vary.

        Examples:
            Amazon.com, Inc. (Single sector and sub-sector)
                {'sector': 'Corporates', 'sub-sector': 'Industrials', 'industry': 'Retailing', 'is_rd_entity': True}

            Bank of America (Multiple sub-sectors)
                {'sector': 'Financial Institutions', 'sub-sector': ['Asset Managers', 'Banks', 'Broker-Dealers', 'Finance Companies', 'Others'], 'industry': None, 'is_rd_entity': True}

            Acadia Healthcare Company, Inc. (Multiple sectors and sub-sectors)
                {'sector': ['Corporates', 'Insurance'], 'sub-sector': ['Industrials', 'Health'], 'industry': 'Health Care', 'is_rd_entity': True}

            UBM Development AG (Non-RD company)
                {'sector': [], 'sub-sector': [], 'industry': [], 'is_rd_entity': False}
    """

    logger.info(f"RD Industry request for inst_id: {inst_id}")

    # Simulate a request to the industry URL
    logger.info(f"get_company_RD_industry called for : {inst_id}")
    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    url = f"{capitaliq_base_url}{industry_url_infix}{inst_id}"
    try:
        global async_client
        response = await async_client.get(url, headers=auth.build_auth_headers(raw_request))
        source = Source(title="Company RD industry classification", url=url)
        if response.status_code == 200:
            industry_data = response.json()
            logger.info(f"Received RD industry data for {inst_id}: {industry_data}")

            sector = []
            sub_sector = []
            industry = []

            is_rd_entity = bool(industry_data.get("RDIndustries"))

            if industry_data.get("RDIndustries"):
                for item in industry_data.get("RDIndustries", []):
                    category = item.get("KeyIndustryCategory")
                    name = item.get("RDIndustryLongName")
                    if category == 0:
                        sector.append(name)
                    elif category == 1:
                        sub_sector.append(name)
                    elif category == 2:
                        industry.append(name)
                if len(sector) == 1:
                    sector = sector[0]
                elif not sector:
                    sector = None
                if len(sub_sector) == 1:
                    sub_sector = sub_sector[0]
                elif not sub_sector:
                    sub_sector = None
                if len(industry) == 1:
                    industry = industry[0]
                elif not industry:
                    industry = None

            result = {
                "sector": sector,
                "sub-sector": sub_sector,
                "industry": industry,
                "is_rd_entity": is_rd_entity
            }

            logger.info(f"Parsed RD industry data for {inst_id}: {result}")
            return {"sources": source, "data": result}

        elif response.status_code == 204:
            logger.info(f"No RD industry data found for {inst_id}.")
            return {"sources": source, "data": {"message": "No RD industry data found for the given company."}}

        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return f"Error: {response.status_code} - {response.text}"

    except httpx.RequestError as e:
        logger.error(f"Request failed: {e}")
        return f"Request failed: {e}"


@mcp.tool()
async def get_company_MI_industry(inst_id: str) -> dict:
    """
        Retrieve MI industry classification information for a given company ID.

        Args:
            inst_id (str): The company ID for which to fetch MI industry data.

        Returns:
            dict: {
                sources (str): The URL used to fetch the data.
                data (dict): {
                    mi_industry (Optional[str or List[str]]): MI industry/industries or None.
                    is_rd_entity (bool): True if 'RDIndustries' is present, else False.
                }
            }

        Raises:
            requests.exceptions.RequestException: If the HTTP request fails.

        Note:
            The returned data structure is determined by the external API and may vary.

        Examples:
            Amazon.com, Inc.
                {'mi-industry': 'Broadline Retail', 'is_rd_entity': True}

            UBM Development AG (Non-RD company)
                {'mi-industry': 'Diversified Real Estate Activities', 'is_rd_entity': False}
    """

    logger.info(f"MI Industry request for inst_id: {inst_id}")

    # Simulate a request to the industry URL
    logger.info(f"get_company_MI_industry called for : {inst_id}")
    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    url = f"{capitaliq_base_url}{industry_url_infix}{inst_id}"
    try:
        global async_client
        response = await async_client.get(url, headers=auth.build_auth_headers(raw_request))
        source = Source(title="Company MI industry classification", url=url)
        if response.status_code == 200:

            industry_data = response.json()
            logger.info(f"Received MI industry data for {inst_id}: {industry_data}")

            industry = []

            is_rd_entity = bool(industry_data.get("RDIndustries"))

            if industry_data.get("MIIndustries"):
                for item in industry_data.get("MIIndustries", []):
                    if item.get("KeyIndustryRelationshipLevel") == 0:
                        industry.append(item.get("MIIndustryLongName"))
                if len(industry) == 1:
                    industry = industry[0]
                elif not industry:
                    industry = None

            result = {
                "mi-industry": industry,
                "is_rd_entity": is_rd_entity
            }

            logger.info(f"Parsed MI industry data for {inst_id}: {result}")
            return {"sources": source, "data": result}

        elif response.status_code == 204:
            logger.info(f"No MI industry data found for {inst_id}.")
            return {"sources": source, "data": {"message": "No MI industry data found for the given company."}}

        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return f"Error: {response.status_code} - {response.text}"

    except httpx.RequestError as e:
        logger.error(f"Request failed: {e}")
        return f"Request failed: {e}"


@mcp.tool()
async def get_company_CIQ_industry(inst_id: str) -> dict:
    """
        Retrieve CIQ industry classification information for a given company ID.

        Args:
            inst_id (str): The company ID for which to fetch CIQ industry data.

        Returns:
            dict: {
                sources (str): The URL used to fetch the data.
                data (dict): {
                    ciq_industry (Optional[str or List[str]]): CIQ industry/industries or None.
                    is_rd_entity (bool): True if 'RDIndustries' is present, else False.
                }
            }

        Raises:
            requests.exceptions.RequestException: If the HTTP request fails.

        Note:
            The returned data structure is determined by the external API and may vary.

        Examples:
            Amazon.com, Inc.
                {'ciq-industry': 'Broadline Retail', 'is_rd_entity': True}

            UBM Development AG (Non-RD company)
                {'ciq-industry': 'Diversified Real Estate Activities', 'is_rd_entity': False}
    """

    logger.info(f"CIQ Industry request for inst_id: {inst_id}")

    # Simulate a request to the industry URL
    logger.info(f"get_company_CIQ_industry called for : {inst_id}")
    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    url = f"{capitaliq_base_url}{industry_url_infix}{inst_id}"
    try:
        global async_client
        response = await async_client.get(url, headers=auth.build_auth_headers(raw_request))
        source = Source(title="Company CIQ industry classification", url=url)
        if response.status_code == 200:

            industry_data = response.json()
            logger.info(f"Received CIQ industry data for {inst_id}: {industry_data}")

            industry = []

            is_rd_entity = bool(industry_data.get("RDIndustries"))

            if industry_data.get("CIQIndustries"):
                for item in industry_data.get("CIQIndustries", []):
                    if item.get("KeyIndustryRelationshipLevel") == 0:
                        industry.append(item.get("CIQIndustryLongName"))
                if len(industry) == 1:
                    industry = industry[0]
                elif not industry:
                    industry = None

            result = {
                "ciq-industry": industry,
                "is_rd_entity": is_rd_entity
            }

            logger.info(f"Parsed CIQ industry data for {inst_id}: {result}")
            return {"sources": source, "data": result}

        elif response.status_code == 204:
            logger.info(f"No CIQ industry data found for {inst_id}.")
            return {"sources": source, "data": {"message": "No CIQ industry data found for the given company."}}

        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return f"Error: {response.status_code} - {response.text}"

    except httpx.RequestError as e:
        logger.error(f"Request failed: {e}")
        return f"Request failed: {e}"


# Define a custom lifespan for FastAPI with a task to manage MCP
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Initialize MCP server task group
    logger.info("Initializing MCP server task group...")
    global async_client
    async_client = httpx.AsyncClient(timeout=10)
    async with contextlib.AsyncExitStack() as stack:
        await stack.enter_async_context(mcp.session_manager.run())
        yield
    # Shutdown: Close the AsyncClient
    await async_client.aclose()


@router.get("/company-industry/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "ok"}


# Create FastAPI app with lifespan
app = FastAPI(lifespan=lifespan)
app.mount("/company-industry", mcp.streamable_http_app())
app.include_router(router)

