import React from 'react';

import { config } from '@spglobal/spa';
import { useUserTraits } from '@spglobal/userprofileservice';

import LandingPageDashboard from '../../components/Landing/dashboard/LandingPageDashboard';
import { FilterBoxProvider } from '@spglobal/react-components';

const FeedbackLandingPage = () => {
  const traits = useUserTraits(['onlineConfigurations']);
  const ChatRD_KOC = 300001585;
  const chatRDEnabled = traits && traits.onlineConfigurations.includes(ChatRD_KOC);
  const isInternalUser = traits.internalUser === true;

  React.useEffect(() => {
    if (!(chatRDEnabled === true && isInternalUser === true)) {
      window.location.href = `${config('onCloudRootPath')}web/client?auth=inherit`;
    }
  }, [chatRDEnabled, isInternalUser]);

  return (
    <>
      <h1>
        <strong>Feedback Report</strong> <span style={{ fontSize: '0.7em' }}>| DASHBOARD</span>
      </h1>
      <br />
      <FilterBoxProvider>
        <LandingPageDashboard />
      </FilterBoxProvider>

    </>
  );
};

export default FeedbackLandingPage;
