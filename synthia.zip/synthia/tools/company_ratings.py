import contextlib
import logging
from contextlib import asynccontextmanager
from datetime import datetime, timedelta

import httpx
from fastapi import FastAPI, APIRouter
from fastapi import Request
from mcp.server.fastmcp import FastMCP, Context

from src.synthia.config.api_config import get_config
from src.synthia.tools.mcp_responses import (
    MCPResponse,
    SpLatestCreditRating,
    SpHistCreditRating,
    MoodyLatestRating,
    FitchLatestRating,
    MoodyHistRating,
    FitchHistRating
)
from src.synthia.utils.logging_config import configure_logging
from . import auth
from .mcp_utils import get_mcp_tool_source

# Configure logging
logger = configure_logging(logger_name=__name__, log_file='company_ratings.log')

mcp: FastMCP = FastMCP("Company Ratings MCP", stateless_http=True)

logger.info("Ratings MCP Server starting up...")

router = APIRouter()

# Create a single AsyncClient instance for reuse (performance optimization for Lambda)
async_client: httpx.AsyncClient = None


@mcp.tool()
async def get_latest_ratings(keyInstn: str) -> MCPResponse:
    """
    Retrieves the current S&P credit ratings and credit watch outlook information for a specified company.
    
    This MCP tool provides access to real-time S&P credit rating data including rating symbols,
    credit watch status, and outlook information for comprehensive credit risk assessment.
    
    Args:
        keyInstn (str): The unique company identifier (institution ID) used to retrieve ratings.
    
    Returns:
        MCPResponse: An MCPResponse object containing the following structure:
            - sources (list[Source]): List containing citation information:
                - title (str): "Company Ratings"
                - url (str): Direct link to the company's ratings history page in S&P Capital IQ Pro
            - data (list[SpLatestCreditRating]): List of current rating records, each containing:
                - RatingDate (str): ISO 8601 formatted date when the rating was assigned
                                   (e.g., "2025-06-12T08:10:16")
                - RatingType (str): Category of the rating:
                                   • "Foreign Currency LT" - Foreign currency long-term rating
                                   • "Local Currency LT" - Local currency long-term rating  
                                   • "Foreign Currency ST" - Foreign currency short-term rating
                                   • "Local Currency ST" - Local currency short-term rating
                - DebtType (str): Type of debt instrument rated (typically "Issuer Credit Rating")
                - RatingSymbol (str): S&P credit rating symbol (e.g., "AA-", "BBB+", "A-1+")
                - CreditWatchOutlook (str): Current credit watch or outlook status:
                                          • "Watch Pos" - CreditWatch Positive
                                          • "Watch Neg" - CreditWatch Negative
                                          • "Stable" - Stable outlook
                                          • "Positive" - Positive outlook
                                          • "Negative" - Negative outlook
                - CreditWatchOutlookDate (str): ISO 8601 formatted date when the credit watch/outlook
                                               was assigned (e.g., "2025-07-10T12:01:06")
                - LastReviewDate (str): ISO 8601 formatted date when the rating was last reviewed
                                       (e.g., "2025-03-15T09:30:00")
            - isError (bool): False for successful requests, True for error conditions
            - message (str|None): Error message if request fails, None for successful requests
    
    Example Response:
        {
            "sources": [{"title": "Company Ratings", "url": "https://..."}],
            "data": [
                {
                    "RatingDate": "2025-06-12T08:10:16",
                    "RatingType": "Foreign Currency LT",
                    "DebtType": "Issuer Credit Rating",
                    "RatingSymbol": "AA-",
                    "CreditWatchOutlook": "Watch Neg",
                    "CreditWatchOutlookDate": "2025-07-10T12:01:06",
                    "LastReviewDate": "2025-03-15T09:30:00"
                }
            ],
            "isError": False,
            "message": None
        }
        
    """
    logger.info(f"Latest rating request for keyInstn: {keyInstn}")

    # Get configuration
    cfg = get_config()
    capitaliq_base_url = cfg["capitaliq_base_url"]
    current_ratings_url_infix = "AIReportBuilder/entityCurrentRating/"
    old_ciqpro_url = cfg["old_ciqpro_url"]
    logger.info(f"get_latest_ratings called for : {keyInstn}")
    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    url = f"{capitaliq_base_url}{current_ratings_url_infix}{keyInstn}"
    global async_client
    try:
        response = await async_client.get(url, headers=auth.build_auth_headers(raw_request))
        source = await get_mcp_tool_source(
            mcp_tool_name=get_latest_ratings.__name__,
            source_url=f"{old_ciqpro_url}#company/ratingsHistory?Id={keyInstn}",
            institution_id=str(keyInstn),
            headers=auth.build_auth_headers(raw_request),
            default_title="Company Ratings",
        )
        logger.info(f"Ratings API response status: {response.status_code}")
        if response.status_code == 200:
            rating_data = response.json()
            logger.info(f"Latest rating data: {len(rating_data)} records")
            processed_rating_data = [SpLatestCreditRating(**item) for item in rating_data]
            return MCPResponse(
                sources=[source],
                data=processed_rating_data,
                isError=False,
                message=None
            )
        elif response.status_code == 204:
            logger.info(f"No ratings found for keyInstn: {keyInstn}.")
            return MCPResponse(
                sources=None,
                data=None,
                isError=False,
                message="No ratings found for the given company."
            )
        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return MCPResponse(
                sources=None,
                data=None,
                isError=True,
                message=f"Error: {response.status_code} - {response.text}"
            )
    except httpx.RequestError as e:
        logger.error(f"Request failed: {e}")
        return MCPResponse(
            sources=None,
            data=None,
            isError=True,
            message=f"Request failed: {e}"
        )


@mcp.tool()
async def get_historical_rating_data(keyInstn: str, years_back: int = 5) -> MCPResponse:
    """
    Retrieves historical S&P credit ratings and credit watch/outlook progression for a specified company,
    filtered to show only records from the last N years (default: 5 years).
    
    This MCP tool provides historical credit rating data showing the evolution of S&P ratings
    over time, including all rating changes, outlook adjustments, and credit watch events.
    
    Args:
        keyInstn (str): The unique company identifier (institution ID) used to retrieve historical ratings.
        years_back (int, optional): Number of years back from current date to filter historical data.
                                   Default is 5 years. Set to 0 or negative value to get all historical data.
    
    Returns:
        MCPResponse: An MCPResponse object containing the following structure:
            - sources (list[Source]): List containing citation information:
                - title (str): "Company History Ratings"
                - url (str): Direct link to the company's ratings history page in S&P Capital IQ Pro
            - data (list[SpHistCreditRating]): List of historical rating records, each containing:
                - RT_RATING_TYPE_CODE (str): Category of the rating:
                                           • "Foreign Currency LT" - Foreign currency long-term rating
                                           • "Local Currency LT" - Local currency long-term rating
                                           • "Foreign Currency ST" - Foreign currency short-term rating
                                           • "Local Currency ST" - Local currency short-term rating
                - RT_DEBT_TYPE_CODE (str): Type of debt instrument rated (typically "Issuer Credit Rating")
                - RT_CURRENT_RATING_SYMBOL (str): S&P credit rating symbol at the time of action
                                                 (e.g., "AA-", "BBB+", "A-1+")
                - RT_RATING_DATE (str): ISO 8601 formatted date when the rating was assigned
                                       (e.g., "2025-06-12T08:10:16")
                - RT_CURRENT_CW_OL (str): Credit watch or outlook status at the time:
                                        • "Watch Pos" - CreditWatch Positive
                                        • "Watch Neg" - CreditWatch Negative
                                        • "Positive" - Positive outlook
                                        • "Negative" - Negative outlook
                                        • "Stable" - Stable outlook
                - RT_CURRENT_CW_OL_DATE (str): ISO 8601 formatted date when the credit watch/outlook
                                              was assigned (e.g., "2025-07-10T12:01:06")
                - RT_CURRENT_CW_OL_ACTION_WORD (str): Description of the rating action taken:
                                                    • "CreditWatch/Outlook" - Watch or outlook change
                                                    • "Downgrade | CreditWatch/Outlook" - Rating downgrade with watch/outlook
                                                    • "Upgrade | CreditWatch/Outlook" - Rating upgrade with watch/outlook
                                                    • "Affirmation | CreditWatch/Outlook" - Rating affirmation with watch/outlook
            - isError (bool): False for successful requests, True for error conditions
            - message (str|None): Error message if request fails, None for successful requests
    
    Example Response:
        {
            "sources": [{"title": "Company History Ratings", "url": "https://..."}],
            "data": [
                {
                    "RT_RATING_TYPE_CODE": "Foreign Currency LT",
                    "RT_DEBT_TYPE_CODE": "Issuer Credit Rating",
                    "RT_CURRENT_RATING_SYMBOL": "AA-",
                    "RT_RATING_DATE": "2025-06-12T08:10:16",
                    "RT_CURRENT_CW_OL": "Watch Neg",
                    "RT_CURRENT_CW_OL_DATE": "2025-07-10T12:01:06",
                    "RT_CURRENT_CW_OL_ACTION_WORD": "CreditWatch/Outlook"
                }
            ],
            "isError": False,
            "message": None
        }
    
    Usage Examples:
        # Get last 5 years of historical ratings (default)
        result = await get_historical_rating_data("4004205")
        
        # Get last 3 years of historical ratings
        result = await get_historical_rating_data("4004205", years_back=3)
        
        # Get all historical ratings (no date filtering)
        result = await get_historical_rating_data("4004205", years_back=0)
    
        
    """
    logger.info(f"History Rating requested: {keyInstn}, years_back: {years_back}")
    logger.info(f"get_historical_rating_data called for : {keyInstn}")

    # Get configuration
    cfg = get_config()
    capitaliq_base_url = cfg["capitaliq_base_url"]
    history_ratings_url_infix = "ChatRD/ratingshistory/"
    old_ciqpro_url = cfg["old_ciqpro_url"]

    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    url = f"{capitaliq_base_url}{history_ratings_url_infix}{keyInstn}"
    global async_client
    try:
        response = await async_client.get(url, headers=auth.build_auth_headers(raw_request))
        source = await get_mcp_tool_source(
            mcp_tool_name=get_historical_rating_data.__name__,
            source_url=f"{old_ciqpro_url}#company/ratingsHistory?Id={keyInstn}",
            institution_id=str(keyInstn),
            headers=auth.build_auth_headers(raw_request),
            default_title="Company History Ratings",
        )
        if response.status_code == 200:
            rating_data = response.json()
            logger.info(f"Historical rating data: {len(rating_data)} records")
            RELEVANT_FIELDS = [
                "RT_RATING_TYPE_CODE", "RT_DEBT_TYPE_CODE", "RT_CURRENT_RATING_SYMBOL", "RT_RATING_DATE",
                "RT_CURRENT_CW_OL", "RT_CURRENT_CW_OL_DATE", "RT_CURRENT_CW_OL_ACTION_WORD"
            ]

            if isinstance(rating_data, list):
                filtered_data = [
                    {k: v for k, v in item.items() if k in RELEVANT_FIELDS}
                    for item in rating_data
                ]
            else:
                filtered_data = rating_data

            # Apply date filtering if years_back is specified (positive value)
            if years_back > 0:
                cutoff_date = datetime.now() - timedelta(days=years_back * 365)
                logger.info(f"Filtering data from {cutoff_date.strftime('%Y-%m-%d')} onwards")
                logger.info(f"Current date: {datetime.now().strftime('%Y-%m-%d')}")

                date_filtered_data = []
                for item in filtered_data:
                    rating_date_str = item.get("RT_RATING_DATE")
                    cw_ol_date_str = item.get("RT_CURRENT_CW_OL_DATE")

                    # Check if either date field falls within the time range
                    include_record = False

                    # Check RT_RATING_DATE
                    if rating_date_str:
                        try:
                            rating_date = None

                            # Try ISO format with T and Z
                            if 'T' in rating_date_str:
                                rating_date_str_clean = rating_date_str.replace('Z', '')
                                rating_date = datetime.fromisoformat(rating_date_str_clean)
                            else:
                                # Try other common formats
                                for fmt in ['%Y-%m-%d %H:%M:%S', '%Y-%m-%d', '%m/%d/%Y', '%d/%m/%Y']:
                                    try:
                                        rating_date = datetime.strptime(rating_date_str, fmt)
                                        break
                                    except ValueError:
                                        continue

                            if rating_date and rating_date >= cutoff_date:
                                include_record = True

                        except (ValueError, TypeError) as e:
                            logger.warning(f"Could not parse RT_RATING_DATE '{rating_date_str}': {e}")

                    # Check RT_CURRENT_CW_OL_DATE if not already included
                    if not include_record and cw_ol_date_str:
                        try:
                            cw_ol_date = None

                            # Try ISO format with T and Z
                            if 'T' in cw_ol_date_str:
                                cw_ol_date_str_clean = cw_ol_date_str.replace('Z', '')
                                cw_ol_date = datetime.fromisoformat(cw_ol_date_str_clean)
                            else:
                                # Try other common formats
                                for fmt in ['%Y-%m-%d %H:%M:%S', '%Y-%m-%d', '%m/%d/%Y', '%d/%m/%Y']:
                                    try:
                                        cw_ol_date = datetime.strptime(cw_ol_date_str, fmt)
                                        break
                                    except ValueError:
                                        continue

                            if cw_ol_date and cw_ol_date >= cutoff_date:
                                include_record = True

                        except (ValueError, TypeError) as e:
                            logger.warning(f"Could not parse RT_CURRENT_CW_OL_DATE '{cw_ol_date_str}': {e}")

                    # Include record if either date is within range or if we couldn't parse any dates (to avoid data loss)
                    if include_record or (not rating_date_str and not cw_ol_date_str):
                        date_filtered_data.append(item)

                filtered_data = date_filtered_data
                logger.info(f"After date filtering: {len(filtered_data)} records")

            # Process filtered data into Pydantic models
            processed_rating_data = [SpHistCreditRating(**item) for item in filtered_data]
            logger.info(f"Historical rating data: {len(filtered_data)} records after filtering")
            return MCPResponse(
                sources=[source],
                data=processed_rating_data,
                isError=False,
                message=None
            )
        elif response.status_code == 204:
            logger.info(f"No historical rating data found for keyInstn: {keyInstn}.")
            return MCPResponse(
                sources=None,
                data=None,
                isError=False,
                message="No historical rating data found for the given company."
            )
        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return MCPResponse(
                sources=None,
                data=None,
                isError=True,
                message=f"Error: {response.status_code} - {response.text}"
            )
    except httpx.RequestError as e:
        logger.error(f"Request failed: {e}")
        return MCPResponse(
            sources=None,
            data=None,
            isError=True,
            message=f"Request failed: {e}"
        )


@mcp.tool()
async def get_moodys_latest_ratings(keyInstn: str) -> MCPResponse:
    """
    Retrieves current Moody's credit ratings and issuer outlook information for a specified company.
    
    This MCP tool provides access to current Moody's credit rating data including rating symbols,
    issuer outlook, and rating type classifications for comprehensive multi-agency credit assessment.
    
    Args:
        keyInstn (str): The unique company identifier (institution ID) used to retrieve Moody's ratings.
    
    Returns:
        MCPResponse: An MCPResponse object containing the following structure:
            - sources (list[Source]): List containing citation information:
                - title (str): "Company Ratings"
                - url (str): Direct link to the company's credit ratings page in S&P Capital IQ Pro
            - data (list[MoodyLatestRating]): List of current Moody's rating records, each containing:
                - KeyInstn (int): The company or institution identifier from Moody's system
                - CreditRating (str|None): The Moody's credit rating symbol:
                                         • Long-term ratings: "Aaa", "Aa1", "Aa2", "Aa3", "A1", "A2", "A3", "Baa1", etc.
                                         • Short-term ratings: "P-1", "P-2", "P-3", "NP" (Not Prime)
                                         • Special ratings: "WR" (Withdrawn), null for outlook-only records
                - RatingsAsOf (str): ISO 8601 formatted date when the rating was assigned
                                   (e.g., "2025-07-18T06:32:20")
                - CreditWatchOutlook (str|None): Current credit watch or outlook status:
                                                • "Stable" - Stable outlook
                                                • "Positive" - Positive outlook  
                                                • "Negative" - Negative outlook
                                                • "Developing" - Developing outlook
                                                • "Under Review" - Under review for possible upgrade/downgrade
                                                • "Withdrawn" - Rating withdrawn
                                                • null - No outlook assigned
                - RatingType (str): Category and description of the Moody's rating:
                                   • "Long Term Rating (Senior Unsecured Foreign)" - Foreign currency long-term
                                   • "Seniormost Revenue Backed Rating (Senior Unsecured Domestic)" - Domestic senior
                                   • "Short Term Rating (Commercial Paper Domestic)" - Short-term commercial paper
                                   • "Outlook" - Outlook-only record (CreditRating will be null)
                - GroupType (str): Classification group (typically "Ratings Summary")
            - isError (bool): False for successful requests, True for error conditions
            - message (str|None): Error message if request fails, None for successful requests
    
    Example Response:
        {
            "sources": [{"title": "Company Ratings", "url": "https://..."}],
            "data": [
                {
                    "KeyInstn": 4004205,
                    "CreditRating": "Aaa",
                    "RatingsAsOf": "2025-07-18T06:32:20",
                    "CreditWatchOutlook": None,
                    "RatingType": "Seniormost Revenue Backed Rating (Senior Unsecured Domestic)",
                    "GroupType": "Ratings Summary"
                },
                {
                    "KeyInstn": 4004205,
                    "CreditRating": "P-1",
                    "RatingsAsOf": "2016-04-27T12:04:18",
                    "CreditWatchOutlook": None,
                    "RatingType": "Short Term Rating (Commercial Paper Domestic)",
                    "GroupType": "Ratings Summary"
                }
            ],
            "isError": False,
            "message": None
        }
        
    """

    logger.info(f"Moodys Latest rating request for keyInstn: {keyInstn}")

    # Get configuration
    cfg = get_config()
    capitaliq_base_url = cfg["capitaliq_base_url"]
    agency_ratings_url_infix = "AIReportBuilder/agencyCurrentRating/"
    old_ciqpro_url = cfg["old_ciqpro_url"]

    logger.info(f"get_moodys_latest_ratings called for : {keyInstn}")
    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    url = f"{capitaliq_base_url}{agency_ratings_url_infix}{keyInstn}"
    global async_client
    try:
        response = await async_client.get(url, headers=auth.build_auth_headers(raw_request))
        source = await get_mcp_tool_source(
            mcp_tool_name=get_moodys_latest_ratings.__name__,
            source_url=f"{old_ciqpro_url}#company/creditratings?Id={keyInstn}",
            institution_id=str(keyInstn),
            headers=auth.build_auth_headers(raw_request),
            default_title="Company Ratings",
        )
        if response.status_code == 200:
            moodys_rating_data = response.json()
            moody_ratings = moodys_rating_data.get("MoodyRating", [])
            ratings_models = []
            for rating in moody_ratings:
                rating.pop("CreditRatingDirection", None)
                ratings_models.append(MoodyLatestRating(**rating))
            logger.info("MoodyRating records: %d", len(ratings_models))
            return MCPResponse(
                sources=[source],
                data=ratings_models,
                isError=False,
                message=None
            )
        elif response.status_code == 204:
            logger.info(f"No Moodys ratings found for keyInstn: {keyInstn}.")
            return MCPResponse(
                sources=None,
                data=None,
                isError=False,
                message="No Moodys ratings found for the given company."
            )
        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return MCPResponse(
                sources=None,
                data=None,
                isError=True,
                message=f"Error: {response.status_code} - {response.text}"
            )
    except httpx.RequestError as e:
        logger.error(f"Request failed: {e}")
        return MCPResponse(
            sources=None,
            data=None,
            isError=True,
            message=f"Request failed: {e}"
        )


@mcp.tool()
async def get_fitch_latest_ratings(keyInstn: str) -> MCPResponse:
    """
    Retrieves current Fitch credit ratings and issuer outlook information for a specified company.
    
    This MCP tool provides access to current Fitch credit rating data including international and national
    scale ratings, issuer default ratings (IDR), and outlook information for multi-agency credit analysis.
    
    Args:
        keyInstn (str): The unique company identifier (institution ID) used to retrieve Fitch ratings.
    
    Returns:
        MCPResponse: An MCPResponse object containing the following structure:
            - sources (list[Source]): List containing citation information:
                - title (str): "Company Ratings"
                - url (str): Direct link to the company's credit ratings page in S&P Capital IQ Pro
            - data (list[FitchLatestRating]): List of current Fitch rating records, each containing:
                - KeyInstn (int): The company or institution identifier from Fitch system
                - CreditRating (str|None): The Fitch credit rating symbol:
                                         • Long-term international ratings: "AAA", "AA+", "AA", "AA-", "A+", "A", "A-", "BBB+", etc.
                                         • Long-term national ratings: "AAA(usa)", "AA+(mex)", "A-(can)", etc.
                                         • Short-term ratings: "F1+", "F1", "F2", "F3", "B", "C", "D"
                                         • Special ratings: "WD" (Withdrawn), "NR" (Not Rated)
                                         • null for outlook-only records
                - RatingsAsOf (str): ISO 8601 formatted date when the rating was assigned
                                   (e.g., "2025-06-20T13:07:02")
                - CreditWatchOutlook (str|None): Current credit watch or outlook status:
                                                • "Stable" - Stable outlook
                                                • "Positive" - Positive outlook
                                                • "Negative" - Negative outlook
                                                • "Evolving" - Evolving outlook
                                                • "RWP" - Rating Watch Positive
                                                • "RWN" - Rating Watch Negative
                                                • "RWE" - Rating Watch Evolving
                                                • "RO:Sta" - Rating Outlook Stable
                                                • "RO:Pos" - Rating Outlook Positive
                                                • "RO:Neg" - Rating Outlook Negative
                                                • null - No outlook assigned
                - RatingType (str): Category and description of the Fitch rating:
                                   • "Long-Term Foreign Currency IDR" - Foreign currency issuer default rating
                                   • "Long-Term Local Currency IDR" - Local currency issuer default rating
                                   • "Short-Term Foreign Currency IDR" - Short-term foreign currency rating
                                   • "Long-Term National Issuer Rating" - National scale long-term rating
                                   • "Senior Unsecured" - Senior unsecured debt rating
                                   • "Outlook" - Outlook-only record (CreditRating will be null)
                - GroupType (str): Classification group (typically "Ratings Summary")
            - isError (bool): False for successful requests, True for error conditions
            - message (str|None): Error message if request fails, None for successful requests
    
    Example Response:
        {
            "sources": [{"title": "Company Ratings", "url": "https://..."}],
            "data": [
                {
                    "KeyInstn": 7599691,
                    "CreditRating": "AA+ (mex)",
                    "RatingsAsOf": "2025-06-20T13:07:02",
                    "CreditWatchOutlook": "RO:Sta",
                    "RatingType": "Long-Term National Issuer Rating",
                    "GroupType": "Ratings Summary"
                },
                {
                    "KeyInstn": 7599691,
                    "CreditRating": None,
                    "RatingsAsOf": "2025-06-20T13:07:02",
                    "CreditWatchOutlook": "Stable",
                    "RatingType": "Outlook",
                    "GroupType": "Ratings Summary"
                }
            ],
            "isError": False,
            "message": None
         }

    """

    logger.info(f"Fitch Latest rating request for keyInstn: {keyInstn}")

    # Get configuration
    cfg = get_config()
    capitaliq_base_url = cfg["capitaliq_base_url"]
    agency_ratings_url_infix = "AIReportBuilder/agencyCurrentRating/"
    old_ciqpro_url = cfg["old_ciqpro_url"]

    logger.info(f"get_fitch_latest_ratings called for : {keyInstn}")
    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    url = f"{capitaliq_base_url}{agency_ratings_url_infix}{keyInstn}"
    global async_client
    try:
        response = await async_client.get(url, headers=auth.build_auth_headers(raw_request))
        source = await get_mcp_tool_source(
            mcp_tool_name=get_fitch_latest_ratings.__name__,
            source_url=f"{old_ciqpro_url}#company/creditratings?Id={keyInstn}",
            institution_id=str(keyInstn),
            headers=auth.build_auth_headers(raw_request),
            default_title="Company Ratings",
        )
        if response.status_code == 200:
            fitch_rating_data = response.json()
            fitch_ratings = fitch_rating_data.get("FitchRating", [])
            ratings_models = []
            for rating in fitch_ratings:
                rating.pop("CreditRatingDirection", None)
                ratings_models.append(FitchLatestRating(**rating))
            logger.info("FitchRating records: %d", len(ratings_models))
            return MCPResponse(
                sources=[source],
                data=ratings_models,
                isError=False,
                message=None
            )
        elif response.status_code == 204:
            logger.info(f"No fitch ratings found for keyInstn: {keyInstn}.")
            return MCPResponse(
                sources=None,
                data=None,
                isError=False,
                message="No fitch ratings found for the given company."
            )
        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return MCPResponse(
                sources=None,
                data=None,
                isError=True,
                message=f"Error: {response.status_code} - {response.text}"
            )
    except httpx.RequestError as e:
        logger.error(f"Request failed: {e}")
        return MCPResponse(
            sources=None,
            data=None,
            isError=True,
            message=f"Request failed: {e}"
        )


# @mcp.tool()
async def get_moodys_history_ratings(keyInstn: str) -> MCPResponse:
    """
    Retrieves complete historical Moody's credit ratings and issuer outlook progression for a specified company.
    
    This MCP tool provides comprehensive historical Moody's credit rating data showing the evolution of ratings
    over time, including all rating changes, outlook adjustments, and withdrawal events for trend analysis.
    
    Args:
        keyInstn (str): The unique company identifier (institution ID) used to retrieve historical Moody's ratings.
    
    Returns:
        MCPResponse: An MCPResponse object containing the following structure:
            - sources (list[Source]): List containing citation information:
                - title (str): "Company Ratings"
                - url (str): Direct link to the company's credit ratings page in S&P Capital IQ Pro
            - data (list[MoodyHistRating]): List of historical Moody's rating records, each containing:
                - KeyInstn (int): The company or institution identifier from Moody's system
                - CreditRating (str|None): The historical Moody's credit rating symbol:
                                         • Long-term ratings: "Aaa", "Aa1", "Aa2", "Aa3", "A1", "A2", "A3", "Baa1", "Baa2", "Baa3", etc.
                                         • Short-term ratings: "P-1", "P-2", "P-3", "NP" (Not Prime)
                                         • Special ratings: "WR" (Withdrawn), null for historical outlook-only records
                - RatingsAsOf (str): ISO 8601 formatted date when the historical rating was assigned
                                   (e.g., "1999-10-25T00:00:00")
                - CreditWatchOutlook (str|None): Historical credit watch or outlook status at time of action:
                                                • "Stable" - Stable outlook
                                                • "Positive" - Positive outlook  
                                                • "Negative" - Negative outlook
                                                • "Developing" - Developing outlook
                                                • "Under Review" - Under review for possible upgrade/downgrade
                                                • "Withdrawn" - Rating withdrawn
                                                • null - No outlook assigned at time of action
                - RatingType (str): Category and description of the historical Moody's rating:
                                   • "LT Issuer Rating (Domestic)" - Domestic long-term issuer rating
                                   • "Long Term Rating (Senior Unsecured Foreign)" - Foreign currency long-term
                                   • "Seniormost Revenue Backed Rating (Senior Unsecured Domestic)" - Domestic senior
                                   • "Short Term Rating (Commercial Paper Domestic)" - Short-term commercial paper
                                   • "Outlook" - Historical outlook-only record (CreditRating will be null)
                - GroupType (str): Classification group (typically "Ratings Summary")
            - isError (bool): False for successful requests, True for error conditions
            - message (str|None): Error message if request fails, None for successful requests
    
    Example Response:
        {
            "sources": [{"title": "Company Ratings", "url": "https://..."}],
            "data": [
                {
                    "KeyInstn": 4004205,
                    "CreditRating": "B1",
                    "RatingsAsOf": "1999-10-25T00:00:00",
                    "CreditWatchOutlook": null,
                    "RatingType": "LT Issuer Rating (Domestic)",
                    "GroupType": null
                },
                {
                    "KeyInstn": 4004205,
                    "CreditRating": null,
                    "RatingsAsOf": "2003-11-15T00:00:00",
                    "CreditWatchOutlook": "Stable",
                    "RatingType": "Outlook",
                    "GroupType": null
                }
            ],
            "isError": False,
            "message": None
        }

        
    """

    logger.info(f"Moodys Historical rating request for keyInstn: {keyInstn}")

    # Get configuration
    cfg = get_config()
    capitaliq_base_url = cfg["capitaliq_base_url"]
    agencyhistory_ratings_url_infix = "AIReportBuilder/agencyHistoryRating/"
    old_ciqpro_url = cfg["old_ciqpro_url"]

    logger.info(f"get_moodys_history_ratings called for : {keyInstn}")
    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    url = f"{capitaliq_base_url}{agencyhistory_ratings_url_infix}{keyInstn}"
    global async_client
    try:
        response = await async_client.get(url, headers=auth.build_auth_headers(raw_request))
        source = await get_mcp_tool_source(
            mcp_tool_name=get_moodys_history_ratings.__name__,
            source_url=f"{old_ciqpro_url}#company/creditratings?Id={keyInstn}",
            institution_id=str(keyInstn),
            headers=auth.build_auth_headers(raw_request),
            default_title="Company Ratings",
        )
        if response.status_code == 200:
            moodys_rating_data = response.json()
            moody_ratings = moodys_rating_data.get("MoodyRating", [])
            ratings_models = []
            for rating in moody_ratings:
                rating.pop("CreditRatingDirection", None)
                ratings_models.append(MoodyHistRating(**rating))
            logger.info("MoodyRating records: %d", len(ratings_models))
            return MCPResponse(
                sources=[source],
                data=ratings_models,
                isError=False,
                message=None
            )
        elif response.status_code == 204:
            logger.info(f"No Moodys ratings found for keyInstn: {keyInstn}.")
            return MCPResponse(
                sources=None,
                data=None,
                isError=False,
                message="No Moodys ratings found for the given company."
            )
        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return MCPResponse(
                sources=None,
                data=None,
                isError=True,
                message=f"Error: {response.status_code} - {response.text}"
            )
    except httpx.RequestError as e:
        logger.error(f"Request failed: {e}")
        return MCPResponse(
            sources=None,
            data=None,
            isError=True,
            message=f"Request failed: {e}"
        )


# @mcp.tool()
async def get_fitch_History_ratings(keyInstn: str) -> MCPResponse:
    """
    Retrieves complete historical Fitch credit ratings and issuer outlook progression for a specified company.
    
    This MCP tool provides comprehensive historical Fitch credit rating data showing the evolution of both
    international and national scale ratings over time, including outlook adjustments.
    
    Args:
        keyInstn (str): The unique company identifier (institution ID) used to retrieve historical Fitch ratings.
    
    Returns:
        MCPResponse: An MCPResponse object containing the following structure:
            - sources (list[Source]): List containing citation information:
                - title (str): "Company Ratings"
                - url (str): Direct link to the company's credit ratings page in S&P Capital IQ Pro
            - data (list[FitchHistRating]): List of historical Fitch rating records, each containing:
                - KeyInstn (int): The company or institution identifier from Fitch system
                - CreditRating (str|None): The historical Fitch credit rating symbol:
                                         • Long-term international ratings: "AAA", "AA+", "AA", "AA-", "A+", "A", "A-", "BBB+", etc.
                                         • Long-term national ratings: "AAA(usa)", "AA+(mex)", "A-(can)", etc.
                                         • Short-term ratings: "F1+", "F1", "F2", "F3", "B", "C", "D"
                                         • Special ratings: "WD" (Withdrawn), "NR" (Not Rated)
                                         • null for outlook-only historical records
                - RatingsAsOf (str): ISO 8601 formatted date when the historical rating was assigned
                                   (e.g., "2020-03-15T10:30:00")
                - CreditWatchOutlook (str|None): Historical credit watch or outlook status at time of action:
                                                • "Stable" - Stable outlook
                                                • "Positive" - Positive outlook
                                                • "Negative" - Negative outlook
                                                • "Evolving" - Evolving outlook
                                                • "RWP" - Rating Watch Positive
                                                • "RWN" - Rating Watch Negative
                                                • "RWE" - Rating Watch Evolving
                                                • "RO:Sta" - Rating Outlook Stable
                                                • "RO:Pos" - Rating Outlook Positive
                                                • "RO:Neg" - Rating Outlook Negative
                                                • "Withdrawn" - Rating withdrawn
                                                • null - No outlook assigned at time of action
                - RatingType (str): Category and description of the historical Fitch rating:
                                   • "Long-Term National Issuer Rating" - National scale long-term rating
                                   • "Long-Term Foreign Currency IDR" - Foreign currency issuer default rating
                                   • "Long-Term Local Currency IDR" - Local currency issuer default rating
                                   • "Short-Term Foreign Currency IDR" - Short-term foreign currency rating
                                   • "Senior Unsecured" - Senior unsecured debt rating
                                   • "Outlook" - Historical outlook-only record (CreditRating will be null)
                - GroupType (str): Classification group (typically "Ratings Summary")
            - isError (bool): False for successful requests, True for error conditions
            - message (str|None): Error message if request fails, None for successful requests
    
    Example Response:
        {
            "sources": [{"title": "Company Ratings", "url": "https://..."}],
            "data": [
                {
                    "KeyInstn": 7599691,
                    "CreditRating": "BBB+ (mex)",
                    "RatingsAsOf": "2020-03-15T10:30:00",
                    "CreditWatchOutlook": null,
                    "RatingType": "Long-Term National Issuer Rating",
                    "GroupType": "Ratings Summary"
                },
                {
                    "KeyInstn": 7599691,
                    "CreditRating": "A- (mex)",
                    "RatingsAsOf": "2021-08-22T14:15:00",
                    "CreditWatchOutlook": "RO:Pos",
                    "RatingType": "Long-Term National Issuer Rating",
                    "GroupType": "Ratings Summary"
                },
                {
                    "KeyInstn": 7599691,
                    "CreditRating": "AA+ (mex)",
                    "RatingsAsOf": "2022-12-05T16:45:00",
                    "CreditWatchOutlook": "RO:Sta",
                    "RatingType": "Long-Term National Issuer Rating",
                    "GroupType": "Ratings Summary"
                },
                {
                    "KeyInstn": 7599691,
                    "CreditRating": "WD",
                    "RatingsAsOf": "2024-06-30T12:00:00",
                    "CreditWatchOutlook": "Withdrawn",
                    "RatingType": "Long-Term National Issuer Rating",
                    "GroupType": "Ratings Summary"
                },
                {
                    "KeyInstn": 7599691,
                    "CreditRating": null,
                    "RatingsAsOf": "2022-09-10T09:30:00",
                    "CreditWatchOutlook": "Positive",
                    "RatingType": "Outlook",
                    "GroupType": "Ratings Summary"
                }
            ],
            "isError": False,
            "message": None
        }

        
    """

    logger.info(f"Fitch History rating request for keyInstn: {keyInstn}")

    # Get configuration
    cfg = get_config()
    capitaliq_base_url = cfg["capitaliq_base_url"]
    agencyhistory_ratings_url_infix = "AIReportBuilder/agencyHistoryRating/"
    old_ciqpro_url = cfg["old_ciqpro_url"]

    logger.info(f"get_fitch_History_ratings called for : {keyInstn}")
    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    url = f"{capitaliq_base_url}{agencyhistory_ratings_url_infix}{keyInstn}"
    global async_client
    try:
        response = await async_client.get(url, headers=auth.build_auth_headers(raw_request))
        source = await get_mcp_tool_source(
            mcp_tool_name=get_fitch_History_ratings.__name__,
            source_url=f"{old_ciqpro_url}#company/creditratings?Id={keyInstn}",
            institution_id=str(keyInstn),
            headers=auth.build_auth_headers(raw_request),
            default_title="Company Ratings",
        )
        if response.status_code == 200:
            fitch_rating_data = response.json()
            fitch_ratings = fitch_rating_data.get("FitchRating", [])
            ratings_models = []
            for rating in fitch_ratings:
                rating.pop("CreditRatingDirection", None)
                ratings_models.append(FitchHistRating(**rating))
            logger.info("FitchRating records: %d", len(ratings_models))
            return MCPResponse(
                sources=[source],
                data=ratings_models,
                isError=False,
                message=None
            )
        elif response.status_code == 204:
            logger.info(f"No fitch ratings found for keyInstn: {keyInstn}.")
            return MCPResponse(
                sources=None,
                data=None,
                isError=False,
                message="No fitch ratings found for the given company."
            )
        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return MCPResponse(
                sources=None,
                data=None,
                isError=True,
                message=f"Error: {response.status_code} - {response.text}"
            )
    except httpx.RequestError as e:
        logger.error(f"Request failed: {e}")
        return MCPResponse(
            sources=None,
            data=None,
            isError=True,
            message=f"Request failed: {e}"
        )


# Define a custom lifespan for FastAPI with a task to manage MCP


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Initialize MCP server task group
    logger.info("Initializing MCP server task group...")
    global async_client
    async_client = httpx.AsyncClient(timeout=10)
    async with contextlib.AsyncExitStack() as stack:
        await stack.enter_async_context(mcp.session_manager.run())
        yield
    await async_client.aclose()


@router.get("/agency-ratings/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "ok"}


# Create FastAPI app with lifespan
app = FastAPI(lifespan=lifespan)
app.mount("/agency-ratings", mcp.streamable_http_app())
app.include_router(router)
logger.info("Ratings MCP Server started successfully.")
