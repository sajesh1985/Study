import json
import logging
from typing import Dict, LiteralString, Optional, Any, Union

from src.synthia.persistence.document_queries import Query

logger = logging.getLogger(__name__)


def insert_job_file_map_query() -> Query:
    query: LiteralString = """
        INSERT INTO product.job_file_map (
            jobid, fileid, table_name, table_json
        ) VALUES (
            %(jobid)s, %(fileid)s, %(table_name)s, %(table_json)s
        )
    """
    schema = {
        "jobid": str,
        "fileid": str,
        "table_name": str,
        "table_json": (dict, str),
    }
    return Query(query, schema)


def fetch_job_file_map_query() -> Query:
    query: LiteralString = """
        SELECT jfm.jobid, jfm.table_name, jfm.table_json, doc.s3_uri
        FROM product.job_file_map as jfm
        JOIN product.documents as doc ON jfm.fileid = doc.id
        WHERE jfm.jobid = %(jobid)s AND jfm.table_name = %(table_name)s
    """
    schema = {
        "jobid": str,
        "table_name": str,
    }
    return Query(query, schema)


def update_job_file_map_query() -> Query:
    query: LiteralString = """
        UPDATE product.job_file_map
        SET table_json = %(table_json)s
        WHERE jobid = %(jobid)s AND fileid = %(fileid)s AND table_name = %(table_name)s
    """
    schema = {
        "jobid": str,
        "fileid": str,
        "table_name": str,
        "table_json": (dict, str),
    }
    return Query(query, schema)


async def save_job_file_map_record(record: Union[dict, list[dict]]) -> bool:
    """Insert one or more job_file_map records."""
    query = insert_job_file_map_query()

    records = record if isinstance(record, list) else [record]

    for rec in records:
        if isinstance(rec.get("table_json"), (dict, list)):
            rec["table_json"] = json.dumps(rec["table_json"])

    logger.info("First job_file_map record to insert: %s", records[0])

    query.build_params(records[0])
    logger.info("Inserting job_file_map records: %s", len(records))

    try:
        await query.execute(
            records, multiple_insert=True
        )
        logger.info("job_file_map record(s) inserted successfully.")
        return True
    except Exception as e:
        logger.error("Failed to insert job_file_map record(s): %s", e, exc_info=True)
        raise


async def get_job_file_map_record(jobid: str, table_name: str) -> Optional[Dict[str, Any]]:
    """Fetch single job_file_map record by composite key."""
    try:
        query = fetch_job_file_map_query()
        params = query.build_params({
            "jobid": jobid,
            "table_name": table_name
        })
        row = await query.execute(params, "one")
        if not row:
            return None

        # (jobid, table_name, table_json, s3_uri)
        table_json_val = row[2]
        try:
            table_json_parsed = json.loads(table_json_val) if isinstance(table_json_val, (str, bytes)) else table_json_val
        except Exception:
            table_json_parsed = table_json_val

        return {
            "jobid": row[0],
            "table_name": row[1],
            "table_json": table_json_parsed,
            "s3_uri": row[3],
        }
    except Exception as e:
        logger.error("Failed to fetch job_file_map record: %s", e, exc_info=True)
        raise


async def update_job_file_map_record(jobid: str, fileid: str, table_name: str, table_json: Union[dict, str]) -> bool:
    """Update table_json field for given composite key."""
    try:
        tj = json.dumps(table_json) if isinstance(table_json, dict) else table_json
        query = update_job_file_map_query()
        params = query.build_params({
            "jobid": jobid,
            "fileid": fileid,
            "table_name": table_name,
            "table_json": tj
        })
        await query.execute(params)
        logger.info("job_file_map record updated successfully.")
        return True
    except Exception as e:
        logger.error("Failed to update job_file_map record: %s", e, exc_info=True)
        raise
