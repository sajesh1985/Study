import copy
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List, Optional, Union

import pandas as pd
from pydantic import BaseModel


class MessageRole(str, Enum):
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"


class GuardrailOutput(BaseModel):
    message: str
    action: str


@dataclass
class ChatMessage:
    """Chat message."""

    role: MessageRole = MessageRole.USER
    content: Union[str, Dict, List[Dict]] = ""

    def __str__(self) -> str:
        return f"{self.role.value}: {self.content}"


def chat_history_to_str(
    chat_history: List[ChatMessage], mode: Optional[str] = "both", additional_message: Optional[ChatMessage] = None
) -> str:
    """
    This function convert chat history to string format which later getting used in prompt.
    """
    chat_str = ""
    if mode == "both":
        for msg in chat_history:
            chat_str = chat_str + str(msg) + "\n"
    if mode == "user":
        for msg in chat_history:
            if msg.role == MessageRole.USER:
                chat_str = chat_str + str(msg) + "\n"

    if additional_message:
        chat_str = chat_str + str(additional_message)

    return chat_str


def safe_get(collection: Union[Dict, List], keys: List[Union[str, int]], default: Optional[Any] = None) -> Any:
    """Safely get the value from nested dictionary and/or list collection based on the provided keys.
    Parameters:
    - collection (dict, list): List, dict or combination of these collections to search for a value.
    - keys (list): List of keys or indices to access the value.
    - default (optional [Any]): Default value to return if the key is not found.

    Returns:
    - Any: The value at the specified key or index, or the default value if not found.

    Example:
    >>> data = {'a': [{'b': 1}, {'c': 2}]}
    >>> safe_get(data, ['a', 0, 'b'])
    """
    result = copy.deepcopy(collection)
    for key in keys:
        if not result:
            return default
        try:
            result = result[key]
        except (KeyError, IndexError, TypeError):
            return default
    return result


def dict_coalesce(data_source: Dict, keys: List[str], default: Optional[Any] = None) -> Any:
    """Safely get the first non-null value from a dictionary by the provided keys.
    Parameters:
    - data_source (dict): The dictionary to search.
    - keys (list): List of possible keys to access the value.
    - default (optional [Any]): Default value to return if none of the keys are found or have None values.

    Returns:
    - Any: The first non-null value found at the specified keys, or the default value if not found.

    Example:
    >>> data = {'id': None, 'value': 3}
    >>> dict_coalesce(data, ['name', 'id', 'value'], default=0)
    """
    values = [data_source.get(key) for key in keys]
    try:
        return next(item for item in values if item is not None)
    except StopIteration:
        return default


# Union-type for the most common types of DataFrame indices
IndexType = Union[int, str, float, pd.Timestamp]


def df_safe_get(df: pd.DataFrame, column: str, row: IndexType = None, default: Optional[Any] = None) -> Any:
    """Safely get a value from a DataFrame cell by the provided column name and row index.
    Parameters:
    - df (pd.DataFrame): The DataFrame to search.
    - column (str): The column name to access.
    - row (int): The row index to access. (For filtered DataFrames, this is the index of the row. `df.index[row]`)
    - default (optional [Any]): Default value to return if the column or row is not found.

    Returns:
    - Any: The value at the specified column and row (or index), or the default value if not found.
    """
    column = df.get(column)
    if column is None:
        return default

    value = column.get(row)
    return value if value is not None else default
