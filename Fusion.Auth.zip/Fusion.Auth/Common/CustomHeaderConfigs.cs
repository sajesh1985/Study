﻿using Fis.Epp.Fusion.Auth.Models;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Fis.Epp.Fusion.Auth.Common
{
    public sealed class CustomHeaderConfigs
    {
        private readonly RequestDelegate _next;
        private readonly IConfiguration _configuration;
        private readonly string CSPConfig = "Content-Security-Policy";
        public static Dictionary<string, string> AddHeaders { get; private set; }

        public CustomHeaderConfigs(RequestDelegate next, IConfiguration configuration)
        {
            _next = next;
            _configuration = configuration;
        }
        public async Task Invoke(HttpContext httpContext)
        {
            List<string> removeHeaders = _configuration.GetSection("AppConfiguration:CustomHeaders:RemoveHeaders").Get<List<string>>();

            if (removeHeaders != null)
            {
                foreach (string header in removeHeaders)
                {
                    httpContext.Response.Headers.Remove(header);
                }
            }

            AddHeaders = _configuration.GetSection("AppConfiguration:CustomHeaders:AddHeaders").GetChildren().ToDictionary(x => x.Key, x => x.Value);

            if (AddHeaders != null)
            {
                foreach (var header in AddHeaders)
                {
                    if (header.Key.Equals(CSPConfig))
                    {
                        string value = header.Value;
                        AddKeepAliveUrl(httpContext, "connect-src", ref value);
                        AddKeepAliveUrl(httpContext, "img-src", ref value);
                        httpContext.Response.Headers.Add(header.Key, value);
                    }
                    else
                    {
                        httpContext.Response.Headers.Add(header.Key, header.Value);
                    }
                }
            }

            await _next(httpContext);
        }

        public void AddKeepAliveUrl(HttpContext httpContext, string contentType, ref string headerValue)
        {
            int startIndex = headerValue.IndexOf(contentType);
            if (startIndex >= 0)
            {
                string keepAliveURL = string.Empty;
                if (httpContext.Request.Headers.ContainsKey(RequestHeader.SessionToken.GetEnumDescription()))
                {
                    var jwtToken = JwtHelper.ReadToken(httpContext.Request.Headers[RequestHeader.SessionToken.GetEnumDescription()]);
                    var _claim = jwtToken.Claims.SingleOrDefault(x => x.Type == JWTEnum.KeepAliveURL.GetEnumDescription());
                    if (_claim != null)
                    {
                        keepAliveURL = _claim.Value;
                    }
                }
                else if (httpContext.Request.HasFormContentType && httpContext.Request.Form.ContainsKey(RequestHeader.KeepAliveURL.GetEnumDescription()))
                {
                    keepAliveURL = Convert.ToString(httpContext.Request.Form[RequestHeader.KeepAliveURL.GetEnumDescription()]);
                }
                int lastIndex = headerValue.IndexOf(";", startIndex);
                if (!string.IsNullOrWhiteSpace(keepAliveURL) && lastIndex >= 0)
                {
                    headerValue = headerValue.Insert(lastIndex, $" {keepAliveURL}");
                }
            }
        }
    }

    // Extension method used to add the middleware to the HTTP request pipeline.
    public static class CustomHeaderConfigExtensions
    {
        public static IApplicationBuilder UseCustomHeaderConfigMiddleware(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<CustomHeaderConfigs>();
        }
    }
}
