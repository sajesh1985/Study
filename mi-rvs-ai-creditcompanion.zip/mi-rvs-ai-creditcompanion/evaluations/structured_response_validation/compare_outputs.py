import argparse
import json
import pandas as pd
from collections import Counter

parser = argparse.ArgumentParser(description="Regression Test Script")
parser.add_argument("--response_dev_file", type=str, help="Questions File")
parser.add_argument("--response_branch_file", type=str, help="Responses File")
parser.add_argument("--response_comparison_out_file", type=str, help="Responses File")

args = parser.parse_args()
response_dev_file = args.response_dev_file
response_branch_file = args.response_branch_file
response_comparison_out_file = args.response_comparison_out_file
unique_identifier_column = "question"
columns_to_compare = ["response", "leading_line"]  # List of columns to compare


def parse_text_to_dict(text_block):
    """
    Parses a multi-line string with 'Key: Value' pairs into a dictionary.
    Handles values that span multiple lines by creating a list.
    """
    if not isinstance(text_block, str):
        return {}
        
    parsed_dict = {}
    lines = text_block.strip().split('\n')
    current_key = None

    for line in lines:
        line = line.strip()
        if not line:
            continue

        if ':' in line:
            key, value = line.split(':', 1)
            current_key = key.strip()
            value = value.strip()
            
            if value:
                parsed_dict[current_key] = value
            else:
                parsed_dict[current_key] = []
        elif current_key and isinstance(parsed_dict.get(current_key), list):
            parsed_dict[current_key].append(line)
            
    return parsed_dict


def compare_data_structures(dict1, dict2):
    """
    Compares two dictionaries in an order-agnostic way.
    Returns a tuple: (are_equivalent, detailed_differences).
    """
    keys1 = set(dict1.keys())
    keys2 = set(dict2.keys())

    if keys1 != keys2:
        return False, f"Key mismatch. Difference: {keys1.symmetric_difference(keys2)}"

    differences = {}
    for key in dict1:
        val1 = dict1[key]
        val2 = dict2[key]
        if isinstance(val1, list) and isinstance(val2, list):
            if Counter(val1) != Counter(val2):
                differences[key] = {'file1_values': sorted(val1), 'file2_values': sorted(val2)}
        elif val1 != val2:
            differences[key] = {'file1_value': val1, 'file2_value': val2}

    if differences:
        return False, differences
    
    return True, "No differences found. The structures are equivalent."


def analyze_csv_files(file1_path, file2_path, id_column, compare_columns_list, output_json_path):
    """
    Main function to load, process, compare specified columns, and log differences to a JSON file.
    """
    print(f"--- Analyzing '{file1_path}' vs '{file2_path}' ---")
    
    try:
        df1 = pd.read_csv(file1_path)
        df2 = pd.read_csv(file2_path)
    except FileNotFoundError as e:
        print(f"Error: {e}. Please ensure both CSV files exist.")
        return

    differences_log = []
    merged_df = pd.merge(df1, df2, on=id_column, suffixes=('_dev', '_feature'), how='outer', indicator=True)

    # Process rows that are present in both files
    for index, row in merged_df[merged_df['_merge'] == 'both'].iterrows():
        identifier = row[id_column]
        
        print("\n" + "="*80)
        print(f"Comparing row with ID: '{identifier}'")
        print("="*80)

        row_differences = {}
        any_difference_found_in_row = False

        # Iterate through the list of columns to compare
        for column_to_compare in compare_columns_list:
            val_dev = row.get(f'{column_to_compare}_dev')
            val_feature = row.get(f'{column_to_compare}_feature')

            # Handle potential NaN values from merge
            val_dev = '' if pd.isna(val_dev) else val_dev
            val_feature = '' if pd.isna(val_feature) else val_feature
            
            are_equivalent = False
            details = {}

            print(f"\n--- Comparing column: '{column_to_compare}' ---")
            print(f"Dev Value:\n{val_dev}")
            print(f"Feature Value:\n{val_feature}")
            
            # Use specialized comparison for 'response' column
            if column_to_compare == "response":
                dict_dev = parse_text_to_dict(val_dev)
                dict_feature = parse_text_to_dict(val_feature)
                are_equivalent, details = compare_data_structures(dict_dev, dict_feature)
            # Use simple string comparison for other columns like 'leading_line'
            else:
                if val_dev == val_feature:
                    are_equivalent = True
                    details = "No differences found. The values are identical."
                else:
                    are_equivalent = False
                    details = {
                        f"{column_to_compare}_dev": val_dev,
                        f"{column_to_compare}_feature": val_feature
                    }

            # --- Console logging for immediate feedback ---
            print("\n--- Comparison Result ---")
            if are_equivalent:
                print(f"✅ Result: EQUIVALENT. {details}")
            else:
                print(f"❌ Result: NOT EQUIVALENT. Differences found:")
                print(json.dumps(details, indent=2))
                any_difference_found_in_row = True
                row_differences[column_to_compare] = {
                    "dev_value": val_dev,
                    "feature_value": val_feature,
                    "details": details
                }

        # If any column in the row had a difference, add it to the main log
        if any_difference_found_in_row:
            difference_entry = {
                "Question": identifier,
                "differences": row_differences
            }
            differences_log.append(difference_entry)
        
        print("="*80)

    # After the loop, write the collected differences to a JSON file
    if differences_log:
        print(f"\nFound functional difference(s) in {len(differences_log)} question(s). Writing details to '{output_json_path}'...")
        with open(output_json_path, 'w') as f:
            json.dump(differences_log, f, indent=4)
        print("JSON file created successfully.")
    else:
        # Empty the JSON file if it already exists and no differences are found
        with open(output_json_path, 'w') as f:
            json.dump([], f) 
        print("\nNo functional differences found between the files. Empty JSON file was created.")


analyze_csv_files(response_dev_file, response_branch_file, unique_identifier_column, columns_to_compare, response_comparison_out_file)
