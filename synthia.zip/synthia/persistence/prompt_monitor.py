"""Prompt edit tracking for Synthia."""

import json
import logging
from datetime import datetime
from decimal import Decimal
from typing import Any, Dict, List, Optional

from src.synthia.persistence.database_manager import get_connection_pool
from src.synthia.user_profile.user_profile_provider import (
    UserProfileData,
    fetch_user_profile_data,
)
from src.synthia.utils.logging_config import configure_logging

logger = configure_logging(
    logger_name=__name__,
    log_file="synthia.log",
    module_levels={__name__: logging.DEBUG},
)


class PromptMonitor:
    """Manages prompt edit lifecycle using inline SQL."""

    def __init__(self, auth_token: Optional[str] = None):
        self._connection_pool = None
        self.profile: Optional[UserProfileData] = None
        self.auth_token = auth_token

    async def _get_keyonline_user(self) -> int:
        if self.profile is None:
            self.profile = await fetch_user_profile_data(self.auth_token)
        return self.profile["KeyOnlineUser"]

    def _get_pool(self):
        if self._connection_pool is None:
            self._connection_pool = get_connection_pool()
        if self._connection_pool is None:
            raise RuntimeError(
                "Connection pool not initialized. Call initialize_connection_pool() during app startup."
            )
        return self._connection_pool

    async def _execute(
        self,
        query: str,
        params: Optional[List[Any]] = None,
        fetchone: bool = False,
        fetchall: bool = False,
    ):
        pool = self._get_pool()
        async with pool.connection() as conn:
            cursor = await conn.execute(query, params or [])
            if fetchone:
                row = await cursor.fetchone()
                if row is None:
                    return None
                columns = [desc.name for desc in cursor.description]
                return dict(zip(columns, row))
            if fetchall:
                rows = await cursor.fetchall()
                if not rows:
                    return []
                columns = [desc.name for desc in cursor.description]
                return [dict(zip(columns, row)) for row in rows]
            await conn.commit()
            return None

    def _normalize_row(self, row: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        if row is None:
            return None
        normalized = dict(row)
        for field in ("response", "request"):
            value = normalized.get(field)
            if isinstance(value, str):
                try:
                    normalized[field] = json.loads(value)
                except json.JSONDecodeError:
                    logger.debug("Failed to deserialize %s for prompt %s", field, row.get("prompt_id"))
        progress = normalized.get("progress")
        if progress is not None and not isinstance(progress, Decimal):
            normalized["progress"] = Decimal(str(progress))
        for field in ("started_at", "completed_at", "created_at", "updated_at"):
            value = normalized.get(field)
            if isinstance(value, datetime):
                normalized[field] = value.isoformat()
        return normalized

    async def create_prompt_edit(
        self,
        prompt_id: str,
        job_id: str,
        section_id: str,
        section_title: Optional[str] = None,
        prompt: Optional[str] = None,
        status: Optional[str] = None,
        progress: Optional[float] = None,
        previous_prompt_id: Optional[str] = None,
        request: Optional[Dict[str, Any]] = None,
        response: Optional[Dict[str, Any]] = None,
        started_at: Optional[str | datetime] = None,
        completed_at: Optional[str | datetime] = None,
    ) -> None:
        keyonline_user = await self._get_keyonline_user()
        await self._execute(
            """
            INSERT INTO Product.report_edits (
                prompt_id,
                job_id,
                keyonlineuser,
                previous_prompt_id,
                prompt,
                section_id,
                section_title,
                progress,
                status,
                response,
                request,
                started_at,
                completed_at
            )
            VALUES (
                %s,
                %s,
                %s,
                %s,
                %s,
                %s,
                %s,
                %s,
                %s,
                CAST(%s AS jsonb),
                CAST(%s AS jsonb),
                %s,
                %s
            )
            ON CONFLICT (prompt_id) DO UPDATE
            SET
                job_id = EXCLUDED.job_id,
                keyonlineuser = EXCLUDED.keyonlineuser,
                previous_prompt_id = EXCLUDED.previous_prompt_id,
                prompt = EXCLUDED.prompt,
                section_id = EXCLUDED.section_id,
                section_title = EXCLUDED.section_title,
                progress = EXCLUDED.progress,
                status = EXCLUDED.status,
                response = EXCLUDED.response,
                request = EXCLUDED.request,
                started_at = EXCLUDED.started_at,
                completed_at = EXCLUDED.completed_at,
                updated_at = CURRENT_TIMESTAMP
            """,
            [
                prompt_id,
                job_id,
                keyonline_user,
                previous_prompt_id,
                prompt,
                section_id,
                section_title,
                self.safe_decimal(progress),
                status,
                self.safe_json_dumps(response),
                self.safe_json_dumps(request),
                self.safe_parse_dt(started_at),
                self.safe_parse_dt(completed_at),
            ],
        )

    async def get_prompt_edit(self, prompt_id: str, job_id: str) -> Optional[Dict[str, Any]]:
        keyonline_user = await self._get_keyonline_user()
        row = await self._execute(
            """
            SELECT *
            FROM Product.report_edits
            WHERE prompt_id = %s AND job_id = %s AND keyonlineuser = %s
            """,
            [prompt_id, job_id, keyonline_user],
            fetchone=True,
        )
        return self._normalize_row(row)

    async def update_prompt_edit(self, prompt_id: str, updates: Dict[str, Any]) -> bool:
        if not updates:
            return False
        keyonline_user = await self._get_keyonline_user()
        allowed_fields = {
            "job_id",
            "previous_prompt_id",
            "prompt",
            "section_id",
            "section_title",
            "progress",
            "status",
            "response",
            "request",
            "started_at",
            "completed_at",
        }
        set_clauses: List[str] = []
        params: List[Any] = []
        for field, value in updates.items():
            if field not in allowed_fields:
                continue
            if field in {"response", "request"}:
                set_clauses.append(f"{field} = CAST(%s AS jsonb)")
                params.append(self.safe_json_dumps(value))
            elif field == "progress":
                set_clauses.append(f"{field} = %s")
                params.append(self.safe_decimal(value))
            elif field in {"started_at", "completed_at"}:
                set_clauses.append(f"{field} = %s")
                params.append(self.safe_parse_dt(value))
            else:
                set_clauses.append(f"{field} = %s")
                params.append(value)
        if not set_clauses:
            return False
        set_clauses.append("updated_at = CURRENT_TIMESTAMP")
        params.extend([prompt_id, keyonline_user])
        await self._execute(
            f"""
            UPDATE Product.report_edits
            SET {', '.join(set_clauses)}
            WHERE prompt_id = %s AND keyonlineuser = %s
            """,
            params,
        )
        return True

    async def list_prompt_edits(
        self,
        job_id: Optional[str] = None,
        section_id: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        keyonline_user = await self._get_keyonline_user()
        filters: List[str] = ["keyonlineuser = %s"]
        params: List[Any] = [keyonline_user]
        if job_id:
            filters.append("job_id = %s")
            params.append(job_id)
        if section_id:
            filters.append("section_id = %s")
            params.append(section_id)
        rows = await self._execute(
            f"""
            SELECT *
            FROM Product.report_edits
            WHERE {' AND '.join(filters)}
            ORDER BY created_at DESC
            """,
            params,
            fetchall=True,
        )
        return [self._normalize_row(row) for row in rows]

    async def delete_prompt_edit(self, prompt_id: str) -> bool:
        keyonline_user = await self._get_keyonline_user()
        await self._execute(
            """
            DELETE FROM Product.report_edits
            WHERE prompt_id = %s AND keyonlineuser = %s
            """,
            [prompt_id, keyonline_user],
        )
        return True

    def safe_json_dumps(self, value: Optional[Any]) -> Optional[str]:
        if value is None:
            return None
        return json.dumps(value)

    def safe_decimal(self, value: Optional[Any]) -> Optional[Decimal]:
        if value is None:
            return None
        return Decimal(str(value))

    def safe_parse_dt(self, value: Optional[Any]) -> Optional[datetime]:
        if value is None:
            return None
        if isinstance(value, datetime):
            return value
        if isinstance(value, str) and value:
            return datetime.fromisoformat(value.replace("Z", "+00:00"))
        raise ValueError(f"Unsupported datetime value: {value}")


def get_prompt_monitor(auth_token: Optional[str] = None) -> PromptMonitor:
    return PromptMonitor(auth_token=auth_token)
