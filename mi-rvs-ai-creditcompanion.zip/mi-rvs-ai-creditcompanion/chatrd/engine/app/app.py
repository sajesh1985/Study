from dotenv import load_dotenv

load_dotenv()

import json
import logging
import os
import types
from io import BytesIO
from itertools import groupby
from typing import Dict

import pandas as pd
import streamlit as st
from pandas import json_normalize

from chatrd.core.document import (
    CSDTableResponse,
    ParentChildTableResponse,
    TableResponse,
)
from chatrd.core.utils import ChatMessage, MessageRole
from chatrd.engine.app.callbacks import StreamlitCallback
from chatrd.engine.app.config import (
    ASSISTANT_ROLE,
    DATA_SERVICE_LLMS,
    MAIN_LLMS,
    USER_ROLE,
)
from chatrd.engine.app.engine_initiator import get_chat_engine
from chatrd.engine.app.response_enricher import ResponseEnricher
from chatrd.engine.app.utils import contains_a_tag
from chatrd.engine.components.query_analyzer.suggested_entity_rephrase.suggested_routes import (
    SuggestedContent,
    SuggestedRoute,
    SuggestedRoutesResponse,
)
from chatrd.engine.exceptions import RDException

callback = StreamlitCallback()
STREAMING = True


default_log_format = "%(asctime)s - %(levelname)s [%(name)s:%(funcName)s|L-%(lineno)d] - %(message)s"
logging.basicConfig(
    format=os.getenv("LOG_FORMAT", default=default_log_format),
    level=os.getenv("LOG_LEVEL", logging.INFO),
)
logger = logging.getLogger(__name__)

st.set_page_config(
    page_title="CreditCompanion™",
    layout="wide",
)

st.session_state.setdefault("generation_messages", [{"role": ASSISTANT_ROLE, "content": "How can I help you?"}])
st.session_state.setdefault("retrieval_messages", [{"role": ASSISTANT_ROLE, "content": "How can I help you?"}])
st.session_state.setdefault("chat_history", [])


def download_chat_logs():
    final_df = []
    for message_history in [
        st.session_state.generation_messages,
        st.session_state.retrieval_messages,
    ]:
        df = pd.DataFrame()
        user_msg, assistant_msg = [], []
        for idx, (key, group) in enumerate(groupby(message_history, key=lambda m: m["role"])):
            if idx == 0:
                continue
            messages = ""
            if key == USER_ROLE:
                for message in group:
                    messages = messages + message["content"]
                user_msg.append(messages)
            else:
                for message in group:
                    if isinstance(message["content"], pd.DataFrame):
                        messages = messages + str(message["content"].to_markdown())
                    elif isinstance(message["content"], CSDTableResponse) or isinstance(
                        message["content"], ParentChildTableResponse
                    ):
                        messages = messages + str(json_normalize(message["content"].data).to_markdown())
                    elif isinstance(message["content"], Dict):
                        messages = messages + json.dumps(message["content"])
                    else:
                        messages = messages + message["content"]
                assistant_msg.append(messages)
        if len(user_msg) == len(assistant_msg):
            df["user_query"] = user_msg
        else:
            df["user_query"] = user_msg[:-1]
            if mode == "generation":
                st.session_state.generation_messages = st.session_state.generation_messages[:-1]
                st.session_state.chat_history = st.session_state.chat_history[:-1]
            else:
                st.session_state.retrieval_messages = st.session_state.retrieval_messages[:-1]
        df["chatrd_response"] = assistant_msg
        final_df.append(df)
    excel_file = BytesIO()
    with pd.ExcelWriter(excel_file, engine="xlsxwriter") as writer:
        final_df[0].to_excel(writer, sheet_name="Generation Responses", index=False)
        final_df[1].to_excel(writer, sheet_name="Retrieval Responses", index=False)

    return excel_file


generation_on = st.toggle("Generate responses", value=True)
mode = "generation" if generation_on else "retrieval"
st.sidebar.header("Settings")
st.sidebar.write("__Query Analyzer__")
st.sidebar.write("__Tagged routes__")

tagged_routes = st.sidebar.selectbox(
    "select tagged routes",
    [None, "AllResearch", "MacroResearch", "EntityResearch", "DataQuery", "Criteria", "Definitions"],
    key="tagged_routes",
)
model_name_for_analyzer = st.sidebar.selectbox("Select LLM", MAIN_LLMS, key="analyzer_llm")

temperature_for_analyzer = st.sidebar.slider(
    "Select a temperature value between 0 and 1", 0.0, 1.0, 0.0001, key="analyzer_temp"
)
if generation_on:
    st.sidebar.write("__Query Synthesizer__")
    model_name_for_non_flex_synthesizer = st.sidebar.selectbox("Select LLM", MAIN_LLMS, key="synthesizer_llm")

    temperature_for_non_flex_synthesizer = st.sidebar.slider(
        "Select a temperature value between 0 and 1",
        0.0,
        1.0,
        0.0,
        key="synthesizer_temp",
    )

st.sidebar.write("__Data Service LLMs__")
model_name_for_data_service = st.sidebar.selectbox("Select LLM", DATA_SERVICE_LLMS, key="data_service_llm")

st.sidebar.download_button(
    "Download chat logs",
    data=download_chat_logs(),
    file_name="chatrd_chat_logs.xlsx",
    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
)


def run():

    if prompt := st.chat_input("Enter your query here."):
        with st.chat_message("user", avatar=USER_ROLE):
            msg = {"role": USER_ROLE, "content": prompt}
            st.markdown(prompt, unsafe_allow_html=True)
            if generation_on:
                st.session_state.generation_messages.append(msg)
            else:
                st.session_state.retrieval_messages.append(msg)

        with st.chat_message(ASSISTANT_ROLE, avatar=ASSISTANT_ROLE):
            with st.status("Parsing Question...", expanded=True) as status:
                if generation_on:
                    status.update(label="Generating response...", state="running", expanded=True)
                    try:
                        response = CHAT.chat(
                            message=prompt,
                            model_name_for_analyzer=model_name_for_analyzer,
                            temperature_for_analyzer=temperature_for_analyzer,
                            model_name_for_non_flex_synthesizer=model_name_for_non_flex_synthesizer,
                            temperature_for_non_flex_synthesizer=temperature_for_non_flex_synthesizer,
                            model_name_for_data_service=model_name_for_data_service,
                            chat_history=st.session_state.chat_history,
                            model_name_for_analyzer_entity_extractor=model_name_for_analyzer,
                            temperature_for_analyzer_entity_extractor=temperature_for_analyzer,
                            model_name_for_analyzer_sector_extractor=model_name_for_analyzer,
                            temperature_for_analyzer_sector_extractor=temperature_for_analyzer,
                            model_name_for_tool_classifier=model_name_for_analyzer,
                            temperature_for_tool_classfifer=temperature_for_analyzer,
                            streaming=STREAMING,
                            tagged_routes=[tagged_routes] if tagged_routes else [],
                        )
                    except RDException as e:
                        callback.execute_callback(
                            callback_message=(str(e) + "\n\n" + str(e.inner_exception)), mode=mode
                        )
                        return
                else:
                    status.update(label="Retrieving documents...", state="running", expanded=True)
                    try:
                        response = CHAT.retrieve(
                            model_name_for_analyzer=model_name_for_analyzer,
                            temperature_for_analyzer=temperature_for_analyzer,
                            model_name_for_data_service=model_name_for_data_service,
                            message=prompt,
                            chat_history=[],
                        )
                    except RDException as e:
                        callback.execute_callback(
                            callback_message=(str(e) + "\n\n" + str(e.inner_exception)), mode=mode
                        )
                        return
                links = []
                if generation_on:
                    st.session_state.chat_history.append(ChatMessage(role=MessageRole.USER, content=prompt))
                    for res in response.content:
                        if res["type"] == "table":
                            response_table = pd.DataFrame(res["content"].rows)
                            callback.execute_callback(callback_message=response_table, mode=mode)
                        elif res["type"] in ["csd_table", "parentchild_table"]:
                            response_table = res["content"]
                            callback.execute_callback(callback_message=response_table, mode=mode)
                        elif res["type"] and isinstance(res["content"], types.GeneratorType):
                            links = callback.execute_callback(callback_message=res["content"], mode=mode)
                        elif res["type"] == "suggestion" or res["type"] == "route_suggestion":
                            formatted_suggestions = ""
                            query_entity_is_rd = None
                            for item in res["content"].content:
                                if item.text:
                                    formatted_suggestions += "\n\n" + item.text
                                elif item.suggestions and isinstance(item, SuggestedRoutesResponse):
                                    if isinstance(item.suggestions[0], SuggestedRoute):
                                        suggested_route_metadata = [
                                            [route.name, route.definition] for route in item.suggestions
                                        ]
                                        suggested_route_metadata_format = []
                                        for i in range(len(suggested_route_metadata)):
                                            suggested_route_metadata_format.append(
                                                "  - "
                                                + "**"
                                                + suggested_route_metadata[i][0]
                                                + "**"
                                                + " "
                                                + suggested_route_metadata[i][1]
                                            )
                                        formatted_suggestions += "\n" + "\n".join(suggested_route_metadata_format)
                                    elif isinstance(item.suggestions[0], SuggestedContent):

                                        for content in item.suggestions:
                                            if content.text:
                                                formatted_suggestions += "\n- " + content.text

                                            if content.routes is not None:
                                                suggested_route_metadata = [
                                                    [route.name, route.definition] for route in content.routes
                                                ]
                                                suggested_route_metadata_format = []
                                                for i in range(len(suggested_route_metadata)):
                                                    suggested_route_metadata_format.append(
                                                        "  - "
                                                        + "**"
                                                        + suggested_route_metadata[i][0]
                                                        + "**"
                                                        + " "
                                                        + suggested_route_metadata[i][1]
                                                    )
                                                formatted_suggestions += "\n" + "\n".join(
                                                    suggested_route_metadata_format
                                                )

                                elif item.suggestions:
                                    suggested_entity_metadata = [
                                        [entity.id, entity.name, entity.query] for entity in item.suggestions
                                    ]
                                    suggested_entity_metadata_format = []
                                    for i in range(len(suggested_entity_metadata)):
                                        suggested_entity_metadata_format.append(
                                            "**"
                                            + suggested_entity_metadata[i][0]
                                            + " - "
                                            + suggested_entity_metadata[i][1]
                                            + "**"
                                            + " - "
                                            + suggested_entity_metadata[i][2]
                                        )
                                    formatted_suggestions += "\n- " + "\n- ".join(suggested_entity_metadata_format)

                            if res["content"].behavior == "collapse":
                                output_message = f"<details> <summary> <h6> {res['content'].title} </h6> </summary> {formatted_suggestions} </details>"
                            else:
                                output_message = f"###### {res['content'].title} {formatted_suggestions}"

                            callback.execute_callback(
                                callback_message=output_message,
                                mode=mode,
                            )
                        else:
                            callback.execute_callback(
                                callback_message=(
                                    (
                                        contains_a_tag(res["content"])
                                        if isinstance(res["content"], str)
                                        else contains_a_tag(res["content"].content)
                                    )
                                    if res["content"]
                                    else ""
                                ),
                                mode=mode,
                            )
                if not response.cited_docs:
                    response.cited_docs = links
                cited_data_service_docs = []
                if response.source_docs:

                    source_links, cited_links, unauthorized_links = RESPONSE_ENRICHER.extract_categorized_sources(
                        source_docs=response.source_docs,
                        cited_docs=response.cited_docs,
                        unauthorized_docs=response.unauthorized_docs,
                    )

                    useful_links = [l for l in source_links if l not in cited_links]
                    # print cited links
                    links = list(cited_links)

                    source_texts, data_service_docs = RESPONSE_ENRICHER.get_docs_text_from_response(response.cited_docs)
                    cited_data_service_docs = data_service_docs
                    if cited_data_service_docs:
                        for doc in cited_data_service_docs:
                            if "source_description" in doc.metadata:
                                if doc.metadata["source_description"]:
                                    for s_desc in doc.metadata["source_description"]:
                                        tag = contains_a_tag(f"[{s_desc[0]}]({s_desc[1]})")
                                        if not tag in links:
                                            links.insert(
                                                0,
                                                tag,
                                            )
                    if links:
                        # The above for loop reverses the order of the links, so we need to reverse it back to see the same order in streamlit and frontend
                        links = links[::-1]
                        if generation_on:
                            links = ["\n###### Sources:\n - " + "\n- ".join(links) + "\n"]
                            sources = "".join([r + "\n\n" for r in links])
                            callback.execute_callback(callback_message=f"{sources}", mode=mode)
                        else:
                            sources = "".join(
                                [
                                    f"__{idx+1} :__"
                                    + "\n"
                                    + s
                                    + "\n\n"
                                    + "__Source Text :__ \n\n"
                                    + contains_a_tag(r)
                                    + "\n\n"
                                    for idx, (r, s) in enumerate(zip(source_texts, source_links))
                                ]
                            )
                            callback.execute_callback(callback_message=f"{sources}", mode=mode)

                    # print usefull links
                    links = list(set(useful_links))
                    source_texts, data_service_docs = RESPONSE_ENRICHER.get_docs_text_from_response(
                        [d for d in response.source_docs if d not in response.cited_docs]
                    )
                    if data_service_docs:
                        for doc in data_service_docs:
                            if "source_description" in doc.metadata:
                                if doc.metadata["source_description"]:
                                    for s_desc in doc.metadata["source_description"]:
                                        links.insert(
                                            0,
                                            contains_a_tag(f"[{s_desc[0]}]({s_desc[1]})"),
                                        )
                    if links:
                        if generation_on:
                            links = ["\n###### Other Related Research:\n - " + "\n- ".join(links) + "\n"]
                            sources = "".join([r + "\n\n" for r in links])
                            callback.execute_callback(callback_message=f"{sources}", mode=mode)
                        else:
                            sources = "".join(
                                [
                                    f"__{idx+1} :__"
                                    + "\n"
                                    + s
                                    + "\n\n"
                                    + "__Source Text :__ \n\n"
                                    + contains_a_tag(r)
                                    + "\n\n"
                                    for idx, (r, s) in enumerate(zip(source_texts, source_links))
                                ]
                            )
                            callback.execute_callback(callback_message=f"{sources}", mode=mode)

                    data_service_docs = data_service_docs + cited_data_service_docs

                    if data_service_docs:

                        for ds in data_service_docs:
                            if "is_error" in ds.metadata:
                                callback.execute_callback(
                                    callback_message="__Data Service API Response__ :\n\n",
                                    mode=mode,
                                )
                                if not isinstance(ds.content, TableResponse):
                                    callback.execute_callback(
                                        callback_message=((contains_a_tag(ds.content)) if ds.content else ""),
                                        callback_type="data_service",
                                        mode=mode,
                                    )
                                if isinstance(ds.content, TableResponse) and (not generation_on):
                                    response_table = pd.DataFrame(ds.content.rows)
                                    callback.execute_callback(callback_message=response_table, mode=mode)

                            if ds.metadata["response_payload"]:
                                callback.execute_callback(
                                    callback_message="__Data Service API Payload__ :\n\n",
                                    mode=mode,
                                )

                                callback.execute_callback(
                                    callback_message=ds.metadata["response_payload"],
                                    callback_type="data_service",
                                    mode=mode,
                                )

                    # print unauthorized links
                    links = list(set(unauthorized_links))
                    if links:
                        if generation_on:
                            links = [
                                "\n###### S&P Ratings Research Outside Subscription:\n - " + "\n- ".join(links) + "\n"
                            ]
                            sources = "".join([r + "\n\n" for r in links])
                            callback.execute_callback(callback_message=f"{sources}", mode=mode)
                        else:
                            sources = "".join(
                                [
                                    f"__{idx+1} :__"
                                    + "\n"
                                    + s
                                    + "\n\n"
                                    + "__Source Text :__ \n\n"
                                    + contains_a_tag(r)
                                    + "\n\n"
                                    for idx, (r, s) in enumerate(zip(source_texts, source_links))
                                ]
                            )
                            callback.execute_callback(callback_message=f"{sources}", mode=mode)
                else:
                    if not generation_on:
                        callback.execute_callback(callback_message=response.content[0][0]["content"], mode=mode)

                status.update(label="Query Complete", state="complete", expanded=True)
                st.rerun()


st.title("💬 CreditCompanion™")
st.markdown("🚀 A natural language interface for S&P Ratings Direct data powered by MI C&RS Technology.")
script = """<div id = 'chat_outer'></div>"""
st.markdown(script, unsafe_allow_html=True)


def write_messages(message):
    if isinstance(message["content"], pd.DataFrame):
        st.dataframe(message["content"])
    elif isinstance(message["content"], CSDTableResponse) or isinstance(message["content"], ParentChildTableResponse):
        st.dataframe(json_normalize(message["content"].data))
    elif isinstance(message["content"], Dict):
        st.json(message["content"], expanded=False)
    else:
        st.markdown(message["content"], unsafe_allow_html=True)


# Loop for displaying messages to user on each rerun
all_messages = st.session_state.generation_messages if generation_on else st.session_state.retrieval_messages
for idx, (key, group) in enumerate(groupby(all_messages, key=lambda m: m["role"])):
    with st.chat_message(key):
        if (key == ASSISTANT_ROLE) and not generation_on and (idx != 0):
            script = """<div id = 'chat_inner'></div>"""
            st.markdown(script, unsafe_allow_html=True)
            for message in group:
                write_messages(message)
        else:
            for message in group:
                write_messages(message)
    css_body_container = """
        <style>
            div[data-testid='stVerticalBlock']:has(div#chat_inner):not(:has(div#chat_outer)) {{
                                max-height: 300px; /* Set the maximum height here */
                                overflow-y: scroll; /* Enable vertical scrolling */
                            }}
        </style>
        """
    st.markdown(css_body_container, unsafe_allow_html=True)

if __name__ == "__main__":
    CHAT = get_chat_engine()
    APP_STATE = {"chunks": []}
    RESPONSE_ENRICHER = ResponseEnricher()
    run()
