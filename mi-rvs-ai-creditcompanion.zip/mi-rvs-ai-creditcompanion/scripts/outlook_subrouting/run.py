import json

from chatrd.core.aws_utils.sagemaker import get_assumed_sagemaker_llm_client
from chatrd.core.embedding import embedding_factory
from chatrd.core.llm import LCLLMFactory
from chatrd.core.vectorstore import OpenSearch
from chatrd.engine.components.query_analyzer.uc_subrouting import (
    OutlookSubrouter,
)
from chatrd.engine.configuration import Constants, get_config_machinery

# config_machinery = get_config_machinery()


# def _get_vector_stores():
#     host = config_machinery.get_config_value(Constants.OpenSearch.OPENSEARCH_HOST)
#     port = config_machinery.get_config_value(Constants.OpenSearch.OPENSEARCH_PORT)
#     user_name = config_machinery.get_config_value(Constants.OpenSearch.OPENSEARCH_USER_NAME)
#     password = config_machinery.get_config_value(Constants.OpenSearch.OPENSEARCH_PASSWORD)
#     criteria_index_name = config_machinery.get_config_value(Constants.GeneralConstants.CRITERIA_INDEX_NAME)
#     research_index_name = config_machinery.get_config_value(Constants.GeneralConstants.RESEARCH_INDEX_NAME)
#     definition_index_name = config_machinery.get_config_value(Constants.GeneralConstants.DEFINITION_INDEX_NAME)
#     commentary_index_name = config_machinery.get_config_value(Constants.GeneralConstants.COMMENTARY_INDEX_NAME)
#     embedding_model = embedding_factory(model_name="cohere-multi")
#     criteria_vector_store = OpenSearch(host, port, user_name, password, criteria_index_name, embedding_model)
#     research_vector_store = OpenSearch(host, port, user_name, password, research_index_name, embedding_model)
#     definition_vector_store = OpenSearch(host, port, user_name, password, definition_index_name, embedding_model)
#     commentary_vector_store = OpenSearch(host, port, user_name, password, commentary_index_name, embedding_model)
#     vector_stores_dict = {
#         "criteria": criteria_vector_store,
#         "research": research_vector_store,
#         "definition": definition_vector_store,
#         "commentary": commentary_vector_store,
#     }
#     return vector_stores_dict


# llm = LCLLMFactory().get_llm(
#     deployment_name_or_model_id="haiku",
#     temperature=0,
# )

# vector_stores_dict = _get_vector_stores()
# reranker_client = get_assumed_sagemaker_llm_client(
#     role_arn=config_machinery.get_config_value(Constants.SageMaker.SAGEMAKER_ROLE_ARN),
#     region_name=config_machinery.get_config_value(Constants.SageMaker.SAGEMAKER_REGION_NAME),
# )["sagemaker-runtime"]

# outlook_retriever = OutlookRetriever(vector_stores_dict=vector_stores_dict, reranker_client=reranker_client)
outlook_subrouter = OutlookSubrouter(model_name="haiku")

with open("scripts/outlook_subrouting/test_prompts.json") as f:
    test_prompts = json.load(f)

for _, test_case in enumerate(test_prompts["macro"]):
    subrouting_result = outlook_subrouter.run(test_case)
    if subrouting_result == "macro":
        print(f"For question: {test_case} \n Expected: macro \n Predicted {subrouting_result} \n -----")
    else:
        print(f"For question: {test_case} \n Expected: macro \n \033[31mPredicted {subrouting_result}\033[0m \n -----")

for _, test_case in enumerate(test_prompts["entity"]):
    subrouting_result = outlook_subrouter.run(test_case)
    if subrouting_result == "entity":
        print(f"For question: {test_case} \n Expected: entity \n Predicted {subrouting_result} \n -----")
    else:
        print(f"For question: {test_case} \n Expected: entity \n \033[31mPredicted {subrouting_result}\033[0m \n -----")
