from typing import List, Optional, Union

from pydantic import BaseModel


class SuggestedRoute(BaseModel):
    name: Optional[str] = None
    definition: Optional[str] = None
    query: Optional[str] = None


class SuggestedContent(BaseModel):
    text: Optional[str] = None
    routes: Optional[List[SuggestedRoute]] = None


class SuggestedRoutesResponse(BaseModel):
    text: Optional[str] = None
    suggestions: Optional[Union[List[SuggestedRoute], List[SuggestedContent]]] = None


class SuggestedRoutesContent(BaseModel):
    title: str
    content: List[SuggestedRoutesResponse]
    behavior: Optional[str] = "collapse"
