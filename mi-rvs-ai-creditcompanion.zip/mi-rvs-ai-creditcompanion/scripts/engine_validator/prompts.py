from enum import Enum


class UCType(Enum):
    """Supported Use Case Types"""
    CREDIT_MEMO = "credit_memo"
    CRITERIA = "criteria"
    DEALS_TRANCHE = "deals_tranche"
    ESG = "esg"
    FINANCIALS = "financials"
    GENERAL = "general"
    INFO_COVERAGE = "info_coverage"
    OUTLOOK = "outlook"
    PEERS = "peers"
    QUERY = "query"
    RATING_ACTION = "rating_action"
    RATINGS = "ratings"
    RESEARCH = "research"
    SCORES_MODIFIERS = "scores&modifiers"
    SECURITIES = "securities"
    SNW = "sNw"


prompt_collection = {
    "credit_memo": [
        "Draft me a Credit memo for Microsoft.",
        "Draft me a Credit memo for Bank of America.",
        "Could you make a credit analysis for Siemens?",
    ],
    "criteria": [
        "Can you explain the business risks faced by life insurance sector?",
        "What factors in the SACP contribute to the Issuer Credit Rating (ICR) of a corporation?",
        "What criteria is applied to rate American Express Company?",
    ],
    "deals_tranche": [
        "What are all the active deals of APOLLO Series 2002-1 Trust?",
        "What were the tranches associated with Washington Mutual Mortgage Securities's previous deals?",
        "Can you provide a list of all active deals for JPMorgan Chase Bank and Credit Protection Trust 90?",
    ],
    "esg": [
        "What is the ESG profile of Microsoft?",
        "What impact do ESG factors have on the credit rating of Toyota Financials?",
        "Compare the ESG profile between Micron and AMD.",
        "Compare the ESG profile between Tesla and Volkswagen.",
    ],
    "financials": [
        "What's the financial outlook for Microsoft?",
        "What's the financial performance been for Tesla over the past 5 years?",
        "What was the revenue of Microsoft in 2022?",
        "What are the financial trends for Apple Inc?",
        "What are the financials for Tesla and Volkswagen?",
    ],
    "general": [
        "Explain National Scale Ratings.",
        "What are the key ratios for the corporate methodology?",
        "What is the difference between short-term and long-term credit ratings?",
        "Which sector has the highest income increase in the last year?",
        "What sectors experienced increased demand in a higher interest rate environment?",
    ],
    "info_coverage": [
        "Can you provide me the analyst coverage for Oracle Corporation?",
        "Can you provide me the NAICS code for Samsung Electronics?",
        "What is the S&P global ratings industry of Cisco Systems, Inc?",
    ],
    "outlook": [
        "What is the outlook for Apple?",
        "What is the outlook for Amazon?",
        "What is the outlook for the healthcare sector?",
        "What would cause a downgrade for Chevron?",
    ],
    "peers": [
        "What are the analyst peers of IBM Credit LLC?",
        "Show all competitors of Walmart Inc.",
        "What is the difference in credit ratings between Oracle Corporation and IBM?",
        "Peer comparison for Volkswagen",
        "Peer comparison for Toyota Industries",
    ],
    "query": [
        "Show me a list of potential rising stars in USA.",
        "What companies were downgraded in Spain in 2021?",
        "Show me companies that have downgraded credit rating this year.",
        "Show me companies that are fallen angels in the last twelve months.",
        "Show me a list of corporates with investment grade ratings in the India.",
        "Show me all the banks in USA with an A rating.",
        "What are some companies that have been upgraded in the Gas sector?",
        "What were the top companies based on credit rating in the year 2022?",
    ],
    "rating_action": [
        "What is the latest rating action taken for Microsoft?",
        "When was the last upgrade for IBM?",
        "What is the last rating action and rationale for Toyota Financials?",
        "What are the latest rating actions for Barclays?",
        "What are the ratings and rating action for Tesla?",
    ],
    "ratings": [
        "What is the rating of AU3FN0068797?",
        "What is the rating of IBM?",
        "What are the Ratings for Tesla according to S&P Global Ratings?",
        "What is impact of Japanese yen on Toyota Financials?",
        "What are the ratings and rating action for Tesla?",
    ],
    "research": [
        "Show me the latest research articles for Microsoft.",
        "Can you provide a credit report list for JPMorgan Chase?",
        "Article list for HSBC.",
    ],
    "scores&modifiers": ["What are the scores and factors for HSBC?", "What is the current SACP for Microsoft?"],
    "securities": [
        "What is the list of rated securities issued by Bank of America?",
        "Show me all securities of Bank of America with maturity in 2026.",
    ],
    "sNw": [
        "Provide a SWOT analysis for Microsoft.",
        "Provide a SWOT analysis for Apple.",
        "Provide a SWOT analysis for Tesla.",
    ],
}


def get_prompts_for_uc_types(*uc_types: UCType) -> dict[UCType, list[str]]:
    """Get a list of prompts for a specific use case types.
    Response is a dict with uc_type as keys and list of prompts as values."""
    result = {}
    for item in uc_types:
        result[item] = prompt_collection.get(item.value, [])
    return result
