"""State management schemas for tracking job progress."""

from typing import Dict, List, Optional, TypedDict, Any
from datetime import datetime


class State(TypedDict, total=False):
    """Base state for tracking operations."""
    
    status: str  # Status of the operation (initializing, processing, completed, failed)
    progress: float  # Progress of the operation (0.0 - 1.0)
    error: Optional[str]  # Error message if any
    metadata: Optional[Dict[str, Any]]  # Additional metadata


class WorkerState(State):
    """State for tracking a worker job."""
    
    job_id: str  # Unique identifier for the job
    sections: Optional[List[Dict[str, Any]]]  # Generated sections
    completed_at: Optional[str]  # Timestamp when the job was completed
    outline: Optional[List[Dict[str, Any]]]  # Generated outline
    topic: Optional[str]  # Topic of the report
    style: Optional[str]  # Style of the report
    depth: Optional[int]  # Depth of the report
    num_sections: Optional[int]  # Number of sections
    current_section_idx: Optional[int]  # Current section index being processed
    total_sections: Optional[int]  # Total number of sections
    last_section_name: Optional[str]  # Name of the last section generated
    last_updated: Optional[str]  # Timestamp of the last update
    awaiting_approval: Optional[bool]  # Whether the job is waiting for approval
    human_approved: Optional[bool]  # Whether the outline was approved by a human
    human_feedback: Optional[str]  # Feedback from the human reviewer
    section_errors: Optional[List[str]]  # List of errors encountered during section generation
    finalization_error: Optional[str]  # Error encountered during report finalization