"""Utility module to replace functionality of other packages with numpy implementations
where there is no direct numpy equivalent function."""

import numpy as np
from numpy.typing import NDArray


# Replacement for `torch.nn.functional.normalize`
def np_normalize(input_array: NDArray, p: float = 2, axis: int = 1, eps: float = 1e-12):
    """Normalize a numpy array along a specified axis.

    Args:
        input_array (numpy.ndarray): The input numpy array to normalize.
        p (float): The order of the norm (default is 2 for L2 norm).
        axis (int): The axis along which to normalize (default is 1).
        eps (float): A small value to avoid division by zero (default is 1e-12).
    :return: The normalized numpy array.
    """
    # Compute the norm along the specified axis
    norm = np.linalg.norm(input_array, ord=p, axis=axis, keepdims=True)

    # Avoid division by zero by adding a small epsilon
    norm = np.maximum(norm, eps)

    # Divide the input array by the norm
    normalized_array = input_array / norm

    return normalized_array


# Replacement for `torch.topk`
def np_topk(
    input_array: NDArray, k: int, axis: int = -1, largest: bool = True, sorted: bool = True
) -> tuple[NDArray, NDArray]:
    """Find the the top-k elements and their indices along a specified axis from a numpy array.

    Args:
        input_array (numpy.ndarray): The input numpy array.
        k (int): The number of top elements to retrieve.
        axis (int): The axis along which to find the top-k elements (default is -1, the last axis).
        largest (bool): If True, returns the largest elements; if False, returns the smallest (default is True).
        sorted (bool): If True, returns the top-k elements in sorted order (default is True).

    Returns:
        tuple (numpy.ndarray, numpy.ndarray) of [0] values and [1] indices of the the top-k elements.
    """
    # kth: Element index to partition by.
    kth = -k if largest else k
    index_range = range(-k, 0) if largest else range(k)
    # Use np.argpartition to find the indices of the top-k largest/smallest elements
    partitioned_indices = np.argpartition(input_array, kth, axis=axis)
    topk_indices = np.take(partitioned_indices, indices=index_range, axis=axis)

    # Gather the top-k values using the indices
    topk_values = np.take_along_axis(input_array, topk_indices, axis=axis)

    if sorted:
        # Sort the top-k values and indices
        sorted_order = np.argsort(-topk_values if largest else topk_values, axis=axis)
        topk_values = np.take_along_axis(topk_values, sorted_order, axis=axis)
        topk_indices = np.take_along_axis(topk_indices, sorted_order, axis=axis)

    return topk_values, topk_indices
