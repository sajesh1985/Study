import logging
from functools import lru_cache
from typing import Any, Dict

from src.synthia.aws_utils.aws_client import get_aws_client, get_secret
from src.synthia.config.api_config import get_config
from src.synthia.utils.logging_config import configure_logging

logger = configure_logging(
    logger_name=__name__,
    log_file="synthia.log",
    module_levels={__name__: logging.DEBUG},
)


def get_secrets() -> Dict[str, Any]:
    """Get secrets from AWS Secrets Manager.

    Results are cached to avoid repeated API calls.
    Clear cache with get_secrets.cache_clear() if secrets are rotated.
    """
    try:
        cfg = get_config()
        logger.info("Fetching AWS secrets from Secrets Manager")

        secrets_manager_client = get_aws_client("secretsmanager")
        secrets = get_secret(secrets_manager_client, cfg.get("secrets_name"))

        logger.info("Successfully fetched AWS secrets")
        return secrets
    except Exception as e:
        logger.error(f"Failed to fetch AWS secrets: {e}")
        raise