// Copyright Notice!
// This document is protected under the trade secret and copyright
// laws as the property of Fidelity National Information Services, Inc.
// Copying, reproduction or distribution should be limited and only to
// employees with a “need to know” to do their job.
// Any disclosure of this document to third parties is strictly prohibited.
// © 2016 Fidelity National Information Services.
// All rights reserved worldwide.

package com.fis.digitalpayments.app;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatTextView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ConsoleMessage;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;

import com.fis.digitalpayments.sdk.SDKManager;
import com.fis.digitalpayments.sdk.messaging.WebEventLogger;
import com.fis.digitalpayments.sdk.messaging.ProductType;
import com.fis.digitalpayments.sdk.messaging.WebEvent;
import com.fis.digitalpayments.sdk.messaging.WebEventListener;
import com.fis.digitalpayments.sdk.messaging.WebEventType;
import com.fis.digitalpayments.sdk.mobile_payments.R;

import org.jetbrains.annotations.NotNull;

import java.util.HashMap;

@SuppressWarnings({"FieldCanBeLocal", "SpellCheckingInspection"})
public class WebViewFragment extends Fragment implements WebEventListener {

    //region Public Members

    public SDKManager sdkManager;

    // endregion

    //region Private Members

    private boolean mIsDemoMode;
    private boolean mShouldToastEvents;
    private boolean mIsEventNavigationEnabled;
    private boolean mIsSDKEnabled;
    private boolean mIsDisclosureEnabled;
    private int mMenuId;

    private String mDemoPreferenceKey;
    private String mUrlPreferenceKey;
    private String mToastEventsPreferenceKey;
    private String mEventNavigationPreferenceKey;
    private String mEnableSDKPreferenceKey;
    private String mEnableDisclosurePreferenceKey;
    private WebEventListener mEventLogger;

    private WebView mWebView;
    private String mCurrentWebViewUrl;
    private final String pauseTimePreferenceKey = "pauseTime";
    private boolean loadingFinished = true;
    private boolean redirect = false;
    private boolean mIsWebViewLoaded = false;

    private final String FNC1_URL_BP = "https://epayments-epayui-fnc-1.money-movement.com/1999/DebugAccess?userName=0913&productCode=Bill_Pay&destination=PhotoBillPay&internalUserID=FFAB0D1831294213A8C8DDF32457A47E";
    private final String FNC1_URL_PP = "https://epayments-epayui-fnc-1.money-movement.com/TestCeBPeoplePay1847x/DebugAccess?userName=15072298-rouvvtfjljdbexad-ro&productCode=PeoplePay&deviceType=Mobile&destination=Home&internalUserID=FFAB0D1831294213A8C8DDF32457A47E";
    private final String FNC1_URL_ZL = "https://epayments-epayui-fnc-1.money-movement.com/TestPeoplePay50202X/DebugAccess?userName=Zeller6&productCode=Zelle&destination=Home&internalUserID=FFAB0D1831294213A8C8DDF32457A47E";
    private final String FNC2_URL_BP = "https://epayments-epayui-fnc-2.money-movement.com/1999/DebugAccess?userName=1999DEMO_USER_306610107&productCode=Bill_Pay&destination=PhotoBillPay&internalUserID=FFAB0D1831294213A8C8DDF32457A47E";
    private final String FNC2_URL_PP = "https://epayments-epayui-fnc-2.money-movement.com/TestCeBPeoplePay1847x/DebugAccess?userName=15072298-rouvvtfjljdbexad-ro&productCode=PeoplePay&deviceType=Mobile&destination=Home&internalUserID=FFAB0D1831294213A8C8DDF32457A47E";
    private final String FNC2_URL_ZL = "https://epayments-epayui-fnc-2.money-movement.com/TestPeoplePay50202X/DebugAccess?userName=ZelleDemo055&productCode=Zelle&destination=Home&internalUserID=FFAB0D1831294213A8C8DDF32457A47E";
    private final String FNC3_URL_BP = "https://epayments-epayui-fnc-3.money-movement.com/1999/DebugAccess?userName=demoPB&productCode=Bill_Pay&destination=PhotoBillPay&internalUserID=FFAB0D1831294213A8C8DDF32457A47E";
    private final String FNC3_URL_PP = "https://epayments-epayui-fnc-3.money-movement.com/TestCeBPeoplePay1847x/DebugAccess?userName=15072298-rouvvtfjljdbexad-ro&productCode=PeoplePay&deviceType=Mobile&destination=Home&internalUserID=FFAB0D1831294213A8C8DDF32457A47E";
    private final String LOCAL_SYS_URL = "https://epayments-epayui-fnc-3.money-movement.com/TestPeoplePay50202X/DebugAccess?userName=31jan2022&productCode=Zelle&destination=Home&internalUserID=FFAB0D1831294213A8C8DDF32457A47E";
    private final String LOCAL_FNC_URL = "http://10.0.2.2:4021/TestPeoplePay50202X/DebugAccess?userName=Nisnam&productCode=Zelle&destination=Home";
    /*private final String FNC3_URL_PP = "https://epayments-epayui-fnc-3.money-movement.com/TestPeoplePay50202X/DebugAccess?userName=31jan2022&productCode=Zelle&destination=Home&internalUserID=FFAB0D1831294213A8C8DDF32457A47E";
    private final String LOCAL_SYS_URL = "http://localhost:4000/TestPeoplePay50202X/DebugAccess?userName=Vin1986nam&productCode=Zelle&destination=Home&internalUserID=FFAB0D1831294213A8C8DDF32457A47E";
    private final String LOCAL_FNC_URL = "http://10.0.2.2/PM2WebClient/Mobile/Index.html";*/
    private final String LOCAL_TEST = "file:///android_asset/TestSite/Index.html";
    private final String REMOTE_TEST = "https://snitest.readiness.billsupport.com/Mobile/Index.html";

    private final String ZELLE_DEMO_1 = "https://epayments-epayui-cert-3.money-movement.com/TestPeoplePay50202Z/DebugAccess?userName=Kyle%20North&productCode=Zelle&destination=Home&internalUserID=FFAB0D1831294213A8C8DDF32457A47E";
    private final String ZELLE_DEMO_2 = "https://epayments-epayui-cert-3.money-movement.com/TestPeoplePay50202Z/DebugAccess?userName=Andreas%20Rivera&productCode=Zelle&destination=Home&internalUserID=FFAB0D1831294213A8C8DDF32457A47E";
    private final String ZELLE_DEMO_3 = "https://epayments-epayui-cert-3.money-movement.com/TestPeoplePay50202Z/DebugAccess?userName=Lillian%20Large&productCode=Zelle&destination=Home&internalUserID=FFAB0D1831294213A8C8DDF32457A47E";
    private final String ZELLE_DEMO_4 = "https://epayments-epayui-cert-3.money-movement.com/TestPeoplePay50202Z/DebugAccess?userName=Issac%20Khan&productCode=Zelle&destination=Home&internalUserID=FFAB0D1831294213A8C8DDF32457A47E";

    private final String[] mDomainWhiteList = {"","epayments-crossdomain-fnc.billdomain.com", "snitest.readiness.billsupport.com", "epayments-epayui-sys-1.metavante.com", "epayments-epayui-fnc-1.money-movement.com", "epayments-epayui-fnc-2.money-movement.com", "epayments-epayui-fnc-3.money-movement.com", "epayments-epayui-uat-2.money-movement.com", "epayments-epayui-cert-3.money-movement.com", "10.0.2.2"};

    private OnFragmentInteractionListener mFragmentInteractionListener;

    // endregion

    //region Fragment Lifecycle

    public WebViewFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(@NotNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        try {
            // Inflate the layout for this fragment
            View view = inflater.inflate(R.layout.fragment_web_view, container, false);

            loadEnvironmentSettings(view);

            mEventLogger = new WebEventLogger();
            mWebView = getAndConfigureWebView(view);
            if (mIsSDKEnabled) {
                addSDKtoWebView(mWebView);
            }

            overrideWebViewMethods(mWebView);
            loadWebViewInitial(mCurrentWebViewUrl, view);

            final Button button = view.findViewById(R.id.loading_button);
            button.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    loadWebView(mCurrentWebViewUrl);
                }
            });

            return view;
        } catch (NullPointerException e) {
            Log.d(this.toString(), "Could not inflate view.");
        }
        return null;
    }

    @Override public void onPause() {
        super.onPause();
        startRefreshTimer();
    }

    @Override public void onResume() {
        super.onResume();
        checkRefreshTimer();
    }

    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        menu.clear();

        try {
            getActivity().getMenuInflater().inflate(mMenuId, menu);

            MenuItem toastMenuItem = menu.findItem(R.id.toast_events);
            toastMenuItem.setChecked(mShouldToastEvents);

            MenuItem eventNavigationMenuItem = menu.findItem(R.id.event_navigation);
            eventNavigationMenuItem.setChecked(mIsEventNavigationEnabled);

            MenuItem enableSDKMenuItem = menu.findItem(R.id.enable_sdk);
            enableSDKMenuItem.setChecked(mIsSDKEnabled);

            MenuItem enableDisclosureMenuItem = menu.findItem(R.id.enable_disclosure);
            enableDisclosureMenuItem.setChecked(mIsDisclosureEnabled);

            super.onPrepareOptionsMenu(menu);
        } catch (NullPointerException e) {
            Log.d(this.toString(), "Could not get menu inflater.");
        }
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
        // Inflate the menu; this adds items to the action bar if it is present.
        menu.clear();
        menuInflater.inflate(mMenuId, menu);

        super.onCreateOptionsMenu(menu, menuInflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        // Handle item selection
        int menuItemId = item.getItemId();
        if (menuItemId == R.id.local_sys) {
            loadWebView(LOCAL_SYS_URL);
            return true;
        }
        else if (menuItemId == R.id.local_rdy) {
            loadWebView(LOCAL_FNC_URL);
            return true;
        }
        else if (menuItemId == R.id.local_test) {
            loadWebView(LOCAL_TEST);
            return true;
        }
        else if (menuItemId == R.id.remote_test) {
            loadWebView(REMOTE_TEST);
            return true;
        }
        else if (menuItemId == R.id.fnc1_BP) {
            loadWebView(FNC1_URL_BP);
            return true;
        }
        else if (menuItemId == R.id.fnc1_PP) {
            loadWebView(FNC1_URL_PP);
            return true;
        }
        else if (menuItemId == R.id.fnc1_ZL) {
            loadWebView(FNC1_URL_ZL);
            return true;
        }
        else if (menuItemId == R.id.fnc2_BP) {
            loadWebView(FNC2_URL_BP);
            return true;
        }
        else if (menuItemId == R.id.fnc2_PP) {
            loadWebView(FNC2_URL_PP);
            return true;
        }
        else if (menuItemId == R.id.fnc2_ZL) {
            loadWebView(FNC2_URL_ZL);
            return true;
        }
        else if (menuItemId == R.id.fnc3_BP) {
            loadWebView(FNC3_URL_BP);
            return true;
        }
        else if (menuItemId == R.id.fnc3_PP) {
            loadWebView(FNC3_URL_PP);
            return true;
        }
        else if (menuItemId == R.id.zelle_demo_1) {
            loadWebView(ZELLE_DEMO_1);
            return true;
        }
        else if (menuItemId == R.id.zelle_demo_2) {
            loadWebView(ZELLE_DEMO_2);
            return true;
        }
        else if (menuItemId == R.id.zelle_demo_3) {
            loadWebView(ZELLE_DEMO_3);
            return true;
        }
        else if (menuItemId == R.id.zelle_demo_4) {
            loadWebView(ZELLE_DEMO_4);
            return true;
        }
        else if (menuItemId == R.id.edit_url) {
            promptUrlEdit();
            return true;
        }
        else if (menuItemId == R.id.refresh) {
            loadWebView(mCurrentWebViewUrl);
            return true;
        }
        else if (menuItemId == R.id.restart) {
            mWebView.destroy();
            restart();
            return true;
        }
        else if (menuItemId == R.id.demo_mode) {
            setPreference(mDemoPreferenceKey, true);
            restart();
            return true;
        }
        else if (menuItemId == R.id.qa_mode) {
            setPreference(mDemoPreferenceKey, false);
            restart();
            return true;
        }
        else if (menuItemId == R.id.enable_sdk) {
            mIsSDKEnabled = !item.isChecked();
            setPreference(mEnableSDKPreferenceKey, mIsSDKEnabled);

            // tests the dispose method
            if (sdkManager != null) {
                sdkManager.dispose();
            }

            restart();
            return true;
        }
        else if (menuItemId == R.id.enable_disclosure) {
            mIsDisclosureEnabled = !item.isChecked();
            setPreference(mEnableDisclosurePreferenceKey, mIsDisclosureEnabled);
            restart();
            return true;
        }
        else if (menuItemId == R.id.toast_events) {
            mShouldToastEvents = !item.isChecked();
            setPreference(mToastEventsPreferenceKey, mShouldToastEvents);
            return true;
        }
        else if (menuItemId == R.id.event_navigation) {
            mIsEventNavigationEnabled = !item.isChecked();
            setPreference(mEventNavigationPreferenceKey, mIsEventNavigationEnabled);
            return true;
        }
        else if (menuItemId == R.id.version_info) {
            showVersionInfo(SDKManager.getVersion(getContext()).getVersionString());
            return true;
        }
        else {
            return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mFragmentInteractionListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mFragmentInteractionListener = null;
    }

    //endregion

    //region Private Utility Methods

    private void overrideWebViewMethods(WebView webView) {

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView webView, String urlNewString) {
                if (!loadingFinished) {
                    redirect = true;
                }

                loadingFinished = false;
                webView.loadUrl(urlNewString);
                return true;
            }


            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                loadingFinished = false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if(!redirect){
                    loadingFinished = true;
                }

                if(loadingFinished && !redirect){
                    Log.d(this.toString(),"Loading finished and not a redirect.");
                } else{
                    redirect = false;
                }

            }
        });

        webView.setWebChromeClient(new WebChromeClient() {

            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    final String[] requestedResources = request.getResources();
                    request.grant(requestedResources);
                }
            }

            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                Log.d("WebView", consoleMessage.message() + " -- From line "
                        + consoleMessage.lineNumber() + " of "
                        + consoleMessage.sourceId());
                return true;
            }
        });


    }

    private void loadEnvironmentSettings(View view) {
        loadPreferenceKeys();
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
        mIsDemoMode = sharedPreferences.getBoolean(mDemoPreferenceKey, false);
        mCurrentWebViewUrl = sharedPreferences.getString(mUrlPreferenceKey, FNC1_URL_ZL);
        mShouldToastEvents = sharedPreferences.getBoolean(mToastEventsPreferenceKey, false);
        mIsEventNavigationEnabled = sharedPreferences.getBoolean(mEventNavigationPreferenceKey, false);
        mIsSDKEnabled = sharedPreferences.getBoolean(mEnableSDKPreferenceKey, true);
        mIsDisclosureEnabled = sharedPreferences.getBoolean(mEnableDisclosurePreferenceKey, true);

        if (mIsDemoMode) {
            mMenuId = R.menu.menu_demo;
        }
        else {
            mMenuId = R.menu.menu_main;
            hideProgress(view);
        }

        getActivity().invalidateOptionsMenu();
    }

    private void loadPreferenceKeys() {
        mDemoPreferenceKey = getString(R.string.demo_flag_preference_key);
        mUrlPreferenceKey = getString(R.string.url_preference_key);
        mToastEventsPreferenceKey = getString(R.string.toast_events_preference_key);
        mEventNavigationPreferenceKey = getString(R.string.event_navigation_preference_key);
        mEnableSDKPreferenceKey = getString(R.string.enable_sdk_preference_key);
        mEnableDisclosurePreferenceKey = getString(R.string.enable_disclosure_preference_key);
    }

    private void loadWebView(String url) {
        loadWebViewInitial(url, getView());
        setPreference(mUrlPreferenceKey, url);
    }

    private void loadWebViewInitial(String url, View view) {
        mIsWebViewLoaded = false;
        mCurrentWebViewUrl = url;
        showProgress(view);
        mWebView.clearCache(true);

        timerDelayStopProgress(70000, getString(R.string.serviceUnavailableMessage), getString(R.string.serviceUnavailableButtonText), view);
        mWebView.loadUrl(mCurrentWebViewUrl);
    }

    private void timerDelayStopProgress(@SuppressWarnings("SameParameterValue") long time, final String message, final String buttonText, final View view) {
        if (mIsDemoMode) {
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                public void run() {
                    if (!mIsWebViewLoaded) {
                        stopProgressWithMessage(message, buttonText, view);
                    }
                }
            }, time);
        }
    }

    private void stopProgressWithMessage(String message, String buttonText, View view) {
        view.findViewById(R.id.loading_progress).setVisibility(View.GONE);

        AppCompatTextView textView = view.findViewById(R.id.loading_message);
        textView.setText(message);
        textView.setVisibility(View.VISIBLE);

        AppCompatButton button = view.findViewById(R.id.loading_button);
        button.setText(buttonText);
        button.setVisibility(View.VISIBLE);
    }

    private void hideProgress() {
        hideProgress(getView());
    }

    private void hideProgress(View view) {
        view.findViewById(R.id.loading_layout).setVisibility(View.GONE);
    }

    private void showProgress(View view) {
        if (mIsDemoMode) {
            view.findViewById(R.id.loading_message).setVisibility(View.GONE);
            view.findViewById(R.id.loading_button).setVisibility(View.GONE);
            view.findViewById(R.id.loading_layout).setVisibility(View.VISIBLE);
            view.findViewById(R.id.loading_progress).setVisibility(View.VISIBLE);
        }
    }
    
    private void startRefreshTimer() {
        if (mIsDemoMode) {
            SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(getActivity()).edit();
            editor.putLong(pauseTimePreferenceKey, System.currentTimeMillis());
            editor.apply();
        }
    }

    private void checkRefreshTimer() {
        if (mIsDemoMode) {
            SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
            long start = preferences.getLong(pauseTimePreferenceKey, 0);
            long elapsed = System.currentTimeMillis() - start;

            if (elapsed > 300000) {
                loadWebView(mCurrentWebViewUrl);
            }
        }
    }

    private void showVersionInfo(String version) {
        AlertDialog alertDialog = new AlertDialog.Builder(getContext(), R.style.DialogTheme).create();
        alertDialog.setTitle("SDKManager version: " + version + "\n");
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
    }

    private void promptUrlEdit() {
        View editDialogView = View.inflate(getContext(), R.layout.edit_dialog, null);
        final EditText editText = editDialogView.findViewById(R.id.edit_text);
        editText.setText(mCurrentWebViewUrl);

        AlertDialog.Builder builder = new AlertDialog.Builder(getContext(), R.style.DialogTheme);
        builder.setTitle("Edit URL");
        builder.setView(editDialogView);

        // Set up the buttons
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                loadWebView(editText.getText().toString());
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();
    }

    private void setPreference(String key, boolean preference) {
        SharedPreferences.Editor editor = getPreferenceEditor();
        editor.putBoolean(key, preference);
        editor.apply();
    }

    private void setPreference(String key, String preference) {
        SharedPreferences.Editor editor = getPreferenceEditor();
        editor.putString(key, preference);
        editor.apply();
    }

    private SharedPreferences.Editor getPreferenceEditor() {
        return PreferenceManager.getDefaultSharedPreferences(getActivity()).edit();
    }

    private void restart() {
        mFragmentInteractionListener.onWebViewFragmentInteraction();
    }

    //endregion

    //region Interface Implementations

    @Override
    public void onEventReceived(WebEvent event) {
        mEventLogger.onEventReceived(event);
        HashMap<String, String> params = new HashMap<>(event.getEventParams());
        WebEventType eventType = event.getEventType();
        ProductType productType = event.getEventProduct();

        if (mShouldToastEvents) {
            ((MainActivity)getActivity()).toastEvent(getContext(), event.getEventId(), eventType, productType, params);
        }

        if (eventType == WebEventType.COMPLETED) {
            if (mIsEventNavigationEnabled) {
                Bundle data = new Bundle();
                data.putString("eventId", event.getEventId());
                data.putSerializable("eventType", eventType);
                data.putSerializable("productType", productType);
                data.putSerializable("params", params);

                BalanceFragment balanceFragment = new BalanceFragment();
                balanceFragment.setArguments(data);

                FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
                transaction.add(android.R.id.content, balanceFragment);
                transaction.hide(this);
                transaction.commit();
            }
        }
        else if (eventType == WebEventType.STARTED) {
            hideProgress();
            mIsWebViewLoaded = true;
        }
    }

    interface OnFragmentInteractionListener {
        void onWebViewFragmentInteraction();
    }

    //endregion

    //region WebView Bridge Configuration

    @SuppressLint("SetJavaScriptEnabled")
    private WebView getAndConfigureWebView(View view) {
        // Allow remote Chrome debugging on post-KitKat devices
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            WebView.setWebContentsDebuggingEnabled(true);
        }
        android.webkit.CookieManager.getInstance().setAcceptCookie(true);

        WebView webView = view.findViewById(R.id.webview);
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        return webView;
    }

    private void addSDKtoWebView(WebView webView) {
        if (mIsDisclosureEnabled) {
            sdkManager = SDKManager.create(getContext(), webView, mDomainWhiteList, this);
        }
        else {
            sdkManager = SDKManager.create(getContext(), webView, mDomainWhiteList, this, mIsDisclosureEnabled);
        }
    }

    //endregion
}
