import styled from "@emotion/styled";

export const SuggestionBarContainer = styled.div`
    display: flex;
    justify-content: center;
`;