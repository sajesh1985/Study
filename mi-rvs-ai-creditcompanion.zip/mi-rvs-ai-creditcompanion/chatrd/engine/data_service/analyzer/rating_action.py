import logging
from typing import Optional

from chatrd.core.llm import LCLLMFactory
from chatrd.core.llm.parsers import PydanticOutputParser
from chatrd.core.llm.prompt.template import SimplePromptTemplate
from chatrd.engine.configuration import get_config_machinery
from chatrd.engine.data_service.analyzer.base import BaseAnalyzer
from chatrd.engine.data_service.analyzer.prompts.prompts import (
    RATING_ACTION_OUTPUT_PARSER_TEMPLATE,
    TableFiltersRatingActionValues,
)
from chatrd.engine.data_service.analyzer.utils import clean_dict
from chatrd.engine.data_service.schema import Analyzer, ProcessorInput

logger = logging.getLogger(__name__)

config_machinery = get_config_machinery()


class RatingActionAnalyzer(BaseAnalyzer):
    """Query Analyzer for Rating Action use case,
    retrieving from query recent rating move direction (upgrade / downgrade / None)
    """

    def __init__(self, vector_database_path: Optional[str] = None):
        self.vector_database_path = vector_database_path

    def analyze(self, processor: ProcessorInput) -> Analyzer:
        model_for_data_service = LCLLMFactory().get_llm(
            deployment_name_or_model_id=processor.llm,
            temperature=processor.temperature,
        )

        output_parser = PydanticOutputParser(pydantic_object=TableFiltersRatingActionValues)
        prompt_template = SimplePromptTemplate(
            template=RATING_ACTION_OUTPUT_PARSER_TEMPLATE,
            partial_variables={
                "format_instructions": output_parser.get_format_instructions(),
            },
        )

        question_prompt = prompt_template.format(question=processor.user_input)
        output = model_for_data_service.invoke(question_prompt)
        try:
            parsed_output = output_parser.invoke(output)
            parsed_output_dict = parsed_output.model_dump()
        except Exception as e:
            logger.error(f"Rating Action Use Case, Query Analyzer failed, incorrect output format: {e}")
            parsed_output_dict = dict()
        analyzer_output = clean_dict(parsed_output_dict)
        logger.info(f"\nRecent Action Query Analyzer output : \n{analyzer_output}")
        return Analyzer(
            user_input=processor.user_input,
            uc_type=processor.uc_type,
            response=analyzer_output,
        )
