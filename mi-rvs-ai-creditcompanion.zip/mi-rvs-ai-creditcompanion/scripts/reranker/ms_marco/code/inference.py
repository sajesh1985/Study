import json
import logging
from typing import List

import torch
from sagemaker_inference import encoder
from sentence_transformers.cross_encoder import CrossEncoder

PAIRS = "pairs"
SCORES = "scores"


class MarcoCrossEncoder:
    def __init__(self) -> None:
        self.device = torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")
        logging.info(f"Using device: {self.device}")
        self.model = CrossEncoder(model_name="cross-encoder/ms-marco-MiniLM-L-6-v2", device=self.device)

    def __call__(self, pairs: List[List[str]]) -> List[float]:
        scores = self.model.predict(pairs)
        return scores


def model_fn(model_dir: str) -> MarcoCrossEncoder:
    try:
        return MarcoCrossEncoder()
    except Exception:
        logging.exception(f"Failed to load model from: {model_dir}")
        raise


def transform_fn(cross_encoder: MarcoCrossEncoder, input_data: bytes, content_type: str, accept: str) -> bytes:
    payload = json.loads(input_data)
    model_output = cross_encoder(**payload)
    output = {SCORES: model_output}
    return encoder.encode(output, accept)
