import os
import asyncio
import logging
from typing import Any, Dict, Optional
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
from langgraph.store.postgres.aio import AsyncPostgresStore
from langgraph.store.memory import InMemoryStore
from langgraph.checkpoint.memory import InMemorySaver
from psycopg_pool import AsyncConnectionPool

from src.synthia.aws_utils.aws_client import get_env_specific_secret_key
from src.synthia.config.api_config import get_config
from src.synthia.utils.logging_config import configure_logging
from src.synthia.utils.aws_secrets import get_secrets

logger = configure_logging(
    logger_name=__name__,
    log_file="synthia.log",
    module_levels={__name__: logging.DEBUG},  # Set this module to DEBUG
)

cfg = get_config()

# Global connection pool - initialize once for the entire application
_connection_pool: Optional[AsyncConnectionPool] = None
_connection_pool_agent: Optional[AsyncConnectionPool] = None
_main_health_check_task: Optional[asyncio.Task] = None
_agent_health_check_task: Optional[asyncio.Task] = None
_checkpointer = None
_store = None
_engine = None

async def _get_secrets() -> Dict[str, Any]:
    """Get secrets from AWS Secrets Manager."""
    logger.info("Fetching aws secrets")
    secrets = await asyncio.to_thread(get_secrets)
    logger.info("Fetched aws secrets")
    return secrets


async def _keep_alive_task(pool: AsyncConnectionPool, interval: int = 60 * 10):
    """Periodically check pool health to prevent idle connection timeout."""
    while True:
        try:
            await asyncio.sleep(interval)
            logger.info("Performing Database connection pool health check...")
            async with pool.connection() as conn:
                await conn.execute("SELECT 1")
            logger.info("Database connection pool health check passed")
        except asyncio.CancelledError:
            logger.info("Database health check task cancelled")
            break
        except Exception as e:
            logger.warning(f"Database health check failed: {e}")


async def initialize_main_connection_pool(postgres_connection_string: str, min_pool_size: int = 4):
    """Initialize the main connection pool."""
    logger.info("Initializing main connection pool...")
    global _connection_pool, _main_health_check_task
    if _connection_pool is None:
        connection_kwargs = {
            "autocommit": True,
            "prepare_threshold": 0,
        }
        _connection_pool = AsyncConnectionPool(
            conninfo=postgres_connection_string,
            max_size=cfg.get("main_pool_max_size", 4),
            min_size=min_pool_size,
            max_idle=1200,  # 20 minutes - recycle idle connections
            max_lifetime=1500,  # 25 minutes - recycle all connections
            reconnect_timeout=30,  # Retry reconnection for 30 seconds
            kwargs=connection_kwargs,
            open=False,
        )
        await _connection_pool.open()

        # Start health check every 5 minutes
        logger.info("Starting main connection pool health check task...")
        _main_health_check_task = asyncio.create_task(
            _keep_alive_task(_connection_pool, interval=60*5)
        )


async def initialize_agent_connection_pool(postgres_connection_string: str):
    """Initialize the agent connection pool and storage components."""
    global _connection_pool_agent, _checkpointer, _store, _agent_health_check_task
    if _connection_pool_agent is None:
        connection_kwargs = {
            "autocommit": True,
            "prepare_threshold": 0,
        }
        _connection_pool_agent = AsyncConnectionPool(
            conninfo=postgres_connection_string,
            # + "?options=-csearch_path%3DAgent",
            max_size=cfg.get("agent_pool_max_size", 4),
            max_idle=1200,  # 20 minutes - recycle idle connections
            max_lifetime=1500,  # 25 minutes - recycle all connections
            reconnect_timeout=30,  # Retry reconnection for 30 seconds
            kwargs=connection_kwargs,
            open=False,
        )
        await _connection_pool_agent.open()

        # Start health check every 5 minutes
        logger.info("Starting agent connection pool health check task...")
        _agent_health_check_task = asyncio.create_task(
            _keep_alive_task(_connection_pool_agent, interval=60*5)
        )
        # Initialize global checkpointer and store
        if os.environ.get("RUNNING_LOCALLY", "false").lower() in ("true", "1", "yes"):
            _checkpointer = InMemorySaver()
            _store = InMemoryStore()
            # set_llm_db_cache(InMemoryCache()) # custom lookup not implemented hence not used in local mode
        else:
            logger.info("Creating Langgraph store and checkpointer with Postgres backend...")
            _checkpointer = AsyncPostgresSaver(_connection_pool_agent)
            _store = AsyncPostgresStore(_connection_pool_agent)
            logger.info("Created Langgraph store and checkpointer with Postgres backend...")

            logger.info("Started setting up Langgraph store and checkpointer with Postgres backend...")
            await asyncio.gather(
                _checkpointer.setup(),
                _store.setup()
            )
            #await _checkpointer.setup()
            #await _store.setup()
            logger.info("Completed setting up Langgraph store and checkpointer with Postgres backend...")


            # postgres_connection_string = postgres_connection_string.replace(
            #     "postgresql://", "postgresql+psycopg://"
            # )
            # _engine = create_async_engine(
            #     postgres_connection_string,
            #     # + "?options=-csearch_path%3DAgent",
            #     pool_size=cfg.get("llm_cache_db_pool_size", 4),
            #     max_overflow=cfg.get("llm_cache_db_overflow_size", 10),
            # )
            # _llm_db_cache = AsyncPostGreSQLCache(
            #     engine=_engine, cache_schema=HashedLLMCache
            # )
            # await _llm_db_cache.initialize_schema()
            # set_llm_db_cache(_llm_db_cache, engine_name="PostGreSQLCache")

            # async with _connection_pool_agent.connection() as conn:
            #     await conn.execute("CREATE SCHEMA IF NOT EXISTS Agent")

            


async def get_postgres_conn_string():
    secrets = await _get_secrets()
    username = secrets[get_env_specific_secret_key('postgresql_uname')]
    password = secrets[get_env_specific_secret_key('postgresql_pwd')]
    host = secrets[get_env_specific_secret_key('postgresql_host')]

    postgres_connection_string = (
        f"postgresql://{username}:{password}@{host}:5432/creditmemo"
    )
    return postgres_connection_string

async def initialize_connection_pool():
    """Initialize both main and agent connection pools and storage components. Call this during FastAPI startup."""
    secrets = await _get_secrets()
    username = secrets[get_env_specific_secret_key('postgresql_uname')]
    password = secrets[get_env_specific_secret_key('postgresql_pwd')]
    host = secrets[get_env_specific_secret_key('postgresql_host')]

    postgres_connection_string = (
        f"postgresql://{username}:{password}@{host}:5432/creditmemo"
    )
    await initialize_main_connection_pool(postgres_connection_string)
    await initialize_agent_connection_pool(postgres_connection_string)

async def initialize_service_connection_pool():
    """Initialize both main and agent connection pools and storage components. Call this during FastAPI startup."""
    secrets = await _get_secrets()
    username = secrets[get_env_specific_secret_key('postgresql_uname')]
    password = secrets[get_env_specific_secret_key('postgresql_pwd')]
    host = secrets[get_env_specific_secret_key('postgresql_host')]

    postgres_connection_string = (
        f"postgresql://{username}:{password}@{host}:5432/creditmemo"
    )
    await initialize_main_connection_pool(postgres_connection_string)

async def cancel_health_check_tasks():
    """Cancel health check tasks for both connection pools."""
    global _main_health_check_task, _agent_health_check_task

    if _main_health_check_task:
        _main_health_check_task.cancel()
        try:
            await _main_health_check_task
        except asyncio.CancelledError:
            logger.info("Main health check task cancelled successfully")
        _main_health_check_task = None

    if _agent_health_check_task:
        _agent_health_check_task.cancel()
        try:
            await _agent_health_check_task
        except asyncio.CancelledError:
            logger.info("Agent health check task cancelled successfully")
        _agent_health_check_task = None


async def close_main_connection_pool():
    """Close the main connection pool."""
    global _connection_pool

    await cancel_health_check_tasks()

    async def close_pool_safely(pool, pool_name):
        if pool:
            try:
                await pool.close()
                # Give the pool workers a moment to shut down cleanly
                await asyncio.sleep(0.1)
            except Exception as e:
                logging.warning(f"Error closing {pool_name}: {e}")

    await close_pool_safely(_connection_pool, "main connection pool")
    _connection_pool = None


async def close_agent_connection_pool():
    """Close the agent connection pool and cleanup storage."""
    global _connection_pool_agent, _checkpointer, _store

    # Cleanup global storage components
    _checkpointer = None
    _store = None

    async def close_pool_safely(pool, pool_name):
        if pool:
            try:
                await pool.close()
                # Give the pool workers a moment to shut down cleanly
                await asyncio.sleep(0.1)
            except Exception as e:
                logging.warning(f"Error closing {pool_name}: {e}")

    await close_pool_safely(_connection_pool_agent, "agent connection pool")
    _connection_pool_agent = None


# async def close_engine():
#     """Close the engine connection."""
#     global _engine
#     if _engine:
#         try:
#             await _engine.dispose()  # Dispose the engine safely
#             await asyncio.sleep(0.1)
#         except Exception as e:
#             logging.warning(f"Error closing engine: {e}")
#     _engine = None


async def close_connection_pool():
    """Close both main and agent connection pools and cleanup storage. Call this during FastAPI shutdown."""
    await close_main_connection_pool()
    await close_agent_connection_pool()
    #await close_engine()


def get_connection_pool() -> Optional[AsyncConnectionPool]:
    """Get the global connection pool."""
    return _connection_pool


def get_connection_pool_agent() -> Optional[AsyncConnectionPool]:
    """Get the global connection pool for agent."""
    return _connection_pool_agent


def get_checkpointer():
    """Get the global checkpointer instance."""
    return _checkpointer


def get_store():
    """Get the global store instance."""
    return _store


# def set_llm_db_cache(cache, engine_name: str = "in_memory_store") -> None:
#     """
#     Set the langchain global LLM cache compatible
#     with the langchain model classes using the recommender
#     setter func.

#     Args:
#         cache: The cache instance to set
#         engine_name: Name of the cache engine for logging
#     Returns:
#         None
#     """

#     if os.getenv("ENABLE_CACHE", "false").lower() in ("true", "1", "yes"):
#         logger.info(f"Enabling Global LLM cache with {engine_name}")
#         set_llm_cache(cache)
#     else:
#         logger.info("Global LLM cache is disabled")
