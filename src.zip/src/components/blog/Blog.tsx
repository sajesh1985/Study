import {
  badgeAppearance,
  Divider,
  H1,
  MediaFigure,
  MediaObject,
  PageTitle,
  Icon,
  Card,
  CardHeader,
  CardBody,
  Badge,
  InputField,
  Button,
  Link,
  H4,
  MediaBody,
} from '@spglobal/react-components';
import React, { useState } from 'react';
import { useSelector } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { config, FocusAreaLoadElement, useMessageBus } from '@spglobal/spa';
import { useFlag } from '@spglobal/featureflags';
import { BELL, BLOCKED } from '@spglobal/koi-icons';
import { useUserTraits } from '@spglobal/userprofileservice';
import { logMostPopular, logUsage } from '@spglobal/loggingservice';
import { getRelevantDomainURL } from '../../utils/urlUtilities';
import { ErrorTemplate } from './ErrorTemplate';

export interface IBlog {
  EditorsPicksData?: any[];
  FeatureActiveResult?: any[];
  FeatureNameData?: any[];
  FeatureNewsData?: any[];
}

const setImageSrc = (originalSrc: string): string => {
  const onPremURL = getRelevantDomainURL(config('onPremRootPath'), true);
  let imgSrc = originalSrc;
  if (originalSrc) {
    if (originalSrc.indexOf('http') === 0) {
      imgSrc = onPremURL + originalSrc.split('/').slice(-2).join('/');
    } else {
      imgSrc = onPremURL + originalSrc;
    }
    imgSrc = imgSrc.replace('Platform09', '/InteractiveX/Images/Platform09/');
  }
  return imgSrc;
};

export const Blog: React.FC<IBlog> = ({ FeatureNewsData }) => {
  const { t: dashboardStrings } = useTranslation(['dashboard']);
  const notificationsEnabled = useFlag('fflag_header_notificationpanel');
  const [menuIsVisible, setMenuIsVisible] = React.useState(true);
  // this implementation for spg-webplatform
  const userSession = useSelector((state?) => {
    return state?.userSession;
  });
  // this recommended implementation for spg-webplatform-core
  const traits = useUserTraits(['email', 'lastName', 'firstName', 'internalUser']);
  const messageBus = useMessageBus();
  const [textInput, setTextInput] = useState<string>();
  const searchParams = new URLSearchParams(location.search);

  // publish a message
  const sendMessage = () => {
    messageBus.main.next({
      type: 'test-click', // needs to be unique
      payload: {
        textInput,
      },
    });
  };

  const openLeftMenu = () => {
    messageBus.main.next({
      type: 'left_nav', // needs to be unique
      payload: {
        visible: !menuIsVisible,
      },
    });
    setMenuIsVisible(!menuIsVisible);
  };

  const logPageUsage = () => {
    logUsage(
      {
        keyPage: 0,
        usage: {
          keyForeignLanguage: 0,
        },
      },
      traits?.internalUser
    )
      .then(() => window.alert('logUsage hit was successful!'))
      .catch((err) => console.error(err));
  };

  const logPageMostPopular = () => {
    const keyArticle = searchParams.get('id');

    logMostPopular([keyArticle])
      .then(() => window.alert('logMostPopular hit was successful!'))
      .catch((err) => console.error(err));
  };

  const handleInput = React.useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    setTextInput(event.target.value);
  }, []);

  return (
    <>
      <div className="spg-container">
        <div className="spg-row spg-justify-center">
          <div className="spg-col spg-col-6@md spg-col-6@xl">
            <H1>{dashboardStrings('mfeTitle')}</H1>
          </div>
        </div>
      </div>
      <div className="spg-col">
        <div className="spg-mt-xl">
          <b>Following concepts are included with this template project.</b>
        </div>
        <div className="spg-mt-xl">1. Created functional component to get blogs data</div>
        <div className="spg-mt-xl">2. How to use CCA components</div>
        <div className="spg-mt-xl">3. How to get text from resource file</div>
        <div className="spg-mt-xl">4. How to resolve Image path for specific domain</div>
        <div className="spg-mt-xl">5. Unit testing framework setup with unit tests examples</div>
        <div className="spg-mt-xl">
          <Link href="#user_profile_example">6. How to use user profile</Link>
        </div>
        {/*Hide for standalone mode and durandal spa*/}
        {userSession?.isLoggedIn && traits && (
          <>
            <div className="spg-mt-xl">
              <Link href="#hydra_blogs_example">7. How to use headless hydra api call</Link>
            </div>
            <div className="spg-mt-xl">
              <Link href="#feature_flags_example">8. How to use feature flags</Link>
            </div>
            <div className="spg-mt-xl">
              <Link href="#message_bus_example">9. How to use MessageBus</Link>
            </div>
            <div className="spg-mt-xl">
              <Link href="#logging_example">10. How to use Logging</Link>
            </div>
            <div className="spg-mt-xl">
              <Link href="#error_example">11. How to use Error</Link>
            </div>
          </>
        )}

        <div className="spg-mt-xl">
          <b>Note:</b> Check <b>Dashboard.tsx</b> file in your newly created MFE template to
          understand the implementation.{' '}
        </div>
      </div>
      <Divider />
      <div id="user_profile_example" className="spg-m-sm" />
      <Card hasBorder>
        <CardHeader title="User Profile Example" />
        <CardBody className="spg-text-medium">
          <Badge className="spg-mb-sm">Sample</Badge>
          <div className="spg-align-center">
            <b className="spg-text spg-text-bold">
              {dashboardStrings('impersonationBannerInfoBadge')}:
            </b>
            {traits
              ? ` ${traits.lastName}, ${traits.firstName} | ${traits.email}`
              : ` ${userSession?.userInformation?.email}`}
          </div>
        </CardBody>
      </Card>
      {/*Hide for standalone and durandal spa*/}
      {userSession?.isLoggedIn && traits && (
        <>
          <div id="feature_flags_example" className="spg-m-sm" />
          <Card hasBorder>
            <CardHeader title="@spglobal/featureflags Example" />
            <CardBody className="spg-text-medium">
              <p>
                Example of reading the <code>fflag_header_notificationpanel</code> feature flag from
                LaunchDarkly.
              </p>
              <p>
                <Badge purpose={badgeAppearance.seventh} className="spg-mb-sm">
                  Note:
                </Badge>
                if the feature flag enabled you should see the <i>Notifications Enabled</i>
                text with a bell in the sample section below.
              </p>
              <Badge className="spg-mb-sm">Sample</Badge>
              <div>
                Notifications{' '}
                {notificationsEnabled ? (
                  <>
                    Enabled <Icon icon={BELL} />
                  </>
                ) : (
                  <>
                    Disabled <Icon icon={BLOCKED} />
                  </>
                )}
              </div>
            </CardBody>
          </Card>
          <div id="message_bus_example" className="spg-m-sm" />
          <Card hasBorder>
            <CardHeader title="MessageBus Example" />
            <CardBody className="spg-text-medium">
              <p>
                Example of creating the <code>test-click</code> event using MessageBus, and
                subscribing to this event.
              </p>
              <p>
                <Badge purpose={badgeAppearance.seventh} className="spg-mb-sm">
                  Note:
                </Badge>{' '}
                click <i>{menuIsVisible ? 'Close' : 'Open'} Left Menu</i> button to trigger{' '}
                <code>left_nav</code> event that is processed by core&apos;s{' '}
                <code>LeftHandMenu</code> component
              </p>
              <Badge className="spg-mb-sm">Sample</Badge>
              <div className="spg-d-flex spg-align-center spg-w-50">
                <InputField
                  placeholder="Enter message as a payload for MessageBus testing"
                  onInput={handleInput}
                />
                <Button onClick={sendMessage} className="spg-ml-md">
                  Test
                </Button>
                <Button onClick={openLeftMenu} className="spg-ml-md">
                  {menuIsVisible ? 'Close' : 'Open'} Left Menu
                </Button>
              </div>
            </CardBody>
          </Card>
          <div id="logging_example" className="spg-m-sm" />
          <FocusAreaLoadElement name="loggingExampleCard" pagefal timeline />
          <Card hasBorder>
            <CardHeader title="Logging Example" />
            <CardBody className="spg-text-medium">
              <p>
                Example of using <code>@spglobal/loggingservice</code> that currently provides{' '}
                <code>logUsage</code> and <code>logMostPopular</code> functions to gather useful
                analytics by sending requests to <code>logging-service</code>
              </p>
              <p>
                <Badge purpose={badgeAppearance.seventh} className="spg-mb-sm">
                  Note:
                </Badge>
                to this card exmpale also applies Focus Area Load (FAL) logging that is sent to
                Kibana for analysis
              </p>
              <Badge className="spg-mb-sm">Sample</Badge>
              <div className="spg-align-center">
                <Button onClick={logPageUsage}>Log Page Usage</Button>
                <Button onClick={logPageMostPopular}>Log Most Popular</Button>
              </div>
            </CardBody>
          </Card>
          <ErrorTemplate />
          <div id="hydra_blogs_example" className="spg-m-sm" />
          <PageTitle title={dashboardStrings('blogsTitle')} />
          <Divider />
          <div className="spg-row spg-mb-lg">
            {FeatureNewsData?.length > 0 ? (
              <div className="spg-col-12">
                {FeatureNewsData.map(
                  ({ Id, ArticleType, FilePath_FilePath, Headline, DocAbstract }) => (
                    <div key={Id}>
                      <MediaObject key={Id}>
                        <MediaFigure title={ArticleType} link="#">
                          <img src={setImageSrc(FilePath_FilePath)} alt="" />
                        </MediaFigure>
                        <MediaBody>
                          <>
                            <H4>{Headline}</H4>
                            <p>{DocAbstract}</p>
                          </>
                        </MediaBody>
                      </MediaObject>
                      <Divider />
                    </div>
                  )
                )}
              </div>
            ) : (
              <div>
                <p>{dashboardStrings('noDataMessage')}</p>
              </div>
            )}
            <div className="spg-col-auto is-d-none is-d-flex@lg">
              <Divider isVertical />
            </div>
          </div>
        </>
      )}
    </>
  );
};
