import logging

from chatrd.engine.data_service.model_output_parser import base_parser

logger = logging.getLogger(__name__)


class RevenueSourceItemParser(base_parser.BaseItemParser):
    def map_look_values(self, kpqi, value_str, operator_payload, operator_text):
        return value_str, value_str, operator_payload, operator_text

    def custom_logic_before_field_search(self, key, value_str):
        return key, value_str
