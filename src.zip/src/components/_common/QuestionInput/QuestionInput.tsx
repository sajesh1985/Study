import 'regenerator-runtime';
import SpeechRecognition, { useSpeechRecognition } from 'react-speech-recognition';
import React, { useState, useEffect, useMemo, KeyboardEvent, forwardRef, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import {
  useIsBreakpoint,
  Icon,
  IconButton,
  DropDownItem,
  DropDownGroup,
  Modal,
  ModalContent,
  ModalFooter,
  ModalHeader,
  InputField,
  Tabs,
  Tab
} from '@spglobal/react-components';

import { BreakPoint, DISPLAYNAME_PREFIX, Purpose, Size } from '@spglobal/koi-helpers';
import { CLEAR } from '@spglobal/koi-icons';
import { faArrowRight, faHistory } from '@fortawesome/free-solid-svg-icons';
import { Interaction } from '../../../types/interaction';
import { useChatRD } from '../../../context/chatrd';
import ChatRDGenerateIcon from '../DoubleStarsIcon/DoubleStarsIcon';
import { GenerateInfoBlock } from '../GenerateInfoBlock/GenerateInfoBlock';

import {
  InputContainer,
  Container,
  StyledSpeechIcon,
  HistoryDropdown,
  HistoryDropdownItem,
  GenerateButton,
  CustomModalStyled,
  EditorStyled,
} from './QuestionInput.styles';

import {
  QuestionInputType,
  CurrentTabEnum,
  ResponseType,
  AtInputType,
} from './QuestionInput.types';

import { nextTabIndex, prevTabIndex } from './questionInputHelpers'
import { SpeechIcon } from '../SpeechIcon/SpeechIcon';

import { getGenerateInput } from '../../../services/api';
import { CustomModalList } from './CustomModalList';
import { TabNavigationKeys } from './TabNavigationKeys';
import {
  Editor,
  EditorState,
  Modifier,
  CompositeDecorator,
  SelectionState,
  DraftHandleValue,
  DraftEditorCommand,
  ContentBlock,
  ContentState
} from 'draft-js';
import 'draft-js/dist/Draft.css';

const handleStrategy = (
  contentBlock: ContentBlock,
  callback: (start: number, end: number) => void,
  contentState: ContentState
): void => {
  contentBlock.findEntityRanges(
    (character) => {
      const entityKey = character.getEntity();
      return (
        entityKey !== null &&
        contentState.getEntity(entityKey).getType() === 'MENTION'
      );
    },
    callback
  );
};
  
const decorator = new CompositeDecorator([
  {
    strategy: handleStrategy,
    component: (props) => {
      return <span style={{ color: '#8ab4f8' }}>{props.children}</span>;
    },
  },
]);

export const QuestionInput = forwardRef<HTMLInputElement, QuestionInputType>(
  ({ onSearch, domUpdateValue, onSearchValueUpdate,isButtonDisabled }) => {
    const { t } = useTranslation(['chatiq_main']);
    const isMobile = useIsBreakpoint(BreakPoint.MD);
    const { interactions } = useChatRD();
    const { transcript, resetTranscript, browserSupportsSpeechRecognition } =
      useSpeechRecognition();

    const [isListening, setIsListening] = useState<boolean>(false);
    const [speechSupport, setSpeechSupport] = useState<boolean>(true);
    const [allowSpeech, setAllowSpeech] = useState<boolean>(true);

    const [isAtModalOpen, setIsAtModalOpen] = useState<boolean>(false);
    
    const [atInput, setAtInput] = useState<AtInputType>({
      value:'',
      currentTab: CurrentTabEnum.none
    });

    const [atStateResponse, setAtStateResponse] = useState<ResponseType | null>(null);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [selectedTabId, setSelectedTabId] = useState(CurrentTabEnum.all);
    const [focused, setFocused] = React.useState(true);

    const textArea = useRef(null);

    const [myEditorState, getMyEditorState]=useState<string>('')
    const [tagEntities, setTagEntities]= useState<Array<{ type: string; id: string,name:string,countrycode:String,start:string, end:string }>>([]);
    
    useEffect(() => {
      const tab = isAtModalOpen ? CurrentTabEnum.all : CurrentTabEnum.none;
      
      setAtInput({
        value:'',
        currentTab: tab
      })
    }, [isAtModalOpen]);

    useEffect(() => {
      udpateTextToEditor(domUpdateValue);
      setFocused(true);
    }, [domUpdateValue]);
    const handleSearch = () => {
      if (myEditorState.toString().trim() !== '' && isButtonDisabled === false) {
        stopHandle();
        // setTimeout(() => {
          onSearch(myEditorState.trim(),tagEntities);
          clearEditor();
          onSearchValueUpdate('');
          setAtInput({value:'', currentTab: CurrentTabEnum.all});
          setTagEntities([]);
        // }, 200);
      }
    };

     const handleListing = () => {
       setIsListening(true);
       document.body.classList.add('focuseTemp');
       SpeechRecognition.startListening({
         continuous: true,
       });
      };

    const stopHandle = () => {
      SpeechRecognition.stopListening();
      document.body.classList.remove('focuseTemp');
      setIsListening(false);
      resetTranscript();
    };

    useEffect(() => {
      if (transcript) {
        udpateTextToEditor(transcript)
        if (!isListening) {
          resetTranscript();
        }
      }

      if (!browserSupportsSpeechRecognition) {
        setSpeechSupport(false);
      }
    }, [transcript, browserSupportsSpeechRecognition]);

      const IQuestions = useMemo(() => {
        const filterQuestionData = interactions?.filter(
          (item: Interaction) => item.req
        );
      const arr1 = Array.from(
          new Set(filterQuestionData?.map((filterQuestion: Interaction) => filterQuestion?.input))
        );
      const arr2 = Array.from(new Set(interactions.map((item: Interaction) => item.req && item.req.toString())));
        if(arr1 && arr1.length > 0 && arr2 && arr2.length > 0)
        {
          return arr1.concat(arr2);
        }
        else
        {
          return (arr1 && arr1.length > 0) ? arr1 : arr2;
        }
        
      }, [interactions]);

    
    /*const SQuestionsIndex = useMemo(() => {
      let selectedIndex = null;
      IQuestions.forEach((item: string, index: number) => {
        if (item == searchValue) {
          selectedIndex = index;
        }
      });
      return selectedIndex;
    }, [IQuestions, searchValue]);

    const onKeyDownHandler = (event: KeyboardEvent) => {
      if (event.key === 'Enter') {
        handleSearch();
      } else if (event.key === 'ArrowUp' && IQuestions.length > 0) {
        event.preventDefault();
        SQuestionsIndex == null
          ? setSearchValue(IQuestions[IQuestions.length - 1].toString())
          : SQuestionsIndex == 0
          ? setSearchValue(IQuestions[0].toString())
          : setSearchValue(IQuestions[SQuestionsIndex - 1].toString());
      } else if (event.key === 'ArrowDown' && IQuestions.length > 0) {
        event.preventDefault();
        SQuestionsIndex == null
          ? setSearchValue(IQuestions[0].toString())
          : SQuestionsIndex == IQuestions.length - 1
          ? setSearchValue(IQuestions[IQuestions.length - 1].toString())
          : setSearchValue(IQuestions[SQuestionsIndex + 1].toString());
      }
    };*/

    const handleSpeechIconClick = () => {
      navigator.mediaDevices
        .getUserMedia({ audio: true, video: false })
        .then(() => {
          isListening ? stopHandle() : handleListing();
        })
        .catch(() => {
          setAllowSpeech(false);
        });
    };

    useEffect(() => {
      const searchedValue = atInput.value;

      setIsLoading(true);
      const loadData = async () => {
        const activeTab = atInput.currentTab;
        try {
          let response:ResponseType | null = null;
          if (activeTab !== CurrentTabEnum.none) {
            response = await getGenerateInput(searchedValue, activeTab);
            setAtStateResponse(response);
          }
          setIsLoading(false);
        } catch (error) {
          console.error('Fetch error', error);
          setIsLoading(false);
        }
      };

      const timerId = setTimeout(loadData, 2000);

      return () => {
        clearTimeout(timerId);
        if (isLoading) setIsLoading(false);
      };
       
    }, [atInput.currentTab, atInput.value]);

    const handleCloseCustomModal = () => {
      setIsAtModalOpen(false);
      setFocused(true);
      setAtStateResponse(null);
      setAtInput({ value: '', currentTab: CurrentTabEnum.none });
      setSelectedTabId(CurrentTabEnum.all);
    };
    
    const handleUpdateGenerativeInput = (res: ResponseType) => {
      const partBeforeSpecialSymbol = res.name.split('›')[0].trim();
      let trimmedSymbol=partBeforeSpecialSymbol;
      const regex = /\)\s*(.+)/;
      const match = partBeforeSpecialSymbol.match(regex);
      if(match)
      {
        trimmedSymbol = match[1];
      }
      let entityType = res.additionalFields?.find((field) => field.fieldName.toLowerCase() === 'entity_type' ||
      field.fieldName.toLowerCase() === 'entitytype')?.fieldValue;
      let countryCode ='';
      if(!(entityType && entityType !== 'null'))
      {
        entityType = res.additionalFields?.find((field) => field.fieldName.toLowerCase() === 'entitytypefct')?.fieldValue;
      }
      if(entityType.toLowerCase() === 'geographies')
      {
        countryCode = res.additionalFields?.find((field) => field.fieldName.toLowerCase() === 'keycountry')?.fieldValue;
      }
      const id = res.additionalFields?.find((field) => field.fieldName.toLowerCase() === 'keyuniversalentity' || field.fieldName.toLowerCase() === 'asidid')?.fieldValue;
      const startIndex = myEditorState.length + 1;
      const endIndex = myEditorState.length + 1 + trimmedSymbol.length;
      setTagEntities([...tagEntities, { type: entityType, id: id, name: trimmedSymbol,countrycode : countryCode,start:startIndex.toString(), end:endIndex.toString()}]);
      
      handleCloseCustomModal();
      handleInsertText(trimmedSymbol);
    };

    const handleAtInputOnChange = (event: React.ChangeEvent<HTMLInputElement>) => {
      const value: string = event.target.value;

      if (value.endsWith('>') || value.endsWith('<')) {
        return;
      }

      setAtInput({ ...atInput, value: event.target.value });
    };

    useEffect(() => {
      const handleKeyDown = (event: KeyboardEvent) => {
        if (isAtModalOpen) {
          if ((event.shiftKey && event.key === '>') || (event.shiftKey && event.key === 'ArrowRight')){
            const newTab = nextTabIndex(atInput.currentTab);
            setAtInput({ ...atInput, currentTab: newTab });
            setSelectedTabId(newTab);
          } else if ((event.shiftKey && event.key === '<') || (event.shiftKey && event.key === 'ArrowLeft')) {
            const newTab = prevTabIndex(atInput.currentTab);
            setAtInput({ ...atInput, currentTab: newTab });
            setSelectedTabId(newTab);
          }
        }
      };

      document.addEventListener('keydown', handleKeyDown as unknown as EventListener);

      return () => {
        document.removeEventListener('keydown', handleKeyDown as unknown as EventListener);
      };
    }, [atInput.currentTab, isAtModalOpen]);

    const [editorState, setEditorState] = useState(EditorState.createEmpty(decorator));

    const clearEditor = () => {
      setEditorState(EditorState.createEmpty(decorator))
    }

    useEffect(() => {
      getMyEditorState(editorState.getCurrentContent().getPlainText())
      let currentContent = editorState.getCurrentContent().getPlainText();
      let isModified=false;
      for(var k=0;k<tagEntities.length;k++)
      {
        if(!currentContent.includes(tagEntities[k].name))
        {
          tagEntities.splice(k,1);
          isModified = true;
          break;
        }
      }
      if(isModified)
      {
          for(var k=0;k<tagEntities.length;k++)
          {
            if(currentContent.includes(tagEntities[k].name))
            {
              tagEntities[k].start = (currentContent.indexOf(tagEntities[k].name)).toString();
              tagEntities[k].end = (parseInt(tagEntities[k].start) + tagEntities[k].name.length).toString();
            }
          }
      }
    },[editorState]);

    const udpateTextToEditor = (addText:string) => {
      const emptyEditorState = EditorState.createEmpty(decorator);
      const currentContent = emptyEditorState.getCurrentContent();
      const currentSelection = emptyEditorState.getSelection();
      const textWithInsert = Modifier.insertText(
        currentContent,
        currentSelection,
        addText
      )
      const newState = EditorState.push(emptyEditorState, textWithInsert, 'insert-characters');
      setEditorState(newState);
    }
     
    const handleBeforeInput = (
      chars: string, 
    ): DraftHandleValue => {
      if (chars === '@') {
        setIsAtModalOpen(true);
        return 'handled';
      }
      return 'not-handled';
    };
     
    const handleInsertText = (tempText:string): void => {
      const currentContent = editorState.getCurrentContent();
      const currentSelection = editorState.getSelection();
      const contentStateWithEntity = currentContent.createEntity('MENTION', 'MUTABLE', { text: tempText });
      const entityKey = contentStateWithEntity.getLastCreatedEntityKey();
      const textWithEntity = Modifier.insertText(
        currentContent,
        currentSelection,
        ` ${tempText}`,
        null,
        entityKey
      );
      const newState = EditorState.push(editorState, textWithEntity, 'insert-characters');

      setEditorState(EditorState.forceSelection(newState, textWithEntity.getSelectionAfter()));
      setIsAtModalOpen(false);
      setFocused(true);
    };

    useEffect(() => { 
      if (textArea?.current && !isAtModalOpen && focused) {
        textArea?.current?.focus();
      }
    }, [editorState,isAtModalOpen,focused]);

    const unFocus = () => {
      setTimeout(() => {
              if (focused) setFocused(false)
          }, 300);
    }
    
    const focus =() => {
      if(!focused)setFocused(true)
    }
     
    const handlePastedText = (text: string, html: string | undefined, editorState: EditorState): DraftHandleValue => {
      // Handle pasted text here
      const currentText = editorState.getCurrentContent().getPlainText();
      if(currentText.length + text.length > 250)
      {
        if(html)
        return 'handled';
      }

      return 'not-handled';
    };

    const handleKeyCommand = (command: DraftEditorCommand, editorState: EditorState): DraftHandleValue => {
      if (command === 'backspace') {
        const selection = editorState.getSelection();
        if (selection.isCollapsed()) {
          const contentState = editorState.getCurrentContent();
          const startKey = selection.getStartKey();
          const startOffset = selection.getStartOffset();
          const blockWithLinkAtBeginning = contentState.getBlockForKey(startKey);
          const entityKey = blockWithLinkAtBeginning.getEntityAt(startOffset - 1);
    
          if (entityKey) {
            blockWithLinkAtBeginning.findEntityRanges(
              character => character.getEntity() === entityKey,
              (start, end) => {
                const entitySelection = SelectionState.createEmpty(startKey).merge({
                  anchorOffset: start,
                  focusOffset: end,
                });
                const contentStateWithoutEntity = Modifier.removeRange(contentState, entitySelection, 'backward');
                const newState = EditorState.push(editorState, contentStateWithoutEntity, 'delete-character');
                setEditorState(EditorState.forceSelection(newState, entitySelection.merge({
                  anchorOffset: start,
                  focusOffset: start
                })));
              }
            );
            return 'handled';
          }
        }
      }
      if (command === 'split-block') {
        handleSearch();
        return 'handled';
      }

      return 'not-handled';
    };

    return (
      <>
        <CustomModalStyled>
          <Modal
            ariaLabel="Modal"
            canEscapeKeyClose
            canOutsideClickClose
            style={{
              marginLeft: 'var(--size-space-10xl)',
              position: 'absolute',
              bottom: '60px',
            }}
            size={Size.LARGE}
            isOutlined
            slideFromTop
            hasBackdrop
            onClose={() => {
              handleCloseCustomModal();
            }}
            usePortal={false}
            isOpen={isAtModalOpen}
          >
            <ModalHeader title={''} style={{ padding: '16px 16px 2px 16px' }}>
              <InputField
                autoFocus
                componentSize={Size.MEDIUM}
                inFieldLabel=""
                maxLength={30}
                onChange={(event: React.ChangeEvent<HTMLInputElement>) =>
                  handleAtInputOnChange(event)
                }
                value={atInput.value}
                skeletonConfig={{
                  animation: true,
                  loading: false,
                }}
                type="text"
              />
            </ModalHeader>
            <ModalContent style={{ maxHeight: '200px', overflow: 'auto' }}>
              <Tabs
                style={{overflow: 'hidden' }}
                alignment="left"
                isPrimary={false}
                leftElement={null}
                moreButtonTitle=""
                resizeDelay={300}
                rightElement={null}
                selectedTabId={selectedTabId}
                showMore
                skeletonConfig={{
                  animation: true,
                  loading: false,
                }}
                tabsContainerTabIndex={-1}
              >
                <Tab
                  id={CurrentTabEnum.all}
                  title="All"
                  selected={selectedTabId === CurrentTabEnum.all ? true : false}
                  onClick={() => {
                    setAtInput({ ...atInput, currentTab: CurrentTabEnum.all });
                  }}
                  onClickCapture={() => {
                    setAtInput({ ...atInput, currentTab: CurrentTabEnum.all });
                  }}
                >
                  <CustomModalList
                    isLoading={isLoading}
                    listData={atStateResponse?.destinations}
                    handleItemClick={handleUpdateGenerativeInput}
                    highlightText={atInput.value}
                  />
                </Tab>

                <Tab
                  id={CurrentTabEnum.companies}
                  title="Companies"
                  selected={selectedTabId === CurrentTabEnum.companies ? true : false}
                  onClick={() => {
                    setAtInput({ ...atInput, currentTab: CurrentTabEnum.companies });
                  }}
                  onClickCapture={() => {
                    setAtInput({ ...atInput, currentTab: CurrentTabEnum.companies });
                  }}
                >
                  <CustomModalList
                    isLoading={isLoading}
                    listData={atStateResponse?.destinations}
                    handleItemClick={handleUpdateGenerativeInput}
                    highlightText={atInput.value}
                  />
                </Tab>

                <Tab
                  id={CurrentTabEnum.fixed_income}
                  title="Fixed Income"
                  selected={CurrentTabEnum.fixed_income ? true : false}
                  onClick={() => {
                    setAtInput({ ...atInput, currentTab: CurrentTabEnum.fixed_income });
                  }}
                  onClickCapture={() => {
                    setAtInput({ ...atInput, currentTab: CurrentTabEnum.fixed_income });
                  }}
                >
                  <CustomModalList
                    isLoading={isLoading}
                    listData={atStateResponse?.destinations}
                    handleItemClick={handleUpdateGenerativeInput}
                    highlightText={atInput.value}
                  />
                </Tab>
              </Tabs>
            </ModalContent>
            <ModalFooter style={{ textAlign: 'left' }}>
              <TabNavigationKeys />
            </ModalFooter>
          </Modal>
        </CustomModalStyled>
        <Container>
          <InputContainer>
            <EditorStyled>
              <Editor
                ref={textArea}
                editorState={editorState}
                onChange={setEditorState}
                handleBeforeInput={handleBeforeInput}
                handleKeyCommand={handleKeyCommand}
                handlePastedText={handlePastedText}
                onBlur={unFocus}
                onFocus={focus}
              />
            </EditorStyled>
            <span>
              <IconButton
                icon={CLEAR}
                size={Size.MEDIUM}
                onClick={() => { clearEditor() }}
                active={true}
              />
            </span>
            {interactions.length > 0 && (
              <HistoryDropdown
                mobileMenuTitle={t('questionInput.questionsHistory')}
                disablePortal={true}
                transitionContainerClassName={'historyWrapper'}
                triggerElement={
                  <StyledSpeechIcon>
                    <Icon icon={faHistory} size={Size.MEDIUM} />
                  </StyledSpeechIcon>
                }
              >
                <DropDownGroup>
                  {IQuestions.map((question: string, index: number) => (
                    question && <DropDownItem key={index} selected={question == editorState.getCurrentContent().getPlainText() ? true : false}>
                      <HistoryDropdownItem
                        size={Size.LARGE}
                        onClick={() => udpateTextToEditor(IQuestions[index].toString())}
                      >
                        {question}
                      </HistoryDropdownItem>
                    </DropDownItem>
                  ))}
                </DropDownGroup>
              </HistoryDropdown>
            )}
            <div style={{cursor: 'pointer'}}  title="Entity Recognition: Use the '@' symbol to specify the entity you're looking to search for" >@</div>
            {speechSupport && (
              <SpeechIcon
                allowSpeech={allowSpeech}
                isListening={isListening}
                handleSpeechIconClick={handleSpeechIconClick}
              />
          )}
          <GenerateButton
              leftIcon={isMobile ? null : <ChatRDGenerateIcon fill={isButtonDisabled ? 'var(--button-color-disabled)' : '#8AB4F8'}/>}
            purpose={Purpose.MARKETING}
              onClick={handleSearch}
              disabled={isButtonDisabled}
            >
              {isMobile ? <Icon icon={faArrowRight} /> : 'Generate'}
            </GenerateButton>
          </InputContainer>
          <GenerateInfoBlock />
        </Container>
      </>
    );
  }
);

QuestionInput.displayName = `${DISPLAYNAME_PREFIX}.QuestionInput`;
