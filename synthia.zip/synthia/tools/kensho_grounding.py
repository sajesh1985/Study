from mcp.server.fastmcp import FastMCP, Context
from fastapi import FastAPI, APIRouter, Request
import logging
import httpx
from contextlib import asynccontextmanager
import contextlib
import jwt
import time
import os

from src.synthia.config.api_config import get_config
from src.synthia.utils.logging_config import configure_logging
from src.synthia.utils.source import Source
from src.synthia.aws_utils.aws_client import get_aws_client, get_secret, get_env_specific_secret_key
from src.synthia.tools.mcp_responses import (
    MCPResponse
)
from src.synthia.tools.research_articles import get_secrets
from src.synthia.user_profile.auth_strategy import has_datasource_access

from . import auth

# Configure logging
logger = configure_logging(logger_name=__name__, log_file='kensho_grounding.log')

mcp: FastMCP = FastMCP("Kensho Grounding MCP", stateless_http=True)
logger.info("Kensho Grounding MCP Server starting up...")

router = APIRouter()
async_client: httpx.AsyncClient = None
ALL_APPLICATION_SCOPES = "kensho:app:grounding-router"


async def get_access_token_from_key(client_id, scope=ALL_APPLICATION_SCOPES):
    # Get configuration
    cfg = get_config()
    kensho_authentication_url = cfg.get("kensho_authentication_url")
    kensho_private_pem_key = cfg["kensho_private_pem_key"]

    synthia_secret = await get_secrets()
    kensho_private_pem = synthia_secret[get_env_specific_secret_key(kensho_private_pem_key)]
    logger.info(f"Generating access token for client_id: {client_id} with scope: {scope}")
    iat = int(time.time())
    encoded = jwt.encode(
        {
            "aud": kensho_authentication_url,
            "exp": iat + (30 * 60),  # expire in 30 minutes
            "iat": iat,
            "sub": client_id,
            "iss": client_id,
        },
        kensho_private_pem,
        algorithm="RS256",
    )
    
    global async_client
    response = await async_client.post(
        kensho_authentication_url,
        headers={
            "Content-Type": "application/x-www-form-urlencoded",
            "Accept": "application/json",
        },
        data={
            "scope": scope,
            "grant_type": "client_credentials",
            "client_assertion_type": "urn:ietf:params:oauth:client-assertion-type:jwt-bearer",
            "client_assertion": encoded,
        }
    )
    
    if response.status_code != 200:
        logger.error(f"Failed to get access token: {response.status_code} - {response.text}")
        raise Exception(f"Failed to get access token: {response.status_code} - {response.text}")
    return response.json()["access_token"]

global KENSHO_ACCESS_TOKEN
KENSHO_ACCESS_TOKEN = None

@mcp.tool()
async def get_data_from_transcripts_filings(query: str ) -> MCPResponse:
    """Fetches data chunks from the transcripts and filings dataset based on the provided query.
    
    This tool searches through earnings call transcripts and SEC filings using Kensho's grounding API
    to find relevant content based on your query.
    
    Args:
        query (str): The grounding query string (e.g., "What did Apple say about revenue in their last earnings call?")
    
    Returns:
        MCPResponse: The response containing grounding data with the following structure:
            - sources: List of Source objects with title and URL
            - data: List of dictionaries containing:
                - content: The actual text content from the transcript/filing
                - financial_quarter: Quarter number (1-4)
                - financial_year: Year (e.g., 2025)
                - industry_name: Industry classification
                - instn_name: Company name
                - filing_date: Date of filing (if applicable)
                - event_date: Date of the event (earnings call date)
                - file_type: Type of document (e.g., "Earnings Call")
                - document_type: Document classification
                - source_uri: Direct link to the source document (matched from sources list)
            - isError: Boolean indicating if there was an error
            - message: Status message
    
    Note: Each data row's source_uri is matched with the corresponding Source object in the sources list
    based on index position, providing proper citation and linking between data and its source.
    
    Example Response:
        MCPResponse(
            sources=[Source(title="CapIQ Pro", url="https://www.capitaliq.spglobal.com/apisv3/spg-webplatform-core/docviewer?mid=243123059")],
            data=[{
                "content": "We are pleased to report revenue growth of 15% this quarter...",
                "financial_quarter": 3,
                "financial_year": 2025,
                "industry_name": "Technology",
                "instn_name": "Apple Inc.",
                "filing_date": null,
                "event_date": "2025-06-20",
                "file_type": "Earnings Call",
                "document_type": "Earnings Call",
                "source_uri": "https://www.capitaliq.spglobal.com/apisv3/spg-webplatform-core/docviewer?mid=243123059"
            }],
            isError=False,
            message="Grounding data retrieved successfully."
        )
    """
    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    headers = raw_request.headers
    logger.info(f"Headers received: {headers}")
    auth_headers = auth.build_auth_headers(raw_request)
    auth_token = auth_headers.get("Authorization", "")

    if not await has_datasource_access(auth_token, "Transcripts"):
        logger.error("User does not have KOS \"Transcripts\" access.")
        return MCPResponse(
            sources=None,
            data=None,
            isError=True,
            message="No Relevant Data Available"
        )

    query = query.strip()
    allowed_datasets = ["transcripts_filings_agent"]
    return await get_grounding_results(query, allowed_datasets=allowed_datasets)

#@mcp.tool()
async def get_data_from_financial_statements(query: str) -> MCPResponse:
    """Fetches grounding data from the financial statements dataset based on the provided query.
    Args:
        query (str): The grounding query string.
    Returns:
        MCPResponse: The response containing grounding data or error information.
    """
    query = query.strip()
    allowed_datasets = ["multiples_stocks"]
    return await get_grounding_results(query, allowed_datasets=allowed_datasets)


async def get_grounding_results(query: str, allowed_datasets: list ) -> MCPResponse:
    """
    Invokes the grounding API with the provided query and allowed_datasets, and returns the result in MCP format.

    Args:
        query (str): The grounding query string.
        allowed_datasets (list): List of allowed datasets for the grounding API.

    Returns:
        MCPResponse: The response containing grounding data or error information.
    """
    # Get configuration
    cfg = get_config()
    kensho_grounding_api_url = cfg.get("kensho_grounding_api_url")
    KENSHO_CLIENT_ID = cfg.get("kensho_client_id")
    
    logger.info(f"get_grounding_results called for query: {query}, allowed_datasets: {allowed_datasets}")
    global KENSHO_ACCESS_TOKEN
    if KENSHO_ACCESS_TOKEN is None:   
        KENSHO_ACCESS_TOKEN = await get_access_token_from_key(KENSHO_CLIENT_ID)
    
    kensho_auth_headers = {
        "Authorization": f"Bearer {KENSHO_ACCESS_TOKEN}",
        "Content-Type": "application/json",
    }
    payload = {
        "query": query,
        "allowed_datasets": allowed_datasets
    }
    try:
        global async_client
        response = await async_client.post(kensho_grounding_api_url, json=payload, headers=kensho_auth_headers)
        if response.status_code == 200:
            api_data = response.json()
            logger.info(f"Grounding API response: {api_data}")
            problems_data = api_data.get("problems", [])
            if problems_data:
                logger.error(f"Grounding API returned problems: {problems_data}")
                return MCPResponse(
                        sources=None,
                        data=None,
                        isError=True,
                        message=f"Grounding API returned problems: {problems_data}"
                    )
            
            grounded_data = api_data.get("response", [])
            mcp_data = []
            mcp_sources = []
            for item in grounded_data:
                if item.get("representation_type") == "tabular":
                    datarows = item.get("data", [])
                    source_rows = item.get("sources", [])
                    # Create a mapping of source index to URI for quick lookup
                    source_uri_map = {}
                    for idx, source_row in enumerate(source_rows):
                        source_uri = source_row.get("source", {}).get("uri", "")
                        source_uri_map[idx] = source_uri
                        mcp_sources.append(Source(title=source_row.get("source", {}).get("name", ""), url=source_uri))
        
                    # Add URI to each data row
                    for idx, row in enumerate(datarows):
                        # Add the corresponding URI to the row data
                        if idx in source_uri_map:
                            row["source_uri"] = source_uri_map[idx]
                        mcp_data.append(row)

            logger.info(f"Grounding data returned: {mcp_data}")
            return MCPResponse(
                sources=mcp_sources,
                data=mcp_data,
                isError=False,
                message="Grounding data retrieved successfully."
            )
        elif response.status_code == 204:
            logger.info("No grounding data found for the given query.")
            source = Source(title="Kensho grounding api url", url=kensho_grounding_api_url)
            return MCPResponse(
                sources=source,
                data=[{"message": "No grounding data found for the given query."}],
                isError=False,
                message="No grounding data found for the given query."
            )
        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return MCPResponse(
                sources=None,
                data=None,
                isError=True,
                message=f"{response.status_code} - {response.text}"
            )
    except httpx.RequestError as e:
        logger.error(f"Request failed: {e}")
        return MCPResponse(
            sources=None,
            data=None,
            isError=True,
            message=f"Request failed: {e}"
        )

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Initializing Grounding MCP server task group...")
    global async_client
    async_client = httpx.AsyncClient(timeout=10)
    async with contextlib.AsyncExitStack() as stack:
        await stack.enter_async_context(mcp.session_manager.run())
        yield
    await async_client.aclose()

@router.get("/kensho-grounding/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "ok"}

# Create FastAPI app with lifespan
app = FastAPI(lifespan=lifespan)
app.mount("/kensho-grounding", mcp.streamable_http_app())
app.include_router(router)
logger.info("Kensho Grounding MCP Server started successfully.")