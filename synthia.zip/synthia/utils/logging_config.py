import logging
import os
from typing import Dict, Any, Optional, List


def configure_logging(
    log_file: str = 'synthia.log', 
    level: int = logging.INFO,
    module_levels: Optional[Dict[str, int]] = None,
    quiet_modules: Optional[List[str]] = None
):
    """
    Configure logging with customized settings.
    
    Args:
        log_file: Name of the log file
        level: Default logging level
        module_levels: Dict of module names and their specific log levels
        quiet_modules: List of module names to set to WARNING level
    """
    logging_handlers = [
        logging.StreamHandler()  # Always log to console
    ]
    
    # Add file handler if running locally or explicitly requested
    if os.environ.get("RUNNING_LOCALLY", "true").lower() in ("true", "1", "yes"):
        logging_handlers.append(logging.FileHandler(log_file))

    for handler in logging_handlers:
        handler.setFormatter(CustomFormatter())

    # Configure basic logging
    logging.basicConfig(
        level=level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(module)s - Line: %(lineno)d - %(message)s',
        handlers=logging_handlers
    )
    
    # Set specific module log levels if provided
    if module_levels:
        for module_name, module_level in module_levels.items():
            logging.getLogger(module_name).setLevel(module_level)
    
    # Set noisy modules to WARNING level
    default_quiet_modules = [
        "httpcore.http11",
        "httpx",
        "urllib3",
        "httpcore",
        "asyncio",
        "charset_normalizer"
    ]
    
    # Combine default and user-specified quiet modules
    all_quiet_modules = default_quiet_modules
    if quiet_modules:
        all_quiet_modules.extend(quiet_modules)
    
    # Set all quiet modules to WARNING level
    for module in all_quiet_modules:
        logging.getLogger(module).setLevel(logging.WARNING)
        
    # Return logger for the calling module
    return logging.getLogger()


class CustomFormatter(logging.Formatter):
    blue = "\x1b[34m"
    grey = "\x1b[38m"
    yellow = "\x1b[33m"
    red = "\x1b[31m"
    bold_red = "\x1b[31;1m"
    reset = "\x1b[0m"
    log_format = "%(asctime)s - %(name)s - %(levelname)s - %(message)s (%(filename)s:%(lineno)d)"

    FORMATS = {
        logging.DEBUG: blue + log_format + reset,
        logging.INFO: grey + log_format + reset,
        logging.WARNING: yellow + log_format + reset,
        logging.ERROR: red + log_format + reset,
        logging.CRITICAL: bold_red + log_format + reset
    }

    def format(self, record):
        log_fmt = self.FORMATS.get(record.levelno)
        formatter = logging.Formatter(log_fmt)
        return formatter.format(record)
