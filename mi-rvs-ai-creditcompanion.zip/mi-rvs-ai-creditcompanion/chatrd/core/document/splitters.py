import copy
import logging
import uuid
from abc import ABC, abstractmethod
from collections.abc import Sequence
from typing import Any

from chatrd.core.document.schema import ArticleType, Document
from chatrd.core.document.text_splitters import RecursiveCharacterTextSplitter
from chatrd.core.document.utils import (
    _clean_commentary_xml,
    _clean_criteria_xml,
    _clean_definitions_xml,
    _clean_research_xml,
    _split_commentary_md,
    _split_commentary_xml,
    _split_criteria_xml,
    _split_definitions_xml,
    _split_research_xml,
)

logger = logging.getLogger(__name__)


class DocumentSplitter(ABC):
    @abstractmethod
    def split_text(self, text: str) -> Any:
        pass

    @abstractmethod
    def split_document(self, document: Document) -> Any:
        pass

    @abstractmethod
    def split_documents(self, documents: Sequence[Document]) -> Any:
        pass


class RecursiveCharacterDocumentSplitter(DocumentSplitter):
    def __init__(self, chunk_size: int = 4096, chunk_overlap: int = 400) -> None:
        self.text_splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap)

    def split_text(self, text: str) -> Sequence[str]:
        return self.text_splitter.split_text(text)

    def split_document(self, document: Document) -> Sequence[Document]:
        splitted_documents = []
        for chunk in self.split_text(document.content):
            metadata = copy.deepcopy(document.metadata)
            metadata["id"] = str(uuid.uuid4())
            splitted_documents.append(Document(content=chunk, metadata=metadata))
        return splitted_documents

    def split_documents(self, documents: Sequence[Document]) -> Sequence[Document]:
        splitted_documents = []
        for document in documents:
            splitted_documents.extend(self.split_document(document))
        return splitted_documents


class XMLDocumentSplitter(DocumentSplitter):
    def __init__(self) -> None:
        return None

    def split_text(self, text: str, article_type: ArticleType) -> tuple[Sequence[str], Sequence[dict]]:

        if article_type == ArticleType.CRITERIA:
            cleaned_text = _clean_criteria_xml(text)
            return _split_criteria_xml(cleaned_text)
        elif article_type == ArticleType.RESEARCH:
            cleaned_text = _clean_research_xml(text)
            return _split_research_xml(cleaned_text)
        elif article_type == ArticleType.DEFINITIONS:
            cleaned_text = _clean_definitions_xml(text)
            return _split_definitions_xml(cleaned_text)
        elif article_type == ArticleType.COMMENTARY:
            cleaned_text = _clean_commentary_xml(text)
            return _split_commentary_xml(cleaned_text)
        else:
            logger.error(f"the article type {article_type} is not supported")
            raise ValueError("Invalid Article Type")

    def split_document(self, document: Document, article_type: ArticleType) -> Sequence[Document]:

        splitted_documents = []
        for chunk, chunk_metadata in zip(*self.split_text(document.content, article_type=article_type)):
            metadata = copy.deepcopy(document.metadata)
            metadata["id"] = str(uuid.uuid4())
            metadata.update(chunk_metadata)
            splitted_documents.append(Document(content=chunk, metadata=metadata))
        return splitted_documents

    def split_documents(self, documents: Sequence[Document], article_type: ArticleType) -> Sequence[Document]:

        splitted_documents = []
        for document in documents:
            splitted_documents.extend(self.split_document(document, article_type=article_type))
        return splitted_documents


class MarkdownDocumentSplitter(DocumentSplitter):
    def __init__(self) -> None:
        return None

    def split_text(self, text: str, article_type: ArticleType) -> list[str]:

        if article_type == ArticleType.COMMENTARY:
            # cleaned_text = _clean_commentary_md(text)
            return _split_commentary_md(text)
        else:
            logger.error(f"the article type {article_type} is not supported")
            raise ValueError("Invalid Article Type")

    def split_document(self, document: Document, article_type: ArticleType) -> Sequence[Document]:

        splitted_documents = []
        for chunk, chunk_metadata in zip(*self.split_text(document.content, article_type=article_type)):
            metadata = copy.deepcopy(document.metadata)
            metadata["id"] = str(uuid.uuid4())
            metadata.update(chunk_metadata)
            splitted_documents.append(Document(content=chunk, metadata=metadata))
        return splitted_documents

    def split_documents(self, documents: Sequence[Document], article_type: ArticleType) -> Sequence[Document]:

        splitted_documents = []
        for document in documents:
            splitted_documents.extend(self.split_document(document, article_type=article_type))
        return splitted_documents
