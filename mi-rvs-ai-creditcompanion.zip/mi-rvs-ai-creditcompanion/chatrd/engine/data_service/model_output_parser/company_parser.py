import logging
from datetime import timedelta

import dateutil.parser as parser

from chatrd.engine.data_service.model_output_parser import base_parser
from chatrd.engine.data_service.model_output_parser.utils import (
    GenerateRatingList,
    _format_rating_list_values,
    validate_rating_string,
)
from chatrd.engine.data_service.model_output_parser.variables import (
    GLOBAL_CREDIT_RATING_MAPPING,
)

logger = logging.getLogger(__name__)


class CompanyItemParser(base_parser.BaseItemParser):
    def custom_logic_before_field_search(self, key, value_str):
        return key, value_str

    # Overwrite the method for rating use cases.
    def map_look_values(self, kpqi, value_str, operator_payload, operator_text):
        if kpqi in [334045, 334235]:
            value_str = value_str.lower()
            # validate rating or credit watch input strings
            value_str, operator_payload, operator_text = validate_rating_string(
                kpqi, value_str, operator_payload, operator_text
            )
            # post-process rating list for payload
            if "," in value_str:
                if operator_payload == 1:
                    values_to_remove = [value.strip() for value in value_str.split(",")]
                    value_str = GLOBAL_CREDIT_RATING_MAPPING.copy()
                    for value in values_to_remove:
                        value_str.remove(value)
                    value_str = ", ".join(value_str)
                operator_payload = 7
                operator_text = "in"
                lookup_value = _format_rating_list_values([item.strip().upper() for item in value_str.split(",")])
                lookup_value_text = lookup_value
            elif operator_payload == 3:
                operator_payload = 7
                operator_text = "in"
                value_list = GenerateRatingList().greater_than(value_str)
                lookup_value = _format_rating_list_values(value_list)
                lookup_value_text = lookup_value
            elif operator_payload == 6:
                operator_payload = 7
                operator_text = "in"
                value_list = GenerateRatingList().equal_greater_than(value_str)
                lookup_value = _format_rating_list_values(value_list)
                lookup_value_text = lookup_value
            elif operator_payload == 5:
                operator_payload = 7
                operator_text = "in"
                value_list = GenerateRatingList().equal_less_than(value_str)
                lookup_value = _format_rating_list_values(value_list)
                lookup_value_text = lookup_value
            elif operator_payload == 2:
                operator_payload = 7
                operator_text = "in"
                value_list = GenerateRatingList().less_than(value_str)
                lookup_value = _format_rating_list_values(value_list)
                lookup_value_text = lookup_value
            elif operator_payload == 17:
                operator_payload = 7
                operator_text = "in"
                value_list = GenerateRatingList().between(value_str)
                lookup_value = _format_rating_list_values(value_list)
                lookup_value_text = lookup_value
            else:
                lookup_value = value_str
                lookup_value_text = value_str
        elif kpqi in [336004, 336003, 333833]:
            if operator_payload == 0:
                operator_payload = 17
                operator_text = "between"
                start_date = parser.parse(value_str)
                end_date = start_date + timedelta(days=1)
                lookup_value = base_parser._format_between_two_dates(start_date, end_date)
                lookup_value_text = lookup_value
            elif operator_payload == 26:
                lookup_value, operator_payload = base_parser.check_dynamic_time_window(
                    kpqi, value_str, operator_payload
                )
                lookup_value_text = lookup_value
                operator_text = "between"
            else:
                lookup_value = value_str
                lookup_value_text = value_str
        else:
            lookup_value = value_str
            lookup_value_text = value_str
        return lookup_value, lookup_value_text, operator_payload, operator_text
