﻿// Copyright Notice!
// This document is protected under the trade secret and copyright
// laws as the property of Fidelity National Information Services, Inc.
// Copying, reproduction or distribution should be limited and only to
// employees with a “need to know” to do their job.
// Any disclosure of this document to third parties is strictly prohibited.
// © 2017 Fidelity National Information Services.
// All rights reserved worldwide.
Type.registerNamespace("Fis.Epp.EPaymentsUI.DeviceSupport");

/// <summary>
/// Registers and dispatches callback functions.
/// </summary>
Fis.Epp.EPaymentsUI.DeviceSupport.CallbackDispatcher = (function () {
    var instance;
    if (instance) {
        return instance;
    }
    instance = this;

    this._callbackRegistry = {};
    this._DEFAULT_METHOD_COLLECTION_KEY = "Fis.Epp.EPaymentsUI.DeviceSupport.CallbackDispatcher.default_key";

    /// <summary>
    /// Registers a callback function.
    /// </summary>
    /// <param name="object">The object on which to apply the callback. In most cases 'this' would be passed in.</param>
    /// <param name="callback">The callback function to register.</param>
    /// <param name="callbackKey">Unique identifier for the callback function.</param>
    this.registerCallback = function (object, callback, callbackKey) {
        if (typeof callback !== 'function') {
            return;
        }

        this._callbackRegistry[callbackKey] = {
            "object": object,
            "callback": callback
        };
    },

        /// <summary>
        /// Invokes a registered callback.
        /// </summary>
        /// <param name="args">Array of arguments to be passed to the callback.</param>
        /// <param name="callbackKey">Unique identifier for the callback function.</param>
        this.dispatchCallback = function (args, callbackKey) {
            var callbackObject = null;
            if (this._callbackRegistry[callbackKey] !== null) {
                callbackObject = this._callbackRegistry[callbackKey];
            }

            if (callbackObject !== null && callbackObject["callback"] !== null) {
                try {
                    callbackObject["callback"].apply(callbackObject["object"], args);
                } catch (exception) {
                    if (console && console.log && typeof (console.log) === "function") {
                        console.log(exception);
                    }
                }
            }
        };

    return instance;
}());

// Global native callback method
Fis.Epp.EPaymentsUI.DeviceSupport.GlobalNativeResponseHandler = function (nativeResponseJSON) {
    Fis.Epp.EPaymentsUI.DeviceSupport.CallbackDispatcher.dispatchCallback([nativeResponseJSON], nativeResponseJSON.callbackKey);
};

// Cordova platform support
Fis.Epp.EPaymentsUI.DeviceSupport._isCordova = false;
Fis.Epp.EPaymentsUI.DeviceSupport._cordovaPluginMetadata;
Fis.Epp.EPaymentsUI.DeviceSupport.registerCordova = function (cordova, cordovaPluginMetadata) {
    if (cordova) {
        window.cordova = cordova;
        Fis.Epp.EPaymentsUI.DeviceSupport._isCordova = true;
        Fis.Epp.EPaymentsUI.DeviceSupport._cordovaPluginMetadata = cordovaPluginMetadata;
    }
};

function NativeRoutingParameters(bridgeId, methodId) {
    this.bridgeId = bridgeId;
    this.methodId = methodId;
};

/// <summary>
/// Bridge to a native device. Abstracts away device specific details.
/// </summary>
Fis.Epp.EPaymentsUI.DeviceSupport.DeviceBridge = function (isEnabled) {

    this._isEnabled = (typeof isEnabled === 'boolean' && isEnabled === true)
        || (typeof isEnabled === 'string' && isEnabled.toLowerCase() === 'true') ? true : false;
    this._platform = null;
    this._metadata = null;
    this._callbackDispatcher = Fis.Epp.EPaymentsUI.DeviceSupport.CallbackDispatcher;
    this._eventProduct = null;
    this._contactBridgeId = "deviceContactBridge";
    this._imageBridgeId = "deviceImageBridge";
    this._eventNotificationBridgeId = "deviceWebEventBridge";
    this._nativeResponseHandlerMethodName = "Fis.Epp.EPaymentsUI.DeviceSupport.GlobalNativeResponseHandler";
    this._UIWebViewURLPrefix = "fisdigitalpaymentsdevicebridge://127.0.0.1/Bridge?";
    this._imageRoutingParameters = new NativeRoutingParameters(this._imageBridgeId, "getImage");
    this._selectImageRoutingParameters = new NativeRoutingParameters(this._imageBridgeId, "selectImage");
    this._shareImageRoutingParameters = new NativeRoutingParameters(this._imageBridgeId, "shareImage");
    this._printImageRoutingParameters = new NativeRoutingParameters(this._imageBridgeId, "printImage");
    this._contactRoutingParameters = new NativeRoutingParameters(this._contactBridgeId, "getContacts");
    this._pickContactRoutingParameters = new NativeRoutingParameters(this._contactBridgeId, "pickContact");
    this._webEventRoutingParameters = new NativeRoutingParameters(this._eventNotificationBridgeId, "raiseEvent");
    this._registerHandlerRoutingParameters = new NativeRoutingParameters(this._eventNotificationBridgeId, "registerNativeMessageHandler");

    this.PLATFORMS = {
        ANDROID: "android",
        IOS: "ios",
        IOS_LEGACY: "ios_legacy",
        CORDOVA: "cordova"
    };

    this.MESSAGE_CODE = {
        PERMISSION_DENIED: "PERMISSION_DENIED",
        PERMISSION_PERMANENTLY_DENIED: "PERMISSION_PERMANENTLY_DENIED",
        BRIDGE_EXECUTION_FAILED: "BRIDGE_EXECUTION_FAILED",
        BRIDGE_REQUEST_PROCESSING_FAILED: "BRIDGE_REQUEST_PROCESSING_FAILED",
        BRIDGE_RESPONSE_PROCESSING_FAILED: "BRIDGE_RESPONSE_PROCESSING_FAILED",
        EVENT_RAISED: "EVENT_RAISED",
        NAVIGATE_BACK: "NAVIGATE_BACK"
    };

    this.MESSAGE_TYPE = {
        INFORMATION: "INFORMATION",
        WARNING: "WARNING",
        ERROR: "ERROR",
        ACTION_REQUEST: "ACTION_REQUEST"
    };

    this.EVENT_TYPE = {
        INFORMATION: "INFORMATION",
        ERROR: "ERROR",
        COMPLETED: "COMPLETED",
        STARTED: "STARTED",
        ENROLLMENT_COMPLETED: "ENROLLMENT_COMPLETED",
        PAYMENT_ADDED: "PAYMENT_ADDED",
        PAYMENT_MODIFIED: "PAYMENT_MODIFIED",
        PAYMENT_DELETED: "PAYMENT_DELETED",
        PAYEE_ADDED: "PAYEE_ADDED",
        PAYEE_MODIFIED: "PAYEE_MODIFIED",
        PAYEE_DELETED: "PAYEE_DELETED",
        BACK_BUTTON: "BACK_BUTTON"
    };

    this.PRODUCT = {
        PLATFORM: "PLATFORM",
        BILL_PAY: "BILL_PAY",
        PEOPLE_PAY: "PEOPLE_PAY",
        TRANSFERS: "TRANSFERS",
        ZELLE: "ZELLE"
    };

    this._init();
};

Fis.Epp.EPaymentsUI.DeviceSupport.DeviceBridge.prototype = {

    _init: function () {
        this._platform = this._detectPlatform();
        this._metadata = this._getMetadata();
    },

    _detectPlatform: function () {
        var platform = null;

        if (window.FISDigitalPaymentsDeviceBridge) {
            platform = this.PLATFORMS.ANDROID;
        }

        if (platform === null && window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.FISDigitalPaymentsDeviceBridge) {
            platform = this.PLATFORMS.IOS;
        }

        if (platform === null) {
            var userAgent = window.navigator.userAgent.toLowerCase();
            var ios = /iphone|ipod|ipad/.test(userAgent);
            if (ios) {
                var standalone = window.navigator.standalone;
                var safari = /safari/.test(userAgent);
                if (!standalone && !safari) {
                    platform = this.PLATFORMS.IOS_LEGACY;
                }
            }
        }

        return platform;
    },

    _getMetadata: function() {
        var onReceiveMetadata = function(result) {
            if (result.isSuccessful) {
                this._metadata = result.data;
            }
        };

        var nativeRoutingParameters = new NativeRoutingParameters("deviceMetadataBridge", "getMetadata");
        return this._routeNative(this, onReceiveMetadata, "getMetadata", nativeRoutingParameters);
    },

    selectImage: function (object, callback, options) {
        var callbackKey = options && options.callbackKey ? options.callbackKey : this._selectImageRoutingParameters.methodId;

        this._routeNative(object, callback, callbackKey, this._selectImageRoutingParameters);
    },

    /// <summary>
    /// Gets the contacts from the device.
    /// </summary>
    getContacts: function (object, callback, options) {
        var callbackKey = options && options.callbackKey ? options.callbackKey : this._contactRoutingParameters.methodId;
        return this._routeNative(object, callback, callbackKey, this._contactRoutingParameters);
    },

    /// <summary>
    /// Captures image with phone camera.
    /// </summary>
    captureImage: function (object, callback, options) {
        var callbackKey = options && options.callbackKey ? options.callbackKey : this._imageRoutingParameters.methodId;
        return this._routeNative(object, callback, callbackKey, this._imageRoutingParameters);
    },

    /// <summary>
    /// Share image with other applications.
    /// </summary>
    shareImage: function (object, callback, options) {
        var callbackKey = options && options.callbackKey ? options.callbackKey : this._shareImageRoutingParameters.methodId;
        var methodParams = {
                    "shareContent": options
                };
        return this._routeNative(object, callback, callbackKey, this._shareImageRoutingParameters, methodParams);
    },

    /// <summary>
    /// Share image with other applications.
    /// </summary>
    printImage: function (object, callback, options) {
        var callbackKey = options && options.callbackKey ? options.callbackKey : this._printImageRoutingParameters.methodId;
        var methodParams = {
                    "printContent": options
                };
        return this._routeNative(object, callback, callbackKey, this._printImageRoutingParameters, methodParams);
    },

    pickContact: function (object, callback, options) {

        var callbackKey = options && options.callbackKey ? options.callbackKey : this._pickContactRoutingParameters.methodId;

        if (options && options.disableFallback) {
            this._routeNative(object, callback, callbackKey, this._pickContactRoutingParameters);
        }
        else {
            var metadata = this.getMetadata();
            if (metadata &&
                metadata.supportedMethods &&
                metadata.supportedMethods.contacts &&
                metadata.supportedMethods.contacts.includes("PICK_CONTACT")) {

                this._routeNative(object, callback, callbackKey, this._pickContactRoutingParameters);
            }
            else {
                this.getContacts(object, callback, options);
            }
        }
    },

    /// <summary>
    /// Sets the product to be used for all events. Used only when a specific product is not provided in a raise event call.
    /// </summary>
    setEventProduct: function (product) {
        this._eventProduct = product;
    },

    /// <summary>
    /// Raises event to device that can be handled with native code.
    /// </summary>
    raiseEvent: function (object, callback, eventId, eventType, options) {

        var callbackKey = options && options.callbackKey ? options.callbackKey : this._webEventRoutingParameters.methodId;

        var eventProduct = options && options.eventProduct ? options.eventProduct : this._eventProduct;
        options = this._extendOptionsEventProperties(options, eventType, eventProduct);

        var methodParams = {
            "eventId": eventId,
            "eventType": options.eventType,
            "eventProduct": options.eventProduct,
            "eventParams": options.eventParams
        };

        return this._routeNative(object, callback, callbackKey, this._webEventRoutingParameters, methodParams);
    },

    registerNativeMessageHandler: function (object, callback) {
        var registered = false;
        var metadata = this.getMetadata();
        if (metadata &&
            metadata.supportedMethods &&
            metadata.supportedMethods.contacts &&
            metadata.supportedMethods.contacts.includes("REGISTER_NATIVE_MESSAGE_HANDLER")) {

             registered = this._routeNative(object, callback, this._registerHandlerRoutingParameters.methodId, this._registerHandlerRoutingParameters);

        } else {
            registered = false;
        }

        return registered;
    },

    getIsEnabled: function () {
        return this._isEnabled;
    },

    setIsEnabled: function (isEnabled) {
        this._isEnabled = isEnabled;
    },

    getPlatform: function () {
        // Cordova set via global, refactor to hold device config as singleton
        if (Fis.Epp.EPaymentsUI.DeviceSupport._isCordova === true) {
            this._platform = this.PLATFORMS.CORDOVA;
        }

        return this._platform;
    },

    getMetadata: function (object, callback) {
        // Cordova set via global, refactor to hold device config as singleton
        if (this.getPlatform() === this.PLATFORMS.CORDOVA) {
            this._metadata = Fis.Epp.EPaymentsUI.DeviceSupport._cordovaPluginMetadata;
        }

        return this._metadata;
    },

    _routeNative: function (object, callback, callbackKey, nativeRoutingParameters, methodParameters) {
        var routed = false;
        var platform = this.getPlatform();

        if (platform && this._isEnabled) {

            this._callbackDispatcher.registerCallback(object, callback, callbackKey);

            // Legacy IOS support. Can be removed once all clients have upgraded to version 2+ of the SDK.
            if (platform === this.PLATFORMS.IOS_LEGACY) {
                var url = this._createIOSUIWebViewURL(nativeRoutingParameters, callbackKey, methodParameters);
                window.location = url;
                routed = true;
            }
            else {
                var bridgeJSONMessage = this._createBridgeJSONMessage(nativeRoutingParameters, callbackKey, methodParameters);

                switch (platform) {
                    case this.PLATFORMS.ANDROID:
                        try {
                            window.FISDigitalPaymentsDeviceBridge.postMessage(JSON.stringify(bridgeJSONMessage));
                            routed = true;
                        } catch (exception) {
                            this._log(exception);
                        }
                        break;
                    case this.PLATFORMS.CORDOVA:
                        try {
                            var log = this._log;
                            cordova.exec(function () { }, function (error) { log(error); }, 'FISDigitalPaymentsSDKCordovaPlugin', 'getContacts', [bridgeJSONMessage]);
                            routed = true;
                        } catch (exception) {
                            this._log(exception);
                        }
                        break;
                    case this.PLATFORMS.IOS:
                        try {
                            webkit.messageHandlers.FISDigitalPaymentsDeviceBridge.postMessage(JSON.stringify(bridgeJSONMessage));
                            routed = true;
                        } catch (exception) {
                            this._log(exception);
                        }
                        break;
                }
            }
        }
        return routed;
    },

    _extendOptions: function (options, extensions) {
        if (!options) {
            options = {};
        }

        for (var extension in extensions) {
            if (extensions.hasOwnProperty(extension)) {
                options[extension] = extensions[extension];
            }
        }

        return options;
    },

    _extendOptionsEventProperties: function (options, eventType, productType) {
        var eventOptions = {
            "eventType": eventType,
            "eventProduct": productType
        };
        return this._extendOptions(options, eventOptions);
    },

    _createBridgeJSONMessage: function (nativeRoutingParameters, callbackKey, params) {
        var bridgeJSONMessage = {
            "bridge": nativeRoutingParameters.bridgeId,
            "method": nativeRoutingParameters.methodId,
            "callback": this._nativeResponseHandlerMethodName,
            "callbackKey": callbackKey,
            "params": params ? params : {}
        };

        return bridgeJSONMessage;
    },

    _createIOSUIWebViewURL: function (nativeRoutingParameters, callbackKey, params) {
        var url = this._UIWebViewURLPrefix + "bridge=" + nativeRoutingParameters.bridgeId + "&method=" + nativeRoutingParameters.methodId + "&callback=" + this._nativeResponseHandlerMethodName;

        if (callbackKey) {
            url += "&callbackKey=" + callbackKey;
        }

        if (params) {
            for (var key in params) {
                if (params.hasOwnProperty(key)) {
                    url += "&p-" + key + "=" + params[key];
                }
            }
        }

        return url;
    },

    _log: function (object) {
        if (console && console.log && typeof (console.log) === "function") {
            console.log(object);
        }
    }
};
