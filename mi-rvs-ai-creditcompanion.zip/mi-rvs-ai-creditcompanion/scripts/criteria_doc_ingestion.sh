#!/bin/bash

set -e

PROJ_FOLDER=$( dirname -- "$0"; )

# python ${PROJ_FOLDER}/open_search_ingestion.py \
#         --index-name "chatrd-criteria-dev" \
#         --input-file-path "s3://sagemaker.us-east-1.mi-ds-chatrd-dev/tmp/criteria_df_combined_v2.csv" \
#         --text-col-name "CLOB_DATA" \
#         --metadata-col-names "ARTICLE_ID,sourceObjectId,SOURCE_TITLE,ARTICLE_DATE,PRIMARY_SECTOR_CODE,PRIMARY_SUB_SECTOR_CODE,TYPE_OF_CRITERIA,SUBTYPE_OF_CRITERIA" \
#         --output-file-path "s3://sagemaker.us-east-1.mi-ds-chatrd-dev/dev/splitted_criteria_docs.parquet" \
#         --n-samples 5
#         --is-criteria

python ${PROJ_FOLDER}/open_search_ingestion.py \
        --index-name "chatrd-criteria-dev" \
        --input-file-path "s3://sagemaker.us-east-1.mi-crs-chatrd-dev/dev/dataset/criteria_df_combined_v2.csv" \
        --text-col-name "CLOB_DATA" \
        --metadata-col-names "ARTICLE_ID,sourceObjectId,SOURCE_TITLE,ARTICLE_DATE,PRIMARY_SECTOR_CODE,PRIMARY_SUB_SECTOR_CODE,TYPE_OF_CRITERIA,SUBTYPE_OF_CRITERIA" \
        --output-file-path "s3://sagemaker.us-east-1.mi-crs-chatrd-dev/dev/processed/splitted_criteria_docs.parquet" \
        --is-criteria