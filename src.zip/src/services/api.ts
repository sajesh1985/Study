import axios, { AxiosResponse } from 'axios';
import { ConfigKey, config } from '@spglobal/spa';

import {
  InteractionRequestResponse,
  SessionFeedbackRequestPayload,
  InteractionRequestPayload,
  InteractionFeedbackRequestPayload,
  ChatHistoryRequestPayload,
  ChatHistoryResponse,
  ChatSessionHistoryRequestPayload,
  ArchiveSessionRequestPayload,
  MIToken
} from '../types/api';
import { Feedback, Sentiment } from '../types/interaction';
import axiosSecurityInstance from './securityAxios';
import {
  TYPEAHEAD_CARD_NAMES_ALL, 
  TYPEAHEAD_CARD_NAMES_COMPANIES, 
  TYPEAHEAD_CARD_NAMES_FIXED_INCOMES,
  TYPEAHEAD_CARD_NAMES_TRENDING,
} from '../constants/constants';

async function makeApiRequest<P, R>(endpoint: string, payload: P): Promise<R> {
  const apiRootPath = config('onCloudRootPath');
  const chatRDApiRoot = `${apiRootPath}apisv3/chatrd-service/v1`;
  const response = await axios.post<R>(`${chatRDApiRoot}/${endpoint}/`, payload, {
    timeout: 120000, // 120s
  });
  return response.data;
}

export async function makeDashboardApiRequest<P, R>(payload: P): Promise<R> {
  const apiRootPath = config('onCloudRootPath');
  const chatRDApiRoot = `${apiRootPath}apisv3/chatrd-service/v1/Dashboard/feedbackdata/`;

  const response = await axios.post<R>(`${chatRDApiRoot}`, payload, {
    timeout: 120000, // 120s
  });

  return response.data;
}

export async function makeDashboardUserInputAnswerApiRequest<R>(endpoint: string,): Promise<R> {
  const apiRootPath = config('onCloudRootPath');
  const chatRDApiRoot = `${apiRootPath}apisv3/chatrd-service/v1/Dashboard/session/${endpoint}`;

  const response = await axios.get<R>(`${chatRDApiRoot}`, {
    timeout: 120000, // 120s
  });

  return response.data;
}

export async function getGenerateInput(
  request: string,
  typeaheadCardNames: string
){
  return await makeApiRequestGenerateInput('OmniSuggest/suggest', request, typeaheadCardNames);
}

export async function makeApiRequestGenerateInput<P, R>(endpoint: string, payload: P, typeaheadCardNames:string): Promise<R> {
  const apiRootPath = config('onCloudRootPath');
  const chatRDApiRoot = `${apiRootPath}apisv3/search-service/v3`;
  let maxResults = 15;
  let requestTypeaheadCardNames:string[];
  
  if (typeaheadCardNames === 'All') {
    requestTypeaheadCardNames = TYPEAHEAD_CARD_NAMES_ALL;
  } else if (typeaheadCardNames === 'Companies') {
    requestTypeaheadCardNames =TYPEAHEAD_CARD_NAMES_COMPANIES;
  } else if (typeaheadCardNames === 'Fixed_income') {
    requestTypeaheadCardNames =TYPEAHEAD_CARD_NAMES_FIXED_INCOMES;
  } 
  
  if (!payload) {
    requestTypeaheadCardNames = TYPEAHEAD_CARD_NAMES_TRENDING;
    maxResults=3;
  }

  const adapted_payload = {
    'query': payload,
    'max_results': maxResults,
    'typeahead_card_names': requestTypeaheadCardNames,
  }
  const response = await axios.post<R>(`${chatRDApiRoot}/${endpoint}`, adapted_payload, {
    timeout: 120000, // 120s
  });

  /*let filteredData = Array.isArray((response.data as any).destinations) 
    ? (response.data as any).destinations.filter((item: any) => { 
        return item?.additionalFields?.some((en: any) => (
          en.fieldName.toLowerCase() === 'rd_kos' && checkKOS(en.fieldValue)
        )
    )})
    
    : [];

  (response.data as any).destinations = filteredData;*/

  return response.data;
}

/*function checkKOS(value: string): boolean {
            if(value.indexOf(',') > -1){
              return value.match(/\[(.*?)\]/)[1].split(',').some((val: string) => RD_KOS.includes(val));
            }
            else if(value.match(/\[(.*?)\]/) && value.match(/\[(.*?)\]/)[1] !== 'null'){
              return (RD_KOS.includes(value.match(/\[(.*?)\]/)[1]));
            }
            else{
              return false;
            }
}*/


async function makeApiGetRequest<P, R>(endpoint: string, payload: P): Promise<R> {
  const apiRootPath = config('onCloudRootPath');
  const chatRDApiRoot = `${apiRootPath}apisv3/ht/chatrd-service/v1`;
  const response = await axios.get<R>(`${chatRDApiRoot}/${endpoint}/`, payload);

  return response.data;
}

export async function createInteraction(
  request: InteractionRequestPayload
): Promise<InteractionRequestResponse> {
    return makeApiRequest('chat/prompt', request);
}

export async function getChatHistory(
  request: ChatHistoryRequestPayload
): Promise<ChatHistoryResponse[]> {
  return makeApiGetRequest('chat/sessionhistory', request);
}

export async function getChatDetailsFromSession(
  request: ChatSessionHistoryRequestPayload
): Promise<ChatHistoryResponse[]> {
  return makeApiGetRequest('chat/session/'+ request.sessionId, request);
}

export async function sessionFeedback(sessionId: string, feedback: Feedback): Promise<void> {
  const payload: SessionFeedbackRequestPayload = {
    session: sessionId,
    feedback_sentiment: Sentiment.None,
    text_feedback: feedback.text,
    tags: feedback.tags,
  };
  await makeApiRequest('feedback', payload);
}

export async function interactionFeedback(
  sessionId:string,
  interactionId: string,
  feedback: Feedback
): Promise<void> {
  const payload: InteractionFeedbackRequestPayload = {
    sessionId:sessionId,
    interactionId: interactionId,
    feedback_sentiment: feedback.sentiment,
    text_feedback: feedback.text,
    tags: feedback.tags,
  };

  await makeApiRequest('chat/feedback', payload);
}

export const getStreamingAPIUrl = () => {
  const apiRootPath = config('onCloudRootPath');
  const chatRDApiRoot = `${apiRootPath}apisv3/ht/chatrd-service/v1`;
  return chatRDApiRoot + '/chat/prompt/stream';
};

export const getUserPreferences = async (): Promise<any> => {
  const url = config('storageSvc') + `v1/StoredObjects('UserPreferences_UserPreferences_chatrd_agreement')`;
  try {
    const response: AxiosResponse<any> = await axios.get(url);
    let isAck= 0;
    if(response.data && response.data.RequestJson !=='')
    {
      isAck = JSON.parse(response.data.RequestJson);
    }
    return isAck === 1 ? true : false;
  } catch (error) {
    return null;
  }
};

export  const updateUserPreferences = async () => {
  const url = `${config('storageSvc')}v1/StoredObjects`;
  const payload: any = {
    "Name": "UserPreferences_chatrd_agreement",
    "@odata.type": "#StorageService.UserPreferences",
    "StoredObjectType": "UserPreferences",
   "RequestJson": "1"
  };
  const response = await axios.post(url, payload, {
    timeout: 120000, // 120s
  });
  return response.data;
};

export async function archiveSession(
  request: ArchiveSessionRequestPayload
): Promise<InteractionRequestResponse> {
  return makeApiRequest('Chat/archive', request);
}

export async function archiveAllSession(
): Promise<InteractionRequestResponse> {
  const apiRootPath = config('onCloudRootPath');
  const chatRDApiRoot = `${apiRootPath}apisv3/chatrd-service/v1`;
  const response = await axios.post(`${chatRDApiRoot}/Chat/archiveall/`, {
    timeout: 120000, // 120s
  });

  return response.data;
}

export async function fetchMagnitudes(
  magnitude: string,
  currency: string
): Promise<any> {
  const apiRootPath = config('onCloudRootPath');
  const chatRDApiRoot = `${apiRootPath}apisv3/dataapi-service/v2/Internal/Public/DisplayMagnitude(Magnitude=%27${magnitude}%27)?currency=${currency}`;
  const response = await axios.get(`${chatRDApiRoot}`, {
    timeout: 120000, // 120s
    headers: {
      'Accept': "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
      'Accept-Encoding':"gzip, deflate, br, zstd"
    }
  });

  return response.data;
}

export async function fetchAllArchives(
): Promise<ChatHistoryResponse[]> {
  const apiRootPath = config('onCloudRootPath');
  const chatRDApiRoot = `${apiRootPath}apisv3/ht/chatrd-service/v1`;
  const response = await axios.get(`${chatRDApiRoot}/Chat/archives/`, {
    timeout: 120000, // 120s
  });

  return response.data;
}

export const exportResult = async (payload:any) => {
  const url = `${config('onCloudRootPath')}SNL.Services.Data.Service/v1/ProductQuery.svc/exportResultsRequest`;
  let tokenData: URLSearchParams;
  var tokenParam = { timeout: 120000,headers:{} };
  let token: MIToken | null;
  const payloadReq: any ={
    "productQueryRequest": JSON.parse(payload)
  };
  payloadReq.productQueryRequest.userDefinedFormulas = [];
  payloadReq.productQueryRequest.userDefinedCriteria = [];
  payloadReq.criteriaLineItems = [];
  payloadReq.productQueryRequest.functionRequests[0].reports = [];
  let report:any = {name:'Custom Screener Report',fields:payloadReq.productQueryRequest.functionRequests[0].fields,reportType:"report"};
  payloadReq.productQueryRequest.extensionPropertiesJson = '{"userDefinedFormulas":[],"hideQueryFilter":true,"queryLineToFieldMappings":{"queryLineToFieldMappings":[]},"chartDetails":[]}';
  payloadReq.criteriaLineItems.push('Export');
  payloadReq.screenName = "New Screen";
  payloadReq.type = 3;
  payloadReq.includeFunctionOptions = false;
  payloadReq.includeDynamicFieldLabels = false;
  payloadReq.exportAlias = false;
  payloadReq.sortedColumn = null;
  payloadReq.productQueryRequest.functionRequests[0].reports.push(report);

 // if(sessionStorage.getItem('security/session.accessToken'))
  //{
      const clientId = config('clientId' as ConfigKey);
      const clientSecret = config('clientSecret' as ConfigKey);
      const keyCurrentClientCodes = config('projectTrackerCode' as ConfigKey);
      tokenData = new URLSearchParams({
        grant_type: 'refresh_token',
        client_id: clientId,
        client_secret: clientSecret,
      });
      const clientCodes = createClientCodes(keyCurrentClientCodes);
      if (clientCodes) {
        Object.entries(clientCodes).forEach(([key, value]) => {
          tokenData.append(key, value);
        });
      }
      token = await axiosSecurityInstance(`${config('securitySvc')}oauth/token`, {
        method: 'POST',
        data: tokenData,
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        },
      })
      .then((tokenResponse) => tokenResponse.data as MIToken)
        .catch(() => null);
    
      if (token) {
        console.log(token);
        tokenParam.headers = { Authorization: `Bearer ${token.access_token}` }
      }
      
      
  //}
  
  const response = await axios.post(url, payloadReq, tokenParam );

  return response.data;

}

const createClientCodes = (encodedClientCodes: string): Record<string, string> => {
  if (!encodedClientCodes) {
    return null;
  }
  const decodedString = decodeURIComponent(encodedClientCodes);
  const codesArray = decodedString.split(',');
  const clientCodes: Record<string, string> = {};

  codesArray.forEach((clientCode) => {
    if (clientCode) {
      const [index, code] = clientCode.split(':');
      clientCodes[`snl[clientCodes][${index}]`] = code;
    }
  });

  return clientCodes;
};

