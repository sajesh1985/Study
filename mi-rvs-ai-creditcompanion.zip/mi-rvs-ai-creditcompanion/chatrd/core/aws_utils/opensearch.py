import aws_secretsmanager_caching
import botocore


def get_secret(secret_id: str) -> str:
    client = botocore.session.get_session().create_client("secretsmanager")
    cache_config = aws_secretsmanager_caching.SecretCacheConfig()
    cache = aws_secretsmanager_caching.SecretCache(config=cache_config, client=client)
    return cache.get_secret_string(secret_id)
