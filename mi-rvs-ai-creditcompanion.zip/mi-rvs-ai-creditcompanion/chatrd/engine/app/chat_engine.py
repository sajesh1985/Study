import logging
from importlib.resources import files
from typing import List, Optional

from chatrd.core.utils import ChatMessage, MessageRole
from chatrd.engine.components.query_analyzer import QueryAnalyzer
from chatrd.engine.components.query_analyzer.utils import TaggedEntity
from chatrd.engine.components.query_processor import QueryProcessor
from chatrd.engine.components.query_processor.query_retriever import QueryRetriever
from chatrd.engine.components.schema import (
    QueryAnalyzerInput,
    QueryAnalyzerOutput,
    QueryProcessorInput,
)
from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.patterns import RDSingleton
from chatrd.engine.responses import get_default_answer, get_default_response_output
from chatrd.engine.utils import ChatResponse

logger = logging.getLogger(__name__)

config_machinery = get_config_machinery()
DEFAULT_MODEL_NAME_FOR_ANALYZER = config_machinery.get_config_value(Constants.GeneralConstants.MODEL_NAME_FOR_ANALYZER)
DEFAULT_TEMPERATURE_FOR_ANALYZER = config_machinery.get_config_value(
    Constants.GeneralConstants.TEMPERATURE_FOR_ANALYZER
)
DEFAULT_MODEL_NAME_FOR_ANALYZER_ENTITY_EXTRACTOR = config_machinery.get_config_value(
    Constants.GeneralConstants.MODEL_NAME_FOR_ANALYZER_ENTITY_EXTRACTOR
)
DEFAULT_TEMPERATURE_FOR_ANALYZER_ENTITY_EXTRACTOR = config_machinery.get_config_value(
    Constants.GeneralConstants.TEMPERATURE_FOR_ANALYZER_ENTITY_EXTRACTOR
)
DEFAULT_MODEL_NAME_FOR_ANALYZER_SECTOR_EXTRACTOR = config_machinery.get_config_value(
    Constants.GeneralConstants.MODEL_NAME_FOR_ANALYZER_SECTOR_EXTRACTOR
)
DEFAULT_TEMPERATURE_FOR_ANALYZER_SECTOR_EXTRACTOR = config_machinery.get_config_value(
    Constants.GeneralConstants.TEMPERATURE_FOR_ANALYZER_SECTOR_EXTRACTOR
)
DEFAULT_MODEL_NAME_FOR_NONFLEX_SYNTHESIZER = config_machinery.get_config_value(
    Constants.GeneralConstants.MODEL_NAME_FOR_NONFLEX_SYNTHESIZER
)
DEFAULT_TEMPERATURE_FOR_NONFLEX_SYNTHESIZER = config_machinery.get_config_value(
    Constants.GeneralConstants.TEMPERATURE_FOR_NONFLEX_SYNTHESIZER
)

DEFAULT_MODEL_NAME_FOR_FLEX_SYNTHESIZER = config_machinery.get_config_value(
    Constants.GeneralConstants.MODEL_NAME_FOR_FLEX_SYNTHESIZER
)
DEFAULT_TEMPERATURE_FOR_FLEX_SYNTHESIZER = config_machinery.get_config_value(
    Constants.GeneralConstants.TEMPERATURE_FOR_FLEX_SYNTHESIZER
)

DEFAULT_MODEL_NAME_FOR_TOOL_CLASSIFIER = config_machinery.get_config_value(
    Constants.GeneralConstants.MODEL_NAME_FOR_TOOL_CLASSIFIER
)

DEFAULT_TEMPERATURE_FOR_TOOL_CLASSIFIER = config_machinery.get_config_value(
    Constants.GeneralConstants.TEMPERATURE_FOR_TOOL_CLASSIFIER
)

DEFAULT_MODEL_NAME_FOR_DATA_SERVICE = config_machinery.get_config_value(
    Constants.DataService.MODEL_NAME_FOR_DATA_SERVICE
)

DEFAULT_TEMPERATURE_FOR_DATA_SERVICE = config_machinery.get_config_value(
    Constants.DataService.TEMPERATURE_FOR_DATA_SERVICE
)


class RDChatEngine(metaclass=RDSingleton):
    def __init__(self):
        embeddings_uc_type_path = (
            files("chatrd.engine.data")
            .joinpath(config_machinery.get_config_value(Constants.UCType.UC_EMBEDDING_FILE_NAME))
            .resolve()
        )
        self._query_analyzer = QueryAnalyzer(
            embeddings_uc_type_path=str(embeddings_uc_type_path),
            uc_embedding_model=config_machinery.get_config_value(Constants.UCType.UC_EMBEDDING_MODEL),
        )
        self._query_retriever = QueryRetriever()
        self._query_processor = QueryProcessor()

    def chat(
        self,
        model_name_for_analyzer: Optional[str] = DEFAULT_MODEL_NAME_FOR_ANALYZER,
        temperature_for_analyzer: Optional[float] = DEFAULT_TEMPERATURE_FOR_ANALYZER,
        model_name_for_analyzer_entity_extractor: Optional[float] = DEFAULT_MODEL_NAME_FOR_ANALYZER_ENTITY_EXTRACTOR,
        temperature_for_analyzer_entity_extractor: Optional[float] = DEFAULT_TEMPERATURE_FOR_ANALYZER_ENTITY_EXTRACTOR,
        model_name_for_analyzer_sector_extractor: Optional[str] = DEFAULT_MODEL_NAME_FOR_ANALYZER_SECTOR_EXTRACTOR,
        temperature_for_analyzer_sector_extractor: Optional[float] = DEFAULT_TEMPERATURE_FOR_ANALYZER_SECTOR_EXTRACTOR,
        model_name_for_non_flex_synthesizer: Optional[str] = DEFAULT_MODEL_NAME_FOR_NONFLEX_SYNTHESIZER,
        temperature_for_non_flex_synthesizer: Optional[float] = DEFAULT_TEMPERATURE_FOR_NONFLEX_SYNTHESIZER,
        model_name_for_flex_synthesizer: Optional[str] = DEFAULT_MODEL_NAME_FOR_FLEX_SYNTHESIZER,
        temperature_for_flex_synthesizer: Optional[float] = DEFAULT_TEMPERATURE_FOR_FLEX_SYNTHESIZER,
        model_name_for_tool_classifier: Optional[str] = DEFAULT_MODEL_NAME_FOR_TOOL_CLASSIFIER,
        temperature_for_tool_classfifer: Optional[float] = DEFAULT_TEMPERATURE_FOR_TOOL_CLASSIFIER,
        model_name_for_data_service: Optional[str] = DEFAULT_MODEL_NAME_FOR_DATA_SERVICE,
        temperature_for_data_service: Optional[float] = DEFAULT_TEMPERATURE_FOR_DATA_SERVICE,
        list_of_tagged_entities: Optional[List[TaggedEntity]] = [],
        message: str = "",
        chat_history: Optional[List[ChatMessage]] = [],
        streaming: Optional[bool] = False,
        tagged_routes: Optional[str] = [],
    ) -> ChatResponse:
        if message == "":
            return get_default_answer(original_query=message)
        try:
            # Step-1: Analyzing query
            analyzer_input = QueryAnalyzerInput(
                llm=model_name_for_analyzer,
                temperature=temperature_for_analyzer,
                llm_for_entity_extractor=model_name_for_analyzer_entity_extractor,
                temperature_for_entity_extractor=temperature_for_analyzer_entity_extractor,
                llm_for_sector_extractor=model_name_for_analyzer_sector_extractor,
                temperature_for_sector_extractor=temperature_for_analyzer_sector_extractor,
                message=message,
                list_of_tagged_entities=list_of_tagged_entities,
                chat_history=chat_history,
            )
            analyzer_output = None
            try:
                analyzer_output = self._query_analyzer.execute(inputs=analyzer_input, tagged_routes=tagged_routes)
                if isinstance(analyzer_output, ChatResponse):
                    return analyzer_output
            except Exception as e:
                if tagged_routes is not None and len(tagged_routes) != 0:
                    logger.error(f"Hard Routing Failure: {e}")
                    return get_default_answer()
                logger.error(f"Error in query analyzer: {e}, calling backup retriever")
                analyzer_output = QueryAnalyzerOutput(
                    query=message,
                    uc_type="general",
                    backup=True,
                    original_query=message,
                    rephrased_query=message,
                    entities=None,
                    original_language="English",
                )
            # Step-2: Processing Query (retrieving document using OpenSearch, retrieving data using APIs, synthesizing)
            response = get_default_answer(original_query=message)
            try:
                query_processor_input = QueryProcessorInput(
                    llm_for_non_flex_synthesizer=model_name_for_non_flex_synthesizer,
                    temperature_for_non_flex_synthesizer=temperature_for_non_flex_synthesizer,
                    llm_for_flex_synthesizer=model_name_for_flex_synthesizer,
                    temperature_for_flex_synthesizer=temperature_for_flex_synthesizer,
                    llm_for_tool_classifier=model_name_for_tool_classifier,
                    temperature_for_tool_classfifer=temperature_for_tool_classfifer,
                    llm_for_data_service=model_name_for_data_service,
                    temperature_for_data_service=temperature_for_data_service,
                    message=analyzer_output.rephrased_query,
                    chat_history=[],
                    streaming=streaming,
                    analyzer_output=analyzer_output,
                )
                response = self._query_processor.execute(inputs=query_processor_input)
            except Exception as e:
                if tagged_routes is not None and len(tagged_routes) != 0:
                    logger.error(f"Hard Routing Failure: {e}")
                    return get_default_answer()
                logger.error(f"Error in query processor: {e}, checking if backup was already used")
                if analyzer_output.backup:
                    logger.error("Backup already used, returning default answer")
                    return get_default_answer(original_query=message)
                logger.error("Calling backup retriever")
                analyzer_output = QueryAnalyzerOutput(
                    query=message,
                    uc_type="general",
                    backup=True,
                    original_query=message,
                    rephrased_query=message,
                    entities=None,
                    original_language="English",
                )
                query_processor_input = QueryProcessorInput(
                    llm_for_non_flex_synthesizer=model_name_for_non_flex_synthesizer,
                    temperature_for_non_flex_synthesizer=temperature_for_non_flex_synthesizer,
                    llm_for_flex_synthesizer=model_name_for_flex_synthesizer,
                    temperature_for_flex_synthesizer=temperature_for_flex_synthesizer,
                    llm_for_tool_classifier=model_name_for_tool_classifier,
                    temperature_for_tool_classfifer=temperature_for_tool_classfifer,
                    llm_for_data_service=model_name_for_data_service,
                    temperature_for_data_service=temperature_for_data_service,
                    message=analyzer_output.rephrased_query,
                    chat_history=[],
                    streaming=streaming,
                    analyzer_output=analyzer_output,
                )
                response = self._query_processor.execute(inputs=query_processor_input)
        except Exception as e:
            if tagged_routes is not None and len(tagged_routes) != 0:
                logger.error(f"Hard Routing Failure: {e}")
            logger.error(e)
            return get_default_answer(original_query=message)
        return response

    def retrieve(
        self,
        model_name_for_analyzer: Optional[str] = DEFAULT_MODEL_NAME_FOR_ANALYZER,
        temperature_for_analyzer: Optional[float] = DEFAULT_TEMPERATURE_FOR_ANALYZER,
        model_name_for_tool_classifier: Optional[str] = DEFAULT_MODEL_NAME_FOR_TOOL_CLASSIFIER,
        temperature_for_tool_classfifer: Optional[float] = DEFAULT_TEMPERATURE_FOR_TOOL_CLASSIFIER,
        model_name_for_data_service: Optional[str] = DEFAULT_MODEL_NAME_FOR_DATA_SERVICE,
        temperature_for_data_service: Optional[float] = DEFAULT_TEMPERATURE_FOR_DATA_SERVICE,
        message: str = "",
        chat_history: Optional[List[ChatMessage]] = [],
    ) -> ChatResponse:
        if message == "":
            return get_default_answer(original_query=message)
        # Step-1: Analyzing query
        analyzer_input = QueryAnalyzerInput(
            llm=model_name_for_analyzer,
            temperature=temperature_for_analyzer,
            message=message,
            list_of_tagged_entities=[],
            chat_history=chat_history,
        )

        analyzer_output = self._query_analyzer.execute(inputs=analyzer_input)
        if isinstance(analyzer_output, ChatResponse):
            return analyzer_output
        # Step-2: Retrieving documents (OpenSearch) and data (APIs)
        retrieved_docs = self._query_retriever.execute(
            model_name_for_tool_classifier,
            temperature_for_tool_classfifer,
            model_name_for_data_service,
            temperature_for_data_service,
            analyzer_output,
        )
        return ChatResponse(
            role=MessageRole.ASSISTANT,
            content="Below are the retrieved docs:",
            source_docs=retrieved_docs,
        )
