package com.fis.digitalpayments.sdk.imaging;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.os.ResultReceiver;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.webkit.WebView;

import androidx.annotation.RequiresApi;

// Extending Activity instead of AppCompatActivity for Cordova support
public class PrintContentActivity extends Activity {

    public static final int PRINT_CONTENT_REQUEST_CODE = 1;
    public static final String PRINT_CONTENT_RESULT_RECEIVER_NAME = "PRINT_CONTENT_RESULT_RECEIVER_NAME";
    public static final String PRINT_CONTENT_RESULT_NAME = "PRINT_CONTENT_RESULT_NAME";
    public static final String PRINT_CONTENT_REQUEST_PARAM = "PRINT_CONTENT_REQUEST_PARAM";
    private WebView webView;

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getResultReceiver() != null) {
            String printContent = "";
            Bundle parameters = getIntent().getExtras();
            if (parameters != null && parameters.containsKey(PRINT_CONTENT_REQUEST_PARAM)) {
                printContent = parameters.getString(PRINT_CONTENT_REQUEST_PARAM);
            }

            webView = new WebView(this);
            webView.loadData(printContent, "text/html; charset=utf-8", "UTF-8");
            print(webView);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == PRINT_CONTENT_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                ResultReceiver resultReceiver = getResultReceiver();
                Bundle resultData = new Bundle();
                resultData.putString(PRINT_CONTENT_RESULT_NAME, "Success!");
                resultReceiver.send(RESULT_OK, resultData);
            }
        }
        finish();
    }

    private ResultReceiver getResultReceiver() {
        return getIntent().getParcelableExtra(PRINT_CONTENT_RESULT_RECEIVER_NAME);
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private void print(WebView webView) {
        try {
            PrintManager printManager = (PrintManager) this.getSystemService(Context.PRINT_SERVICE);
            PrintAttributes.Builder builder = new PrintAttributes.Builder();
            PrintDocumentAdapterWrapper printAdapter = new PrintDocumentAdapterWrapper(webView.createPrintDocumentAdapter());
            builder.setMediaSize(PrintAttributes.MediaSize.NA_LETTER);
            if (printManager != null) {
                printManager.print("My Document", printAdapter, builder.build());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private class PrintDocumentAdapterWrapper extends PrintDocumentAdapter {

        private final PrintDocumentAdapter delegate;
        public PrintDocumentAdapterWrapper(PrintDocumentAdapter adapter){
            super();
            this.delegate = adapter;
        }

        @Override
        public void onLayout(PrintAttributes printAttributes, PrintAttributes printAttributes1, CancellationSignal cancellationSignal, LayoutResultCallback layoutResultCallback, Bundle bundle) {
            delegate.onLayout(printAttributes, printAttributes1, cancellationSignal, layoutResultCallback, bundle);
        }

        @Override
        public void onWrite(PageRange[] pageRanges, ParcelFileDescriptor parcelFileDescriptor, CancellationSignal cancellationSignal, WriteResultCallback writeResultCallback) {
            delegate.onWrite(pageRanges, parcelFileDescriptor, cancellationSignal, writeResultCallback);
        }

        @RequiresApi(api = Build.VERSION_CODES.KITKAT)
        public void onFinish(){
            delegate.onFinish();
            webView.setWebViewClient(null);
            webView.removeAllViews();
            webView.destroyDrawingCache();
            webView.destroy();
            webView=null;
            finish();
        }
    }
}
