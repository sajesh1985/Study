import asyncio
import contextlib
import logging
from contextlib import asynccontextmanager
from datetime import date
from datetime import datetime, timedelta, timezone
from typing import Optional, List, Dict, Any, Tuple

import httpx
from fastapi import FastAPI, APIRouter
from fastapi import Request
from mcp.server.fastmcp import FastMCP, Context

from src.synthia.config.api_config import get_config
from src.synthia.tools.mcp_responses import (
    CompanyDescriptionDataModel,
    CompanyOfficerItem,
    MCPResponse,
    ResponseModel,
    OwnershipSummaryItem,
    TopHoldersItem,
    TopHoldersActivityChartDataItem,
    CompanyEsgScoreResponse,
    MarketCapDataResponse,
    MarketEquityDataResponse,
    SeriesResponse,
    StockChartResponse,
    CDSParSpreadMap,
    CDSParSpreadValue
)
from src.synthia.tools.types import EsgGridDataDimension, EsgChartDataScoreType
from src.synthia.utils.logging_config import configure_logging
from . import auth
from .mcp_utils import get_mcp_tool_source

# Configure logging
logger = configure_logging(logger_name=__name__, log_file='company_info.log', )

logger.info("Company Info MCP Server starting up...")
mcp: FastMCP = FastMCP("Company Info MCP Server", stateless_http=True)

omni_suggest_body = {
    "query": "<COMP_NAME>",
    "typeahead_context":
        {
            "currentKeyPageId": 1,
            "keyCannedReportsParent": 0
        },
    "max_results": 15
}

router = APIRouter()

# Create a single AsyncClient instance for
# reuse (performance optimization for Lambda)
async_client: httpx.AsyncClient = None


async def get_company_description_data(keyInstn: str, auth_headers: dict) -> dict:
    logger.info(f"Fetching Company Description")

    # Get configuration
    cfg = get_config()
    capitaliq_base_url = cfg["capitaliq_base_url"]
    company_description_url_infix = "AIReportBuilder/companyDesc/"

    url = f"{capitaliq_base_url}{company_description_url_infix}{keyInstn}"
    logger.info(f"URL for company description: {url}")

    try:
        global async_client
        response = await async_client.get(url, headers=auth_headers)
        response_json = response.json()
        company_desc_data = CompanyDescriptionDataModel(
            description=response_json.get("BusinessDescription", ""),
            long_description=response_json.get("LongBusinessDesc", ""),
            country_short_name=response_json.get("CountryShortName", ""),
            date_incorporated_year=response_json.get("DateIncorporatedYear", ""),
            sic_code_display=response_json.get("SICCodeDisplay", ""),
            nace_code_display=response_json.get("NACECodeDisplay", ""),
            naics_code_display=response_json.get("NAICSCodeDisplay", ""),
            activity_code_display=response_json.get("ActivityCodeDisplay", ""),
            FloatPercent=response_json.get("FloatPercent", ""),
            InstOwnershipPercent=response_json.get("InstOwnershipPercent", ""),
            countryKeyInstn=response_json.get("countryKeyInstn", None),
            KeyCountry=response_json.get("KeyCountry", ""),
            keyInstn=keyInstn
        )

        if response.status_code == 200:
            logger.info(f"response from company description"
                        f" tool is {response}")
            return {
                "data": company_desc_data
            }
        elif response.status_code == 204:
            logger.info(f"No content found for the given Inst ID: {keyInstn}")
            return {"data": None}
        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return {"data": None}
    except httpx.RequestError as e:
        logger.error(f"Request failed: {e}")
        return {"data": None}


def get_company_ids(suggest_result) -> dict:
    logger.info(f"Fetching Company keyInstn "
                f"response of {len(suggest_result)} records")
    try:
        destinations = suggest_result['destinations']

        max_score = None
        selected_keyInstn = None

        for data in destinations:
            keyInstn = None
            calculated_score = None

            for field in data.get('additionalFields', []):
                name = field.get('fieldName')
                if name == 'id':
                    keyInstn = field.get('fieldValue')
                elif name == 'calculated_score':
                    calculated_score = field.get('fieldValue')

            if calculated_score is not None and (max_score is None or calculated_score > max_score):
                max_score = calculated_score
                selected_keyInstn = keyInstn

    except Exception as e:
        logger.error(f"Error processing company data: {e}")
        selected_keyInstn = "No keyInstn available"
    return {"keyInstn": selected_keyInstn}


async def _fetch_cds_curve_identifiers(keyInstn: int, raw_request: Request) -> Optional[Dict[str, Any]]:
    """
    Call CDSCurveIdentifiers persisted query and select identifiers using the new logic:
    - First, filter for records with isPrimarySecurity == True and primaryTradingItem == True.
    - If exactly one record matches, choose it.
    - If multiple records match, sort by tierId (asc), then docClauseId (asc), and choose the first.

    Returns dict with {"securityId": int, "tradingItemID": int} or None.
    """
    cfg = get_config()
    GRAPH_URL = cfg["capitaliq_graphql_url"]

    payload = {
        "operationName": "CDSCurveIdentifiers",
        "extensions": {
            "persistedQuery": {
                "version": 1,
                "sha256Hash": "45a5a34faaf624ae3d89d6c88b06f2159394ff4910cd299c3e4b4f0440cd97c5"
            }
        },
        "variables": {"keyInstns": [int(keyInstn)]}
    }
    logger.info(f"CDSCurveIdentifiers payload: {payload}")

    ctx: Context = mcp.get_context()
    raw_req: Request = raw_request or ctx.request_context.request
    headers = auth.build_auth_headers(raw_req)

    global async_client
    resp = await async_client.post(GRAPH_URL, headers=headers, json=payload)
    logger.info(f"CDSCurveIdentifiers response status: {resp.status_code}")

    try:
        logger.info(f"CDSCurveIdentifiers response body: {resp.text}")
    except Exception:
        pass

    if resp.status_code != 200:
        logger.error(f"CDSCurveIdentifiers error: {resp.status_code} - {resp.text}")
        return None

    data = resp.json().get("data", {})
    items = data.get("cdsCurveIdentifiers", []) or []

    # Filter for isPrimarySecurity and primaryTradingItem
    filtered = [it for it in items if bool(it.get("isPrimarySecurity")) and bool(it.get("primaryTradingItem"))]
    selected = None
    if len(filtered) == 1:
        selected = filtered[0]
    elif len(filtered) > 1:
        # Sort by tierId asc, then docClauseId asc, handling missing values by treating them as large numbers
        def safe_int(v):
            try:
                return int(v)
            except Exception:
                return 1_000_000_000  # push missing/non-int to the end

        filtered.sort(key=lambda it: (safe_int(it.get("tierId")), safe_int(it.get("docClauseId"))))
        selected = filtered[0]
    else:
        return None

    sec_id = selected.get("securityId")
    ti_id = selected.get("tradingItemID")
    if not (sec_id and ti_id):
        return None

    logger.info(f"Selected CDS identifiers: securityId={sec_id}, tradingItemID={ti_id}")
    return selected


async def _fetch_cds_eod_par_spread(security_id: int, trading_item_id: int, start_date: str, end_date: str,
                                    raw_request: Request) -> List[Dict[str, Any]]:
    """
    Call CDSChartEODChartTab persisted query for the given ids and date range.
    Extract historicEODPriceData entries with fields: priceDate, parSpreadMidIn (if present).
    """
    cfg = get_config()
    GRAPH_URL = cfg["capitaliq_graphql_url"]
    payload = {
        "operationName": "CDSChartEODChartTab",
        "extensions": {
            "persistedQuery": {
                "version": 1,
                "sha256Hash": "449ab36e59d976218ef04f7213e9af48e7208f566990442f51f06664086e25db"
            }
        },
        "variables": {
            "tradingItemIds": [int(trading_item_id)],
            "securityIds": [int(security_id)],
            "startDate": start_date,
            "endDate": end_date,
        }
    }
    logger.info(f"CDSChartEODChartTab payload: {payload}")

    ctx: Context = mcp.get_context()
    raw_req: Request = raw_request or ctx.request_context.request
    headers = auth.build_auth_headers(raw_req)

    global async_client
    resp = await async_client.post(GRAPH_URL, headers=headers, json=payload)
    logger.info(f"CDSChartEODChartTab response status: {resp.status_code}")
    try:
        logger.info(f"CDSChartEODChartTab response body: {resp.text}")
    except Exception:
        pass

    if resp.status_code != 200:
        logger.error(f"CDSChartEODChartTab error: {resp.status_code} - {resp.text}")
        return []

    body = resp.json().get("data", {})
    all_tenor = body.get("allCDSTenorByTradingItemIds", {})
    eod = all_tenor.get("eodPriceData", {})
    hist = eod.get("historicEODPriceData", []) or []
    logger.info(f"CDSChartEODChartTab: received {len(hist)} historic EOD rows")

    out: List[Dict[str, Any]] = []
    for row in hist:
        ps = row.get("parSpreadMidIn")
        pd = row.get("priceDate")
        if ps is not None and pd:
            out.append({"priceDate": pd, "parSpreadMidIn": ps})
    if out:
        logger.info(
            f"CDS EOD sample: first={{'priceDate': out[0]['priceDate'], 'parSpreadMidIn': out[0]['parSpreadMidIn']}}; last={{'priceDate': out[-1]['priceDate'], 'parSpreadMidIn': out[-1]['parSpreadMidIn']}}")
    return out


def _aggregate_cds_series(raw_series: List[Dict[str, Any]], frequency: str) -> List[Dict[str, Any]]:
    """Down-sample raw CDS rows to the requested frequency.

    The function keeps the last available observation for each weekly or monthly
    bucket while preserving overall chronological order.

    Args:
        raw_series: List of dictionaries with keys ``priceDate`` (YYYY-MM-DD)
            and ``parSpreadMidIn``.
        frequency: One of ``daily``, ``weekly`` or ``monthly`` (already
            normalized to lowercase).

    Returns:
        A filtered list of rows matching the target frequency.
    """

    if frequency == "daily":
        return raw_series

    sorted_rows = sorted(
        (row for row in raw_series if row.get("priceDate")),
        key=lambda row: row["priceDate"],
    )

    buckets: Dict[Tuple[int, int], Dict[str, Any]] = {}
    order: List[Tuple[int, int]] = []

    for row in sorted_rows:
        price_date = row.get("priceDate")
        try:
            dt = datetime.strptime(price_date, "%Y-%m-%d")
        except Exception:
            # Skip rows with invalid dates
            continue

        if frequency == "weekly":
            iso_cal = dt.isocalendar()
            bucket_key: Tuple[int, int] = (iso_cal[0], iso_cal[1])
        else:  # monthly
            bucket_key = (dt.year, dt.month)

        if bucket_key not in buckets:
            order.append(bucket_key)
        # Since rows are sorted ascending, later assignments overwrite with the
        # last observation within the bucket.
        buckets[bucket_key] = row

    return [buckets[key] for key in order if key in buckets]


def _build_cds_par_spread_series(raw_series: List[Dict[str, Any]]) -> CDSParSpreadMap:
    """
    Convert raw EOD rows into a date-keyed CDSParSpreadMap.

    Input rows must contain:
      - priceDate: YYYY-MM-DD
      - parSpreadMidIn: numeric

    Output keys are DD-MM-YYYY with CDSParSpreadValue entries.
    """
    series_map: Dict[str, CDSParSpreadValue] = {}
    for it in raw_series:
        price_date = it.get("priceDate")
        psmi = it.get("parSpreadMidIn")
        if price_date is None or psmi is None:
            continue
        try:
            yyyy, mm, dd = price_date.split("-")
            key = f"{dd}-{mm}-{yyyy}"
        except Exception:
            key = price_date
        try:
            series_map[key] = CDSParSpreadValue(parSpreadMidIn=float(psmi))
        except Exception:
            # Skip rows with non-numeric parSpreadMidIn
            continue
    return CDSParSpreadMap(series=series_map)


async def get_company_headcount(keyInstn: int, auth_headers: dict) -> dict:
    """
    Fetch the headcount for a given company Inst ID.

    Args:
        keyInstn (int): The Inst ID to get headcount for also called as Instn ID, MI Key, KeyInstn.

    Returns:
        dict: A dictionary containing Employee headcount.
    """
    logger.info(f"get_company_headcount called for: {keyInstn}")
    keyInstnInt = int(keyInstn) if isinstance(keyInstn, str) else keyInstn
    payload = {
        "extensions": {
            "persistedQuery": {
                "version": 1,
                "sha256Hash": "a8862cad9852c3ac76b09f3ac8ce39fca24f8bc88d6f84ac633ffe637165ec0c"
            }
        },
        "variables": {
            "keyInstn": keyInstnInt
        }
    }
    # Get configuration
    cfg = get_config()
    GRAPH_URL = cfg["capitaliq_graphql_url"]
    # headers = {"Authorization": auth_headers, "Content-Type": "application/json"}
    logger.info(f"get_company_Headcount payload: {payload}")

    try:
        global async_client
        response = await async_client.post(GRAPH_URL, headers=auth_headers, json=payload)
        if response.status_code == 200:
            headcount_data = response.json()

            instn = headcount_data.get("data", {}).get("instnByKeyInstn", {})
            headcounts = instn.get("headCounts", [])
            processed_headcount = [{"count": hc.get("count")} for hc in headcounts if "count" in hc]
            first_headcount = processed_headcount[0]["count"] if processed_headcount else None

            logger.info(f"Final Headcount data: {processed_headcount}")

            return {"Headcount": first_headcount}
        elif response.status_code == 204:
            logger.info(f"No headcount data found for the given company : {keyInstn}")
            return {"Headcount": None}
        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return {"error": f"{response.status_code} - {response.text}"}
    except Exception as e:
        logger.error(f"Request failed: {e}")
        return {"error": f"Request failed: {e}"}


async def get_market_cap_data(keyInstn: int, auth_headers: dict) -> MarketCapDataResponse:
    """
    Fetch the Market Cap Data for an keyInstn.
    """
    cfg = get_config()
    GRAPHQL_URL = cfg.get("capitaliq_graphql_url")
    payload = {
        "extensions": {
            "persistedQuery": {
                "version": 1,
                "sha256Hash": "e2185ce2d278b9b3e75e380df46bc6eadd4607bdfac2ad92b0c203c1ae5b55de"
            }
        },
        "variables": {
            "keyInstn": keyInstn
        }
    }
    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(GRAPHQL_URL, json=payload, headers=auth_headers)
            logger.info(f"Market Cap API response status: {response.status_code}")
            response_json = response.json()
            if response.status_code == 200 and response_json.get("data"):
                response_data = response_json.get("data")
                equities = response_data.get("equityByKeyInstn", {}).get("equities", [])
                data = None
                if len(equities) > 0:
                    data = {}
                    data["currency"] = equities[0].get("currency", {}).get("keyCurrency")
                    data["exchange"] = equities[0].get("exchange", {}).get("shortName")
                    data["equityStats"] = equities[0].get("stats", {})
                    return MarketCapDataResponse(data=data, error=None)

                logger.info(f"No market cap data found in the response for Inst ID: {keyInstn}")
                return MarketCapDataResponse(data=None, error="No market cap data found in the response")
            elif response.status_code == 204:
                error_message = f"{response.status_code} - No Market Cap data found for the given Inst ID: {keyInstn}"
                logger.info(error_message)
                return MarketCapDataResponse(data=None, error=error_message)
            elif response.status_code == 200 and response_json.get("errors"):
                errors = response_json.get('errors', [])
                error_status = response.status_code
                message = "Unknown error"
                if len(errors) > 0:
                    error_status = errors[0].get("extensions", {}).get("http", {}).get("status", response.status_code)
                    message = errors[0].get("message", "Unknown error")
                error_message = f"{error_status} - {message}"
                logger.error(error_message)
                return MarketCapDataResponse(data=None, error=error_message)
            else:
                error_message = f"{response.status_code} - {response.text}"
                logger.error(error_message)
                return MarketCapDataResponse(data=None, error=error_message)
    except Exception as e:
        logger.error(f"Unexpected error while calling Market Cap API: {e}")
        return MarketCapDataResponse(data=None, error=f"Unexpected error: {e}")


async def get_market_equity_data(keyInstn: str, auth_headers: dict) -> MarketEquityDataResponse:
    """
    Fetch Market Equity Data for keyInstn.
    """
    cfg = get_config()
    GRAPHQL_URL = cfg.get("capitaliq_graphql_url")
    payload = {
        "extensions": {
            "persistedQuery": {
                "version": 1,
                "sha256Hash": "841227582fdc4312ffdc61d5e6766af20340965ffc7489b5fa63313aed7d7dd7"
            }
        },
        "variables": {
            "keyUniversalEntity": keyInstn
        }
    }
    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(GRAPHQL_URL, json=payload, headers=auth_headers)
            logger.info(f"Market Equity Data API response status: {response.status_code}")
            response_json = response.json()
            if response.status_code == 200 and response_json.get("data"):
                response_data = response_json.get("data")
                equity = response_data.get("equity", [])

                if len(equity) > 0:
                    return MarketEquityDataResponse(data=equity[0], error=None)

                logger.info(f"No equities found in the response for Inst ID: {keyInstn}")
                return MarketEquityDataResponse(data=None, error="No equities found in the response")
            elif response.status_code == 204:
                logger.info(f"No Market equity data found for the given Inst ID: {keyInstn}")
                error_message = f"{response.status_code} - No Market equity data found"
                return MarketEquityDataResponse(data=None, error=error_message)
            elif response.status_code == 200 and response_json.get("errors"):
                errors = response_json.get('errors', [])
                error_status = response.status_code
                message = "Unknown error"
                if len(errors) > 0:
                    error_status = errors[0].get("extensions", {}).get("http", {}).get("status", response.status_code)
                    message = errors[0].get("message", "Unknown error")
                error_message = f"{error_status} - {message}"
                logger.error(error_message)
                return MarketEquityDataResponse(data=None, error=error_message)
            else:
                logger.error(f"Market equity API error: {response.status_code} - {response.text}")
                error_message = f"{response.status_code} - {response.text}"
                return MarketEquityDataResponse(data=None, error=error_message)
    except Exception as e:
        logger.error(f"Unexpected error while calling Market equity API: {e}")
        return MarketEquityDataResponse(data=None, error=f"Unexpected error: {e}")


def get_year_wise_grid_data(raw_data: list[dict[str, Any]]) -> dict[str, Any]:
    year_wise_grid_data = {}
    for grid_data in raw_data:
        if (
                grid_data.get("Criteria") is not None
                or grid_data.get("SAMQuestion") is not None
        ):
            continue
        year = grid_data.get("year")
        if year_wise_grid_data.get(year) is None:
            year_wise_grid_data[year] = {}

        dimension = grid_data.get("SAMDimension")
        if year_wise_grid_data[year].get(dimension) is None:
            year_wise_grid_data[year][dimension] = {}

        index_category = grid_data.get("IndexPeerCategory")
        if index_category == "Score":
            year_wise_grid_data[year][dimension]["Score"] = grid_data.get("CriteriaScore")
        elif index_category == "Weight (%)":
            year_wise_grid_data[year][dimension]["Weight"] = grid_data.get("CriteriaScore")

    return year_wise_grid_data


@mcp.tool()
async def get_company_description(company_name: str) -> MCPResponse:
    """
    Retrieve company description, such as company background, operating segments
    and Inst ID obtained from S&Ps Capital IQ API
    Args:
        company_name (str): The name of the company to search for, if this is an integer or a string that can be cast to an integer,
                            it will be used directly as the Inst ID (KeyInstn).
    Returns:
        MCPResponse: MCP tool data or an error message.

        MCPResponse:
            source (Source): Information about the data source, including title and link.
            data (CompanyDescriptionDataModel | None): The company description data or None in case there's no content or error.
            isError (bool): Flag indicating if the response is an error.
            message (str | None): Optional message providing additional information about the response or error.

        Source:
            title (str): The title of the data source
            url (str): The URL of the data source

        CompanyDescriptionDataModel:
            description (str): Brief description of the company.
            long_description (str): Long description of the company.
            country_short_name (str): Country short name of the country of company's headquarter.
            date_incorporated_year (str): Date incorporated year.
            sic_code_display (str): SIC code display.
            nace_code_display (str): NACE code display.
            naics_code_display (str): NAICS code display.
            activity_code_display (str): Activity code display.
            keyInstn (str): S&P's unique key to identify institutions. Institutions are corporations, partnerships, proprietorships, not-for-profit organizations, government agencies, and any other chartered organization.
            Headcount (int): Number of employees in the company.
            FloatPercent (str): The float percent of the company.
            InstOwnershipPercent (str): The institutional ownership percent of the company.
            countryKeyInstn (int): The country key institution ID.
            KeyCountry (str): The key country code.

        Example:
            1. Successful response:
                {
                    "source": {
                        "title": "Corporate Profile",
                        "url": "https://www.capitaliqdev.spglobal.com/web/client?auth=inherit&id=3004222"
                    },
                    "data": {
                        "description": "A leading global provider of financial information and analytics.",
                        "long_description": "This company operates in various segments including technology, healthcare, and finance...",
                        "country_short_name": "USA",
                        "date_incorporated_year": "1990",
                        "sic_code_display": "7372",
                        "nace_code_display": "62.01",
                        "naics_code_display": "541512",
                        "activity_code_display": "Software Development",
                        "keyInstn": "123456",
                        "Headcount": 40001,
                        "FloatPercent": "72.74364",
                        "InstOwnershipPercent": "21.39",
                        "countryKeyInstn": 4639247,
                        "KeyCountry": "IT"
                    },
                    "isError": False,
                    "message": None
                }
            2. Error response - without any no data found or error:
                {
                    "source": {
                        "title": "Corporate Profile",
                        "url": "https://www.capitaliqdev.spglobal.com/web/client?auth=inherit&id=3004222"
                    },
                    "data": None,
                    "keyInstn": "123456",
                    "isError": True,
                    "message": "No data found for the specified company."
                }
    """
    # Company ID/CIQCompanyId - S&P Cap IQ unique identifier for companies. Used for mapping between SNL KeyInstn and CapIQ CompanyID
    # request = Depends(Request)
    ctx: Context = mcp.get_context()
    print("ctx.config=======> ", getattr(ctx, "config", None))
    raw_request: Request = ctx.request_context.request
    headers = raw_request.headers
    logger.info(f"Headers received: {headers}")
    auth_headers = auth.build_auth_headers(raw_request)
    logger.info(f"get_company_description called for : {company_name}")

    # Get configuration
    cfg = get_config()
    old_ciqpro_url = cfg["old_ciqpro_url"]
    omni_suggest_base_url = cfg["omni_suggest_base_url"]

    url = f"{omni_suggest_base_url}"
    omni_suggest_body["query"] = company_name
    try:
        logger.info(f"Request URL: {url}")
        # If company_name is an int or a string that can be cast to int, use it directly
        try:
            keyInstn_val = int(company_name)
            logger.info(f"company_name is an int, using keyInstn_val={keyInstn_val} directly, skipping API call.")
        except (TypeError, ValueError):
            global async_client
            response = await async_client.post(url, headers=auth_headers, json=omni_suggest_body)
            logger.info(f"Response status: {response.status_code}")
            if response.status_code == 200:
                response_json = response.json()
                logger.info(f"Response JSON: {response_json}")
                company_ids = get_company_ids(response_json)
                keyInstn_val = company_ids['keyInstn']
            else:
                logger.error(f"Error: {response.status_code} - {response.text}")
                return MCPResponse(
                    sources=None,
                    data=None,
                    isError=True,
                    message=f"Error: {response.status_code} - {response.text}"
                )

            if not isinstance(keyInstn_val, int):
                try:
                    keyInstn_val = int(keyInstn_val)
                except (TypeError, ValueError):
                    return MCPResponse(
                        sources=None,
                        data=None,
                        isError=True,
                        message="Invalid Inst ID format."
                    )
        description, headcount = await asyncio.gather(
            get_company_description_data(str(keyInstn_val), auth_headers),
            get_company_headcount(str(keyInstn_val), auth_headers)
        )

        source = await get_mcp_tool_source(
            mcp_tool_name=get_company_description.__name__,
            source_url=f"{old_ciqpro_url}#company/profile?id={keyInstn_val}",
            institution_id=str(keyInstn_val),
            headers=auth.build_auth_headers(raw_request),
            default_title="Corporate Profile",
        )
        merged_description = {}
        if description and "data" in description and description["data"]:
            desc_data = description["data"]
            # If desc_data is a CompanyDescriptionDataModel, convert to dict for merging
            desc_dict = desc_data.__dict__ if hasattr(desc_data, "__dict__") else desc_data
        else:
            desc_dict = {}
        # if company_ids:
        #     desc_dict["keyInstn"] = company_ids["keyInstn"]
        # Add headcount as a separate field in data
        if headcount and "Headcount" in headcount:
            desc_dict["Headcount"] = headcount["Headcount"]
        data_model = CompanyDescriptionDataModel(**desc_dict)
        return MCPResponse(
            sources=source,
            data=data_model,
            isError=False,
            message=None
        )
        # else:
        #     logger.error(f"Error: {response.status_code} - {response.text}")
        #     return MCPResponse(
        #         sources=None,
        #         data=None,
        #         isError=True,
        #         message=f"Error: {response.status_code} - {response.text}"
        #     )
    except httpx.RequestError as e:
        logger.error(f"Request failed: {e}")
        return MCPResponse(
            sources=None,
            data=None,
            isError=True,
            message=f"Request failed: {e}"
        )


@mcp.tool()
async def get_company_officers(keyInstn: int, roleCategory: str = 'EXECUTIVES') -> MCPResponse:
    """
    Fetch officers for a given Inst ID/KeyInstn/MI Key (keyInstn) and roles within the company.

    Args:
        keyInstn (int): The Inst ID to get officers for company also called as Instn ID, MI Key, KeyInstn.
        roleCategory (str): Specifies a category of roles within a company, only below are the possible value for this
        - EXECUTIVES
        - BOARD_OF_DIRECTORS
        - PROFESSIONALS
        - OTHER_BOARD_MEMBER
        Here is definition of these role category
            Executives: "All executives, excluding professionals"
            Professionals: "All executives, excluding executives"
            BoardOfDirectors: "All board of director members"
            OtherBoardMember: "All other board members"

    Returns:
        MCPResponse: Data containing key officers information for given company and role category.

        MCPResponse:
            source (Source): Information about the data source, including title and link.
            data (List[CompanyOfficerItem] | None): The list of company officer items or None in case there's no content or error.
            isError (bool): Flag indicating if the response is an error.
            message (str | None): Optional message providing additional information about the response or error.

        Source:
            title (str): The title of the data source
            url (str): The URL of the data source

        CompanyOfficerItem:
            title (str): The title of the officer
            biography (str): The biography of the officer
            name (str): The name of the officer
            keyPersonUrl (str): The URL to the officer's profile on the CIQPro site

        ErrorResponse:
            error (str): The error message
    """
    logger.info(f"get_company_officers called for: {keyInstn}, roleCategory: {roleCategory}")

    # Get configuration
    cfg = get_config()
    GRAPH_URL = cfg["capitaliq_graphql_url"]
    old_ciqpro_url = cfg["old_ciqpro_url"]

    payload = {
        "extensions": {
            "persistedQuery": {
                "version": 1,
                "sha256Hash": "305147546b69b1670ca49c1eea67f2f487a206101cb7022f672e04480c46502e"
            }
        },
        "variables": {
            "keyInstn": keyInstn,
            "roleCategory": roleCategory,
            "current": True
        }
    }

    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    headers = {
        "Content-Type": "application/json",
        **auth.build_auth_headers(raw_request)
    }
    logger.info(f"Headers received: {headers}")
    logger.info(f"get_company_officers payload: {payload}")

    try:
        global async_client
        response = await async_client.post(GRAPH_URL, headers=headers, json=payload)
        source = await get_mcp_tool_source(
            mcp_tool_name=get_company_officers.__name__,
            source_url=f"{old_ciqpro_url}#company/profile?id={keyInstn}",
            institution_id=str(keyInstn),
            headers=auth.build_auth_headers(raw_request),
            default_title="Company Officers",
        )
        if response.status_code == 200:
            officers_data = response.json()
            logger.info(f"Officers data: {officers_data}")
            officers = (
                officers_data.get("data", {})
                .get("employeesByKeyInstn", [])
            )
            processed_officers = []
            for officer in officers:
                key_person_id = officer.get("person", {}).get("keyPerson")
                processed_officer = CompanyOfficerItem(
                    title=officer.get("roles", [{}])[0].get("title") if officer.get("roles") else None,
                    biography=officer.get("person", {}).get("biography", {}).get("text"),
                    name=officer.get("person", {}).get("name"),
                    keyPersonUrl=(
                        f"{old_ciqpro_url}#company/officerBio?ID={keyInstn}&KP={key_person_id}"
                        if key_person_id else None
                    ),
                )
                processed_officers.append(processed_officer)

            return MCPResponse(
                sources=source,
                data=processed_officers,
                isError=False,
                message=None
            )
        elif response.status_code == 204:
            logger.info(f"No officers data found for the given company : {keyInstn} for role {roleCategory}")
            return MCPResponse(
                sources=None,
                data=None,
                isError=False,
                message="No officers data found for the given company."
            )
        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return MCPResponse(
                sources=None,
                data=None,
                isError=True,
                message=f"Error: {response.status_code} - {response.text}"
            )
    except httpx.RequestError as e:
        logger.error(f"Request failed: {e}")
        return MCPResponse(
            sources=None,
            data=None,
            isError=True,
            message=f"Request failed: {e}"
        )


@mcp.tool()
async def get_company_ownership(keyInstn: int) -> MCPResponse:
    """
    Fetch Company Ownership Details for a given Inst ID/KeyInstn/MI Key (keyInstn).

    Args:
        keyInstn (int): Inst ID/KeyInstn/MI Key - S&P's unique key to identify institutions. Institutions are corporations, partnerships, proprietorships, not-for-profit organizations, government agencies, and any other chartered organization.

    Returns:
        MCPResponse: Company's ownership data or an error message.

    MCPResponse:
        source (Source): Information about the data source, including title and link.
        data (ResponseModel | None): Company Ownership Details for a given company or None in case there's no content or error.
        isError (bool): Flag indicating if the response is an error.
        message (str | None): Optional message providing additional information about the response or error.

    ResponseModel:
        OwnershipSummary (list[OwnershipSummaryItem]): Breakdown of ownership by lender type.
        TopHoldersActivityChartData (list[TopHoldersActivityChartDataItem]): Historical holding data for top holders.
        TopHolders (list[TopHoldersItem]): List of top holders with details.
        KeyCurrency (str): Currency code for the ownership values (e.g., 'USD').
        PricingAsof (str): Date as of which the pricing and ownership data is reported (ISO format string).

    OwnershipSummaryItem:
        LenderType (str): Type of owner (e.g., Institutions, Individuals/Insiders).
        CommonStockEquivalentHeld (str | None): Number of shares held (as string).
        MarketValueOfOwnership (str): Market value of the holding (as string, usually in millions).
        CommonSharesOutstandingPercent (str | None): Percentage of total shares outstanding (as string).
        KeyHoldingType (str | None): Numeric code for holding type (may be null).
        KeyCurrency (str): Currency code (e.g., 'USD').
        PricingAsof (datetime): Date the data is as of (ISO format string).
        FormOrder (int): Order for display/sorting (integer).

    TopHoldersActivityChartDataItem:
        FactSetCompanyID (int): Unique ID for the company/holder (integer).
        FndgNameOfHolder (str): Name of the holder.
        CommonStockEquivalentHeld (str): Number of shares held at the given date (as string).
        DateEndedStandard (datetime): Date of the holding (ISO format string).

    TopHoldersItem:
        FndgNameOfHolder (str): Name of the holder.
        CommonStockEquivalentHeld (str): Number of shares held (as string).
        MarketValueOfOwnership (str): Market value of the holding (as string).
        CommonSharesOutstandingPercent (str): Percentage of total shares outstanding (as string).
        OwnershipInformationDate (datetime): Date the ownership info was reported (ISO format string).
        DateEndedStandard (datetime): Period end date (ISO format string).
        KeyCurrency (str): Currency code (e.g., 'USD').
        KeyInstnOwner (int | None): Unique key for the institution owner (integer, may be null).

    ErrorResponse:
        error (str): Error message describing the issue.

    Examples:
        {
          "sources": {
            "title": "Company Ownership",
            "url": "https://www.capitaliqdev.spglobal.com/apisv3/spg-webplatform-core/company/OwnershipSummary?Id=4137291"
          },
          "value": {
            "OwnershipSummary": [
              {
                "LenderType": "Institutions",
                "CommonStockEquivalentHeld": "514613782",
                "MarketValueOfOwnership": "126456.044650",
                "CommonSharesOutstandingPercent": "56.98",
                "KeyHoldingType": "1",
                "KeyCurrency": "USD",
                "PricingAsof": "2025-08-29T00:00:00",
                "FormOrder": 0
              }
            ],
            "TopHoldersActivityChartData": [
              {
                "FactSetCompanyID": 823170,
                "FndgNameOfHolder": "State Street Global Advisors Inc.",
                "CommonStockEquivalentHeld": "55.03582100",
                "DateEndedStandard": "2025-08-29T00:00:00"
              }
            ],
            "TopHolders": [
              {
                "FndgNameOfHolder": "State Street Global Advisors Inc.",
                "CommonStockEquivalentHeld": "55035821",
                "MarketValueOfOwnership": "13474.970413",
                "CommonSharesOutstandingPercent": "6.01",
                "OwnershipInformationDate": "2023-12-31T00:00:00",
                "DateEndedStandard": "2024-03-31T00:00:00",
                "KeyCurrency": "USD",
                "KeyInstnOwner": 110652
              }
            ],
            "KeyCurrency": "USD",
            "PricingAsof": "2025-08-29T00:00:00"
          },
            "isError": false,
            "message": None
        }

    Note:
        Ownership data is sourced from S&P Capital IQ and may include institutions, corporations, insiders, and public holders. The Inst ID/KeyInstn/MI Key is S&P's unique key to identify institutions.
    """
    cfg = get_config()
    capitaliq_base_url = cfg["capitaliq_base_url"]
    old_ciqpro_url = cfg["old_ciqpro_url"]
    company_ownership_url_infix = "AIReportBuilder/ownershipData/"

    url = f"{capitaliq_base_url}{company_ownership_url_infix}{keyInstn}"

    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    headers = auth.build_auth_headers(raw_request)
    headers["Accept"] = "application/json"

    logger.info(f"get_company_ownership URL: {url}")
    logger.info(f"get_company_ownership called for keyinstn: {keyInstn}")

    try:
        global async_client
        response = await async_client.get(url, headers=headers)
        source = await get_mcp_tool_source(
            mcp_tool_name=get_company_ownership.__name__,
            source_url=f"{old_ciqpro_url}#company/OwnershipSummary?ID={keyInstn}",
            institution_id=str(keyInstn),
            headers=auth.build_auth_headers(raw_request),
            default_title="Company Ownership",
        )
        logger.info(f"Ownership API response status: {response.status_code}")
        response.raise_for_status()
        data = response.json()
        try:
            ownership_summary = [OwnershipSummaryItem(**item) for item in data.get("OwnershipSummary", [])]
            top_holders = [TopHoldersItem(**item) for item in data.get("TopHolders", [])]
            top_holders_activity = [TopHoldersActivityChartDataItem(**item) for item in
                                    data.get("TopHoldersActivityChartData", [])]
            key_currency = data.get("KeyCurrency", "")
            pricing_asof = data.get("PricingAsof", "")
            model = ResponseModel(
                OwnershipSummary=ownership_summary,
                TopHoldersActivityChartData=top_holders_activity,
                TopHolders=top_holders,
                KeyCurrency=key_currency,
                PricingAsof=pricing_asof,
            )
            return MCPResponse(
                sources=source,
                data=model,
                isError=False,
                message=None
            )
        except Exception as e:
            logger.error(f"Error parsing ownership response: {e}")
            return MCPResponse(
                sources=None,
                data=None,
                isError=True,
                message=f"Error parsing ownership response: {e}"
            )
    except Exception as e:
        logger.error(f"An error occurred: {e}")
        return MCPResponse(
            sources=None,
            data=None,
            isError=True,
            message=str(e)
        )


@mcp.tool()
async def get_market_data(keyInstn: int) -> MCPResponse:
    """
    Fetch Market Capitalization and Market Equity data for a given Inst ID/KeyInstn/MI Key (keyInstn).
    Args:
        keyInstn (int): The Inst ID to get market data for also called as Instn ID, MI Key, KeyInstn.
    Returns:
        MCPResponse: The market data response.

    MCPResponse:
        source (Source): Information about the data source, including title and link.
        data (MarketCapDataResponse && MarketEquityDataResponse): Market Capitalization and Market Equity data for the given Inst ID.
        isError (bool): Flag indicating if the response is an error.
        message (str | None): Optional message providing additional information about the response or error.

    MarketCapDataResponse:
        data (MarketCapData | None): Market Capitalization data including currency, exchange, and equity stats
        error (str | None): Error message if the request failed or no data was found

    MarketEquityDataResponse:
        data (MarketEquityData | None): Market Equity data including various financial metrics
        error (str | None): Error message if the request failed or no data was found

    MarketCapData:
        currency (str | None): The currency code (e.g., 'USD')
        exchange (str | None): The exchange short name (e.g., 'NYSE')
        equityStats (MarketCapEquityStats | None): A dictionary containing various equity statistics such as market cap,
            shares outstanding, and other financial metrics

    MarketCapEquityStats:
        marketCap (dict | None): Market capitalization statistic.
        avg3MDailyVolume (dict | None): Average 3-month daily volume statistic.
        beta3Y (dict | None): 3-year beta statistic.
        divYield (dict | None): Dividend yield statistic.
        sharesOutstanding (dict | None): Shares outstanding statistic.
        sharesSoldShort (dict | None): Shares sold short statistic.
        shortInShOut (dict | None): Short interest in shares outstanding statistic.
        totalEnterpriseValue (dict | None): Total enterprise value statistic.

    MarketEquityData:
        keyFndg (int): Unique identifier for the equity
        keyUniversalEntity (str): Universal entity key for the equity
        symbol (str): Ticker symbol of the equity
        dividend (float | None): Dividend value if available
        exchange (MarketExchangeData | None): Exchange details
        latestPrice (MarketEquityLatestPrice | None): Latest price metrics
        currency (MarketEquityCurrency | None): Currency details
        instn (MarketEquityInstn | None): Institution details.

    MarketEquityLatestPrice:
        price (dict | None): Latest price information
        open (dict | None): Opening price information
        close (dict | None): Closing price information
        high (dict | None): Highest price information
        low (dict | None): Lowest price information
        volume (dict | None): Volume information
        vwap (dict | None): Volume-weighted average price information
        bid (dict | None): Bid price information
        ask (dict | None): Ask price information
        changePrice (dict | None): Change in price information
        changePercentage (dict | None): Change in percentage information

    Examples:
    1. Successful response:
        {
            "sources": {
                "title": "Market Data",
                "url": "https://www.capitaliqdev.spglobal.com/web/client?auth=inherit#company/profile?id={keyInstn}"
            },
            "data": {
                "market_cap": {
                    "data": {
                        "currency": "USD",
                        "exchange": "NYSE",
                        "equityStats": {
                        "marketCap": {
                            "value": 1080038.8282,
                            "asOf": "2025-09-17T00:00:00.000Z"
                        },
                        "avg3MDailyVolume": {
                            "value": null,
                            "asOf": "2025-09-17T00:00:00.000Z"
                        },
                        "beta3Y": {
                            "value": null,
                            "asOf": "2025-09-17T00:00:00.000Z"
                        },
                        "divYield": {
                            "value": 0.4351646512406377,
                            "asOf": "2025-09-17T00:00:00.000Z"
                        },
                        "sharesOutstanding": {
                            "value": 14840390000,
                            "asOf": "2025-09-17T00:00:00.000Z"
                        },
                        "sharesSoldShort": {
                            "value": 113582365,
                            "asOf": "2025-09-17T00:00:00.000Z"
                        },
                        "shortInShOut": {
                            "value": 0.765359704158718,
                            "asOf": "2025-09-17T00:00:00.000Z"
                        },
                        "totalEnterpriseValue": {
                            "value": 1035469.8282,
                            "asOf": "2025-09-17T00:00:00.000Z"
                        }
                    },
                    "error": null
                },
                "market_equity": {
                    "data": {
                        "keyFndg": 149330,
                        "keyUniversalEntity": "4004205",
                        "symbol": "AAPL",
                        "dividend": null,
                        "exchange": {
                            "name": "Nasdaq Global Select Market",
                            "exchangeCode": "XNGS"
                        },
                        "latestPrice": {
                            "price": {
                                "value": 245.5,
                                "asOf": "2025-09-19T20:00:00.000Z"
                            },
                            "open": {
                                "value": 0,
                                "asOf": "0001-01-01T00:00:00.000Z"
                            },
                            "close": {
                                "value": 234.07,
                                "asOf": "2025-09-12T20:00:00.476Z"
                            },
                            "high": {
                                "value": 0,
                                "asOf": "0001-01-01T00:00:00.000Z"
                            },
                            "low": {
                                "value": 0,
                                "asOf": "0001-01-01T00:00:00.000Z"
                            },
                            "volume": {
                                "value": 163741314,
                                "asOf": "0001-01-01T00:00:00.000Z"
                            },
                            "vwap": {
                                "value": 0,
                                "asOf": "0001-01-01T00:00:00.000Z"
                            },
                            "bid": {
                                "value": 246.58,
                                "asOf": "2025-09-22T10:02:59.000Z"
                            },
                            "ask": {
                                "value": 246.87,
                                "asOf": "2025-09-22T10:02:59.000Z"
                            },
                            "changePrice": {
                                "value": 7.62,
                                "asOf": "0001-01-01T00:00:00.000Z"
                            },
                            "changePercentage": {
                                "value": 3.2,
                                "asOf": "0001-01-01T00:00:00.000Z"
                            }
                        },
                        "currency": {
                            "name": "Bolivian Boliviano",
                            "symbol": "Bs"
                        },
                        "instn": {
                            "name": "Apple Inc.",
                            "websiteUrl": "www.apple.com"
                        }
                    },
                    "error": null
                }
            },
            "isError": false,
            "message": null
        }

    2. Error response - without any no data found or error:
        {
            "sources": {
                "title": "Market Data",
                "url": "https://www.capitaliqdev.spglobal.com/web/client?auth=inherit#company/profile?id={keyInstn}"
            },
            "data": {
                "market_cap": null,
                "market_equity": null
            },
            "isError": true,
            "message": "No market cap data found in the response; No equities found in the response"
        }
    """
    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    headers = raw_request.headers
    logger.info(f"Headers received: {headers}")
    auth_headers = auth.build_auth_headers(raw_request)

    cfg = get_config()
    old_ciqpro_url = cfg["old_ciqpro_url"]

    market_cap_data, market_equity_data = await asyncio.gather(
        get_market_cap_data(keyInstn, auth_headers),
        get_market_equity_data(str(keyInstn), auth_headers)
    )
    logger.info(f"Market Cap Data: {market_cap_data}")
    logger.info(f"Market Equity Data: {market_equity_data}")

    isError = False
    message = None
    if (market_cap_data.error is not None) or (market_equity_data.error is not None):
        isError = True
        message = "; ".join(filter(None, [market_cap_data.error, market_equity_data.error]))
    source = await get_mcp_tool_source(
        mcp_tool_name=get_market_data.__name__,
        source_url=f"{old_ciqpro_url}#company/profile?id={keyInstn}",
        institution_id=str(keyInstn),
        headers=auth.build_auth_headers(raw_request),
        default_title="Corporate Profile",
    )
    return MCPResponse(
        sources=source,
        data={
            "market_cap": market_cap_data.data,
            "market_equity": market_equity_data.data
        },
        isError=isError,
        message=message
    )


async def get_benchmark_indices(keyInstn: int, auth_headers: dict) -> dict:
    """
    Retrieve the KeyUniversalEntity and Name for the first benchmark index where isStockChartIndex is True
    from the chartPreference/getBenchmark API for a given company.

    Args:
        keyInstn (int): The company key to query for benchmark indices.
        auth_headers (dict): Authentication headers for the API request.

    Returns:
        dict or None: A dictionary with 'KeyUniversalEntity' and 'Name' of the first benchmark index with isStockChartIndex True,
        or None if not found or on error.

    Example:
        If the API returns:
            {
                "value": [
                    {"KeyUniversalEntity": "12345", "Name": "S&P 500", "isStockChartIndex": True},
                    {"KeyUniversalEntity": "67890", "Name": "Other", "isStockChartIndex": False}
                ]
            }
        The function will return {"KeyUniversalEntity": "12345", "Name": "S&P 500"}.

    Notes:
        - Returns None if no benchmark index with isStockChartIndex True is found.
        - Returns None on HTTP errors or exceptions.
    """
    # Get configuration
    cfg = get_config()
    benchmark_indice_url = cfg["stock_chart_benchmark_index"]
    url = f"{benchmark_indice_url}/getBenchmark?keyCompany={keyInstn}"
    print(f"Using stock chart URL: {url}")

    async with httpx.AsyncClient() as client:
        resp = await client.get(url, headers=auth_headers)
        if resp.status_code == 200:
            data = resp.json()
            value_list = data.get('value', [])
            filtered = [item for item in value_list if item.get('isStockChartIndex') is True]
            for item in filtered:
                if 'KeyUniversalEntity' in item and isinstance(item['KeyUniversalEntity'], str):
                    return {
                        "KeyUniversalEntity": item['KeyUniversalEntity'],
                        "Name": item.get('Name')
                    }
            return None
        elif resp.status_code == 204:
            logger.info(f"No stock chart found for the given company: {keyInstn}")
            return None
        else:
            logger.error(f"Error: {resp.status_code} - {resp.text}")
            return None


async def fetch_stockchart(keyInstn: int, start_date: str, end_date: str, kpqi: int, contentset: int,
                           auth_headers: dict) -> dict:
    """
    Fetch stock chart time series data for a given company or benchmark index and metric (kpqi) from S&P Capital IQ API.

    Args:
        keyInstn (int or str): S&P's unique key to identify institutions (for companies) or KeyUniversalEntity (for benchmark indices).
        start_date (str): Start date for the time series (YYYY-MM-DD).
        end_date (str): End date for the time series (YYYY-MM-DD).
        kpqi (int): Metric KPQI identifier (e.g., 290942 for trading volume, 290930 for closing price, 309761 for closing index value).
        contentset (int): Content set identifier (1 for company, 6 for index).
        auth_headers (dict): Authentication headers for the API request.

    Returns:
        SeriesResponse: Contains currency (localizedMagnitude/unit) and a dictionary mapping date strings to metric values for the given kpqi within the given date range.
            - If data is found: SeriesResponse(currency=..., data={date1: value1, date2: value2, ...})
            - If no data: SeriesResponse(currency=None, data=None)

    Notes:
        - Handles both company and benchmark index time series depending on contentset and keyInstn.
        - Converts non-numeric or missing values (e.g., 'NA', '', None) to None.
        - Extracts localizedMagnitude/unit for each metric and returns it in the currency field.
        - Used internally by get_company_stockchart to fetch individual metric series.
    """
    # Get configuration
    cfg = get_config()
    url = cfg["stock_chart_url"]
    print(f"Using stock chart URL: {url}")

    # Example payload, replace with what the API expects
    payload = {
        "startDate": start_date,
        "endDate": end_date,
        "conversion": {
            "currencyConversionMode": 0,
            "keyCurrency": None,
            "magnitudeOverride": 0
        },
        "entities": [
            {"id": str(keyInstn), "contentSet": contentset}
        ],
        "metrics": [
            {"kpqi": kpqi, "type": 1}
        ]
    }

    with httpx.Client() as client:
        response = client.post(url, headers=auth_headers, json=payload)
        print("Status code:", response.status_code)
        if response.status_code == 200:
            data = response.json()
            print("Raw API response:", data)
            date_value_dict = {}

            # Extract localizedMagnitude if present and metadata exists
            series_list = data.get("series", [])
            if series_list and "metadata" in series_list[0] and "localizedMagnitude" in series_list[0]["metadata"]:
                localized_magnitude = series_list[0]["metadata"]["localizedMagnitude"]
            else:
                localized_magnitude = None

            # Extract date-value pairs from the API response
            for series in data.get("series", []):
                for dp in series.get("dataPoints", []):
                    if dp.get("date") is not None:
                        date_only = dp["date"][:10]
                        val = dp.get("value")
                        # Convert 'NA' and other non-numeric to None
                        # Handle 'NA', empty string, None, and other non-numeric values
                        if val is None or (isinstance(val, str) and (val.strip() == "" or val.strip().upper() == "NA")):
                            val_num = None
                        else:
                            try:
                                val_num = float(val)
                            except (ValueError, TypeError):
                                val_num = None
                        date_value_dict[date_only] = val_num

            print(date_value_dict)
            # Load into SeriesResponse model with localizedMagnitude and datapoint
            return SeriesResponse(currency=localized_magnitude, data=date_value_dict)
        elif response.status_code == 204:
            logger.info(f"No stock chart found for the given company: {keyInstn}")
            return SeriesResponse(currency=None, data=None)
        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return SeriesResponse(currency=None, data=None)


@mcp.tool()
async def get_company_stockchart(keyInstn: int, start_date: str = None, end_date: str = None,
                                 metric: str = 'all') -> MCPResponse:
    """
    Fetch company stock chart time series (closing price, trading volume, and/or closing index value) for a given Inst ID/KeyInstn/MI Key (keyInstn).

    Args:
        keyInstn (int): S&P's unique key to identify institutions (Inst ID/KeyInstn/MI Key).
        start_date (str, optional): Start date for the time series (YYYY-MM-DD). Defaults to 1 year ago if not provided.
        end_date (str, optional): End date for the time series (YYYY-MM-DD). Defaults to today if not provided.
        metric (str, optional): Which metric(s) to fetch: 'tradingvolume', 'closingprice', 'closingindexvalue', or 'all'. Defaults to 'all'.
            - 'tradingvolume': Fetches trading volume time series for the company.
            - 'closingprice': Fetches closing price time series for the company.
            - 'closingindexvalue': Fetches closing index value for the company's benchmark index.
            - 'all': Fetches all three metrics and merges them by date.

    Returns:
        MCPResponse: Stock chart data or an error message.

    MCPResponse:
        sources (Source | None): Information about the data source, including title and link, or None if no data found.
        data (StockChartResponse | None): The merged stock chart data or None if no data found.
        isError (bool): Flag indicating if the response is an error.
        message (str | None): Optional message providing additional information about the response or error.

    StockChartResponse:
        benchmark (str | None): Name of the benchmark index if 'closingindexvalue' is requested, else None.
        currency (Dict[str, str | None]): Dictionary with metric keys ('closing_price', 'trading_volume', 'closing_index_value') and their corresponding localizedMagnitude/unit from the API response. 
                                          For closing price, the value may be "{$}" or similar; for trading volume, it may be "(actual)"; for closing index value, it may be "" or None.
        datapoint (Dict[str, Dict[str, float | None]] | None): Dictionary with date as key and a dictionary of metrics (closing_price, trading_volume, closing_index_value) as value. 
                                                               All three keys are always present for each date, with None if not available.

    Source:
        title (str): The title of the data source.
        url (str): The URL of the data source.

    Examples:
        Success (all metrics, default date range):
            Request:
                get_company_stockchart(keyInstn=4000193)
            Response:
                {
                    "sources": {"title": "company stock chart", "url": "https://www.capitaliq.spglobal.com/web/client#company/stock?id=4000193"},
                    "data": {
                        "benchmark": "S&P 500",
                        "currency": {
                            "closing_price": "{$}",
                            "trading_volume": "(actual)",
                            "closing_index_value": ""
                        },
                        "datapoint": {
                            "2023-09-17": {"closing_price": 39.55, "trading_volume": 27769380.0, "closing_index_value": 1234.56},
                            "2023-09-18": {"closing_price": 40.12, "trading_volume": 28123456.0, "closing_index_value": 1240.10},
                            ...
                        }
                    },
                    "isError": false,
                    "message": null
                }
        No data:
            {
                "sources": null,
                "data": null,
                "isError": false,
                "message": "No stock chart found for the given company."
            }
        Only closing price:
            {
                "sources": {"title": "company stock chart", "url": "..."},
                "currency": {"closing_price": "{$}", "trading_volume": null, "closing_index_value": null},
                "data": {
                    "benchmark": null,
                    "datapoint": {
                        "2024-09-17": {"closing_price": 39.55, "trading_volume": null, "closing_index_value": null},
                        ...
                    }
                },
                "isError": false,
                "message": null
            }
        Only trading volume:
            {
                "sources": {"title": "company stock chart", "url": "..."},
                "currency": {"closing_price": null, "trading_volume": "(actual)", "closing_index_value": null},
                "data": {
                    "benchmark": null,
                    "datapoint": {
                        "2024-09-17": {"closing_price": null, "trading_volume": 27769380.0, "closing_index_value": null},
                        ...
                    }
                },
                "isError": false,
                "message": null
            }
        Only closing index value:
            {
                "sources": {"title": "company stock chart", "url": "..."},
                "currency": {"closing_price": null, "trading_volume": null, "closing_index_value": ""},
                "data": {
                    "benchmark": "S&P 500",
                    "datapoint": {
                        "2024-09-17": {"closing_price": null, "trading_volume": null, "closing_index_value": 1234.56},
                        ...
                    }
                },
                "isError": false,
                "message": null
            }

    Note:
        - Stock chart data is sourced from S&P Capital IQ and may include missing values (None) for some dates or metrics.
        - The Inst ID/KeyInstn/MI Key is S&P's unique key to identify institutions.
        - When 'closingindexvalue' is requested, the benchmark index for the company is determined and its time series is fetched.
        - All three metric keys ('closing_price', 'trading_volume', 'closing_index_value') are always present for each date in the result, with None if not available.
        - The response includes a 'benchmark' field with the benchmark index name if applicable.
        - The 'currency' field contains the localizedMagnitude/unit for each metric as returned by the API (e.g., "{$}", "(actual)", "" or None).
    """

    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    headers = auth.build_auth_headers(raw_request)
    headers["Accept"] = "application/json"

    # Default date range: 1 year if not provided
    if not end_date or not isinstance(end_date, str) or not end_date.strip():
        end_dt = datetime.now(timezone.utc)
        end_date = end_dt.strftime("%Y-%m-%d")
    else:
        try:
            end_dt = datetime.strptime(end_date, "%Y-%m-%d")
        except Exception:
            return MCPResponse(
                sources=None,
                data=None,
                isError=True,
                message="Input 'end_date' should be a valid string in 'YYYY-MM-DD' format."
            )

    # max 5 year back start date would be allowed      
    if not start_date or not isinstance(start_date, str) or not start_date.strip():
        start_dt = end_dt - timedelta(days=365)
        start_date = start_dt.strftime("%Y-%m-%d")
    else:
        try:
            start_dt = datetime.strptime(start_date, "%Y-%m-%d")
            five_year_ago = end_dt - timedelta(days=5 * 365)
            if start_dt < five_year_ago:
                start_dt = five_year_ago
                start_date = start_dt.strftime("%Y-%m-%d")
        except Exception:
            return MCPResponse(
                sources=None,
                data=None,
                isError=True,
                message="Input 'start_date' should be a valid string in 'YYYY-MM-DD' format."
            )

    # Map metric names to kpqi and output keys
    metric_map = {
        'tradingvolume': {'kpqi': 290942, 'key': 'trading_volume'},
        'closingprice': {'kpqi': 290930, 'key': 'closing_price'},
        'closingindexvalue': {'kpqi': 309761, 'key': 'closing_index_value'}
    }

    # Determine which metrics to fetch
    metrics_to_fetch = []
    if metric == 'all':
        metrics_to_fetch = ['tradingvolume', 'closingprice', 'closingindexvalue']
    elif metric in metric_map:
        metrics_to_fetch = [metric]
    else:
        logger.error(f"Invalid metric argument: {metric}")
        return MCPResponse(
            sources=None,
            data=None,
            isError=True,
            message=f"Invalid metric argument: {metric}"
        )

    # Fetch and merge, ensuring both keys are present for every date
    all_keys = ['closing_price', 'trading_volume', 'closing_index_value']
    # Fetch data for each metric
    metric_data = {k: None for k in all_keys}
    found_data = False
    benchmark_name = None
    for m in metrics_to_fetch:
        if m != 'closingindexvalue':
            resp = await fetch_stockchart(keyInstn, start_date, end_date, kpqi=metric_map[m]['kpqi'], contentset=1,
                                          auth_headers=headers)
        else:
            # For closingindexvalue, get the benchmark index key and fetch its stockchart
            benchmark_info = await get_benchmark_indices(keyInstn, auth_headers=headers)
            benchmark_key = benchmark_info["KeyUniversalEntity"] if benchmark_info else None
            benchmark_name = benchmark_info["Name"] if benchmark_info else None
            if benchmark_key:
                resp = await fetch_stockchart(benchmark_key, start_date, end_date, kpqi=metric_map[m]['kpqi'],
                                              contentset=6, auth_headers=headers)
            else:
                resp = SeriesResponse(data=None)

        if resp.data:
            found_data = True
            metric_data[metric_map[m]['key']] = resp.data

            # Store currency for each metric in a separate dictionary
            if 'currency_dict' not in locals():
                currency_dict = {}

            currency_dict[metric_map[m]['key']] = getattr(resp, "currency", None)

    if not found_data:
        logger.info(f"No stock chart found for the given company: {keyInstn}")
        return MCPResponse(
            sources=None,
            data=None,
            isError=False,
            message="No stock chart found for the given company."
        )

    # Collect all valid dates that are present in any metric_data dict (union)
    # Accept both 'YYYY-MM-DD' and 'YYYY-MM-DDTHH:MM:SS...' formats
    all_dates = set()

    # Ensure start_dt and end_dt are always reinitialized    
    start_dt = datetime.strptime(start_date, "%Y-%m-%d")
    end_dt = datetime.strptime(end_date, "%Y-%m-%d")

    for d in metric_data.values():
        if d:
            for date_str in d.keys():
                try:
                    if isinstance(date_str, str) and len(date_str) >= 10:
                        dt = datetime.strptime(date_str[:10], "%Y-%m-%d")
                        if start_dt <= dt <= end_dt:
                            all_dates.add(date_str)
                except Exception:
                    continue

    # Build merged data as a list of dicts for StockChartResponse
    # Only build merged_data if there are dates to merge
    merged_data = {}
    if all_dates:
        for date in sorted(all_dates):
            merged_data[date] = {
                "closing_price": metric_data['closing_price'][date] if metric_data['closing_price'] and date in
                                                                       metric_data['closing_price'] else None,
                "trading_volume": metric_data['trading_volume'][date] if metric_data['trading_volume'] and date in
                                                                         metric_data['trading_volume'] else None,
                "closing_index_value": metric_data['closing_index_value'][date] if metric_data[
                                                                                       'closing_index_value'] and date in
                                                                                   metric_data[
                                                                                       'closing_index_value'] else None
            }
    else:
        logger.info("No dates found to merge for datapoints.")

    # Prepare response as requested: StockChartResponse(benchmark=..., currency=..., datapoints=...)
    stockchart_response = StockChartResponse(
        benchmark=benchmark_name,
        currency={
            "closing_price": currency_dict.get('closing_price'),
            "trading_volume": currency_dict.get('trading_volume'),
            "closing_index_value": currency_dict.get('closing_index_value')
        },
        datapoint=merged_data if merged_data else None
    )
    cfg = get_config()
    old_ciqpro_url = cfg["old_ciqpro_url"]
    source = await get_mcp_tool_source(
        mcp_tool_name=get_company_stockchart.__name__,
        source_url=f"{old_ciqpro_url}#company/stock?id={keyInstn}",
        institution_id=str(keyInstn),
        headers=auth.build_auth_headers(raw_request),
        default_title="Company Stock Chart",
    )
    return MCPResponse(
        sources=source,
        data=stockchart_response,
        isError=False,
        message=None
    )


@mcp.tool()
async def get_company_corporate_issuance_cds_data(
    keyInstn: int,
    startDate: Optional[str] = None,
    endDate: Optional[str] = None,
    frequency: str = "daily",
) -> MCPResponse:
    """
    Retrieve Corporate Issuance related Credit Default Swaps pricing time series for a company (KeyInstn) as a date-keyed map.

    This tool returns the CDS (Credit Default Swaps) par spread mid end-of-day series transforming the results into a DD-MM-YYYY keyed structure.

    Args:
        keyInstn (int): S&P KeyInstn identifier for the company.
        startDate (str | None): Start date in ISO format (YYYY-MM-DD). If omitted alongside endDate,
            defaults to today minus 365 days. If endDate is provided without startDate, defaults to endDate minus 365 days.
        endDate (str | None): End date in ISO format (YYYY-MM-DD). If omitted alongside startDate,
            defaults to today. If startDate is provided without endDate, defaults to startDate plus 365 days.
        frequency (str): Resampling frequency for the returned series data. Supported values:
            'daily' (default), 'weekly', 'monthly'.

    Returns:
        MCPResponse: MCP tool response or an error message.

        MCPResponse:
            sources (Source): Information about the data source, including title and link.
            data (CDSParSpreadMap | None): Date-keyed map of parSpreadMidIn values (CDS) or None when not available. Includes 'metadata' describing the selected identifiers.
            isError (bool): Flag indicating if the response is an error.
            message (str | None): Optional explanatory message for empty/error outcomes.

        Source:
            title (str): The title of the data source.
            url (str): The URL to the relevant page in CIQ Pro.

                CDSParSpreadMap:
                        BaseModel with:
                            - series (Dict[str, CDSParSpreadValue]): DD-MM-YYYY -> value map
                            - metadata (Dict[str, Any]): Instrument identifiers and helper context:
                                    * keyInstn, securityId, tradingItemId, tier, docClause, keyCurrency, runningCoupon, cdsTenor, name
                                    * frequency ("daily" | "weekly" | "monthly") describing the returned sampling cadence
                                    * originalDatapointCount / resampledDatapointCount summarizing the number of observations before/after resampling
                                    * latestParSpreadMidInBps (float) and latestParSpreadMidInDate (YYYY-MM-DD) reflecting the most recent par spread mid observation available in the response
                                    name format: "<tier> <keyCurrency> <docClause> (Primary)" when both isPrimarySecurity and primaryTradingItem are true

        CDSParSpreadValue:
            parSpreadMidIn (float): CDS par spread (mid) value for that date.

    Examples:
        1. Successful response:
            {
                "sources": {
                    "title": "Corporate Issuance — CDS Par Spread (EOD)",
                    "url": "https://www.capitaliqdev.spglobal.com/web/client?auth=inherit#fixedIncome/cds?ID=3004222"
                },
                "data": {
                    "series": {
                        "19-09-2025": { "parSpreadMidIn": 123.4 },
                        "18-09-2025": { "parSpreadMidIn": 124.1 }
                    },
                    "metadata": {
                        "keyInstn": 3004222,
                        "securityId": 123,
                        "tradingItemId": 456,
                        "tier": "Senior Unsecured",
                        "docClause": "CR14",
                        "keyCurrency": "USD",
                        "runningCoupon": 5.0,
                        "cdsTenor": "5Y",
                        "name": "Senior Unsecured USD CR14 (Primary)"
                    }
                },
                "isError": false,
                "message": null
            }
        2. Error response:
            {
                "sources": null,
                "data": null,
                "isError": true,
                "message": "No matching CDS instrument found."
            }
    """

    logger.info(
        f"get_company_corporate_issuance_cds_data called for: {keyInstn}, startDate={startDate}, endDate={endDate}, frequency={frequency}")
    normalized_frequency = (frequency or "daily").lower()
    if normalized_frequency not in {"daily", "weekly", "monthly"}:
        return MCPResponse(
            sources=None,
            data=None,
            isError=True,
            message=(
                "Invalid frequency. Supported values are 'daily', 'weekly', or 'monthly'."
            ),
        )
    # Compute defaults for a 1-year window

    try:
        if not startDate and not endDate:
            # Default: last 365 days ending today
            endDate = date.today().isoformat()
            startDate = (date.today() - timedelta(days=365)).isoformat()
        elif startDate and not endDate:
            # If start provided, set end to start + 365 days
            sd = date.fromisoformat(startDate)
            endDate = (sd + timedelta(days=365)).isoformat()
        elif endDate and not startDate:
            # If end provided, set start to end - 365 days
            ed = date.fromisoformat(endDate)
            startDate = (ed - timedelta(days=365)).isoformat()
        # else: both provided; use as-is
    except Exception as e:
        logger.error(f"Invalid date format for startDate/endDate: {e}")
        return MCPResponse(sources=None, data=None, isError=True, message="Invalid date format. Use YYYY-MM-DD.")

    # Acquire request for auth propagation
    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request

    try:
        selected_curve_identifier = await _fetch_cds_curve_identifiers(keyInstn, raw_request)
        if not selected_curve_identifier:
            return MCPResponse(sources=None, data=None, isError=True, message="No matching CDS instrument found.")

        raw_series = await _fetch_cds_eod_par_spread(
            int(selected_curve_identifier["securityId"]),
            int(selected_curve_identifier["tradingItemID"]),
            startDate,
            endDate,
            raw_request,
        )
        sampled_series = _aggregate_cds_series(raw_series, normalized_frequency)
        cds_map = _build_cds_par_spread_series(sampled_series)

        latest_par_spread_mid_in_bps: Optional[float] = None
        latest_par_spread_mid_in_date: Optional[str] = None
        if sampled_series:
            latest_row = max(
                (
                    row
                    for row in sampled_series
                    if row.get("priceDate") and row.get("parSpreadMidIn") is not None
                ),
                key=lambda row: row["priceDate"],
                default=None,
            )
            if latest_row:
                latest_par_spread_mid_in_date = latest_row.get("priceDate")
                try:
                    latest_par_spread_mid_in_bps = float(latest_row.get("parSpreadMidIn"))
                except (TypeError, ValueError):
                    latest_par_spread_mid_in_bps = None

        # Attach constrained metadata from identifier selection
        tier = selected_curve_identifier.get("tier")
        doc_clause = selected_curve_identifier.get("docClause")
        key_currency = selected_curve_identifier.get("keyCurrency")
        is_primary = bool(selected_curve_identifier.get("isPrimarySecurity")) and bool(
            selected_curve_identifier.get("primaryTradingItem"))
        primary_suffix = " (Primary)" if is_primary else ""
        tier_str = str(tier) if tier is not None else ""
        cur_str = str(key_currency) if key_currency is not None else ""
        doc_str = str(doc_clause) if doc_clause is not None else ""
        name = " ".join([p for p in [tier_str, cur_str, doc_str] if p]).strip() + primary_suffix

        cds_map.metadata = {
            "keyInstn": selected_curve_identifier.get("keyInstn"),
            "securityId": selected_curve_identifier.get("securityId"),
            "tradingItemId": selected_curve_identifier.get("tradingItemID"),
            "tier": tier,
            "docClause": doc_clause,
            "keyCurrency": key_currency,
            "runningCoupon": selected_curve_identifier.get("runningCoupon"),
            "cdsTenor": selected_curve_identifier.get("cdsTenor"),
            "name": name,
            "frequency": normalized_frequency,
            "originalDatapointCount": len(raw_series),
            "resampledDatapointCount": len(sampled_series),
            "latestParSpreadMidInBps": latest_par_spread_mid_in_bps,
            "latestParSpreadMidInDate": latest_par_spread_mid_in_date,
        }

        cfg = get_config()
        core_url = cfg["core_url"]

        source = await get_mcp_tool_source(
            mcp_tool_name=get_company_corporate_issuance_cds_data.__name__,
            source_url=f"{core_url}company/cds?Id={keyInstn}",
            institution_id=str(keyInstn),
            headers=auth.build_auth_headers(raw_request),
            default_title="Credit Default Swaps EOD Data",
        )
        return MCPResponse(sources=source, data=cds_map, isError=False, message=None)

    except Exception as e:
        logger.error(f"Error in get_company_corporate_issuance_cds_data: {e}")
        return MCPResponse(sources=None, data=None, isError=True, message=str(e))


@mcp.tool()
async def get_company_esg_score(keyInstn: int, years_in_number: int = 2) -> MCPResponse:
    """
        Fetch Company E, S, G Score report for a given Inst ID/KeyInstn/MI Key (keyInstn) and years which says how much year of report is needed.

        Args:
            keyInstn (int): Inst ID/KeyInstn/MI Key - S&P's unique key to identify institutions. Institutions are corporations, partnerships, proprietorships, not-for-profit organizations, government agencies, and any other chartered organization.
            years_in_number (int): This says how much last year of data need to be fetched (the max limit if for last 5 year and default would be 2 year
        Returns:
            MCPResponse: ESG Score data or an error message.

        MCPResponse:
            source (Source): Information about the data source, including title and link.
            data (list[CompanyEsgScoreResponse] | []): Company ESG Score Details for a given company and year or None in case there's no content or error.
            isError (bool): Flag indicating if the response is an error.
            message (str | None): Optional message providing additional information about the response or error.

        CompanyEsgScoreResponse:
            year(int): Represent the data of particular year
            score_type (str): Represent the company score type, Eg. ESG Score, Environmental Score, Social Score, Governance & Economic Score
            company_score (int): Represent company score
            industry_avg_score (int): Represent industry average score
            industry_min_score(int): Represent min score for the year
            industry_max_score(int): Represent max score for the year
            dimension(str): Represent mapping of score type
            weight_in_percentage(int) : Represent the weight percentage

        ErrorResponse:
            error (str): Error message describing the issue.

        Examples:
            {
              "sources": {
                "title": "ESG Scores",
                "url": "https://www.capitaliqdev.spglobal.com/web/client?auth=inherit#company/esgHistory?ID=4000193"
              },
              "data": [
                {
                  "year": 2024,
                  "score_type": "ESG Score",
                  "company_score": 60,
                  "industry_avg_score": 34,
                  "industry_min_score": 8,
                  "industry_max_score": 90,
                  "dimension": "Total Sustainability Score",
                  "weight_in_percentage": 100
                },
                {
                  "year": 2024,
                  "score_type": "Environmental Score",
                  "company_score": 76,
                  "industry_avg_score": 32,
                  "industry_min_score": 1,
                  "industry_max_score": 94,
                  "dimension": "Environmental",
                  "weight_in_percentage": 3
                }
              ],
              "isError": false,
              "message": null
            }
        """
    logger.info(f"get_company_esg_score called for: {keyInstn}, recent history data for: {years_in_number} years")

    # Get configuration
    cfg = get_config()
    old_ciqpro_url = cfg["old_ciqpro_url"]
    esg_score_url = f"{cfg['capitaliq_base_url']}AIReportBuilder/esgScoreData/{keyInstn}/1/0"
    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    headers = {
        "Content-Type": "application/json",
        **auth.build_auth_headers(raw_request)
    }
    logger.info(f"Headers received: {headers}")
    try:
        global async_client
        response = await async_client.get(esg_score_url, headers=headers)
        logger.info(f"Response :: {response}")
        source = await get_mcp_tool_source(
            mcp_tool_name=get_company_esg_score.__name__,
            source_url=f"{old_ciqpro_url}#company/esgProfile?ID={keyInstn}",
            institution_id=str(keyInstn),
            headers=auth.build_auth_headers(raw_request),
            default_title="ESG Scores",
        )
        if response.status_code == 200:
            esg_score_data = response.json()
            logger.info(f"Received esg scores :: {esg_score_data}")
            esg_chart_data = esg_score_data.get("ESGChartData")
            esg_grid_data = esg_score_data.get("ESGGridData")
            year_wise_grid_data = get_year_wise_grid_data(raw_data=esg_grid_data)
            logger.info(f"Processed grid data :: {year_wise_grid_data}")
            processed_esg_score = []
            for chart_data in esg_chart_data:
                dimension = ""
                score_type = chart_data.get("ScoreType")
                if score_type == EsgChartDataScoreType.ESG_SCORE.value:
                    dimension = EsgGridDataDimension.TOTAL_SUSTAINABILITY_SCORE.value
                elif score_type == EsgChartDataScoreType.SOCIAL_SCORE.value:
                    dimension = EsgGridDataDimension.SOCIAL.value
                elif score_type == EsgChartDataScoreType.ENVIRONMENTAL_SCORE.value:
                    dimension = EsgGridDataDimension.ENVIRONMENTAL.value
                elif score_type == EsgChartDataScoreType.GOVERNANCE_AND_ECONOMIC_SCORE.value:
                    dimension = EsgGridDataDimension.GOVERNANCE_AND_ECONOMIC.value
                logger.info(f"Dimension is :: {dimension} for score type :: {score_type}")
                year = chart_data.get("year")
                processed_esg_score.append(
                    CompanyEsgScoreResponse(
                        score_type=score_type,
                        company_score=chart_data.get("CompanyScore"),
                        industry_avg_score=chart_data.get("IndustryAvgScore"),
                        industry_max_score=chart_data.get("SAMIndustryMaxScore"),
                        industry_min_score=chart_data.get("SAMIndustryMinScore"),
                        year=year,
                        dimension=dimension,
                        weight_in_percentage=year_wise_grid_data[year][dimension]["Weight"],
                    )
                )

            processed_esg_score = sorted(processed_esg_score, key=lambda obj: obj.year, reverse=True)
            if years_in_number > 5:
                years_in_number = 5  # only allow to expose last 5 year of records

            # Each year contains 4 record based on their score type i.e. ESG Score, Environmental Score, Social Score, Economic & Governance Score
            processed_esg_score = processed_esg_score[:years_in_number * 4]
            logger.info(f"Final esg score data: {processed_esg_score}")
            return MCPResponse(
                sources=source,
                data=processed_esg_score,
                isError=False,
                message=None
            )
        elif response.status_code == 204:
            logger.info(f"No ESG score data found for the given company : {keyInstn}")
            return MCPResponse(
                sources=None,
                data=None,
                isError=False,
                message="No ESG score data found for the given company."
            )
        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return MCPResponse(
                sources=None,
                data=None,
                isError=True,
                message=f"Error: {response.status_code} - {response.text}"
            )
    except httpx.RequestError as e:
        logger.error(f"Request failed: {e}")
        return MCPResponse(
            sources=None,
            data=None,
            isError=True,
            message=f"Request failed: {e}"
        )


# Define a custom lifespan for FastAPI with a task to manage MCP
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Initialize MCP server task group
    logger.info("Initializing MCP server task group...")

    global async_client
    async_client = httpx.AsyncClient(timeout=10)

    async with contextlib.AsyncExitStack() as stack:
        await stack.enter_async_context(mcp.session_manager.run())
        yield

    # Shutdown: Close the AsyncClient
    await async_client.aclose()


@router.get("/company-overview/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "ok"}


app = FastAPI(lifespan=lifespan)
app.mount("/company-overview", mcp.streamable_http_app())
app.include_router(router)
logger.info("Company Info MCP Server started successfully.")
