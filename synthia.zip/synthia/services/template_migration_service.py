import aioboto3
import logging
from pathlib import Path
from typing import Callable
from src.synthia.aws_utils.aws_client import get_region
from src.synthia.config.api_config import get_config


logger = logging.getLogger(__name__)


class TemplateMigrationService:
    """Temporary (from Oct -> Dec) migration service allowing to load the prompt and extraction templates to s3. Also useful during development."""

    def __init__(self):
        self.prompt_templates_path = Path(__file__).parent.parent / "resources" / "templates"
        self.excel_extraction_configs_path = self.prompt_templates_path / "excel_prop_data"

    async def migrate_templates(self):
        config = get_config()
        destination_s3_bucket_name = config.get("templates_s3_bucket", "creditmemo-templates-dev.us-east-1.cm-tl")
        session = aioboto3.Session(region_name=get_region())
        async with session.client("s3") as s3_client:
            await self.migrate_prompt_templates(
                s3_client,
                destination_s3_bucket_name,
                destination_s3_prefix=config.get("s3_templates_prefix_default", "system/")
            )
            await self.migrate_excel_extraction_configs(
                s3_client,
                destination_s3_bucket_name,
                destination_s3_prefix=f"excelconfigs/spglobal.com/" # there is currently no configuration for this section available
            )

    async def migrate_prompt_templates(self, s3_client, destination_s3_bucket_name, destination_s3_prefix):
        await self.migrate_folder(
            s3_client,
            destination_s3_bucket_name,
            destination_s3_prefix,
            self.prompt_templates_path,
            lambda path: path.name.endswith('.yaml')
        )

    async def migrate_excel_extraction_configs(self, s3_client, destination_s3_bucket_name, destination_s3_prefix):
        await self.migrate_folder(
            s3_client,
            destination_s3_bucket_name,
            destination_s3_prefix,
            self.excel_extraction_configs_path,
            lambda path: path.name.endswith('.json')
        )

    async def migrate_folder(self, s3_client, destination_s3_bucket_name: str, destination_s3_prefix: str, source_path: Path, source_file_filter: Callable[[Path], bool]):
        for source_file_path in source_path.iterdir():
            if not source_file_path.is_file() or not source_file_filter(source_file_path):
                continue
            source_file_absolute_path = source_file_path.absolute()
            destination_object_path = f"{destination_s3_prefix}{source_file_path.name}"
            logger.info("Migrating file: %s to s3: %s/%s", source_file_absolute_path, destination_s3_bucket_name, destination_object_path)
            with source_file_path.open('rb') as source_file_handle:
                await s3_client.upload_fileobj(source_file_handle, destination_s3_bucket_name, destination_object_path)