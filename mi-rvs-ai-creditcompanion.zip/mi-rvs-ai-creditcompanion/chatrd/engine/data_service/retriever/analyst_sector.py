from typing import Optional

from chatrd.engine.configuration import Constants
from chatrd.engine.data_service.retriever.base import BaseRetriever
from chatrd.engine.data_service.retriever.utils import (
    _retrieve,
    get_multiple_keyinstn_id,
)
from chatrd.engine.data_service.schema import Analyzer, ProcessorInput, Retriever


class AnalystSectorRetriever(BaseRetriever):
    def retrieve(
        self,
        processor: ProcessorInput = None,
        analyzer: Optional[Analyzer] = None,
    ) -> Retriever:
        # Read Arguments
        entities = processor.entities

        if not entities or len(entities["companies"]) == 0:
            return Retriever()
        endpoint_path = Constants.RatingsAPI.RATINGS_API_ANALYST_SECTORS_ENDPOINT_PATH
        parameter = get_multiple_keyinstn_id(entities)
        return _retrieve(endpoint_path=endpoint_path, parameter=parameter)
