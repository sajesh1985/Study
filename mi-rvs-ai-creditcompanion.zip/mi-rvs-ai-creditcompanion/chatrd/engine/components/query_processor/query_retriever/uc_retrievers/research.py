import logging
from datetime import datetime
from typing import Dict, List, Union

from botocore.client import BaseClient

from chatrd.core.document.schema import Document, OrderedSet
from chatrd.core.llm import LCLLMFactory
from chatrd.core.llm.components import BaseLanguageModel
from chatrd.core.synthesizer import CompactAndRefineSynthesizer
from chatrd.core.vectorstore import OpenSearch
from chatrd.engine.components.query_analyzer.entity_extractor.utils import (
    Companies,
    Entities,
    RevenueSource,
)
from chatrd.engine.components.query_processor.query_retriever.article_type_extractor import (
    ArticleTypeExtractor,
)
from chatrd.engine.components.query_processor.query_retriever.reranker import (
    get_reranked_documents,
)
from chatrd.engine.components.query_processor.query_retriever.uc_retrievers.base import (
    UCRetriever,
)
from chatrd.engine.components.query_processor.query_retriever.uc_retrievers.prompt_templates import (
    OPENING_PROMPT,
    RESEARCH_EXAMPLES,
    RESEARCH_PROMPT,
)
from chatrd.engine.components.query_processor.query_retriever.utils import (
    add_unstructured_source,
    get_custom_logic_filters_for_entities,
    get_filters_for_research,
    post_process_retrieved_docs,
)
from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.responses import get_default_answer

logger = logging.getLogger(__name__)

config_machinery = get_config_machinery()


class ResearchRetriever(UCRetriever):
    def __init__(self, vector_stores_dict: Dict[str, OpenSearch], reranker_client: BaseClient):
        self.vector_stores_dict = vector_stores_dict
        self.top_k_text_research = config_machinery.get_config_value(Constants.GeneralConstants.TOP_K_TEXT_RESEARCH)
        self.top_k_text_research_rerank = config_machinery.get_config_value(
            Constants.GeneralConstants.TOP_K_TEXT_RESEARCH_RERANK
        )
        self.reranker_client = reranker_client
        self.reranker_endpoint_name = config_machinery.get_config_value(
            Constants.SageMaker.SAGEMAKER_RERANKER_ENDPOINT_NAME
        )

    def retrieve(
        self,
        query: str,
        entities: Entities,
        uc_type: str,
        model_name_for_tool_classifier: str,
        temperature_for_tool_classififer: float,
        original_language: str,
        original_query: str,
        multi_uc_type: bool = False,
    ):
        """
        This method returns a list of article summaries.
        """
        all_entities = entities.companies + entities.revenue_sources
        summaries = OrderedSet()
        base_url = "https://www.capitaliq.spglobal.com/web/client?auth=inherit#ratingsdirect/creditResearch?rid="
        for entity in all_entities:
            query = self.rephrased_query(query, entity)
            vector_db_retrieved_documents = self.vector_db_retrieval(
                query=query,
                entity=entity,
                uc_type=uc_type,
                model_name_for_filtering=model_name_for_tool_classifier,
                original_language=original_language,
            )
            articles_to_summarize = [article for article in vector_db_retrieved_documents if isinstance(article, List)]
            if articles_to_summarize:
                non_flex_llm_synthesizer = LCLLMFactory().get_llm(
                    deployment_name_or_model_id="haiku",
                    temperature=0.0,
                )
                flex_llm_synthesizer = LCLLMFactory().get_llm(
                    deployment_name_or_model_id="anthropic.claude-3-7-sonnet-20250219-v1:0",
                    temperature=0.0,
                )
                opening = self.generate_opening(
                    query=query,
                    llm=non_flex_llm_synthesizer,
                    original_query=original_query,
                    original_language=original_language,
                )
                summaries.add(Document(content=opening, synthesize=False))
                results = [
                    self.summarize(
                        article,
                        query,
                        non_flex_llm_synthesizer,
                        flex_llm_synthesizer,
                        original_query,
                        original_language=original_language,
                    )
                    for article in articles_to_summarize
                ]
                for article, abstract in zip(articles_to_summarize, results):
                    article_id = article[0].metadata["articleID"]
                    article_date = article[0].metadata["articleReleaseDate"]
                    article_title = (
                        article[0].metadata["PreferredTitle"].replace(":", "\:").replace("$", "\$").replace("<br>", "")
                    )
                    article_date = datetime.strptime(article_date, "%Y-%m-%dT%H:%M:%S").strftime("%b %d, %Y")
                    summary = (
                        f'<strong><a href="{base_url}{article_id}" target="_blank">{article_title}'
                        f"</a></strong>, <em>{article_date}</em>"
                    )
                    summaries.add(Document(content=summary, metadata=article[0].metadata, synthesize=False))
                    summaries.add(Document(content=abstract, synthesize=False))
            else:
                summaries.add(vector_db_retrieved_documents[0])

        summaries = add_unstructured_source(summaries)
        return summaries

    def vector_db_retrieval(
        self,
        query: str,
        entity: Union[Companies, RevenueSource],
        uc_type: str,
        model_name_for_filtering: str,
        original_language: str,
    ):
        article_type_extractor = ArticleTypeExtractor(model_name=model_name_for_filtering)
        article_type_filter = article_type_extractor.get(question=query)
        logger.info(f"filter applied for article type: {article_type_filter}")
        _, relevant_article_ids = get_filters_for_research(
            vector_stores_dict=self.vector_stores_dict, entity=entity, article_type=article_type_filter, uc_type=uc_type
        )
        if not relevant_article_ids:
            return get_default_answer(
                entity=entity, reason="no_relevant_articles", original_language=original_language, query=query
            )
        all_documents = []
        for fetched_ids in relevant_article_ids:
            article_filter = get_custom_logic_filters_for_entities([fetched_ids])
            logger.info(f"filter applied for research doc : {article_filter}")
            retrieved_documents, scores = self.vector_stores_dict["research"].get_relevant_documents(
                query,
                efficient_filter=article_filter,
                model_id=config_machinery.get_config_value(Constants.OpenSearch.NEURAL_SEARCH_MODEL_ID),
                search_pipeline=config_machinery.get_config_value(
                    Constants.OpenSearch.HYBRID_SEARCH_SEARCH_PIPELINE_ID
                ),
                top_k_text_chunks=self.top_k_text_research,
            )

            retrieved_documents = get_reranked_documents(
                query=query,
                retrieved_documents=retrieved_documents,
                entity=entity,
                reranker_client=self.reranker_client,
                reranker_endpoint_name=self.reranker_endpoint_name,
                reranker_threshold=None,
                top_k_text_chunks=self.top_k_text_research_rerank,
            )
            retrieved_documents = post_process_retrieved_docs(retrieved_documents)
            if not retrieved_documents:
                return get_default_answer(
                    entity=entity, reason="no_relevant_articles", original_language=original_language, query=query
                )
            retrieved_documents = self.add_additional_metadata_to_documents(
                uc_type=uc_type, user_query=query, entity=entity, documents=retrieved_documents
            )
            all_documents.append(list(retrieved_documents))
        return all_documents

    def summarize(
        self,
        article_documents: list[Document],
        query: str,
        non_flex_llm: BaseLanguageModel,
        flex_llm: BaseLanguageModel,
        original_query: str,
        original_language: str,
    ):

        prompt = RESEARCH_PROMPT.replace("{original_language}", original_language)

        response_synthesizer = CompactAndRefineSynthesizer(
            non_flex_llm=non_flex_llm,
            flex_llm=flex_llm,
            streaming=True,
            expert_guidelines="",
            initial_prompt_template_str=prompt,
            refine_prompt_str="",
            initial_prompt_template_flex_str="",
        )
        response_synthesizer.update_prompt_templates({"examples": RESEARCH_EXAMPLES})
        summary = response_synthesizer.get_response(
            message_str="", chat_str=original_query, documents=article_documents
        )
        return summary

    def summarize_without_streaming(
        self,
        article_documents: list[Document],
        query: str,
        non_flex_llm: BaseLanguageModel,
        flex_llm: BaseLanguageModel,
        original_query: str,
        original_language: str,
    ):
        response_synthesizer = CompactAndRefineSynthesizer(
            non_flex_llm=non_flex_llm,
            flex_llm=flex_llm,
            streaming=False,
            expert_guidelines="",
            initial_prompt_template_str=RESEARCH_PROMPT,
            refine_prompt_str="",
            initial_prompt_template_flex_str="",
        )
        response_synthesizer.exclude_llm_metadata_super_list = config_machinery.get_config_value(
            Constants.GeneralConstants.EXCLUDE_LLM_METADATA_SUPER_LIST
        )
        response_synthesizer.update_prompt_templates({"examples": RESEARCH_EXAMPLES})
        summary = response_synthesizer.get_response(
            message_str="", chat_str=original_query, documents=article_documents, original_language=original_language
        )
        return summary.content

    def generate_opening(
        self, query: str, llm: BaseLanguageModel, original_query: str, original_language: str, stream: bool = True
    ):
        prompt = OPENING_PROMPT.format(query_str=original_query, original_language=original_language)
        response = llm.invoke(prompt)
        return response.content
