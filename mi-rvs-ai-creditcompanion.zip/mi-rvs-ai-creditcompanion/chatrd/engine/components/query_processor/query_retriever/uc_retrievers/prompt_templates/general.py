GENERAL_EXAMPLES = """
<macro_examples>
--------------------------------
{
  "question": "Make a summary for US Tariff policy and the effect on <xyz region/country> Economy."
  "is_micro": false,
  "is_macro": true
}
--------------------------------
{
  "question": "What are the recent trends affecting the <xyz industry>?"
  "is_micro": false,
  "is_macro": true
}
--------------------------------
{
  "question": "what are the latest publications on the <xyz sector>?"
  "is_micro": false,
  "is_macro": true
}
--------------------------------
{
  "question": "Please conduct an IICRA on <xyz industry>"
  "is_micro": false,
  "is_macro": true
}
--------------------------------
{
  "question": "What are the risks and opportunities for <xyz industry>?"
  "is_micro": false,
  "is_macro": true
}
--------------------------------
{
  "question": "Provide european macroeconomic analysis"
  "is_micro": false,
  "is_macro": true
}
--------------------------------
{
  "question": "give me a brief summary of <xyz sector> in <abc country>"
  "is_micro": false,
  "is_macro": true
}
</macro_examples>
<micro_examples>
--------------------------------
{
  "question": "Can you provide a summary on <xyz company>?",
  "is_micro": true,
  "is_macro": false
}
--------------------------------
{
  "question": "Provide me a summary of <xyz company> this Q1 results",
  "is_micro": true,
  "is_macro": false
}
--------------------------------
{
  "question": "What is the new transaction model for <xyz company>",
  "is_micro": true,
  "is_macro": false
}
--------------------------------
{
  "question": "How <xyz company> manages its supply chain risk?",
  "is_micro": true,
  "is_macro": false
}
--------------------------------
{
  "question": "can you provide a breakdown of <xyz company> total revenue breakdown by region in <xyz country>?",
  "is_micro": true,
  "is_macro": false
}
--------------------------------
{
  "question": "Can you please give me an overall summary of <xyz entity> investments?",
  "is_micro": true,
  "is_macro": false
}
--------------------------------
{
  "question": "How will the merge of comanies <abc company> and <xyz company> impact the realease of the <product>?",
  "is_micro": true,
  "is_macro": false
}
--------------------------------
{
  "question": "Please list the subsidiaries and suppliers of <xyz company> for <year>",
  "is_micro": true,
  "is_macro": false
}
--------------------------------
{
  "question": "Why did <xyz company> not have a credit rating until <year>",
  "is_micro": true,
  "is_macro": false
}
--------------------------------
{
  "question": "Describe the business trend for <xyz company>.",
  "is_micro": true,
  "is_macro": false
}
--------------------------------
</micro_examples>
<micro_macro_examples>
--------------------------------
{
  "question": "What is the impact of rising oil prices on the profitability of <xyz company>?",
  "is_micro": true,
  "is_macro": true
}
--------------------------------
{
  "question": "Explain impact of U.S. tariff on <xyz company>",
  "is_micro": true,
  "is_macro": true
}
--------------------------------
{
  "question": "Can you provide market research on <xyz company>?",
  "is_micro": true,
  "is_macro": true
}
--------------------------------
{
  "question": "Could you elaborate on the global trends that are affecting <xyz company>?",
  "is_micro": true,
  "is_macro": true
}
--------------------------------
{
  "question": "What are the fiscal risks in <xyz country>?",
  "is_micro": true,
  "is_macro": true
}
--------------------------------
{
  "question": "What is the latest research on North American banks?",
  "is_micro": true,
  "is_macro": true
}
--------------------------------
{
  "question": "What companies could be affected by increase of natural gas prices?",
  "is_micro": true,
  "is_macro": true
}
--------------------------------
{
  "question": "Which banks are consolidating in <xyz country>?",
  "is_micro": true,
  "is_macro": true
}
--------------------------------
{
  "question": "Give me the risks of Canadian steel companies rated BB+ or less.",
  "is_micro": true,
  "is_macro": true
}
--------------------------------
{
  "question": "What is GDP in <xyz country>?",
  "is_micro": true,
  "is_macro": true
}
--------------------------------
{
  "question": "What is the gross refining margin outlook and earnings outlook for oil refining companies?",
  "is_micro": true,
  "is_macro": true
}
--------------------------------
{
  "question": "Summarize the prospect of construction companies in S. Korea.",
  "is_micro": true,
  "is_macro": true
}
</micro_macro_examples>
"""

GENERAL_PROMPTS = """
You are an expert credit analyst tasked with categorizing user questions as either micro-level, macro-level, or both.

### Definitions:

- **Micro-Level Questions**: These focus on specific entities (mentioned by their names), individuals, comparison to peers/others or detailed aspects of a situation. They often involve inquiries about particular companies, their products, results, or operational strategies. For example, asking about credit risk of <xyz company>. Remember: Always set is_micro to true (and is_macro depending on the other parts of question) if any company is mentioned by its name.

- **Macro-Level Questions**: These focus on broader economic factors, trends, or policies that affect entire industries, sectors, subsectors or economies. They typically involve inquiries about economic indicators, market trends, or regulatory impacts.

- **Micro-Macro Questions**: Questions that incorporate elements from both micro and macro perspectives. They may: 
  - Ask about specific companies or entities while also considering broader economic trends, conditions, or factors that extend beyond the company's own business environment.
  - Inquire about economic indicators at the country level.
  - Require answers that address characteristics of a group of entities (companies, corporates, banks). For example, to answer 'risks of steel companies in Europe' one may need to mention specific companies by name, therefore it's both micro- and macro-level question.

### Instructions:

Analyze the user question and determine whether it is micro, macro, or both.
Provide the output in JSON format with the following structure:
- question: The original user question.
- is_micro: A boolean indicating if the question is micro (true/false).
- is_macro: A boolean indicating if the question is macro (true/false).

### Examples:
{examples}

### User Question:
{question}

Please provide the output in JSON format as described above. Do NOT output other than valid JSON format.
"""
