import logging
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Sequence

from chatrd.core.document import Document
from chatrd.core.utils import ChatMessage, chat_history_to_str

logger = logging.getLogger(__name__)


class BaseResponseSynthesizer(ABC):
    """Base Response Synthesizer Class"""

    @abstractmethod
    def get_response(self, message_str: str, chat_str: str, documents: Sequence[Dict], **kwargs: Dict[str, Any]) -> str:
        """Get response."""

    def synthesize(
        self,
        message: Optional[ChatMessage],
        documents: List[Document],
        chat_history: Sequence[ChatMessage],
        **kwargs: Dict[str, Any],
    ) -> str:

        if len(documents) == 0:
            logger.error("Zero documents passed to the synthesizer.")
            return ""

        chat_str = chat_history_to_str(chat_history, additional_message=message)

        response = self.get_response(
            message_str=None,
            chat_str=chat_str,
            documents=documents,
            **kwargs,
        )

        return response
