
import React from 'react';
import { Answer, DocWrapper } from './KnowledgeDiscoveryView.styles';
import {
  LicenseManager,
} from 'ag-grid-enterprise';
import { config } from '@spglobal/spa';
import {
  KnowledgeDiscoveryResponseNode,
} from '@root/types/api';
const AG_GRID_LICENSE_KEY = config('agGridLicenseKey');
LicenseManager.setLicenseKey(AG_GRID_LICENSE_KEY);

interface KnowledgeDiscoveryViewProps extends React.ComponentPropsWithoutRef<'div'> {
  answer: KnowledgeDiscoveryResponseNode['answer'];
  documents: KnowledgeDiscoveryResponseNode['documents'];
}

export const KnowledgeDiscoveryView: React.FC<KnowledgeDiscoveryViewProps> = ({
  answer
}: KnowledgeDiscoveryViewProps) => {
  return (
    <DocWrapper>
      <Answer>{answer}</Answer>
      
    </DocWrapper>
  );
};
