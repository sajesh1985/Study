import datetime
import re
from datetime import date, timedelta

from dateutil.relativedelta import relativedelta
from word2number import w2n

from chatrd.engine.data_service.model_output_parser import utils


def test_update_unit_scale_btw_case():
    lookup_value, magnitude = "[10000]-[500000]", 1000
    result = utils.update_unit_scale(lookup_value, magnitude)
    expected_result = "[10.0]-[500.0]"

    assert expected_result == result


def test_update_unit_scale_bigger_bigger_than_case():
    lookup_value, magnitude = "500000", 1
    result = utils.update_unit_scale(lookup_value, magnitude)
    expected_result = "500000.0"

    assert expected_result == result


def test_check_dynamic_time_window_this_week():
    kpqi, lookup_value, operator_payload = 322992, "this week", 26
    result_lookup_value, result_operator = utils.check_dynamic_time_window(kpqi, lookup_value, operator_payload)

    assert "]-[" in result_lookup_value
    assert result_operator == 17


def test_check_dynamic_time_window_this_month():
    kpqi, lookup_value, operator_payload = 322992, "this month", 26
    result_lookup_value, result_operator = utils.check_dynamic_time_window(kpqi, lookup_value, operator_payload)

    match_list = re.findall(r"\[\d+\/01\/\d+\]", result_lookup_value)

    assert len(match_list) >= 1
    assert "]-[" in result_lookup_value
    assert result_operator == 17


def test_check_dynamic_time_window_this_year():
    kpqi, lookup_value, operator_payload = 322992, "this year", 26
    result_lookup_value, result_operator = utils.check_dynamic_time_window(kpqi, lookup_value, operator_payload)

    match_list = re.findall(r"\[01\/01\/\d+\]", result_lookup_value)

    assert len(match_list) >= 1
    assert "]-[" in result_lookup_value
    assert result_operator == 17


# def test_check_dynamic_time_window_last_three_months():
#     kpqi, lookup_value, operator_payload = 336004, "[11/22/2023]-[02/22/2024]", 17
#     result_lookup_value, result_operator = utils.check_dynamic_time_window(
#         kpqi, lookup_value, operator_payload
#     )
#
#     breakpoint()
#     assert 1==2
#     # match_list = re.findall("\[01\/01\/\d+\]", result_lookup_value)
#     #
#     # assert len(match_list) >= 1
#     # assert "]-[" in result_lookup_value
#     # assert result_operator == 17


def test_check_dynamic_time_window_days():
    kpqi, lookup_value, operator_payload = 322992, "last two days", 26
    today = datetime.date.today()
    expected_starting_day = today - relativedelta(days=2)

    today = today.strftime("%m/%d/%Y")
    expected_starting_day = expected_starting_day.strftime("%m/%d/%Y")
    expected_result = f"[{expected_starting_day}]-[{today}]"

    result_lookup_value, result_operator = utils.check_dynamic_time_window(kpqi, lookup_value, operator_payload)
    assert result_lookup_value == expected_result
    assert result_operator == 17


def test_check_dynamic_time_window_months():
    kpqi, lookup_value, operator_payload = 322992, "last four months", 26

    today = datetime.date.today()
    expected_starting_day = today - relativedelta(months=4)

    today = today.strftime("%m/%d/%Y")
    expected_starting_day = expected_starting_day.strftime("%m/%d/%Y")
    expected_result = f"[{expected_starting_day}]-[{today}]"

    result_lookup_value, result_operator = utils.check_dynamic_time_window(kpqi, lookup_value, operator_payload)
    assert result_lookup_value == expected_result
    assert result_operator == 17


def test_check_dynamic_time_window_years():
    kpqi, lookup_value, operator_payload = 322992, "last two years", 26

    today = datetime.date.today()
    expected_starting_day = today - relativedelta(years=2)

    today = today.strftime("%m/%d/%Y")
    expected_starting_day = expected_starting_day.strftime("%m/%d/%Y")
    expected_result = f"[{expected_starting_day}]-[{today}]"

    result_lookup_value, result_operator = utils.check_dynamic_time_window(kpqi, lookup_value, operator_payload)
    assert result_lookup_value == expected_result
    assert result_operator == 17


def test_check_dynamic_time_window_with_perfect_input():
    kpqi, lookup_value, operator_payload = 322992, "-12m", 26
    result_lookup_value, result_operator = utils.check_dynamic_time_window(kpqi, lookup_value, operator_payload)

    assert result_lookup_value == "-12M"
    assert result_operator == operator_payload

    kpqi, lookup_value, operator_payload = 320342, "last 1 day", 26
    result_lookup_value, result_operator = utils.check_dynamic_time_window(kpqi, lookup_value, operator_payload)

    assert result_lookup_value == "-1D"
    assert result_operator == operator_payload


# def test_check_dynamic_time_window_for_rating_date():
#     kpqi, lookup_value, operator_payload = 336004, "last 7 days", 26
#     result_lookup_value, result_operator = utils.check_dynamic_time_window(
#         kpqi, lookup_value, operator_payload
#     )
#
#     today = datetime.date.today()
#     expected_starting_day = today - relativedelta(days=7)
#
#     today = today.strftime("%m/%d/%Y")
#     expected_starting_day = expected_starting_day.strftime("%m/%d/%Y")
#     expected_result = f"[{expected_starting_day}]-[{today}]"
#
#     assert result_lookup_value == expected_result
#     assert result_operator == 17


def test__format_time_period():
    lookup_value = "this week"
    today = date.today()
    start = today - timedelta(days=today.weekday())
    start_date = start.strftime("%m/%d/%Y")
    end_date = today.strftime("%m/%d/%Y")
    expected_value = f"[{start_date}]-[{end_date}]"

    lookup_value, operator_payload = utils._format_time_period(lookup_value)

    assert lookup_value == expected_value
    assert operator_payload == 17


def test__format_num_time_period():
    lookup_value = "last 4 days"
    today = date.today()
    time_range = w2n.word_to_num("4")
    starting_day = today - relativedelta(days=time_range)
    start_date = starting_day.strftime("%m/%d/%Y")
    end_date = today.strftime("%m/%d/%Y")
    expected_value = f"[{start_date}]-[{end_date}]"

    lookup_value, operator_payload = utils._format_num_time_period(lookup_value, 3)

    assert lookup_value == expected_value
    assert operator_payload == 17


def test__format_num_time_period_valid_datetime():
    lookup_value = "11/01/2023"
    operator_payload = 3

    result_lookup_value, result_operator_payload = utils._format_num_time_period(lookup_value, operator_payload)

    assert lookup_value == result_lookup_value
    assert result_operator_payload == operator_payload
