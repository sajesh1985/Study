from .outlook import (
    OUTLOOK_SUBROUTING_EXAMPLES,
    OUTLOOK_SUBROUTING_PARSER_TEMPLATE,
    OutlookSubrouting,
    OutlookSubroutingValues,
)
from .rating_action import (
    RATING_ACTION_SUBROUTING_TEMPLATE,
    parser_rating_action_subrouting,
)
from .scores_modifiers import (
    SCORES_MODIFIERS_TRIGGERS_PROMPT,
    add_company_name_to_prompt,
    parser_scores_modifiers_subrouting,
)
