from functools import lru_cache
import os
from botocore.config import Config
from boto3 import Session
from botocore.client import BaseClient
import json
import logging
from botocore.exceptions import ClientError
from src.synthia.utils.logging_config import configure_logging
from typing import Optional


logger = configure_logging(logger_name=__name__, module_levels={"boto3": logging.WARNING, "botocore": logging.WARNING})


def get_region() -> str:
    aws_region = os.getenv("AWS_REGION", "us-east-1")
    return aws_region or "us-east-1" # Explicitly set default region if exposed AWS_REGION is empty


@lru_cache(maxsize=1)
def get_boto_session():
    """Cache the session, which manages connection pooling."""
    return Session()


def get_aws_client(service: str, region: str = "us-east-1", max_attempts: int = 10, pool_connections: int = 50
                   , read_timeout: int = 420, connect_timeout: int = 10, signature_version: Optional[str] = None
    ):
    logger.info(f"Creating AWS client for {service} in {region}")
    session = get_boto_session()

    retry_config = Config(
        region_name=get_region(),
        retries={
            "max_attempts": max_attempts,
            "mode": "standard"
        },
        max_pool_connections=pool_connections,
        read_timeout=read_timeout,
        signature_version=signature_version,
        connect_timeout=connect_timeout
    )

    client = session.client(
        service_name=service, config=retry_config, region_name=region,
    )

    logger.info(f"Created AWS client for {service} in {region}")

    return client


def get_secret(secrets_manager_client: BaseClient, secret_name: str):
    response = secrets_manager_client.get_secret_value(SecretId=secret_name)
    secret = json.loads(response.get("SecretString"))
    return secret

def get_parameter(ssm_client: BaseClient, parameter_name: str, with_decryption: bool = True):
    try:
        logger.info(f"Fetching AWS parameters for {parameter_name}")
        response = ssm_client.get_parameter(
            Name=parameter_name,
            WithDecryption=with_decryption
        )
        logger.info(f"Fetched AWS parameters for {parameter_name}")
        return response['Parameter']['Value']
    except ClientError as e:
        print(f"Error retrieving parameter {parameter_name}: {e}")
        return None


def get_env_specific_secret_key(key: str) -> str:
    env_name = os.getenv("ENV", "dev")
    # Explicitly set default env if exposed ENV is empty
    env_name = env_name or "dev"
    aws_region = get_region()
    key = f"creditmemo/{env_name}/{aws_region}/{key}"
    logger.info(f"Fetch secret key :: {key}")
    return key


def get_env_specific_params_key(key: str) -> str:
    env_name = os.getenv("ENV", "dev")
    # Explicitly set default env if exposed ENV is empty
    env_name = env_name or "dev"
    aws_region = get_region()
    return f"/creditmemo/{env_name}/{aws_region}/{key}"
