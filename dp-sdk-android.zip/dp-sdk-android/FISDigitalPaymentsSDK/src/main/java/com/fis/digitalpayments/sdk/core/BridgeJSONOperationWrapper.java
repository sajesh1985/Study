// Copyright Notice!
// This document is protected under the trade secret and copyright
// laws as the property of Fidelity National Information Services, Inc.
// Copying, reproduction or distribution should be limited and only to
// employees with a “need to know” to do their job.
// Any disclosure of this document to third parties is strictly prohibited.
// © 2017 Fidelity National Information Services.
// All rights reserved worldwide.

package com.fis.digitalpayments.sdk.core;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * @author e1035413  on 1/20/2017.
 */

public class BridgeJSONOperationWrapper {

    public static void putJSON(JSONObject jsonObject, String name, Object value) throws BridgeException {
        try {
            jsonObject.put(name, value);
        } catch (JSONException e) {
            String attemptedName = name != null ? name : "NULL";
            throw new BridgeException(String.format("Error putting JSON value for '%s'", attemptedName), e);
        }
    }

}
