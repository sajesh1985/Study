from .synthesizer import QuerySynthesizer
