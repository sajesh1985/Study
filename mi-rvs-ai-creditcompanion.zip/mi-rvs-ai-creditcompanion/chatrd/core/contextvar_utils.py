from contextvars import ContextVar

user_ctx_var: ContextVar[str] = ContextVar("user_ctx", default={"auth_token": None, "cookie": None})
