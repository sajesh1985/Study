from chatrd.core.thread_utils import submit_to_shared_thread_pool
from chatrd.engine.components.query_analyzer.translator.translator import (
    InputModerationTranslator,
)


class Get_translation_result:
    def __init__(self, text, original_language):
        self.text = text
        self.original_language = original_language
        self.translator = InputModerationTranslator()
        if self.original_language.capitalize() != "English":
            self.text_process = submit_to_shared_thread_pool(
                self.translator.translator, self.text, self.original_language
            )

    def result(self):
        if self.original_language.capitalize() != "English":
            return self.text_process.result()
        else:
            return self.text
