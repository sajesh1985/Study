from datetime import datetime
from typing import Dict, List

rating_debt_type_list = [
    "Issuer Credit Rating (Foreign Currency LT)",
    "Issuer Credit Rating (Foreign Currency ST)",
    "Issuer Credit Rating (Local Currency LT)",
    "Issuer Credit Rating (Local Currency ST)",
    "Financial Strength Rating (Local Currency LT)",
    "Financial Strength Rating (Local Currency ST)",
    "Financial Strength Rating (Argentina National Scale LT)",
]


def extract_debt_type(df, rating_debt_type_list):
    standardized_rating_debt_type_list = [item.replace(" ", "") for item in rating_debt_type_list if item is not None]
    for name in df:
        mnemonic_name = name.get("MnemonicName")
        if mnemonic_name is None:
            continue
        standardized_name = mnemonic_name.replace(" ", "")
        if standardized_name in standardized_rating_debt_type_list:
            return mnemonic_name
    return []


def add_dict_to_scores_modifiers(list_of_dicts, entity_name):
    new_dict = {
        "Id": 0,
        "ParentId": 0,
        "MnemonicName": None,
        "MnemonicClass": None,
        "DataField": "RT_ENTITY_NAME",
        "ProductDefinition": None,
        "Company1": entity_name,
        "HasScores": "1",
    }

    list_of_dicts.insert(0, new_dict)

    return list_of_dicts


def expand_rename_company_columns(data, num_companies=25):
    """
    Expands and rename the data to include multiple company columns (1 to 25),
    copying Company1 data to column1 and leaving the rest empty.

    Args:
        data (list): List of dictionaries containing data with Company1 column
        num_companies (int): Number of company columns to create (default: 25)

    Returns:
        list: Modified data with expanded company columns
    """
    modified_data = []
    for item in data:
        new_item = item.copy()
        company1_value = new_item.get("Company1", "")
        if "Company1" in new_item:
            del new_item["Company1"]
        new_item["Column1"] = company1_value
        for i in range(2, num_companies + 1):
            new_item[f"Column{i}"] = ""
        new_item.pop("HasScores", None)
        modified_data.append(new_item)
    return modified_data


def format_dates_score_modifiers(data):
    formatted_data = []
    for item in data:
        formatted_item = item.copy()
        if "Column1" in formatted_item:
            value = formatted_item["Column1"]
            if value and isinstance(value, str):
                value = value.strip().upper()
                try:
                    dt = datetime.strptime(value, "%b %d %Y %I:%M%p")
                    formatted_item["Column1"] = dt.strftime("%m/%d/%Y")
                except ValueError:
                    pass

        formatted_data.append(formatted_item)

    return formatted_data


def modify_urls_company_rating_scores(data):
    base_url = "/web/client?auth=inheritt"

    for item in data:
        new_item = item.copy()
        mnemonic = item.get("MnemonicName", "")
        mnemonic = "" if mnemonic is None else mnemonic.upper()

        if mnemonic == "RATINGS & SCORES" or mnemonic == "RATINGS & FACTORS":
            for key, value in item.items():
                if key.startswith("Column") and value not in [None, ""]:
                    new_href = f"href='{base_url}#company/profile?id="
                    company_id = value.split("company/profile?Id=")[-1].split(">")[0]
                    new_item[key] = f"<a target='_blank' {new_href}{company_id}'>View Profile</a>"
                elif key.startswith("Column"):
                    new_item[key] = ""

        item.update(new_item)
    return data


def check_scores_modifiers_fields_in_data(df: List[Dict], sector: str):
    data_availability = {"score_modifier": False, "rating_info": False}
    score_fields_corp_insurance = {
        "SP_NR_GC_BRP_ANCH": "Business Risk",
        "SP_NR_GC_IR_ANCH": "Industry Risk",
        "SP_NR_GC_CR_ANCH": "Country Risk",
        "SP_NR_GC_CICRA_ANCH": "CICRA",
        "SP_NR_GC_CP_ANCH": "Competitive Position",
        "SP_NR_GC_FRPCFAL_ANCH": "Financial Risk",
        "SP_NR_GC_IRO_ANCH": "Anchor",
    }

    modifier_fields_corp_insurance = {
        "SP_NR_DIV_MOD_ADJ_CONC": "Diversification/Portfolio Effect",
        "SP_NR_CS_MOD_ADJ_CONC": "Capital Structure",
        "SP_NR_FP_MOD_ADJ_CONC": "Financial Policy",
        "SP_NR_LIQ_MOD_ADJ_CONC": "Liquidity",
        "SP_NR_MG_MOD_ADJ_CONC": "Management & Governance",
        "SP_NR_CRA_MOD_ADJ_CONC": "Comparable Rating Analysis",
        "SP_NR_GC_SACP": "Stand-Alone Credit Profile",
    }

    bicra_fields = {"ER_ANCH_ROUND": "Economic Risk", "SP_NR_IR_CNTRYIR": "Industry Risk", "RtgAnchorBanks": "Anchor"}

    factors_fields = {
        "SP_NR_BP_MOD_ADJ_CONC": "Business Position",
        "SP_NR_CE_MOD_ADJ_CONC": "Capital & Earnings",
        "SP_NR_RP_MOD_ADJ_CONC": "Risk Position",
        "SP_NR_FL_MOD_ADJ_CONC": "Funding & Liquidity",
        "SP_NR_GC_CRA_ADJ": "Comparable Rating Analysis",
        "SP_NR_GC_SACP": "Stand Alone Credit Profile",
        "SUPPORT_ALAC": "ALAC Support",
        "SUPPORT_GROUP": "Group Support",
        "SUPPORT_GRE": "GRE Support",
        "SUPPORT_SOVEREIGN": "Government Support",
        "ICR_SUPPORT_NAME": "Support Name",
        "ICR_SUPPORT_VALUE": "Support Value",
        "SUPPORT_ADDITIONAL": "Additional Support",
        "SOVEREIGN_CONSTRAINT": "Sovereign Constraint",
        "SUPPORT_GUARANTEE": "Guarantee Support",
        "ADDITIONAL_FACTORS": "Overall Additional Factors",
    }

    required_fields = {
        "RT_ENTITY_NAME": "RT_ENTITY_NAME",
        "RT_ENTITY_ID": "RT_ENTITY_ID",
        "RDICRRatingType": "Rating",
        "RDRatingDate": "Rating Date",
        "RDLastReviewDate": "Last Review Date",
        "RDCreditWatchOutlook": "CreditWatch/Outlook",
        "RDCWOLDate": "CreditWatch/Outlook Date",
    }

    if sector in ["Corporates", "Insurance"]:
        score_fields = score_fields_corp_insurance
        modifier_fields = modifier_fields_corp_insurance
    elif sector == "Financial Institutions":
        score_fields = bicra_fields
        modifier_fields = factors_fields

    all_fields = {**score_fields, **modifier_fields}

    # Checking if score and modifier fields are present
    score_and_modifier_present = any(any(row["DataField"] == field for row in df) for field in all_fields)
    if score_and_modifier_present:
        data_availability["score_modifier"] = True

    # If no score/modifier fields, we are returning only rating info
    if not score_and_modifier_present:
        rating_data_exists = all(any(row["DataField"] == field for row in df) for field in list(required_fields.keys()))

        if rating_data_exists:
            data_availability["rating_info"] = True
            rating_info = [row for row in df if row["DataField"] in required_fields]
            rating_info_sorted = sorted(
                rating_info, key=lambda row: list(required_fields.keys()).index(row["DataField"])
            )
            return rating_info_sorted, data_availability

    return df, data_availability
