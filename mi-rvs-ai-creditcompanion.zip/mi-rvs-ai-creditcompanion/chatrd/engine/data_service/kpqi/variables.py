from .base import KPQI

SECONDARY_KEYS = "secondary_keys"
SECONDARY_KEYS_DEFAULT_VALUE = []

NUM_SECONDARY_KEYS = "num_secondary_keys"
NUM_SECONDARY_KEYS_DEFAULT_VALUE = (
    [
        {
            "key": "FY0",
            "keyJointHint": "sk_584",
            "keyOption": 0,
            "value": "FY0",
            "displayValue": "Latest Fiscal Year",
            "mask": "FY0",
        }
    ],
)

FUNC_SECONDARY = "func_secondary"
FUNC_SECONDARY_DEFAULT_VALUE = None

FUNC_TERTIARY = "func_tertiary"
FUNC_TERTIARY_DEFAULT_VALUE = None


NUM_FUNC_SECONDARY = "num_func_secondary"
NUM_FUNC_SECONDARY_DEFAULT_VALUE = "FY0"

NUM_FUNC_TERTIARY = "num_func_tertiary"
NUM_FUNC_TERTIARY_DEFAULT_VALUE = None

SERVICER_FUNC_SECONDARY_DEFAULT = (
    "Aircraft Servicer,Asset Backed Master Servicer,Asset Backed Servicer,"
    "Auto Servicer,Commercial Construction Loan Servicer,Commercial Construction Loan Special Servicer,"
    "Commercial Fin Loans & Credits Special Servicer,Commercial Finance Servicer,Commercial Finance Special Servicer,"
    "Commercial Loan Servicer,Commercial Master Servicer,Commercial Mortgage Loan Master Servicer,"
    "Commercial Mortgage Loan Primary Servicer,Commercial Mortgage Loan Special Servicer,Commercial Special Servicer,"
    "Consumer Fin Insurance & Rcvbls Special Servicer,Consumer Finance Loans & Credits Primary Servicer,"
    "Consumer Finance Loans & Credits Special Servicer,Consumer Finance Special Servicer,Equipment Leasing Servicer,"
    "Franchise Servicer,Multifamily Housing Revenue Bond Servicer,Residential Loan Servicer,Residential Loan Special Servicer,"
    "Residential Manufactured Housing Mtg Loan Servicer,Residential Master Servicer,Residential Mortgage Loan Master Servicer,"
    "Residential Mortgage Loan Primary Servicer,Residential Mortgage Loan Special Servicer,"
    "Residential Mortgage Loan Sub Lien Servicer,Residential Mortgage Loan Subprime Servicer,"
    "Residential Reverse Mortgage Loan Servicer,Small Balance Commercial Mortgage Primary Servicer,"
    "Small Balance Commercial Mortgage Special Servicer,Student Loan Servicer,Tax Lien Servicer,Time Share  Servicer"
)


KPQI_CUSTOM_VALUES = {
    KPQI.KPQI_328477: {
        FUNC_SECONDARY: "Investor 1",
        SECONDARY_KEYS: [
            {
                "keyJointHint": "sk_1003",
                "value": "Investor 1",
                "displayValue": "Investor 1",
            }
        ],
    },
    KPQI.RD_CREDIT_RATING_GLOBAL: {
        FUNC_SECONDARY: "Issuer Credit Rating",
        FUNC_TERTIARY: "Foreign Currency LT|0",
        SECONDARY_KEYS: [
            {
                "key": "Issuer Credit Rating",
                "keyJointHint": "sk_1218",
                "keyOption": 0,
                "value": "Issuer Credit Rating",
                "displayValue": "Issuer Credit Rating",
                "mask": "Issuer Credit Rating",
            },
            {
                "key": "Foreign Currency LT",
                "keyJointHint": "sk_1220",
                "keyOption": 0,
                "value": "Foreign Currency LT",
                "displayValue": "Foreign Currency LT",
                "mask": "Foreign Currency LT",
            },
            {
                "key": "0",
                "keyJointHint": "sk_50018",
                "keyOption": 0,
                "value": "0",
                "displayValue": "Current",
                "mask": "0",
            },
        ],
    },
    KPQI.RD_CREDIT_RATING_DATE_GLOBAL: {
        FUNC_SECONDARY: "Issuer Credit Rating",
        FUNC_TERTIARY: "Foreign Currency LT|0",
        SECONDARY_KEYS: [
            {
                "key": "Issuer Credit Rating",
                "keyJointHint": "sk_1218",
                "keyOption": 0,
                "value": "Issuer Credit Rating",
                "displayValue": "Issuer Credit Rating",
                "mask": "Issuer Credit Rating",
            },
            {
                "key": "Foreign Currency LT",
                "keyJointHint": "sk_1220",
                "keyOption": 0,
                "value": "Foreign Currency LT",
                "displayValue": "Foreign Currency LT",
                "mask": "Foreign Currency LT",
            },
            {
                "key": "0",
                "keyJointHint": "sk_50028",
                "keyOption": 0,
                "value": "0",
                "displayValue": "Current",
                "mask": "0",
            },
        ],
    },
    KPQI.RD_RATING_ACTION_DATE_GLOBAL: {
        FUNC_SECONDARY: "Issuer Credit Rating",
        FUNC_TERTIARY: "Foreign Currency LT|0",
        SECONDARY_KEYS: [
            {
                "key": "Issuer Credit Rating",
                "keyJointHint": "sk_1218",
                "keyOption": 0,
                "value": "Issuer Credit Rating",
                "displayValue": "Issuer Credit Rating",
                "mask": "Issuer Credit Rating",
            },
            {
                "key": "Foreign Currency LT",
                "keyJointHint": "sk_1220",
                "keyOption": 0,
                "value": "Foreign Currency LT",
                "displayValue": "Foreign Currency LT",
                "mask": "Foreign Currency LT",
            },
            {
                "key": "0",
                "keyJointHint": "sk_50028",
                "keyOption": 0,
                "value": "0",
                "displayValue": "Current",
                "mask": "0",
            },
        ],
    },
    KPQI.RD_CWOL_GLOBAL: {
        FUNC_SECONDARY: "Issuer Credit Rating",
        FUNC_TERTIARY: "Foreign Currency LT|0",
        SECONDARY_KEYS: [
            {
                "key": "Issuer Credit Rating",
                "keyJointHint": "sk_1218",
                "keyOption": 0,
                "value": "Issuer Credit Rating",
                "displayValue": "Issuer Credit Rating",
                "mask": "Issuer Credit Rating",
            },
            {
                "key": "Foreign Currency LT",
                "keyJointHint": "sk_1220",
                "keyOption": 0,
                "value": "Foreign Currency LT",
                "displayValue": "Foreign Currency LT",
                "mask": "Foreign Currency LT",
            },
            {
                "key": "0",
                "keyJointHint": "sk_50019",
                "keyOption": 0,
                "value": "0",
                "displayValue": "Current",
                "mask": "0",
            },
        ],
    },
    KPQI.RD_CREDIT_WATCH_OUTLOOK_DATE_GLOBAL: {
        FUNC_SECONDARY: "Issuer Credit Rating",
        FUNC_TERTIARY: "Foreign Currency LT|0",
        SECONDARY_KEYS: [
            {
                "key": "Issuer Credit Rating",
                "keyJointHint": "sk_1218",
                "keyOption": 0,
                "value": "Issuer Credit Rating",
                "displayValue": "Issuer Credit Rating",
                "mask": "Issuer Credit Rating",
            },
            {
                "key": "Foreign Currency LT",
                "keyJointHint": "sk_1220",
                "keyOption": 0,
                "value": "Foreign Currency LT",
                "displayValue": "Foreign Currency LT",
                "mask": "Foreign Currency LT",
            },
            {
                "key": "0",
                "keyJointHint": "sk_50029",
                "keyOption": 0,
                "value": "0",
                "displayValue": "Current",
                "mask": "0",
            },
        ],
    },
    KPQI.RD_RATING_ACTION_GLOBAL: {
        FUNC_SECONDARY: "Issuer Credit Rating",
        FUNC_TERTIARY: "Foreign Currency LT|0",
        SECONDARY_KEYS: [
            {
                "key": "Issuer Credit Rating",
                "keyJointHint": "sk_1218",
                "keyOption": 0,
                "value": "Issuer Credit Rating",
                "displayValue": "Issuer Credit Rating",
                "mask": "Issuer Credit Rating",
            },
            {
                "key": "Foreign Currency LT",
                "keyJointHint": "sk_1220",
                "keyOption": 0,
                "value": "Foreign Currency LT",
                "displayValue": "Foreign Currency LT",
                "mask": "Foreign Currency LT",
            },
            {
                "key": "0",
                "keyJointHint": "sk_50020",
                "keyOption": 0,
                "value": "0",
                "displayValue": "Current",
                "mask": "0",
            },
        ],
    },
    KPQI.RD_LAST_REVIEW_DATE_GLOBAL: {
        FUNC_SECONDARY: "Issuer Credit Rating",
        FUNC_TERTIARY: "Foreign Currency LT|0",
        SECONDARY_KEYS: [
            {
                "key": "Issuer Credit Rating",
                "keyJointHint": "sk_1218",
                "keyOption": 0,
                "value": "Issuer Credit Rating",
                "displayValue": "Issuer Credit Rating",
                "mask": "Issuer Credit Rating",
            },
            {
                "key": "Foreign Currency LT",
                "keyJointHint": "sk_1220",
                "keyOption": 0,
                "value": "Foreign Currency LT",
                "displayValue": "Foreign Currency LT",
                "mask": "Foreign Currency LT",
            },
        ],
    },
    KPQI.KPQI_326143: {
        NUM_FUNC_SECONDARY: "Announcement",
        NUM_FUNC_TERTIARY: None,
    },
    KPQI.KPQI_326144: {
        NUM_FUNC_SECONDARY: "Announcement",
        NUM_FUNC_TERTIARY: None,
    },
    KPQI.KPQI_300202: {
        NUM_FUNC_SECONDARY: "Announcement",
        NUM_FUNC_TERTIARY: None,
    },
    KPQI.KPQI_300194: {
        NUM_FUNC_SECONDARY: "Announcement",
        NUM_FUNC_TERTIARY: None,
        NUM_SECONDARY_KEYS: [
            {
                "key": "Announcement",
                "keyJointHint": "sk_98",
                "keyOption": 0,
                "value": "Announcement",
                "displayValue": "Announcement",
                "mask": "Announcement",
            }
        ],
    },
    KPQI.Market_Cap: {
        NUM_FUNC_SECONDARY: "Current",
        NUM_FUNC_TERTIARY: None,
    },
    KPQI.Regulatory_Filer_Type: {
        FUNC_SECONDARY: "MRY",
        SECONDARY_KEYS: [
            {
                "key": "MRY",
                "keyJointHint": "sk_388",
                "keyOption": 0,
                "value": "MRY",
                "displayValue": "MstRctYear",
                "mask": "MRY",
            }
        ],
        NUM_SECONDARY_KEYS: [
            {
                "keyJointHint": "sk_611",
                "value": "Current",
                "key": "Current",
                "displayValue": "Current",
            },
            {"keyJointHint": "sk_50003", "value": "0", "displayValue": "None"},
        ],
    },
    KPQI.KPQI_365227: {
        FUNC_SECONDARY: SERVICER_FUNC_SECONDARY_DEFAULT,
        FUNC_TERTIARY: "All|0",
    },
    KPQI.KPQI_365228: {
        FUNC_SECONDARY: SERVICER_FUNC_SECONDARY_DEFAULT,
        FUNC_TERTIARY: "All|0",
    },
    KPQI.KPQI_338483: {
        FUNC_SECONDARY: "Issue Credit Rating",
        FUNC_TERTIARY: "Foreign Currency LT|0",
    },
    KPQI.KPQI_338482: {
        FUNC_SECONDARY: "Issue Credit Rating",
        FUNC_TERTIARY: "Foreign Currency LT|0",
    },
    KPQI.KPQI_359323: {
        FUNC_SECONDARY: "Issuer",
        FUNC_TERTIARY: None,
        SECONDARY_KEYS: [
            {
                "key": "Issuer",
                "keyJointHint": "sk_1442",
                "keyOption": 0,
                "value": "Issuer",
                "displayValue": "Issuer",
                "mask": "Issuer",
            },
        ],
    },
    KPQI.RD_SEC_CREDIT_RATING_GLOBAL: {
        FUNC_SECONDARY: "Issue Credit Rating",
        FUNC_TERTIARY: "Foreign Currency LT|0",
    },
    KPQI.RD_SEC_CWOL_GLOBAL: {
        FUNC_SECONDARY: "Issue Credit Rating",
        FUNC_TERTIARY: "Foreign Currency LT|0",
    },
    KPQI.RD_SEC_CREDIT_RATING_DATE_GLOBAL: {
        FUNC_SECONDARY: "Issue Credit Rating",
        FUNC_TERTIARY: "Foreign Currency LT|0",
    },
    KPQI.RD_SEC_CREDIT_WATCH_OUTLOOK_DATE_GLOBAL: {
        FUNC_SECONDARY: "Issue Credit Rating",
        FUNC_TERTIARY: "Foreign Currency LT|0",
    },
    KPQI.KPQI_322517: {FUNC_SECONDARY: "2", FUNC_TERTIARY: None},
}
