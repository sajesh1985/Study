from abc import abstractmethod
from typing import Any

from chatrd.engine.patterns import RDSingleton


class Callback(metaclass=RDSingleton):
    @abstractmethod
    def execute_callback(self, callback_state: Any) -> Any:
        pass
