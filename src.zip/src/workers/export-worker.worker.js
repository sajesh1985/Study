/// <reference lib="webworker" />

onmessage = function(e){
    const { gridApi, allRecords } = e.data;

    // Perform the export
    try {

      const excelData = gridApi.exportDataAsExcel({allColumns: true,allRows: true,rowData: allRecords});
  
      // Send the result (Excel data) back to the main thread
      postMessage({ success: true, data: excelData });
    } catch (error) {
      postMessage({ success: false, error: error });
    }
  };

  