import logging

from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.data_service.retriever.base import BaseRetriever
from chatrd.engine.data_service.retriever.utils import _retrieve
from chatrd.engine.data_service.schema import Analyzer, ProcessorInput, Retriever

logger = logging.getLogger(__name__)
config_machinery = get_config_machinery()


class FinancialMetricsRetriever(BaseRetriever):
    def retrieve(self, processor: ProcessorInput = None, analyzer: Analyzer = None):
        if not processor.entities or len(processor.entities["companies"]) == 0:
            return Retriever()
        endpoint_path = Constants.RatingsAPI.RATINGS_API_CSD_INDIVIDUAL_METRICS_ENDPOINT_PATH
        keyInstns = analyzer.response["keyInstns"]
        metrics_list = analyzer.response["metricsList"]
        time_periods = analyzer.response["time"]
        metric_codes = ",".join(set(metric["MetricCode"] for metric in metrics_list))
        period = ",".join(time_periods)

        metrics_mapping = {metric["MetricCode"]: metric["MetricName"] for metric in metrics_list}
        payload = {
            "KeyInstn": keyInstns,
            "MetricField": metric_codes,
            "Period": period,
        }
        result = _retrieve(endpoint_path, api_method="POST", data=payload)
        for res in result.api_data:
            metric_code = res.get("MetricName")
            if metric_code is not None:
                metric_code = str(metric_code)
                res["MetricName"] = metrics_mapping.get(metric_code, metric_code)
        return Retriever(
            api_data=result.api_data,
            screener_payload=payload,
            total_count=len(result.api_data),
            api_method="POST",
            api_type="ratings",
            url=endpoint_path,
        )
