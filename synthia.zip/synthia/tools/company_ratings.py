from mcp.server.fastmcp import FastMCP, Context
from fastapi import FastAPI, APIRouter
from fastapi import Request
from fastapi import Depends
import logging
import httpx
from contextlib import asynccontextmanager
import contextlib
from src.synthia.config.api_config import get_config
from src.synthia.tools.mcp_responses import MoodyRatingModel, MoodyRatingsResponse
from . import auth
from src.synthia.utils.logging_config import configure_logging
from src.synthia.utils.source import Source

# Configure logging
configure_logging(log_file='company_ratings.log')
logger = logging.getLogger(__name__)

mcp: FastMCP = FastMCP("Company Ratings MCP", stateless_http=True)

cfg = get_config()

logger.info("Ratings MCP Server starting up...")
capitaliq_base_url = cfg["capitaliq_base_url"]
old_ciqpro_url = cfg["old_ciqpro_url"]
current_ratings_url_infix = "AIReportBuilder/entityCurrentRating/"
history_ratings_url_infix = "ChatRD/ratingshistory/"
agency_ratings_url_infix = "AIReportBuilder/agencyCurrentRating/"
agencyhistory_ratings_url_infix = "AIReportBuilder/agencyHistoryRating/"

router = APIRouter()

# Create a single AsyncClient instance for reuse (performance optimization for Lambda)
async_client: httpx.AsyncClient = None

@mcp.tool()
async def get_latest_ratings(inst_id: str) -> dict:
    """
    Get ratings for a given company id
    Args:
        inst_id (str): The Company id to get ratings for

    Returns:
        dict: A dictionary containing the current ratings for the given company also source for citation.
        The dictionary will have the following attributes for the company/issuer:
        - sources (str): The URL used to fetch the S&P rating Current data.
        - data (dict): Contains S&P's Current ratings and creditwatch outlook information:
           - RatingDate (str): The date when the rating was assigned, in ISO 8601 format.
           - RatingType (str): The type of rating, indicating whether it is for foreign currency or local currency.
           - DebtType (str): Specifies the type of debt being rated, such as 'Issuer Credit Rating'.
           - RatingSymbol (str): The symbol representing the credit rating (e.g., 'AA-').
           - CreditWatchOutlook (str): Indicates the outlook for the credit rating, which can be 'Positive', 'Negative', or 'Stable'.
           - CreditWatchOutlookDate (str): The date associated with the credit watch outlook, in ISO 8601 format.
    """
    logger.info(f"Latest rating request for inst_id: {inst_id}")

    # Simulate a request to the ratings URL
    logger.info(f"get_latest_ratings called for : {inst_id}")
    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    url = f"{capitaliq_base_url}{current_ratings_url_infix}{inst_id}"
    global async_client
    try:
        response = await async_client.get(url, headers=auth.build_auth_headers(raw_request))
        source = Source(title="Company Ratings", url=f"{old_ciqpro_url}#company/ratingsHistory?Id={inst_id}")
        if response.status_code == 200:
            rating_data = response.json()
            logger.info(f"Latest rating data: {len(rating_data)} records")
            return {"source": [source], "data": rating_data}
        elif response.status_code == 204:
            logger.info(f"No ratings found for inst_id: {inst_id}.")
            return {"source": [source], "data": {"message": "No ratings found for the given company."}}
        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return f"Error: {response.status_code} - {response.text}"
    except httpx.RequestError as e:
        logger.error(f"Request failed: {e}")
        return f"Request failed: {e}"


@mcp.tool()
async def get_historical_rating_data(inst_id: str) -> dict:
    """
    Get historical ratings for a given company id

    Args: inst_id (str): The Company id to get ratings for

    Returns:
    A  dictionary containing the historical ratings for the Instn ID also source for citation
    But only relevant fields are included in the response for clarity.
    Field meanings:
        - sources (str): The URL used to fetch the S&P rating history data.
        - data (dict): Contains S&P's Historical ratings and creditwatch outlook information:
            - RT_RATING_TYPE_CODE:	Rating type description for the credit rating
            - RT_DEBT_TYPE_CODE:    Debt type description for the credit rating
            - RT_CURRENT_CW_OL:     Current credit watch symbol and current outlook symbol
            - RT_CURRENT_CW_OL_ACTION_WORD:	The direction in which the credit rating was moved
            - RT_CURRENT_RATING_SYMBOL: Rating identifier or code representing an entity, program, or security
            - RT_RATING_DATE:   Date on which the rating was assigned by the analyst
            - RT_CURRENT_CW_OL_DATE:	The date on which the combined credit watch and outlook was assigned
    Note:
        Some fields returned by the API are omitted from the response as they are not relevant for most use cases.
    """
    logger.info(f"History Rating requested: {inst_id}")
    logger.info(f"get_historical_rating_data called for : {inst_id}")
    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    headers = raw_request.headers
    logger.info(f"Headers received: {headers}")
    url = f"{capitaliq_base_url}{history_ratings_url_infix}{inst_id}"
    global async_client
    try:
        response = await async_client.get(url, headers=auth.build_auth_headers(raw_request))
        source = Source(title="Company History Ratings", url=f"{old_ciqpro_url}#company/ratingsHistory?Id={inst_id}")
        if response.status_code == 200:
            rating_data = response.json()
            logger.info(f"Historical rating data: {len(rating_data)} records")
            RELEVANT_FIELDS = [
            "RT_RATING_TYPE_CODE", "RT_DEBT_TYPE_CODE","RT_CURRENT_RATING_SYMBOL", "RT_RATING_DATE",
            "RT_CURRENT_CW_OL", "RT_CURRENT_CW_OL_DATE", "RT_CURRENT_CW_OL_ACTION_WORD"
            ]

            if isinstance(rating_data, list):
                filtered_data = [
                    {k: v for k, v in item.items() if k in RELEVANT_FIELDS}
                    for item in rating_data
                ]
            else:
                filtered_data = rating_data
            logger.info(f"Historical rating data: {len(filtered_data)} records after filtering")
            return {"source": [source], "data" : filtered_data }
        elif response.status_code == 204:
            logger.info(f"No historical rating data found for inst_id: {inst_id}.")
            return {"source": [source], "data": {"message": "No historical rating data found for the given company."}}
        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return f"Error: {response.status_code} - {response.text}"
    except httpx.RequestError as e:
        logger.error(f"Request failed: {e}")
        return f"Request failed: {e}"

@mcp.tool()
async def get_moodys_latest_ratings(inst_id: str) -> MoodyRatingsResponse:
    """
    Retrieves Moody's ratings Current only and issuer outlook latest information for a given company ID.

    Args:
        inst_id (str): The unique identifier for the company to fetch Moody's ratings.

    Returns:
        dict: A dictionary with the following structure:
            - sources (str): The URL used to fetch the Moody's ratings data.
            - data (dict): Contains Moody's ratings and issuer information:
                - MoodyRating (list): List of Moody's rating records, each with:
                    - KeyInstn (int): The company or institution identifier.
                    - CreditRating (str): The Moody's credit rating (e.g., 'A1', 'WR').
                    - RatingsAsOf (str): The date and time the rating was assigned (ISO 8601 format).
                    - CreditWatchOutlook (str): The outlook or watch status for the rating.
                    - RatingType (str): The type of Moody's rating (e.g., 'Long Term Rating').

    Example:
    {
        "data": {
            "MoodyRating": [
                {
                    "KeyInstn": 7599691,
                    "CreditRating": "WR",
                    "RatingsAsOf": "2016-07-27T17:52:01",
                    "CreditWatchOutlook": "Withdrawn",
                    "RatingType": "Long Term Rating (LT Corporate Family Ratings Domestic)"
                }
            ]
        }
    }

    Notes:
        - If no Moody's ratings are found, the data field will contain a message.
        - Errors are logged and returned as error messages.
    """

    logger.info(f"Moodys Latest rating request for inst_id: {inst_id}")

    # Simulate a request to the ratings URL
    logger.info(f"get_moodys_latest_ratings called for : {inst_id}")
    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    url = f"{capitaliq_base_url}{agency_ratings_url_infix}{inst_id}"
    global async_client
    try:
        response = await async_client.get(url, headers=auth.build_auth_headers(raw_request))
        source = Source(title="Company Ratings", url=f'{old_ciqpro_url}#company/creditratings?ID={inst_id}')
        if response.status_code == 200:
            moodys_rating_data = response.json()
            moody_ratings = moodys_rating_data.get("MoodyRating", [])
            for rating in moody_ratings:
                rating.pop("CreditRatingDirection", None)

            ratings_models = [MoodyRatingModel(**r) for r in moody_ratings]
            data = {
                "MoodyRating": ratings_models,
            }
            logger.info("MoodyRating records: %d", len(data["MoodyRating"]))
            result = MoodyRatingsResponse(
                sources=[source],
                data=data
            )
            return result
        elif response.status_code == 204:
            logger.info(f"No Moodys ratings found for inst_id: {inst_id}.")
            return MoodyRatingsResponse(
                sources=[source],
                data={"MoodyRating": []}
            )
        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return MoodyRatingsResponse(
                sources=[source],
                data={"MoodyRating": []}
            )
    except httpx.RequestError as e:
        logger.error(f"Request failed: {e}")
        return MoodyRatingsResponse(
            sources=[source],
            data={"MoodyRating": []}
        )


@mcp.tool()
async def get_fitch_latest_ratings(inst_id: str) -> dict:
    """
        Retrieves Fitch Current ratings for a given company ID.

        Args:
            inst_id (str): The unique identifier for the company to fetch Fitch ratings.

        Returns:
            dict: A dictionary with the following structure:
                - sources (str): The URL used to fetch the Fitch ratings data.
                - data (dict): Contains Fitch's ratings information:
                    - FitchRating (list): List of Fitch rating records, each with:
                        - KeyInstn (int): The company or institution identifier.
                        - CreditRating (str): The Fitch credit rating (e.g., 'AA+', 'BBB-').
                        - RatingsAsOf (str): The date and time the rating was assigned (ISO 8601 format).
                        - CreditWatchOutlook (str): The outlook or watch status for the rating (e.g., 'Stable', 'Negative').
                        - RatingType (str): The type of Fitch rating (e.g., 'Long-Term National Issuer Rating').
                        - Additional fields as provided by the API.

        Example:
            {
                "data": {
                    "FitchRating": [
                        {
                            "KeyInstn": 7599691,
                            "CreditRating": "AA+ (mex)",
                            "RatingsAsOf": "2025-06-20T13:07:02",
                            "CreditWatchOutlook": "RO:Sta",
                            "RatingType": "Long-Term National Issuer Rating"
                        }
                    ]
                }
            }

        Notes:
            - Only the FitchRating section is returned from the API response.
            - If no Fitch ratings are found, the data field will contain a message.
            - Errors are logged and returned as error messages.
        """

    logger.info(f"Fitch Latest rating request for inst_id: {inst_id}")

    # Simulate a request to the ratings URL
    logger.info(f"get_fitch_latest_ratings called for : {inst_id}")
    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    url = f"{capitaliq_base_url}{agency_ratings_url_infix}{inst_id}"
    global async_client
    try:
        response = await async_client.get(url, headers=auth.build_auth_headers(raw_request))
        source = Source(title="Company Ratings", url=f'{old_ciqpro_url}#company/creditratings?ID={inst_id}')
        if response.status_code == 200:
            fitch_rating_data = response.json()
            fitch_ratings = fitch_rating_data.get("FitchRating", [])
            for rating in fitch_ratings:
                rating.pop("CreditRatingDirection", None)
            data = {"FitchRating": fitch_ratings}
            logger.info("FitchRating records: %d", len(data["FitchRating"]))
            return {"sources": [source], "data": data}
        elif response.status_code == 204:
            logger.info(f"No fitch ratings found for inst_id: {inst_id}.")
            return {"sources": [source], "data": {"message": "No fitch ratings found for the given company."}}
        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return f"Error: {response.status_code} - {response.text}"
    except httpx.RequestError as e:
        logger.error(f"Request failed: {e}")
        return f"Request failed: {e}"


@mcp.tool()
async def get_moodys_history_ratings(inst_id: str) -> dict:
    """
        Retrieves Moody's Historical ratings and outlook information for a given company ID.

        Args:
            inst_id (str): The unique identifier for the company to fetch Moody's ratings.

        Returns:
            dict: A dictionary with the following structure:
                - sources (str): The URL used to fetch the Moody's ratings data.
                - data (dict): Contains Moody's ratings and issuer information:
                    - MoodyRating (list): List of Moody's rating records, each with:
                        - KeyInstn (int): The company or institution identifier.
                        - CreditRating (str): The Moody's credit rating (e.g., 'A1', 'WR').
                        - RatingsAsOf (str): The date and time the rating was assigned (ISO 8601 format).
                        - CreditWatchOutlook (str): The outlook or watch status for the rating.
                        - RatingType (str): The type of Moody's rating (e.g., 'Long Term Rating').
                        - CreditRatingDirection (str): The direction in which the credit rating was moved (e.g., 'Upgrade', 'Downgrade', 'Affirmation').

        Example:
        {
            "data": {
                "MoodyRating": [
                    {
                        "KeyInstn": 7599691,
                        "CreditRating": "A1",
                        "RatingsAsOf": "2016-07-27T17:52:01",
                        "CreditWatchOutlook": "Withdrawn",
                        "RatingType": "Long Term Rating (LT Corporate Family Ratings Domestic)",
                        "CreditRatingDirection": "Upgrade"
                    }
                ]
            }
        }

        Notes:
            - If no Moody's ratings are found, the data field will contain a message.
            - Errors are logged and returned as error messages.
        """

    logger.info(f"Moodys Historical rating request for inst_id: {inst_id}")

    # Simulate a request to the ratings URL
    logger.info(f"get_moodys_history_ratings called for : {inst_id}")
    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    url = f"{capitaliq_base_url}{agencyhistory_ratings_url_infix}{inst_id}"
    global async_client
    try:
        response = await async_client.get(url, headers=auth.build_auth_headers(raw_request))
        source = Source(title="Company Ratings",url=f'{old_ciqpro_url}#company/creditratings?ID={inst_id}')
        if response.status_code == 200:
            moodys_rating_data = response.json()
            data = {
                "MoodyRating": moodys_rating_data.get("MoodyRating", []),
            }
            logger.info("MoodyRating records: %d", len(data["MoodyRating"]))
            return {"sources": [source], "data": data}
        elif response.status_code == 204:
            logger.info(f"No Moodys ratings found for inst_id: {inst_id}.")
            return {"sources": [source], "data": {"message": "No Moodys ratings found for the given company."}}
        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return f"Error: {response.status_code} - {response.text}"
    except httpx.RequestError as e:
        logger.error(f"Request failed: {e}")
        return f"Request failed: {e}"

@mcp.tool()
async def get_fitch_History_ratings(inst_id: str) -> dict:
    """
        Retrieves Fitch Historical ratings for a given company ID.

        Args:
            inst_id (str): The unique identifier for the company to fetch Fitch ratings.

        Returns:
            dict: A dictionary with the following structure:
                - sources (str): The URL used to fetch the Fitch ratings data.
                - data (dict): Contains Fitch's ratings information:
                    - FitchRating (list): List of Fitch rating records, each with:
                        - KeyInstn (int): The company or institution identifier.
                        - CreditRating (str): The Fitch credit rating (e.g., 'AA+', 'BBB-').
                        - RatingsAsOf (str): The date and time the rating was assigned (ISO 8601 format).
                        - CreditWatchOutlook (str): The outlook or watch status for the rating (e.g., 'Stable', 'Negative').
                        - RatingType (str): The type of Fitch rating (e.g., 'Long-Term National Issuer Rating').
                        - CreditRatingDirection (str): The direction in which the credit rating was moved (e.g., 'Upgrade', 'Downgrade', 'Affirmation').

        Example:
            {
                "data": {
                    "FitchRating": [
                        {
                            "KeyInstn": 7599691,
                            "CreditRating": "AA+ (mex)",
                            "RatingsAsOf": "2025-06-20T13:07:02",
                            "CreditWatchOutlook": "RO:Sta",
                            "RatingType": "Long-Term National Issuer Rating",
                            "CreditRatingDirection": "Downgrade"
                        }
                    ]
                }
            }

        Notes:
            - Only the FitchRating section is returned from the API response.
            - If no Fitch ratings are found, the data field will contain a message.
            - Errors are logged and returned as error messages.
        """

    logger.info(f"Fitch History rating request for inst_id: {inst_id}")

    # Simulate a request to the ratings URL
    logger.info(f"get_fitch_History_ratings called for : {inst_id}")
    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    url = f"{capitaliq_base_url}{agencyhistory_ratings_url_infix}{inst_id}"
    global async_client
    try:
        response = await async_client.get(url, headers=auth.build_auth_headers(raw_request))
        source = Source(title="Company Ratings",url=f'{old_ciqpro_url}#company/creditratings?ID={inst_id}')
        if response.status_code == 200:
            fitch_rating_data = response.json()
            fitch_rating = {"FitchRating": fitch_rating_data.get("FitchRating", [])}
            logger.info("FitchRating records: %d", len(fitch_rating["FitchRating"]))
            return {"sources": [source], "data": fitch_rating}
        elif response.status_code == 204:
            logger.info(f"No fitch ratings found for inst_id: {inst_id}.")
            return {"sources": [source], "data": {"message": "No fitch ratings found for the given company."}}
        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return f"Error: {response.status_code} - {response.text}"
    except httpx.RequestError as e:
        logger.error(f"Request failed: {e}")
        return f"Request failed: {e}"



# Define a custom lifespan for FastAPI with a task to manage MCP


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Initialize MCP server task group
    logger.info("Initializing MCP server task group...")
    global async_client
    async_client = httpx.AsyncClient(timeout=10)
    async with contextlib.AsyncExitStack() as stack:
        await stack.enter_async_context(mcp.session_manager.run())
        yield
    await async_client.aclose()


@router.get("/agency-ratings/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "ok"}


# Create FastAPI app with lifespan
app = FastAPI(lifespan=lifespan)
app.mount("/agency-ratings", mcp.streamable_http_app())
app.include_router(router)
logger.info("Ratings MCP Server started successfully.")