import boto3
import json
import os
from langchain_aws import ChatBedrockConverse
from pprint import pprint
import json
from langchain.schema.runnable import RunnableLambda
import time

import boto3
import pandas as pd
import json
import tqdm.auto as tqdm
import os

model_ids = {
    "claude3sonnet1":"anthropic.claude-3-sonnet-20240229-v1:0",
    "claude3haiku1":"anthropic.claude-3-haiku-20240307-v1:0",
    "claude35sonnet1":"arn:aws:bedrock:us-east-1:339712941790:inference-profile/us.anthropic.claude-3-5-sonnet-20240620-v1:0",
    "claude35haiku1":"arn:aws:bedrock:us-east-1:339712941790:inference-profile/us.anthropic.claude-3-5-haiku-20241022-v1:0",
    "claude35sonnet2":"arn:aws:bedrock:us-east-1:339712941790:inference-profile/us.anthropic.claude-3-5-sonnet-20241022-v2:0",
    "claude37sonnet1":"arn:aws:bedrock:us-east-1:339712941790:inference-profile/us.anthropic.claude-3-7-sonnet-20250219-v1:0",
    "novapro1":"us.amazon.nova-pro-v1:0",
    "novalite1":"us.amazon.nova-lite-v1:0",
    "novamicro1":"us.amazon.nova-micro-v1:0",
    "llama33":"us.meta.llama3-3-70b-instruct-v1:0",
    "llama32": "us.meta.llama3-2-11b-instruct-v1:0"
}

model = "llama3"
modelId = model_ids[model]

KEYWORD_MATCHING = "manual"
# KEYWORD_MATCHING = "llm"

# Initialize AWS Bedrock client
bedrock_runtime = boto3.client("bedrock-runtime")

keyword_dict = {}
kw_categories = [
    "competitors",
    "public_filings"
]

for k in kw_categories:
    with open(f"keywords/{k}.txt", 'r') as f:
        keyword_dict[k] = f.readlines()


moderation_prompt_fname = "all_cat_vs_keywords/all_categories_minus_kw.txt"

with open(f"../data/guardrails/moderation_prompts/{moderation_prompt_fname}", 'r') as f:
    moderation_prompt = f.read()

kw_prompt_fname = "all_cat_vs_keywords/keywords_public_filings_competitors.txt"

with open(f"../data/guardrails/moderation_prompts/{kw_prompt_fname}", 'r') as f:
    moderation_prompt_keywords = f.read()



def filter_content(user_input):

    query = moderation_prompt.replace("[[user_question]]", user_input)


    llm = ChatBedrockConverse(model=modelId)

    messages = [
        ("user", query)
    ]

    model_response = llm.invoke(messages)

    answer = model_response.text()
    answer = answer.replace("```json", "")
    answer = answer.replace("```", "")

    return json.loads(answer.strip())

def match_keywords_manual(question, keyword_dict):

    for k in keyword_dict.keys():
        for kw in keyword_dict[k]:
            if kw.lower() in question.lower():
                return {"question":question, "question_blocked":"true", "blocked_categories":[f"{k}_kw"]}

    return {"question":question, "question_blocked":"false", "blocked_categories":[]}

def match_keywords_llm(question):

    query = moderation_prompt_keywords.replace("[[user_question]]", user_input)


    llm = ChatBedrockConverse(model=modelId)

    messages = [
        ("user", query)
    ]

    model_response = llm.invoke(messages)

    answer = model_response.text()
    answer = answer.replace("```json", "")
    answer = answer.replace("```", "")

    return json.loads(answer.strip())

def filter_inc_keywords(user_input):

    if KEYWORD_MATCHING == "manual":
        keyword_res = match_keywords_manual(user_input, keyword_dict)
    elif KEYWORD_MATCHING == "llm":
        keyword_res = match_keywords_llm(user_input)


    llm_res = filter_content(user_input)

    question_blocked = "true" if keyword_res["question_blocked"] == "true" or llm_res["question_blocked"] == "true" else "false"
    blocked_categories = keyword_res["blocked_categories"] + llm_res["blocked_categories"]

    return {"question":user_input, "question_blocked": question_blocked, "blocked_categories": blocked_categories}


filter_step = RunnableLambda(filter_inc_keywords)



questions_dir = "../data/guardrails/questions"
questions_files = [
    "advice.csv", 
   "malicious.csv", 
   "opinion.csv", 
   "internal_operations.csv", 
   "competitors.csv",
    "confiential.csv",
    "client_support.csv",
    "public_filings_kw.csv",
    "valid_public_filings_kw.csv",
   "non_blocked_questions_full.csv"
]

def open_test_questions():
    dfs = []
    for f in questions_files:
        path = os.path.join(questions_dir, f)
        dfs.append(pd.read_csv(path))

    return pd.concat(dfs).fillna("").reset_index(drop=True)


df = open_test_questions()



guardrail_outputs = []
errors = []

start = time.time()
for index, row in tqdm.tqdm(df.iterrows()):
    question = row["question"]

    try:
        response = filter_step.invoke(question)
        # response = json.loads(response)
        
        guardrail_output = response["question_blocked"]
        # guardrail_notes = response.get("notes")
        
        output_dict = {
            "question": question,
            "ground_truth_blocked": row["ground_truth_blocked"],
            "ground_truth_blocked_reason": row["blocked_reason"],
            "prediction": guardrail_output,
            "full_response": response
        }
        
        
        for c in response["blocked_categories"]:
            output_dict[c] = True
        
        guardrail_outputs.append(
            output_dict
            )
    except Exception as e:
        print(e)
        # print(response)
        errors.append(response)
        continue

end = time.time()

total_duration = end-start


df2 = pd.DataFrame(guardrail_outputs)
df2["ground_truth_blocked"] = df2["ground_truth_blocked"].astype(str).str.lower()
df3 = df2.loc[df2['ground_truth_blocked'] != df2['prediction']]
tp_plus_fp = df2.loc[df2['ground_truth_blocked'] == 'true']
tp_plus_fn = df2.loc[df2['prediction'] == 'true']
tp = tp_plus_fp.loc[tp_plus_fp["prediction"] == 'true']
recall = tp.shape[0]/tp_plus_fp.shape[0]
precision = tp.shape[0]/tp_plus_fn.shape[0]

avg_q_time = total_duration/df.shape[0]

results = {

    "total_questions": df.shape[0],
    "num_questions_answered": df2.shape[0],
    "error_outputs": df.shape[0] - df2.shape[0],
    "avg_query_time_secs": avg_q_time,
    "valid_questions_total": df2.loc[df2['ground_truth_blocked'] == 'false'].shape[0],
    "invalid_questions_total": df2.loc[df2['ground_truth_blocked'] == 'true'].shape[0],
    "invalid_q_categories": {
        "advice": df2.loc[df2['ground_truth_blocked_reason'] == 'advice'].shape[0],
        "malicious": df2.loc[df2['ground_truth_blocked_reason'] == 'malicious'].shape[0],
        "opinion": df2.loc[df2['ground_truth_blocked_reason'] == 'opinion'].shape[0],
        "internal_operations": df2.loc[df2['ground_truth_blocked_reason'] == 'internal_operations'].shape[0],
        "confidential": df2.loc[df2['ground_truth_blocked_reason'] == 'confidential'].shape[0],
        "competitors": df2.loc[df2['ground_truth_blocked_reason'] == 'competitors'].shape[0],
        "client_support": df2.loc[df2['ground_truth_blocked_reason'] == 'client_support'].shape[0],
        "public_filings": df2.loc[df2['ground_truth_blocked_reason'] == 'public_filings'].shape[0],
    },
    "guardrail_acted_correctly": df2.loc[df2['ground_truth_blocked'] == df2['prediction']].shape[0],
    "guardrail_acted_incorrectly": df3.shape[0],
    "recall": recall,
    "precision": precision,
    "blocked_valid_question": df3.loc[df3['ground_truth_blocked'] == False].shape[0],
    "allowed_invalid_question": df3.loc[df3['ground_truth_blocked'] == True].shape[0],
}

filters = ["Investment_Advice", 
           'Malicious_Prompts', 
           'Opinions_of_Quality', 
           'SP_Internal_Operations', 
           'Confidential_Information', 
           'Competitors', 
           'Client_Support',
           'Public_Filings',
          'public_filings_kw',
          'competitors_kw']
map_filter_to_reason ={
    "Investment_Advice":"advice",
    "Malicious_Prompts":"malicious",
    "Opinions_of_Quality":"opinion",
    "SP_Internal_Operations":"internal_operations",
    "Competitors":"competitors",
    "Confidential_Information":"confidential",
    "Client_Support":"client_support",
    'Public_Filings':"public_filings",
    "public_filings_kw": "public_filings_kw",
    "competitors_kw":"competitors_kw"
}

incorrectly_applied_filters = {}
for f in filters:
    try:
        incorrectly_applied_filters[f] = df3.loc[df3[f] == True].shape[0]
    except:
        pass

results["incorrectly_applied_filters"] = incorrectly_applied_filters

failed_to_apply_filters = {}


for f in filters:
    try:
        reason = map_filter_to_reason[f]
        failed_to_apply_filters[f] = df3.loc[df3['ground_truth_blocked_reason'] == reason].shape[0]
    except:
        pass

results["failed_to_apply_filters"] = failed_to_apply_filters
results


kw = "_kw_"


try:
    os.mkdir(f"outputs/{model}{kw}{KEYWORD_MATCHING}")
except:
    pass

with open(f"outputs/{model}{kw}{KEYWORD_MATCHING}/results.json", 'w') as f:
    json.dump(results, f)

df2.to_csv(f"outputs/{model}{kw}{KEYWORD_MATCHING}/guardrail_question_output.csv", index=False)
df2.loc[df2["ground_truth_blocked"] != df2["prediction"]].to_csv(f"outputs/{model}{kw}{KEYWORD_MATCHING}/guardrail_question_output_no_match.csv")