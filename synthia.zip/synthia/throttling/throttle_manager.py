import datetime
import json
import logging
from functools import wraps
from typing import Callable, Any

from fastapi import HTTPException, Request

from src.synthia.persistence.database_manager import get_connection_pool
from src.synthia.user_profile.user_profile_provider import fetch_user_profile_data

logger = logging.getLogger("ThrottleManager")
logger.setLevel(logging.INFO)

DEFAULT_HOURLY_LIMIT = 5
DEFAULT_DAILY_LIMIT = 10
DEFAULT_MONTHLY_LIMIT = 50


class ThrottleManager:
    """
    Singleton class to manage API request throttling.

    This class provides methods to check, log, and enforce throttling limits
    for users and APIs. It coordinates with the database to fetch configuration,
    count requests, and log accepted or throttled requests. Only one instance
    of this class exists throughout the application.
    """

    _instance = None

    def __new__(cls, *args, **kwargs):
        """
        Create or return the singleton instance of ThrottleManager.

        Returns:
            ThrottleManager: The singleton instance.
        """
        if cls._instance is None:
            cls._instance = super(ThrottleManager, cls).__new__(cls)
        return cls._instance

    def _resolve_limits(self, config) -> dict:
        """
        Resolve the throttle limits from config or use defaults.

        Args:
            config (Optional[Tuple[int, int, int]]): Limits tuple.

        Returns:
            Dict[str, int]: Dictionary of resolved limits.
        """
        hourly_limit = min(v for v in [
            config[0] if config else None,
            DEFAULT_HOURLY_LIMIT
        ] if v is not None)
        daily_limit = min(v for v in [
            config[1] if config else None,
            DEFAULT_DAILY_LIMIT
        ] if v is not None)
        monthly_limit = min(v for v in [
            config[2] if config else None,
            DEFAULT_MONTHLY_LIMIT
        ] if v is not None)
        return {"hourly_limit": hourly_limit, "daily_limit": daily_limit, "monthly_limit": monthly_limit}

    async def get_config(self, conn, key_online_user: str, api_name: str) -> dict | None:
        """
        Fetch the throttle configuration for a user and API.

        Args:
            conn: The database connection to use.
            key_online_user (str): The user identifier.
            api_name (str): The API name.

        Returns:
            Optional[Dict[str, int]]: Limits dict, or None if not found.
        """
        query = """
            SELECT
                hourly_limit,
                daily_limit,
                monthly_limit
            FROM Product.throttle_config
            WHERE
                (key_online_user = %(key_online_user)s OR key_online_user = 'SYSTEM')
                AND api_name = %(api_name)s
            ORDER BY CASE WHEN key_online_user = %(key_online_user)s THEN 0 ELSE 1 END
            LIMIT 1;
        """
        params = {"key_online_user": key_online_user, "api_name": api_name}
        cursor = await conn.execute(query, params)
        result = await cursor.fetchall()
        cfg = result[0] if result and result[0] else None

        if not cfg:
            return None
        return self._resolve_limits(cfg)

    async def try_create_request(self, key_online_user: str, api_name: str, user_ip: str, request_data: dict) -> bool:
        """
        Attempt to create a request and log it as accepted or throttled.

        Args:
            key_online_user (str): The user identifier.
            api_name (str): The API name.
            user_ip (str): The user's IP address.
            request_data (dict): The request payload.

        Returns:
            bool: True if request is accepted, False if throttled.
        """
        logger.info(
            f"Processing request for key_online_user={key_online_user}, api_name={api_name}, user_ip={user_ip}"
        )

        pool = get_connection_pool()
        async with pool.connection() as conn:
            # Get config using the same connection
            config = await self.get_config(conn, key_online_user, api_name)

            if config is None:
                logger.info("No throttle config found; allowing all requests")
                await conn.execute(
                    "INSERT INTO Product.accepted_requests (key_online_user, api_name, user_ip, created_at) VALUES (%s, %s, %s, NOW())",
                    [key_online_user, api_name, user_ip]
                )
                return True

            async with conn.transaction():
                cursor = await conn.execute(
                    "SELECT id FROM Product.accepted_requests WHERE key_online_user = %s AND api_name = %s FOR UPDATE",
                    [key_online_user, api_name]
                )
                locked = await cursor.fetchall()

                if not locked:
                    lock_key = abs(hash(f"{key_online_user}:{api_name}")) % (2 ** 31)
                    await conn.execute("SELECT pg_advisory_xact_lock(%s)", [lock_key])
                    logger.debug(f"Acquired advisory lock for key_online_user={key_online_user}, api_name={api_name}")

                now = datetime.datetime.now(datetime.timezone.utc)
                hour_ago = now - datetime.timedelta(hours=1)
                day_ago = now - datetime.timedelta(days=1)
                month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)

                cursor = await conn.execute(
                    """
                    SELECT
                        COUNT(*) FILTER (WHERE created_at >= %s) AS hourly_count,
                        COUNT(*) FILTER (WHERE created_at >= %s) AS daily_count,
                        COUNT(*) FILTER (WHERE created_at >= %s) AS monthly_count
                    FROM Product.accepted_requests
                    WHERE key_online_user = %s AND api_name = %s
                    """,
                    [hour_ago, day_ago, month_start, key_online_user, api_name]
                )
                counts = await cursor.fetchone()

                hour_count, day_count, month_count = counts
                logger.debug(f"Hourly count: {hour_count}, Daily count: {day_count}, Monthly count: {month_count}")

                if (
                        hour_count < config["hourly_limit"] and
                        day_count < config["daily_limit"] and
                        month_count < config["monthly_limit"]
                ):
                    logger.warning(
                        f"Request accepted for key_online_user={key_online_user}, api_name={api_name}, "
                        f"user_ip={user_ip}. Counts - Hourly: {hour_count}/{config['hourly_limit']}, "
                        f"Daily: {day_count}/{config['daily_limit']}, Monthly: {month_count}/{config['monthly_limit']}"
                    )
                    await conn.execute(
                        "INSERT INTO Product.accepted_requests (key_online_user, api_name, user_ip, created_at) VALUES (%s, %s, %s, NOW())",
                        [key_online_user, api_name, user_ip]
                    )
                    return True
                else:
                    logger.error(
                        f"Request throttled for key_online_user={key_online_user}, api_name={api_name}, "
                        f"user_ip={user_ip}. Counts - Hourly: {hour_count}/{config['hourly_limit']}, "
                        f"Daily: {day_count}/{config['daily_limit']}, Monthly: {month_count}/{config['monthly_limit']}"
                    )
                    await conn.execute(
                        "INSERT INTO Product.throttled_requests (key_online_user, api_name, user_ip, request_data, timestamp) VALUES (%s, %s, %s, %s, NOW())",
                        [key_online_user, api_name, user_ip, json.dumps(request_data)]
                    )
                    return False

    def throttle_view(self) -> Callable:
        """
        Decorator to apply throttling logic to FastAPI view functions.

        Returns:
            Callable: The decorator function.
        """

        def decorator(func) -> Callable:
            @wraps(func)
            async def wrapper(request: Request, *args, **kwargs) -> Any:
                """
                Wrapper for the decorated view function to enforce throttling.

                Args:
                    request (Request): The FastAPI request object.
                    *args: Positional arguments.
                    **kwargs: Keyword arguments.

                Returns:
                    Any: The result of the view function.

                Raises:
                    HTTPException: If the request is throttled.
                """
                key_online_user = kwargs.pop('key_online_user', None)
                user_ip = request.client.host
                request_data = request.data if hasattr(request, 'data') else {}
                token = kwargs.get('token', '')

                # Fetch key_online_user if missing and token is present
                if key_online_user is None and token is not None:
                    user_profile = await fetch_user_profile_data(token)
                    key_online_user = str(user_profile["KeyOnlineUser"])

                api_name = func.__name__
                logger.debug(f"Throttling view for API: {api_name}, key_online_user={key_online_user}")
                allowed = await self.try_create_request(key_online_user, api_name, user_ip, request_data)
                if not allowed:
                    logger.warning(f"User {key_online_user} throttled for API {api_name}")
                    raise HTTPException(
                        status_code=429,
                        detail="Too many requests. Please try again later."
                    )
                return await func(request=request, *args, **kwargs)

            return wrapper

        return decorator
