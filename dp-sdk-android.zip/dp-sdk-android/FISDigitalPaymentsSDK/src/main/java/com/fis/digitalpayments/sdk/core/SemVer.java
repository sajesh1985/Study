package com.fis.digitalpayments.sdk.core;

public class SemVer {

    private final int mMajor;
    private final int mMinor;
    private final int mPatch;
    private final String mPrerelease;

    public SemVer(int major, int minor, int patch, String prerelease) {
        mMajor = major;
        mMinor = minor;
        mPatch = patch;
        mPrerelease = prerelease;
    }

    int getMajor() {
        return mMajor;
    }

    int getMinor() {
        return mMinor;
    }

    int getPatch() {
        return mPatch;
    }

    String getPrerelease() {
        return mPrerelease;
    }

    public String getVersionString() {
        String version = mMajor + "." + mMinor + "." + mPatch;
        if (mPrerelease != null && !mPrerelease.isEmpty()) {
            version += "." + mPrerelease;
        }

        return version;
    }
}
