﻿// Copyright Notice! 
// This document is protected under the trade secret and copyright 
// laws as the property of Fidelity National Information Services, Inc. 
// Copying, reproduction or distribution should be limited and only to 
// employees with a “need to know” to do their job. 
// Any disclosure of this document to third parties is strictly prohibited.
// © 2018 Fidelity National Information Services.
// All rights reserved worldwide.

namespace Fis.Epp.Fusion.Auth.Common
{
    using Fis.Epp.Fusion.Auth.Models;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.AspNetCore.Mvc.Filters;
    using System;
    using System.Linq;   

    /// <summary>
    /// Represents filter that validated auth requests.
    /// </summary>
    public class ValidateSessionTokenAttribute : ActionFilterAttribute
    {
        private readonly AppConfiguration _configuration;
        private readonly bool ValidateLifeTime;
        public ValidateSessionTokenAttribute(AppConfiguration configuration,bool validateLifetime = true)
        {
            _configuration = configuration;
            this.ValidateLifeTime = validateLifetime;
        }
        public override void OnActionExecuting(ActionExecutingContext context)
        {            
            if (!IsValidRequest(context.HttpContext.Request))
            {
                context.HttpContext.Response.StatusCode = StatusCodes.Status404NotFound;
                context.Result = new BadRequestObjectResult("Security headers missing.");
            }
            base.OnActionExecuting(context);
        }

        private bool IsValidRequest(HttpRequest request)
        {
            bool isValidRequest = false;
            var headerExists = request.Headers.ContainsKey(RequestHeader.SessionToken.GetEnumDescription());
            if (headerExists) {
                var claimsPrincipal = JwtHelper.ValidateSymmetricToken(_configuration.TokenSigningKey, request.Headers[RequestHeader.SessionToken.GetEnumDescription()], this.ValidateLifeTime);
                if (claimsPrincipal != null && claimsPrincipal.Claims.Count() > 0)
                {
                    isValidRequest = true;
                }                
            }
            return isValidRequest;
        }        
    }
}