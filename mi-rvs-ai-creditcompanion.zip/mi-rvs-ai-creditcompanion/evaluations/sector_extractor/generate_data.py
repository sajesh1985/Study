import argparse
import json
import pathlib
from evaluations.sector_extractor.utils import question_generator, setup_logging, get_dictionary_from_folders

def init_parser():
    parser = argparse.ArgumentParser(
        description="""

        """
    )
    parser.add_argument(
        "--template-entities-path", 
        type=str, 
        help="template entities directory path", 
        default="evaluations/data/sector_extraction/template_entities/"
    )
    parser.add_argument(
        "--template-questions-path",
        type=str,
        help="template questions directory path",
        default="evaluations/data/sector_extraction/template_questions/"
    )
    parser.add_argument(
        "--num-runs",
        type=int,
        help="samples per question template",
        default=3
    )
    parser.add_argument(
        "--output-path",
        type=str,
        help="output path for generated questions",
        default="evaluations/data/sector_extraction/generated_data/evaluation_questions.json"
    )
    return parser


if __name__ == "__main__":

    parser = init_parser()
    logger = setup_logging()
    args = parser.parse_args()

    try:
        template_entities = get_dictionary_from_folders(pathlib.Path(args.template_entities_path).resolve())
    except Exception as e:
        logger.error(f"error {e} in loading file {args.template_entities_path}")
        exit(1)

    try:
        template_questions = get_dictionary_from_folders(pathlib.Path(args.template_questions_path).resolve())
    except Exception as e:
        logger.error(f"error {e} in loading file {args.template_questions_path}")
        exit(1)

    questions = question_generator(template_entities, template_questions, num_runs=args.num_runs)

    try:
        with open(args.output_path, "w") as json_file:
            json.dump(questions, json_file)
    except Exception as e:
        logger.error(f"error {e} in saving file {args.output_path}")
        exit(1)

    logger.info(f"Generated {sum([len(value) for value in questions.values()])} questions are saved at {args.output_path}")
