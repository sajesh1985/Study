from typing import List, Optional, Union, Callable, Any, TypeVar, Generic
from src.synthia.schemas.template import TemplateSection
from src.synthia.schemas.workflow import ReportSection

T = TypeVar('T', bound=Union[TemplateSection, 'ReportSection'])

class TreeUtils(Generic[T]):
    """Utility class for tree operations on section structures."""
    
    @staticmethod
    def collect_leaf_nodes(sections: List[T]) -> List[T]:
        """Return all sections that have no child sections."""
        leaves: List[T] = []

        def _walk(nodes: List[T]) -> None:
            for node in nodes:
                children = getattr(node, 'sections', []) or []
                if not children:
                    leaves.append(node)
                else:
                    _walk(children)

        _walk(sections)
        return leaves