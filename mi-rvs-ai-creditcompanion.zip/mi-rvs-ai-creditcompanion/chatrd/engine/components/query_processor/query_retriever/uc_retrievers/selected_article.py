import logging
from typing import Dict, Union

from botocore.client import BaseClient

from chatrd.core.vectorstore import OpenSearch
from chatrd.engine.components.query_analyzer.entity_extractor.utils import (
    Companies,
    RevenueSource,
)
from chatrd.engine.components.query_analyzer.utils import TaggedEntity
from chatrd.engine.components.query_processor.query_retriever.uc_retrievers.base import (
    UCRetriever,
)
from chatrd.engine.components.query_processor.query_retriever.utils import (
    add_unstructured_source,
    get_custom_logic_filters_for_entities,
)
from chatrd.engine.configuration import Constants, get_config_machinery

config_machinery = get_config_machinery()
logger = logging.getLogger(__name__)


class SelectedArticlesRetriever(UCRetriever):
    def __init__(self, vector_stores_dict: Dict[str, OpenSearch], reranker_client: BaseClient):
        self.vector_stores_dict = vector_stores_dict
        self.top_k_selected_articles = config_machinery.get_config_value(
            Constants.GeneralConstants.TOP_K_SELECTED_ARTICLES
        )

    def retrieve(
        self, query: str, uc_type: str, list_of_tagged_entities: list[TaggedEntity], multi_uc_type: bool = False
    ):
        relevant_article_ids = [int(t.id) for t in list_of_tagged_entities]
        all_documents = []
        for index in ["research", "commentary", "definition", "criteria"]:
            retrieved_documents = self.vector_db_retrieval(
                query=query,
                entity=None,
                uc_type=uc_type,
                index_name=index,
                relevant_article_ids=relevant_article_ids,
            )
            all_documents.extend(retrieved_documents)
        retrieved_documents = all_documents
        logger.info(f"Total number of documents: {len(retrieved_documents)}")

        retrieved_documents = add_unstructured_source(retrieved_documents)
        return retrieved_documents

    def vector_db_retrieval(
        self,
        query: str,
        entity: Union[Companies, RevenueSource],
        uc_type: str,
        index_name: str,
        relevant_article_ids: list[int],
    ):
        query = self.rephrased_query(query, entity)
        filters = get_custom_logic_filters_for_entities(relevant_article_ids)
        logger.info(f"filter applied for {index_name} docs : {filters}")
        retrieved_documents, scores = self.vector_stores_dict[index_name].get_relevant_documents(
            query,
            efficient_filter=filters,
            model_id=config_machinery.get_config_value(Constants.OpenSearch.NEURAL_SEARCH_MODEL_ID),
            search_pipeline=config_machinery.get_config_value(Constants.OpenSearch.HYBRID_SEARCH_SEARCH_PIPELINE_ID),
            top_k_text_chunks=self.top_k_selected_articles,
        )
        retrieved_documents = self.add_additional_metadata_to_documents(
            uc_type=uc_type, user_query=query, entity=entity, documents=retrieved_documents
        )
        return retrieved_documents
