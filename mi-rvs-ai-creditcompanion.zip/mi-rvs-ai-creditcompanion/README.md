# ChatRD

**⚠ Note:**
- [Git LFS](https://git-lfs.com/) is used to manage large files. Run `git lfs pull` to download large files.


## 📖 Getting Started

### With venv or virtualenv

1. Create python virtual environment: `python -m venv <env_folder>` **or** `python -m virtualenv <env_folder>`
2. Activate the virtual environment: 
  - Manually: `<env-name>/bin/activate`
  - With poetry: `poetry env activate`
    - to check the environment config: `poetry env info`
    - to select a virtual environment: `poetry env use <env_folder>/bin/python`
3. Install dependencies
  - pip user: `pip install -e .`
  - poetry user: `poetry install`
4. Create a `.env` file in the project root folder including the variables listed in the [Environment variables](#environment-variables) section.

### With conda

1. Create python virtual environment:`conda create -n <env_name> python=<version>`
2. Activate the virtual environment: `conda activate <env-name>`
3. Install dependencies
  - pip user: `pip install -e .`
  - poetry user: `poetry install`
4. Create a `.env` file in the project root folder including the variables listed in the [Environment variables](#environment-variables) section.

### Environment variables
```bash
OPENSEARCH_PASSWORD=<password>

ENGINE_ROLE_ARN="arn:aws:iam::339712941790:role/mi-crs-chatrd-dev-role"
DATASERVICE_VECTOR_PATH="s3://chatrd-assets.us-east-1.mi-crs-chatrd-dev/dev/data_service/vectors/"
DATASERVICE_SCREENER_ENV="dev"

SCREENER_USER=<username>
SCREENER_PASS=<password>
SCREENER_PASS_PROD=<password>

SEARCH_API_ENV="dev"
SEARCH_API_USER=<username>
SEARCH_API_PASS=<password>

RATINGS_API_ENV="dev"
RATINGS_API_USER=<username>
RATINGS_API_PASS=<password>

BEDROCK_CONN_TIMEOUT=10
BEDROCK_READ_TIMEOUT=50

API_BASE_URL="https://www.capitaliqdev.spglobal.com"

SOURCE_GENERATION_BASE_URL="https://www.capitaliqdev.spglobal.com"
```
**⚠ Note:**

- **SCREENER, SEARCH, RATINGS APIs have same username and password**
- For the search API, we can only use prod for human QA and we can't use prod for any programatic testing
- For the screener API, we can only use staging for development. It is an agreement with the owner
- Update 24-09-2025 : There was a URL config refactoring effort undertaken to move all API URL logic to environment variables. As a result we need to specify following environment variables in the .env file API_BASE_URL and SOURCE_GENERATION_URL.This means that all APIs point to a single environment. 


## ⌨ Development

**Poetry commands for local development, research and quality checks**

- Install dependencies
  - Install only the main dependecies: `poetry install --only main`
  - Install the main and dev dependencies:`poetry install`
  - Install the extra **research** dependencies for local research & investigation: poetry install: `poetry install --with research`
- Run the application locally with streamlit
  - `poetry run app` (cmd: *streamlit run chatrd/engine/app/app.py*)
- Quality checks
  - code lint: `poetry run code_lint` (*black and isort checks*)
  - run unit-tests: `poetry run test`
  - run unit-tests with coveragew report: `poetry run test_coverage`

- Commands before code commit
  - code format: `poetry run code_format` (*sourcecode and import statement formatting with black and isort*)
  - pre-commit actions: `poetry run pre_commit` (*run code format, lint and unit-tests*)


## ❓ How to Release Manually

1. bump the version number in `pyproject.toml` by using a new feature branch and a PR (see [Semantic Versioning 2.0.0](https://semver.org/))
2. merge changes from the `develop` branch or the new branch into the `main` branch
3. check if [GitHub workflows](https://github.com/spglobal-innersource/mi-rvs-ai-creditcompanion/actions) have errors
4. check if a new release uploaded to the Jfrog repo [spg-dti-ai-python-local/chatrdlib/](https://artifactory-use-prod.cicd.spglobal.com/artifactory/spg-dti-ai-python-local/chatrdlib/)
5. if everything works as expected, a new [tag](https://github.com/spglobal-innersource/mi-rvs-ai-creditcompanion/tags) and a new GitHub [release](https://github.com/spglobal-innersource/mi-rvs-ai-creditcompanion/releases) will be created automatically from the main branch