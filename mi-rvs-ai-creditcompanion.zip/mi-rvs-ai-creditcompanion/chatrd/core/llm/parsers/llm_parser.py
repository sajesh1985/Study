"""Parser for the inputs and outputs of different LLM providers."""

import json
import logging
from typing import Any, AsyncIterator, Dict, Iterator, List, Optional, Union

from chatrd.core.llm.components.generation import GenerationChunk
from chatrd.core.llm.components.message import BaseMessage, MessageRole
from chatrd.core.llm.components.providers import LLMInputOption, ProviderMapping
from chatrd.core.utils import safe_get

logger = logging.getLogger(__name__)

GUARDRAILS_BODY_KEY = "amazon-bedrock-guardrailAssessment"
ASSISTANT_PROMPT = "\n\nAssistant:"
HUMAN_PROMPT_PROVIDERS = ["anthropic", "claude"]
USER_PROMPT_PROVIDERS = [
    "ai21",
    "ai21-llm",
    "amazon",
    "bedrock",
    "cohere",
    "cohere-llm",
    "llama",
    "meta",
    "mistral",
]


class LLMInputOutputParser:
    """Class to prepare the inputs to a format that LLM model expects.
    It also provides helper function to extract the generated text from the model response.
    """

    @staticmethod
    def get_provider_role_format(provider: Union[str, ProviderMapping], role: Union[str, MessageRole]) -> str:
        """Get the role format based on the model provider."""
        if isinstance(role, MessageRole):
            _role = role.value
        elif isinstance(role, str):
            _role = role.lower()
        else:
            raise ValueError(f"Invalid type for role: {type(role)}. It must be a string or MessageRole.")

        if isinstance(provider, str):
            return ProviderMapping.parse(provider).get_role_format(_role)
        return provider.get_role_format(_role)

    @classmethod
    def prepare_input(
        cls,
        provider: str,
        model_kwargs: Dict[str, Any],
        prompt: Optional[str] = None,
        system: Optional[str] = None,
        messages: Optional[List[Dict]] = None,
    ) -> Dict[str, Any]:
        provider_details = ProviderMapping.parse(provider).value
        get_role_format = ProviderMapping.parse(provider).get_role_format

        # Set provider based configurations
        max_token_key = provider_details.get_input_config_name(LLMInputOption.MAX_TOKENS)
        if max_token_key not in model_kwargs:
            model_kwargs[max_token_key] = 1024
        if provider == "anthropic":
            if messages:
                model_kwargs["anthropic_version"] = "bedrock-2023-05-31"

        # Preparing all kinds of inputs
        history_items = []
        if messages:
            for msg in messages:
                if isinstance(msg, BaseMessage):
                    role = MessageRole.parse(msg)
                    history_items.append(f"{get_role_format(role)} {msg.content}".strip())
                else:
                    role = msg.get("role", "user").lower()
                    history_items.append(f"{get_role_format(role)} {msg.get('content')}".strip())
        history = "\n\n".join(history_items)

        if prompt:
            prompt = _human_assistant_format(prompt, provider)

        # Create a single input adding: System message, history messages if any, and finally the latest prompt.
        sorted_valid_inputs = [input.strip() for input in [system, history, prompt] if input not in (None, "")]
        combined_prompt = "\n\n".join(sorted_valid_inputs)
        combined_prompt = _fix_newlines_in_prompt(combined_prompt, get_role_format(MessageRole.USER))
        if not combined_prompt.startswith("\n\n"):
            combined_prompt = "\n\n" + combined_prompt

        # Create the input body and re-map provider specific input configurations
        input_body = {}
        input_key = provider_details.input_key
        input_body[input_key] = combined_prompt

        kwargs = {provider_details.get_input_config_name(key): value for key, value in model_kwargs.items()}
        input_config_key = provider_details.input_config_key
        if input_config_key:
            input_body[input_config_key] = kwargs
        else:
            input_body = {**kwargs, **input_body}

        return input_body

    @staticmethod
    def _combine_inputs(input_body: Dict[str, Any]) -> Dict[str, Any]:
        prompt = input_body.pop("prompt", "")
        system = input_body.pop("system", None)
        messages = input_body.pop("messages", None)
        valid_inputs = [input for input in [prompt, system, messages] if input not in (None, "")]
        input_body["prompt"] = "\n\n".join(valid_inputs)
        return input_body

    @classmethod
    def _extract_llm_output(cls, response: Union[List, Dict], output_key: str):
        """Extract the LLM output from the response based on the provider specific output key."""
        extract_instruction = output_key.replace("[", ".[").split(".")
        for idx, instr in enumerate(extract_instruction):
            if instr.startswith("[") and instr.endswith("]"):
                if instr[1:-1].lstrip("-+").isdigit():
                    extract_instruction[idx] = int(instr[1:-1])
                else:
                    logger.error(f"Invalid index format: {instr}")
                    raise ValueError(f"Invalid index format: {instr}")
        result = safe_get(response, extract_instruction)
        id = safe_get(response, extract_instruction[:-1] + ["id"])
        if not id:
            safe_get(response, "id")
        logger.debug(f"Extracted LLM output: {result}")
        return result, id

    @classmethod
    def prepare_output(cls, provider: str, response: Any) -> dict:
        provider_details = ProviderMapping.parse(provider).value
        response_str = response.get("body").read().decode()
        response_body = json.loads(response_str)
        text_result, id = cls._extract_llm_output(response_body, provider_details.output_key)

        # Extract usage information
        headers = response.get("ResponseMetadata", {}).get("HTTPHeaders", {})
        prompt_tokens = int(headers.get("x-amzn-bedrock-input-token-count", 0))
        completion_tokens = int(headers.get("x-amzn-bedrock-output-token-count", 0))

        return {
            "text": text_result,
            "body": response_body,
            "id": id,
            "usage": {
                "prompt_tokens": prompt_tokens,
                "completion_tokens": completion_tokens,
                "total_tokens": prompt_tokens + completion_tokens,
            },
        }

    @classmethod
    def prepare_output_stream(
        cls,
        provider: str,
        response: Any,
        stop: Optional[List[str]] = [],
        messages_api: bool = False,
    ) -> Iterator[GenerationChunk]:
        provider_details = ProviderMapping.parse(provider).value
        stream = response.get("body")
        if not stream:
            return

        if messages_api:
            output_key = "message"
        else:
            output_key = provider_details.output_key

        for event in stream:
            chunk = event.get("chunk")
            if not chunk:
                continue

            chunk_obj = json.loads(chunk.get("bytes").decode())

            # Check for stop sequences
            stop_cfg = provider_details.get_input_config_name([LLMInputOption.STOP])
            stop_sequences = [i.value for i in stop_cfg if i is not None]
            stop_sequences.extend(stop or [])
            for stop in stop_sequences:
                if chunk_obj.get(stop):
                    return

            if messages_api and chunk_obj.get("type") in (
                "message_start",
                "content_block_start",
                "content_block_delta",
            ):
                if chunk_obj.get("type") == "content_block_delta":
                    chk = _stream_response_to_generation_chunk(chunk_obj)
                    yield chk
                else:
                    continue
            else:
                text_result, id = cls._extract_llm_output(chunk_obj, output_key)
                if not text_result:
                    continue
                guardrails_obj = chunk_obj.get(GUARDRAILS_BODY_KEY) if GUARDRAILS_BODY_KEY in chunk_obj else None
                yield GenerationChunk(text=text_result, generation_info={GUARDRAILS_BODY_KEY: guardrails_obj, "id": id})

    @classmethod
    async def aprepare_output_stream(
        cls, provider: str, response: Any, stop: Optional[List[str]] = None
    ) -> AsyncIterator[GenerationChunk]:
        provider_details = ProviderMapping.parse(provider).value
        stream = response.get("body")
        if not stream:
            return

        output_key = provider_details.output_key
        if not output_key:
            raise ValueError(f"Unknown streaming response output key for provider: {provider}")

        for event in stream:
            chunk = event.get("chunk")
            if not chunk:
                continue

            chunk_obj = json.loads(chunk.get("bytes").decode())

            # Check for stop sequences
            stop_cfg = provider_details.get_input_config_name([LLMInputOption.STOP])
            stop_sequences = [i.value for i in stop_cfg if i is not None]
            stop_sequences.extend(stop or [])
            for stop in stop_sequences:
                if chunk_obj.get(stop):
                    return

            text_result, _ = cls._extract_llm_output(chunk_obj, output_key)
            yield GenerationChunk(text=text_result)


def _fix_newlines_in_prompt(input_text: str, user_prompt: str) -> str:
    """Add 2x newlines before 'Human:' and 'Assistant:' prompts and remove extra newlines."""
    user_prompt = user_prompt.strip()
    new_text = input_text
    for word in [user_prompt, "Assistant:"]:
        new_text = new_text.replace(word, "\n\n" + word)
        while "\n\n\n" + word in new_text:
            new_text = new_text.replace("\n\n\n" + word, "\n\n" + word)
    return new_text


def _human_assistant_format(input_text: str, provider: str) -> str:
    user_prompt = _get_human_prompt_format(provider)

    # Ensure if the user_prompt appears
    if user_prompt not in input_text:
        input_text = f"\n\n{user_prompt} {input_text}"  # SILENT CORRECTION
    # Ensure that the assistant prompt appears
    if input_text.count("Assistant:") == 0:
        input_text = input_text + ASSISTANT_PROMPT  # SILENT CORRECTION
    # Ensure the assistant prompt not appears before user prompt.
    if input_text.find(user_prompt) > input_text.find("Assistant:"):
        input_text = f"\n\n{user_prompt} {input_text}"  # SILENT CORRECTION

    input_text = _fix_newlines_in_prompt(input_text, user_prompt)
    return input_text


def _stream_response_to_generation_chunk(
    stream_response: Dict[str, Any],
) -> GenerationChunk:
    """Convert a stream response to a generation chunk."""
    if not stream_response["delta"]:
        return GenerationChunk(text="")
    return GenerationChunk(
        text=stream_response["delta"]["text"],
        generation_info=dict(
            finish_reason=stream_response.get("stop_reason", None),
        ),
    )


def _get_human_prompt_format(provider):
    if provider in USER_PROMPT_PROVIDERS:
        return "User:"
    elif provider in HUMAN_PROMPT_PROVIDERS:
        return "Human:"
    else:
        return "User:"
