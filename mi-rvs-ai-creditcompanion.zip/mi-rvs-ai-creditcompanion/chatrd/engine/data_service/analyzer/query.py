import logging
import re
from datetime import date
from typing import Optional

from chatrd.core.llm import LCLLMFactory
from chatrd.core.llm.components.message import AIMessage
from chatrd.engine.components.query_analyzer.filter_retrievers.base import FiltersInput
from chatrd.engine.components.query_analyzer.filter_retrievers.prompts import (
    TIME_THRESHOLD_PROMPT_STRING_OUTPUT,
    output_parser_time_threshold_symbol,
    task_specific_examples_string,
    task_specific_instructions_string,
)
from chatrd.engine.components.query_analyzer.filter_retrievers.time_threshold import (
    TimeThresholdFilter,
)
from chatrd.engine.data_service.analyzer import BaseAnalyzer
from chatrd.engine.data_service.analyzer.prompts.company_classification_prompts import (
    COMPANY_CLASSIFICATION,
    COMPANY_CLASSIFICATION_EXAMPLES,
)
from chatrd.engine.data_service.analyzer.prompts.credit_action_prompts import (
    CREDITACTION_EXTRACTION_EXAMPLES,
    CREDITACTION_EXTRACTION_PROMPT,
)
from chatrd.engine.data_service.analyzer.prompts.credit_rating_prompts import (
    CREDITRATING_EXTRACTION_EXAMPLES,
    CREDITRATING_EXTRACTION_PROMPT,
)
from chatrd.engine.data_service.analyzer.prompts.creditwatch_outlook_prompts import (
    CREDITWATCH_OUTLOOK_EXTRACTION_EXAMPLES,
    CREDITWATCH_OUTLOOK_EXTRACTION_PROMPT,
)
from chatrd.engine.data_service.analyzer.prompts.display_column_prompts import (
    DISPLAY_COLUMN_PROMPT,
)
from chatrd.engine.data_service.analyzer.prompts.financial_prompts import (
    QUERY_FINANCIAL_EXAMPLES,
    QUERY_FINANCIAL_EXTRACTION_PROMPT_TEMPLATE,
)
from chatrd.engine.data_service.analyzer.prompts.geography_prompts import (
    GEOGRAPHY_EXTRACTION_EXAMPLES,
    GEOGRAPHY_EXTRACTION_PROMPT,
)
from chatrd.engine.data_service.analyzer.prompts.industry_prompts import (
    INDUSTRY_EXTRACTION_PROMPT,
    QueryIndustryRetriever,
    parser_industry_extraction,
)
from chatrd.engine.data_service.analyzer.prompts.main_extraction_prompts import (
    MAIN_EXTRACTION_PROMPT,
    MAIN_EXTRACTION_SAMPLES,
)
from chatrd.engine.data_service.analyzer.prompts.model_validator import (
    validate_and_convert_response,
)
from chatrd.engine.data_service.analyzer.utils import (
    convert_tuples_to_string,
    filter_llm_response_financial_metrics,
    get_financial_metrics_by_sectors,
    sorting_extractor,
)
from chatrd.engine.data_service.kpqi.base import KPQI
from chatrd.engine.data_service.model_output_parser.variables import (
    SYNONYMS_CREDIT_RATING_MAPPING,
)
from chatrd.engine.data_service.schema import Analyzer, ProcessorInput
from chatrd.engine.data_service.utils import convert_response_to_dict_for_screener

logger = logging.getLogger(__name__)


CLAUDE_3_7_LLM = "claude-3-7-sonnet-20250219-v1:0"
HAIKU_4_5_LLM = "us.anthropic.claude-haiku-4-5-20251001-v1:0"


class QueryAnalyzer(BaseAnalyzer):
    def __init__(self, vector_database_path: Optional[str] = None):
        self.vector_database_path = vector_database_path

    def analyze(self, processor: ProcessorInput, ds_tag: Optional["str"] = "company") -> Analyzer:
        # Define LLM
        model_for_data_service = LCLLMFactory().get_llm(
            deployment_name_or_model_id=CLAUDE_3_7_LLM,
            temperature=processor.temperature,
        )

        error_message = None
        # Verify if the user question is a company related question
        company_classification_prompt = COMPANY_CLASSIFICATION.format(
            company_classification_examples=convert_tuples_to_string(COMPANY_CLASSIFICATION_EXAMPLES),
            user_question=processor.user_input,
        )
        try:
            classification_response = model_for_data_service.invoke(company_classification_prompt)
            classification_response = classification_response.content
        except Exception as e:
            logger.error(f"Error in company classification: {e}")
            classification_response = "non-company"

        if classification_response == "non-company":
            error_message = (
                "CreditCompanion<sup>TM</sup> currently supports only company-related queries. Lists of securities for multiple entities are coming soon. "
                "Please rephrase your question to focus on companies or sectors."
            )
            logger.info("Query Analyzer: Non-company question detected.")
            return Analyzer(uc_type=processor.uc_type, ds_tag=ds_tag, error_message=error_message, response={})

        response_dict = {"type": "company"}
        # 1- EXTRACT MAIN ATTRIBUTES FROM USER QUESTION
        main_extraction_prompt = MAIN_EXTRACTION_PROMPT.format(
            main_extraction_examples=convert_tuples_to_string(MAIN_EXTRACTION_SAMPLES),
            user_question=processor.user_input,
        )
        response = model_for_data_service.invoke(main_extraction_prompt)

        try:
            if isinstance(response, AIMessage):
                response = response.content
            attributes_dict = convert_response_to_dict_for_screener(response)
            attributes_dict = {key.lower(): value for key, value in attributes_dict.items()}
        except Exception as e:
            logger.error(f"Error in converting response to dict: {e}")
            attributes_dict = dict()
        logger.info(f"\nQuery Analyzer main extractor output : \n{attributes_dict}")

        # 2.a EXTRACT INDUSTRY
        industry_question = attributes_dict.get("industry", "")
        if industry_question != "":
            sector_retriever = QueryIndustryRetriever(
                uc_specific_prompt=INDUSTRY_EXTRACTION_PROMPT,
                output_parser=parser_industry_extraction,
                filters_input=FiltersInput(llm=HAIKU_4_5_LLM, temperature=0.0),
            )
            try:
                industry_response = sector_retriever.invoke(industry_question)
            except (IndexError, KeyError, AttributeError) as e:
                logger.info(f"Extracted industry is malformed or empty: {e}")
                industry_response = ""

            if industry_response != "":
                response_dict["industry"] = {
                    "value": industry_response,
                    "connector": "and",
                    "operator": "in",
                    "display_column": False,
                }
                logger.info(f"\nQuery Analyzer industry extractor output : \n{response_dict['industry']}")
            else:
                response_dict["industry"] = {
                    "value": None,
                    "connector": "and",
                    "operator": "in",
                    "display_column": True,
                }
                logger.info(f"Query Analyzer industry extractor could not extract any information: {industry_question}")

        # 2.b EXTRACT CREDIT RATING
        rating_question = attributes_dict.get("credit_rating", "")
        if rating_question != "":
            try:
                credit_rating_prompt = CREDITRATING_EXTRACTION_PROMPT.format(
                    synonyms=", ".join(f"{key} ({value})" for key, value in SYNONYMS_CREDIT_RATING_MAPPING.items()),
                    creditrating_extraction_examples=convert_tuples_to_string(CREDITRATING_EXTRACTION_EXAMPLES),
                    current_date=date.today().strftime("%m/%d/%Y"),
                    user_question=rating_question,
                    display_column_instructions=DISPLAY_COLUMN_PROMPT.format(value="credit rating"),
                )

                credit_ratings_response = model_for_data_service.invoke(credit_rating_prompt)
                credit_ratings_response = credit_ratings_response.content
                response = validate_and_convert_response(credit_ratings_response, "credit_rating")

                credit_ratings = response.get("value", None)
                time_frame = response.get("time_frame", None)
                display_column = response.get("display_column", False)

                if credit_ratings is None and time_frame is None and display_column is False:
                    error_message = (
                        "CreditCompanion was unable to find any matching results for the specified credit rating. "
                        "Please try another question. "
                    )
                    logger.info("Query Analyzer: User question could not be mapped to any credit rating.")
                    return Analyzer(uc_type=processor.uc_type, ds_tag=ds_tag, error_message=error_message, response={})

                if credit_ratings or display_column:
                    response_dict[str(KPQI.RD_CREDIT_RATING_GLOBAL.value)] = {
                        "value": credit_ratings,
                        "connector": "and",
                        "operator": "in",
                        "display_column": display_column,
                    }
                    log_message = f"\nQuery Analyzer credit rating extractor output : \n{response_dict[str(KPQI.RD_CREDIT_RATING_GLOBAL.value)]}"
                    if time_frame:
                        time_frame = time_frame.split("-")[1].strip()
                        response_dict["last review date"] = {
                            "value": time_frame,
                            "connector": "and",
                            "operator": "from",
                        }
                        log_message += f"\n{response_dict['last review date']}"
                else:
                    log_message = (
                        "nQuery Analyzer credit rating extractor could not extract any information: {rating_question}"
                    )
                logger.info(f"{log_message}")
            except Exception as e:
                logger.error(f"Error in credit rating extraction for question:{rating_question}, Error: {e}")

        # 2.c EXTRACT CREDIT WATCH / OUTLOOK ACTIONS
        creditwatch_outlook_question = attributes_dict.get("creditwatch_outlook_actions", "")
        if creditwatch_outlook_question != "":
            try:
                creditwatch_outlook_prompt = CREDITWATCH_OUTLOOK_EXTRACTION_PROMPT.format(
                    creditwatch_outlook_extraction_examples=convert_tuples_to_string(
                        CREDITWATCH_OUTLOOK_EXTRACTION_EXAMPLES
                    ),
                    current_date=date.today().strftime("%m/%d/%Y"),
                    user_question=creditwatch_outlook_question,
                    display_column_instructions=DISPLAY_COLUMN_PROMPT.format(value="credit watch / outlook"),
                )

                creditwatch_outlook_response = model_for_data_service.invoke(creditwatch_outlook_prompt)
                creditwatch_outlook_response = creditwatch_outlook_response.content
                response = validate_and_convert_response(creditwatch_outlook_response, "creditwatch_outlook")

                creditwatch_outlook = response.get("value", None)
                time_frame = response.get("time_frame", None)
                display_column = response.get("display_column", False)

                if creditwatch_outlook or display_column:
                    response_dict[str(KPQI.RD_CWOL_GLOBAL.value)] = {
                        "value": creditwatch_outlook,
                        "connector": "and",
                        "operator": "in",
                        "display_column": display_column,
                    }
                    log_message = f"\nQuery Analyzer credit watch / outlook extractor output : \n{response_dict[str(KPQI.RD_CWOL_GLOBAL.value)]}"
                    # CreditWatch/Outlook Timeframe is Current Only for 25.12
                    # if time_frame:
                    #     time_frame = time_frame.split("-")[1].strip()
                    #     response_dict["credit watch outlook date"] = {
                    #         "value": time_frame,
                    #         "connector": "and",
                    #         "operator": "from",
                    #     }
                    #     log_message += f"\n{response_dict['credit watch outlook date']}"
                else:
                    log_message = "nQuery Analyzer credit watch / outlook extractor could not extract any information: {creditwatch_outlook_question}"
                logger.info(f"{log_message}")
            except Exception as e:
                logger.error(
                    f"Error in credit watch / outlook extraction for question:{creditwatch_outlook_question}, Error: {e}"
                )

        # 2.d EXTRACT CREDIT ACTION
        rating_action_question = attributes_dict.get("credit_action_type", "")
        if rating_action_question != "":
            try:
                rating_action_prompt = CREDITACTION_EXTRACTION_PROMPT.format(
                    creditaction_extraction_examples=convert_tuples_to_string(CREDITACTION_EXTRACTION_EXAMPLES),
                    current_date=date.today().strftime("%m/%d/%Y"),
                    user_question=rating_action_question,
                )

                rating_action_response = model_for_data_service.invoke(rating_action_prompt)
                rating_action_response = rating_action_response.content
                response = validate_and_convert_response(rating_action_response, "credit_action")

                credit_action = response.get("value", None)
                time_frame = response.get("time_frame", None)
                display_column = response.get("display_column", False)

                if credit_action or display_column:
                    response_dict[str(KPQI.RD_RATING_ACTION_GLOBAL.value)] = {
                        "value": credit_action,
                        "connector": "and",
                        "operator": "equal",
                        "display_column": display_column,
                    }
                    log_message = f"\nQuery Analyzer rating action extractor output : \n{response_dict[str(KPQI.RD_RATING_ACTION_GLOBAL.value)]}"
                    if time_frame:
                        response_dict["credit rating date"] = {
                            "value": time_frame,
                            "connector": "and",
                            "operator": "from",
                        }
                        log_message += f"\n{response_dict['credit rating date']}"
                else:
                    log_message = f"nQuery Analyzer rating action extractor could not extract any information: {rating_action_question}"
                logger.info(f"{log_message}")
            except Exception as e:
                logger.error(f"Error in credit action extraction for question:{rating_action_question}, Error: {e}")

        # 2.e EXTRACT GEOGRAPHY
        geography_question = attributes_dict.get("geography", "")
        if geography_question != "":
            geography_prompt = GEOGRAPHY_EXTRACTION_PROMPT.format(
                geography_extraction_examples=convert_tuples_to_string(GEOGRAPHY_EXTRACTION_EXAMPLES),
                user_question=geography_question,
            )

            try:
                geography_response = model_for_data_service.invoke(geography_prompt)
                response = validate_and_convert_response(geography_response.content, "geography")
                geography_response = response.get("value", None)

            except (IndexError, KeyError, AttributeError) as e:
                logger.info(f"Extracted geography is malformed or empty: {e}")
                geography_response = ""

            if geography_response != "":
                response_dict["geography"] = {
                    "value": geography_response,
                    "connector": "and",
                    "operator": "in",
                    "display_column": False,
                }
                logger.info(f"\nQuery Analyzer geography extractor output : \n{response_dict['geography']}")
            else:
                response_dict["geography"] = {
                    "value": None,
                    "connector": "and",
                    "operator": "in",
                    "display_column": True,
                }
                logger.info(
                    f"Query Analyzer geography extractor could not extract any information: {geography_question}"
                )

        # 2.f.i EXTRACT FINANCIALS
        # Get all financial metrics from sectors CORP and FI for 25.09 and later in 25.12 pass {} for all 3 sectors
        financial_question = attributes_dict.get("financial_metrics", "")
        if financial_question != "":
            metrics_list, metric_names = get_financial_metrics_by_sectors(sectors={"CORP", "FI"})
            unique_metric_names = list(set(metric_names))
            unique_metric_names.sort()

            financial_prompt = QUERY_FINANCIAL_EXTRACTION_PROMPT_TEMPLATE.format(
                query_financial_examples=convert_tuples_to_string(QUERY_FINANCIAL_EXAMPLES),
                financial_metrics=unique_metric_names,
                user_input=financial_question,
            )
            financial_extraction_llm = LCLLMFactory().get_llm(
                deployment_name_or_model_id=CLAUDE_3_7_LLM,
                temperature=processor.temperature,
            )
            output = financial_extraction_llm.invoke(financial_prompt)
            logger.info(f"Query Analyzer financial extractor output: {output}")
            extracted_metric_names, extracted_metric_list = filter_llm_response_financial_metrics(
                output, metric_names, metrics_list
            )
            logger.info(f"Filtered Financial Metrics: {extracted_metric_names}")

            unique_metrics = []
            unique_extracted_metric_list = []
            for metric in extracted_metric_list:
                metric_code = metric.get("MetricCode", "")
                if metric_code in unique_metrics:
                    continue
                unique_metrics.append(metric_code)
                unique_extracted_metric_list.append(metric)

            financial_metrics_dict = {
                "financialMetricsList": unique_extracted_metric_list,
            }
            response_dict = {**response_dict, **financial_metrics_dict}

            # 2.f.ii EXTRACT FINANCIALS TIME
            if extracted_metric_names:
                ## Extracting dates for financial metrics
                date_retriever_string_output = TimeThresholdFilter(
                    uc_specific_prompt=TIME_THRESHOLD_PROMPT_STRING_OUTPUT,
                    output_parser=output_parser_time_threshold_symbol,
                    specific_instructions_fn=task_specific_instructions_string,
                    examples_fn=task_specific_examples_string,
                    filters_input=FiltersInput(llm=processor.llm, temperature=processor.temperature),
                )
                extracted_time = date_retriever_string_output.invoke(financial_question, today_date=date.today())
                extracted_periods_dict = extracted_time.model_dump(exclude="ChainOfThought")
                extracted_periods = extracted_periods_dict.get("PeriodsList", ["LFY"])
                if not extracted_periods:
                    extracted_periods = ["LFY"]
                response_dict["financialTime"] = list(set(extracted_periods))
                logger.info(f"Financial Metrics Time Retriever - output: {response_dict['financialTime']}")
            else:
                response_dict["financialTime"] = []

            # List query analyzer only supports default date for rating and rating actions if financials are mentioned in the user question
            # if 'financialMetrics' in response_dict below condition removes the keys that contain 'date' in the response_dict
            # So that query flow applies default date for rating and rating actions and dynamic date only for financials
            if "financialMetrics" in response_dict:
                # Remove keys that contain 'date'
                keys_to_remove = [key for key in response_dict.keys() if "date" in key]
                for key in keys_to_remove:
                    del response_dict[key]
        else:
            response_dict["financialMetricsList"] = []
            response_dict["financialTime"] = []

        # 2.g EXTRACT THE ORDER
        order_question = attributes_dict.get("sorting", "")
        if order_question != "":
            sorting_response_dict = sorting_extractor(model_for_data_service, order_question)
            if not sorting_response_dict:
                logger.info("Company Query Analyzer : no special order")
            else:
                if any(value is not None for value in sorting_response_dict.values()):
                    logger.info(f"\nCompany Query Analyzer order response: \n{sorting_response_dict}")
                    response_dict = {**response_dict, **sorting_response_dict}
                else:
                    logger.info("Company Query Analyzer : no special order")

        return Analyzer(uc_type=processor.uc_type, ds_tag=ds_tag, error_message=error_message, response=response_dict)
