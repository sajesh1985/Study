# from enum import Enum
import yaml
import os
# from src.synthia.prompts.section_guideline_prompts import (
#     company_description,
#     key_financials,
#     sector_and_risk_analysis,
#     sp_current_rating,
#     sp_ratings_history,
#     credit_outlook,
#     analyst_peers,
#     news_key_developments,
#     swot_analysis,
#     moody_fitch_analysis,
# )


class SectionTitle(str, Enum):
    COMPANY_DESCRIPTION = "Company Description"
    KEY_FINANCIALS = "Key Financials (Sources & Uses of Liquidity)"
    SECTOR_RISK_ANALYSIS = "Sector & Industry Risk Analysis + CICRA"
    SP_CURRENT_RATINGS = "S&P Current Ratings"
    SP_RATINGS_HISTORY = "S&P Ratings History"
    CREDIT_OUTLOOK = "Credit Outlook"
    ANALYST_PEERS = "Analyst Peers / Peer Comps structured data"
    NEWS_KEY_DEVELOPMENTS = "News & Key Developments"
    SWOT_ANALYSIS = "SWOT Analysis"
    MOODY_FITCH_ANALYSIS = "Moody's & Fitch Ratings & History"
    GEOGRAPHIC_MIX = "Geographic Mix"
    SEGMENT_MIX = "Segment Mix"
    SHAREPRICE = "Share Price"
    SUMMARY_ANALYSIS = "Summary Analysis"    
    COMPANY_AUDIT_DETAILS = "Company Audit Details"
    COMPANY_FINANCIAL_HIGHLIGHTS = "Company Financial Highlights"
    COMPANY_INCOME_STATEMENT="Company Income Statement"
    COMPANY_BALANCE_SHEET="Company Balance Sheet"
    COMPANY_CASH_FLOW="Company Cash Flow"

    SEGMENT_ANALYSIS="Segment Analysis"
    COMPANY_PERFORMANCE_ANALYSIS="Company Performance Analysis"

# def map_string_to_enum(section_title: str) -> SectionTitle:
#     """Maps a string title to the corresponding SectionTitle enum."""
#     # Normalize the string for comparison
#     normalized_title = section_title.strip()
#     for title in SectionTitle:
#         if title.value == normalized_title:
#             return title
#     return None  # or handle the error as needed


# def get_system_prompt_for_section(section_title: str, template_filename: str) -> str:
#     """
#     Returns the system prompt for a given section title from the specified template YAML file.
#     :param section_title: The title of the section as a string.
#     :param template_filename: The filename of the template YAML.
#     :return: The system prompt for the section.
#     """
#     # Resolve the full path if not absolute
#     if not os.path.isabs(template_filename):
#         # Assuming templates are in src/synthia/resources/templates/
#         base_dir = os.path.dirname(os.path.abspath(__file__))
#         template_path = os.path.join(base_dir, "..", "resources", "templates", template_filename)
#         template_path = os.path.normpath(template_path)
#     else:
#         template_path = template_filename

#     if not os.path.exists(template_path):
#         return ""

#     with open(template_path, "r", encoding="utf-8") as f:
#         template_data = yaml.safe_load(f)

#     sections = template_data.get("sections", [])
#     for section in sections:
#         if section.get("section_title", "").strip() == section_title.strip():
#             return section.get("system_prompt", "") or ""
#     return ""
