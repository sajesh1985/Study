import logging
from typing import Dict, List

from pydantic import BaseModel

from chatrd.core.document import Document
from chatrd.core.vectorstore import OpenSearch
from chatrd.engine.components.query_processor.query_retriever.uc_retrievers.base import (
    UCRetriever,
)
from chatrd.engine.components.query_processor.query_retriever.utils import (
    add_unstructured_source,
)
from chatrd.engine.configuration import Constants, get_config_machinery

logger = logging.getLogger(__name__)

config_machinery = get_config_machinery()


class DefinitionRetriever(UCRetriever):
    def __init__(self, vector_stores_dict: Dict[str, OpenSearch]):
        self.vector_stores_dict = vector_stores_dict
        self.top_k_text_definition = config_machinery.get_config_value(Constants.GeneralConstants.TOP_K_TEXT_DEFINITION)

    def retrieve(self, query: str, sectors: BaseModel, multi_uc_type: bool = False) -> List[Document]:
        vector_db_retrieved_documents = self.vector_db_retrieval(query=query)
        logger.info(f"Total number of retrieved documents : {len(vector_db_retrieved_documents)}")
        vector_db_retrieved_documents = add_unstructured_source(vector_db_retrieved_documents)
        return vector_db_retrieved_documents

    def vector_db_retrieval(self, query: str) -> List[Document]:
        retrieved_documents, scores = self.vector_stores_dict["definition"].get_relevant_documents(
            query,
            efficient_filter=None,
            model_id=config_machinery.get_config_value(Constants.OpenSearch.NEURAL_SEARCH_MODEL_ID),
            search_pipeline=config_machinery.get_config_value(Constants.OpenSearch.HYBRID_SEARCH_SEARCH_PIPELINE_ID),
            top_k_text_chunks=self.top_k_text_definition,
        )
        retrieved_documents = self.add_additional_metadata_to_documents(
            uc_type="definition", user_query=query, entity=None, documents=retrieved_documents
        )

        return retrieved_documents
