import styled from '@emotion/styled';

export const PreformattedContent = styled.pre`
  font-family: var(--font-family-mono);
  margin: 0;
`;
export const DivformattedContent = styled.div`
  font-feature-settings: 'clig' off, 'liga' off;
  font-family: "Akkurat";
  font-size: 14px;
  font-style: normal;
  font-weight: 400;
  line-height: var(--scale-line-height-150);
  a
  {
      color: var(--color-text-link);
  }
`;
