import logging

from chatrd.engine.data_service.model_output_parser import base_parser

logger = logging.getLogger(__name__)


class SecurityItemParser(base_parser.BaseItemParser):
    def map_look_values(self, kpqi, value_str, operator_payload, operator_text):
        return value_str, value_str, operator_payload, operator_text

    def custom_logic_before_field_search(self, key, value_str):
        if key == "security identifier":
            if len(value_str) == 9:
                key = "cusip"
            elif len(value_str) == 12:
                key = "isin"
        return key, value_str
