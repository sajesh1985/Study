﻿// Copyright Notice! 
// This document is protected under the trade secret and copyright 
// laws as the property of Fidelity National Information Services, Inc. 
// Copying, reproduction or distribution should be limited and only to 
// employees with a “need to know” to do their job. 
// Any disclosure of this document to third parties is strictly prohibited.
// © 2018 Fidelity National Information Services.
// All rights reserved worldwide.

namespace Fis.Epp.Fusion.Auth
{
    using Fis.Epp.Fusion.Auth.Models;

    /// <summary>Represents an application diagnostics utility.</summary>
    public class AppDiagnostics
    {
        #region Public Methods

        /// <summary>Record exception data.</summary>
        /// <param name="errorData">Represents error data.</param>
        public static void RecordException(ExceptionLoggerModel errorData)
        {
            if (errorData != null)
            {                
                NLog.LogEventInfo logAuthErrorEvent = new NLog.LogEventInfo(NLog.LogLevel.Error, "", "");
                logAuthErrorEvent.Properties[ExceptionEnum.CorrelationId.GetEnumDescription()] = errorData.CorrelationId;
                logAuthErrorEvent.Properties[ExceptionEnum.FeId.GetEnumDescription()] = errorData.FeId;
                logAuthErrorEvent.Properties[ExceptionEnum.UserId.GetEnumDescription()] = errorData.UserId;
                logAuthErrorEvent.Properties[ExceptionEnum.MemberId.GetEnumDescription()] = errorData.MemberId;
                logAuthErrorEvent.Properties[ExceptionEnum.RequestorId.GetEnumDescription()] = errorData.RequestorId;
                logAuthErrorEvent.Properties[ExceptionEnum.RequestUrl.GetEnumDescription()] = errorData.RequestUrl;
                logAuthErrorEvent.Properties[ExceptionEnum.ErrorStack.GetEnumDescription()] = errorData.ErrorStack;
                logAuthErrorEvent.Properties[ExceptionEnum.ErrorMessage.GetEnumDescription()] = errorData.ErrorMessage;
                NLog.Logger _loggerUI = NLog.LogManager.GetLogger(ExceptionEnum.FusionAuth.GetEnumDescription());
                _loggerUI.Log(logAuthErrorEvent);
            }
        }

        #endregion
    }
}
