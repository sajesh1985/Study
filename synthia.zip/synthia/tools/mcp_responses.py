from typing import Dict, Optional, List

from pydantic import BaseModel, Field

from src.synthia.utils.source import Source


class ErrorResponse(BaseModel):
    error: str = Field(description="Error message describing the failure.")


class QuarterInfo(BaseModel):
    name: str = Field(description="Name of the quarter or period, e.g., '2024 FQ2' or 'LTM'.")
    value: str = Field(description="Value for the specified quarter or period.")
    periodEndDate: Optional[str] = Field(None, description="End date of the period, if available.")
    LastUpdateDate: Optional[str] = Field(None, description="Last update date for the data, if available.")


class MetricEntry(BaseModel):
    CreditStatsMetricCaption: str = Field(description="Caption describing the credit stats metric.")
    Threshold: str = Field(description="Threshold value for the metric, e.g., '<18%' or '>16%'.",
                           examples=['<18%', '>16%'])
    LatestQuarter: QuarterInfo = Field(description="Information about the latest quarter for the metric.")
    Ltm: QuarterInfo = Field(description="Information about the last twelve months (LTM) for the metric.")
    ReportedCurrency: str = Field(description="Currency in which the metric is reported.")


class TransformedOutlook(BaseModel):
    downside: List[MetricEntry] = Field([], description="List of downside metric entries.")
    upside: List[MetricEntry] = Field([], description="List of upside metric entries.")


class FinancialOutlookThresholdResponse(BaseModel):
    sources: Source | None = Field(None, description="Source URL of the financial outlook data.")
    value: TransformedOutlook | ErrorResponse = Field(
        description="Company financial outlook threshold current data or error response."
    )

class MoodyRatingModel(BaseModel):
    KeyInstn: int = Field(..., description="The company or institution identifier.")
    CreditRating: Optional[str] = Field(None, description="The Moody's credit rating (e.g., 'A1', 'WR').")
    RatingsAsOf: Optional[str] = Field(None, description="The date and time the rating was assigned (ISO 8601 format).")
    CreditWatchOutlook: Optional[str] = Field(None, description="The outlook or watch status for the rating.")
    RatingType: Optional[str] = Field(None, description="The type of Moody's rating (e.g., 'Long Term Rating').")
    GroupType: Optional[str] = Field(None, description="The group type for the rating (optional).")


class MoodyRatingsResponse(BaseModel):
    sources: List[Source] = Field(..., description="Metadata and source URL for traceability.")
    data: Dict[str, List[MoodyRatingModel]] = Field(..., description="Dictionary containing MoodyRating list.")
