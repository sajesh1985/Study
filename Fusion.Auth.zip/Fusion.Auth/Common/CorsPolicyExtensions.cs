﻿using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;

namespace Fis.Epp.Fusion.Auth.Common
{
    public static class CorsPolicyExtensions
    {
        public static void UseCorsPolicy(this IApplicationBuilder builder)
        {
            var serviceProvider = builder.ApplicationServices;
            var appConfigService = serviceProvider.GetService<AppConfiguration>();
            bool enableCors = appConfigService.CorsPolicies.Enable;
            if (enableCors)
            {
                builder.UseCors("EnableCors");
            }
        }
        public static void AddCorsPolicy(this IServiceCollection services)
        {
            var serviceProvider = services.BuildServiceProvider();
            var appConfigService = serviceProvider.GetService<AppConfiguration>();

            bool enableCors = appConfigService.CorsPolicies.Enable;
            if (enableCors)
            {
                string[] allowedOrigins = appConfigService.CorsPolicies.CorsAllowedOrigins.Split(",");
                string[] allowedMethods = appConfigService.CorsPolicies.CorsAllowedMethods.Split(",");
                string[] allowedHeaders = appConfigService.CorsPolicies.CorsAllowedHeaders.Split(",");

                services.AddCors(options =>
                {
                    options.AddPolicy("EnableCors",
                          builder =>
                          {
                              builder.WithOrigins(allowedOrigins)
                              .WithMethods(allowedMethods)
                              .WithHeaders(allowedHeaders);
                          });
                });
            }
        }
    }
}

