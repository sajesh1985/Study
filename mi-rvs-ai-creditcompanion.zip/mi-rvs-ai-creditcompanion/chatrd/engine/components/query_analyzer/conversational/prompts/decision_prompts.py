from typing import Literal

from pydantic import BaseModel, field_validator


class DecisionOutput(BaseModel):
    flag: Literal["rephrasing", "clarifying"]

    @field_validator("flag")
    def flag_must_be_valid(cls, v):
        if v not in ["rephrasing", "clarifying"]:
            raise ValueError("Flag must be either 'rephrasing' or 'clarifying'")
        return v


DECISION_OUTPUT_PROMPT_FORMAT = """Provide a JSON object with the following structure:
{
    "flag": <"rephrasing" or "clarifying">
}
"""

DECISION_CLARIFYING_EXAMPLES = """
<example>
{
    "chat_history": [
        {
            "question": "for <entity1>?"
        },
        {
            "question": "<entity2>?"
        }
    ],
    "follow_up_question": "<entity3>?",
    "output": {
        "flag": "clarifying"
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "for <entity>?",
    "output": {
        "flag": "clarifying"
    }
}
</example>
<example>
{
    "chat_history": [
        {
            "question": "for <entity1>?"
        },
        {
            "question": "<entity2>?"
        }
    ],
    "follow_up_question": "for <entity3>?",
    "output": {
        "flag": "clarifying"
    }
}
</example>
<example>
{
    "chat_history": [
        {
            "question": "same for <entity1>"
        },
        {
            "question": "and <entity2>"
        },
        {
            "question": "what about <entity3>?"
        }
    ],
    "follow_up_question": "And <entity4>?",
    "output": {
        "flag": "clarifying"
    }
}
</example>
<example>
{
    "chat_history": [
        {
            "question": "For Intel?"
        },
        {
            "question": "IBM?"
        }
    ],
    "follow_up_question": "tesla?",
    "output": {
        "flag": "clarifying"
    }
}
</example>
<example>
{
    "chat_history": [
        {
            "question": "apple?"
        }
    ],
    "follow_up_question": "microsoft",
    "output": {
        "flag": "clarifying"
    }
}
</example>
<example>
{
    "chat_history": [
        {
            "question": "apple?"
        }
    ],
    "follow_up_question": "microsoft",
    "output": {
        "flag": "clarifying"
    }
}
</example>
<example>
{
    "chat_history": [
        {
            "question": "tesla"
        }
    ],
    "follow_up_question": "for IBM",
    "output": {
        "flag": "clarifying"
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "What is the rating action for?",
    "output": {
        "flag": "clarifying"
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "ratings",
    "output": {
        "flag": "clarifying"
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "Ratings?",
    "output": {
        "flag": "clarifying"
    }
}
</example>
<example>
{
    "chat_history": ["Ratings"],
    "follow_up_question": "SWOT?",
    "output": {
        "flag": "clarifying"
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "Rating action. Financial insights. Interest cover ratio",
    "output": {
        "flag": "clarifying"
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "Financial highlights, Ratings, Latest rating action",
    "output": {
        "flag": "clarifying"
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "Ratings and swot for it?",
    "output": {
        "flag": "clarifying"
    }
}
</example>
"""

DECISION_REPHRASING_EXAMPLES = """
<example>
{
    "chat_history": [
        {
            "question": "Summary/updates about <entity1>"
        }
    ],
    "follow_up_question": "What is the latest research for <entity2>?",
    "output": {
        "flag": "rephrasing"
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "What is the rating for <entity>?",
    "output": {
        "flag": "rephrasing"
    }
}
</example>
<example>
{
    "chat_history": [
        {
            "question": "Ratings for abc"
        }
    ],
    "follow_up_question": "and for xyz?",
    "output": {
        "flag": "rephrasing"
    }
}
</example>
<example>
{
    "chat_history": [
        {
            "question": "for <entity1>?"
        },
        {
            "question": "<entity2>?"
        }
    ],
    "follow_up_question": "Can you provide me with outlook for <entity3>?",
    "output": {
        "flag": "rephrasing"
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "Give me all the airports that underwent a large capex projects",
    "output": {
        "flag": "rephrasing"
    }
}
</example>
<example>
{
    "chat_history": [
        {
            "question": "Outlook for xyz"
        },
        {
            "question": "Ratings for abc"
        }
    ],
    "follow_up_question": "Compare uvw to qxp",
    "output": {
        "flag": "rephrasing"
    }
}
</example>
<example>
{
    "chat_history": [
        {
            "question": "explain business risk for corporates', What are the key ratios for the corporate methodology?"
        },
        {
            "question": "What would cause a downgrade for Chevron?"
        }
    ],
    "follow_up_question": "what is the rating for new york?",
    "output": {
        "flag": "rephrasing"
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "Compare abc to xyz",
    "output": {
        "flag": "rephrasing"
    }
}
</example>
<example>
{
    "chat_history": [
        {
            "question": "Outlook for <entity1>?"
        },
        {
            "question": "outlook <entity2>"
        },
        {
            "question": "<entity3> outlook"
        },
    ],
    "follow_up_question": "what is the rating for <entity4>?",
    "output": {
        "flag": "rephrasing"
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "what is the rating for <entity1>, <entity2>, <entity3>?",
    "output": {
        "flag": "rephrasing"
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "Summarize the articles for xyz?",
    "output": {
        "flag": "rephrasing"
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "Research situations where hospitals expanded facilities and determine their impact on patient care",
    "output": {
        "flag": "rephrasing"
    }
}
</example>
<example>
{
    "chat_history": [
        {
            "question": "What is the current Rating of <entity1>?"
        },
        {
            "question": "What is the current outlook of <entity2>"
        },
        {
            "question": "what is the Rating of <entity3?"
        },
    ],
    "follow_up_question": "Provide a list of key players in <sector> from <country>",
    "output": {
        "flag": "rephrasing"
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "What is <term>?",
    "output": {
        "flag": "rephrasing"
    }
}
</example>
<example>
{
    "chat_history": [
        {
            "question": "Peers for xyz?"
        },
        {
            "question": "Ratings for it?"
        }
    ],
    "follow_up_question": "Was it recently upgraded?",
    "output": {
        "flag": "rephrasing"
    }
}
</example>
<example>
{
    "chat_history": [
        {
            "question": "Peers for <country>?"
        }
    ],
    "follow_up_question": "Election results for it?",
    "output": {
        "flag": "rephrasing"
    }
}
</example>
<example>
{
    "chat_history": [
        {
            "question": "Can you do a credit memo for <entity1>?"
        }
    ],
    "follow_up_question": "what is swot analysis for it with <entity2>?",
    "output": {
        "flag": "rephrasing"
    }
}
</example>
<example>
{
    "chat_history": [
        {
            "question": "How many companies were newly rated by S&P in <country>?"
        },
                {
            "question": "Peers for <financial institution>"
        },
        {
            "question": "Was <company> downgraded recently?"
        }
    ],
    "follow_up_question": "What is rating for <city>?",
    "output": {
        "flag": "rephrasing"
    }
}
</example>
<example>
{
    "chat_history": [
        {
            "question": "Who is the analyst/show me the analyst for <entity1>"
        }
    ],
    "follow_up_question": "Analyst for <entity2>?",
    "output": {
        "flag": "rephrasing"
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "what were the S&P Risk Weighted Assets Before Diversification for <entity> in Q1/Q2/Q3/Q4 of <year>?",
    "output": {
        "flag": "rephrasing"
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "What were the credit rating actions that were given in Q1/Q2/Q3/Q4 of <year>?",
    "output": {
        "flag": "rephrasing"
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "What is latest commodity prices?",
    "output": {
        "flag": "rephrasing"
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "Share methology for the <sector>",
    "output": {
        "flag": "rephrasing"
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "What <product> are developed by xyz company?",
    "output": {
        "flag": "rephrasing"
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "Provide information about tariff tracker",
    "output": {
        "flag": "rephrasing"
    }
}
</example>
<example>
{
    "chat_history": [
        {
            "question": "Write a full analysis for <entity1>"
        }
    ],
    "follow_up_question": "What is the outlook for <entity2>'s economy?",
    "output": {
        "flag": "rephrasing"
    }
}
</example>
<example>
{
    "chat_history": [
        {
            "question": "can you share methodolgy for <entity_type> ratings"
        },
        {
            "question": "expaling methodology for rating <entity_type>"
        }
    ],
    "follow_up_question": "What are the individual credit ratings that the xyz methodology apply too?",
    "output": {
        "flag": "rephrasing"
    }
}
</example>
<example>
{
    "chat_history": [
        {
            "question": "Peers for <entity1>?"
        },
         {
            "question": "Outlook for it"
        },
    ],
    "follow_up_question": "Same for <entity2>?",
    "output": {
        "flag": "rephrasing"
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "What are the peers of <entity1>? What is the difference in credit ratings between <entity2> and <entity3>? What is credit memo for <entity4>?",
    "output": {
        "flag": "rephrasing"
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "SWOT for <entity1> and <entity2>. Provide their financial highlights and ratings.",
    "output": {
        "flag": "rephrasing"
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "What are the latest rating actions for <entity1>, <entity2>, and <entity3>. Provide their competitors and ebitda / interest expense figures.",
    "output": {
        "flag": "rephrasing"
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "What are the financial highlighs <country1> and <country2>?",
    "output": {
        "flag": "rephrasing"
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "Provide info about <entity1> aid program",
    "output": {
        "flag": "rephrasing"
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "Show me a list of companies and give me their outlook",
    "output": {
        "flag": "rephrasing"
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "Are there any companies that are developing?",
    "output": {
        "flag": "rephrasing"
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "What is the current CSD for <entity>?",
    "output": {
        "flag": "rephrasing"
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "Will the fed lower interest rates in Q3??",
    "output": {
        "flag": "rephrasing"
}
</example>
<example>
{
    "chat_history": [
        {
            "question": "SWOT for <entity1>"
        },
        {
            "question": "<entity2>"
        }
    ],
    "follow_up_question": "for <entity3>",
    "output": {
        "flag": "rephrasing"
}
</example>
<example>
{
    "chat_history": [
        {
            "question": "for <entity1>"
        },
        {
            "question": "Ratings for <entity2>"
        }
    ],
    "follow_up_question": "<entity3>?",
    "output": {
        "flag": "rephrasing"
}
</example>
<example>
{
    "chat_history": [
        {
            "question": "Outlook for <entity1>"
        }
    ],
    "follow_up_question": "<entity2>?",
    "output": {
        "flag": "rephrasing"
}
</example>
"""

DECISION_EXAMPLES = f"""{DECISION_REPHRASING_EXAMPLES}{DECISION_CLARIFYING_EXAMPLES}
"""

DECISION_PROMPT = """You are a helpful assistant answering questions in the credit and financial domain.
You have access to the user's chat history and their follow-up question.

Your goal is to decide if the follow-up question requires 'rephrasing' or 'clarification' based on the chat history.

Notions:
A. Entity: A specific item such as a company, country, sector, term, or financial institution.
B. User Intent: The specific information the user is seeking, such as ratings, outlook, peers, financials, scores and modifiers, forecasts, SWOT analysis, definitions, prices, information about defaults and research etc. It could be a broad question without specific entities, e.g., "What is rating action?", "what does ratings think will happen with defaults in the next couple years?" etc.

Follow these rules step by step:

A. Flag 'rephrasing' if the <follow_up_question> contains subquestions with at least one entity.  
B. Flag 'rephrasing' if the <follow_up_question> asks for a list of entities with or without criteria or attributes.  
C. Flag 'rephrasing' if the <follow_up_question> contains the word 'outlook' or 'ratings' or 'rating action' or refers to outlook-related properties (e.g., positive/negative entities).  
D. Flag 'rephrasing' if the <follow_up_question> and <chat_history> together include both an entity and user intent (e.g., ratings, peers, financials).  
E. If the <follow_up_question> contains only phrases like '[entity name]?' or 'for [entity name]', check the <chat_history>:  
   - E.1. Flag 'rephrasing' if a <question> in the <chat_history> contains user intent.  
   - E.2. Flag 'clarifying' if no <question> in the <chat_history> contains user intent.  
F. Flag 'rephrasing' if the <follow_up_question> asks about the latest trends in an industry or decisions of an entity.  
G. Flag 'rephrasing' if the <follow_up_question> asks about rating actions for an entity type or about most/less recent actions.  
H. Flag 'rephrasing' if the <follow_up_question> contains both an entity and intent (e.g., "Tesla bankruptcy" -> Tesla as entity, bankruptcy as intent).  
I. Flag 'rephrasing' if the <follow_up_question> contains user intent (f.e., definition, criteria, etc) and asks about broad topics without specific entities.
J. Flag 'rephrasing' if the <follow_up_question> contains a few user intents and at least one entity. 
K. Flag 'clarifying' if the <follow_up_question> contains only user intent without any entity and there is no entity in <chat_history>.
L. Flag 'rephrasing' if the <follow_up_question> asks about shortening or extending the response that generated for the previous question in the <chat_history>.

Here are the current use cases and some explanation for each:

1. ratings: Ratings are letter grades given to companies by the S&P Global generally concerning the likelihood of default. We classify things as ratings when the question is asking for the rating of a company. Keywords are Credit Rating, Credit Rating History, Servicer Evaluations Ranking, historical ratings, past ratings assigned, current ratings, S&P Global Ratings, national scale ratings, and other sneakier ways of asking for ratings like asking for "outlook changes" over the years. This category will retrieve the information, if we are asking about the impact of a rating then we would be in the general category.
2. rating_action: Rating actions give information about why ratings change. We classify queries to rating actions when we are asking about rating actions, asking about latest actions, upgrades and downgrades to the outlook or rating of an entity, and rating rationale.
3. peers: Peers category retrieves a table of information regarding the S&P Global's view of an entity and its competitors. Within the financial domain, peers has a specific meaning, we generally classify as peers when we are asking about competitors and the word "peers" or "competitors" is in the user query. Other phrases we look out for are "analyst peers", "list of competitors", "list of peers", "top peers". Asking about something other than the retrieval of this information, for example impact, needs to go to "general".
4. outlook: The outlook category retrieves the S&P Globals opinion about what would need to happen in the future for a rating to upgrade or downgrade. Most of the time questions that ask about outlook need to be in this category.
5. research: The research category will pull a list of articles about the given user query. For example, Show me a research list on entity/topic, list of articles on Apple, reports on IBM, etc.
6. criteria: The criteria category will retrieve information related to guidelines/methodology about assigning ratings for different industries, sovereign entities, entities, etc. Additionally, these guidelines outline different risks entities might face such as business risk or financial risk. This can also include impact of being in a specific group key on the methodology. This also covers how various properties of an entity impact rating, like SACP (Stand Alone Credit Profile) on Credit Issuer Ratings.
Keyword heavy: Categories financials, scores and modifiers, definitions, info and coverage, are all retrieving information about specific keywords the user is requesting. Ensure that the appropriate keyword from this category is included in the user query.
7. scores&modifiers: Very keyword heavy, essentially if the user asks for a score : scores of an entity, but not if the user is asking how a score impacts a company, impact falls into general. Always check if the user is asking about a score
8. financials: Financials pulls financial data. When the user asks for a financial highlights, insights, trends, financial performance, financial spread, key ratio, profitability, cash flow trends, revenue, EBITDA ratio, interest ratio scores, debts and other financial metrics.
9. definitions: Definitions in this context does not refer to if the user is asking for a definition of any arbitrary term, but if the user is asking for the meaning of a term that is present in the S&P Global's definition page, these terms are listed as terminology, if the user is asking for the definition of a term not in terminology, classify as general, the definitions retrieval will fail otherwise.
10. ESG: Classification as esg will pull environmental, social, and governance information from the S&P Global database for entities. Essentially any question asking for the ESG profile, ESG factors, or environmental, social, and governance factors for an entity or multiple entities falls under ESG. If the user is specifically asking to compare the ESG factors of two entities it goes into esg not peers. If the user is asking for impact, classify as general.
11. info_coverage: The info coverage category covers the following attributes for a company's metadata, additionally as well as information about the people (analysts) covering the entity, such as their email, name, address, mobile number, and other personal info.
12. query: The query category covers generating various lists, for example, companies that are fallen angels in the last twelve months list of US public finance securities in industry in the region. Generally speaking, if a more specific category covers the user question such as financials, securities, scores and modifiers prefer that.
13. securities: The securities category covers requesting a list of securities, senior unsecured securities, securities with an associated maturity date, maturity based, debt based, and ratings of the securities of an entity.
14. SWOT: The sNw category retrieves information from the S&P Global database covering what the Strengths, Weaknesses, Opportunities, Threats of an entity. This category covers user queries about strengths and weaknesses. Can be asked in a few ways, SWOT analysis, Strengths, Weaknesses, Opportunities, Threats) analysis, strengths and weaknesses. Also covers comparisons between two entities.
15. deals_tranche: The deals tranche category retrieves information from the S&P Global database about deals, asset classes, and tranches. User queries that get classified as deals_tranche will generally be asking for details about deals, active deals, tranches, ratings of tranches, overview of historical tranches, ABS or MBS deals, etc.
16. credit_memo: The credit memo category will call an external service that will create a credit memo for an entity. This can be called a few specific things, "credit memo", "credit brief", "credit analysis", "credit research report", and/or credit report.
17. general: The general category acts a catchall for queries that don't need a specific tool. If we misclassify a query, the entire system may fail, therefore when we are uncertain about categories or a question does not fit cleanly into a different more specific category we should return "general"

Using the above use cases infer if the <follow_up_question> requires 'rephrasing' or 'clarification' based on the <chat_history> and the rules provided.
If the <follow_up_question> is ambiguous or incomplete based on the above rules, flag clarifying. Otherwise, flag rephrasing.

<critical> Do not ask a clarifying question when intent and entity are clear from <follow_up_question> and <chat_history>! </critical> 

<formatting>
{output_prompt_format}
</formatting>

<examples>
{examples}
</examples>

<chat_history>
{list_of_questions}
</chat_history>

<follow_up_question>{question}</follow_up_question>

Return only the valid JSON output without anything else.
Think step by step and return the JSON.
"""
