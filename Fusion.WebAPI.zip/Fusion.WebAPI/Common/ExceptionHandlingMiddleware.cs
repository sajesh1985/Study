﻿namespace Fis.Epp.Fusion.WebAPI.Common
{
    using Fis.Epp.Fusion.WebAPI;
    using Fis.Epp.Fusion.WebAPI.LoggerModels;
    using Fis.Epp.Fusion.WebAPI.Models;
    using Microsoft.AspNetCore.Http;
    using Newtonsoft.Json;
    using System;
    using System.Net;
    using System.Threading.Tasks;

    public class ExceptionHandlingMiddleware
    {
        private readonly RequestDelegate next;

        public ExceptionHandlingMiddleware(RequestDelegate next)
        {
            this.next = next;
        }

        public async Task Invoke(HttpContext context)
        {
            try
            {
                await next(context);
            }
            catch (Exception ex)
            {
                await HandleExceptionAsync(context, ex);
            }
        }

        private static Task HandleExceptionAsync(HttpContext context, Exception exception)
        {
            // log the exception
            var headers = context.Request.Headers;

            string brandId = string.Empty;
            string userId = string.Empty;
            string correlationId = string.Empty;

            if (!string.IsNullOrEmpty(headers[RequestHeader.Fe_Id.GetEnumDescription()]))
            {
                brandId = headers[RequestHeader.Fe_Id.GetEnumDescription()];
            }

            if (!string.IsNullOrEmpty(headers[RequestHeader.User_Id.GetEnumDescription()]))
            {
                userId = headers[RequestHeader.User_Id.GetEnumDescription()];
            }

            if (!string.IsNullOrEmpty(headers[RequestHeader.Correlation_Id.GetEnumDescription()]))
            {
                correlationId = headers[RequestHeader.Correlation_Id.GetEnumDescription()];
            }

            AppDiagnostics appDiagnostics = new AppDiagnostics(context);

            AppExceptionLoggerModel errorData = new AppExceptionLoggerModel
            {
                BrandId = brandId,
                UserId = userId,
                ErrorMessage = exception.Message,
                ErrorStack = exception.StackTrace,
                RequestUrl = context.Request.Path,
                CorrelationId = correlationId
            };

            appDiagnostics.RecordResourcesException(errorData);

            // Return error response
            context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
            context.Response.ContentType = "application/json";

            string errorCode = "GENF001"; // Returns custom error codes based on exception type            

            var result = JsonConvert.SerializeObject(new
            {
                type = "APPLICATION_ERROR",
                details = new[] {
                    new
                    {
                        code = errorCode,
                        message = exception.Message
                    }
                }
            });

            return context.Response.WriteAsync(result);
        }
    }
}
