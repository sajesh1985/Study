﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace Fis.Epp.Fusion.Auth.Models
{
    public enum JWTEnum
    {
        [Description("FeId")]
        FeId,
        [Description("sessionTimeout")]
        sessionTimeout,
        [Description("KeepAliveURL")]
        KeepAliveURL,
        [Description("correlationId")]
        correlationId,
        [Description("USER_ID")]
        USER_ID,
        [Description("FE_ID")]
        FE_ID,
        [Description("balanceList")]
        balanceList
    }
}
