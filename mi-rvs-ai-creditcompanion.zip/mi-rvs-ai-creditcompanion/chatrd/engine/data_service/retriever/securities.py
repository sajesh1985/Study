import logging
from typing import Optional

import pandas as pd

from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.data_service.retriever.base import BaseRetriever
from chatrd.engine.data_service.retriever.utils import _retrieve
from chatrd.engine.data_service.schema import Analyzer, ProcessorInput, Retriever
from chatrd.engine.data_service.utils import parse_csv_string

logger = logging.getLogger(__name__)

config_machinery = get_config_machinery()
DEBT_TYPE_CSV_DATA = config_machinery.get_config_value(Constants.DataService.DEBT_TYPE_CSV_DATA)
RATING_TYPE_CSV_DATA = config_machinery.get_config_value(Constants.DataService.RATING_TYPE_CSV_DATA)


class ListOfSecuritiesRetriever(BaseRetriever):
    def retrieve(
        self,
        processor: ProcessorInput = None,
        analyzer: Optional[Analyzer] = None,
        api_method: str = "POST",
        api_type: str = "ratings",
    ) -> Retriever:
        # Read Arguments
        entities = processor.entities

        if not entities or len(entities["companies"]) == 0:
            return Retriever()

        endpoint_path = Constants.RatingsAPI.RATINGS_API_ISSUANCES_ENDPOINT_PATH
        debt_type = rating_type = maturity_start = maturity_end = ""

        if analyzer:
            debt_type = analyzer.response["DebtType"]
            rating_type = analyzer.response["RoleType"]
            maturity_start = analyzer.response["MaturityStartDate"]
            maturity_end = analyzer.response["MaturityEndDate"]

        data = {
            "KeyInstn": str(entities["companies"][0]["mi_id"]),
            "DebtType": debt_type,
            "MaturityStartDate": maturity_start,
            "MaturityEndDate": maturity_end,
            "RoleType": rating_type,
        }
        return _retrieve(endpoint_path=endpoint_path, api_method="POST", data=data)
