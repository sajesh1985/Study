from pydantic import BaseModel, field_validator


class ClarifyingOutput(BaseModel):
    clarifying_question: str

    @field_validator("clarifying_question")
    def output_must_be_valid(cls, v):
        if not isinstance(v, str):
            raise ValueError("Response must be a string.")
        return v


CLARIFYING_OUTPUT_PROMPT_FORMAT = """Provide a JSON object with the following structure:
{
    "clarifying_question": str(<A clarifying question to get relevant information>)
}
"""

CLARIFYING_EXAMPLES = """<example>
{
    "chat_history": [
        {
            "question": "<entity1>?"
        },
        {
            "question": "<entity2>?"
        },
        {
            "question": "<entity3>?"
        }
    ],
    "follow_up_question": "<entity4>?",
    "output": {
        "clarifying_question": "Could you clarify what information you need about <entity4>?""
    }
}
</example>
<example>
{
    "chat_history": [
        {
            "question": "apple"
        },
    ],
    "follow_up_question": "tesla",
    "output": {
        "clarifying_question": "Could you clarify what information you need about Tesla?""
    }
}
</example>
<example>
{
    "chat_history": [
        {
            "question": "For Intel?"
        },
        {
            "question": "IBM?"
        }
    ],
    "follow_up_question": "tesla?",
    "output": {
        "clarifying_question": "Could you clarify what information you need about Tesla?""
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "What is outlook for?",
    "output": {
        "clarifying_question": "Could you specify which entity you are asking about the outlook for?"
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "SWOT?",
    "output": {
        "clarifying_question": "Could you specify which information you are asking about SWOT?"
    }
}
</example>
<example>
{
    "chat_history": [
        {
            "question": "name of competitors for Volkswagen"
        },
        {
            "question": "Compare strengths for Tesla, Volkswagen, Ford"
        }
    ],
    "follow_up_question": "Share some insights about the Diesel scandal",
    "output": {
        "clarifying_question": "Could you specify which entity you are asking about diesel scandal?"
    }
}
</example>
"""


CLARIFYING_PROMPT = """
You are a helpful assistant answering questions in the credit and financial domain. You have access to the user's chat history and their follow-up question.

<instructions>
If the <follow_up_question> is unclear or requires more information, provide a clarifying question to seek further details. Do not mention previous entities from the chat history. Do NOT answer; only clarify question. Do NOT modify or abbreviate any entity names (zyX Km AB univ, CD); they MUST appear verbatim in the output (zyX Km AB univ, CD). 

If follow_up_question question is a self-explanatory and independent standalone inquiry, rephrased_question MUST returned same as follow_up_question
</instructions>

<formatting>
{output_prompt_format}
</formatting>

<examples>
{examples}
</examples>

<chat_history>
{list_of_questions}
</chat_history>

<follow_up_question>{question}</follow_up_question>

Return only the valid JSON output without anything else. In the JSON you must ALWAYS return the key 'clarifying_question' with the value being the clarifying question you generated.
Take a deep breath and make the right decision.
"""
