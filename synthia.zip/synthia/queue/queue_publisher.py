import logging
from typing import Dict, Optional, List, Any
from functools import lru_cache

from src.synthia.queue.queue_backend import get_queue_backend

logger = logging.getLogger(__name__)

class ReportPublisher:
    """Publish messages to a single queue (local or SQS), using only fields your original code handled + user_sections."""

    def __init__(self):
        self.backend = get_queue_backend()

    @staticmethod
    def _env(action: str, payload: Dict) -> Dict:
        return {"action": action, "payload": payload}

    async def publish_generate_report(
            self,
            *,
            job_id: str,
            token: str,
            refresh_token: Optional[str],
            correlation_id: Optional[str] = None,
    ) -> str:
        try:
            payload = {
                "job_id": job_id,
                "token": token,
                "refresh_token": refresh_token,
                "correlation_id": correlation_id
            }
            body = self._env("generate_report", payload)
            mid = await self.backend.send_message(body)
            logger.info("[job_id=%s] Published generate_report id=%s", job_id, mid)
            return mid
        except Exception as e:
            logger.exception("[job_id=%s] Failed to publish generate_report: %s", job_id, str(e))
            raise

    async def publish_outline_approval(
        self,
        *,
        job_id: str,
        approved: bool,
        token: str,
        refresh_token: Optional[str] = None,
        revised_sections: Optional[int] = None,
        revised_depth: Optional[int] = None,
        user_sections: Optional[list] = None,
        correlation_id: Optional[str] = None,
    ) -> str:
        try:
            payload: Dict = {
                "job_id": job_id,
                "approved": bool(approved),
                "token": token,
                "refresh_token": refresh_token,
                "correlation_id": correlation_id,
            }
            if revised_sections is not None:
                payload["revised_sections"] = int(revised_sections)
            if revised_depth is not None:
                payload["revised_depth"] = int(revised_depth)
            if user_sections is not None:
                payload["user_sections"] = list(user_sections)  # <-- added

            body = self._env("process_outline_approval", payload)
            mid = await self.backend.send_message(body)
            logger.info("[job_id=%s] Published process_outline_approval id=%s approved=%s", job_id, mid, approved)
            return mid
        except Exception as e:
            logger.exception("[job_id=%s] Failed to publish process_outline_approval: %s", job_id, str(e))
            raise

    async def publish_section_edit_prompt(
        self,
        *,
        job_id: str,
        request: Dict[str, Any],
        token: str,
        correlation_id: Optional[str] = None,
    ) -> str:
        try:
            payload: Dict = {
                "job_id": job_id,
                "request": request,
                "token": token,
                "correlation_id": correlation_id,
            }

            body = self._env("process_section_edit_prompt", payload)
            mid = await self.backend.send_message(body)
            logger.info("[job_id=%s] Published process_section_edit_prompt id=%s", job_id, mid)
            return mid
        except Exception as e:
            logger.exception("[job_id=%s] Failed to publish process_section_edit_prompt: %s", job_id, str(e))
            raise

    async def publish_section_edit_approval(
        self,
        *,
        job_id: str,
        prompt_id: str,
        status: str,
        token: str,
        correlation_id: Optional[str] = None,
    ) -> str:
        try:
            payload: Dict = {
                "job_id": job_id,
                "prompt_id": prompt_id,
                "status": status,
                "token": token,
                "correlation_id": correlation_id,
            }

            body = self._env("process_section_edit_approval", payload)
            mid = await self.backend.send_message(body)
            logger.info("[job_id=%s] Published process_section_edit_approval id=%s prompt_id=%s status=%s", job_id, mid, prompt_id, status)
            return mid
        except Exception as e:
            logger.exception("[job_id=%s] Failed to publish process_section_edit_approval prompt_id=%s: %s", job_id, prompt_id, str(e))
            raise

@lru_cache(maxsize=1)
def get_publisher() -> ReportPublisher:
    return ReportPublisher()
