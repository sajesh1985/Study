import datetime
import enum
import json
import pathlib
import pydantic
import os
import asyncio
from mcp.server.fastmcp import FastMCP, Context
from fastapi import FastAPI, APIRouter
from fastapi import Request
from fastapi import Depends
from contextlib import asynccontextmanager
import httpx
import logging
import contextlib
from src.synthia.config.api_config import get_config
from . import auth
from src.synthia.utils.logging_config import configure_logging
from ..persistence.database_manager import close_connection_pool, get_postgres_conn_string, \
    initialize_main_connection_pool, get_connection_pool
from ..persistence.excel_queries import get_job_file_map_record, save_job_file_map_record
from ..utils.helper import get_presigned_url
from ..utils.source import Source

# Configure logging
logger = configure_logging(logger_name=__name__, log_file='excel_prod_data.log',)

logger.info("Excel Prop Data MCP Server starting up...")
mcp: FastMCP = FastMCP("Excel Prop Data MCP Server", stateless_http=True)

cfg = get_config()


router = APIRouter()


# Create a single AsyncClient instance for reuse (performance optimization for Lambda)
async_client: httpx.AsyncClient = None




def transform_excel_data_rowwise(data: dict) -> dict:
    """
    Transform the Excel data from columnar to row-wise format.
    Each column becomes a field, and each row becomes a record.
    """
    if not data:
        return {
            "excel_table_name": None,
            "table_json": [],
            "file_id": None,
            "s3_uri": None,
        }
    
    table_json = data.get("table_json", [])
    
    # Extract headers (first row of each column)
    headers = [col[0] for col in table_json]
    
    # Find the maximum number of rows across all columns
    max_rows = max(len(col) for col in table_json) if table_json else 0
    
    # Transform to row-wise format
    transformed_records = []
    
    # Start from index 1 to skip headers
    for row_idx in range(1, max_rows):
        record = {}
        for col_idx, header in enumerate(headers):
            if row_idx < len(table_json[col_idx]):
                record[header] = table_json[col_idx][row_idx]
            else:
                record[header] = None
        transformed_records.append(record)
    
    return {
        "excel_table_name": data.get("table_name"),
        "table_json": transformed_records,
        "file_id": data.get("file_id"),
        "s3_uri": data.get("s3_uri"),
        # "source": data.get("source"),
    }


@mcp.tool()
async def get_excel_prop_data(job_id: str, table_names: list[str]) -> list[dict]:
    """
    Retrieve relevant structured table data from user uploaded excel file or documents
    Args:
        job_id (str): The report job id
        table_names (list[str]): list of table names(one or more) to be retrieved from excel file
    Returns:
        list[dict]: A list of dictionaries, each containing:
            {
                "excel_table_name": <name of the table retrieved from excel file>,
                "table_json": <list of dictionary where each dictionary treated as one record in the table>,
                "file_id": <file id of the excel file>,
                "s3_uri": <url of the excel file>,
                "source": <a dictionary with title and url of the source excel file>,
                "error": <error message if table not found (optional)>
            }
    """
    logger.info(f"retrieving tables {table_names} for report {job_id}")

    if not table_names:
        logger.warning(f"No table names provided for job_id={job_id}")
        return []

    # Process all tables in parallel
    results = await asyncio.gather(
        *[fetch_table_data(job_id, table_name) for table_name in table_names],
        return_exceptions=True
    )
    
    processed_results = []
    for i, result in enumerate(results):
        if isinstance(result, Exception):
            logger.error(f"Unhandled exception for table '{table_names[i]}': {result}", exc_info=result)
            processed_results.append({
                "excel_table_name": table_names[i],
                "table_json": [],
                "file_id": None,
                "s3_uri": None,
                "source": Source(title="", url="#"),
                "error": f"Unhandled error: {str(result)}"
            })
        else:
            processed_results.append(result)
    
    return processed_results



async def fetch_table_data(job_id: str, table_name: str) -> dict:
    """Helper function to fetch data for a single table"""
    try:
        data = await get_job_file_map_record(job_id, table_name)

        if not data:
            logger.warning(f"No data found for job_id={job_id}, table_name={table_name}")
            return {
                "excel_table_name": table_name,
                "table_json": [],
                "file_id": None,
                "s3_uri": None,
                "source": Source(title="", url="#"),
                "error": f"No data found for table '{table_name}'"
            }

        source_title = data.get("s3_uri", "").split("/")[-1] if data.get("s3_uri") else ""
        # Consider using the presigned URL or remove this line entirely
        # source_url = get_presigned_url(data.get("s3_uri")) if data.get("s3_uri") else "#"
        return {
            **transform_excel_data_rowwise(data),
            "source": Source(title=source_title, url="#")
        }
    except Exception as e:
        logger.error(f"Error fetching data for table '{table_name}' in job_id={job_id}: {str(e)}", exc_info=True)
        return {
            "excel_table_name": table_name,
            "table_json": [],
            "file_id": None,
            "s3_uri": None,
            "source": Source(title="", url="#"),
            "error": f"Error retrieving table '{table_name}': {str(e)}"
        }


# Define a custom lifespan for FastAPI with a task to manage MCP
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Initialize MCP server task group
    logger.info("Initializing Excel prop data MCP server task group...")

    global async_client
    async_client = httpx.AsyncClient(timeout=10)
    stack = contextlib.AsyncExitStack()
    try:
        await stack.enter_async_context(mcp.session_manager.run())
        logger.info("Initializing connection pool...")
        conn_string = await get_postgres_conn_string()
        await initialize_main_connection_pool(conn_string)
        logger.info("Connection pool initialized successfully")
        yield
    except Exception as e:
        logger.error(f"Exception during startup: {e}")
        raise
    finally:
        logger.info("Gracefully terminating")
        await close_connection_pool()
        logger.info("Connection pool closed successfully")
    # Shutdown: Close the AsyncClient
        await async_client.aclose()
        await stack.aclose()
        logger.info("Gracefully terminated")


@router.get("/excel-prop-data/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "ok"}


class DebugTemplateType(enum.Enum):
    Corporate = 'corporate' # uses ImportTemplateBanks.xlsx from tests
    Bank = 'bank' # uses ImportTemplateCompanies.xlsx from tests

class DebugPopulateRequest(pydantic.BaseModel):
    TemplateType: DebugTemplateType
    JobId: str

@router.post('/debug/populate')
async def populate_prop_data_from_static_jsons(request: DebugPopulateRequest):
    """
    IMPORTANT NOTE: THIS WORKS ONLY ON DEV MACHINES
    Populate the prop data with tables for a given job id and the type of the template using the test expectations saved in tests.
    Hack until we have the full processing in place to unblock prompting.
    """
    base_path = pathlib.Path(__file__).parent.parent.parent.parent.joinpath('tests', 'excel_prop_data', 'extraction', 'expectations')

    logger.info(f"/debug/populate: using the following path to grab the mocked files: {base_path}")

    if request.TemplateType == DebugTemplateType.Corporate:
        extract_file_names = [
            'BalanceSheet.json',
            'BaseCaseCoFs.json',
            'BaseCaseSintesi.json',
            'CashFlowStatement.json',
            'FinancialHighlights.json',
            'FinancialStatementManual.json',
            'IncomeStatement.json'
        ]
    else:
        extract_file_names = [
            'BankDetailedFinancials.json',
            'BankDetailedPeerAnalysis.json',
            'BankFinancialHighlights.json',
            'BankPeerAnalysis.json',
            'BankRatiosAndOtherInfo.json'
        ]

    records = []
    for file_name in extract_file_names:
        sheet = json.load(open(base_path.joinpath(file_name)))[0]
        for table in sheet.get("tables", []):
            table_name = table.get("table_name")
            table_data = table.get("metrics")
            records.append({
                "jobid": request.JobId,
                "fileid": "any",
                "table_name": table_name,
                "table_json": json.dumps(table_data),
            })

    conn = get_connection_pool()

    # workaround for file table pointing to wrong job table - creating it ad hoc, remove this once not needed
    async with conn.connection() as aconn:
        sql = f"INSERT INTO product.jobs (jobid, userid, status, last_report_generated_datetime) VALUES (%(jobid)s, %(userid)s, %(status)s, %(generated)s)"
        params= {
            'jobid': request.JobId,
            'userid': '',
            'status': '',
            'generated': datetime.datetime.now()
        }
        await aconn.execute(sql, params)

    await save_job_file_map_record(conn, records)


app = FastAPI(lifespan=lifespan)
app.mount("/excel-prop-data", mcp.streamable_http_app())
app.include_router(router)
logger.info("Excel prop data MCP Server started successfully.")
