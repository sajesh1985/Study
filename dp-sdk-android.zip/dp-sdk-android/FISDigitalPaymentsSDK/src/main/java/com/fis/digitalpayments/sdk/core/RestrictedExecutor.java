// Copyright Notice!
// This document is protected under the trade secret and copyright
// laws as the property of Fidelity National Information Services, Inc.
// Copying, reproduction or distribution should be limited and only to
// employees with a “need to know” to do their job.
// Any disclosure of this document to third parties is strictly prohibited.
// © 2016 Fidelity National Information Services.
// All rights reserved worldwide.

package com.fis.digitalpayments.sdk.core;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.ResultReceiver;

/**
 * @author e1035413 on 12/28/2016.
 */

class RestrictedExecutor {
    static void executeWithPermission(String permissionId, final RestrictedOperation permissionedAction, Context context) {
        executeWithPermission(permissionId, permissionedAction, context, true);
    }

    static void executeWithPermission(String permissionId, final RestrictedOperation permissionedAction, Context context, boolean enableDisclosure) {
        Intent intent = new Intent(context, AcquirePermissionActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        intent.putExtra(AcquirePermissionActivity.REQUEST_PARAM_PERMISSION_ID, permissionId);
        intent.putExtra(AcquirePermissionActivity.REQUEST_PARAM_ENABLE_DISCLOSURE, enableDisclosure);

        intent.putExtra(AcquirePermissionActivity.PERMISSION_RESULT_RECEIVER_NAME, new ResultReceiver(new Handler()) {
            @Override
            protected void onReceiveResult(int resultCode, final Bundle resultData) {
                switch (resultCode) {
                    case AcquirePermissionActivity.RESULT_PERMISSION_GRANTED:
                        permissionedAction.onPermissionGranted();
                        break;
                    case AcquirePermissionActivity.RESULT_PERMISSION_DENIED:
                        permissionedAction.onPermissionDenied();
                        break;
                    case AcquirePermissionActivity.RESULT_PERMISSION_PERMANENTLY_DENIED:
                        permissionedAction.onPermissionPermanentlyDenied();
                    default:
                        // TODO: Send message back for error cases
                        break;
                }
            }
        });
        context.startActivity(intent);
    }
}
