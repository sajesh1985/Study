import operator
from typing import Annotated, List, Optional
from typing_extensions import TypedDict
from langgraph.graph import StateGraph
from langgraph.constants import START, END
from langgraph.types import Send
from typing import Literal
from langgraph.types import interrupt, Command
import logging
from src.synthia.schemas.workflow import ReportConfig, ReportSection
from src.synthia.schemas.sections import Section  # already imported
from src.synthia.utils.logging_config import configure_logging
from src.synthia.agents.report_builder import ReportBuilder
from src.synthia.persistence.database_manager import  get_checkpointer, get_store

logger = logging.getLogger(__name__)

# Initialize logger using centralized configuration
logger = configure_logging(
    log_file="synthia.log",
    module_levels={__name__: logging.DEBUG},  # Set this module to DEBUG
)


class OverallState(TypedDict):
    report_config: ReportConfig
    report_outline: List[Section]
    all_sections: Annotated[List[ReportSection], operator.add]
    final_report: List[ReportSection]

    # Human interaction state
    human_approved_outline: bool
    human_approved_report: bool
    human_feedback_report: Optional[str]

    # Workflow control
    job_id: str
    current_section_idx: Optional[int]  # Index of the current section being processed
    status: Optional[str]
    progress: Annotated[Optional[float], operator.add]  # Must be None in initial state!
    error: Optional[str]


class SectionState(TypedDict):
    report_config: ReportConfig
    section_title: str
    section_content: str
    sub_sections: List[Section]
    section_index: Optional[int]  # Index in the overall report
    progress: Annotated[Optional[float], operator.add]


async def create_report_graph(report_builder: ReportBuilder) -> StateGraph:
    """Create the main report generation graph."""

    async def create_outline(
        state: OverallState,
    ) -> Command[Literal["human_review_of_outline"]]:
        report_outline: List[Section] = await report_builder.generate_outline(
            state["report_config"]
        )
        num_sections = state["report_config"]["num_sections"]
        report_outline = report_outline[0:num_sections]

        return Command(
            update={"report_outline": report_outline, "progress": 0.1},
            goto="human_review_of_outline",
        )

    def human_review_of_outline(
        state: OverallState,
    ) -> Command[Literal["section_parallelizer", "create_outline"]]:
        """Wait for human approval of the outline."""
        outline_for_review: List[Section] = state["report_outline"]
        state["status"] = "awaiting_approval"

        # Create the interrupt with the outline data
        is_approved = interrupt(
            {
                "question": "Please approve the outline.",
                "report_outline": outline_for_review,
                "status": "awaiting_approval",
            }
        )

        # Return based on approval
        if is_approved or state.get("human_approved_outline"):
            return Command(update={"progress": 0.2}, goto="section_parallelizer")
        else:
            return Command(goto="create_outline")

    def section_parallelizer(state: OverallState) -> Command[Literal["section_writer"]]:
        """Parallelize section generation."""
        sends = []
        for i, section in enumerate(state["report_outline"]):
            # Section is a Pydantic model, use attribute access
            if isinstance(section, Section) and hasattr(section, "name"):
                sends.append(
                    Send(
                        "section_writer",
                        {
                            "report_config": state["report_config"],
                            "section_title": section.name,
                            "section_content": section.description,
                            "section_index": i + 1,
                        },
                    )
                )
        return Command(update={"progress": 0.3}, goto=sends)

    async def section_writer(
        state: SectionState,
    ) -> Command[Literal["synthesizer"]]:
        try:
            outline_section = {
                "name": state["section_title"],
                "description": state["section_content"],
                "section_index": state["section_index"],
            }

            section_result: ReportSection = (
                await report_builder.generate_section_content(
                    config=state["report_config"],
                    section=outline_section,
                )
            )
            return Command(
                update={"all_sections": [section_result], "progress": 0.5},
                goto="synthesizer",
            )
        except Exception as e:
            logger.error(f"Error processing section {state['section_title']}: {e}")
            state["error"] = (state.get("error") or "") + str(e)
            section_result: ReportSection = {
                "name": state["section_title"],
                "description": f"Error processing section: {state['section_title']}",
            }
            return Command(
                update={"all_sections": [section_result], "progress": 0.5},
                goto="synthesizer",
            )

    async def synthesizer(
        state: OverallState,
    ) -> Command[Literal[END]]:
        """Finalize the report using the report agent wrapper function."""

        try:

            finalized_sections = await report_builder.finalize_report(
                sections=state["all_sections"],
                report_template=state["report_config"].get("style", ""),
            )

            return Command(
                update={
                    "final_report": finalized_sections,
                    # "all_sections": finalized_sections,
                    "status": "completed",
                    "progress": 1.0,
                },
                goto=END,
            )
        except Exception as e:
            logger.error(f"Error finalizing report: {e}")
            state["error"] = str(e)
            state["status"] = "failed"
            return Command(goto=END)

    # def human_review_of_final_report(
    #     state: OverallState,
    # ) -> Command[Literal[END, "section_parallelizer"]]:  # type: ignore
    #     """Wait for human approval of the final report."""
    #     state["status"] = "awaiting_final_approval"

    #     is_approved = True

    #     # is_approved = interrupt(
    #     #     {
    #     #         "question": "Please approve the final report.",
    #     #         "final_report": state["final_report"],
    #     #         "status": "awaiting_final_approval",
    #     #     }
    #     # )

    #     if is_approved or state.get("human_approved_report"):
    #         return Command(update={"progress": 1.0}, goto=END)
    #     else:
    #         return Command(goto="section_parallelizer")

    builder = StateGraph(OverallState)
    # Add nodes with dependency injection
    builder.add_node("create_outline", create_outline)
    builder.add_node("human_review_of_outline", human_review_of_outline)

    builder.add_node("section_parallelizer", section_parallelizer)
    builder.add_node("section_writer", section_writer)
    builder.add_node("synthesizer", synthesizer)
    #builder.add_node("human_review_of_final_report", human_review_of_final_report)

    # Add edges
    builder.add_edge(START, "create_outline")
    # builder.add_edge("section_parallelizer", "synthesizer")

    #conn = await AsyncConnection.connect(postgres_connection_string, **connection_kwargs)

    # storage = StorageProvider()
    # await storage.initialize()

    checkpointer = get_checkpointer()
    store = get_store()

    graph = builder.compile(
        checkpointer=checkpointer,
        store=store,
        debug=False,
        name="report_workflow",
    )

    return graph
