import asyncio
import contextvars
from concurrent.futures import Executor, ThreadPoolExecutor
from typing import Callable, Optional, ParamSpec, TypeVar

# Shared thread pool
SHARED_THREAD_POOL = ThreadPoolExecutor(max_workers=16)

# ContextVar to detect if we're already inside the pool
_is_in_pool = contextvars.ContextVar("_is_in_pool", default=False)


def submit_to_shared_thread_pool(fn, *args, **kwargs):
    if _is_in_pool.get():
        # We're already inside a thread → run directly or submit without copying context
        return SHARED_THREAD_POOL.submit(fn, *args, **kwargs)

    ctx = contextvars.copy_context()

    def wrapped():
        _is_in_pool.set(True)
        return ctx.run(fn, *args, **kwargs)

    return SHARED_THREAD_POOL.submit(wrapped)


P = ParamSpec("P")
T = TypeVar("T")


async def run_in_executor(
    executor: Optional[Executor],
    func: Callable[P, T],
    *args: P.args,
    **kwargs: P.kwargs,
) -> T:
    """Run a function in an executor.
    Raises RuntimeError if the function raises a StopIteration.
    """

    def wrapper() -> T:
        try:
            return func(*args, **kwargs)
        except StopIteration as exc:
            # StopIteration can't be set on an asyncio.Future, it raises a TypeError
            # and leaves the Future pending forever. So convert it to a RuntimeError.
            raise RuntimeError from exc

    return await asyncio.get_running_loop().run_in_executor(executor, wrapper)
