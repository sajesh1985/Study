import logging
from concurrent.futures._base import Future
from datetime import date
from types import SimpleNamespace
from typing import List, Optional, Tuple, Union

import numpy as np
from dateutil.relativedelta import relativedelta

from chatrd.core.aws_utils.bedrock import get_assumed_bedrock_llm_client
from chatrd.core.retriever_utils.fuzzy_search import fuzzy_substring_match
from chatrd.core.thread_utils import submit_to_shared_thread_pool
from chatrd.engine.components.query_analyzer.conversational import (
    ConversationalPrompter,
)
from chatrd.engine.components.query_analyzer.conversational.prompts import (
    RephrasingOutput,
)
from chatrd.engine.components.query_analyzer.entity_extractor import EntityExtractor
from chatrd.engine.components.query_analyzer.entity_extractor.utils import Entities
from chatrd.engine.components.query_analyzer.filter_retrievers.base import FiltersInput
from chatrd.engine.components.query_analyzer.filter_retrievers.prompts import (
    TIME_THRESHOLD_PROMPT_DATE_OUTPUT_UNSTRUCTURED,
    empty_instructions_string,
    output_parser_time_threshold_dates,
    time_threshold_date_additional_examples_string,
)
from chatrd.engine.components.query_analyzer.filter_retrievers.time_threshold import (
    TimeThresholdFilter,
)
from chatrd.engine.components.query_analyzer.geography_extractor import (
    GeographyExtractor,
)
from chatrd.engine.components.query_analyzer.guardrail.input_moderation_guardrail import (
    InputModerationGuardrail,
)
from chatrd.engine.components.query_analyzer.guardrail.responses import (
    get_blocked_topic_message,
)
from chatrd.engine.components.query_analyzer.sector_extractor import SectorExtractor
from chatrd.engine.components.query_analyzer.sector_extractor.utils import (
    CriteriaSectorExtractedFields,
    ResearchSectorExtractedFields,
)
from chatrd.engine.components.query_analyzer.suggested_entity_rephrase.prompter import (
    SuggestedEntityRephrasePrompter,
)
from chatrd.engine.components.query_analyzer.suggested_entity_rephrase.utils import (
    SuggestedEntities,
    SuggestedEntity,
)
from chatrd.engine.components.query_analyzer.time_rephraser import QuestionRephraser
from chatrd.engine.components.query_analyzer.translator.translator import (
    InputModerationTranslator,
)
from chatrd.engine.components.query_analyzer.translator.utils import (
    Get_translation_result,
)
from chatrd.engine.components.query_analyzer.uc_router import EndpointRouter
from chatrd.engine.components.query_analyzer.uc_router.router import (
    MultiTopicEndpointRouter,
)
from chatrd.engine.components.query_analyzer.uc_subrouting import (
    OutlookSubrouter,
    RatingActionSubrouter,
    ScoresModifiersSubrouter,
    add_company_name_to_prompt,
)
from chatrd.engine.components.query_analyzer.uc_subrouting.prompt_templates import (
    OutlookSubroutingValues,
)
from chatrd.engine.components.query_analyzer.utils import TaggedEntity
from chatrd.engine.components.schema import (
    ComponentsOutput,
    EntityType,
    QueryAnalyzerInput,
    QueryAnalyzerOutput,
)
from chatrd.engine.components.state_machine import StateMachine
from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.responses import get_default_answer
from chatrd.engine.utils import ChatResponse

logger = logging.getLogger(__name__)

config_machinery = get_config_machinery()


class QueryAnalyzer(StateMachine):
    def __init__(self, embeddings_uc_type_path: str, uc_embedding_model: str):
        super().__init__(
            machine_role="QueryAnaylzer",
            failure_response="Query Analyzer Failed.",
            success_response="Query Analyzer Passed.",
        )
        self.uc_embedding_model = uc_embedding_model
        # self.embeddings = np.load(embeddings_uc_type_path, allow_pickle=True)
        self.uc_router = MultiTopicEndpointRouter(model_name="endpoint_embedder")
        self.bedrock_client = get_assumed_bedrock_llm_client(
            role_arn=config_machinery.get_config_value(Constants.Bedrock.BEDROCK_ROLE_ARN),
            region_name=config_machinery.get_config_value(Constants.Bedrock.BEDROCK_REGION_NAME),
        )["bedrock-runtime"]

    def _execute_internal(
        self, inputs: QueryAnalyzerInput, tagged_routes: List[str]
    ) -> ComponentsOutput(QueryAnalyzerOutput):
        logger.info(f"Query Analyzer started analyzing for query: {inputs.message}")
        translator = InputModerationTranslator()
        guardrail = InputModerationGuardrail()
        logger.info(f"Guardrail check with model: {guardrail.model.model_id}")
        message_translation = submit_to_shared_thread_pool(translator.run, query=inputs.message)
        message_translation = message_translation.result()

        original_message = inputs.message
        original_language = message_translation["language"]
        if original_language.lower() != "english":
            inputs.message = message_translation["translated_text"]

        future_guardrail_output = submit_to_shared_thread_pool(guardrail.run, user_input=inputs.message)

        future_run_analyzer_output = submit_to_shared_thread_pool(
            self.run_analyzer,
            inputs=inputs,
            original_language=original_language,
            original_message=original_message,
            tagged_routes=tagged_routes,
        )

        guardrail_output = future_guardrail_output.result()
        btm = get_blocked_topic_message(
            inputs.message, guardrail, guardrail_output, translator, original_language, original_message
        )
        if btm is not None:
            return btm

        run_analyzer_output = future_run_analyzer_output.result()
        return run_analyzer_output

    def process_subqueries(
        self,
        rephrasing_output: RephrasingOutput,
        inputs: QueryAnalyzerInput,
        original_language: str,
        original_message: str,
        tagged_routes=[],
    ) -> QueryAnalyzerOutput:
        """
        Processes subqueries and constructs mutli topic query analyzer output.
        ### Args:
            - rephrasing_output (RephrasingOutput): Output from the Conversational Prompter
            - inputs (QueryAnalyzerInput): Input parameters for the query analyzer, used for getting information for running entity extractor.
        ### Returns:
            - QueryAnalyzerOutput : A QueryAnalyzerOutput object containing the results of the analysis.
        """

        resolve_futures = lambda y: list(map(lambda x: x.result(), y))

        # Hardcoded for now need to add to QueryAnalyzerInput
        run_entity_extractor_individually = False
        run_geography_extractor_individually = True

        # Initial Routing and Sectors Futures
        subqueries, initial_routes, sectors_future = self.process_subqueries_sectors(
            rephrasing_output, inputs, tagged_routes=tagged_routes
        )

        # Subquery Entity Futures Extraction and Suggestions Futures
        superquery_entities, subquery_entities_potential_futures = self.subquery_entity_extraction(
            rephrasing_output, inputs, run_individually=run_entity_extractor_individually
        )
        entity_extractor_result, entity_suggestions, raw_entities = superquery_entities
        suggestions_future = submit_to_shared_thread_pool(
            self.get_suggestions, entity_suggestions, raw_entities, inputs
        )

        is_rd_entity, entity_name = self.check_rd_entity(entities=entity_extractor_result, tagged_routes=tagged_routes)

        if not is_rd_entity:
            logger.error(f"MultiQueryAnalyzer: no RD entity detected for {entity_extractor_result}")
            try:
                return get_default_answer(
                    entity_name=entity_name,
                    reason="get_default_answer_for_non_rd_entity",
                    suggested_entities=suggestions_future.result(),
                    original_language=original_language,
                )
            except Exception as e:
                logger.error(f"Error in getting default answer for non RD entity: {e}")
                return get_default_answer(
                    entity_name=entity_name,
                    reason="get_default_answer_for_non_rd_entity",
                    suggested_entities=[],
                    original_language=original_language,
                )

        # Outlook Subrouter futures
        outlook_subrouting_futures: List[Future] = [
            submit_to_shared_thread_pool(
                self.run_sub_router, uc_type=uc_type, inputs=inputs, rephrased_question=subquery
            )
            for (uc_type, subquery) in zip(initial_routes, subqueries)
        ]

        # Evaluate subquery entities
        subquery_entities: Optional[List[Entities]] = None
        if run_entity_extractor_individually:
            subqueries, subquery_entities = zip(*list(map(lambda x: x.result(), subquery_entities_potential_futures)))
        else:
            subqueries, subquery_entities = zip(*subquery_entities_potential_futures)

        subquery_geographies_potential_futures = self.subquery_geography_extraction(
            rephrasing_output, inputs, run_individually=run_geography_extractor_individually
        )
        if run_geography_extractor_individually:
            logger.info("Geography extractor started")
            subqueries, subquery_geographies = zip(
                *[(subquery, future.result()) for subquery, future in subquery_geographies_potential_futures]
            )
            logger.info("Geography extractor ended")
        else:
            raise ValueError("Not implemented")

        is_geo_or_region_initial_question = False
        if True in subquery_geographies:
            is_geo_or_region_initial_question = True

        final_route_futures = [
            submit_to_shared_thread_pool(
                self.process_subquery_subrouting,
                initial_route,
                subquery_entity,
                inputs,
                SimpleNamespace(rephrased_question=subquery, rephrased_initial_question=subquery),
            )
            for (initial_route, subquery_entity, subquery) in zip(initial_routes, subquery_entities, subqueries)
        ]

        # Evaluate remaining futures
        outlook_subrouting = resolve_futures(outlook_subrouting_futures)
        final_routes, entity_types = zip(*resolve_futures(final_route_futures))
        sectors: List[str] = resolve_futures(sectors_future)

        if "query" in final_routes:
            logger.info(
                "'query' uc_type found in subqueries, returning single query uc_type output with original user question"
            )
            outputs = QueryAnalyzerOutput(
                query=inputs.message,
                original_language=original_language,
                original_query=original_message,
                uc_type="query",
                rephrased_query=rephrasing_output.initial_question,
                guidelines="",
                entities=Entities(),
                suggested_entities=None,
                sectors=None,
                entity_type=None,
                is_geo_or_region=is_geo_or_region_initial_question,
                tagged_routes=tagged_routes,
            )
            return outputs

        total_entities = len(
            entity_extractor_result.companies
            + entity_extractor_result.revenue_sources
            + entity_extractor_result.securities
        )
        if set(final_routes) == {"ratings", "outlook"} and total_entities == 1:
            logger.info(
                "'ratings' and 'outlook' uc_types found in subqueries, returning single ratings uc_type output with rephrased initial user question"
            )
            suggestions = suggestions_future.result()
            if suggestions:
                suggestions.query_entity_is_rd = is_rd_entity
            ratings_query_analyzer = QueryAnalyzerOutput(
                query=inputs.message,
                original_language=original_language,
                original_query=original_message,
                uc_type="ratings",
                rephrased_query=rephrasing_output.rephrased_initial_question,
                guidelines="",
                entities=entity_extractor_result,
                entity_type=entity_types[0],
                suggested_entities=suggestions,
                list_of_tagged_entities=inputs.list_of_tagged_entities,
                is_geo_or_region=is_geo_or_region_initial_question,
                tagged_routes=tagged_routes,
            )
            logger.info("Super Query Analyzer Output: " + str(ratings_query_analyzer))
            return ratings_query_analyzer

        qa_output_list_futures = [
            submit_to_shared_thread_pool(
                self.assemble_analyzer_outputs,
                conversational_prompter_output=SimpleNamespace(
                    rephrased_question=subquery, rephrased_initial_question=subquery
                ),
                entity_extractor_result=subquery_entity,
                inputs=inputs,
                uc_type=final_route,
                sector_extractor_result=sector,
                subrouting_result=outlook_subrouting_result,
                entity_suggestions_result=None,
                entity_type=entity_type,
                original_language=original_language,
                original_query=original_message,
                is_geo_or_region=is_geo_or_region,
                tagged_routes=tagged_routes,
            )
            for (
                final_route,
                subquery_entity,
                subquery,
                sector,
                outlook_subrouting_result,
                entity_type,
                is_geo_or_region,
            ) in zip(
                final_routes,
                subquery_entities,
                subqueries,
                sectors,
                outlook_subrouting,
                entity_types,
                subquery_geographies,
            )
        ]

        subquery_analyzer_outputs: List[QueryAnalyzerOutput] = resolve_futures(qa_output_list_futures)
        assert isinstance(
            subquery_analyzer_outputs, list
        ), f"Expected subquery_analyzer_outputs to be a list of QueryAnalyzerOutputs, actual type is {type(subquery_analyzer_outputs)}"
        suggestions = suggestions_future.result()
        if suggestions:
            suggestions.query_entity_is_rd = is_rd_entity
        super_query_analyzer_output = QueryAnalyzerOutput(
            query=inputs.message,
            uc_type="multi",
            rephrased_query=rephrasing_output.rephrased_initial_question,
            entities=entity_extractor_result,
            suggested_entities=suggestions,
            list_of_tagged_entities=inputs.list_of_tagged_entities,
            subquery_analyzer_outputs=subquery_analyzer_outputs,
            multi_uc_type=True,
            original_language=original_language,
            original_query=original_message,
            tagged_routes=tagged_routes,
        )
        logger.info("Super Query Analyzer Output: " + str(super_query_analyzer_output))
        return super_query_analyzer_output

    def process_subquery_subrouting(
        self,
        uc_type: str,
        entity_extractor_result: Union[Entities, SimpleNamespace],
        inputs: QueryAnalyzerInput,
        conversational_prompter_output: Union[SimpleNamespace, RephrasingOutput],
    ) -> Tuple[str, EntityType]:
        """
        Runs logical and entity subrouting for a subquery.
        ### Args:
            - uc_type (str): Use case type for the subquery.
            - entity_extractor_result (Entities): Entities extracted from the subquery.
            - inputs (QueryAnalyzerInput): Input parameters for the query analyzer, used for getting information for running rephrase with entity prompter.
            - conversational_prompter_output (SimpleNamespace or RephrasingOutput): Output from the Conversational Prompter or SimpleNamespace that mimics ConversationalPrompter output with the subquery.
        ### Returns:
            - str: The final use case type after subrouting.
            - EntityType: The type of entity mentioned in the subquery.
        """
        if uc_type == "scores&modifiers":
            try:
                COMPANY_NAMES = ", ".join([company.extracted_name for company in entity_extractor_result.companies])
                subrouter = ScoresModifiersSubrouter(model_name=inputs.llm, temperature=inputs.temperature)
                assert isinstance(conversational_prompter_output.rephrased_initial_question, str)
                new_uc_type = subrouter.run(
                    query=conversational_prompter_output.rephrased_initial_question,
                    # query=inputs.message,
                    entities_input=add_company_name_to_prompt(COMPANY_NAMES),
                )
                assert isinstance(new_uc_type, str)
                uc_type = new_uc_type
                if uc_type != "scores&modifiers":
                    logger.info(f"Subrouting for scores&modifiers: changing uc_type from scores&modifiers to {uc_type}")
                else:
                    logger.info("Subrouting for scores&modifiers: uc_type remains unchanged")
            except Exception as e:
                logger.error(f"Query Analyzer error in subrouting scores&modifiers query: {e}")
                uc_type = "scores&modifiers"

        # subrouting for rating actions, questions with no specific company mentioned
        if uc_type == "rating_action":
            if entity_extractor_result.securities or entity_extractor_result.revenue_sources:
                # a specific security or revenue source exists, remains in rating_action
                logger.info(f"Subrouting for rating_action: uc_type remains {uc_type}")
            elif not entity_extractor_result.companies:
                # no subject, general use case
                uc_type = "query"
                logger.info(f"Subrouting for rating_action: changing uc_type from rating_action to {uc_type}")
            else:
                # question subject may exist
                COMPANY_NAMES = ", ".join([company.extracted_name for company in entity_extractor_result.companies])
                subrouter = RatingActionSubrouter(model_name=inputs.llm, temperature=inputs.temperature)
                entity_subject_bool = subrouter.run(
                    query=conversational_prompter_output.rephrased_initial_question, entities=COMPANY_NAMES
                )
                if entity_subject_bool:
                    # user asked about rating action of a certain entity
                    logger.info(f"Subrouting for rating_action: uc_type remains {uc_type}")
                else:
                    # no subject, entity entity appears as a data filter ("show me all Japanese companies")
                    uc_type = "query"
                    logger.info(f"Subrouting for rating_action: changing uc_type from rating_action to {uc_type}")
        entity_type = self.get_entity_mentioned_type(entities=entity_extractor_result)

        if entity_type is EntityType.STRUCTURED_FINANCE:
            logger.info(f"changing uc_type from {uc_type} to deals_tranche")
            uc_type = "deals_tranche"
        if entity_extractor_result.securities:
            logger.info(f"changing uc_type from {uc_type} to ratings")
            uc_type = "ratings"

        if uc_type == "others":
            logger.error("No use case supported for others type.")
            raise Exception()
        return uc_type, entity_type

    def get_suggestions(
        self, entity_suggestions: Entities, raw_entities: Entities, inputs: QueryAnalyzerInput
    ) -> Optional[SuggestedEntities]:
        """
        Extracts entity suggestions and inits a SuggestedEntities object.

        ### Args:
            - entity_suggestions (Entities): Entities extracted from the query.
            - raw_entities (Entities): Raw entities extracted from the query.
            - inputs (QueryAnalyzerInput): Input parameters for the query analyzer, used for getting information for running rephrase with entity prompter.
        ### Returns:
            - Optional[SuggestedEntities]: A SuggestedEntities object containing the suggested entities or None.
        """
        entity_name_suggestions, entity_id_suggestions = [], []
        if entity_suggestions:
            for item in entity_suggestions:
                entity_name_suggestions.append(self.extract_name_from_entity(item))
                entity_id_suggestions.append(self.extract_id_from_entity(item))

        entity_suggestions_result = None
        if entity_name_suggestions and entity_id_suggestions and raw_entities:
            rephrase_with_entity_prompter = SuggestedEntityRephrasePrompter(
                model_name=inputs.llm, temperature=inputs.temperature
            )
            query_rephrase_result = rephrase_with_entity_prompter.run(
                query=inputs.message, extracted_entity=raw_entities[0], suggested_entities=entity_name_suggestions
            )
            try:
                entity_suggestions_result = SuggestedEntities(
                    entities=[
                        SuggestedEntity(
                            id=entity_id_suggestions[i],
                            name=entity_name_suggestions[i],
                            query=query_rephrase_result.rephrased_questions[i],
                        )
                        for i in range(len(entity_id_suggestions))
                    ]
                )
            except Exception as e:
                logger.error(f"Query Analyzer error in rephrasing query with entity: {e}")
                entity_suggestions_result = None
        return entity_suggestions_result

    sector_type = List[Union[CriteriaSectorExtractedFields, ResearchSectorExtractedFields]]

    def process_subqueries_sectors(
        self, rephrasing_output: RephrasingOutput, inputs: QueryAnalyzerInput, tagged_routes=[]
    ) -> Tuple[List[str], List[str], List[Future]]:
        """
        Processes subqueries and extracts sectors.

        ### Args:
            - rephrasing_output (RephrasingOutput): Output from the Conversational Prompter
            - inputs (QueryAnalyzerInput): Input parameters for the query analyzer, used for getting information for running sector extractor.
        ### Returns:
            - List[str]: List of subqueries extracted from the rephrasing output.
            - List[str]: List of use case types for each subquery.
            - List[Future]: List of Future objects for sector extraction results.
        """
        assert isinstance(rephrasing_output.subqueries, list)
        subqueries: List[str] = rephrasing_output.subqueries
        if tagged_routes:
            # for now tagged_routes works only for one tagged_routes, this can be changed later
            uc_type_to_tagged_routes, _ = self.uc_router.get_routing(query=inputs.message, tagged_routes=tagged_routes)
            uc_types = uc_type_to_tagged_routes * len(subqueries)
        else:
            uc_types: List[str] = self.uc_router.run(query=subqueries, tagged_routes=tagged_routes)
        supported_queries = dict(zip(subqueries, uc_types))
        subqueries = list(supported_queries.keys())
        uc_types = list(supported_queries.values())
        sector_extractor = SectorExtractor(model_name=inputs.llm, temperature=inputs.temperature)
        future_sectors = [
            submit_to_shared_thread_pool(
                sector_extractor.run, query=rephrasing_output.rephrased_initial_question, uc_type=uc_type
            )
            for (subquery, uc_type) in zip(subqueries, uc_types)
        ]
        # sectors : List[Union[CriteriaSectorExtractedFields, ResearchSectorExtractedFields]] = [future_sector.result() for future_sector in future_sectors]
        return subqueries, uc_types, future_sectors

    def subquery_entity_extraction(
        self, rephrasing_output: RephrasingOutput, inputs: QueryAnalyzerInput, run_individually=False
    ) -> Tuple[Tuple[Entities, Entities, Entities], List[Tuple[str, Union[Future, Entities]]]]:
        """
        Extracts Entities from RephrasingOutput Subqueries and initial question.

        ### Args:
            - rephrasing_output (RephrasingOutput): Output from the Conversational Prompter
            - inputs (QueryAnalyzerInput): Input parameters for the query analyzer, used for getting information for running entity extractor.
            - run_individually (bool): If True, runs entity extractor for each subquery individually, otherwise runs it for the initial question and aggregates results.
        ### Returns:
            - Tuple[Entities, Entities, Entities]: A tuple containing:
                - Entities extracted from the initial question.
                - Suggested Entities based on the initial question.
                - Raw Entities extracted from the initial question.
            - List[Tuple[str, Union[Future, Entities]]]: A list of tuples containing:
                - Subquery string.
                - Either a Future object for the subquery entity extraction or the extracted Entities directly if run_individually is False.
        """
        entity_extractor = EntityExtractor(
            model_name=inputs.llm_for_entity_extractor, temperature=inputs.temperature_for_entity_extractor
        )
        future_entity = submit_to_shared_thread_pool(
            entity_extractor.run,
            query=rephrasing_output.rephrased_initial_question,
            list_of_tagged_entities=inputs.list_of_tagged_entities,
        )
        assert isinstance(rephrasing_output.subqueries, list)
        subqueries: List[str] = rephrasing_output.subqueries
        if run_individually:
            extract_entities = lambda query, list_of_tagged_entities: entity_extractor.run(
                query=query, list_of_tagged_entities=list_of_tagged_entities
            )[0]
            future_entities = [
                submit_to_shared_thread_pool(
                    extract_entities,
                    query=subquery,
                    list_of_tagged_entities=inputs.list_of_tagged_entities,
                )
                for subquery in subqueries
            ]
            subquery_entities: List[Tuple[str, Union[Entities, Future]]] = [
                (subquery, future_entity) for (subquery, future_entity) in zip(subqueries, future_entities)
            ]
            initial_rephrased_entity_result: Tuple[Entities, Entities, Entities] = future_entity.result()
            return initial_rephrased_entity_result, subquery_entities

        else:
            initial_rephrased_entity_result: Tuple[Entities, Entities, Entities] = future_entity.result()
            top_match_entities: Entities = initial_rephrased_entity_result[0]
            categories = ["companies", "securities", "revenue_sources"]
            name_obj_category = [
                (entity.extracted_name, entity, category)
                for category in categories
                for entity in getattr(top_match_entities, category)
            ]
            entities_flattened = {
                subquery: [
                    (category, entity_obj)
                    for (name, entity_obj, category) in name_obj_category
                    if fuzzy_substring_match(subquery, name)
                ]
                for subquery in subqueries
            }
            subquery_entities: List[Tuple[str, Union[Entities, Future]]] = []
            for subquery in subqueries:
                subquery_entity = Entities()
                subquery_entities_flattened = entities_flattened[subquery]
                for category, entity_obj in subquery_entities_flattened:
                    getattr(subquery_entity, category).append(entity_obj)
                subquery_entities.append((subquery, subquery_entity))
            return initial_rephrased_entity_result, subquery_entities

    def subquery_geography_extraction(
        self, rephrasing_output: RephrasingOutput, inputs: QueryAnalyzerInput, run_individually=False
    ) -> List[Tuple[str, Future]]:
        geography_extractor = GeographyExtractor(
            model_name=inputs.llm_for_entity_extractor, temperature=inputs.temperature_for_entity_extractor
        )
        assert isinstance(rephrasing_output.subqueries, list)
        subqueries: List[str] = rephrasing_output.subqueries
        if run_individually:
            extract_geographies = lambda query: geography_extractor.run(
                query=query,
            )
            future_geographies = [
                submit_to_shared_thread_pool(extract_geographies, query=subquery) for subquery in subqueries
            ]
            subquery_geographies: List[Tuple[str, Future]] = [
                (subquery, future_geography) for (subquery, future_geography) in zip(subqueries, future_geographies)
            ]
            return subquery_geographies

        else:
            raise ValueError("Not implemented")

    def assemble_analyzer_outputs(
        self,
        conversational_prompter_output: Union[SimpleNamespace, RephrasingOutput],
        entity_extractor_result: Entities,
        inputs: QueryAnalyzerInput,
        uc_type: str,
        sector_extractor_result: Union[CriteriaSectorExtractedFields, ResearchSectorExtractedFields],
        subrouting_result: str,
        entity_suggestions_result: Optional[Tuple[Entities]],
        entity_type: EntityType,
        original_language: str,
        original_query: str,
        is_geo_or_region: bool,
        tagged_routes: List[str],
    ) -> QueryAnalyzerOutput:
        """
        Assembles the final QueryAnalyzerOutput based on the provided parameters.
        ### Args:
            - conversational_prompter_output (SimpleNamespace or RephrasingOutput): Output from the Conversational Prompter or SimpleNamespace that mimics ConversationalPrompter output.
            - entity_extractor_result (Entities): Entities extracted from the subquery.
            - inputs (QueryAnalyzerInput): Input parameters for the query analyzer, used for getting information for running rephrase with entity prompter.
            - uc_type (str): Use case type for the subquery.
            - sector_extractor_result (Union[CriteriaSectorExtractedFields, ResearchSectorExtractedFields]): Extracted sectors from the subquery.
            - subrouting_result (str): Result of the subrouting process.
            - entity_suggestions_result (Optional[Tuple[Entities]]): Suggested entities based on the subquery.
            - entity_type (EntityType): The type of entity mentioned in the subquery.
        ### Returns:
            - QueryAnalyzerOutput (QueryAnalyzerOutput): A QueryAnalyzerOutput object containing the results of the analysis.
        """
        extracted_dates = None
        if uc_type == "query":
            outputs = QueryAnalyzerOutput(
                query=inputs.message,
                uc_type=uc_type,
                multi_uc_type=True,
                rephrased_query=conversational_prompter_output.rephrased_initial_question,
                guidelines="",
                entities=Entities(),
                suggested_entities=None,
                sectors=None,
                entity_type=None,
                original_language=original_language,
                original_query=original_query,
                is_geo_or_region=is_geo_or_region,
                tagged_routes=tagged_routes,
            )
            logger.info(f"Query Analyzer processed results for the given query : {inputs.message} \n {outputs}")
            return outputs

        if uc_type == "general" or uc_type == "macro":
            is_rd_entity, entity_name = True, None
            date_retriever_date_output_unstructured = TimeThresholdFilter(
                uc_specific_prompt=TIME_THRESHOLD_PROMPT_DATE_OUTPUT_UNSTRUCTURED,
                output_parser=output_parser_time_threshold_dates,
                specific_instructions_fn=empty_instructions_string,
                examples_fn=time_threshold_date_additional_examples_string,
                filters_input=FiltersInput(llm=inputs.llm, temperature=inputs.temperature),
            )
            extracted_dates = date_retriever_date_output_unstructured.invoke(
                conversational_prompter_output.rephrased_initial_question,
                today_date=date.today(),
                today_date_year=date.today().year,
                last_year=date.today().year - 1,
                today_date_minus_year=date.today() + relativedelta(years=-1),
            )
            time_rephraser = QuestionRephraser(model_name=inputs.llm, temperature=inputs.temperature)
            time_rephrased_question = time_rephraser.rephrase(
                extracted_dates, conversational_prompter_output.rephrased_initial_question
            )
            conversational_prompter_output.rephrased_initial_question = time_rephrased_question

        elif uc_type == "outlook":
            logger.info(f"Result of the outlook subrouter: {subrouting_result}")
            if subrouting_result == "macro":
                is_rd_entity, entity_name = True, None
            else:
                is_rd_entity, entity_name = self.check_rd_entity(
                    entities=entity_extractor_result, tagged_routes=tagged_routes
                )
        else:
            is_rd_entity, entity_name = self.check_rd_entity(
                entities=entity_extractor_result, tagged_routes=tagged_routes
            )

        if uc_type in ["research", "scores&modifiers", "info_coverage"]:
            outputs = QueryAnalyzerOutput(
                query=inputs.message,
                uc_type=uc_type,
                multi_uc_type=True,
                rephrased_query=conversational_prompter_output.rephrased_initial_question,
                guidelines="",
                entities=entity_extractor_result,
                suggested_entities=entity_suggestions_result,
                sectors=sector_extractor_result,
                entity_type=entity_type,
                original_language=original_language,
                original_query=original_query,
                is_geo_or_region=is_geo_or_region,
                tagged_routes=tagged_routes,
            )
            logger.info(f"Query Analyzer processed results for the given query : {inputs.message} \n {outputs}")
            return outputs

        if uc_type == "outlook":
            outputs = QueryAnalyzerOutput(
                query=inputs.message,
                multi_uc_type=True,
                uc_type=uc_type,
                rephrased_query=conversational_prompter_output.rephrased_initial_question,
                guidelines="",
                entities=entity_extractor_result,
                suggested_entities=entity_suggestions_result,
                sectors=sector_extractor_result,
                entity_type=entity_type,
                subrouting_result=subrouting_result,
                original_language=original_language,
                original_query=original_query,
                is_geo_or_region=is_geo_or_region,
                tagged_routes=tagged_routes,
            )
            logger.info(f"Query Analyzer processed results for the given query : {inputs.message} \n {outputs}")
            return outputs

        outputs = QueryAnalyzerOutput(
            query=inputs.message,
            uc_type=uc_type,
            multi_uc_type=True,
            rephrased_query=conversational_prompter_output.rephrased_initial_question,
            guidelines="",
            entities=entity_extractor_result,
            sectors=sector_extractor_result,
            entity_type=entity_type,
            extracted_timeframe=extracted_dates,
            original_language=original_language,
            original_query=original_query,
            is_geo_or_region=is_geo_or_region,
            tagged_routes=tagged_routes,
        )
        logger.info(f"Query Analyzer processed results for the given query : {inputs.message} \n {outputs}")
        return outputs

    def run_analyzer(
        self, inputs: QueryAnalyzerInput, original_language: str, original_message: str, tagged_routes=[]
    ) -> ComponentsOutput(QueryAnalyzerOutput):
        conversational_prompter = ConversationalPrompter(model_name=inputs.llm, temperature=inputs.temperature)
        future_conversational_prompter_output = submit_to_shared_thread_pool(
            conversational_prompter.run,
            query=inputs.message,
            history=inputs.chat_history,
        )
        decision, conversational_prompter_output = future_conversational_prompter_output.result()
        if decision.flag == "clarifying":
            message = conversational_prompter_output.clarifying_question
            message = Get_translation_result(message, original_language)
            message = message.result()
            return get_default_answer(
                reason="clarifying",
                message=message,
                original_language=original_language,
                original_query=original_message,
            )

        if conversational_prompter_output.subqueries is not None and len(conversational_prompter_output.subqueries) > 1:
            return self.process_subqueries(
                conversational_prompter_output, inputs, original_language, original_message, tagged_routes=tagged_routes
            )

        entity_extractor = EntityExtractor(
            model_name=inputs.llm_for_entity_extractor, temperature=inputs.temperature_for_entity_extractor
        )
        # check for article entities
        article_entities = [entity for entity in inputs.list_of_tagged_entities if entity.type == "Articles"]
        if article_entities:
            # Log all found article entities
            for article_entity in article_entities:
                logger.info(f"Found article entity with ID: {article_entity.id}, Name: {article_entity.name}")

            outputs = QueryAnalyzerOutput(
                query=inputs.message,
                original_language=original_language,
                original_query=original_message,
                uc_type="selected_article",
                rephrased_query=conversational_prompter_output.rephrased_initial_question,
                guidelines="",
                entities=Entities(),
                sectors=None,
                entity_type=None,
                list_of_tagged_entities=inputs.list_of_tagged_entities,
                tagged_routes=tagged_routes,
            )
            logger.info(
                f"Query Analyzer processed results for selected articles: {[entity.id for entity in article_entities]}"
            )
            logger.info(outputs)
            return outputs

        sector_extractor = SectorExtractor(model_name=inputs.llm, temperature=inputs.temperature)

        # Will need to adjust for multitopic routing in the future
        uc_router_result = self.uc_router.get_routing(
            query=conversational_prompter_output.rephrased_initial_question,
            tagged_routes=tagged_routes,
            multi_topic=False,
        )
        if uc_router_result[1] is False and uc_router_result[0][0] == "suggested route failure":
            logger.error("Hard Routing Failure: UC Router Failure")
            return get_default_answer()
        uc_type = uc_router_result[0][0]
        # if len(tagged_routes) > 0:
        #     tagged_routes = tagged_routes[0]
        routing_flag = uc_router_result[1]
        future_entity = submit_to_shared_thread_pool(
            entity_extractor.execute,
            query=conversational_prompter_output.rephrased_initial_question,
            list_of_tagged_entities=inputs.list_of_tagged_entities,
        )

        future_sector = submit_to_shared_thread_pool(
            sector_extractor.execute, query=conversational_prompter_output.rephrased_initial_question, uc_type=uc_type
        )

        future_subrouter = submit_to_shared_thread_pool(
            self.run_sub_router,
            uc_type=uc_type,
            inputs=inputs,
            rephrased_question=conversational_prompter_output.rephrased_initial_question,
        )

        # Get results
        (entity_extractor_result, entity_suggestions, raw_entities), entity_extraction_flag = future_entity.result()
        sector_extractor_result, sector_extractor_flag = future_sector.result()
        subrouting_result = future_subrouter.result()
        geography_extractor = GeographyExtractor(
            model_name=inputs.llm_for_entity_extractor, temperature=inputs.temperature_for_entity_extractor
        )
        future_geography = submit_to_shared_thread_pool(
            geography_extractor.run,
            query=conversational_prompter_output.rephrased_initial_question,
        )
        logger.info("Geography extractor started")
        is_geo_or_region = future_geography.result()
        logger.info("Geography extractor ended")
        backup = False
        if not (routing_flag and entity_extraction_flag and sector_extractor_flag):
            backup = True
        # overriding uc_type logic, depending on entities
        if uc_type == "scores&modifiers":
            try:
                COMPANY_NAMES = ", ".join([company.extracted_name for company in entity_extractor_result.companies])
                subrouter = ScoresModifiersSubrouter(model_name=inputs.llm, temperature=inputs.temperature)
                uc_type = subrouter.run(
                    query=conversational_prompter_output.rephrased_initial_question,
                    # query=inputs.message,
                    entities_input=add_company_name_to_prompt(COMPANY_NAMES),
                )
                if uc_type != "scores&modifiers":
                    logger.info(f"Subrouting for scores&modifiers: changing uc_type from scores&modifiers to {uc_type}")
                else:
                    logger.info("Subrouting for scores&modifiers: uc_type remains unchanged")
            except Exception as e:
                logger.error(f"Query Analyzer error in subrouting scores&modifiers query: {e}")
                uc_type = "scores&modifiers"

        # subrouting for rating actions, questions with no specific company mentioned
        if uc_type == "rating_action":
            if entity_extractor_result.securities or entity_extractor_result.revenue_sources:
                # a specific security or revenue source exists, remains in rating_action
                logger.info(f"Subrouting for rating_action: uc_type remains {uc_type}")
            elif not entity_extractor_result.companies:
                # no subject, general use case
                uc_type = "query"
                logger.info(f"Subrouting for rating_action: changing uc_type from rating_action to {uc_type}")
            else:
                # question subject may exist
                COMPANY_NAMES = ", ".join([company.extracted_name for company in entity_extractor_result.companies])
                subrouter = RatingActionSubrouter(model_name=inputs.llm, temperature=inputs.temperature)
                entity_subject_bool = subrouter.run(
                    query=conversational_prompter_output.rephrased_initial_question, entities=COMPANY_NAMES
                )
                if entity_subject_bool:
                    # user asked about rating action of a certain entity
                    logger.info(f"Subrouting for rating_action: uc_type remains {uc_type}")
                else:
                    # no subject, entity entity appears as a data filter ("show me all Japanese companies")
                    uc_type = "query"
                    logger.info(f"Subrouting for rating_action: changing uc_type from rating_action to {uc_type}")

        entity_name_suggestions, entity_id_suggestions = [], []
        if entity_suggestions:
            for item in entity_suggestions:
                entity_name_suggestions.append(self.extract_name_from_entity(item))
                entity_id_suggestions.append(self.extract_id_from_entity(item))

        entity_suggestions_result = None
        if entity_name_suggestions and entity_id_suggestions and raw_entities:
            rephrase_with_entity_prompter = SuggestedEntityRephrasePrompter(
                model_name=inputs.llm, temperature=inputs.temperature
            )
            query_rephrase_result = rephrase_with_entity_prompter.run(
                query=inputs.message, extracted_entity=raw_entities[0], suggested_entities=entity_name_suggestions
            )
            try:
                entity_suggestions_result = SuggestedEntities(
                    entities=[
                        SuggestedEntity(
                            id=entity_id_suggestions[i],
                            name=entity_name_suggestions[i],
                            query=query_rephrase_result.rephrased_questions[i],
                        )
                        for i in range(len(entity_id_suggestions))
                    ]
                )
            except Exception as e:
                logger.error(f"Query Analyzer error in rephrasing query with entity: {e}")
                entity_suggestions_result = None

        entity_type = self.get_entity_mentioned_type(entities=entity_extractor_result)
        if entity_type is EntityType.STRUCTURED_FINANCE:
            logger.info(f"changing uc_type from {uc_type} to deals_tranche")
            uc_type = "deals_tranche"
        if entity_extractor_result.securities:
            logger.info(f"changing uc_type from {uc_type} to ratings")
            uc_type = "ratings"

        if uc_type == "others":
            logger.error("No use case supported for others type.")
            return get_default_answer(original_language=original_language, original_query=original_message)
        # set the extracted dates to None
        extracted_dates = None
        # for now we removed the entity check for general question because entity extractor gets some non valid entity and search api may gets some entity which is not RD (e.g. -> how does the uaw strike impact auto makers?).

        # analyzer for uc_type query, relies on subrouting for rating actions
        is_rd_entity, entity_name = self.check_rd_entity(entities=entity_extractor_result, tagged_routes=tagged_routes)

        if not is_rd_entity:
            if entity_suggestions_result:
                logger.info(
                    f"Entity {entity_name} is not an RD entity and there are RD suggestions found in {entity_suggestions_result}."
                )
            else:
                logger.info(
                    f"Entity {entity_name} is not an RD entity and there are no RD suggestions found in {entity_suggestions_result}."
                )
            return get_default_answer(
                entity_name=entity_name,
                reason="get_default_answer_for_non_rd_entity",
                suggested_entities=entity_suggestions_result,
                original_language=original_language,
            )

        if uc_type == "query":
            outputs = QueryAnalyzerOutput(
                query=inputs.message,
                original_language=original_language,
                original_query=original_message,
                uc_type=uc_type,
                rephrased_query=conversational_prompter_output.rephrased_initial_question,
                guidelines="",
                entities=Entities(),
                suggested_entities=None,
                sectors=None,
                entity_type=None,
                backup=backup,
                is_geo_or_region=is_geo_or_region,
                tagged_routes=tagged_routes,
            )
            logger.info(f"Query Analyzer processed results for the given query : {inputs.message} \n {outputs}")
            return outputs

        if uc_type == "general" or uc_type == "macro":
            # is_rd_entity, entity_name = True, None
            date_retriever_date_output_unstructured = TimeThresholdFilter(
                uc_specific_prompt=TIME_THRESHOLD_PROMPT_DATE_OUTPUT_UNSTRUCTURED,
                output_parser=output_parser_time_threshold_dates,
                specific_instructions_fn=empty_instructions_string,
                examples_fn=time_threshold_date_additional_examples_string,
                filters_input=FiltersInput(llm=inputs.llm, temperature=inputs.temperature),
            )
            extracted_dates = date_retriever_date_output_unstructured.invoke(
                conversational_prompter_output.rephrased_initial_question,
                today_date=date.today(),
                today_date_year=date.today().year,
                last_year=date.today().year - 1,
                today_date_minus_year=date.today() + relativedelta(years=-1),
            )
            time_rephraser = QuestionRephraser(model_name=inputs.llm, temperature=inputs.temperature)
            time_rephrased_question = time_rephraser.rephrase(
                extracted_dates, conversational_prompter_output.rephrased_initial_question
            )
            conversational_prompter_output.rephrased_initial_question = time_rephrased_question

        elif uc_type == "outlook":
            logger.info(f"Result of the outlook subrouter: {subrouting_result}")
            if subrouting_result == "macro":
                is_rd_entity, entity_name = True, None
            else:
                is_rd_entity, entity_name = self.check_rd_entity(
                    entities=entity_extractor_result, tagged_routes=tagged_routes
                )
        else:
            is_rd_entity, entity_name = self.check_rd_entity(
                entities=entity_extractor_result, tagged_routes=tagged_routes
            )

        if entity_suggestions_result:
            entity_suggestions_result.query_entity_is_rd = is_rd_entity

        if uc_type in ["research", "scores&modifiers", "info_coverage"]:
            outputs = QueryAnalyzerOutput(
                query=inputs.message,
                original_language=original_language,
                original_query=original_message,
                uc_type=uc_type,
                rephrased_query=conversational_prompter_output.rephrased_initial_question,
                guidelines="",
                entities=entity_extractor_result,
                suggested_entities=entity_suggestions_result,
                sectors=sector_extractor_result,
                entity_type=entity_type,
                backup=backup,
                is_geo_or_region=is_geo_or_region,
                tagged_routes=tagged_routes,
            )
            logger.info(f"Query Analyzer processed results for the given query : {inputs.message} \n {outputs}")
            return outputs

        if uc_type == "outlook":
            outputs = QueryAnalyzerOutput(
                query=inputs.message,
                original_language=original_language,
                original_query=original_message,
                uc_type=uc_type,
                rephrased_query=conversational_prompter_output.rephrased_initial_question,
                guidelines="",
                entities=entity_extractor_result,
                suggested_entities=entity_suggestions_result,
                sectors=sector_extractor_result,
                entity_type=entity_type,
                subrouting_result=subrouting_result,
                backup=backup,
                is_geo_or_region=is_geo_or_region,
                tagged_routes=tagged_routes,
            )
            logger.info(f"Query Analyzer processed results for the given query : {inputs.message} \n {outputs}")
            return outputs

        outputs = QueryAnalyzerOutput(
            query=inputs.message,
            original_language=original_language,
            original_query=original_message,
            uc_type=uc_type,
            rephrased_query=conversational_prompter_output.rephrased_initial_question,
            guidelines="",
            entities=entity_extractor_result,
            suggested_entities=entity_suggestions_result,
            sectors=sector_extractor_result,
            entity_type=entity_type,
            extracted_timeframe=extracted_dates,
            tagged_routes=tagged_routes if tagged_routes else None,
            is_geo_or_region=is_geo_or_region,
        )
        logger.info(f"Query Analyzer processed results for the given query : {inputs.message} \n {outputs}")
        return outputs

    def get_entity_mentioned_type(self, entities: Entities) -> EntityType:
        if entities.revenue_sources:
            return EntityType.REVENUE_SOURCE
        elif entities.securities:
            return EntityType.SECURITY
        elif entities.companies:
            if entities.companies[0].subsector_code in ["PUBFIN", "GOVS"]:
                return EntityType.USPF
            elif entities.companies[0].subsector_code == "SOV":
                return EntityType.SOVEREIGN
            elif entities.companies[0].rd_sector and entities.companies[0].rd_sector[0] == "Structured Finance":
                return EntityType.STRUCTURED_FINANCE
            else:
                return EntityType.COMPANY
        else:
            return None

    def check_rd_entity(self, entities: Entities, tagged_routes: List[str]):
        if tagged_routes:
            return True, None

        if entities:
            all_entities = entities.companies + entities.revenue_sources + entities.securities
            if all_entities:
                entity_list = [entity.is_rd_entity for entity in all_entities]
                entity_1st = all_entities[0]
                entity_1st_name = entity_1st.name if hasattr(entity_1st, "name") else entity_1st.extracted_name
                if len(all_entities) == 0 or (len(all_entities) == 1 and not entity_1st.is_rd_entity):
                    return False, entity_1st_name
                if len(all_entities) > 1:
                    if any(entity_list):
                        return True, None
                    else:
                        return False, entity_1st_name

        return True, None

    def extract_name_from_entity(self, entity: Entities) -> Optional[str]:
        if entity.securities:
            return entity.securities[0].extracted_name
        elif entity.revenue_sources:
            return entity.revenue_sources[0].name
        elif entity.companies:
            return entity.companies[0].name

    def extract_id_from_entity(self, entity: Entities):
        if entity.securities:
            return str(entity.securities[0].id)
        elif entity.revenue_sources:
            return str(entity.revenue_sources[0].asid)
        elif entity.companies:
            return str(entity.companies[0].mi_id)

    def run_sub_router(self, uc_type: str, inputs: QueryAnalyzerInput, rephrased_question):
        if uc_type == "outlook":
            subrouter = OutlookSubrouter(model_name=inputs.llm, temperature=inputs.temperature)
            try:
                subrouting_result = subrouter.run(query=rephrased_question)
                logger.info(f"Result of the outlook subrouter: {subrouting_result}")
                return subrouting_result
            except Exception as e:
                logger.error(f"Error occurred while running outlook subrouter: {e}")
                # Fall back to the default MACRO value
                return OutlookSubroutingValues.TYPE_MACRO.value
