CREDITRATING_EXTRACTION_PROMPT = """You are tasked with extracting S&P credit rating(s), time frame information, and display column preferences from user questions.

**INSTRUCTIONS:**
1. Extract ONLY S&P credit rating(s), time frame, and display column preference from the USER QUESTION
2. Return ONLY a Python dictionary string with keys "value", "time_frame", and "display_column"
3. Do NOT provide explanations, comments, or additional text
4. ALWAYS return all three keys ("value", "time_frame", "display_column") in the response

**OUTPUT FORMAT REQUIREMENTS:**
- "value": Return as string when available, None when not available
- "time_frame": Return as string when available, None when not available
- "display_column": Return as True when user wants to include/display ratings, False otherwise
- Both value and time_frame must be strings (when present) or None (when absent)
- display_column must be boolean (True or False)
- Output must be a valid Python dictionary string format

**CREDIT RATING EXTRACTION RULES:**
- Single rating: Return as string (e.g., "AA", "BBB+", "CCC-")
- Multiple/range ratings: Return as comma-separated string of quoted values in descending order (e.g., "'AAA','AA+','AA'")
- Credit rating could be ask in different cases (upper, lower, mixed) but you should always return in upper case.
- Use exact S&P notation with +/- modifiers where applicable
- Map synonyms to actual ratings using this reference: {synonyms}
- If no credit rating mentioned: Return None
- For "rated companies" queries: Include AAA through SD (include R, D, SD)
- For "investment grade" or "IG" queries: Include AAA through BBB- only
- For "speculative grade" queries: Include BB+ through SD (include R, D, SD)
- For "defaulted companies" queries: Include D and SD ratings only
- R = Regulatory supervision
- D = Payment default on an obligation
- SD = Selective default on a specific issue or class of obligations
- NR = Not Rated (only include when explicitly requested)

**COMPARISON OPERATORS:**
- "better than", "higher than", "more than", "greater than", "above" → Include all ratings higher than specified
- "lower than", "less than", "below", "worse than" → Include all ratings lower than specified  
- "greater than or equal", "at least", "or better", "or above" → Include specified rating and all higher
- "less than or equal", "at most", "or worse", "or below" → Include specified rating and all lower
- "between X and Y", "from X to Y" → Include all ratings from the higher rating to the lower rating (inclusive of both endpoints)
    * Always identify which rating is higher and which is lower on the S&P scale
    * Include all ratings from the higher rating down to the lower rating (inclusive)
    * Example: "between BB- and BBB+" means BBB+, BBB, BBB-, BB+, BB, BB-
- "equal to", "exactly", "is", "rated" → Only the specified rating
- "not equal to", "doesn't equal", "not", "except" → All ratings except the specified one
- Multiple ratings: "AA, A and B", "AAA or BB+" → Include all specified ratings

**TIME FRAME EXTRACTION RULES:**
- Format: "[MM/DD/YYYY]-[MM/DD/YYYY]" (string)
- Current date: {current_date}
- If no time frame mentioned, return None
- Handle relative dates (e.g., "last 6 months", "this year", "Q1 2024")

{display_column_instructions}

**S&P RATING SCALE (highest to lowest):**
AAA, AA+, AA, AA-, A+, A, A-, BBB+, BBB, BBB-, BB+, BB, BB-, B+, B, B-, CCC+, CCC, CCC-, CC, C, R, D, SD, NR

**EXAMPLES:**
{creditrating_extraction_examples}

**EXPECTED OUTPUT FORMAT (PYTHON DICTIONARY STRING):**
- When no credit rating found: {{"value": None, "time_frame": None, "display_column": False}}
- When only credit rating found: {{"value": "AA+", "time_frame": None, "display_column": False}}
- When only time frame found: {{"value": None, "time_frame": "01/01/2024-03/31/2024", "display_column": False}}
- When both found: {{"value": "'AAA','AA+'", "time_frame": "01/01/2024-12/31/2024", "display_column": False}}
- When display_column is True: {{"value": None, "time_frame": None, "display_column": True}}

**USER QUESTION:** {user_question}"""

CREDITRATING_EXTRACTION_EXAMPLES = [
    (
        "Give me the companies with AA or above rating in 2024.",
        {"value": "'AAA','AA+','AA'", "time_frame": "[01/01/2024]-[12/31/2024]", "display_column": False},
    ),
    (
        "List me the companies that received top ratings in the last 6 months.",
        {
            "credit_rating": None,
            "time_frame": "[{TODAY_DATE + relativedelta(months=-6):%m/%d/%Y}]-[{TODAY_DATE:%m/%d/%Y}]",
            "display_column": False,
        },
        "The question is asking for top ratings, which means all the credit ratings from AAA to BBB-. The time frame for the rating is last 6 months",
        {
            "value": "'AAA','AA+','AA','AA-','A+','A','A-','BBB+','BBB','BBB-'",
            "time_frame": "[{TODAY_DATE + relativedelta(months=-6):%m/%d/%Y}]-[{TODAY_DATE:%m/%d/%Y}]",
            "display_column": False,
        },
    ),
    (
        "Show me top rated companies.",
        {
            "value": "'AAA','AA+','AA','AA-'",
            "time_frame": None,
            "display_column": False,
        },
        "The top rating covers all the credit ratings from AAA to BBB-. Thus the answer must contains all the credit ratings from AAA to BBB-. The time frame for the rating isn't specified. Thus, it should be None.",
        {
            "value": "'AAA','AA+','AA','AA-','A+','A','A-','BBB+','BBB','BBB-'",
            "time_frame": None,
            "display_column": False,
        },
    ),
    (
        "List health care companies with credit score above lower medium grade in the last 3 months with their EBITDA and revenue for Q1 and Q2 of 2024.",
        {
            "value": "'AAA','AA+','AA'",
            "time_frame": "[01/01/2024]-[06/30/2024]",
            "display_column": False,
        },
        "Lower medium grade is BBB+. Question is asking above 'lower medium grade'. Thus the answer should contains the BBB+. The question is also asking for the credit rating in the last 3 months, which is [{TODAY_DATE + relativedelta(months=-3):%m/%d/%Y}]-[{TODAY_DATE:%m/%d/%Y}].",
        {
            "value": "'AAA','AA+','AA','AA-','A+','A','A-'",
            "time_frame": "[{TODAY_DATE + relativedelta(months=-3):%m/%d/%Y}]-[{TODAY_DATE:%m/%d/%Y}]",
            "display_column": False,
        },
    ),
    (
        "Provide me list of rated companies.",
        {
            "credit_rating": "AAA, AA+, AA, A+, A, A-, BBB+, BBB, BBB-",
            "time_frame": "[{TODAY_DATE + relativedelta(months=-6):%m/%d/%Y}]-[{TODAY_DATE:%m/%d/%Y}]",
            "display_column": True,
        },
        """The question is asking for rated companies, which means all the credit ratings. The time frame for the rating isn't specified. Thus, it should be None.
        'display_column' can not be True because user ask a specific criteria for rating: 'rated companies'""",
        {
            "value": "'AAA','AA+','AA','AA-','A+','A','A-','BBB+','BBB','BBB-','BB+','BB','BB-','B+','B','B-','CCC+','CCC','CCC-','CC','C','R','D','SD'",
            "time_frame": None,
            "display_column": False,
        },
    ),
    (
        "What are the Indian companies with credit ratings in the last one year?",
        {
            "value": "'AAA','AA+','AA','AA-','A+','A','A-','BBB+','BBB','BBB-','BB+','BB','BB-','B+','B','B-','CCC+','CCC','CCC-','CC','C','R','D','SD'",
            "time_frame": "[{TODAY_DATE + relativedelta(years=-1):%m/%d/%Y}]-[{TODAY_DATE:%m/%d/%Y}]",
            "display_column": False,
        },
    ),
    (
        "Give me CCC rated companies in the last 12 months.",
        {
            "value": "'CCC+','CCC','CCC-'",
            "time_frame": "[{TODAY_DATE + relativedelta(months=-12):%m/%d/%Y}]-[{TODAY_DATE:%m/%d/%Y}]",
            "display_column": False,
        },
        "The question is asking for CCC rated companies. Thus the answer must contains only the 'CCC'. The time frame for the rating is last 12 months",
        {
            "value": "CCC",
            "time_frame": "[{TODAY_DATE + relativedelta(months=-12):%m/%d/%Y}]-[{TODAY_DATE:%m/%d/%Y}]",
            "display_column": False,
        },
    ),
    (
        "Show me companies rated above A- and below AAA.",
        {
            "value": "'AAA','AA+','AA','AA-','A+','A', 'A-'",
            "time_frame": None,
            "display_column": True,
        },
        """The question specifically asks rating above A- and below AAA. The response should exclude the A- and AAA.
        'display_column' argument can be true only when there is no criteria in the prompt. The question defines a certain criteria for rating, thus the 'display_column' should be False.""",
        {
            "value": "'AA+','AA','AA-','A+','A'",
            "time_frame": None,
            "display_column": False,
        },
    ),
    (
        "Show me companies rated above or below BB",
        {
            "value": "'AAA','AA+','AA','AA-','A+','A','A-','BBB+','BBB','BBB-','BB+','BB-','B+','B','B-','CCC+','CCC','CCC-','CC','C','R','D','SD'",
            "time_frame": None,
            "display_column": False,
        },
    ),
    (
        "Provide a list of rated companies within Canada that are rated above AA.",
        {
            "value": "AAA",
            "time_frame": None,
            "display_column": False,
        },
        "The question asks credit ratings above 'AA'. The credit ratings above 'AA' are 'AAA' and 'AA+'. The response must cover both.",
        {
            "value": "'AAA','AA+'",
            "time_frame": None,
            "display_column": False,
        },
    ),
    (
        "Show me companies with ratings lower than BB.",
        {
            "value": "'BB-','B+','B','B-','CCC+','CCC','CCC-','CC','C','R','D','SD'",
            "time_frame": None,
            "display_column": False,
        },
    ),
    (
        "Show me a list of aerospace companies greater than CC+.",
        {
            "value": "'AAA','AA+','AA','AA-','A+','A','A-','BBB+','BBB','BBB-','BB+','BB','BB-','B+','B','B-','CCC+','CCC','CCC-'",
            "time_frame": None,
            "display_column": False,
        },
        "'CC+' is not a valid S&P rating. Thus, you can not apply any comparison operator on it. The response must be None for 'value'.",
        {
            "value": None,
            "time_frame": None,
            "display_column": False,
        },
    ),
    (
        "What rating changes happened between July and August?",
        {
            "value": "'AAA','AA+','AA','AA-','A+','A','A-','BBB+','BBB','BBB-','BB+','BB','BB-','B+','B','B-','CCC+','CCC','CCC-','CC','C','R','D','SD'",
            "time_frame": "[07/01/{TODAY_DATE.year}]-[08/31/{TODAY_DATE.year}]",
            "display_column": False,
        },
    ),
    (
        "Provide LATAM Banks with IG rated",
        {
            "value": None,
            "time_frame": None,
            "display_column": False,
        },
        "'IG' is short for 'Investment Grade'. It is special term that covers all the credit ratings from 'AAA' to 'BBB-'. The response must contains all the credit ratings from 'AAA' to 'BBB-'.",
        {
            "value": "'AAA','AA+','AA','AA-','A+','A','A-','BBB+','BBB','BBB-'",
            "time_frame": None,
            "display_column": False,
        },
    ),
    (
        "Provide companies above IG",
        {
            "value": "'AAA','AA+','AA','AA-','A+','A','A-','BBB+','BBB','BBB-'",
            "time_frame": None,
            "display_column": False,
        },
        "'IG' is short for 'Investment Grade'. It is special term that covers all the credit ratings from 'AAA' to 'BBB-'. There is no rating above 'AAA'. Thus, the response must be None for 'value'.",
        {
            "value": None,
            "time_frame": None,
            "display_column": False,
        },
    ),
    (
        "Give me entities with credit ratings between BBB and A in the last 3 months.",
        {
            "value": "'A','A-','BBB+','BBB'",
            "time_frame": "[{TODAY_DATE + relativedelta(months=-3):%m/%d/%Y}]-[{TODAY_DATE:%m/%d/%Y}]",
            "display_column": False,
        },
    ),
    (
        "Can you provide ratings between BB- and BBB+?",
        {
            "value": "'BBB+','BBB','BBB-','BB+','BB','BB-'",
            "time_frame": None,
            "display_column": False,
        },
    ),
    (
        "Provide me a list of companies rated BB- or lower in this year.",
        {
            "value": "'B+','B','B-','CCC+','CCC','CCC-','CC','C'",
            "time_frame": "[01/01/2024]-[12/31/2024]",
            "display_column": False,
        },
        "The question is asking for ratings BB- or lower. Thus the answer must contains the 'BB-','R','D' and 'SD'. The time frame for the rating is this year",
        {
            "value": "'BB-','B+','B','B-','CCC+','CCC','CCC-','CC','C','R','D','SD'",
            "time_frame": "[01/01/{TODAY_DATE.year}]-[12/31/{TODAY_DATE.year}]",
            "display_column": False,
        },
    ),
    (
        "List speculative grade or junk bond companies.",
        {
            "value": "'BB+','BB','BB-','B+','B','B-','CCC+','CCC','CCC-','CC','C','R','D','SD'",
            "time_frame": None,
            "display_column": False,
        },
    ),
    (
        "Give me highly rated companies from January to March 2024.",
        {
            "value": "'AAA','AA+','AA','AA-'",
            "time_frame": "[01/01/2024]-[03/31/2024]",
            "display_column": False,
        },
        "'Highly rated' is synonym for all the credit ratings from 'AAA' to 'A-'. The time frame for the rating is January to March 2024",
        {
            "value": "'AAA','AA+','AA','AA-','A+','A','A-'",
            "time_frame": "[01/01/2024]-[03/31/2024]",
            "display_column": False,
        },
    ),
    (
        "List companies having A rating?",
        {
            "value": "A",
            "time_frame": None,
            "display_column": False,
        },
    ),
    (
        "What companies have BBB+ rating?",
        {
            "value": "BBB+",
            "time_frame": None,
            "display_column": False,
        },
    ),
    (
        "What companies have rating below default rating?",
        {
            "value": "'SD'",
            "time_frame": None,
            "display_column": False,
        },
    ),
    (
        "Find companies with no mention of ratings but high revenue.",
        {"value": None, "time_frame": None, "display_column": False},
    ),
    (
        "Show me companies with high revenue in Q1 2024.",
        {"value": None, "time_frame": "[01/01/2024]-[03/31/2024]", "display_column": False},
        """There is no mention of credit rating in the question. Thus, the 'value' must be None.
        The time frame is not for credit rating. Thus, the 'time_frame' must be None.""",
        {"value": None, "time_frame": None, "display_column": False},
    ),
    # Display Column Examples - when user wants to include ratings in output
    (
        "Give me companies and include their ratings.",
        {
            "value": "'AAA','AA+','AA','AA-','A+','A','A-','BBB+','BBB','BBB-','BB+','BB','BB-','B+','B','B-','CCC+','CCC','CCC-','R','D','SD'",
            "time_frame": None,
            "display_column": False,
        },
        """You should only return full list of ratings when the user asks 'rated companies'. However, the user is asking to 'include ratings'. 
        This description falls under 'display_column' category. Thus, the 'display_column' must be True, 'value' and 'time_frame' must be None.""",
        {"value": None, "time_frame": None, "display_column": True},
    ),
    (
        "Give me creditwatch outlook as positive companies and display their ratings.",
        {"value": "positive", "time_frame": None, "display_column": True},
        "'positive' is not a valid S&P rating. The question asks for the ratings to be displayed. Thus, the 'display_column' must be True, 'value' and 'time_frame' must be None.",
        {"value": None, "time_frame": None, "display_column": True},
    ),
    (
        "Give me the companies and include ratings.",
        {"value": None, "time_frame": None, "display_column": True},
    ),
    # Comparison Operators Examples
    (
        "Show me companies with ratings better than CCC.",
        {
            "value": "'AAA','AA+','AA','AA-','A+','A','A-','BBB+','BBB','BBB-','BB+','BB','BB-','B+','B'",
            "time_frame": None,
            "display_column": False,
        },
        "The question asking for rating better than 'CCC'. According to S&P rating scale, ratings better than 'CCC' starts from 'CCC+' to 'AAA'. Thus the answer must contains all the credit ratings from 'CCC+' to 'AAA'. The time frame for the rating isn't specified. Thus, it should be None.",
        {
            "value": "'AAA','AA+','AA','AA-','A+','A','A-','BBB+','BBB','BBB-','BB+','BB','BB-','B+','B','B-','CCC+'",
            "time_frame": None,
            "display_column": False,
        },
    ),
    (
        "Show me companies with ratings BB- and CC-.",
        {
            "value": "'BB-','CC-'",
            "time_frame": None,
            "display_column": False,
        },
        "According to S&P rating scale, 'CC-' is not a valid rating. Thus, the response must only contain 'BB-'. The time frame for the rating isn't specified. Thus, it should be None.",
        {
            "value": "'BB-'",
            "time_frame": None,
            "display_column": False,
        },
    ),
    (
        "Give me list of companies with ratings AAA, AAA-, AA+ or AA",
        {
            "value": "'AAA','AAA-','AA+','AA'",
            "time_frame": None,
            "display_column": False,
        },
        "According to S&P rating scale, 'AAA-' is not a valid rating. Thus, the response must only contain 'AAA', 'AA+' and 'AA'. The time frame for the rating isn't specified. Thus, it should be None.",
        {
            "value": "'AAA','AA+','AA'",
            "time_frame": None,
            "display_column": False,
        },
    ),
    (
        "Show me companies with ratings greater than BB.",
        {
            "value": "'BBB+','BBB','BBB-','BB+','BB','BB-','B+','B','B-'",
            "time_frame": None,
            "display_column": False,
        },
        "The question is asking for ratings greater than 'BB'. According to S&P rating scale, ratings greater than 'BB' starts from 'BB+' to 'AAA'. Thus the answer must contains all the credit ratings from 'BB+' to 'AAA'. The time frame for the rating isn't specified. Thus, it should be None.",
        {
            "value": "'AAA','AA+','AA','AA-','A+','A','A-','BBB+','BBB','BBB-','BB+'",
            "time_frame": None,
            "display_column": False,
        },
    ),
    (
        "List companies with credit ratings lower than A.",
        {
            "value": "'A+','A','A-','BBB+','BBB','BBB-','BB+','BB','BB-','B+','B','B-','CCC+','CCC','CCC-','CC','C'",
            "time_frame": None,
            "display_column": False,
        },
        "The question is asking for ratings lower than 'A'. According to S&P rating scale, ratings lower than 'A' starts from 'A-' and ends at 'SD'. Thus the answer must contains all the credit ratings from 'A-' to 'SD'. The time frame for the rating isn't specified. Thus, it should be None.",
        {
            "value": "'A-','BBB+','BBB','BBB-','BB+','BB','BB-','B+','B','B-','CCC+','CCC','CCC-','CC','C','R','D','SD'",
            "time_frame": None,
            "display_column": False,
        },
    ),
    (
        "List companies with credit ratings greater than A.",
        {
            "value": "'AAA','AA+','AA','AA-','A+'",
            "time_frame": None,
            "display_column": False,
        },
    ),
    (
        "Give me companies rated BBB or better in 2024.",
        {
            "value": "'AAA','AA+','AA','AA-','A+','A','A-','BBB+'",
            "time_frame": "[01/01/2024]-[12/31/2024]",
            "display_column": False,
        },
        "The question is asking for ratings BBB or better. Thus the answer must contains the 'BBB' also. The time frame for the rating is 2024",
        {
            "value": "'AAA','AA+','AA','AA-','A+','A','A-','BBB+','BBB'",
            "time_frame": "[01/01/2024]-[12/31/2024]",
            "display_column": False,
        },
    ),
    (
        "Show companies with ratings BB+ or worse this year.",
        {
            "value": "'BB','BB-','B+','B','B-','CCC+','CCC','CCC-','CC','C','R','D','SD'",
            "time_frame": "[01/01/{TODAY_DATE.year}]-[12/31/{TODAY_DATE.year}]",
            "display_column": False,
        },
        "The question is asking for ratings BB+ or worse. Thus the answer must contains the 'BB+'. The time frame for the rating is this year",
        {
            "value": "'BB+','BB','BB-','B+','B','B-','CCC+','CCC','CCC-','CC','C','R','D','SD'",
            "time_frame": "[01/01/{TODAY_DATE.year}]-[12/31/{TODAY_DATE.year}]",
            "display_column": False,
        },
    ),
    (
        "Find companies rated between B- and CCC+ in the last quarter.",
        {
            "value": "'B-','CCC+'",
            "time_frame": "[{PREVIOUS_QUARTER_START}]-[{PREVIOUS_QUARTER_END}]",
            "display_column": False,
        },
    ),
    (
        "Give list of corporates that received BB rating in the previous quarter.",
        {
            "value": "'BB'",
            "time_frame": "[{TODAY_DATE + relativedelta(months=-3):%m/%d/%Y}]-[{TODAY_DATE:%m/%d/%Y}]",
            "display_column": False,
        },
        "The question is asking for 'BB' rated corporates. The time frame for the rating must cover the start and end of previous quarter. It should not be last 3 months.",
        {
            "value": "'BB'",
            "time_frame": "[{PREVIOUS_QUARTER_START}]-[{PREVIOUS_QUARTER_END}]",
            "display_column": False,
        },
    ),
    (
        "Show rated companies with excluding AAA in 2024.",
        {
            "value": "'AA+','AA','AA-','A+','A','A-','BBB+','BBB','BBB-','BB+','BB','BB-','B+','B','B-','CCC+','CCC','CCC-','CC','C','R','D','SD'",
            "time_frame": "[01/01/2024]-[12/31/2024]",
            "display_column": False,
        },
    ),
    (
        "Give me companies rated AA, A+ or BB- in the last 6 months.",
        {
            "value": "'AA-','A','BB+'",
            "time_frame": "[{TODAY_DATE + relativedelta(months=-6):%m/%d/%Y}]-[{TODAY_DATE:%m/%d/%Y}]",
            "display_column": False,
        },
        "The question is asking for companies rated 'AA', 'A+' or 'BB-'. Thus the answer must contains all the three credit ratings. The time frame for the rating is last 6 months",
        {
            "value": "'AA','A+','BB-'",
            "time_frame": "[{TODAY_DATE + relativedelta(months=-6):%m/%d/%Y}]-[{TODAY_DATE:%m/%d/%Y}]",
            "display_column": False,
        },
    ),
    (
        "Find companies with ratings greater than or equal to BB-.",
        {
            "value": "'AAA','AA+','AA','AA-','A+','A','A-','BBB+','BBB','BBB-','BB+','BB'",
            "time_frame": None,
            "display_column": False,
        },
        "The question is asking for ratings greater than or equal to 'BB-'. Thus the answer must contains the 'BB-'. The time frame for the rating isn't specified. Thus, it should be None.",
        {
            "value": "'AAA','AA+','AA','AA-','A+','A','A-','BBB+','BBB','BBB-','BB+','BB','BB-'",
            "time_frame": None,
            "display_column": False,
        },
    ),
    (
        "Show companies rated less than or equal to CCC+ in the first quarter of 2025.",
        {
            "value": "'CCC+','CCC','CCC-','CC','C'",
            "time_frame": "[01/01/2025]-[03/31/2025]",
            "display_column": False,
        },
    ),
    (
        "List companies that have defaulted in the last year.",
        {
            "value": None,
            "time_frame": "[01/01/{TODAY_DATE.year - 1}]-[12/31/{TODAY_DATE.year - 1}]",
            "display_column": False,
        },
        "The question is asking for defaulted companies, which means only the credit ratings 'D' and 'SD'. The time frame for the rating is last year",
        {
            "value": "'D','SD'",
            "time_frame": "[01/01/{TODAY_DATE.year - 1}]-[12/31/{TODAY_DATE.year - 1}]",
            "display_column": False,
        },
    ),
    (
        "Show me defaulted companies in 2024.",
        {
            "value": "'D','SD'",
            "time_frame": "[01/01/2024]-[12/31/2024]",
            "display_column": False,
        },
    ),
    (
        "List companies with NR rating.",
        {
            "value": None,
            "time_frame": None,
            "display_column": False,
        },
        "'NR' is a valid S&P rating and the question is explicitly requesting 'NR'. Thus, the response must contain 'NR'.",
        {
            "value": "NR",
            "time_frame": None,
            "display_column": False,
        },
    ),
    (
        "What companies have rating below NR?",
        {
            "value": None,
            "time_frame": None,
            "display_column": False,
        },
    ),
    (
        "show me ratings between A and NR",
        {
            "value": "'A','A-','BBB+','BBB','BBB-','BB+','BB','BB-','B+','B','B-','CCC+','CCC','CCC-','CC','C','R','D','SD','NR'",
            "time_frame": None,
            "display_column": False,
        },
    ),
]
