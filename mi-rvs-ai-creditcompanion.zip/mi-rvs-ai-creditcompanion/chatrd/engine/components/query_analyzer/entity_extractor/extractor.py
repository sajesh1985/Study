import logging
from copy import deepcopy
from typing import List, Optional, Tuple

from chatrd.core.llm import LCLLMFactory
from chatrd.core.llm.components.message import AIMessage
from chatrd.core.llm.parsers import OutputParserException, PydanticOutputParser
from chatrd.core.llm.prompt.template import SimplePromptTemplate
from chatrd.engine.components.query_analyzer.entity_extractor.prompts import (
    ENTITY_EXTRACTOR_EXAMPLES,
    ENTITY_EXTRACTOR_PROMPT_TEMPLATE,
)
from chatrd.engine.components.query_analyzer.entity_extractor.utils import (
    Entities,
    ExtractedEntities,
    ExtractedSecurities,
    extract_cusip,
    extract_info_from_search_api,
    extract_isin,
    find_closest_string_index,
    post_process,
)
from chatrd.engine.components.query_analyzer.faulttolerantexecutor import (
    FaultTolerantExecutor,
)
from chatrd.engine.components.query_analyzer.utils import TaggedEntity
from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.utils import make_unique

config_machinery = get_config_machinery()

logger = logging.getLogger(__name__)


class EntityExtractor(FaultTolerantExecutor):

    def get_default_value(self) -> Tuple[Entities, List[Entities], List[str]]:
        """
        Default value for Entity Extractor is an empty Entity object, empty list of entities (no suggested entities), and an empty list of strings (no list of entity extracted names)

        Args:
            None
        Returns:
            - Entities : Empty Entity object
            - List[Entities] : Empty list of entities (no suggested entities)
            - List[str] : Empty list of strings (no list of entity extracted names)
        """
        return Entities(companies=[], securities=[], revenue_sources=[]), [], []

    def __init__(self, model_name: str, temperature: Optional[float] = 0.0):
        self.model = LCLLMFactory().get_llm(
            deployment_name_or_model_id=model_name,
            temperature=temperature,
        )
        self.entities_to_exclude = config_machinery.get_config_value(
            Constants.GeneralConstants.EXCLUDE_ENTITIES_IN_ENTITY_EXTRACTOR
        )

    def run(
        self, query: str, list_of_tagged_entities: List[TaggedEntity]
    ) -> Tuple[Entities, List[Entities], List[str]]:
        query_for_extractor = deepcopy(query)

        if list_of_tagged_entities:
            logger.info(f"Tagged Entities: {list_of_tagged_entities}")

        # extract securities from query based on regex patterns and tagged entities (no pattern matching) and combine both
        extracted_securities = self.extract_securities(question=query_for_extractor)
        tagged_securities = self.extract_tagged_securities(tagged_entities=list_of_tagged_entities)
        all_securities = ExtractedSecurities(
            isin=extracted_securities.isin + tagged_securities.isin,
            cusip=extracted_securities.cusip + tagged_securities.cusip,
        )
        # extract companies, securities, revenue sources from query
        all_entities = self.extract(question=query_for_extractor)
        all_entities = self.verify_for_exclusion(input_entities=all_entities, to_exclude=self.entities_to_exclude)
        # make search entities by post processing extracted and tagged entities
        search_entities = self.post_process_entities(entities=all_entities, securities=extracted_securities)
        search_entities = make_unique(search_entities, ["XYZ", "xyz"])
        logger.info(f"Post Processed Entities: {search_entities}")
        # remove tagged entities from search entities to avoid duplication
        for item in list_of_tagged_entities:
            index = find_closest_string_index(item.name, search_entities)
            if index != -1:
                del search_entities[index]
        logger.info(f"Post Processed Entities after filtering: {search_entities}")
        # add tagged entities to search entities but use tagged entity id for all except revenue sources where we use tagged entity name
        tagged_entities_id_name = [
            item.id if item.type not in ["REVENUE SOURCE", "RatingsRevenueSource"] else item.name
            for item in list_of_tagged_entities
        ]
        search_entities = tagged_entities_id_name + search_entities
        search_entities = make_unique(search_entities)
        # entity tagged status
        tagged_entities_status = [item in tagged_entities_id_name for item in search_entities]
        logger.info(f"Post Processed Entities after adding tagged entities: {search_entities}")

        # omnisearch valdation for search entities
        top_match_entities, suggested_entities = self.search_for_entities(
            entities=search_entities,
            securities=all_securities,
            tagged_entities_status=tagged_entities_status,
        )
        return top_match_entities, suggested_entities, search_entities

    def extract(self, question: str) -> ExtractedEntities:
        prompt_template = SimplePromptTemplate(template=ENTITY_EXTRACTOR_PROMPT_TEMPLATE)
        prompt = prompt_template.format(
            **{
                "question": question,
                "examples": ENTITY_EXTRACTOR_EXAMPLES,
            }
        )

        response = self.model.invoke(prompt)
        if isinstance(response, AIMessage):
            response = response.content

        logger.debug(f"Entity Extractor prompt for LLM : {prompt}")

        parser = PydanticOutputParser(pydantic_object=ExtractedEntities)
        try:
            entities = parser.parse(response)
            logger.info(f"Extracted Entities: {entities}")
            return entities
        except OutputParserException as e:
            msg = (
                f"Validation error at extracting entities from Entity Extractor's llm output {e}.\n"
                "Response is : {response}"
            )
            logger.error(msg)
            raise e

    def extract_securities(self, question: str) -> ExtractedSecurities:
        cusip = extract_cusip(question)
        isin = extract_isin(question)
        return ExtractedSecurities(cusip=cusip, isin=isin)

    def extract_tagged_securities(self, tagged_entities: List[TaggedEntity]) -> ExtractedSecurities:
        cusip_ids, isin_ids = [], []
        for tagged_entity in tagged_entities:
            if tagged_entity.type == "Securities":
                cusip = extract_cusip(tagged_entity.id)
                isin = extract_isin(tagged_entity.id)
                if cusip:
                    cusip_ids.append(cusip[0])
                if isin:
                    isin_ids.append(isin[0])
        return ExtractedSecurities(cusip=cusip_ids, isin=isin_ids)

    def search_for_entities(
        self, entities: ExtractedEntities, securities: ExtractedSecurities, tagged_entities_status: List[bool] = []
    ) -> Entities:
        entities, suggested_entities = extract_info_from_search_api(
            entities=entities, input_securities=securities, tagged_entities_status=tagged_entities_status
        )
        return entities, suggested_entities

    def post_process_entities(self, entities: ExtractedEntities, securities: ExtractedSecurities) -> List:
        updated_entities = post_process(entities=entities, securities=securities)
        all_entities = updated_entities.entities
        all_entities.extend(securities.isin)
        all_entities.extend(securities.cusip)
        return all_entities

    def verify_for_exclusion(self, input_entities: ExtractedEntities, to_exclude: List[str]) -> ExtractedEntities:
        to_exclude_lower = [entity.lower() for entity in to_exclude]
        return ExtractedEntities(
            entities=[entity for entity in input_entities.entities if entity.lower() not in to_exclude_lower]
        )
