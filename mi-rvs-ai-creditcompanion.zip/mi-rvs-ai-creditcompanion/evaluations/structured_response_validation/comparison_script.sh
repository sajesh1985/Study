#!/bin/bash

TAG1="develop"
TAG2="feature/list_prompt_wto_criteria" # Replace with the actual branch name you want to compare against develop

# Do not change the following paths.  Refer https://spglobal-mi.atlassian.net/wiki/spaces/CT/pages/841548991/Regression+Testing+for+Structured+Solution
REPO_PATH="/home/sagemaker-user/creditcompanion123_temp" # Do not change this path, unless you are sure you know what you are doing.
REGR_PATH="/home/sagemaker-user/creditcompanion/evaluations" # Do not change this path, unless you are sure you know what you are doing.
ENV="/home/sagemaker-user/creditcompanion/.env" # Do not change this path, unless you are sure you know what you are doing.

# Create the directory if it doesn't exist
if [ ! -d "$REPO_PATH" ]; then
  mkdir -p "$REPO_PATH"
  echo "Directory created: $REPO_PATH"
else
  echo "Directory already exists: $REPO_PATH"
fi

if [ ! -d "$REPO_PATH/.git" ]; then
  echo "Cloning repository into $REPO_PATH"
  git clone https://gitlab.ihsmarkit.com/quantitative.research/chatrd/creditcompanion.git "$REPO_PATH"
  cd "$REPO_PATH/chatrd" || exit
else
  echo "Repository already exists. Pulling latest changes in $REPO_PATH"
  cd "$REPO_PATH/chatrd" || exit
  # git pull
fi

PROCESS_SCRIPT="$REGR_PATH/structured_response_validation/regression_script.py"  # the script using the library
COMPARISON_SCRIPT="$REGR_PATH/structured_response_validation/compare_outputs.py"  # the script to compare outputs
IN_FILE="$REGR_PATH/data/questioner_input/list_questioner.txt"
echo "process script: $PROCESS_SCRIPT"
MTAG1=$(echo "$TAG1" | tr '/' '_')
MTAG2=$(echo "$TAG2" | tr '/' '_')

# Temp files for comparison
OUT1="$REGR_PATH/structured_response_validation/output_$MTAG1.csv"
OUT2="$REGR_PATH/structured_response_validation/output_$MTAG2.csv"

LOG1="$REGR_PATH/structured_response_validation/log_$MTAG1.txt"
LOG2="$REGR_PATH/structured_response_validation/log_$MTAG2.txt"

echo "Capturing outputs in : $OUT1 and $OUT2"
echo "Logging in : $LOG1 and $LOG2"
# Remove the log files from previous runs
rm -f "$LOG1"
rm -f "$LOG2"

# cd "$REPO_PATH"
echo "currently in directory: $(pwd)"
echo "currently in env:$ENV"
export $(grep -v '^#' "$ENV" | xargs)

# Ensure clean state
git reset --hard
git clean -fdx

# Function to build and run
run_version() {
    local TAG=$1
    local OUT_FILE=$2
    local LOG_FILE=$3
    echo "checking out tag $TAG"
    git checkout "$TAG"
    git lfs pull
    git pull
    
    # Install dependencies and build
    poetry lock
    poetry install
     # Print the current working directory
    echo "Running in directory: $(pwd)"
    echo "Running for tag $TAG"
    # Run the process and capture output    
    python "$PROCESS_SCRIPT" --in_file "$IN_FILE" --out_file "$OUT_FILE" --log_file "$LOG_FILE" --structured_only
}

# Run each tag
 run_version "$TAG1" "$OUT1" "$LOG1"
 run_version "$TAG2" "$OUT2" "$LOG2"
echo "Runs completed. tag1 $TAG1 out1 $OUT1"
# Compare results (simple diff)
echo "Comparing outputs:"

python "$COMPARISON_SCRIPT"  --response_dev_file "$OUT1" --response_branch_file "$OUT2" --response_comparison_out_file "$REGR_PATH/structured_response_validation"/response_diff.json
# echo python "$COMPARISON_SCRIPT"  --response_dev_file "$OUT1" --response_branch_file "$OUT2" --response_comparison_out_file "$REGR_PATH/structured_response_validation"/response_diff.json

