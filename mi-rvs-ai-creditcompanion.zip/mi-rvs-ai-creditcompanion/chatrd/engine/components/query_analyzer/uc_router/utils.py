import numpy as np


def cosine_similarity(query: np.ndarray, docs: np.ndarray, eps: float = 1e-10) -> np.ndarray:
    """
    Compute cosine similarity between a query vector and multiple document vectors.

    Args:
    - query: 1-dimensional numpy array representing the query vector.
    - docs: 2-dimensional numpy array where each row represents a document vector.

    Returns:
    - similarities: 1-dimensional numpy array of cosine similarities between
      the query vector and each document vector.
    """
    # Calculate dot product of query with each document
    dot_products = np.dot(docs, query)

    # Calculate norms for query and each document
    query_norm = np.linalg.norm(query)
    docs_norm = np.linalg.norm(docs, axis=1)

    query_norm = np.where(query_norm == 0, eps, query_norm)
    docs_norm = np.where(docs_norm == 0, eps, docs_norm)

    # Calculate cosine similarity
    similarities = dot_products / ((query_norm * docs_norm) + eps)

    return similarities
