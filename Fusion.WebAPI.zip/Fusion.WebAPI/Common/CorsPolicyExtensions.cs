﻿using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Fis.Epp.Fusion.WebAPI.Common
{
    public static class CorsPolicyExtensions
    {
        public static void UseCorsPolicy(this IApplicationBuilder builder)
        {
            var serviceProvider = builder.ApplicationServices;
            var appConfigService = serviceProvider.GetService<AppSettings>();
            bool enableCors = appConfigService.EnableCorsPolicy;
            if (enableCors)
            {
                builder.UseCors("CorsPolicy");
            }

        }
        public static void AddCorsPolicy(this IServiceCollection services)
        {
            var serviceProvider = services.BuildServiceProvider();
            var appConfigService = serviceProvider.GetService<AppSettings>();

            string[] allowedOrigins = appConfigService.CorsAllowedOrigins.Split(",");
            string[] allowedMethods = appConfigService.CorsAllowedMethods.Split(",");
            string[] allowedHeaders = appConfigService.CorsAllowedHeaders.Split(",");
            bool enableCorsPolicy = appConfigService.EnableCorsPolicy;
            if (enableCorsPolicy)
            {
                services.AddCors(options =>
            {
                options.AddPolicy("CorsPolicy",
                      builder =>
                      {
                          builder.WithOrigins(allowedOrigins)
                          .WithMethods(allowedMethods)
                          .WithHeaders(allowedHeaders);
                      });
            });
            }
        }
    }
}
