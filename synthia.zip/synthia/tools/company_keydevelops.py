from mcp.server.fastmcp import FastMCP, Context
from fastapi import FastAPI, APIRouter
from fastapi import Request
import logging
from contextlib import asynccontextmanager
import contextlib
from src.synthia.config.api_config import get_config
from . import auth
from src.synthia.utils.logging_config import configure_logging
from src.synthia.utils.source import Source
from datetime import datetime, timedelta
import httpx

# Configure logging
configure_logging(log_file='company_keydevelops.log')
logger = logging.getLogger(__name__)

mcp: FastMCP = FastMCP("Company Key Developments MCP", stateless_http=True)

cfg = get_config()

logger.info("Key Developments MCP Server starting up...")
capitaliq_base_url = cfg["capitaliq_base_url"]
key_developments_url_infix = "AIReportBuilder/keyDevelopments"
capitaliq_base_inherit_auth_url = cfg["capitaliq_base_inherit_auth_url"]

router = APIRouter()

key_development_body = {
    "entityList": None,
    "startDate": "",
    "endDate": ""
}

# Create a single AsyncClient instance for reuse (performance optimization for Lambda)
async_client: httpx.AsyncClient = None

@mcp.tool()
async def get_company_keydevelopments(inst_id: str, startDate: str = "", endDate: str = "") -> dict:
    """
    Get Fetch Instn Key Developments for a given Inst ID/KeyInstn/MI Key (instId) and date range.
    Args:
        inst_id (str):
            The Inst ID to get key developments for, also called as Instn ID, MI Key, KeyInstn.
        startDate (str, optional):
            Start date in 'MM/DD/YYYY' format. Defaults to 6 months ago.
        endDate (str, optional):
            End date in 'MM/DD/YYYY' format. Defaults to today.


    Returns:
        dict: A dictionary containing key developments for the given company and date range.
        The Key Development Headline link have a 'KeyDevelopmentHeadlineLink' field. To view the link, append the KeyDevelopmentHeadlineLink to: base_auth_url

        The dictionary will have the following attributes for the company:
           - KeyDevelopment: The identifier for the key development.
           - KeyDevelopmentTypeName: Key Development Type Name. 
           - KeyDevelopmentHeadline: Headline of the key development.
           - KeyDevelopmentHeadlineLink:  The link to the key development headline.
           - CIQDevelopmentDateBestUTC:  The date on which the key development was best recorded in UTC format.
           - DevelopmentAbstract: A brief summary of the key development.

    Example Response:
            [
                {
                    "KeyDevelopment": -2125656276,
                    "KeyDevelopmentTypeName": "Credit Rating: S&P: New Rating",
                    "KeyDevelopmentHeadline": "Issuer Credit Rating: raA; Positive from New: Argentina National Scale LT",
                    "KeyDevelopmentHeadlineLink": "#company/keyDevelopmentsPreview?keydevid=-2125656276&id=4000193",
                    "CIQDevelopmentDateBestUTC": "2024-05-14T09:56:00",
                    "DevelopmentAbstract": "S&P Global Ratings assigned its 'raA' Argentina national scale long-term issuer credit rating to International Business Machines Corporation (IBM). The outlook is positive. The rating reflects our view of IBM's strong business position, solid financial profile, and the positive outlook on the company."
                }
            ]  
    Error Handling:
        - Returns appropriate HTTP status codes:
        - 200 OK: Successful request
        - 400 Bad Request: Invalid parameters
        - 404 Not Found: Resource not found
        - 500 Internal Server Error: Server error
    """
    logger.info(f"Latest for key devlopments for inst_id: {inst_id}")
    # Set default startDate to 6 months ago if not provided
    if startDate == "" or startDate is None:
        default_start = datetime.now() - timedelta(days=90)
        startDate = default_start.strftime('%m/%d/%Y')

    # Set default endDate to today if not provided
    if endDate == "" or endDate is None:
        endDate = datetime.now().strftime('%m/%d/%Y')

    key_development_body["entityList"] = inst_id
    if startDate:
        key_development_body["startDate"] = startDate
    if endDate:
        key_development_body["endDate"] = endDate

    logger.info(f"get_company_keydevelopments called for : {inst_id}")
    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    url = f"{capitaliq_base_url}{key_developments_url_infix}"
    headers = {
        "Content-Type": "application/json",
        **auth.build_auth_headers(raw_request)
    }

    global async_client
    try:
        response = await async_client.post(url,
                                headers=headers, json=key_development_body)
        if response.status_code == 200:
            key_development_data = response.json()
            
            logger.info(f"key Development Data : {len(key_development_data)} records")
            processed_data = []
            sources = []
            for item in key_development_data:
                processed_item = {
                    "KeyDevelopmentTypeName": item.get("KeyDevelopmentTypeName"),
                    "KeyDevelopmentHeadline": item.get("KeyDevelopmentHeadline"),
                    "KeyDevelopmentHeadlineLink": item.get("KeyDevelopmentHeadlineLink"),
                    "CIQDevelopmentDateBestUTC": item.get("CIQDevelopmentDateBestUTC"),
                    "DevelopmentAbstract": item.get("DevelopmentAbstract"),
                }
                processed_data.append(processed_item)
                title = processed_item["KeyDevelopmentHeadline"]
                url = capitaliq_base_inherit_auth_url + "/" + processed_item["KeyDevelopmentHeadlineLink"]
                source = Source(title=title, url=url)
                sources.append(source)
            
            logger.info(f"key Development Processed Data: {len(processed_data)} records")
            return {
                "sources": sources,
                "data": processed_data
            }
        elif response.status_code == 204:
            logger.info("No key developments found for the given company: {inst_id}")
            source = Source(title="Company Key Developments", url=url)
            return {"sources": source, "data": [{"message": "No key developments found for the given company"}]}
        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return f"Error: {response.status_code} - {response.text}"
    except httpx.RequestError as e:
        logger.error(f"Request failed: {e}")
        return f"Request failed: {e}"


# Define a custom lifespan for FastAPI with a task to manage MCP

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Initialize MCP server task group
    logger.info("Initializing MCP server task group...")
    global async_client
    async_client = httpx.AsyncClient(timeout=10)
    async with contextlib.AsyncExitStack() as stack:
        await stack.enter_async_context(mcp.session_manager.run())
        yield
    await async_client.aclose()


@router.get("/company-keydevs/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "ok"}


# Create FastAPI app with lifespan
app = FastAPI(lifespan=lifespan)
app.mount("/company-keydevs", mcp.streamable_http_app())
app.include_router(router)
logger.info("Key Developments MCP Server started successfully.")