import styled from '@emotion/styled';

export const Container = styled.div`
  display: flex;
  flex-direction: column;
  padding-bottom: 114px;
  width: 100%;
  min-height: calc(100vh - 46px);
  
  & > div {
    max-width: 1080px;
  }
 
`;

export const MainContent = styled.div`
  flex: 1;
  max-width: 100%;
  margin: auto;
`;
