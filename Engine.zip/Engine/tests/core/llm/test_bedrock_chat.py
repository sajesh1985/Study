import json
from typing import List, Union
from unittest.mock import Mock, patch

import pytest
from botocore.config import Config

from chatrd.core.llm.models import BedrockChat
from chatrd.core.llm.components.message import (
    AIMessage,
    AIMessageChunk,
    HumanMessage,
    SystemMessage,
)

CLAUDE_MODEL = "anthropic.test-llm"
ANTHROPIC_PROVIDER = "anthropic"
COHERE_MODEL = "cohere.test-llm"


class TestBedrockChatInitialization:
    """Test cases for BedrockChat class initialization."""

    @pytest.fixture(scope="function")
    def mock_boto_session(self):
        """Test BedrockChat initialization with AWS profile."""
        with patch("chatrd.core.llm.models.bedrock.boto3.Session") as mock_boto_session:
            with patch("chatrd.core.llm.models.bedrock.boto3.client") as mock_boto_client:
                mock_session = Mock()
                mock_client = Mock()
                mock_session.available_profiles = ["default", "test-profile"]
                mock_boto_session.return_value = mock_session
                mock_session.client.return_value = mock_client
                mock_boto_client.return_value = mock_client
                return mock_boto_session

    @pytest.mark.parametrize(
        "provider, auth_type, is_streaming, inc_kwargs, inc_guardrails",
        [
            (ANTHROPIC_PROVIDER, None, False, False, False),
            (None, None, False, False, False),
            (ANTHROPIC_PROVIDER, None, True, False, False),
            (ANTHROPIC_PROVIDER, None, False, True, False),
            (ANTHROPIC_PROVIDER, None, False, False, True),
            (ANTHROPIC_PROVIDER, None, True, True, False),
            (ANTHROPIC_PROVIDER, None, False, True, True),
            (ANTHROPIC_PROVIDER, None, True, True, True),
            (ANTHROPIC_PROVIDER, "aws_profile", False, False, False),
            (ANTHROPIC_PROVIDER, "aws_keys", True, False, False),
            (ANTHROPIC_PROVIDER, "client_config", False, True, False),
        ],
    )
    def test_init_with_params(self, mock_boto_session, provider, auth_type, is_streaming, inc_kwargs, inc_guardrails):
        """Test initialization with different parameters."""
        model_kwargs = None if not inc_kwargs else {"temperature": 0.7, "max_tokens": 100}
        guardrails = None if not inc_guardrails else {"id": "test-id", "version": "1", "trace": True}
        profile = None if auth_type != "aws_profile" else "test-profile"
        aws_keys = None if auth_type != "aws_keys" else {"aws_access_key_id": "test", "aws_secret_access_key": "test"}
        client_config = None if auth_type != "client_config" else Config(region_name="us-west-2")
        region = None if client_config else "us-east-1"
        expected_region = "us-west-2" if client_config else "us-east-1"

        with patch("boto3.Session", mock_boto_session):
            bedrock_chat = BedrockChat(
                model_id=CLAUDE_MODEL,
                provider=provider,
                region_name=region,
                aws_profile_name=profile,
                aws_keys=aws_keys,
                streaming=is_streaming,
                model_kwargs=model_kwargs,
                guardrails=guardrails,
                verbose=True,
                client_config=client_config,
            )

        assert bedrock_chat.model_id == CLAUDE_MODEL
        assert bedrock_chat.get_provider() == ANTHROPIC_PROVIDER
        assert bedrock_chat.region_name == expected_region
        assert bedrock_chat.streaming is is_streaming
        assert bedrock_chat.model_kwargs == model_kwargs
        assert bedrock_chat.guardrails == guardrails
        assert bedrock_chat.verbose is True
        assert bedrock_chat.history == []
        assert bedrock_chat.get_session() is not None
        if not aws_keys:
            assert mock_boto_session.call_count > 1

    def test_init_with_client(self):
        """Test initialization with a custom client."""
        mock_client = Mock()
        mock_client.invoke_model.return_value = Mock()
        bedrock_chat = BedrockChat(model_id=CLAUDE_MODEL, client=mock_client)

        assert bedrock_chat.model_id == CLAUDE_MODEL
        assert bedrock_chat.client == mock_client
        assert bedrock_chat.get_provider() == ANTHROPIC_PROVIDER


class TestBedrockChatInvoke:
    """Test cases for invoke/ainvoke method."""

    @pytest.fixture(scope="function")
    def mock_client_bedrock_chat(self):
        """Create a BedrockChat instance with mocked client."""
        mock_client = Mock()
        return BedrockChat(model_id=COHERE_MODEL, client=mock_client)

    @pytest.fixture
    def message_factory(self):
        """Create sample messages for testing."""

        def message_provider(input: Union[int, List[str]]):
            if isinstance(input, int):
                return [
                    SystemMessage(content="You are a helpful assistant."),
                    HumanMessage(content="Hello, how are you?"),
                ][:input]
            elif isinstance(input, list):
                return [HumanMessage(content=prompt) for prompt in input]
            else:
                return [HumanMessage(content=input)]

        return message_provider

    @pytest.fixture
    def mock_response_body(self):
        """Create a mock response body."""
        return {"generations": [{"id": "test-id", "text": "Test response text", "output": "Test output"}]}

    @pytest.fixture
    def mock_response(self, mock_response_body):
        """Create a mock response object."""
        mock_response = {"body": Mock()}
        mock_response["body"].read.return_value = json.dumps(mock_response_body).encode()
        return mock_response

    @pytest.mark.parametrize(
        "input, expected_history_size",
        [
            (1, 2),
            (2, 3),
            (["Test prompt"], 2),
            (["First message", "Second message"], 3),
        ],
    )
    def test_invoke_with_history_update(
        self, mock_client_bedrock_chat, mock_response, message_factory, input, expected_history_size
    ):
        """Test invoke with human message."""
        messages = message_factory(input)
        expected_history_content = [msg.content for msg in messages]
        expected_result = AIMessage(content="Test response text", id="test-id")
        mock_client_bedrock_chat.client.invoke_model.return_value = mock_response

        result = mock_client_bedrock_chat.invoke(messages)

        assert isinstance(result, AIMessage)
        assert result.content == expected_result.content
        assert result.id == expected_result.id

        # Verify history was updated
        assert len(mock_client_bedrock_chat.history) == expected_history_size
        for i, history_content in enumerate(expected_history_content):
            assert mock_client_bedrock_chat.history[i].content == history_content

    def test_invoke_with_kwargs(self, mock_client_bedrock_chat):
        """Test invoke with additional kwargs."""
        user_input = [HumanMessage("Test with kwargs")]
        ctx = {"temperature": 0.8, "max_tokens": 150}
        expected_result = AIMessage("Test result")
        expected_parsed_input = HumanMessage(content="Test with kwargs")
        expected_parsed_kwargs = {"temperature": 0.8, "max_tokens": 150, "system": None, "messages": []}

        with patch.object(
            mock_client_bedrock_chat.__class__.__bases__[0], "invoke", return_value=expected_result
        ) as mock_invoke:
            result = mock_client_bedrock_chat.invoke(user_input, **ctx)

        assert result == expected_result
        mock_invoke.assert_called_once_with(inputs=expected_parsed_input, **expected_parsed_kwargs)
        call_args = mock_invoke.call_args
        assert call_args[1]["temperature"] == 0.8
        assert call_args[1]["max_tokens"] == 150

    @pytest.mark.asyncio
    async def test_ainvoke_calls_with_kwargs(self, mock_client_bedrock_chat):
        """Test that ainvoke properly uses run_in_executor."""
        messages = [HumanMessage(content="Async test")]
        expected_result = AIMessage(content="Async response")

        with patch("chatrd.core.llm.models.bedrock_chat.run_in_executor") as mock_executor:
            mock_executor.return_value = expected_result
            result = await mock_client_bedrock_chat.ainvoke(messages, temperature=0.7)

        assert result == expected_result
        mock_executor.assert_called_once_with(
            executor=None, func=mock_client_bedrock_chat.ainvoke, messages=messages, temperature=0.7
        )


class TestBedrockChatStreaming:
    """Test cases for stream/astream methods."""

    @pytest.fixture(scope="function")
    def mock_client_bedrock_chat(self):
        """Create a BedrockChat instance with mocked client."""
        mock_client = Mock()
        return BedrockChat(model_id=CLAUDE_MODEL, client=mock_client)

    def test_stream_success(self, mock_client_bedrock_chat):
        """Test successful streaming."""
        messages = [HumanMessage(content="Stream test")]
        expected_chunks = iter([AIMessageChunk(content=chunk) for chunk in ["Hello ", "world", "!"]])

        with patch.object(
            mock_client_bedrock_chat.__class__.__bases__[0], "stream", return_value=iter(expected_chunks)
        ):
            chunks = list(mock_client_bedrock_chat.stream(messages))

        assert len(chunks) == 3
        assert chunks[0].content == "Hello "
        assert chunks[1].content == "world"
        assert chunks[2].content == "!"
        assert all(isinstance(chunk, AIMessageChunk) for chunk in chunks)
        assert len(mock_client_bedrock_chat.history) == 2

    def test_stream_invalid_chunk_type(self, mock_client_bedrock_chat):
        """Test streaming with invalid chunk type."""
        messages = [HumanMessage(content="Stream test")]

        with patch.object(
            mock_client_bedrock_chat.__class__.__bases__[0], "stream", return_value=iter(["invalid_chunk"])
        ):
            with pytest.raises(ValueError, match="Expected AIMessageChunk"):
                list(mock_client_bedrock_chat.stream(messages))

    @pytest.mark.asyncio
    async def test_astream_success(self, mock_client_bedrock_chat):
        """Test successful async streaming."""
        messages = [HumanMessage(content="Async stream test")]
        mock_chunks = [AIMessageChunk(content="Async "), AIMessageChunk(content="streaming!")]

        async def mock_astream(*args, **kwargs):
            for chunk in mock_chunks:
                yield chunk

        with patch.object(mock_client_bedrock_chat.__class__.__bases__[0], "astream", side_effect=mock_astream):
            chunks = []
            async for chunk in mock_client_bedrock_chat.astream(messages):
                chunks.append(chunk)

        assert len(chunks) == 2
        assert chunks[0].content == "Async "
        assert chunks[1].content == "streaming!"
        assert all(isinstance(chunk, AIMessageChunk) for chunk in chunks)

    @pytest.mark.asyncio
    async def test_astream_invalid_chunk_type(self, mock_client_bedrock_chat):
        """Test async streaming with invalid chunk type."""
        messages = [HumanMessage(content="Async stream test")]

        async def mock_astream_invalid(*args, **kwargs):
            yield "invalid_chunk"

        with patch.object(mock_client_bedrock_chat.__class__.__bases__[0], "astream", side_effect=mock_astream_invalid):
            with pytest.raises(ValueError, match="Expected AIMessageChunk"):
                async for chunk in mock_client_bedrock_chat.astream(messages):
                    pass


class TestBedrockChatConversation:
    """Integration tests for BedrockChat class."""

    @pytest.fixture
    def integration_bedrock_chat(self):
        """Create a BedrockChat for integration testing."""
        mock_client = Mock()
        return BedrockChat(model_id=CLAUDE_MODEL, client=mock_client, model_kwargs={"temperature": 0.7})

    def test_full_conversation_workflow(self, integration_bedrock_chat):
        """Test a full conversation workflow."""
        # Mock parent invoke responses
        responses = [
            AIMessage(content="Hello! How can I help you?"),
            AIMessage(content="I can help you with that task."),
            AIMessage(content="Is there anything else you need?"),
        ]

        with patch.object(integration_bedrock_chat.__class__.__bases__[0], "invoke", side_effect=responses):
            # First message
            result1 = integration_bedrock_chat.invoke([HumanMessage(content="Hello")])
            assert result1.content == "Hello! How can I help you?"

            # Second message
            result2 = integration_bedrock_chat.invoke([HumanMessage(content="I need help with a task")])
            assert result2.content == "I can help you with that task."

            # Third message
            result3 = integration_bedrock_chat.invoke([HumanMessage(content="Thank you")])
            assert result3.content == "Is there anything else you need?"
            assert len(integration_bedrock_chat.history) == 6

    def test_conversation_with_history(self, integration_bedrock_chat):
        """Test conversation including system messages."""
        messages = [
            SystemMessage(content="You are a helpful assistant."),
            HumanMessage(content="What's the weather like?"),
        ]

        expected_result = AIMessage(content="I'd need your location to check the weather.")

        with patch.object(integration_bedrock_chat.__class__.__bases__[0], "invoke", return_value=expected_result):
            integration_bedrock_chat.invoke(messages)

        # Verify all messages were added to history
        assert len(integration_bedrock_chat.history) == 3
        assert isinstance(integration_bedrock_chat.history[0], SystemMessage)
        assert integration_bedrock_chat.history[0].content == "You are a helpful assistant."
        assert isinstance(integration_bedrock_chat.history[1], HumanMessage)
        assert integration_bedrock_chat.history[1].content == "What's the weather like?"
        assert isinstance(integration_bedrock_chat.history[2], AIMessage)
        assert integration_bedrock_chat.history[2].content == "I'd need your location to check the weather."

    def test_streaming_conversation(self, integration_bedrock_chat):
        """Test streaming in a conversation context."""
        message = HumanMessage(content="Tell me a story")

        mock_chunks = [
            AIMessageChunk(content="Once "),
            AIMessageChunk(content="upon "),
            AIMessageChunk(content="a time..."),
        ]

        with patch.object(integration_bedrock_chat.__class__.__bases__[0], "stream", return_value=iter(mock_chunks)):
            chunks = list(integration_bedrock_chat.stream([message]))

        # Verify streaming worked
        assert len(chunks) == 3
        full_content = "".join(chunk.content for chunk in chunks)
        assert full_content == "Once upon a time..."

        # Verify message was added to history
        assert len(integration_bedrock_chat.history) >= 1
        assert integration_bedrock_chat.history[0].content == "Tell me a story"

    @pytest.mark.asyncio
    async def test_async_conversation_workflow(self, integration_bedrock_chat):
        """Test async conversation workflow."""
        messages = [HumanMessage(content="Async hello")]
        expected_result = AIMessage(content="Async response")

        with patch("chatrd.core.llm.models.bedrock_chat.run_in_executor", return_value=expected_result):
            result = await integration_bedrock_chat.ainvoke(messages)

        assert result == expected_result

    def test_history_persistence_across_calls(self, integration_bedrock_chat):
        """Test that history persists across multiple calls."""
        with patch.object(
            integration_bedrock_chat.__class__.__bases__[0], "invoke", return_value=AIMessage(content="AI Response")
        ):
            conversation_inputs = [
                HumanMessage(content="Message 1"),
                HumanMessage(content="Message 2"),
                SystemMessage(content="System instruction"),
                HumanMessage(content="Message 3"),
            ]
            for round, message in enumerate(conversation_inputs, start=1):
                integration_bedrock_chat.invoke([message])
                # Verify history size increased after each call with messages and responses
                assert len(integration_bedrock_chat.history) == round * 2

            # Verify history order
            expected_history = [
                "Message 1",
                "AI Response",
                "Message 2",
                "AI Response",
                "System instruction",
                "AI Response",
                "Message 3",
                "AI Response",
            ]
            for i, message in enumerate(expected_history):
                assert integration_bedrock_chat.history[i].content == message
