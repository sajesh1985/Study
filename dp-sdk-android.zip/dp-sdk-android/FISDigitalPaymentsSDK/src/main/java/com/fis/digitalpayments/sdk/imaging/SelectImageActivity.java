// Copyright Notice!
// This document is protected under the trade secret and copyright
// laws as the property of Fidelity National Information Services, Inc.
// Copying, reproduction or distribution should be limited and only to
// employees with a “need to know” to do their job.
// Any disclosure of this document to third parties is strictly prohibited.
// © 2017 Fidelity National Information Services.
// All rights reserved worldwide.

package com.fis.digitalpayments.sdk.imaging;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.ResultReceiver;
import android.provider.MediaStore;
import android.media.ExifInterface;
import androidx.core.content.FileProvider;
import android.util.Base64;

import com.fis.digitalpayments.sdk.core.Bridge;
import com.fis.digitalpayments.sdk.core.BridgeException;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author e1035413 on 2/28/2017.
 */

public class SelectImageActivity extends Activity {

    public static final String IMAGE_RESULT_RECEIVER_NAME = "IMAGE_RESULT_RECEIVER";
    public static final String BASE64_IMAGE_RESULT_NAME = "BASE64_IMAGE_RESULT";
    private static final int SELECT_IMAGE_REQUEST_CODE = 101;
    private static final String preferenceFile = "SelectImageActivity.preferences";
    private static final String uriPreferenceKey = "photoUri";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent imageSelectionIntent = getImageSelectionIntent();
        Intent imageCaptureIntent = null;
        try {
            imageCaptureIntent = getImageCaptureIntent();
        } catch (BridgeException e) {
            //sendBridgeException(e);
        }

        if (imageCaptureIntent != null) {
            Intent intentChooser = Intent.createChooser(imageSelectionIntent, "");
            intentChooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[] {imageCaptureIntent});
            startActivityForResult(intentChooser, SELECT_IMAGE_REQUEST_CODE);
        }
        else {
            startActivityForResult(imageSelectionIntent, SELECT_IMAGE_REQUEST_CODE);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == SELECT_IMAGE_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                ResultReceiver resultReceiver = getIntent().getParcelableExtra(IMAGE_RESULT_RECEIVER_NAME);

                Bitmap bitmap = null;
                try {
                    Uri photoUri = retrievePhotoUri();

                    // Camera images are typically in the Uri and selected images are in the intent. This differs on some devices so check both.
                    if (photoUri != null) {
                        bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), photoUri);
                    }
                    Matrix matrix = new Matrix();
                    if (bitmap == null) {
                        Bundle extras= data.getExtras();

                        if(extras !=null && extras.containsKey("data"))
                        {
                            bitmap = (Bitmap) extras.get("data");
                        }
                        else
                        {
                            bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), data.getData());
                            photoUri = data.getData();
                            matrix.postRotate(getImageOrientation(photoUri));
                        }
                    }
                    bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);

                    //get bitmap dimensions
                    int bmOriginalWidth = bitmap.getWidth();
                    int bmOriginalHeight = bitmap.getHeight();

                    //choose a maximum height
                    int newHeight = 200;
                    //choose a max width
                    int newWidth = 200;

                    //call the method to get the scaled bitmap
                    bitmap = getScaledBitmap(bitmap, bmOriginalWidth, bmOriginalHeight,newHeight, newWidth);

                } catch (IOException e) {
                    //sendBridgeException(new BridgeException("Unable to retrieve bitmap.", e));
                    finish();
                }

                if (bitmap != null) {
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream);
                    byte[] bytes = byteArrayOutputStream.toByteArray();

                    String base64EncodedImage = Base64.encodeToString(bytes, Base64.NO_WRAP);
                    Bundle resultData = new Bundle();
                    resultData.putString(BASE64_IMAGE_RESULT_NAME, base64EncodedImage);
                    resultReceiver.send(RESULT_OK, resultData);
                }
            }
        }
        finish();
    }

    private static Bitmap getScaledBitmap(Bitmap bm, int bmOriginalWidth, int bmOriginalHeight, int newHeight, int newWidth) {
        if(bmOriginalHeight > newHeight && bmOriginalWidth > newWidth ) {
            if (bmOriginalHeight <= bmOriginalWidth ) {
                newWidth = (int) (((double)bmOriginalWidth/(double)bmOriginalHeight) * newHeight);
                bm = Bitmap.createScaledBitmap(bm, newWidth, newHeight, true);
            }
            else {
                newHeight = (int)(((double)bmOriginalHeight/(double)bmOriginalWidth) * newWidth);
                bm = Bitmap.createScaledBitmap(bm, newWidth, newHeight, true);
            }
        }
        return bm;
    }

    private Intent getImageCaptureIntent() throws BridgeException {
        Intent imageCaptureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (imageCaptureIntent.resolveActivity(getPackageManager()) != null) {
            // Create the File where the photo should go
            //Uri photoUri = FileProvider.getUriForFile(this, "com.fis.digitalpayments.sdk.imaging.provider", createImageFile());
            //File file = new File(Environment.getExternalStorageDirectory(), "test.jpg");
            Uri photoUri = Uri.fromFile(createImageFile());
            // Continue only if the FileHandle was successfully created
            if (photoUri != null) {
                storePhotoUri(photoUri);
                imageCaptureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);

                // Can't reliably display front facing camera, this flag may not be supported by all camera apps
                imageCaptureIntent.putExtra("android.intent.extras.CAMERA_FACING", 1);
            } else {
                imageCaptureIntent = null;
            }
        }

        return imageCaptureIntent;
    }

    private void storePhotoUri(Uri photoUri) {
        SharedPreferences preferences = getSharedPreferences(preferenceFile, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString(uriPreferenceKey, photoUri.toString());
        editor.apply();
        editor.commit();
    }

    private Uri retrievePhotoUri() {
        Uri photoUri = null;
        SharedPreferences preferences = getSharedPreferences(preferenceFile, Context.MODE_PRIVATE);
        String photoUriString = preferences.getString(uriPreferenceKey, null);

        if (photoUriString != null) {
            photoUri = Uri.parse(photoUriString);
        }

        return photoUri;
    }

    private Intent getImageSelectionIntent(){
        Intent contentSelectionIntent = null;
        try {
            contentSelectionIntent = new Intent(
                    Intent.ACTION_PICK,
                    android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        } catch (Exception e) {
            //throw new BridgeException("Error creating image file.", e);
        }

        return contentSelectionIntent;
    }

    private File createImageFile() throws BridgeException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDirectory = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image;

        try {
            image = File.createTempFile(imageFileName, ".jpg", storageDirectory);
        } catch (IOException e) {
            throw new BridgeException("Error creating image file.", e);
        }

        return image;
    }

   /* private void sendBridgeException(BridgeException bridgeException) {
        ResultReceiver resultReceiver = getIntent().getParcelableExtra(IMAGE_RESULT_RECEIVER_NAME);
        Bundle resultData = new Bundle();
        resultData.putSerializable(BRIDGE_EXCEPTION_KEY, bridgeException);
        resultReceiver.send(RESULT_FAILED, resultData);
    }*/

    @TargetApi(24)
    private int getImageOrientation(Uri photoUri){
        int rotate = 0;

        if (Build.VERSION.SDK_INT >= 24) {
            InputStream in = null;
            try {
                in = getContentResolver().openInputStream(photoUri);
                ExifInterface exif = new ExifInterface(in);
                int orientation = exif.getAttributeInt(
                        ExifInterface.TAG_ORIENTATION,
                        ExifInterface.ORIENTATION_NORMAL);

                switch (orientation) {
                    case ExifInterface.ORIENTATION_ROTATE_270:
                        rotate = 270;
                        break;
                    case ExifInterface.ORIENTATION_ROTATE_180:
                        rotate = 180;
                        break;
                    case ExifInterface.ORIENTATION_ROTATE_90:
                        rotate = 90;
                        break;
                }
            } catch (IOException e) {
                //sendBridgeException(new BridgeException("Unable to retrieve EXIF data.", e));
            } finally {
                if (in != null) {
                    try {
                        in.close();
                    } catch (IOException ioex) {
                        //sendBridgeException(new BridgeException("Failed to close input stream.", ioex));
                    }

                }
            }
        }
        return rotate;
    }
}
