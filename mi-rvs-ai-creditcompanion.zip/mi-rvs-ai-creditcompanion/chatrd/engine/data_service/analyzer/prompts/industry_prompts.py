from typing import Optional, Union

from pydantic import BaseModel, Field

from chatrd.core.llm.parsers import PydanticOutputParser
from chatrd.core.llm.prompt.template import BasePromptTemplate, SimplePromptTemplate
from chatrd.engine.components.query_analyzer.filter_retrievers.base import (
    BaseFilter,
    FiltersInput,
)


class QuestionSegments(BaseModel):
    Segments: Optional[Union[str, None]] = Field(
        default=None,
        description="The industry or sector explicitly mentioned in the USER QUESTION. If no industry or sector is identified, this field should be set to None.",
    )


parser_industry_extraction = PydanticOutputParser(pydantic_object=QuestionSegments)

INDUSTRY_EXTRACTION_TEMPLATE = """You are a financial analyst, whose goal is to identify and extract industry or sector names mentioned in a USER QUESTION and format the output according to OUTPUT_FORMAT_EXAMPLE.
You need to output Segments field only, do not output any other fields.
Instructions for Segments field:
<INSTRUCTIONS_SEGMENTS>
1. You are provided with a USER QUESTION.
2. Scan the USER QUESTION for any mentions of industry or sector names:
    - extract all sector names as a lower case, normalized, comma separated single string value
    - abbreviations mentioned in sector names should be normalized to their full forms (e.g., 'tech' to 'technology', 'telecom' to 'telecommunications', 'hr' to 'human resources', 'auto' to 'automotive', and 'pr' to 'public relations')
    - if a sector name is mentioned between quotation marks (e.g., "oil and gas", "telecom", "technology, media and telecommunications", "financial institutions"), extract it as a single name without any modification (including name and abbreviation normalization)
    - list only segments explicitly mentioned in the USER QUESTION. Do not deduce or infer any segments that are not explicitly stated
    - do not provide any additional explanations or comments
    - consider 'sovereigns', 'sovereign related', 'corporate', 'corporates', 'government' and 'government related' as a segment
    - if the query mentions any of these terms in EXCEPTIONS_LIST, treat them as if they were in quotation marks. That is, output the whole term as one segment, and remove all commas from these terms in the output
{exceptions}

3. If no industry or sector names are mentioned in the USER QUESTION, set the Segments field to null.
4. The question may reference generic terms like "companies", "entities", "organizations", "firms", "corporations", "industries", "issuers", or "sectors". These generic terms do not specify any particular industry or sector and should not be included in the Segments field.
IMPORTANT NOTE: there is a distinction between 'corporate'/'corporates' and 'corporations': 'corporate'/'corporates' is a segment (to be included in the Segments field), whereas 'corporations' is a generic term (not to be included in the Segments field).
</INSTRUCTIONS_SEGMENTS>
Additional, you will be provided with the following Guidance to help you identify and extract industry or sector names:
- step-by-step logic used to identify and extract industry or sector names
- relevant parts of the USER QUESTION and guidance provided in INSTRUCTIONS_SEGMENTS will be referenced in the reasoning process
You must follow the Guidance strictly and not deviate from it in any way, but you must not include the Guidance in your final answer.
Output Format: follow these instructions to format the response:
{format_instructions}
IMPORTANT NOTE: Guidance is not a part of the output. You must not include the Guidance in your final answer. Return only the answer in the specified Output Format, see OUTPUT_FORMAT_EXAMPLE.
<OUTPUT_FORMAT_EXAMPLE>
{\n  "Segments": "retrieved_segments"\n}
</OUTPUT_FORMAT_EXAMPLE>
Follow these examples, format them according to the Output Format (see OUTPUT_FORMAT_EXAMPLE). The Guidance is provided for each example to illustrate the reasoning process, but it is not part of the output and must not be included in your final answer.:
<EXAMPLES>
{industry_extraction_examples}
</EXAMPLES>
Apply these instructions to this input
USER QUESTION: {question}
""".strip()


INDUSTRY_EXTRACTION_EXAMPLES_LIST = [
    [
        "What are the banking companies?",
        """'Segments'='banking'""",
        """The USER QUESTION explicitly mentions the sector "banking" (INSTRUCTIONS_SEGMENTS: "extract all sector names as a lower case, normalized, comma separated single string value"). Therefore, the Segments field is set to "banking". This Guidance is not supposed to be a part of the final answer (see OUTPUT_FORMAT_EXAMPLE).""",
    ],
    [
        "list auto entities?",
        """'Segments'='automotive'""",
        """The USER QUESTION mentions "auto", which is an abbreviation for "automotive" (INSTRUCTIONS_SEGMENTS: "abbreviations mentioned in sector names should be normalized to their full forms"). Therefore, the Segments field is set to "automotive". This Guidance is not supposed to be a part of the final answer (see OUTPUT_FORMAT_EXAMPLE).""",
    ],
    [
        "List the entities in tech and 'precious metals and mining' sectors.",
        """'Segments'='technology, precious metals and mining'""",
        """USER QUESTION mentions two segments: "tech" and "precious metals and mining" (INSTRUCTIONS_SEGMENTS: 'extract all sector names'). Segment "tech" should be normalized to "technology" (INSTRUCTIONS_SEGMENTS: "abbreviations mentioned in sector names should be normalized to their full forms"), while "precious metals and mining" is in quotation marks and should be extracted as is (INSTRUCTIONS_SEGMENTS: "if a sector name is mentioned between quotation marks, extract it as a single name without any modification"). Therefore, the Segments field is set to "technology, precious metals and mining". This Guidance is not supposed to be a part of the final answer (see OUTPUT_FORMAT_EXAMPLE).""",
    ],
    [
        "Which corporations are in the healthcare, wellness and fitness sectors?",
        """'Segments'='healthcare, wellness, fitness'""",
        """The USER QUESTION mentions three segments: "healthcare", "wellness" and "fitness" (INSTRUCTIONS_SEGMENTS: 'extract all sector names'). Therefore, the Segments field is set to "healthcare, wellness, fitness". This Guidance is not supposed to be a part of the final answer (see OUTPUT_FORMAT_EXAMPLE).""",
    ],
    [
        "List some financial institutions.",
        """'Segments'='financial institutions'""",
        """The USER QUESTION explicitly mentions the sector "financial institutions" (INSTRUCTIONS_SEGMENTS: "extract all sector names as a lower case, normalized, comma separated single string value"). Therefore, the Segments field is set to "financial institutions". This Guidance is not supposed to be a part of the final answer (see OUTPUT_FORMAT_EXAMPLE).""",
    ],
    [
        "Who are the leaders in health and wellness products?",
        """'Segments'='health, wellness products'""",
        """The USER QUESTION mentions "health and wellness products". Since it is not in quotation marks, it should be treated as two separate sectors "health" and "wellness products" (INSTRUCTIONS_SEGMENTS: 'extract all sector names'). Therefore, the Segments field is set to "health, wellness products". This Guidance is not supposed to be a part of the final answer (see OUTPUT_FORMAT_EXAMPLE).""",
    ],
    [
        "Show me a list of government related entities",
        """'Segments'='government related'""",
        """The USER QUESTION explicitly mentions the sector "government related" (INSTRUCTIONS_SEGMENTS: "extract all sector names as a lower case, normalized, comma separated single string value"). Therefore, the Segments field is set to "government related". This Guidance is not supposed to be a part of the final answer (see OUTPUT_FORMAT_EXAMPLE).""",
    ],
    [
        "Show me credit issuers and their sectors",
        """'Segments'=null""",
        """The USER QUESTION uses the generic term "credit issuers" which does not specify any particular industry or sector (INSTRUCTIONS_SEGMENTS: "generic terms like companies, entities, organizations, firms, corporations, industries, issuers, or sectors do not specify any particular industry or sector and should not be included in the Segments field"). Therefore, the Segments field is set to null. This Guidance is not supposed to be a part of the final answer (see OUTPUT_FORMAT_EXAMPLE).""",
    ],
    [
        "Can you list major pharmaceutical companies in the US?",
        """'Segments'='pharmaceutical'""",
        """The USER QUESTION explicitly mentions the sector "pharmaceutical" (INSTRUCTIONS_SEGMENTS: "extract all sector names as a lower case, normalized, comma separated single string value"). Therefore, the Segments field is set to "pharmaceutical". The mention of "US" is a geography and does not affect the Segments field. This Guidance is not supposed to be a part of the final answer (see OUTPUT_FORMAT_EXAMPLE).""",
    ],
    [
        "List all corporates",
        """'Segments'='corporates'""",
        """The USER QUESTION explicitly mentions the sector "corporates" (INSTRUCTIONS_SEGMENTS: "consider 'corporate'/'corporates' as a segment" and "there is a distinction between 'corporate'/'corporates' and 'corporations': 'corporate'/'corporates' is a segment"). Therefore, the Segments field is set to "corporates". This Guidance is not supposed to be a part of the final answer (see OUTPUT_FORMAT_EXAMPLE).""",
    ],
    [
        "Fine me all rated governments",
        """'Segments'='government'""",
        """The USER QUESTION explicitly mentions the sector "government" (INSTRUCTIONS_SEGMENTS: "consider 'government' and 'government related' as a segment"). Therefore, the Segments field is set to "government". This Guidance is not supposed to be a part of the final answer (see OUTPUT_FORMAT_EXAMPLE).""",
    ],
    [
        "Show corporate companies and their geographies",
        """'Segments'='corporate'""",
        """The USER QUESTION explicitly mentions the sector "corporate" (INSTRUCTIONS_SEGMENTS: "extract all sector names as a lower case, normalized, comma separated single string value" and "consider 'corporate'/'corporates' as a segment"). Therefore, the Segments field is set to "corporate". This Guidance is not supposed to be a part of the final answer (see OUTPUT_FORMAT_EXAMPLE).""",
    ],
    [
        "Which companies are engaged in Roads, Bridges, Tunnels and steel production?",
        """'Segments'='roads bridges tunnels, steel production'""",
        """The USER QUESTION mentions two segments: "Roads, Bridges, Tunnels" and "steel production". Since "Roads, Bridges, Tunnels" is in the EXCEPTIONS_LIST, it should be treated as a single segment (INSTRUCTIONS_SEGMENTS: "if any of these terms in EXCEPTIONS_LIST are mentioned, treat them as if they were in quotation marks"). Therefore, the Segments field is set to "roads bridges tunnels, steel production". This Guidance is not supposed to be a part of the final answer (see OUTPUT_FORMAT_EXAMPLE).""",
    ],
    [
        "What are the Swiss companies and what are their sectors?",
        """'Segments'=null""",
        """The USER QUESTION does not explicitly mention any specific industry or sector names. While the country ("Swiss") is mentioned, it does not qualify as an industry segment (INSTRUCTIONS_SEGMENTS: "mention only segments explicitely mentioned in the USER QUESTION. Do not deduce or infer any segments that are not explicitly stated"). Therefore, the Segments field is set to null. This Guidance is not supposed to be a part of the final answer (see OUTPUT_FORMAT_EXAMPLE).""",
    ],
    [
        "Show me organizations in the 'real estate and construction' industry",
        """'Segments'='real estate and construction'""",
        """The USER QUESTION explicitly mentions the sector "real estate and construction" within quotation marks (INSTRUCTIONS_SEGMENTS: "if a sector name is mentioned between quotation marks, extract it as a single name without any modification"). Therefore, even though these are considered two distinct segments, the Segments field is set to "real estate and construction". This Guidance is not supposed to be a part of the final answer (see OUTPUT_FORMAT_EXAMPLE).""",
    ],
    [
        "show me top 10 companies from canada and their sectors",
        """'Segments'=null""",
        """The USER QUESTION does not explicitly specify any particular industry or sector. Although the country ("Canada") is mentioned, it is not an industry segment. Per the guidelines (INSTRUCTIONS_SEGMENTS: "mention only segments explicitly mentioned in the USER QUESTION. Do not deduce or infer any segments that are not explicitly stated"), no assumptions or inferences should be made about industries based on the country. Consequently, the Segments field is set to null. This Guidance is not supposed to be a part of the final answer (see OUTPUT_FORMAT_EXAMPLE).""",
    ],
    [
        "Can you provide a list of sovereigns?",
        """'Segments'='sovereigns'""",
        """The USER QUESTION explicitly mentions the sector "sovereigns" (INSTRUCTIONS_SEGMENTS: "extract all sector names as a lower case, normalized, comma separated single string value" and "consider 'sovereigns', 'sovereign related', 'corporate' and 'corporates' as a segment"). Therefore, the Segments field is set to "sovereigns". This Guidance is not supposed to be a part of the final answer (see OUTPUT_FORMAT_EXAMPLE).""",
    ],
    [
        "What are sovereign related entities?",
        """'Segments'='sovereign related'""",
        """The USER QUESTION explicitly mentions the sector "sovereign related" (INSTRUCTIONS_SEGMENTS: "extract all sector names as a lower case, normalized, comma separated single string value" and "consider 'sovereigns', 'sovereign related', 'corporate' and 'corporates' as a segment"). Therefore, the Segments field is set to "sovereign related". This Guidance is not supposed to be a part of the final answer (see OUTPUT_FORMAT_EXAMPLE).""",
    ],
    [
        "What are the business in oil and gas sectors?",
        """'Segments'='oil and gas'""",
        """The USER QUESTION mentions "oil and gas". Since "Oil & Gas" is in the EXCEPTIONS_LIST, it should be treated as a single segment (INSTRUCTIONS_SEGMENTS: "if any of these terms in EXCEPTIONS_LIST are mentioned, treat them as if they were in quotation marks"). Therefore, the Segments field is set to "oil and gas". This Guidance is not supposed to be a part of the final answer (see OUTPUT_FORMAT_EXAMPLE).""",
    ],
    [
        "Show me firms and their industry details.",
        """'Segments'=null""",
        """The USER QUESTION uses generic terms "firms" and "industry" which do not specify any particular industry or sector (INSTRUCTIONS_SEGMENTS: "generic terms like companies, entities, organizations, firms, corporations, industries, issuers, or sectors do not specify any particular industry or sector and should not be included in the Segments field"). Therefore, the Segments field is set to null. This Guidance is not supposed to be a part of the final answer (see OUTPUT_FORMAT_EXAMPLE).""",
    ],
    [
        "Which organizations fall under the 'technology and farming' sector?",
        """'Segments'='technology and farming'""",
        """The USER QUESTION explicitly mentions the sector "technology and software" within quotation marks (INSTRUCTIONS_SEGMENTS: "if a sector name is mentioned between quotation marks, extract it as a single name without any modification"). Therefore, even though these are considered two distinct segments, the Segments field is set to "technology and software". This Guidance is not supposed to be a part of the final answer (see OUTPUT_FORMAT_EXAMPLE).""",
    ],
]


EXCEPTIONS_LIST = [
    "Aerospace & Defense",
    "Automobiles & Components",
    "Business and Consumer Services",
    "Commercial & Professional Services",
    "Containers & Packaging",
    "Hotels & Gaming",
    "Media & Entertainment",
    "Metals & Mining",
    "Paper & Forest Products",
    "Property & Real Estate",
    "Leisure & Gaming",
    "Natural Resources/Mining",
    "Oil & Gas",
    "Public Finance Initiative/Real Estate",
    "Oil & Gas Projects",
    "Roads Bridges & Tunnels",
]


INDENT = "       "
EXCEPTIONS_LIST_FORMATTED = (
    f"{INDENT}<EXCEPTIONS_LIST>"
    + "\n"
    + f"{INDENT}-"
    + f"\n{INDENT}-".join(EXCEPTIONS_LIST)
    + f"\n{INDENT}</EXCEPTIONS_LIST>"
)


INDUSTRY_EXTRACTION_EXAMPLES_STRING = "\n\n________\n\n".join(
    [
        f"""Question: {question}\nOutput: {response}\nGuidance: {guidance}"""
        for question, response, guidance in INDUSTRY_EXTRACTION_EXAMPLES_LIST
    ]
)


INDUSTRY_EXTRACTION_INPUT = {
    "format_instructions": parser_industry_extraction.get_format_instructions(),
    "industry_extraction_examples": INDUSTRY_EXTRACTION_EXAMPLES_STRING,
    "exceptions": EXCEPTIONS_LIST_FORMATTED,
}


INDUSTRY_EXTRACTION_PROMPT = SimplePromptTemplate(
    template=INDUSTRY_EXTRACTION_TEMPLATE,
    partial_variables=INDUSTRY_EXTRACTION_INPUT,
)


class QueryIndustryRetriever(BaseFilter):
    def __init__(
        self,
        uc_specific_prompt: BasePromptTemplate,
        output_parser: PydanticOutputParser,
        filters_input: Optional[FiltersInput] = None,
    ):
        if filters_input:
            super().__init__(filters_input=filters_input)
        else:
            super().__init__()
        self.prompt_template = uc_specific_prompt
        self.output_parser = output_parser

    def invoke(self, user_input: str) -> BaseModel:
        user_input_prompt = self.prompt_template.format(question=user_input)
        output = self.model_for_data_service.invoke(user_input_prompt)
        output_parsed = self.output_parser.invoke(output)
        segments = output_parsed.model_dump()["Segments"]
        if segments is None:
            response = ""
        else:
            response = segments
        return response
