import logging
from typing import Dict, Optional

from pydantic import BaseModel

from chatrd.core.llm import LCLLMFactory
from chatrd.core.llm.components.message import AIMessage
from chatrd.core.llm.parsers import OutputParserException, PydanticOutputParser
from chatrd.core.llm.prompt.template import SimplePromptTemplate
from chatrd.engine.components.query_analyzer.faulttolerantexecutor import (
    FaultTolerantExecutor,
)
from chatrd.engine.components.query_analyzer.sector_extractor.prompt_templates import (
    CRITERIA_SECTOR_EXAMPLES,
    CRITERIA_SECTOR_PROMPTS,
    RESEARCH_SECTOR_EXAMPLES,
    RESEARCH_SECTOR_PROMPTS,
)
from chatrd.engine.components.query_analyzer.sector_extractor.utils import (
    CriteriaSectorExtractedFields,
    ResearchSectorExtractedFields,
)
from chatrd.engine.components.query_analyzer.utils import UCType

logger = logging.getLogger(__name__)


class SectorExtractor(FaultTolerantExecutor):

    def __init__(self, model_name: str, temperature: Optional[float] = 0.0):
        self.model = LCLLMFactory().get_llm(
            deployment_name_or_model_id=model_name,
            temperature=temperature,
        )

    def run(self, query: str, uc_type: str) -> BaseModel:
        if uc_type == UCType.CRITERIA.value:
            utilities = self._get_utils_for_llm(
                query, CRITERIA_SECTOR_PROMPTS, CRITERIA_SECTOR_EXAMPLES, CriteriaSectorExtractedFields
            )
        else:
            utilities = self._get_utils_for_llm(
                query, RESEARCH_SECTOR_PROMPTS, RESEARCH_SECTOR_EXAMPLES, ResearchSectorExtractedFields
            )

        prompt, parser = utilities["prompt"], utilities["parser"]

        logger.debug(f"Sector Extractor prompt for LLM : {prompt}")
        response = self.model.invoke(prompt)

        if isinstance(response, AIMessage):
            response = response.content

        try:
            sectors = parser.parse(response)
            logger.debug(f"Extracted sector: {sectors}")
            return sectors
        except OutputParserException as e:
            logger.error(f"Validation error from Sector Extractor's llm extraction {e}.")
            raise e

    def _get_utils_for_llm(
        self, query: str, prompt_template_str: str, examples: str, pydantic_object: BaseModel
    ) -> Dict:
        prompt_template = SimplePromptTemplate(template=prompt_template_str)
        prompt = prompt_template.format(
            **{
                "question": query,
                "examples": examples,
            }
        )
        parser = PydanticOutputParser(pydantic_object=pydantic_object)

        return {"prompt": prompt, "parser": parser}
