//import  ChatRD from '../../context/chatrd';
import { ChatRDProvider } from '../../context/chatrd';
import { App } from '../../components/chatrd/chatrd';
import { addLocaleResourceBundle } from '../../utils/localeManager';
import { Suspense } from 'react';
import { Route, Routes } from 'react-router-dom';
import FeedbackLandingPage from '../landingPageDashboardEntry/landingPageDashboardEntry';

addLocaleResourceBundle();

const ChatRDEntry = () => {
  return (
    <ChatRDProvider>
      <Suspense fallback={<div>Loading...</div>}>
          <Routes>
            <Route path="/" element={<App />} />
            <Route path="/dashboard" element={<FeedbackLandingPage/>} />
          </Routes>
        </Suspense>
    </ChatRDProvider>
    )
 
};

export default ChatRDEntry;
