import logging
import time
from copy import deepcopy
from typing import Any, Dict, List, Tuple, Union

import pandas as pd
from pydantic import BaseModel

from chatrd.core.document import (
    CSDTableResponse,
    Document,
    ParentChildTableResponse,
    TableDocument,
    TableResponse,
)
from chatrd.engine.components.query_analyzer.entity_extractor.utils import Entities
from chatrd.engine.configuration import get_config_machinery
from chatrd.engine.data_service.processor import Processor
from chatrd.engine.data_service.schema import ProcessorInput
from chatrd.engine.data_service.utils import get_rd_sector

logger = logging.getLogger(__name__)

config_machinery = get_config_machinery()


def _default_parse(data: Union[str, Dict], uc_type: str) -> Dict:
    responses = []
    for d in data:
        if d["type"] == "text":
            responses.append(
                {
                    "response": d["content"],
                    "response_type": d["type"],
                    "synthesize": d["synthesize"],
                    "error": d.get("error", False),
                }
            )
        elif d["type"] == "table":
            df = deepcopy(d["content"])
            if uc_type == "query":
                remove_dict = ["SOURCING URL"]
            else:
                remove_dict = ["ENTITY ID", "MI KEY", "MI KEY 2", "INSTRUMENT ITEM ID", "SOURCING URL"]
            for c in remove_dict:
                if c in df.columns:
                    df.drop(c, inplace=True, axis=1)

            if len(df) == 0:
                responses.append({"response": "", "response_type": "text", "synthesize": d["synthesize"]})
            else:
                for col in df.columns:
                    df[col] = df[col].apply(lambda x: str(x))
                df.replace("", None, inplace=True)
                df.replace("None", None, inplace=True)
                rows_json = df.to_dict(orient="records")
                column_schema = []
                for col in df.columns:
                    if pd.api.types.is_integer_dtype(df[col].dtype):
                        column_schema.append({"type": "number", "name": col})
                    elif pd.api.types.is_float_dtype(df[col].dtype):
                        column_schema.append({"type": "number", "name": col})
                    else:
                        column_schema.append({"type": "string", "name": col})

                responses.append(
                    {
                        "column_schema": column_schema,
                        "rows": rows_json,
                        "response_type": d["type"],
                        "synthesize": d["synthesize"],
                        "count": d["count"],
                        "count_distribution": d["count_distribution"],
                    }
                )
        elif d["type"] == "csd_table":
            responses.append(
                {
                    "response": d["content"],
                    "response_type": "csd_table",
                    "synthesize": d["synthesize"],
                }
            )
        elif d["type"] == "parentchild_table":
            responses.append(
                {
                    "response": d["content"],
                    "response_type": "parentchild_table",
                    "synthesize": d["synthesize"],
                }
            )
    return responses


def _parse_result(result: Dict, uc_type: str, rd_sector) -> Tuple[Dict, Dict]:
    if uc_type == "deals_tranche" or rd_sector == ["U.S. Public Finance"]:
        data = result.get("data", "")
        response_payload = result.get("api_info", None)
        return _default_parse(data, uc_type), {
            "source_description": result["source_description"],
            "response_payload": response_payload,
        }
    else:
        response_payload = result.get("api_info", "Some error occurred and no payload found from Data Service.")
        if "error" in result:
            logger.info(f"**Data Service API** error response: :red[{result['error']}]")
            return [{"response": str(result["error"]), "response_type": "text", "synthesize": False}], {
                "response_payload": response_payload,
                "source_description": None,
                "is_error": True,
            }

        data = result.get("data", "")
        if data:
            return _default_parse(data, uc_type), {
                "response_payload": response_payload,
                "source_description": result["source_description"],
            }

        return [
            {
                "response": "",
                "response_type": "text",
                "synthesize": False,
            }
        ], {"response_payload": response_payload, "source_description": None}


def call_data_service(
    query: str,
    entities: Entities,
    model_name_for_data_service: str,
    uc_type: str,
    sectors: BaseModel,
    original_language: str = "",
    original_query: str = "",
    multi_uc_type: bool = False,
) -> List[Document]:
    all_entities = entities.companies + entities.revenue_sources
    logger.info("Data Service API is retrieving.")
    start_time = time.time()
    if not (original_language == "" or original_query == ""):
        processor_input = ProcessorInput(
            user_input=query,
            uc_type=uc_type,
            entities=entities.dict(),
            llm=model_name_for_data_service,
            original_language=original_language,
            original_query=original_query,
            multi_uc_type=multi_uc_type,
        )
    else:
        processor_input = ProcessorInput(
            user_input=query,
            uc_type=uc_type,
            entities=entities.dict(),
            llm=model_name_for_data_service,
            multi_uc_type=multi_uc_type,
        )

    result: ProcessorOutput = Processor().response(processor_input=processor_input)

    logger.info(f"Time taken by Data API Services (in seconds) : {time.time() - start_time}")
    logger.info(f"Retrieved Data Service Result : {result}")
    rd_sector = get_rd_sector(entities)
    responses, extra_infos = _parse_result(result, uc_type, rd_sector)
    if "response_payload" not in extra_infos:
        extra_infos["response_payload"] = None

    supported_multiple_use_cases = ["ratings", "financial", "rating_action"]
    supported_single_multi_entity_use_cases = ["ratings", "rating_action"]

    if not multi_uc_type:
        if uc_type in supported_single_multi_entity_use_cases and (len(all_entities) > 1):
            return get_multi_use_case_output(responses=responses, extra_infos=extra_infos)
        else:
            return get_single_use_case_output(responses=responses, extra_infos=extra_infos)
    else:
        if uc_type in supported_multiple_use_cases:
            return get_multi_use_case_output(responses=responses, extra_infos=extra_infos)
        else:
            return get_single_use_case_output(responses=responses, extra_infos=extra_infos)


def get_single_use_case_output(responses: List[Any], extra_infos: Any):
    results = []
    added_metadata = False
    for response in responses:
        metadata = deepcopy(extra_infos)
        if added_metadata:
            metadata["response_payload"] = None
            metadata["source_description"] = None
        if response["response_type"] == "table":
            metadata["response_type"] = "table"
            results.append(
                TableDocument(
                    TableResponse(
                        column_schema=response["column_schema"],
                        rows=response["rows"],
                        count=response["count"],
                        count_distribution=response["count_distribution"],
                    ),
                    metadata=metadata,
                    synthesize=response["synthesize"],
                    authorized=response.get("authorized", True),
                )
            )
        elif response["response_type"] == "csd_table":
            metadata["response_type"] = "csd_table"
            results.append(
                TableDocument(
                    CSDTableResponse(response["response"]),
                    metadata=metadata,
                    synthesize=response["synthesize"],
                    authorized=response.get("authorized", True),
                )
            )
        elif response["response_type"] == "parentchild_table":
            metadata["response_type"] = "parentchild_table"
            results.append(
                TableDocument(
                    ParentChildTableResponse(response["response"]),
                    metadata=metadata,
                    synthesize=response["synthesize"],
                    authorized=response.get("authorized", True),
                )
            )
        elif response["response_type"] == "text":
            metadata["response_type"] = "text"
            results.append(
                Document(
                    content=response["response"],
                    metadata=metadata,
                    synthesize=response["synthesize"],
                    authorized=response.get("authorized", True),
                    error_docs=response.get("error", False),
                )
            )
        else:
            metadata["response_type"] = "text"
            results.append(
                Document(
                    content=response["response"],
                    metadata={
                        "Title": "S&P Global credit rating",
                        "Section_Name": "Information",
                        **metadata,
                    },
                    synthesize=response["synthesize"],
                    authorized=response.get("authorized", True),
                )
            )
        added_metadata = True
    return results


def get_multi_use_case_output(responses: List[Any], extra_infos: Any):
    results = []
    for response in responses:
        metadata = deepcopy(extra_infos)
        if response["response_type"] == "table":
            metadata["response_type"] = "table"
            results.append(
                TableDocument(
                    TableResponse(
                        column_schema=response["column_schema"],
                        rows=response["rows"],
                        count=response["count"],
                        count_distribution=response["count_distribution"],
                    ),
                    metadata=metadata,
                    synthesize=response["synthesize"],
                    authorized=response.get("authorized", True),
                )
            )
            break
        elif response["response_type"] == "csd_table":
            metadata["response_type"] = "csd_table"
            results.append(
                TableDocument(
                    CSDTableResponse(response["response"]),
                    metadata=metadata,
                    synthesize=response["synthesize"],
                    authorized=response.get("authorized", True),
                )
            )
            break
        elif response["response_type"] == "parentchild_table":
            metadata["response_type"] = "parentchild_table"
            results.append(
                TableDocument(
                    ParentChildTableResponse(response["response"]),
                    metadata=metadata,
                    synthesize=response["synthesize"],
                    authorized=response.get("authorized", True),
                )
            )
            break
    return results
