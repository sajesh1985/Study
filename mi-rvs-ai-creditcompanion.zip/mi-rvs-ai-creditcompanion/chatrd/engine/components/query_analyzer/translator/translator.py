import json
from typing import Optional

# from chatrd.core.aws_utils.bedrock import get_assumed_bedrock_llm_client
from chatrd.core.llm import LCLLMFactory
from chatrd.core.llm.components.message import AIMessage
from chatrd.engine.configuration import Constants, get_config_machinery

config_machinery = get_config_machinery()


class InputModerationTranslator:
    def __init__(
        self,
        model_name: str = Constants.Bedrock.QUESTION_TRANSLATOR_MODEL_NAME,
        temperature: Optional[float] = Constants.Bedrock.QUESTION_TRANSLATOR_TEMPERATURE,
    ):

        self.model_name = model_name
        self.temperature = temperature

    def run(self, query: str):
        self.model = LCLLMFactory(
            region_name=config_machinery.get_config_value(Constants.Bedrock.TRANSLATOR_REGION_NAME)
        ).get_llm(
            deployment_name_or_model_id=config_machinery.get_config_value(self.model_name),
            temperature=config_machinery.get_config_value(self.temperature),
        )

        prompt = """
        # S&P Global Language Identification and Translation System

        You are a professional translator for S&P Global. Your task is to identify the original language of a query and translate it to English, following a specific process.

        ## Task Process:
        1. First, identify the original language of the input query
        2. Then translate the entire query to English
        3. Return the results in a structured JSON format

        ## Language Identification Guidelines:
        - When determining the language, ignore specialized terminology and entity names and focus on only other part of sentence
        - Identify only one predominant language (not mixed or multiple languages)
        - If the query contains text from several languages, identify the predominant language
            example:
                "What is the rating of トヨタ自動車株式会社" is in English
                "アナリシス FODA パラ Apple" is Japanese

        ## Translation Guidelines:
        - Translate the entire query to English, including all terminology and entity names
        - If the query is already in English, return the same text
        - Ensure accurate translation of financial and business terminology

        ## Response Format:
        Return your output in this JSON format only, with no additional text:
        ```
        {"language": "original_language", "translated_text": "translated text"}
        ```

        ## Examples:

        <example_1>
        Input text: "Tesla의 평점은 무엇입니까?"
        Output: {"language": "Korean", "translated_text": "What is rating for Tesla"}
        </example_1>

        <example_2>
        Input text: "特斯拉的评级是多少？"
        Output: {"language": "Mandarin", "translated_text": "What is rating for Tesla"}
        </example_2>

        <example_3>
        Input text: "アナリシス FODA パラ Apple"
        Output: {"language": "Japanese", "translated_text": "SWOT analysis for Apple"}
        </example_3>

        <example_4>
        Input text: "What is the rating of トヨタ自動車株式会社"
        Output: {"language": "English", "translated_text": "What is the rating of Toyota Motor Corporation"}
        </example_4>

        Now process the following query:
        <query>{{user_query}}</query>
        """
        query = prompt.replace("{{user_query}}", query)

        model_response = self.model.invoke(query)

        if isinstance(model_response, AIMessage):
            model_response = model_response.content

        return json.loads(model_response)

    def translator(self, text, language):

        self.model2 = LCLLMFactory(
            region_name=config_machinery.get_config_value(Constants.Bedrock.TRANSLATOR_REGION_NAME)
        ).get_llm(
            deployment_name_or_model_id=config_machinery.get_config_value(
                Constants.Bedrock.GENERAL_TRANSLATION_MODEL_NAME
            ),
            temperature=config_machinery.get_config_value(Constants.Bedrock.GENERAL_TRANSLATION_TEMPERATURE),
        )

        prompt = """
                # Text Translation Task in finance based website
                ## Instructions
                Translate the following text into {{language}}. 
                <rules>
                1. Provide ONLY the translation without any explanations or additional text.
                2. If the text is already in {{language}}, return the original text unchanged.
                3. For specialized financial terminology, use the standard {{language}} terms but include the English term in parentheses where appropriate for clarity.
                4. Maintain all numerical values, dates, and proper names exactly as they appear in the original text.
                5. Preserve the original formatting, including paragraphs, bullet points, and section headers.
                </rules>

                ## Text to Translate
                <text>
                {{text}}
                </text>

                Return only the translation without any preamble or explanation.
        """

        query = prompt.replace("{{language}}", language)
        query = query.replace("{{text}}", text)
        model_response = self.model2.invoke(query)

        if isinstance(model_response, AIMessage):
            model_response = model_response.content
        return model_response
