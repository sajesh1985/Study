from typing import AbstractSet, Any, Collection, List, Literal, Optional, Union

from chatrd.core.document.text_splitters.base import TextSplitter
from chatrd.core.llm.components.tokenizer import Tokenizer


class TokenTextSplitter(TextSplitter):
    """Splitting text to tokens using model tokenizer."""

    def __init__(
        self,
        encoding_name: str = "gpt2",
        model_name: Optional[str] = None,
        allowed_special: Union[Literal["all"], AbstractSet[str]] = None,
        disallowed_special: Union[Literal["all"], Collection[str]] = "all",
        **kwargs: Any,
    ) -> None:
        """Create a new TextSplitter."""
        super().__init__(**kwargs)
        self._tokenizer = Tokenizer(model_name, encoding_name, allowed_special, disallowed_special)

    def split_text(self, text: str) -> List[str]:
        """Splits the input text into smaller chunks based on tokenization.
        It uses a custom tokenizer configuration to:
        - encode the input text into tokens
        - processes the tokens in chunks of a specified size with overlap
        - decodes them back into text chunks

        Args:
            text (str): The input text to be split into smaller chunks.

        Returns:
            List[str]: A list of text chunks, where each chunk is derived from the input.
        """

        input_ids = self._tokenizer.encode(text)
        start_idx = 0
        curr_idx = min(start_idx + self._chunk_size, len(input_ids))
        chunk_ids = input_ids[start_idx:curr_idx]

        splits: List[str] = []
        while start_idx < len(input_ids):
            splits.append(self._tokenizer.decode(chunk_ids))
            if curr_idx == len(input_ids):
                break
            start_idx += self._chunk_size - self._chunk_overlap
            curr_idx = min(start_idx + self._chunk_size, len(input_ids))
            chunk_ids = input_ids[start_idx:curr_idx]
        return splits
