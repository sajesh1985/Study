from typing import List
import logging

from src.synthia.utils.logging_config import configure_logging
from src.synthia.user_profile.user_profile_provider import fetch_user_profile_data, UserProfileData

logger = configure_logging(
    logger_name=__name__,
    log_file="synthia.log",
    module_levels={__name__: logging.DEBUG},  # Set this module to DEBUG
)

async def has_datasource_access(auth_token: str, data_source: str) -> bool:
    """
    Check if user has KOS access to the specified data source.

    Args:
        auth_token (str): The authentication token for API access.
        data_source (str): The data source to check access for.
    Returns:
        bool: True if CreditMemo access is present, False otherwise.
    """
    try:
        user_profile: UserProfileData = await fetch_user_profile_data(auth_token)

        # Check if user is RD_ONLY
        IS_RD_ONLY_USER = 1209 in user_profile["KeyOnlineServices"]

        if data_source == "CreditMemo":
            return 1292 in user_profile["KeyOnlineServices"]
        elif data_source == "Filings - BASEL2 Documents" or \
            data_source == "Transcripts" or \
            data_source == "Investor Presentation" or \
            data_source == "Filings":
            return 1266 in user_profile["KeyOnlineServices"]

        return False
    except Exception as e:
        logger.error(f"Error checking KOS access: {str(e)}")
        return False


async def is_creditmemo_user(auth_token: str) -> bool:
    """
    Check if user has CreditMemo access (KeyOnlineServices contains 1292).
    
    Args:
        auth_token: Authentication token for API request.
        
    Returns:
        bool: True if user has CreditMemo access, False otherwise.
    """
    return await has_datasource_access(auth_token, "CreditMemo")