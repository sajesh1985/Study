﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace Fis.Epp.Fusion.Auth.Models
{
    public enum RequestHeader
    {
        [Description("SessionToken")]
        SessionToken,
        [Description("KeepAliveURL")]
        KeepAliveURL,
        [Description("Correlation-ID")]
        Correlation_ID,
        [Description("Application-ID")]
        Application_ID,
        [Description("Authorization")]
        Authorization,
        [Description("Source-ID")]
        Source_ID,
        [Description("UUID")]
        UUID,
        [Description("Locale")]
        Locale,
        [Description("FE-ID")]
        FE_ID,
        [Description("USER-ID")]
        USER_ID,
        [Description("User-Agent")]
        User_Agent,
        [Description("Context-Token")]
        ContextToken,
        [Description("environment-id")]
        environment_id
    }
    public static class EnumExtension
    {
        public static string GetEnumDescription(this Enum enumValue)
        {
            var fieldInfo = enumValue.GetType().GetField(enumValue.ToString());

            var descriptionAttributes = (DescriptionAttribute[])fieldInfo.GetCustomAttributes(typeof(DescriptionAttribute), false);

            return descriptionAttributes.Length > 0 ? descriptionAttributes[0].Description : enumValue.ToString();
        }
    }
}
