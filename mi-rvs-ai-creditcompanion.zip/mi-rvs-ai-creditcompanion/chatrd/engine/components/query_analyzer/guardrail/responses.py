import json
import logging
from importlib.resources import files

from chatrd.core.thread_utils import submit_to_shared_thread_pool
from chatrd.engine.components.query_analyzer.translator.utils import (
    Get_translation_result,
)
from chatrd.engine.responses import get_default_answer

logger = logging.getLogger(__name__)

path = files("chatrd.engine.components.query_analyzer.guardrail").joinpath("blocked_topic_message_map.json").resolve()

with open(path, "r") as f:
    MESSAGE_MAP = json.load(f)


def map_topic_to_message(blocked_categories):

    if "Client_Support" in blocked_categories:
        return MESSAGE_MAP["Client_Support"]

    else:
        feedback_category = blocked_categories[0]
        return MESSAGE_MAP[feedback_category]


def get_blocked_topic_message(message, guardrail, guardrail_output, translator, original_language, original_message):
    try:
        logger.info(f"Guardrail output: {guardrail_output}")

        if guardrail_output["question_blocked"]:
            # Remove any hallucinated categories
            blocked_categories = guardrail_output["blocked_categories"]
            blocked_categories = [c for c in blocked_categories if c in MESSAGE_MAP.keys()]

            if not blocked_categories:
                # Will occur if LLM marks a question as "blocked" but does not provide any category, or only hallucinated category has been provided
                logger.error(f"Question blocked but no topic provided from {guardrail.model_name}.")
                return get_default_answer(
                    reason="default", original_language=original_language, original_query=original_message
                )

            else:
                message = map_topic_to_message(guardrail_output["blocked_categories"])
                message = Get_translation_result(message, original_language)
                message = message.result()
                logger.info(f"Guardrail intervened for {message}")
                return get_default_answer(
                    reason="custom_message",
                    message=message,
                    original_language=original_language,
                    original_query=original_message,
                )
        else:
            return None

    except TypeError:
        # Will occur if LLM output is not in specified JSON format
        logger.info(f"LLM output incorrectly formatted from {guardrail.model_name}.")
        return get_default_answer(
            reason="default", original_language=original_language, original_query=original_message
        )
