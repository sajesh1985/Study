from typing import Optional

from pydantic import BaseModel


class CriteriaSectorExtractedFields(BaseModel):
    sector: Optional[str] = None


class ResearchSectorExtractedFields(BaseModel):
    entities: Optional[list] = None
