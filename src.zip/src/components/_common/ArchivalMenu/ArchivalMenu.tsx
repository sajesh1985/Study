import { faArchive } from '@fortawesome/free-solid-svg-icons';
import { Size } from '@spglobal/koi-helpers';
import { Icon } from '@spglobal/react-components';
import { useState, useRef, useEffect } from 'react';
import { ArchivalButton, ArchivalIcon } from './ArchivalMenu.styles';
import { useUserTraits } from '@spglobal/userprofileservice';
import { getParamValue } from '@spglobal/dataapiservice/src/dataapi/urlUtilities';
import { useChatRD } from '../../../context/chatrd';

interface ArchivalMenuProps {
  onArchive : (sessionId:string) => void;
  sessionId : string;
  isActive? : boolean;
}

const ArchivalMenu : React.FC<ArchivalMenuProps> = ({ onArchive,sessionId,isActive }) => {
  const [isOpen, setIsOpen] = useState(false);
  const {session} = useChatRD();
  const buttonRef = useRef(null);

  // Handle click outside
  useEffect(() => {
    const handleClickOutside = (event:any) => {
      if (buttonRef.current && !buttonRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleButtonClick = () => {
    if(isOpen)
      {
        if(sessionId !== session)
          {
            onArchive(sessionId);
          }
      }
    setIsOpen(!isOpen);
  };

  const getDisplayMode = (displayMode: number): boolean => {
    const overrideUserDispalyModeValue = getParamValue('darkmode');
    return (
      overrideUserDispalyModeValue === '1' ||
      (!overrideUserDispalyModeValue && displayMode === 1)
    );
  };

  const traits = useUserTraits(['displayMode']);
  const isDarkMode = getDisplayMode(traits?.displayMode);

  return (
    <span style={{paddingTop:'5px'}}>
      <ArchivalButton  className={`chat${isActive == true ? 'active':''}`} ref={buttonRef} onClick={handleButtonClick}>
        {isOpen ? <span title='Archive' style={{marginTop: '-10px'}}><ArchivalIcon><Icon style={{left: '100px;'}} icon={faArchive}
                size={Size.MEDIUM}></Icon></ArchivalIcon></span> : isDarkMode ? <ThreeVerticalDots fill='white'/> : <ThreeVerticalDots fill='current'/>}
                </ArchivalButton>
    </span>
  );
};

const ThreeVerticalDots = (props:any) => (
  <svg height="15" fill={props.fill} viewBox="0 0 24 24" width="24">
    <circle cx="12" cy="5" r="2" />
    <circle cx="12" cy="12" r="2" />
    <circle cx="12" cy="19" r="2" />
  </svg>
);

export default ArchivalMenu;
