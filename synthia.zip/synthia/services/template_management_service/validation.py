from typing import Tuple, Any
from src.synthia.services.template_management_service import CreateCompanyTemplateRequest
from src.synthia.services.template_management_service.dto import UpdateCompanyTemplateRequest
from uuid import UUID


def validate_new(
    metadata: CreateCompanyTemplateRequest,
    existing_if_found: Any | None,
    filenames_to_content: dict
) -> Tuple[bool, str | None]:
    if existing_if_found:
        return False, _template_with_the_same_name_already_exists_message(metadata.company_name, metadata.tile_name)
    if not _template_content_file_exists(metadata.template_config_file_name, filenames_to_content):
        return False, _template_content_file_not_exists_message(metadata.template_config_file_name)
    return True, None


def validate_update(
    company_name: str,
    template_id: UUID,
    metadata: UpdateCompanyTemplateRequest,
    existing_if_found: Any | None,
    non_unique_if_found: Any | None,
    filenames_to_content: dict
) -> Tuple[bool, str | None]:
    if not existing_if_found:
        return False, f'Template metadata for company: {company_name} and id: {template_id} does not exist'
    if non_unique_if_found:
        return False, _template_with_the_same_name_already_exists_message(company_name, metadata.tile_name)
    if not _template_content_file_exists(metadata.template_config_file_name, filenames_to_content):
        return False, _template_content_file_not_exists_message(metadata.template_config_file_name)
    return True, None


def _template_content_file_exists(template_config_file_name: str, filenames_to_content: dict) -> bool:
    return template_config_file_name in filenames_to_content


def _template_with_the_same_name_already_exists_message(company_name: str, tile_name: str) -> str:
    return f'Template metadata for company: {company_name} and tile name: {tile_name} already exists'


def _template_content_file_not_exists_message(template_config_file_name: str) -> str:
    return f'No template content file: {template_config_file_name} exist'