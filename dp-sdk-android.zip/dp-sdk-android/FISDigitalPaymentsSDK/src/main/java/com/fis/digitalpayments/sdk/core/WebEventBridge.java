// Copyright Notice!
// This document is protected under the trade secret and copyright
// laws as the property of Fidelity National Information Services, Inc.
// Copying, reproduction or distribution should be limited and only to
// employees with a “need to know” to do their job.
// Any disclosure of this document to third parties is strictly prohibited.
// © 2017 Fidelity National Information Services.
// All rights reserved worldwide.

package com.fis.digitalpayments.sdk.core;

import android.content.Context;
import androidx.annotation.NonNull;

import com.fis.digitalpayments.sdk.messaging.WebEvent;
import com.fis.digitalpayments.sdk.messaging.WebEventListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * @author e1035413 on 12/27/2016.
 */

public class WebEventBridge extends Bridge {

    private final WebEventListener mWebEventListener;
    private String mNativeMessageHandler;
    private String mNativeMessageHandlerCallbackKey;

    WebEventBridge(@NonNull WebEventListener webEventListener) {
        mWebEventListener = webEventListener;
    }

    @SuppressWarnings("SameReturnValue")
    @Override
    public String getBridgeId() { return "deviceWebEventBridge"; }

    @Override
    public void handleRequest(BridgeRequest bridgeRequest, @SuppressWarnings("unused") BridgeRequestCallback bridgeRequestCallback, @SuppressWarnings("unused") Context context) {
        switch (bridgeRequest.getMethod()) {
            case "raiseEvent":
                raiseEvent(bridgeRequest);
                break;
            case "registerNativeMessageHandler":
                registerNativeMessageHandler(bridgeRequest);
                break;
        }
    }

    private void raiseEvent(BridgeRequest bridgeRequest) {
        String eventId = bridgeRequest.getParams().get("eventId");
        String eventParams = bridgeRequest.getParams().get("eventParams");

        Map<String, String> eventParamMapping = new HashMap<>();
        if (eventParams != null) {
            try {
                JSONObject json = new JSONObject(eventParams);
                Iterator<String> iterator = json.keys();
                while (iterator.hasNext()) {
                    String key = iterator.next();
                    String value = json.getString(key);
                    eventParamMapping.put(key, value);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        BridgeMessage bridgeMessage = BridgeMessage.CreateInformation(BridgeMessageCode.EVENT_RAISED, eventId);
        WebEvent webEvent = new WebEvent(eventId, WebEvent.parseWebEventType(bridgeRequest.getParams()), WebEvent.parseProductType(bridgeRequest.getParams()), bridgeMessage, eventParamMapping);
        mWebEventListener.onEventReceived(webEvent);
    }

    private void registerNativeMessageHandler(BridgeRequest bridgeRequest) {
        mNativeMessageHandler = bridgeRequest.getCallbackMethod();
        mNativeMessageHandlerCallbackKey = bridgeRequest.getCallbackKey();
    }

    public String getClientMessageJavascript(BridgeMessage bridgeMessage) {
        return "javascript:" + mNativeMessageHandler + "(" + BridgeResponse.createJSONResponse(null, null, mNativeMessageHandlerCallbackKey, true, bridgeMessage) + ")";
    }
}
