import json
import logging
import os
import random
import re

from chatrd.engine.components.query_analyzer.sector_extractor import SectorExtractor
from chatrd.engine.components.query_analyzer.sector_extractor.utils import CriteriaSectorExtractedFields, ResearchSectorExtractedFields

RANDOM_SEED = 42


def setup_logging():
    import logging

    logging.basicConfig(
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        level=logging.INFO,
    )
    logger = logging.getLogger(__name__)
    return logger

logger = setup_logging()


def extract_keys(template):
    keys = re.findall(r"{(.*?)}", template)
    return keys


def get_dictionary_from_folders(directory_path: str):
    json_dict = {}
    for filename in os.listdir(directory_path):
        if filename.endswith(".json"):
            file_path = os.path.join(directory_path, filename)
            with open(file_path, "r") as file:
                json_content = json.load(file)
            key = os.path.splitext(filename)[0]
            json_dict[key] = json_content
    return json_dict


def question_generator(template_entities, template_questions, num_runs=1):
    questions = {}
    for key, values in template_questions.items():
        templates = values
        if key == "credit_memo":
            n_times = 1
        if key == "criteria":
            n_times = 1
        elif key == "deals_tranche":
            n_times = 1
        elif key == "definition":
            n_times = 1
        elif key == "esg":
            n_times = 1
        elif key == "financials":
            n_times = 1
        elif key == "general":
            n_times = 4
        elif key == "macro":
            n_times = 4
        elif key == "outlook":
            n_times = 4
        elif key == "peers":
            n_times = 1
        elif key == "query":
            n_times = 4
        elif key == "ratings":
            n_times = 1
        elif key == "research":
            n_times = 1
        elif key == "sNw":
            n_times = 1
        else:
            n_times = 1
        for template in templates:
            if n_times == 0:
                break
            unique_questions = set()
            N = num_runs * n_times
            for _ in range(N):
                present_keys = extract_keys(template)
                all_pairs = {}
                for mp_key in present_keys:
                    all_pairs[mp_key] = random.choice(
                        template_entities[mp_key],
                    )
                question = template.format(**all_pairs)
                unique_questions.add((tuple(all_pairs.items()), question))
            if key in questions:
                questions[key].extend(list(unique_questions))
            else:
                questions[key] = list(unique_questions)
    return questions


def load_model(model_id):
    return SectorExtractor(model_name=model_id, temperature=0.0001)
    

def load_data(input_path, select_keys, class_id, samples_per_class, print_info=False):

    with open(input_path) as f:
        questions = json.load(f)

    # keep only the classes with number of questions >0
    questions = {key: value for key, value in questions.items() if len(value) > 0}

    # take all or take a subset
    if samples_per_class == -1:
        questions_subset = questions
    else:
        questions_subset = generate_random_subset_of_questions(input_questions = questions, keep_keys = select_keys, class_id = class_id, count_per_class = samples_per_class)
    
    if print_info:
        logger.info(f"Total generated questions: {sum([len(value) for value in questions.values()])}")
        logger.info(dict_lengths(questions))
        logger.info(f"No. of questions: {sum([len(value) for value in questions_subset.values()])}")
        logger.info(dict_lengths(questions_subset))

    return questions_subset
    

def dict_lengths(input_dict):
    dict_lengths = {}
    for key, value in input_dict.items():
        if isinstance(value, list):
            dict_lengths[key] = len(value)
    return dict_lengths
    

def convert_list_to_dict(input_list):
    return {item[0]: item[1] for item in input_list}


def keys_in_list(keep_keys, input_key_list):
    # input_key_list -> [['sector', 'Industrials'], ['industry', 'Automotive'], ...]
    input_keys = convert_list_to_dict(input_key_list).keys()
    for keep_key in keep_keys:
        if keep_key in input_keys:
            return True
    return False


def generate_random_subset_of_questions(input_questions, keep_keys, class_id, count_per_class = 1):
    random.seed(RANDOM_SEED)

    questions_subset_temp = {uc_type: questions_list for uc_type, questions_list in input_questions.items() if uc_type != 'criteria'}

    questions_temp_sector = {}
    questions_temp_all = {}
    for uc_type, questions_list in questions_subset_temp.items():
        # {'general': [ [['sector', 'industry'], ['question containing sector and industry']], [...], ...]}
        for item in questions_list:
            # if the template question contains any of keep_keys
            if keys_in_list(keep_keys, item[0]):
                if uc_type not in questions_temp_sector.keys():
                    questions_temp_sector[uc_type] = []
                    questions_temp_sector[uc_type].append(item) 
                else:
                    questions_temp_sector[uc_type].append(item)
            # if the template question does not contain any of keep_keys
            else:
                if uc_type not in questions_temp_all.keys():
                    questions_temp_all[uc_type] = []
                    questions_temp_all[uc_type].append(item) 
                else:
                    questions_temp_all[uc_type].append(item)

    if 'non' in class_id:
        return {use_case: random.sample(list(value), count_per_class) for use_case, value in questions_temp_all.items()}
    else:
        return {use_case: random.sample(list(value), count_per_class) for use_case, value in questions_temp_sector.items()}
    

def generate_ground_truth_data_for_entity_extraction(input_keys_dict):
    target_keys = input_keys_dict.keys()
    sector = 'None' if 'sector' not in target_keys else input_keys_dict['sector']
    subsector = 'None' if 'subsector' not in target_keys else input_keys_dict['subsector']
    industry = 'None' if 'industry' not in target_keys else input_keys_dict['industry']
    if industry != 'None':
        return ResearchSectorExtractedFields(entities=[industry])
    elif subsector != 'None':
        return ResearchSectorExtractedFields(entities=[subsector])
    elif sector != 'None':
        return ResearchSectorExtractedFields(entities=[sector])
    return ResearchSectorExtractedFields(entities=[])


def print_result_entities(ground_truth, prediction):
    return ground_truth['question'] + "\n" + f"{ground_truth['output'].entities if hasattr(ground_truth['output'], 'entities') else ''} --- {prediction['output'].entities if hasattr(prediction['output'], 'entities') else ''}" + "\n\n"


def entity_similarity(pred, gt):
    pred, gt = pred.lower(), gt.lower()
    pred, gt = re.sub(r'[^\w\s]', ' ', pred), re.sub(r'[^\w\s]', ' ', gt)
    pred_words, gt_words = pred.split(), gt.split()
    ind = 0
    # print(pred_words, gt_words)
    for pred_word in pred_words:
        for gt_word in gt_words:
            if pred_word in gt_word:
                ind += 1
    if ind >= len(pred_words):
        return True
    return False


def compare_entities(gt_object, pred_object):
    if gt_object.__class__.__name__ != pred_object.__class__.__name__: 
        return False
    if isinstance(gt_object, ResearchSectorExtractedFields):
        if gt_object == pred_object:
            return True
        if len(gt_object.entities) == 0 and len(pred_object.entities) != 0:
            return False
        elif len(gt_object.entities) != 0 and len(pred_object.entities) == 0:
            return False
        entity_counts = {entity: 0 for entity in pred_object.entities}
        for pred_entity in pred_object.entities:
            for gt_entity in gt_object.entities:
                if entity_similarity(pred_entity, gt_entity):
                    entity_counts[pred_entity] += 1
                # else:
                    # print(f"NOOO {pred_entity} --- {gt_entity}")
        # print(entity_counts)
        if all(count > 0 for count in entity_counts.values()):
            return True
        return False


def compare_entities_and_save_results_to_txt(sector_extractor_ground_truth, sector_extractor_predictions, model_id, execution_time, prompt_id, class_id, output_path):
    try:
        os.mkdir(f'{output_path}/{model_id}')
    except FileExistsError:
        pass

    correct_count = 0
    incorrect_count = 0
    output_text = ""
    output_text_false = ""
    for idx in sector_extractor_predictions.keys():
        result = compare_entities(sector_extractor_ground_truth[idx]['output'], sector_extractor_predictions[idx]['output'])
        if result:
            correct_count += 1
            output_text += "TRUE\n" + print_result_entities(sector_extractor_ground_truth[idx], sector_extractor_predictions[idx])
        else:
            incorrect_count += 1
            res_temp = "FALSE\n" + print_result_entities(sector_extractor_ground_truth[idx], sector_extractor_predictions[idx])
            output_text += res_temp
            output_text_false += res_temp

    with open(f'{output_path}/{model_id}/{class_id}_{prompt_id}.txt', 'w') as file:
        file.write(f"Model: {model_id}\nEval data id: {class_id}\nAverage time per sample: {round(execution_time, 2)} sec\n")
        file.write(f"Accuracy: {round(correct_count / (correct_count + incorrect_count + 1e-10), 2)}\n")
        file.write(f"No. of samples (correct/incorrect): {correct_count + incorrect_count} ({correct_count}/{incorrect_count})\n")
        file.write("--------------------------\n\n")
        file.write(output_text)

    with open(f'{output_path}/{model_id}/{class_id}_false_{prompt_id}.txt', 'w') as file:
        file.write(f"Model: {model_id}\nEval data id: {class_id}\nAverage time per sample: {round(execution_time, 2)} sec\n")
        file.write(f"Accuracy: {round(correct_count / (correct_count + incorrect_count + 1e-10), 2)}\n")
        file.write(f"No. of samples (correct/incorrect): {correct_count + incorrect_count} ({correct_count}/{incorrect_count})\n")
        file.write("--------------------------\n\n")
        file.write(output_text_false)

    logger.info(f"--- Results saved to {output_path}/{model_id}/{class_id}_{prompt_id}.txt")
    logger.info(f"--- Results saved to {output_path}/{model_id}/{class_id}_false_{prompt_id}.txt")


def id_2_sec(sector, subsector, industry):
    return id_to_sec_mapping.get(sector), id_to_sub_mapping.get(subsector), id_to_ind_mapping.get(industry)
    

def sec_2_id(sector, subsector, industry):
    return sec_to_id_mapping.get(sector), sub_to_id_mapping.get(subsector), ind_to_id_mapping.get(industry)




COMPLEX_QUESTIONS = {
    "complex_questions": [
        [
            [
                [
                    "se_industry",
                    "Health Care"
                ]
            ],
            "What are the companies in the health care?",
        ],
        [
            [
                [
                    "se_industry",
                    "Property & Real Estate"
                ]
            ],
            "Can you list all the companies in the real estate sector?",
        ],
        [
            [
                [
                    "se_subsector",
                    "Sovereigns"
                ]
            ],
            "List all the companies in the soverign sector",
        ],
        [
            [
                [
                    "se_subsector",
                    "Life"
                ]
            ],
            "Can you provide a list of companies in the life insurance sector in the USA?",
        ],
        [
            [
                [
                    "se_industry",
                    "Energy"
                ]
            ],
            "What are some companies that have been upgraded in the energy sector?",
        ],
        [
            [
                [
                    "se_industry",
                    "Electric"
                ]
            ],
            "What are some companies that have been upgraded in the electric sector?",
        ],
        [
            [
                [
                    "se_subsector",
                    "Banks"
                ]
            ],
            "Show me all the banks in North America with an A rating",
        ],
        [
            [
                [
                    "se_subsector",
                    "Transportation"
                ]
            ],
            "List all the companies in the transportation sector that have been downgraded",
        ],
        [
            [
                [
                    "se_subsector",
                    "Energy and Oil & Gas"
                ]
            ],
            "Can you provide a list of companies in the oil industry in the USA with an A rating",
        ],
        [
            [
                [
                    "se_sector",
                    "Insurance"
                ]
            ],
            "Can you list all the companies in the insurance sector?",
        ],
        [
            [
                [
                    "se_subsector",
                    "Health"
                ]
            ],
            "Can you provide a list of companies in the health insurance?",
        ],
        [
            [
                [
                    "se_subsector",
                    "Power Generation and Transmission"
                ]
            ],
            "List the names of companies operating in the power generation sector.",
        ],
        [
            [
                [
                    "se_sector",
                    "Infrastructure"
                ]
            ],
            "List companies operating in multiple infrastructure sectors.",
        ],
        [
            [
                [
                    "se_subsector",
                    "Other Infrastructure Entities"
                ]
            ],
            "List companies operating in the infrastructure sector that are not involved in energy, finance, energy production, project development, social services, transportation, or public utilities.",
        ],
        [
            [
                [
                    "se_sector",
                    "U.S. Public Finance"
                ]
            ],
            "List companies in public finance business in USA.",
        ],
        [
            [
                [
                    "se_subsector",
                    "Transportation"
                ]
            ],
            "Show me all the companies in transportation business that have been downgraded",
        ],
        [
            [
                [
                    "se_subsector",
                    "Industrials"
                ]
            ],
            "Can you list all the industrial companies?",
        ],
        [
            [
                [
                    "se_subsector",
                    "Commercial Mortgage-Backed Securities"
                ]
            ],
            "List all companies operating in the field of mortgage-backed securities",
        ],       
    ],

    "business_questions": [
        [
            [
                [
                    "se_sector",
                    "Corporates"
                ]
            ],
            "How many of the corporates in the U.S. are rated?",
        ],
        [
            [
                [
                    "se_industry",
                    "Automobiles & Components"
                ]
            ],
            "Give me a list of spec grade (rising stars, fallen angel) automotive companies",
        ],
        [
            [
                [
                    "se_industry",
                    "Capital Goods"
                ]
            ],
            "How many entities are rated within Capital Goods",
        ],
        [
            [
                [
                    "se_industry",
                    "Chemicals"
                ]
            ],
            "How many Chemicals companies have an S&P Rating?",
        ],
        [
            [
                [
                    "se_industry",
                    "Retailing"
                ]
            ],
            "Give me a list of retail companies located in Europe that defaulted last year",
        ],
        [
            [
                [
                    "se_subsector",
                    "Transportation"
                ]
            ],
            "List all companies sector Transportation having BB Rating",
        ],
        [
            [
                [
                    "se_subsector",
                    "Bond"
                ]
            ],
            "Give me the list of bond insurance companies from Europe",
        ],
        [
            [
                [
                    "se_subsector",
                    "Health"
                ]
            ],
            "Give me the list of health insurance companies from Europe",
        ],
        [
            [
                [
                    "se_subsector",
                    "Property/ Casualty"
                ]
            ],
            "Give me the list of property insurance companies from Europe",
        ],
        [
            [
                [
                    "se_subsector",
                    "Reinsurance/ Specialty"
                ]
            ],
            "Give me the list of reinsurance companies from Europe",
        ]
    ]
}


SEC_SUB_IND_MAPPING = [['Corporates', 'Industrials', 'Aerospace & Defense'], ['Corporates', 'Industrials', 'Automobiles & Components'], ['Corporates', 'Industrials', 'Building Materials'], ['Corporates', 'Industrials', 'Business and Consumer Services'], ['Corporates', 'Industrials', 'Capital Goods'], ['Corporates', 'Industrials', 'Chemicals'], ['Corporates', 'Industrials', 'Commercial & Professional Services'], ['Corporates', 'Industrials', 'Consumer Products'], ['Corporates', 'Industrials', 'Containers & Packaging'], ['Corporates', 'Industrials', 'Energy'], ['Corporates', 'Industrials', 'Health Care'], ['Corporates', 'Industrials', 'Homebuilding'], ['Corporates', 'Industrials', 'Hotels & Gaming'], ['Corporates', 'Industrials', 'Information Technology'], ['Corporates', 'Industrials', 'Media & Entertainment'], ['Corporates', 'Industrials', 'Metals & Mining'], ['Corporates', 'Industrials', 'None'], ['Corporates', 'Industrials', 'Paper & Forest Products'], ['Corporates', 'Industrials', 'Property & Real Estate'], ['Corporates', 'Industrials', 'Retailing'], ['Corporates', 'Industrials', 'Telecom Services'], ['Corporates', 'Industrials', 'Transportation'], ['Corporates', 'None', 'None'], ['Corporates', 'Project Finance', 'Industrial'], ['Corporates', 'Project Finance', 'Leisure & Gaming'], ['Corporates', 'Project Finance', 'Natural Resources/ Mining'], ['Corporates', 'Project Finance', 'None'], ['Corporates', 'Project Finance', 'Oil & Gas'], ['Corporates', 'Project Finance', 'Power'], ['Corporates', 'Project Finance', 'Public Finance Initiative/ Real Estate'], ['Corporates', 'Project Finance', 'Telecom'], ['Corporates', 'Project Finance', 'Transport'], ['Corporates', 'Utilities', 'Electric'], ['Corporates', 'Utilities', 'Gas'], ['Corporates', 'Utilities', 'Multi'], ['Corporates', 'Utilities', 'None'], ['Corporates', 'Utilities', 'Water'], ['Financial Institutions', 'Asset Managers', 'None'], ['Financial Institutions', 'Banks', 'None'], ['Financial Institutions', 'Broker-Dealers', 'None'], ['Financial Institutions', 'Covered Bonds', 'None'], ['Financial Institutions', 'Finance Companies', 'None'], ['Financial Institutions', 'None', 'None'], ['Financial Institutions', 'Others', 'None'], ['Governments', 'International Public Finance', 'None'], ['Governments', 'None', 'None'], ['Governments', 'Sovereign Related', 'None'], ['Governments', 'Sovereigns', 'None'], ['Infrastructure', 'Energy and Oil & Gas', 'Energy and Oil & Gas - Other Companies'], ['Infrastructure', 'Energy and Oil & Gas', 'Liquefied Natural Gas'], ['Infrastructure', 'Energy and Oil & Gas', 'Midstream Energy Companies'], ['Infrastructure', 'Energy and Oil & Gas', 'None'], ['Infrastructure', 'Energy and Oil & Gas', 'Oil & Gas Projects'], ['Infrastructure', 'Energy and Oil & Gas', 'Refining Companies'], ['Infrastructure', 'International Public Finance', 'None'], ['Infrastructure', 'None', 'None'], ['Infrastructure', 'Other Infrastructure Entities', 'None'], ['Infrastructure', 'Power Generation and Transmission', 'None'], ['Infrastructure', 'Power Generation and Transmission', 'Power Companies'], ['Infrastructure', 'Power Generation and Transmission', 'Projects - Conventional Power'], ['Infrastructure', 'Power Generation and Transmission', 'Projects - Power & Other'], ['Infrastructure', 'Power Generation and Transmission', 'Projects - Renewables'], ['Infrastructure', 'Project Developers', 'None'], ['Infrastructure', 'Social', 'Entertainment'], ['Infrastructure', 'Social', 'Hospitals'], ['Infrastructure', 'Social', 'Housing'], ['Infrastructure', 'Social', 'None'], ['Infrastructure', 'Social', 'Schools'], ['Infrastructure', 'Social', 'Social - Other'], ['Infrastructure', 'Transportation', 'Airports'], ['Infrastructure', 'Transportation', 'None'], ['Infrastructure', 'Transportation', 'Ports'], ['Infrastructure', 'Transportation', 'Railroads'], ['Infrastructure', 'Transportation', 'Roads, Bridges, & Tunnels'], ['Infrastructure', 'Transportation', 'Transportation - Diversified & Other'], ['Infrastructure', 'Utilities', 'Electric'], ['Infrastructure', 'Utilities', 'Gas'], ['Infrastructure', 'Utilities', 'Multi'], ['Infrastructure', 'Utilities', 'None'], ['Infrastructure', 'Utilities', 'Water'], ['Insurance', 'Bond', 'None'], ['Insurance', 'Health', 'None'], ['Insurance', 'Life', 'None'], ['Insurance', 'None', 'None'], ['Insurance', 'Property/ Casualty', 'None'], ['Insurance', 'Reinsurance/ Specialty', 'None'], ['Structured Finance', 'Asset-Backed Commercial Paper', 'None'], ['Structured Finance', 'Asset-Backed Securities', 'None'], ['Structured Finance', 'Commercial Mortgage-Backed Securities', 'None'], ['Structured Finance', 'Covered Bonds', 'None'], ['Structured Finance', 'None', 'None'], ['Structured Finance', 'Residential Mortgage-Backed Securities', 'None'], ['Structured Finance', 'Servicer Evaluations', 'None'], ['Structured Finance', 'Structured Credit', 'None'], ['U.S. Public Finance', 'Education', 'Auxiliary Enterprises'], ['U.S. Public Finance', 'Education', 'Cash Flow Notes'], ['U.S. Public Finance', 'Education', 'Charter Schools'], ['U.S. Public Finance', 'Education', 'Community Colleges and Districts'], ['U.S. Public Finance', 'Education', 'Independent Schools'], ['U.S. Public Finance', 'Education', 'None'], ['U.S. Public Finance', 'Education', 'Private Universities'], ['U.S. Public Finance', 'Education', 'Public Universities'], ['U.S. Public Finance', 'Healthcare', 'Hospital Districts'], ['U.S. Public Finance', 'Healthcare', 'Human Service Providers'], ['U.S. Public Finance', 'Healthcare', 'None'], ['U.S. Public Finance', 'Healthcare', 'Senior Living'], ['U.S. Public Finance', 'Healthcare', 'U.S. Not-for-Profit Acute Healthcare Standalones'], ['U.S. Public Finance', 'Healthcare', 'U.S. Not-for-Profit Acute Healthcare Systems'], ['U.S. Public Finance', 'Housing', 'Capital Fund Financing Programs'], ['U.S. Public Finance', 'Housing', 'Community Development Financial Institutions GO Debt'], ['U.S. Public Finance', 'Housing', 'Community Development Financial Institutions ICR'], ['U.S. Public Finance', 'Housing', 'Federally Enhanced Housing - Credit Enhancement Instruments'], ['U.S. Public Finance', 'Housing', 'Federally Enhanced Housing - FHA-Insured'], ['U.S. Public Finance', 'Housing', 'Federally Enhanced Housing - FHA-Insured Pass-Through'], ['U.S. Public Finance', 'Housing', 'Federally Enhanced Housing - Multifamily MBS'], ['U.S. Public Finance', 'Housing', 'Federally Enhanced Housing - Single-Family MBS'], ['U.S. Public Finance', 'Housing', 'Federally Enhanced Housing - Single-Family MBS Pass-Through Programs'], ['U.S. Public Finance', 'Housing', 'Federally Enhanced Housing - Single-Family Managed MBS Programs'], ['U.S. Public Finance', 'Housing', 'Housing Finance Agencies GO Debt'], ['U.S. Public Finance', 'Housing', 'Housing Finance Agencies ICR'], ['U.S. Public Finance', 'Housing', 'Interest Only'], ['U.S. Public Finance', 'Housing', 'Mortgage Revenue Bond Programs'], ['U.S. Public Finance', 'Housing', 'None'], ['U.S. Public Finance', 'Housing', 'Rental Housing Bonds - Age Restricted Housing'], ['U.S. Public Finance', 'Housing', 'Rental Housing Bonds - Mobile Home Parks'], ['U.S. Public Finance', 'Housing', 'Rental Housing Bonds - Multifamily Managed Pools'], ['U.S. Public Finance', 'Housing', 'Rental Housing Bonds - Multifamily Static Pools'], ['U.S. Public Finance', 'Housing', 'Rental Housing Bonds - Privatized Military Housing'], ['U.S. Public Finance', 'Housing', 'Rental Housing Bonds - Section 8 Housing'], ['U.S. Public Finance', 'Housing', 'Rental Housing Bonds - Unenhanced Housing'], ['U.S. Public Finance', 'Housing', 'Single-Family Whole Loan Programs'], ['U.S. Public Finance', 'Housing', 'Social Enterprise Lending Organizations ICR'], ['U.S. Public Finance', 'Housing', 'U.S. Social Housing Providers and Public Housing Authorities'], ['U.S. Public Finance', 'Local Government', 'Cash Flow Notes'], ['U.S. Public Finance', 'Local Government', 'Federally Backed Leases'], ['U.S. Public Finance', 'Local Government', 'GO Hospital Districts'], ['U.S. Public Finance', 'Local Government', 'GO Municipalities & Counties'], ['U.S. Public Finance', 'Local Government', 'GO School Districts'], ['U.S. Public Finance', 'Local Government', 'GO Special Districts'], ['U.S. Public Finance', 'Local Government', 'GO Water Districts'], ['U.S. Public Finance', 'Local Government', 'Lottery Revenue'], ['U.S. Public Finance', 'Local Government', 'Miscellaneous Tax'], ['U.S. Public Finance', 'Local Government', 'Municipal Utility Districts'], ['U.S. Public Finance', 'Local Government', 'None'], ['U.S. Public Finance', 'Local Government', 'Priority Lien'], ['U.S. Public Finance', 'Local Government', 'Prison Project Revenue'], ['U.S. Public Finance', 'Local Government', 'Special Assessments'], ['U.S. Public Finance', 'Local Government', 'State Enhancement Programs'], ['U.S. Public Finance', 'Local Government', 'Tax Increment'], ['U.S. Public Finance', 'Local Government', 'Tribes & Nations'], ['U.S. Public Finance', 'None', 'None'], ['U.S. Public Finance', 'Not-for-Profit', 'None'], ['U.S. Public Finance', 'Not-for-Profit', 'Not-for-Profit'], ['U.S. Public Finance', 'Pooled', 'None'], ['U.S. Public Finance', 'Pooled', 'Strong Link'], ['U.S. Public Finance', 'Pooled', 'Weak Link'], ['U.S. Public Finance', 'Pooled', 'Wholesale Utility'], ['U.S. Public Finance', 'Public Power', 'None'], ['U.S. Public Finance', 'Public Power', 'Retail Electric & Gas'], ['U.S. Public Finance', 'Public Power', 'Rural Electric Cooperatives'], ['U.S. Public Finance', 'Public Power', 'Wholesale Electric'], ['U.S. Public Finance', 'States', 'Lottery Revenue'], ['U.S. Public Finance', 'States', 'Miscellaneous Tax'], ['U.S. Public Finance', 'States', 'None'], ['U.S. Public Finance', 'States', 'Pension Funds'], ['U.S. Public Finance', 'States', 'Priority Lien'], ['U.S. Public Finance', 'States', 'States'], ['U.S. Public Finance', 'Transportation', 'Cash Flow Notes'], ['U.S. Public Finance', 'Transportation', 'Grant Anticipation Revenue Vehicles'], ['U.S. Public Finance', 'Transportation', 'Infrastructure'], ['U.S. Public Finance', 'Transportation', 'None'], ['U.S. Public Finance', 'Transportation', 'Priority Lien'], ['U.S. Public Finance', 'Water & Sewer', 'None'], ['U.S. Public Finance', 'Water & Sewer', 'Solid Waste'], ['U.S. Public Finance', 'Water & Sewer', 'State Revolving Fund Pools'], ['U.S. Public Finance', 'Water & Sewer', 'Water-Sewer Independent Wholesale'], ['U.S. Public Finance', 'Water & Sewer', 'Waterworks, Sanitary Sewer & Drainage Utility Systems']]


id_to_sec_mapping = {379: 'Corporates', 416: 'Financial Institutions', 422: 'Insurance', 428: 'Governments', 430: 'U.S. Public Finance', 442: 'Structured Finance', 450: 'Infrastructure'}

id_to_sub_mapping = {380: 'Industrials', 402: 'Utilities', 407: 'Project Finance', 417: 'Asset Managers', 418: 'Banks', 419: 'Broker-Dealers', 420: 'Finance Companies', 421: 'Others', 423: 'Bond', 424: 'Health', 425: 'Life', 426: 'Property/ Casualty', 427: 'Reinsurance/ Specialty', 429: 'International Public Finance', 440: 'Sovereigns', 441: 'Sovereign Related', 443: 'Asset-Backed Commercial Paper', 444: 'Asset-Backed Securities', 445: 'Commercial Mortgage-Backed Securities', 446: 'Covered Bonds', 447: 'Residential Mortgage-Backed Securities', 448: 'Structured Credit', 449: 'Servicer Evaluations', 451: 'Energy and Oil & Gas', 452: 'Power Generation and Transmission', 453: 'Social', 454: 'Transportation', 455: 'Utilities', 456: 'Project Developers', 457: 'International Public Finance', 458: 'Other Infrastructure Entities', 482: 'Covered Bonds', 1320: 'States', 1326: 'Local Government', 1348: 'Healthcare', 1354: 'Education', 1361: 'Housing', 1385: 'Pooled', 1389: 'Public Power', 1393: 'Transportation', 1398: 'Water & Sewer', 1404: 'Not-for-Profit'}

id_to_ind_mapping = {381: 'Aerospace & Defense', 382: 'Automobiles & Components', 383: 'Building Materials', 384: 'Business and Consumer Services', 385: 'Capital Goods', 386: 'Chemicals', 387: 'Commercial & Professional Services', 388: 'Consumer Products', 389: 'Containers & Packaging', 390: 'Energy', 391: 'Health Care', 392: 'Homebuilding', 393: 'Hotels & Gaming', 394: 'Information Technology', 395: 'Media & Entertainment', 396: 'Metals & Mining', 397: 'Paper & Forest Products', 398: 'Property & Real Estate', 399: 'Retailing', 400: 'Telecom Services', 401: 'Transportation', 403: 'Electric', 404: 'Gas', 405: 'Multi', 406: 'Water', 408: 'Industrial', 409: 'Leisure & Gaming', 410: 'Natural Resources/ Mining', 411: 'Oil & Gas', 412: 'Power', 413: 'Public Finance Initiative/ Real Estate', 414: 'Telecom', 415: 'Transport', 459: 'Liquefied Natural Gas', 460: 'Midstream Energy Companies', 461: 'Oil & Gas Projects', 462: 'Refining Companies', 463: 'Energy and Oil & Gas - Other Companies', 464: 'Power Companies', 465: 'Projects - Conventional Power', 466: 'Projects - Renewables', 467: 'Projects - Power & Other', 468: 'Entertainment', 469: 'Hospitals', 470: 'Housing', 471: 'Schools', 472: 'Social - Other', 473: 'Airports', 474: 'Ports', 475: 'Railroads', 476: 'Roads, Bridges, & Tunnels', 477: 'Transportation - Diversified & Other', 478: 'Electric', 479: 'Gas', 480: 'Multi', 481: 'Water', 1321: 'States', 1322: 'Priority Lien', 1323: 'Lottery Revenue', 1324: 'Miscellaneous Tax', 1325: 'Pension Funds', 1327: 'GO Municipalities & Counties', 1328: 'Tribes & Nations', 1329: 'GO School Districts', 1331: 'GO Hospital Districts', 1332: 'GO Special Districts', 1333: 'GO Water Districts', 1334: 'Municipal Utility Districts', 1335: 'Priority Lien', 1336: 'Federally Backed Leases', 1337: 'Lottery Revenue', 1338: 'Miscellaneous Tax', 1339: 'Prison Project Revenue', 1340: 'Special Assessments', 1341: 'Tax Increment', 1342: 'State Enhancement Programs', 1343: 'Cash Flow Notes', 1345: 'Charter Schools', 1346: 'Community Colleges and Districts', 1347: 'Independent Schools', 1349: 'U.S. Not-for-Profit Acute Healthcare Standalones', 1350: 'U.S. Not-for-Profit Acute Healthcare Systems', 1351: 'Hospital Districts', 1352: 'Human Service Providers', 1353: 'Senior Living', 1355: 'Public Universities', 1356: 'Private Universities', 1357: 'Not-for-Profit', 1358: 'Auxiliary Enterprises', 1360: 'Cash Flow Notes', 1362: 'Rental Housing Bonds - Multifamily Static Pools', 1363: 'Rental Housing Bonds - Age Restricted Housing', 1364: 'Federally Enhanced Housing - Credit Enhancement Instruments', 1365: 'Federally Enhanced Housing - Single-Family MBS Pass-Through Programs', 1366: 'Federally Enhanced Housing - Multifamily MBS', 1367: 'Capital Fund Financing Programs', 1368: 'Community Development Financial Institutions GO Debt', 1369: 'Community Development Financial Institutions ICR', 1370: 'Federally Enhanced Housing - Single-Family MBS', 1371: 'Rental Housing Bonds - Section 8 Housing', 1372: 'Federally Enhanced Housing - FHA-Insured', 1373: 'Federally Enhanced Housing - FHA-Insured Pass-Through', 1374: 'Housing Finance Agencies ICR', 1375: 'Interest Only', 1376: 'Rental Housing Bonds - Mobile Home Parks', 1377: 'Federally Enhanced Housing - Single-Family Managed MBS Programs', 1378: 'Rental Housing Bonds - Privatized Military Housing', 1379: 'Single-Family Whole Loan Programs', 1380: 'Housing Finance Agencies GO Debt', 1381: 'Social Enterprise Lending Organizations ICR', 1382: 'U.S. Social Housing Providers and Public Housing Authorities', 1383: 'Rental Housing Bonds - Unenhanced Housing', 1384: 'Rental Housing Bonds - Multifamily Managed Pools', 1386: 'Strong Link', 1387: 'Weak Link', 1388: 'Wholesale Utility', 1390: 'Retail Electric & Gas', 1391: 'Wholesale Electric', 1392: 'Rural Electric Cooperatives', 1394: 'Infrastructure', 1395: 'Priority Lien', 1396: 'Grant Anticipation Revenue Vehicles', 1397: 'Cash Flow Notes', 1399: 'Waterworks, Sanitary Sewer & Drainage Utility Systems', 1400: 'Water-Sewer Independent Wholesale', 1401: 'Solid Waste', 1402: 'State Revolving Fund Pools', 1406: 'Mortgage Revenue Bond Programs'}

sec_to_id_mapping = {'Corporates': 379, 'Financial Institutions': 416, 'Insurance': 422, 'Governments': 428, 'U.S. Public Finance': 430, 'Structured Finance': 442, 'Infrastructure': 450}

sub_to_id_mapping = {'Industrials': 380, 'Utilities': 455, 'Project Finance': 407, 'Asset Managers': 417, 'Banks': 418, 'Broker-Dealers': 419, 'Finance Companies': 420, 'Others': 421, 'Bond': 423, 'Health': 424, 'Life': 425, 'Property/ Casualty': 426, 'Reinsurance/ Specialty': 427, 'International Public Finance': 457, 'Sovereigns': 440, 'Sovereign Related': 441, 'Asset-Backed Commercial Paper': 443, 'Asset-Backed Securities': 444, 'Commercial Mortgage-Backed Securities': 445, 'Covered Bonds': 482, 'Residential Mortgage-Backed Securities': 447, 'Structured Credit': 448, 'Servicer Evaluations': 449, 'Energy and Oil & Gas': 451, 'Power Generation and Transmission': 452, 'Social': 453, 'Transportation': 1393, 'Project Developers': 456, 'Other Infrastructure Entities': 458, 'States': 1320, 'Local Government': 1326, 'Healthcare': 1348, 'Education': 1354, 'Housing': 1361, 'Pooled': 1385, 'Public Power': 1389, 'Water & Sewer': 1398, 'Not-for-Profit': 1404}

ind_to_id_mapping = {'Aerospace & Defense': 381, 'Automobiles & Components': 382, 'Building Materials': 383, 'Business and Consumer Services': 384, 'Capital Goods': 385, 'Chemicals': 386, 'Commercial & Professional Services': 387, 'Consumer Products': 388, 'Containers & Packaging': 389, 'Energy': 390, 'Health Care': 391, 'Homebuilding': 392, 'Hotels & Gaming': 393, 'Information Technology': 394, 'Media & Entertainment': 395, 'Metals & Mining': 396, 'Paper & Forest Products': 397, 'Property & Real Estate': 398, 'Retailing': 399, 'Telecom Services': 400, 'Transportation': 401, 'Electric': 478, 'Gas': 479, 'Multi': 480, 'Water': 481, 'Industrial': 408, 'Leisure & Gaming': 409, 'Natural Resources/ Mining': 410, 'Oil & Gas': 411, 'Power': 412, 'Public Finance Initiative/ Real Estate': 413, 'Telecom': 414, 'Transport': 415, 'Liquefied Natural Gas': 459, 'Midstream Energy Companies': 460, 'Oil & Gas Projects': 461, 'Refining Companies': 462, 'Energy and Oil & Gas - Other Companies': 463, 'Power Companies': 464, 'Projects - Conventional Power': 465, 'Projects - Renewables': 466, 'Projects - Power & Other': 467, 'Entertainment': 468, 'Hospitals': 469, 'Housing': 470, 'Schools': 471, 'Social - Other': 472, 'Airports': 473, 'Ports': 474, 'Railroads': 475, 'Roads, Bridges, & Tunnels': 476, 'Transportation - Diversified & Other': 477, 'States': 1321, 'Priority Lien': 1395, 'Lottery Revenue': 1337, 'Miscellaneous Tax': 1338, 'Pension Funds': 1325, 'GO Municipalities & Counties': 1327, 'Tribes & Nations': 1328, 'GO School Districts': 1329, 'GO Hospital Districts': 1331, 'GO Special Districts': 1332, 'GO Water Districts': 1333, 'Municipal Utility Districts': 1334, 'Federally Backed Leases': 1336, 'Prison Project Revenue': 1339, 'Special Assessments': 1340, 'Tax Increment': 1341, 'State Enhancement Programs': 1342, 'Cash Flow Notes': 1397, 'Charter Schools': 1345, 'Community Colleges and Districts': 1346, 'Independent Schools': 1347, 'U.S. Not-for-Profit Acute Healthcare Standalones': 1349, 'U.S. Not-for-Profit Acute Healthcare Systems': 1350, 'Hospital Districts': 1351, 'Human Service Providers': 1352, 'Senior Living': 1353, 'Public Universities': 1355, 'Private Universities': 1356, 'Not-for-Profit': 1357, 'Auxiliary Enterprises': 1358, 'Rental Housing Bonds - Multifamily Static Pools': 1362, 'Rental Housing Bonds - Age Restricted Housing': 1363, 'Federally Enhanced Housing - Credit Enhancement Instruments': 1364, 'Federally Enhanced Housing - Single-Family MBS Pass-Through Programs': 1365, 'Federally Enhanced Housing - Multifamily MBS': 1366, 'Capital Fund Financing Programs': 1367, 'Community Development Financial Institutions GO Debt': 1368, 'Community Development Financial Institutions ICR': 1369, 'Federally Enhanced Housing - Single-Family MBS': 1370, 'Rental Housing Bonds - Section 8 Housing': 1371, 'Federally Enhanced Housing - FHA-Insured': 1372, 'Federally Enhanced Housing - FHA-Insured Pass-Through': 1373, 'Housing Finance Agencies ICR': 1374, 'Interest Only': 1375, 'Rental Housing Bonds - Mobile Home Parks': 1376, 'Federally Enhanced Housing - Single-Family Managed MBS Programs': 1377, 'Rental Housing Bonds - Privatized Military Housing': 1378, 'Single-Family Whole Loan Programs': 1379, 'Housing Finance Agencies GO Debt': 1380, 'Social Enterprise Lending Organizations ICR': 1381, 'U.S. Social Housing Providers and Public Housing Authorities': 1382, 'Rental Housing Bonds - Unenhanced Housing': 1383, 'Rental Housing Bonds - Multifamily Managed Pools': 1384, 'Strong Link': 1386, 'Weak Link': 1387, 'Wholesale Utility': 1388, 'Retail Electric & Gas': 1390, 'Wholesale Electric': 1391, 'Rural Electric Cooperatives': 1392, 'Infrastructure': 1394, 'Grant Anticipation Revenue Vehicles': 1396, 'Waterworks, Sanitary Sewer & Drainage Utility Systems': 1399, 'Water-Sewer Independent Wholesale': 1400, 'Solid Waste': 1401, 'State Revolving Fund Pools': 1402, 'Mortgage Revenue Bond Programs': 1406}
