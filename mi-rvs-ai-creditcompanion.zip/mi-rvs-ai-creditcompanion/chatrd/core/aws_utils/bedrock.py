import boto3
from botocore.config import Config

from chatrd.core.aws_utils.common import assumed_session
from chatrd.engine.configuration import Constants, get_config_machinery

config_machinery = get_config_machinery()


def get_bedrock_llm_client(region_name: str):
    session = boto3.Session()

    retry_config = Config(
        region_name=region_name,
        retries={
            "max_attempts": 10,
            "mode": "standard",
        },
        max_pool_connections=50,
    )
    vpc_endpoint = config_machinery.get_config_value(Constants.Bedrock.BEDROCK_VPC_ENDPOINT)

    bedrock_client = session.client(
        service_name="bedrock",
        config=retry_config,
        region_name=region_name,
        endpoint_url=vpc_endpoint,
    )

    bedrock_runtime_client = session.client(
        service_name="bedrock-runtime",
        config=retry_config,
        region_name=region_name,
        endpoint_url=vpc_endpoint,
    )

    return {"bedrock": bedrock_client, "bedrock-runtime": bedrock_runtime_client}


def get_assume_bedrock_credentials(role_arn: str, region_name: str):
    sts_client = boto3.client("sts", region_name=region_name)

    # Call the assume_role method of the STSConnection object and pass the role
    # ARN and a role session name.
    assumed_role_object = sts_client.assume_role(
        RoleArn=role_arn,
        RoleSessionName="AssumeRoleSession1",
        region_name=region_name,
    )
    credentials = assumed_role_object["Credentials"]
    return {
        "aws_secret_key": credentials["SecretAccessKey"],
        "aws_access_key": credentials["AccessKeyId"],
        "aws_region": region_name,
        "aws_session_token": credentials["SessionToken"],
    }


client_cache = {}


def get_assumed_bedrock_llm_client(role_arn: str, region_name: str):
    cache_key = f"{role_arn}:{region_name}"

    if cache_key in client_cache:
        return client_cache[cache_key]

    session = assumed_session(
        role_arn=role_arn,
        session_name="AssumeRoleSession-" + region_name,
        region_name=region_name,
    )

    conn_timeout = int(config_machinery.get_config_value(Constants.Bedrock.BEDROCK_CONN_TIMEOUT))
    read_timeout = int(config_machinery.get_config_value(Constants.Bedrock.BEDROCK_READ_TIMEOUT))
    retry_config = Config(
        region_name=region_name,
        retries={
            "max_attempts": 10,
            "mode": "standard",
        },
        max_pool_connections=50,
        connect_timeout=conn_timeout,
        read_timeout=read_timeout,
    )
    vpc_endpoint = config_machinery.get_config_value(Constants.Bedrock.BEDROCK_VPC_ENDPOINT)

    bedrock_client = session.client(
        service_name="bedrock",
        config=retry_config,
        region_name=region_name,
        endpoint_url=vpc_endpoint,
    )

    bedrock_runtime_client = session.client(
        service_name="bedrock-runtime",
        config=retry_config,
        region_name=region_name,
        endpoint_url=vpc_endpoint,
    )

    clients = {"bedrock": bedrock_client, "bedrock-runtime": bedrock_runtime_client}
    client_cache[cache_key] = clients
    return {"bedrock": bedrock_client, "bedrock-runtime": bedrock_runtime_client}
