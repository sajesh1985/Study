import logging

from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.data_service.retriever.base import BaseRetriever
from chatrd.engine.data_service.retriever.utils import _retrieve, get_keyinstn_id
from chatrd.engine.data_service.schema import Analyzer, ProcessorInput, Retriever

logger = logging.getLogger(__name__)
config_machinery = get_config_machinery()


class FinancialRetriever(BaseRetriever):
    def retrieve(self, processor: ProcessorInput = None, analyzer: Analyzer = None):
        if not processor.entities or len(processor.entities["companies"]) == 0:
            return Retriever()
        endpoint_path = Constants.RatingsAPI.RATINGS_API_ENTITY_CSD_ENDPOINT_PATH
        parameter = get_keyinstn_id(processor.entities)
        response = _retrieve(endpoint_path, parameter)
        if response.api_data and "value" in response.api_data and not response.api_data["value"]:
            logger.info(f"No data found from the endpoint: {endpoint_path} with the parameter {parameter}")
            return Retriever()

        return response
