import { ColDef } from 'ag-grid-community';

import { UserProfileAllTypes } from '@spglobal/userprofileservice';
import { 
  getLocalizedDate,
  convertStringToDate
 } from '../../../utils/dateLocalization';

export interface ServerResponseType {
  sessionId: string;
  interactionId: string;
  previousInteractionId: string | null;
  userInput: { type: string; value: string; taggedEntities: string[] }[];
  requestTimeStamp: string;
  responseTimestamp: string | null;
  feedback: {
    feedback_sentiment: string | null;
    text_feedback: string | null;
    tags: string | null;
  };
}

export interface TransformedResponseType {
  feedbackSentiment: string;
  feedbackText: string;
  feedbackTags: string;
  userInputValue: string;
  requestTimeStamp: string;
  responseTimeStamp: string;
  userInputType: string;
  sessionId: string;
  interactionId: string;
  previousInteractionId: string;
}

export interface ColumnDefType extends ColDef {
  cellRendererFramework?: React.ComponentType<any>;
  cellRendererParams?: (params: any) => any;
}

export function fromFeedbackToGrid(responses: ServerResponseType[], userInformation: Partial<UserProfileAllTypes>): TransformedResponseType[] {
  
  const localizedTime = ( time: string, userInformation: Partial<UserProfileAllTypes> ) => {
    let result = ""
    const defaultValue= ""

    if (!time) return ""

    try {
      result = getLocalizedDate(
        convertStringToDate(time),
        true,
        userInformation.culture,
        userInformation.mSTimeZoneID
      )
      return result
    } catch(err) {
      console.log("responseTime", err)
      return defaultValue
    }
  }

  const result = responses.map((res) => ({
    feedbackSentiment: res.feedback.feedback_sentiment || '-',
    feedbackText: res.feedback.text_feedback || '-',
    feedbackTags: res.feedback.tags || '-',
    userInputValue: res.userInput[0]?.value || '-',
    requestTimeStamp: localizedTime(
      res.requestTimeStamp,
      userInformation
    ),
    responseTimeStamp: localizedTime(
      res.responseTimestamp,
      userInformation
    ),
    userInputType: res.userInput[0]?.type || '-',
    sessionId: res.sessionId || '-',
    interactionId: res.interactionId || '-',
    previousInteractionId: res.previousInteractionId || '-',
  }));

  return result
}
