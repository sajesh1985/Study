from abc import ABC, abstractmethod
from typing import Sequence

from chatrd.core.document import Document


class EmbeddingModel(ABC):
    def __init__(self, max_length: int = None):
        self.max_length = max_length

    def embed_texts(self, texts: Sequence[str]) -> Sequence[Sequence[float]]:
        return [self.embed_query(text) for text in texts]

    def embed_documents(self, documents: Sequence[Document]) -> Sequence[Sequence[float]]:
        texts = [document.content for document in documents]
        return self.embed_texts(texts)

    @abstractmethod
    def embed_query(self, text: str) -> Sequence[float]:
        pass
