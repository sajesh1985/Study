from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field


class OutlookSubroutingValues(Enum):
    TYPE_MACRO = "macro"
    TYPE_ENTITY = "entity"


class OutlookSubrouting(BaseModel):
    UseCase: Optional[OutlookSubroutingValues] = Field(
        default="",
        description="Is the outlook requested for a specific entity, or for industry/sector/other (macro)?",
    )


OUTLOOK_SUBROUTING_EXAMPLES = """
__________________
{
    "question": "when was the outlook updated for <xyz entity>?",
    "answer": "entity"
}
__________________
{
    "question": "when was the outlook updated for <xyz entity>?",
    "answer": "entity"
}
__________________
{
    "question": "What are the triggers for a downgrade for <xyz entity>?",
    "answer": "entity"
}
__________________
{
    "question": "Outlook for <xyz entity/city/country>?",
    "answer": "entity"
}
__________________
{
    "question": "What is the outlook for <xyz city/country>?",
    "answer": "entity"
}
__________________
{
    "question": "provide a good overview of the outlook for <xyz entity/city/country>",
    "answer": "entity"
}
__________________
{
    "question": "Outlook for <xyz entity/city/country> in the next couple of years?",
    "answer": "entity"
}
__________________
{
    "question": "What is the Outlook for xyz sector?",
    "answer": "macro"
}
__________________
{
    "question": "What is the outlook for the <xyz country>'s uwv sector?",
    "answer": "macro"
}
__________________
{
    "question": "Outlook for <xyz industry> companies",
    "answer": "macro"
}
__________________
{
    "question": "What is the outlook of <xyz entity>'s economy?",
    "answer": "macro"
}
__________________
{
    "question": "What is the current economic or financial outlook for <xyz entity>?"
    "answer": "macro"
}
__________________
{
    "question": "What is the economic outlook for <xyz country>?"
    "answer": "macro"
}
"""


OUTLOOK_SUBROUTING_PARSER_TEMPLATE = """Your goal is to retrieve information if the question concerns particular entity, or a sector/industry/other:
- "entity", if the question pertains to the outlook for particular entity, e.g. company, country, city, etc.;
- "macro" if the question pertains to the outlook for a sector, industry, market, a continent, or other large segment of economy.

Examples pairs of question (key: question) and answer (key: answer) are given below in JSON format:
<examples>
{examples}
</examples>

Format the output following these guidelines:
{format_instructions}

Do not add anything other than the defined JSON schema. Do not explain to me that this is the JSON output I requested. Do not justify your answer. Provide only the JSON.

Apply the instructions to this question:
{question}
"""
