import logging
import re
from collections import defaultdict
from concurrent.futures._base import Future
from datetime import date
from itertools import chain
from types import GeneratorType, SimpleNamespace
from typing import Dict, List, Optional, Tuple, Union

import pandas as pd
from dateutil.relativedelta import relativedelta

from chatrd.core.document import (
    CSDTableResponse,
    Document,
    ParentChildTableResponse,
    TableDocument,
    TableResponse,
)
from chatrd.core.llm import LCLLMFactory
from chatrd.core.synthesizer import CompactAndRefineSynthesizer, StructuredSynthesizer
from chatrd.core.thread_utils import submit_to_shared_thread_pool
from chatrd.core.utils import MessageRole
from chatrd.engine.components.query_analyzer.entity_extractor.utils import Entities
from chatrd.engine.components.query_analyzer.filter_retrievers.base import FiltersInput
from chatrd.engine.components.query_analyzer.filter_retrievers.prompts import (
    TIME_THRESHOLD_PROMPT_DATE_OUTPUT_UNSTRUCTURED,
    empty_instructions_string,
    output_parser_time_threshold_dates,
    time_threshold_date_additional_examples_string,
)
from chatrd.engine.components.query_analyzer.filter_retrievers.time_threshold import (
    TimeThresholdFilter,
)
from chatrd.engine.components.query_analyzer.guideline_generator import (
    GuidelineGenerator,
)
from chatrd.engine.components.query_analyzer.suggested_entity_rephrase.suggested_routes import (
    SuggestedRoute,
    SuggestedRoutesContent,
    SuggestedRoutesResponse,
)
from chatrd.engine.components.query_analyzer.suggested_entity_rephrase.utils import (
    SuggestedEntitiesContent,
    SuggestedEntitiesResponse,
    SuggestedEntity,
)
from chatrd.engine.components.query_analyzer.time_rephraser import QuestionRephraser
from chatrd.engine.components.query_analyzer.translator.utils import (
    Get_translation_result,
)
from chatrd.engine.components.query_processor.constants import UNAUTHOROZED_DOCS_TEXT
from chatrd.engine.components.query_processor.query_retriever import QueryRetriever
from chatrd.engine.components.query_processor.query_retriever.reranker import (
    remove_duplicates,
)
from chatrd.engine.components.query_processor.query_retriever.uc_retrievers import (  # BackupRetriever,
    GeneralRetriever,
)
from chatrd.engine.components.query_processor.query_retriever.utils import (
    get_sorted_docs_by_date,
)
from chatrd.engine.components.query_processor.query_synthesizer import QuerySynthesizer
from chatrd.engine.components.query_processor.utils import (
    inline_citations_formatter,
    remove_common_items,
    sort_citations,
)
from chatrd.engine.components.schema import QueryAnalyzerOutput, QueryProcessorInput
from chatrd.engine.components.state_machine import StateMachine
from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.prompts import (
    EXPERT_GUIDELINES,
    INITIAL_PROMPT_TEMPLATE_FLEX_STR,
    INITIAL_PROMPT_TEMPLATE_STR,
    REFINE_PROMPT_STR,
)
from chatrd.engine.responses import get_default_answer, get_tagged_routes_suggestions
from chatrd.engine.utils import ChatResponse, CitedSourceList

logger = logging.getLogger(__name__)

config_machinery = get_config_machinery()

DEFAULT_REASONING_CONFIG = config_machinery.get_config_value(Constants.GeneralConstants.DEFAULT_REASONING_CONFIG)


class QueryProcessor(StateMachine):
    def __init__(
        self,
    ):
        super().__init__(
            machine_role="QueryProcessor",
            failure_response="Query Processor Failed.",
            success_response="Query Processor Passed.",
        )
        self._query_retriever = QueryRetriever()
        self._query_synthesizer = QuerySynthesizer()

    def backup_routing(self, inputs: QueryProcessorInput) -> Tuple[QueryProcessorInput, List[Document]]:
        """
        Calls general retriever to retrieve documents with the following parameters:
        - Entity is set to None
        - Search both macro and micro research
        - Search commentary Articles
        - Default time frame instead of user specific time frame
        - UC type is set to "general"
        - Use general guideline

        Is meant to replicate RAG solution for when our existing solution fails for some reason.

        ## Args:
        - inputs (QueryProcessorInput) : Input containing llm parameters and QueryAnalyzerOutput, extracts rephrased_query from it for further processing
        ## Returns:
        - revised_inputs (QueryProcessorInput) : Revised input with updated QueryAnalyzerOutput fields
        - retrieved_docs (List[Document]) : List of documents retrieved by GeneralRetriever
        - future_guideline (Future) : Future object containing the result of guideline generation with general guideline
        """
        if inputs.analyzer_output.tagged_routes is not None and len(inputs.analyzer_output.tagged_routes) != 0:
            logger.info("Hard Routing: Hard Routing Error Reached Backup Retriever, failing")
            return get_default_answer(), None
        logger.info("Backup routing triggered, calling BackupRetriever")
        revised_inputs = inputs.copy(deep=True)
        revised_inputs.analyzer_output.uc_type = "general"

        # Include date extraction functionality:
        # Do not redo timeframe extraction if it has already been done
        if revised_inputs.analyzer_output.extracted_timeframe is None:
            try:
                date_retriever_date_output_unstructured = TimeThresholdFilter(
                    uc_specific_prompt=TIME_THRESHOLD_PROMPT_DATE_OUTPUT_UNSTRUCTURED,
                    output_parser=output_parser_time_threshold_dates,
                    specific_instructions_fn=empty_instructions_string,
                    examples_fn=time_threshold_date_additional_examples_string,
                    filters_input=FiltersInput(
                        llm=inputs.llm_for_non_flex_synthesizer, temperature=inputs.temperature_for_non_flex_synthesizer
                    ),
                )
                extracted_timeframe = date_retriever_date_output_unstructured.invoke(
                    revised_inputs.analyzer_output.rephrased_query,
                    today_date=date.today(),
                    today_date_year=date.today().year,
                    last_year=date.today().year - 1,
                    today_date_minus_year=date.today() + relativedelta(years=-1),
                )
                revised_inputs.analyzer_output.extracted_timeframe = extracted_timeframe
                time_rephraser = QuestionRephraser(
                    model_name=inputs.llm_for_non_flex_synthesizer,
                    temperature=inputs.temperature_for_non_flex_synthesizer,
                )
                time_rephrased_question = time_rephraser.rephrase(
                    extracted_timeframe, revised_inputs.analyzer_output.rephrased_query
                )
                revised_inputs.analyzer_output.rephrased_query = time_rephrased_question
            except Exception as e:
                logger.info(f"Backup Routing: Failure in Question Rephraser: {e}")

        tool = GeneralRetriever(
            vector_stores_dict=self._query_retriever._vector_stores_dict,
            reranker_client=self._query_retriever.reranker_client,
        )
        analyzer_output = revised_inputs.analyzer_output
        documents = tool.retrieve(
            query=analyzer_output.rephrased_query,
            entities=analyzer_output.entities,
            uc_type=analyzer_output.uc_type,
            model_name_for_data_service=inputs.llm_for_data_service,
            temperature_for_data_service=inputs.temperature_for_data_service,
            sectors=analyzer_output.sectors,
            extracted_timeframe=analyzer_output.extracted_timeframe,
            tagged_routes=analyzer_output.tagged_routes,
            macro_micro_routing=True,
        )

        logger.info(f"BackupRetriever retrieved {len(documents)} documents")
        retrieved_docs = documents
        return revised_inputs, retrieved_docs

    def process_multitopic_query_docs(self, inputs: QueryProcessorInput, documents: List[Document]):
        entities = inputs.analyzer_output.entities
        documents = remove_duplicates(documents)
        grouped = defaultdict(list)
        companies_ids = [str(e.mi_id) for e in entities.companies]
        revenue_sources_ids = [str(e.asid) for e in entities.revenue_sources]
        for doc in documents:
            matched = False
            if revenue_sources_ids:
                rs_val = doc.metadata.get("aggRevenueSourceId", "")
                if rs_val:
                    rs_vals = str(rs_val).split(";")
                    for _id in rs_vals:
                        if _id in revenue_sources_ids:
                            grouped[_id].append(doc)
                            matched = True
                            break
            if not matched:
                instn_val = doc.metadata.get("aggPrimarykeyInstn", "")
                instn_vals = str(instn_val).split(";")
                for _id in instn_vals:
                    if _id in companies_ids:
                        grouped[_id].append(doc)
                        break
                secnd_val = doc.metadata.get("aggsecondaryKeyInstn", "")
                secnd_vals = str(secnd_val).split(";")
                for _id in secnd_vals:
                    if _id in companies_ids:
                        grouped[_id].append(doc)
                        break
        sorted_docs = []
        for key in grouped:
            entity_name = grouped[key][0].metadata.get("aggLegalEntityName", "").partition(";")[0].strip()
            sorted_docs.append(
                Document(
                    content=(f"<{entity_name}>"),
                ),
            )
            docs_with_date = [doc for doc in grouped[key] if "articleReleaseDate" in doc.metadata]
            docs_without_date = [doc for doc in grouped[key] if "articleReleaseDate" not in doc.metadata]
            date_sorted = get_sorted_docs_by_date(docs_with_date, len(docs_with_date))
            combined_docs = date_sorted + docs_without_date
            sorted_docs.extend(combined_docs)
            sorted_docs.append(
                Document(
                    content=(f"</{entity_name}>"),
                ),
            )
        return sorted_docs

    def remove_duplicate_sources(self, data):
        seen_links = set()
        for entry in data:
            source_descriptions, unique_source_descriptions = entry.metadata["source_description"], []
            if source_descriptions != None:
                for desc, link in source_descriptions:
                    if link not in seen_links:
                        seen_links.add(link)
                        unique_source_descriptions.append((desc, link))
            entry.metadata["source_description"] = unique_source_descriptions
        return data

    def multitopic_query_docs(self, inputs: QueryProcessorInput) -> List[Tuple[str, List[Document]]]:
        """
        Retrieves documents for each subquery in a multi-topic query.

        ## Args:
        - inputs (QueryProcessorInput) : Input containing llm parameters and a super QueryAnalyzerOutput
        ## Returns:
        - List of tuples, each containing a subquery and its corresponding list of retrieved documents.
        """
        subquery_docs = {}
        assert isinstance(
            inputs.analyzer_output.subquery_analyzer_outputs, list
        ), f"Expected of subquery_analyzer_outputs of QueryAnalyzerOutput to be a list of strings, actual type is {type(inputs.analyzer_output.subquery_analyzer_outputs)}"
        query_retriever_futures = [
            submit_to_shared_thread_pool(
                self._query_retriever.execute,
                inputs.llm_for_tool_classifier,
                inputs.temperature_for_data_service,
                inputs.llm_for_data_service,
                inputs.temperature_for_data_service,
                subquery_output,
            )
            for subquery_output in inputs.analyzer_output.subquery_analyzer_outputs
        ]
        flattened_docs = [doc for future in query_retriever_futures for doc in future.result()]
        structured_docs = [doc for doc in flattened_docs if doc.source == "structured"]
        unstructured_docs = [doc for doc in flattened_docs if doc.source == "unstructured"]
        structured_docs = self.remove_duplicate_sources(structured_docs)
        processed_unstructured = self.process_multitopic_query_docs(inputs, unstructured_docs)
        combined_docs = processed_unstructured + structured_docs
        return combined_docs

    def filter_retrieval_error(self, x):
        return not (
            (
                isinstance(x.content, str)
                and (
                    x.content.startswith("Sorry, CreditCompanion<sup>TM</sup> is")
                    or x.content.startswith("CreditCompanion<sup>TM</sup> is having trouble generating")
                    or x.content.startswith(
                        "CreditCompanion™ is unable to find requested information. Please try another question."
                    )
                    or x.content.startswith(
                        "Sorry, CreditCompanion<sup>TM</sup> is not able to provide requested information."
                    )
                    or x.content.startswith("Sorry, requested information is unavailable. Please try another question.")
                    or x.content.startswith("*CreditCompanion™ is unable to find peers for")
                    or x.content.strip() == ""
                    or x.content.startswith(
                        "CreditCompanion<sup>TM</sup> currently supports only company-related queries."
                    )
                )
            )
            or (hasattr(x, "error_docs") and x.error_docs)
            or (hasattr(x, "metadata") and "is_error" in x.metadata and x.metadata["is_error"])
        )

    def _execute_internal(self, inputs: QueryProcessorInput) -> ChatResponse:
        # Step-1: Retrieving documents from retrivers (opensearch indexes, data service, api)
        if inputs.analyzer_output.entities is None:
            inputs.analyzer_output.entities = Entities(companies=[], securities=[], revenue_sources=[])
        retrieved_docs, future_guideline = None, None
        if inputs.analyzer_output.backup:
            inputs, retrieved_docs = self.backup_routing(inputs)
            if isinstance(inputs, ChatResponse):
                return inputs
        length_of_entities = (
            len(inputs.analyzer_output.entities.companies)
            + len(inputs.analyzer_output.entities.securities)
            + len(inputs.analyzer_output.entities.revenue_sources)
        )
        entity_exists = (inputs.analyzer_output.entities is not None) and (length_of_entities >= 1)

        if not entity_exists and not (
            inputs.analyzer_output.uc_type
            in ["general", "query", "definition", "criteria", "outlook", "selected_article", "sNw"]
        ):
            logger.error(
                "No entities found and UC type is not valid for call without specific entity, calling backup retriever"
            )
            inputs, retrieved_docs = self.backup_routing(inputs)
            if isinstance(inputs, ChatResponse):
                return inputs

        if retrieved_docs is None:
            try:
                if inputs.analyzer_output.uc_type == "multi":
                    retrieved_docs = self.multitopic_query_docs(inputs)
                else:
                    future_retrived_docs = submit_to_shared_thread_pool(
                        self._query_retriever.execute,
                        inputs.llm_for_tool_classifier,
                        inputs.temperature_for_data_service,
                        inputs.llm_for_data_service,
                        inputs.temperature_for_data_service,
                        inputs.analyzer_output,
                    )
                    retrieved_docs = future_retrived_docs.result()
            except Exception as e:
                logger.error(f"Error in retrieving documents: {repr(e)}")
                inputs, retrieved_docs = self.backup_routing(inputs)
            # return get_default_answer(original_language=inputs.analyzer_output.original_language)

        if retrieved_docs is not None:
            if len(list(filter(self.filter_retrieval_error, retrieved_docs))) == 0:
                logger.error("All retrieved documents are error documents, calling backup retriever")
                inputs, retrieved_docs = self.backup_routing(inputs)
                if isinstance(inputs, ChatResponse):
                    return inputs

        retrieved_docs = self.post_filter_error_documents(retrieved_docs)

        if not retrieved_docs:
            logger.error("No documents retrieved, calling backup retriever")
            inputs, retrieved_docs = self.backup_routing(inputs)
            if isinstance(inputs, ChatResponse):
                return inputs

        non_flex_llm_synthesizer = LCLLMFactory().get_llm(
            deployment_name_or_model_id=inputs.llm_for_non_flex_synthesizer,
            temperature=inputs.temperature_for_non_flex_synthesizer,
        )
        flex_llm_synthesizer = LCLLMFactory().get_llm(
            deployment_name_or_model_id=inputs.llm_for_flex_synthesizer,
            temperature=inputs.temperature_for_flex_synthesizer,
        )
        text_synthesizer = CompactAndRefineSynthesizer(
            non_flex_llm=non_flex_llm_synthesizer,
            flex_llm=flex_llm_synthesizer,
            streaming=inputs.streaming,
            expert_guidelines=EXPERT_GUIDELINES,
            initial_prompt_template_str=INITIAL_PROMPT_TEMPLATE_STR,
            initial_prompt_template_flex_str=INITIAL_PROMPT_TEMPLATE_FLEX_STR,
            refine_prompt_str=REFINE_PROMPT_STR,
        )

        structured_synthesizer = StructuredSynthesizer(
            inputs.llm_for_non_flex_synthesizer, inputs.temperature_for_non_flex_synthesizer, non_flex_llm_synthesizer
        )

        non_synthesize_responses = []
        non_synthesize_docs = []
        non_synthesize_error_responses = []
        non_synthesize_error_docs = []
        unauthorized_docs = []
        for doc in retrieved_docs:
            if not doc.authorized:
                unauthorized_docs.append(doc)
                continue
            if not (doc.synthesize or "is_error" in doc.metadata):
                if doc.error_docs:
                    non_synthesize_error_responses.append({"type": "text", "content": doc.content})
                    non_synthesize_error_docs.append(doc)
                else:
                    non_synthesize_responses.append(
                        {
                            "type": (
                                "table"
                                if isinstance(doc.content, TableResponse)
                                else (
                                    "csd_table"
                                    if isinstance(doc.content, CSDTableResponse)
                                    else (
                                        "parentchild_table"
                                        if isinstance(doc.content, ParentChildTableResponse)
                                        else "text"
                                    )
                                )
                            ),
                            "content": doc.content,
                        }
                    )
                    non_synthesize_docs.append(doc)

            if "is_error" in doc.metadata:
                non_synthesize_responses.append({"type": "text", "content": ""})
                non_synthesize_docs.append(doc)

        synthesized_docs = []
        for doc in retrieved_docs:
            if doc.synthesize and doc.authorized:
                synthesized_docs.append(doc)

        # Step-2: Synthesizing the response from retriver results.
        (structured_response, structured_synthesize_docs), (
            text_response,
            text_response_synthesize_docs,
        ) = self._query_synthesizer.execute(
            message=inputs.analyzer_output.rephrased_query,
            chat_history=[],
            documents=synthesized_docs,
            text_synthesizer=text_synthesizer,
            structured_synthesizer=structured_synthesizer,
            query_processor_input=inputs,
        )

        cited_docs = []
        count_of_non_synthesize_sources = 0
        for doc in non_synthesize_docs + structured_synthesize_docs:
            if (
                "source_description" in doc.metadata
                and doc.metadata["source_description"] is not None
                and doc.synthesize is False
            ):
                cited_docs.append(doc)
                for source in doc.metadata["source_description"]:
                    count_of_non_synthesize_sources += 1

        if cited_docs:
            source_descriptions = []
            for doc in cited_docs:
                if doc.metadata["source_description"]:
                    source_descriptions.extend(doc.metadata["source_description"])
                doc.metadata["source_description"] = None
                if inputs.analyzer_output.uc_type == "multi":
                    doc.metadata["response_payload"] = None
            cited_docs[0].metadata["source_description"] = source_descriptions
            cited_docs = [cited_docs[0]]

        if (text_response_synthesize_docs) and (text_response is not None):
            if text_response is not None and isinstance(text_response, GeneratorType):
                text_response = inline_citations_formatter(
                    text_response,
                    text_response_synthesize_docs,
                    cited_docs,
                    count_of_non_synthesize_sources=count_of_non_synthesize_sources,
                )
                text_response = sort_citations(text_response)

        # after filtering synthesized_docs in inline_citations_formatter, we need to re-assign the synthesized_docs
        synthesized_responses = []
        if text_response is not None:
            synthesized_responses.append({"type": "text", "content": text_response})
        responses = []
        if non_synthesize_responses:
            responses.extend(non_synthesize_responses)
        if structured_response is not None:
            responses.extend(structured_response)
        if synthesized_responses:
            responses.extend(synthesized_responses)
        if non_synthesize_error_responses:
            responses.extend(non_synthesize_error_responses)

        source_docs = []
        if non_synthesize_docs:
            source_docs.extend(non_synthesize_docs)
        if (structured_synthesize_docs) and (structured_response is not None):
            source_docs.extend(structured_synthesize_docs)
        if (text_response_synthesize_docs) and (text_response is not None):
            source_docs.extend([text_response_synthesize_docs])
        if non_synthesize_error_docs:
            source_docs.extend(non_synthesize_error_docs)

        if len(unauthorized_docs) > 0:
            UNAUTHOROZED_DOCS_TEXT_TRANSLATION = Get_translation_result(
                UNAUTHOROZED_DOCS_TEXT, inputs.analyzer_output.original_language
            )
            UNAUTHOROZED_DOCS_TEXT_TRANSLATION = UNAUTHOROZED_DOCS_TEXT_TRANSLATION.result()

            responses.append(
                {
                    "type": "text",
                    "content": UNAUTHOROZED_DOCS_TEXT_TRANSLATION,
                }
            )
            source_docs.append(
                Document(
                    content="Unauthorized Documents",
                    synthesize=False,
                )
            )

        text3 = "Let's improve it. Choose an option below to <b>focus</b> CreditCompanion<sup>TM</sup> on a specific set of research or data:"

        text3 = Get_translation_result(text3, inputs.analyzer_output.original_language)
        title_entity = Get_translation_result("Not the right entity?", inputs.analyzer_output.original_language)
        title = Get_translation_result("Response not quite right?", inputs.analyzer_output.original_language)

        text3 = text3.result()
        title_entity = title_entity.result()
        title = title.result()

        if inputs.analyzer_output.suggested_entities:
            text1 = "We found other close matches. Select an entity from the list below to re-run your question:"
            text2 = "Tip: Use the @ symbol in your question to pull up search results and select the company you'd like to see info for. The RD badge indicates Ratings coverage."
            entities = inputs.analyzer_output.suggested_entities.entities.copy()

            text1 = Get_translation_result(text1, inputs.analyzer_output.original_language)
            text2 = Get_translation_result(text2, inputs.analyzer_output.original_language)
            text1 = text1.result()
            text2 = text2.result()

            names, queries = [], []
            for entity in entities:
                names.append(Get_translation_result(entity.name, inputs.analyzer_output.original_language))
                queries.append(Get_translation_result(entity.query, inputs.analyzer_output.original_language))
            for entity, name, query in zip(entities, names, queries):
                entity.name = name.result()
                entity.query = query.result()

            responses.append(
                {
                    "type": "suggestion",
                    "content": SuggestedEntitiesContent(
                        title=title_entity,
                        content=[
                            SuggestedEntitiesResponse(text=text1),
                            SuggestedEntitiesResponse(suggestions=entities),
                            SuggestedEntitiesResponse(text=text2),
                        ],
                        behavior=(
                            "collapse" if inputs.analyzer_output.suggested_entities.query_entity_is_rd else "expand"
                        ),
                    ),
                }
            )
            source_docs.append(
                Document(
                    content="Suggested Entities",
                    synthesize=False,
                )
            )

        responses.append(
            {
                "type": "route_suggestion",
                "content": SuggestedRoutesContent(
                    title=title,
                    content=[
                        SuggestedRoutesResponse(text=text3),
                        SuggestedRoutesResponse(
                            suggestions=get_tagged_routes_suggestions(
                                inputs.analyzer_output.original_language,
                                original_query=inputs.analyzer_output.original_query,
                            )
                        ),
                    ],
                    behavior="collapse",
                ),
            }
        )

        source_docs.append(
            Document(
                content="Suggested Routes",
                synthesize=False,
            )
        )
        # source_docs = remove_common_items(cited_docs, source_docs)

        if len(responses) == 1 and isinstance(responses[0], dict) and responses[0].get("type") == "route_suggestion":
            return get_default_answer(
                original_language=inputs.analyzer_output.original_language,
                original_query=inputs.analyzer_output.original_query,
            )

        if (
            len(responses) > 1
            and isinstance(responses[0], dict)
            and isinstance(responses[1], dict)
            and not responses[0].get("content")
            and responses[1].get("type") == "route_suggestion"
        ):
            return get_default_answer(
                original_language=inputs.analyzer_output.original_language,
                original_query=inputs.analyzer_output.original_query,
            )

        # Step-3: Formatting response to chat engine
        if not ((synthesized_docs) and (text_response is not None)):

            formatted_response = ChatResponse(
                role=MessageRole.ASSISTANT,
                content=responses,
                source_docs=source_docs,
                cited_docs=cited_docs,
                unauthorized_docs=unauthorized_docs,
            )
        else:
            formatted_response = ChatResponse(
                role=MessageRole.ASSISTANT,
                content=responses,
                source_docs=source_docs,
                unauthorized_docs=unauthorized_docs,
            )

        return formatted_response

    def post_filter_error_documents(self, documents: List[Document]) -> List[Document]:
        filtered_docs = []
        for doc in documents:
            if doc.error_docs:
                loop_break = False
                for doc1 in documents:
                    if (
                        (doc1 != doc)
                        and (doc1.entity == doc.entity)
                        and (doc1.metadata.get("articleID", None) is not None)
                    ):
                        loop_break = True
                        break
                if not loop_break:
                    filtered_docs.append(doc)
            else:
                filtered_docs.append(doc)
        return filtered_docs
