﻿// Copyright Notice! 
// This document is protected under the trade secret and copyright 
// laws as the property of Fidelity National Information Services, Inc. 
// Copying, reproduction or distribution should be limited and only to 
// employees with a “need to know” to do their job. 
// Any disclosure of this document to third parties is strictly prohibited.
// © 2017 Fidelity National Information Services.
// All rights reserved worldwide.

namespace Fis.Epp.Fusion.WebAPI.Models
{
    using System.Collections.Generic;
    public class ResourcesAggregatorModel
    {
        /// <summary>
        /// Collection of Properties resource entries.
        /// </summary>
        public Dictionary<string, object> Properties { get; set; }

        /// <summary>
        /// Collection of Text resource entries.
        /// </summary>
        public Dictionary<string, object> Text { get; set; }

        /// <summary>
        /// Collection of Formats resource entries.
        /// </summary>
        public Dictionary<string, object> Formats { get; set; }
        
        /// <summary>
        /// Constructor method to initialize property collections.
        /// </summary>
        public ResourcesAggregatorModel()
        {
            Properties = new Dictionary<string, object>();
            Text = new Dictionary<string, object>();
            Formats = new Dictionary<string, object>();
        }
    }
}