
# PeerRanking Field Names Reference (Capital IQ API):
# =================================================
# RankingCriteria Fields (used for peer ranking and selection):
# - 275622: Total Revenue (Latest Fiscal Year FY0) - Priority 2
# - 329072: Primary Industry - Priority 3
# - 275913: Ranking metric (unknown) - Priority 3
# - 336466: Base company reference (company ID) - Priority 2
# - 334045: Issuer Credit Rating (Local Currency LT, Current) - Priority 1
#
# QueryLines Fields (used for filtering peer universe):
# - 321214: Geography filter ("7652" = All Geographies) - FILTER ONLY, NOT for data retrieval
# - 322992: Company type filter ("7957" = Public Company)
# - 275891: Company status filter ("Operating", "Operating Subsidiary")
# - 327686: Industry classification filter (specific industry codes)
# - 275622: Revenue size filter ([10]-[500] range in millions USD)
# - PEERRANKING: Peer ranking count (value: 5 peers)
#
# Banks-specific Fields (BANKS_PEER_ANALYTICS_PAYLOAD):
# - 275617: Total Assets (Latest Fiscal Quarter FQ0) for banks
# - 275904: Analysis - Priority 3
#
# Field Data Types:
# - contextJson: Display names (e.g., "SP_TOTAL_REV", "SP_EBITDA")
# - secondary: Time period (FY0, FQ0, LTM, NTM, FY+1)
# - value: Filter ranges, ranking priorities, or specific values

COMPS_PEER_ANALYTICS_PAYLOAD = {
    "conversionInformation": {
        "keyCurrency": "USD",
        "nullValue": "NA",
        "dataLanguage": "en-US",
        "requestCulture": "en-US",
        "reportingBasis": "Current/Restated",
        "dateComparison": "Filing Date"
    },
    "clientContext": {
        "clientVersion": "1.0",
        "machineId": "00000000-0000-0000-0000-000000000000",
        "is64Bit": False,
        "excelCulture": "en-US",
        "requestSource": 5,
        "forceLocalQueries": False
    },
    "functionRequests": [
        {
            "perspective": "266637",
            "requestedPerspective": "266637",
            "operationType": 69,
            "fields": [
                {"primary": "329251", "secondary": "FY0", "contextJson": "\"SP_TOTAL_REV\""},
                {"primary": "329252", "secondary": "FY0", "contextJson": "\"SP_EBITDA\""},
                {"primary": "329255", "secondary": "FY0", "contextJson": "\"SP_NET_INC\""},
                {"primary": "329259", "secondary": "FY0", "contextJson": "\"SP_TOTAL_DEBT\""},
                {"primary": "329260", "secondary": "FY0", "contextJson": "\"SP_TOTAL_EQUITY\""},
                {"primary": "329249", "contextJson": "\"SP_MARKETCAP\""},
                {"primary": "334045", "secondary": "Issuer Credit Rating", "tertiary": "Local Currency LT|0", "contextJson": "\"RD_CREDIT_RATING_GLOBAL\""},
                {"primary": "331365", "contextJson": "\"SP_ISSUER_MDYS_LT_RATING\""},
                {"primary": "352813", "secondary": "FY2025", "contextJson": "\"SPG_ESG_SCORE_INDUSTRY\""}
            ],
            "query": {
                "keyPerspective": "266637",
                "baseCompany": "keyinstn",
                "queryFilters": [
                    {
                        "CriteriaItemList": [
                            {
                                "KeyOptionId": "8477",
                                "Caption": "All",
                                "IsDefault": True,
                                "Enabled": True,
                                "FieldMaskTypeString": "None",
                                "ChildCriteriaItemList": []
                            }
                        ],
                        "FilterGroupId": "8476",
                        "Caption": "Primary Industry",
                        "GroupType": 2,
                        "OptionType": 8,
                        "Column": 1,
                        "Required": True,
                        "DateDefaultType": ""
                    },
                    {
                        "CriteriaItemList": [
                            {
                                "KeyOptionId": "7652",
                                "Caption": "All Geographies",
                                "IsDefault": True,
                                "KeyProductQueryItem": "",
                                "Enabled": True,
                                "FieldMaskTypeString": "None",
                                "ChildCriteriaItemList": []
                            }
                        ],
                        "FilterGroupId": "7651",
                        "Caption": "Geography",
                        "GroupType": 2,
                        "OptionType": 8,
                        "Column": 1,
                        "Required": True,
                        "DateDefaultType": ""
                    },
                    {
                        "CriteriaItemList": [
                            {
                                "ChildCriteriaItemList": [],
                                "KeyOptionId": "7957",
                                "Caption": "Public Company",
                                "IsDefault": True,
                                "KeyProductQueryItem": "267967",
                                "ComparisonOperation": 0,
                                "ComparisonValue": "0",
                                "Enabled": True,
                                "LargeMask": "(0:1)",
                                "MaskKey": "267967",
                                "FieldMaskTypeString": "Industry"
                            }
                        ],
                        "FilterGroupId": "7956",
                        "Caption": "Company Type",
                        "GroupType": 2,
                        "OptionType": 1,
                        "Column": 1,
                        "Required": True,
                        "DateDefaultType": ""
                    },
                    {
                        "CriteriaItemList": [
                            {
                                "ChildCriteriaItemList": [],
                                "KeyOptionId": "7974",
                                "Caption": "Operating",
                                "IsDefault": True,
                                "KeyProductQueryItem": "268193",
                                "ComparisonOperation": 7,
                                "ComparisonValue": "0,15",
                                "Enabled": True,
                                "FieldMaskTypeString": "None"
                            },
                            {
                                "ChildCriteriaItemList": [],
                                "KeyOptionId": "7976",
                                "Caption": "Operating Subsidiary",
                                "IsDefault": True,
                                "KeyProductQueryItem": "268193",
                                "ComparisonOperation": 0,
                                "ComparisonValue": "1",
                                "Enabled": True
                            }
                        ],
                        "FilterGroupId": "7973",
                        "Caption": "Company Status",
                        "GroupType": 2,
                        "OptionType": 1,
                        "Column": 1,
                        "Required": True,
                        "DateDefaultType": ""
                    }
                ],
                "queryLineGroups": [
                    {
                        "groupName": "QueryLines",
                        "queryLines": [
                            {
                                "field": {
                                    "fieldKey": "321214",
                                    "exportFieldKey": "321214",
                                    "secondaryKeys": []
                                },
                                "value": "7652",
                                "displayText": "",
                                "operator": 7,
                                "connector": 0,
                                "relativeOperation": False,
                                "queryItemId": "92ad67ff-af12-485a-a671-62b6421ebde6",
                                "supressSelect": False,
                                "mathOperator": 0,
                                "mathValue": None
                            },
                            {
                                "field": {
                                    "fieldKey": "322992",
                                    "exportFieldKey": "322992",
                                    "secondaryKeys": []
                                },
                                "value": "7957",
                                "displayText": "",
                                "operator": 7,
                                "connector": 0,
                                "relativeOperation": False,
                                "queryItemId": "90c232ef-475d-415a-8b59-499269237f43",
                                "supressSelect": False,
                                "mathOperator": 0,
                                "mathValue": None
                            },
                            {
                                "field": {
                                    "fieldKey": "275891",
                                    "exportFieldKey": "275891",
                                    "secondaryKeys": []
                                },
                                "value": "'Operating','Operating Subsidiary'",
                                "displayText": "",
                                "operator": 7,
                                "connector": 0,
                                "relativeOperation": False,
                                "queryItemId": "6f1135b6-76fb-4ac1-92f2-3ae3d56878eb",
                                "supressSelect": False,
                                "mathOperator": 0,
                                "mathValue": None
                            },
                            {
                                "field": {
                                    "fieldKey": "275622",
                                    "exportFieldKey": "275622",
                                    "secondaryKeys": [
                                        {
                                            "displayValue": "Latest Fiscal Year",
                                            "keyJointHint": "sk_584",
                                            "keyOption": -1,
                                            "value": "FY0"
                                        }
                                    ]
                                },
                                "value": "[10]-[500]",
                                "operator": 17,
                                "connector": 0,
                                "relativeOperation": True,
                                "queryItemId": "3dce7bc3-1587-4c13-8dc5-aff024da4811",
                                "supressSelect": False,
                                "mathOperator": 0,
                                "mathValue": None
                            },
                            {
                                "field": {
                                    "fieldKey": "PEERRANKING",
                                    "secondaryKeys": []
                                },
                                "value": 5,
                                "displayText": "",
                                "operator": 23,
                                "connector": 0,
                                "relativeOperation": False,
                                "queryItemId": "8fc90bf9-5a22-41fb-bd48-162f16b259ca",
                                "supressSelect": False,
                                "mathOperator": 0,
                                "mathValue": None
                            }
                        ]
                    },
                    {
                        "groupName": "WhiteAndBlackListCriteria",
                        "queryLines": []
                    },
                    {
                        "groupName": "RankingCriteria",
                        "queryLines": [
                            {
                                "field": {
                                    "fieldKey": "275622",
                                    "secondaryKeys": [
                                        {
                                            "displayValue": "Latest Fiscal Year",
                                            "keyJointHint": "sk_584",
                                            "keyOption": -1,
                                            "value": "FY0"
                                        }
                                    ]
                                },
                                "value": 2,
                                "operator": 0,
                                "connector": 0,
                                "relativeOperation": False,
                                "queryItemId": "8ac0f9c1-c9b5-46be-9852-f301c9f5341b",
                                "supressSelect": False,
                                "mathOperator": 0,
                                "mathValue": None
                            },
                            {
                                "field": {
                                    "fieldKey": "329072",
                                    "secondaryKeys": []
                                },
                                "value": "3",
                                "operator": 0,
                                "connector": 0,
                                "relativeOperation": False,
                                "queryItemId": "18b06cc1-0b52-4667-80ee-9fb13bd82910",
                                "supressSelect": False,
                                "mathOperator": 0,
                                "mathValue": None
                            },
                            {
                                "field": {
                                    "fieldKey": "275913",
                                    "secondaryKeys": []
                                },
                                "value": "3",
                                "operator": 0,
                                "connector": 0,
                                "relativeOperation": False,
                                "queryItemId": "b96610b0-14be-4c1c-b207-171048c79d39",
                                "supressSelect": False,
                                "mathOperator": 0,
                                "mathValue": None
                            },
                            {
                                "field": {
                                    "fieldKey": "336466",
                                    "secondaryKeys": [
                                        {
                                            "displayValue": "keyinstn",
                                            "keyJointHint": "sk_1246",
                                            "keyOption": -1,
                                            "value": "keyinstn"
                                        }
                                    ]
                                },
                                "value": 2,
                                "operator": 0,
                                "connector": 0,
                                "relativeOperation": False,
                                "queryItemId": "c7693af0-db25-447c-869e-b5eca05305ec",
                                "supressSelect": False,
                                "mathOperator": 0,
                                "mathValue": None
                            },
                            {
                                "field": {
                                    "fieldKey": "334045",
                                    "secondaryKeys": [
                                        {
                                            "displayValue": "Issuer Credit Rating",
                                            "keyJointHint": "sk_1218",
                                            "keyOption": 0,
                                            "value": "Issuer Credit Rating"
                                        },
                                        {
                                            "displayValue": "Local Currency LT",
                                            "keyJointHint": "sk_1220",
                                            "keyOption": 0,
                                            "value": "Local Currency LT"
                                        },
                                        {
                                            "displayValue": "Current",
                                            "keyJointHint": "sk_50018",
                                            "keyOption": 0,
                                            "value": "0"
                                        }
                                    ]
                                },
                                "value": "1",
                                "operator": 0,
                                "connector": 0,
                                "relativeOperation": False,
                                "queryItemId": "0ec55bf2-643d-453f-b9d4-89484cf38e48",
                                "supressSelect": False,
                                "mathOperator": 0,
                                "mathValue": None
                            }
                        ]
                    }
                ]
            },
            "functionId": 0,
            "groomingStrategyApplied": False,
            "groomedColumnOrdinal": None,
            "groomedRowOrdinal": None,
            "conversionInfo": None,
            "requestedKeys": None,
            "userDefinedFormulas": []
        }
    ],
    "userDefinedFormulas": None,
    "userDefinedCriteria": None,
    "extensionPropertiesJson": "{\"maximumRowLimit\":250000,\"maximumColumnLimit\":200,\"maximumCellLimit\":10000000,\"queryLineToFieldMappings\":{\"queryLineToFieldMappings\":[]},\"userDefinedFormulas\":[],\"forceLocalQueries\":false,\"dotNetFrameworkVersion\":null}"
}

BANKS_PEER_ANALYTICS_PAYLOAD = {
    "conversionInformation": {
        "keyCurrency": "USD",
        "measurementStandard": 0,
        "conversionMode": 0,
        "nullValue": "NA",
        "dataLanguage": "en-US",
        "requestCulture": "en-US",
        "reportingBasis": "Current/Restated",
        "dateComparison": "Filing Date",
        "industryClassification": "0",
        "packageTrancheClassification": "0"
    },
    "clientContext": {
        "clientVersion": "1.0",
        "machineId": "00000000-0000-0000-0000-000000000000",
        "disableLogging": False,
        "is64Bit": False,
        "excelCulture": "en-US",
        "requestSource": 5,
        "forceLocalQueries": False
    },
    "functionRequests": [
        {
            "perspective": "266637",
            "requestedPerspective": "266637",
            "operationType": 69,
            "fields": [
                {"primary": "321214", "contextJson": None},
                {"primary": "275884", "contextJson": "\"SP_COMPANY_NAME\""},
                {"primary": "329258", "secondary": "FY0", "contextJson": "\"SP_TOTAL_ASSETS\""},
                {"primary": "275823", "secondary": "FY0", "contextJson": "\"SP_AMORT_LOANS_TO_DEPOSITS\""},
                {"primary": "329260", "secondary": "FY0", "contextJson": "\"SP_TOTAL_EQUITY\""},
                {"primary": "273925", "secondary": "FY0", "contextJson": None},
                {"primary": "275821", "secondary": "FY0", "contextJson": "\"SP_COST_TO_INC\""},
                {"primary": "329255", "secondary": "FY0", "contextJson": "\"SP_NET_INC\""},
                {"primary": "275828", "secondary": "FY0", "contextJson": "\"SP_PROBLEM_LOANS_TO_CUSTOMER_LOANS\""},
                {"primary": "275828", "secondary": "FY0", "contextJson": "\"SP_PROBLEM_LOANS_TO_CUSTOMER_LOANS\""},
                {"primary": "275825", "secondary": "FY0", "contextJson": "\"SP_TIER_1_RATIO\""},
                {"primary": "329267", "secondary": "FY0", "contextJson": "\"SP_ROE\""},
                {"primary": "329249", "contextJson": "\"SP_MARKETCAP\""},
                {"primary": "328502", "contextJson": "\"SP_PBV_X\""},
                {"primary": "334045", "secondary": "Issuer Credit Rating", "tertiary": "Local Currency LT|0", "contextJson": "\"RD_CREDIT_RATING_GLOBAL\""},
                {"primary": "331558", "contextJson": "\"SP_FITCH_LT_CREDIT_RATING_DEFAULT\""},
                {"primary": "331381", "contextJson": "\"SP_ISSUER_MDYS_LT_DEBT\""},
                {"primary": "275889", "contextJson": "\"SP_BUSINESS_DESCRIPTION\""},
                {"primary": "369391", "secondary": "FY0", "contextJson": "\"IQ_TOTAL_EMPLOYEES\""}
            ],
            "query": {
                "keyPerspective": "266637",
                "baseCompany": "keyinstn",
                "queryFilters": [
                    {
                        "CriteriaItemList": [
                            {
                                "KeyOptionId": "7652",
                                "Caption": "All Geographies",
                                "IsDefault": True,
                                "Enabled": True,
                                "ChildCriteriaItemList": []
                            }
                        ],
                        "FilterGroupId": "7651",
                        "Caption": "Geography",
                        "GroupType": 2,
                        "OptionType": 8,
                        "Column": 1,
                        "Required": True,
                        "DateDefaultType": ""
                    },
                    {
                        "CriteriaItemList": [
                            {
                                "ChildCriteriaItemList": [],
                                "KeyOptionId": "7957",
                                "Caption": "Public Company",
                                "IsDefault": True,
                                "KeyProductQueryItem": "267967",
                                "ComparisonOperation": 0,
                                "ComparisonValue": "0",
                                "FormOrder": 10,
                                "LowerBound": None,
                                "Enabled": True,
                                "Mask": "",
                                "LargeMask": "(0:1)",
                                "MaskKey": "267967",
                                "FieldMaskTypeString": "Industry"
                            }
                        ],
                        "FilterGroupId": "7956",
                        "FilterGroupIdReplace": "",
                        "Caption": "Company Type",
                        "GroupType": 2,
                        "OptionType": 1,
                        "FormOrder": 20,
                        "OnlineServicesEnabled": False,
                        "OnlineServices": [],
                        "Column": 1,
                        "Required": True,
                        "DateDefaultType": ""
                    },
                    {
                        "CriteriaItemList": [
                            {
                                "ChildCriteriaItemList": [],
                                "KeyOptionId": "7974",
                                "Caption": "Operating",
                                "IsDefault": True,
                                "KeyProductQueryItem": "268193",
                                "ComparisonOperation": 7,
                                "ComparisonValue": "0,15",
                                "Enabled": True,
                                "FieldMaskTypeString": "None",
                                "ClientContextJson": None
                            }
                        ],
                        "FilterGroupId": "7973",
                        "FilterGroupIdReplace": "",
                        "Caption": "Company Status",
                        "GroupType": 2,
                        "OptionType": 1,
                        "Column": 1,
                        "Required": True,
                        "DateDefaultType": ""
                    },
                    {
                        "CriteriaItemList": [
                            {
                                "KeyOptionId": "8477",
                                "Caption": "All",
                                "IsDefault": True,
                                "KeyProductQueryItem": "",
                                "ComparisonOperation": None,
                                "ComparisonValue": "",
                                "FormOrder": 10,
                                "Enabled": True,
                                "FieldMaskType": "None",
                                "ClientContextJson": None,
                                "ChildCriteriaItemList": []
                            }
                        ],
                        "FilterGroupId": "8476",
                        "FilterGroupIdReplace": "",
                        "Caption": "Primary Industry",
                        "GroupType": 2,
                        "OptionType": 8,
                        "FormOrder": 40,
                        "Column": 1,
                        "Required": True,
                        "DateDefaultType": ""
                    }
                ],
                "queryLineGroups": [
                    {
                        "groupName": "QueryLines",
                        "queryLines": [
                            {
                                "field": {
                                    "fieldKey": "321214",
                                    "exportFieldKey": "321214",
                                    "secondaryKeys": []
                                },
                                "value": "7652",
                                "displayText": "",
                                "operator": 7,
                                "connector": 0,
                                "relativeOperation": False,
                                "queryItemId": "f553c681-813c-4d93-b161-88d5269d5000",
                                "supressSelect": False,
                                "mathOperator": 0,
                                "mathValue": None
                            },
                            {
                                "field": {
                                    "fieldKey": "322992",
                                    "exportFieldKey": "322992",
                                    "secondaryKeys": []
                                },
                                "value": "7957",
                                "operator": 7,
                                "connector": 0,
                                "relativeOperation": False,
                                "queryItemId": "156ae6f3-d472-4674-93e5-7475ef49d350",
                                "supressSelect": False,
                                "mathOperator": 0,
                                "mathValue": None
                            },
                            {
                                "field": {
                                    "fieldKey": "275891",
                                    "exportFieldKey": "275891",
                                    "secondaryKeys": []
                                },
                                "value": "Operating",
                                "operator": 7,
                                "connector": 0,
                                "relativeOperation": False,
                                "queryItemId": "0e886aa2-51f2-4119-bbf9-143421dd47fb",
                                "supressSelect": False,
                                "mathOperator": 0,
                                "mathValue": None
                            },
                            {
                                "field": {
                                    "fieldKey": "275617",
                                    "exportFieldKey": "275617",
                                    "secondaryKeys": [
                                        {
                                            "displayValue": "Latest Fiscal Quarter",
                                            "keyJointHint": "sk_584",
                                            "keyOption": -1,
                                            "value": "FQ0"
                                        }
                                    ]
                                },
                                "value": "[5]-[1000]",
                                "displayText": "",
                                "operator": 17,
                                "connector": 0,
                                "relativeOperation": True,
                                "queryItemId": "207ef1cc-4ea8-4360-918f-5f7182dcba07",
                                "supressSelect": False,
                                "mathOperator": 0,
                                "mathValue": None
                            },
                            {
                                "field": {
                                    "fieldKey": "PEERRANKING",
                                    "secondaryKeys": []
                                },
                                "value": 5,
                                "operator": 23,
                                "connector": 0,
                                "relativeOperation": False,
                                "queryItemId": "fedc8a2a-313b-4cc8-a491-85bb0c0d0b38",
                                "supressSelect": False,
                                "mathOperator": 0,
                                "mathValue": None
                            }
                        ]
                    },
                    {
                        "groupName": "WhiteAndBlackListCriteria",
                        "queryLines": []
                    },
                    {
                        "groupName": "RankingCriteria",
                        "queryLines": [
                            {
                                "field": {
                                    "fieldKey": "275617",
                                    "secondaryKeys": [
                                        {
                                            "displayValue": "Latest Fiscal Quarter",
                                            "keyJointHint": "sk_584",
                                            "keyOption": -1,
                                            "value": "FQ0"
                                        }
                                    ]
                                },
                                "value": 2,
                                "operator": 0,
                                "connector": 0,
                                "relativeOperation": False,
                                "queryItemId": "a230b38b-8d6e-46d1-b862-e2f75f73494f",
                                "supressSelect": False,
                                "mathOperator": 0,
                                "mathValue": None
                            },
                            {
                                "field": {
                                    "fieldKey": "336466",
                                    "secondaryKeys": [
                                        {
                                            "displayValue": "keyinstn",
                                            "keyJointHint": "sk_1246",
                                            "keyOption": -1,
                                            "value": "keyinstn"
                                        }
                                    ]
                                },
                                "value": 2,
                                "operator": 0,
                                "connector": 0,
                                "relativeOperation": False,
                                "queryItemId": "e499776a-1622-4fb3-bba2-ca499b3f569b",
                                "supressSelect": False,
                                "mathOperator": 0,
                                "mathValue": None
                            },
                            {
                                "field": {
                                    "fieldKey": "275913",
                                    "secondaryKeys": []
                                },
                                "value": "3",
                                "operator": 0,
                                "connector": 0,
                                "relativeOperation": False,
                                "queryItemId": "d0bd17ba-99c5-4db6-bb9f-ddaf1b819773",
                                "supressSelect": False,
                                "mathOperator": 0,
                                "mathValue": None
                            },
                            {
                                "field": {
                                    "fieldKey": "275904",
                                    "secondaryKeys": []
                                },
                                "value": "3",
                                "operator": 0,
                                "connector": 0,
                                "relativeOperation": False,
                                "queryItemId": "f0f9a6d6-6322-4564-aacc-38fd83349f57",
                                "supressSelect": False,
                                "mathOperator": 0,
                                "mathValue": None
                            },
                            {
                                "field": {
                                    "fieldKey": "334045",
                                    "secondaryKeys": [
                                        {
                                            "displayValue": "Issuer Credit Rating",
                                            "keyJointHint": "sk_1218",
                                            "keyOption": 0,
                                            "value": "Issuer Credit Rating"
                                        },
                                        {
                                            "displayValue": "Local Currency LT",
                                            "keyJointHint": "sk_1220",
                                            "keyOption": 0,
                                            "value": "Local Currency LT"
                                        },
                                        {
                                            "displayValue": "Current",
                                            "keyJointHint": "sk_50018",
                                            "keyOption": 0,
                                            "value": "0"
                                        }
                                    ]
                                },
                                "value": "1",
                                "operator": 0,
                                "connector": 0,
                                "relativeOperation": False,
                                "queryItemId": "d4fcaa61-0375-4c9f-ae55-2e99c99f1549",
                                "supressSelect": False,
                                "valueField": None,
                                "mathOperator": 0,
                                "mathValue": None
                            }
                        ]
                    }
                ]
            },
            "functionId": 0
        }
    ],
    "userDefinedFormulas": None,
    "userDefinedCriteria": None,
    "extensionPropertiesJson": "{\"maximumRowLimit\":250000,\"maximumColumnLimit\":200,\"maximumCellLimit\":10000000,\"queryLineToFieldMappings\":{\"queryLineToFieldMappings\":[]},\"userDefinedFormulas\":[],\"forceLocalQueries\":false,\"dotNetFrameworkVersion\":null}"
}


