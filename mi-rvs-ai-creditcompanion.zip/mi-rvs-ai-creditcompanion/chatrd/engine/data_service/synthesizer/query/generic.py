import logging
from typing import Optional

import pandas as pd

from chatrd.engine.components.query_analyzer.translator.utils import (
    Get_translation_result,
)
from chatrd.engine.data_service.schema import (
    Analyzer,
    ProcessorInput,
    Retriever,
    Synthesizer,
)
from chatrd.engine.data_service.synthesizer.base import BaseSynthesizer
from chatrd.engine.data_service.synthesizer.query.utils import (
    filter_criteria_template,
    generate_template,
    time_period_extractor,
)
from chatrd.engine.data_service.synthesizer.utils import full_response, get_api_info

logger = logging.getLogger(__name__)


class GenericQuerySynthesizer(BaseSynthesizer):
    def synthesize(
        self,
        processor: ProcessorInput = None,
        analyzer: Optional[Analyzer] = None,
        retriever: Retriever = None,
    ) -> Synthesizer:
        user_input = processor.user_input
        analyzer_error_message = analyzer.error_message
        screener_payload_object = retriever.screener_payload_object
        screener_payload = retriever.screener_payload
        df = pd.DataFrame(retriever.api_data)
        count = retriever.total_count
        error = False

        if analyzer_error_message:
            logger.error("Bypassing synthesizer due to error in analyzer")
            template = analyzer_error_message
            footnote = ""
            source_url = [("", "")]
            isFinancialMetrics = False
            error = True
        else:
            if count > 0:
                if (
                    "CreditStats Direct Sector" in screener_payload_object.text_dict
                    and screener_payload_object.text_dict["CreditStats Direct Sector"]
                ):
                    retriever_financialMetrics = screener_payload_object.text_dict["CreditStats Direct Sector"]
                else:
                    retriever_financialMetrics = None

                date_value = time_period_extractor(screener_payload, screener_payload_object)
                footnote = filter_criteria_template(
                    screener_payload_object=screener_payload_object, date_value=date_value
                )
                template = generate_template(date_value, user_input, retriever_financialMetrics)
                source_url = [
                    (
                        "S&P Global Ratings Database",
                        "https://www.capitaliq.spglobal.com/web/client?auth=inherit#office/screener?perspective=266637",
                    )
                ]
                logger.info(f"Response from LLM: {template}")
            else:
                error = True
                logger.info("No data found for the query.")
                template = "CreditCompanion<sup>TM</sup> is having trouble generating a response matching your criteria because the search is too specific, and we couldn't find any results that match. Please try and broaden your search to get more results and share your feedback if you think there's something wrong."
                footnote = ""
                source_url = [("", "")]
                retriever_financialMetrics = None

            isFinancialMetrics = bool(retriever_financialMetrics)
        template = Get_translation_result(template, processor.original_language)
        template = template.result()

        response = full_response(
            template=template,
            data=df,
            data_type="table",
            count=count,
            footnote=footnote,
            isFinancialMetrics=isFinancialMetrics,
            error=error,
        )

        api_info = get_api_info(
            api_method=retriever.api_method,
            api_type=retriever.api_type,
            url=retriever.url,
            screener_payload=retriever.screener_payload,
        )

        return Synthesizer(data_service_response=response, source_description=source_url, api_info=api_info)
