import asyncio
import json
from decimal import Decimal
import logging
import os
from contextlib import asynccontextmanager
from typing import Dict, List, Optional, Any, Literal
import uuid
from datetime import datetime

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Depends, Header, APIRouter, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse, Response
from pydantic import BaseModel, TypeAdapter

from src.synthia.config.api_config import get_config
from src.synthia.persistence import feedback_queries
from src.synthia.persistence.database_manager import (
    initialize_connection_pool,
    close_connection_pool,
    close_main_connection_pool,
    initialize_service_connection_pool,
)
from src.synthia.persistence.report_monitor import get_monitor
from src.synthia.persistence.template_metadata_repository import DatabaseTemplateMetadataRepository
from src.synthia.queue.queue_consumer import ReportQueueConsumer
from src.synthia.queue.queue_publisher import get_publisher
from src.synthia.schemas.template import Template, TemplateSection
from src.synthia.schemas.workflow import (
    PeerCompany,
    PromptStatusEnum,
    ReportConfig,
    ReportStatus,
    ReportStatusEnum,
)
from src.synthia.services.template_management_service import TemplateManagementService, CreateCompanyTemplateRequest, \
    UpdateCompanyTemplateRequest
from src.synthia.services.template_migration_service import TemplateMigrationService
from src.synthia.services.template_service import TemplateService, CompanyTemplate
from src.synthia.user_profile.user_profile_provider import fetch_user_profile_data, fetch_company_name
from src.synthia.user_profile.auth_strategy import is_creditmemo_user
from src.synthia.utils.logging_config import configure_logging
from src.synthia.persistence.prompt_monitor import get_prompt_monitor
from src.synthia.utils.logging_context import clear_logging_context, \
    set_job_id_logging_context, set_prompt_id_logging_context, set_correlation_id_logging_context, \
    set_api_path_logging_context, get_correlation_id_logging_context
from src.synthia.utils.template_util import load_all_templates
from uuid import UUID


load_dotenv(override=True)

# Configure logging
logger = configure_logging(logger_name=__name__, log_file="synthia-service.log")
logger.setLevel(logging.INFO)

logging.getLogger("httpcore.http11").setLevel(logging.WARNING)
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("urllib3").setLevel(logging.WARNING)
logging.getLogger("mcp.client.streamable_http").setLevel(logging.WARNING)
logging.getLogger("httpcore").setLevel(logging.WARNING)

cfg = get_config()


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    logger.info("Initializing connection pool...")
    if os.getenv("QUEUE_BACKEND", "local").lower() == "local":
        await initialize_connection_pool()
    else:
        await initialize_service_connection_pool()
    logger.info("Connection pool initialized successfully")
    queue_consumer = None

    try:
        if os.getenv("QUEUE_BACKEND", "local").lower() == "local":
            logger.warning("Running in local environment.")
            logger.info("Starting queue consumer...")
            queue_consumer = ReportQueueConsumer()
            asyncio.create_task(queue_consumer.run_forever())
            logger.info("Queue consumer started successfully")

        yield
        # Shutdown
        logger.info("Closing connection pool...")
        if os.getenv("QUEUE_BACKEND", "local").lower() == "local":
            await close_connection_pool()
        else:
            await close_main_connection_pool()
        logger.info("Connection pool closed successfully")

        if queue_consumer:
            logger.info("Shutting queue consumer ...")
            await queue_consumer.stop()
            logger.info("Consumer Shut successfully...")

    finally:
        logger.info("Gracefully terminated")


app = FastAPI(
    title="Synthia Service API",
    description="API for triggering/polling and retrieving creditmemo reports",
    version="1.0.0",
    lifespan=lifespan,
    docs_url=f"{cfg['SYNTHIA_SERVICE_API_PREFIX']}/docs",
    redoc_url=f"{cfg['SYNTHIA_SERVICE_API_PREFIX']}/redoc",
    openapi_url=f"{cfg['SYNTHIA_SERVICE_API_PREFIX']}/openapi.json",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

router = APIRouter()


@app.middleware("http")
async def add_logging_context(request: Request, call_next):
    """
    Middleware to set correlation_id, and api_path for logging.
    """
    # Try to get correlation_id from multiple sources
    correlation_id = request.headers.get("x-amzn-requestid")

    # If not in headers, try to get from AWS Lambda context via ASGI scope
    if not correlation_id:
        aws_context = request.scope.get("aws.context")
        if aws_context:
            correlation_id = aws_context.aws_request_id

    # Fallback to UUID if still not found
    if not correlation_id:
        correlation_id = str(uuid.uuid4())
    set_correlation_id_logging_context(correlation_id)

    api_path = request.url.path
    set_api_path_logging_context(api_path)

    try:
        response = await call_next(request)
        response.headers["x-correlation-id"] = correlation_id
        return response
    finally:
        clear_logging_context()


template_service = TemplateService(DatabaseTemplateMetadataRepository())
template_migration_service = TemplateMigrationService()
template_management_service = TemplateManagementService(DatabaseTemplateMetadataRepository())


class ReportRequest(BaseModel):
    """
    Request model for generating a report.
    """

    topic: str
    job_id: Optional[str] = ""
    style: Optional[str] = "business"
    depth: Optional[int] = 3
    sections: Optional[int] = 5
    input_section_title: Optional[str] = ""
    peer_companies: Optional[List[PeerCompany]] = None
    isPeersChanged: Optional[bool] = False


class ReportResponse(BaseModel):
    """
    Response model for report generation request.
    """

    job_id: str
    status: str
    message: str


class OutlineApprovalRequest(BaseModel):
    """
    Request model for approving or rejecting a report outline.
    """

    approved: bool
    feedback: Optional[str] = None
    revised_sections: Optional[int] = None
    revised_depth: Optional[int] = None
    user_sections: Optional[List[Dict[str, Any]]] = None


class ReportPromptRequest(BaseModel):
    """
    Request model for submitting a post report generation chat prompt for section edits.
    """

    job_id: str
    prompt_id: str
    previous_prompt_id: Optional[str] = None
    prompt: str
    section_id: str
    section_name: Optional[str] = None


class SectionEditApprovalRequest(BaseModel):
    job_id: str
    prompt_id: str
    action: Literal["approve", "decline", "retry"]

class UpdateFeedbackRequest(BaseModel):
    job_id: str
    sentiment: str
    feedback: Optional[str] = None
    tags: List[str] = []
    section_title: Optional[str] = None


def get_token(authorization: str = Header(None)):
    """
    Dependency to extract the token from the Authorization header.
    """
    if not authorization:
        logger.warning("No Authorization header provided")
        return None

    return authorization

async def log_context_dependency(request: Request):
    job_id = request.path_params.get("job_id")
    if not job_id:
        try:
            body = await request.body()
            if body:
                data = json.loads(body)
                job_id = data.get("job_id")
        except Exception:
            job_id = None

    set_job_id_logging_context(job_id)

    prompt_id = request.path_params.get("prompt_id")
    if not prompt_id:
        try:
            body = await request.body()
            if body:
                data = json.loads(body)
                prompt_id = data.get("prompt_id")
        except Exception:
            prompt_id = None

    set_prompt_id_logging_context(prompt_id)


@router.get("/")
async def root():
    """
    Root endpoint to verify the service is running.
    """
    return {"status": "online", "message": "Synthia Service API is running"}


@router.get("/health")
async def health_check():
    """
    Health check endpoint.
    """
    return {"status": "ok"}


@router.post("/reports/{job_id}/approve-outline")
async def approve_outline(
    http_request: Request,
    job_id: str,
    request: OutlineApprovalRequest,
    token: str = Depends(get_token),
    dep=Depends(log_context_dependency),
):
    """
    Approve or reject the generated outline for a report.
    """
    refresh_token = http_request.headers.get("Oauth_refresh_token")
    # Log token and request details
    logger.info(f"Approve outline endpoint called for job_id: {job_id}")
    logger.debug(f"Token received: {token}")
    logger.debug(
        f"Request data: approved={getattr(request, 'approved', None)}, feedback={getattr(request, 'feedback', None)}"
    )

    status_tracker = get_monitor(token)
    state: ReportStatus = await status_tracker.get_job(job_id)
    if not state:
        logger.warning(f"Job {job_id} not found")
        raise HTTPException(status_code=404, detail="Job not found")

    if state.status != "awaiting_approval":
        raise HTTPException(
            status_code=400,
            detail=f"Job is not awaiting approval. Current status: {state.status}",
        )

    if request.approved:
        logger.info(
            f"Outline for job {job_id} approved. Continuing with report generation."
        )

        outline_adapter = TypeAdapter(List[TemplateSection])
        outline = (
            outline_adapter.validate_python(request.user_sections)
            if request.user_sections
            else None
        )

        update_report = ReportStatus(
            job_id=job_id,
            status=ReportStatusEnum.OUTLINE_APPROVED,
            outline=outline,
            progress=0.1,
        )
        await status_tracker.update_job(job_id, update_report)

        await get_publisher().publish_outline_approval(
            job_id=job_id,
            approved=True,
            user_sections=request.user_sections,
            token=token,
            refresh_token=refresh_token,
            correlation_id=get_correlation_id_logging_context()
        )
        return {"status": "approved", "message": "Report generation continuing"}
    else:
        logger.info(
            f"Outline for job {job_id} rejected. Starting over with new parameters."
        )
        await status_tracker.reject_outline(
            job_id, request.revised_sections, request.revised_depth
        )

        await get_publisher().publish_outline_approval(
            job_id=job_id,
            approved=False,
            revised_sections=request.revised_sections,
            revised_depth=request.revised_depth,
            token=token,
            correlation_id=get_correlation_id_logging_context()
        )
        return {
            "status": "rejected",
            "message": "Report generation restarting with new parameters",
        }


def is_valid_uuid(job_id: str) -> bool:
    """
    Return True if job_id is a valid UUID string.
    """
    try:
        uuid.UUID(job_id)
        return True
    except (ValueError, AttributeError, TypeError):
        return False


@router.post("/reports", response_model=ReportResponse)
async def create_report(
        request: Request,
        request_body: ReportRequest,
        token: str = Depends(get_token),
        dep=Depends(log_context_dependency),
):
    """
    Create a new report generation job.
    """

    # Check if user has CreditMemo access
    if not await is_creditmemo_user(token):
        logger.warning("User does not have CreditMemo access")
        raise HTTPException(
            status_code=401, 
            detail="Unauthorized: User does not have CreditMemo access"
        )
    
    refresh_token = request.headers.get("Oauth_refresh_token")
    # Log token and request details
    logger.info("Create report endpoint called")
    logger.debug(f"Token received: {token}")
    logger.info(
        f"Report request - topic: {getattr(request_body, 'topic', None)}, style: {getattr(request_body, 'style', None)}, depth: {getattr(request_body, 'depth', None)}, sections: {getattr(request_body, 'sections', None)}"
    )

    try:
        job_id = request_body.job_id

        if job_id and is_valid_uuid(job_id):
            logger.info(f"Using provided job_id: {job_id}")
        elif job_id:
            logger.warning(f"Provided job_id is invalid: {job_id}, generating new one")
            job_id = str(uuid.uuid4())
            logger.info(f"Generated job_id: {job_id}")
        else:
            job_id = str(uuid.uuid4())
            logger.info(f"No job_id provided, generated: {job_id}")

        set_job_id_logging_context(job_id)

        status_tracker = get_monitor(token)
        # Create report configuration
        report_config = ReportConfig(
            topic=request_body.topic,
            job_id=job_id,
            style=request_body.style,
            depth=request_body.depth,
            num_sections=request_body.sections,
            input_section_title=request_body.input_section_title,
            peers=request_body.peer_companies,
            isPeersChanged=request_body.isPeersChanged,
        )

        await status_tracker.create_job(
            job_id=job_id,
            report_config=report_config,
        )
        logger.info(f"Job {job_id} created in database")

        # Queue the report generation instead of using background tasks
        await get_publisher().publish_generate_report(
            job_id=job_id,
            token=token,
            refresh_token=refresh_token,
            correlation_id=get_correlation_id_logging_context()
        )
        logger.info(f"Report generation message published for job {job_id}")

        return {
            "job_id": job_id,
            "status": "accepted",
            "message": "Report generation started",
        }
    except Exception as e:
        import traceback
        logger.error(f"Failed to start report generation: {str(e)}")
        logger.error(traceback.format_exc())
        raise HTTPException(
            status_code=500, detail=f"Failed to start report generation: {str(e)}"
        )


@router.get("/reports")
async def list_active_jobs(token: str = Depends(get_token)):
    """
    List all active report generation job.
    Args:
        token: Token for authentication
    """
    # Log token and request details
    logger.info("List active jobs endpoint called")
    logger.debug(f"Token received: {token}")

    status_tracker = get_monitor(token)
    job_ids = await status_tracker.list_job_ids()
    logger.info(f"Retrieved {len(job_ids)} active job IDs")
    return job_ids


@router.get("/reports/jobs")
async def fetchJobs(token: str = Depends(get_token)) -> List[dict]:
    """
    Query a PostgreSQL table and return results (list of job ids).
    """
    try:
        monitor = get_monitor(token)
        jobs = await monitor.list_job_ids()
        return jobs
    except Exception as e:
        logger.error(f"Database query failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Database query failed: {str(e)}")


def _remove_prompt_from_sections(sections):
    """
    Recursively remove 'prompt' field from sections and their nested sections.
    """
    if not sections:
        return sections
    
    cleaned_sections = []
    for section in sections:
        # Create a copy of the section without the prompt field
        cleaned_section = {k: v for k, v in section.items() if k != "prompt"}
        
        # If there are nested sections, recursively clean them too
        if "sections" in cleaned_section and cleaned_section["sections"]:
            cleaned_section["sections"] = _remove_prompt_from_sections(cleaned_section["sections"])
        
        cleaned_sections.append(cleaned_section)
    
    return cleaned_sections


@router.get("/reports/{job_id}")
async def get_report_status(
        job_id: str,
        token: str = Depends(get_token),
        dep=Depends(log_context_dependency)
):
    """
    Get the status of a report generation job.
    Args:
        job_id: Report job ID
        token: token for authentication
    """
    # Log token and request details
    logger.info(f"Get report status endpoint called for job_id: {job_id}")
    logger.debug(f"Token received: {token}")

    # Log relevant headers
    status_tracker = get_monitor(token)
    if not await status_tracker.job_exists(job_id):
        logger.warning(f"Job {job_id} not found in database")
        raise HTTPException(status_code=404, detail="Job not found")

    state = await status_tracker.get_job(job_id)
    if not state:
        logger.warning(f"Report {job_id} not found despite job existing")
        raise HTTPException(status_code=404, detail="Report not found")

    logger.info(f"Retrieved status for job {job_id}: {state.status}")
    
    # Convert to dict and remove prompt fields from outline
    state_dict = state.model_dump() if hasattr(state, 'model_dump') else state.__dict__
    
    # Remove prompt field from outline sections recursively
    if state_dict.get("outline"):
        state_dict["outline"] = _remove_prompt_from_sections(state_dict["outline"])
    
    return state_dict

class TemplatesResponse(BaseModel):
    templates: Dict[str, Template]


@router.get("/templates", response_model=TemplatesResponse)
async def get_templates() -> TemplatesResponse:
    """
    Get all available templates from the templates directory.
    """
    try:
        templates_dict = await load_all_templates()
        return TemplatesResponse(templates=templates_dict)

    except Exception as e:
        import traceback
        logger.error(f"Error loading templates: {str(e)}")
        logger.error(traceback.format_exc())
        raise HTTPException(
            status_code=500, detail=f"Error loading templates: {str(e)}"
        )


@router.get("/v2/templates")
async def get_company_templates_metadata(company_name: str | None = None, token: str | None = Depends(get_token)) -> List[CompanyTemplate]:
    selected_company_name = await fetch_company_name(token) if token else company_name
    return await template_service.get_company_templates_metadata(selected_company_name)


@router.get("/v2/templates/{template_id}/content")
async def get_company_template_content_by_id(template_id: UUID, token: str | None = Depends(get_token)) -> Template | None:
    if not token:
        raise HTTPException(status_code=401) # no support for getting template content without the company name
    company_name = await fetch_company_name(token)
    template_if_found = await template_service.get_company_template_content_by_id(company_name, template_id)
    if not template_if_found:
        raise HTTPException(status_code=404, detail=f'No template found by company: {company_name} id: {template_id}')
    return template_if_found


@router.post("/v2/templates", status_code=201, response_class=Response)
async def create_company_template_metadata(template: CreateCompanyTemplateRequest):
    success, message = await template_management_service.create_company_template_metadata(template)
    if not success:
        raise HTTPException(status_code=422, detail=message)


@router.put("/v2/templates/{company_name}/{template_id}", response_class=Response)
async def update_company_template_metadata(company_name: str, template_id: UUID, template: UpdateCompanyTemplateRequest):
    success, message = await template_management_service.update_company_template_metadata(company_name, template_id, template)
    if not success:
        raise HTTPException(status_code=422, detail=message)


@router.delete("/v2/templates/{company_name}/{template_id}", response_class=Response)
async def delete_company_template_metadata(company_name: str, template_id: UUID):
    await template_management_service.delete_company_template_metadata(company_name, template_id)


@router.post("/template_migrations", status_code=204, response_class=Response)
async def migrate_templates():
    await template_migration_service.migrate_templates()


@router.get("/utils/mcps")
async def get_mcp_servers(
    token: str = Depends(get_token), output: Optional[str] = None
):
    """
    Get all tools for each MCP server, grouped by server.
    Returns HTML table by default, or JSON if output=json.
    Only includes: Server Name, Server Url, Args Schema, Description, Name, Response Format.
    """
    from src.synthia.mcp_client.mcp_client_async import create_mcp_client

    if not token:
        raise HTTPException(status_code=401, detail="Authentication token required")

    mcp_client = None
    try:
        mcp_client = await create_mcp_client(token)
        server_tools = {}

        # Collect tools from all servers - use correct attribute/method
        if hasattr(mcp_client, "clients"):
            client_items = mcp_client.clients.items()
        elif hasattr(mcp_client, "get_clients"):
            client_items = mcp_client.get_clients().items()
        elif hasattr(mcp_client, "_clients"):
            client_items = mcp_client._clients.items()
        else:
            # Try to get tools directly from the client if it's a single client
            try:
                tools = await mcp_client.get_tools()
                # Filter tools to only include requested fields
                filtered_tools = []
                for tool in tools:
                    tool_dict = (
                        tool.model_dump()
                        if hasattr(tool, "model_dump")
                        else vars(tool) if hasattr(tool, "__dict__") else tool
                    )
                    filtered_tool = _filter_tool_fields(
                        tool_dict, "Single Client", "unknown"
                    )
                    filtered_tools.append(filtered_tool)

                server_tools["unknown"] = filtered_tools
                client_items = []
            except Exception as e:
                logger.error(f"Could not access MCP client tools: {str(e)}")
                raise HTTPException(
                    status_code=500, detail="Could not access MCP client structure"
                )

        for server_url, client in client_items:
            try:
                tools = await client.get_tools()
                # Extract server name
                if server_url.startswith("http"):
                    from urllib.parse import urlparse

                    parsed = urlparse(server_url)
                    server_name = parsed.netloc or parsed.path.split("/")[-1]
                elif "/" in server_url:
                    server_name = server_url.split("/")[-1]
                else:
                    server_name = server_url

                # Filter tools to only include requested fields
                filtered_tools = []
                for tool in tools:
                    tool_dict = (
                        tool.model_dump()
                        if hasattr(tool, "model_dump")
                        else vars(tool) if hasattr(tool, "__dict__") else tool
                    )
                    filtered_tool = _filter_tool_fields(
                        tool_dict, server_name, server_url
                    )
                    filtered_tools.append(filtered_tool)

                server_tools[server_url] = filtered_tools
            except Exception as e:
                logger.warning(
                    f"Failed to get tools from server {server_url}: {str(e)}"
                )
                server_tools[server_url] = []

        if output == "json":
            return JSONResponse(content=server_tools)

        # Generate HTML response efficiently
        return HTMLResponse(content=_generate_mcp_tools_html(server_tools))

    except Exception as e:
        import traceback
        logger.error(f"Failed to get MCP servers: {str(e)}")
        logger.error(traceback.format_exc())
        raise HTTPException(
            status_code=500, detail=f"Failed to get MCP servers: {str(e)}"
        )
    finally:
        # Ensure proper cleanup if needed
        if mcp_client and hasattr(mcp_client, "close"):
            try:
                await mcp_client.close()
            except Exception as e:
                logger.warning(f"Error closing MCP client: {str(e)}")


def _filter_tool_fields(tool_dict: dict, server_name: str, server_url: str) -> dict:
    """
    Filter tool dictionary to only include requested fields.
    """
    filtered_tool = {
        "server_name": server_name,
        "server_url": server_url,
        "name": tool_dict.get("name", ""),
        "description": tool_dict.get("description", ""),
        "response_format": tool_dict.get("response_format", ""),
        "args_schema": tool_dict.get("args_schema", tool_dict.get("inputSchema", "")),
    }
    return filtered_tool


def _generate_mcp_tools_html(server_tools: Dict[str, List[Dict]]) -> str:
    """
    Generate HTML table for MCP servers and tools with only requested fields.
    """
    import json
    from html import escape

    html_parts = [
        "<html><head><style>",
        "table { border-collapse: collapse; width: 100%; margin-bottom: 20px; }",
        "th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }",
        "th { background-color: #f2f2f2; font-weight: bold; }",
        "pre { background-color: #f8f8f8; padding: 4px; margin: 0; white-space: pre-wrap; }",
        "h2 { color: #333; }",
        ".server-name { background-color: #e8f4fd; font-weight: bold; }",
        ".server-url { background-color: #e8f4fd; font-style: italic; }",
        ".serial-number { text-align: center; font-weight: bold; }",
        "</style></head><body>",
        "<h2>MCP Servers and Tools</h2>",
    ]

    # Collect all tools with server info
    all_tools = []
    for server_url, tools in server_tools.items():
        all_tools.extend(tools)

    if not all_tools:
        html_parts.append("<p><em>No tools found across all servers.</em></p>")
    else:
        # Define the specific columns we want to display (with Serial Number first)
        columns = [
            "serial_number",
            "server_name",
            "server_url",
            "name",
            "description",
            "args_schema",
        ]
        column_headers = [
            "Serial Number",
            "Server Name",
            "Server Url",
            "Tool Name",
            "Description",
            "Args Schema",
        ]

        # Build consolidated table
        html_parts.append("<table>")
        html_parts.append(
            "<tr>"
            + "".join(f"<th>{escape(header)}</th>" for header in column_headers)
            + "</tr>"
        )

        for index, tool in enumerate(all_tools, 1):
            # Add serial number to the tool data
            tool["serial_number"] = index

            html_parts.append("<tr>")
            for column in columns:
                value = tool.get(column, "")
                css_class = ""
                if column == "server_name":
                    css_class = "server-name"
                elif column == "server_url":
                    css_class = "server-url"
                elif column == "serial_number":
                    css_class = "serial-number"

                if isinstance(value, (dict, list)):
                    formatted_value = f"<pre>{escape(json.dumps(value, indent=2, ensure_ascii=False))}</pre>"
                else:
                    formatted_value = escape(str(value))

                class_attr = f' class="{css_class}"' if css_class else ""
                html_parts.append(f"<td{class_attr}>{formatted_value}</td>")
            html_parts.append("</tr>")
        html_parts.append("</table>")

    html_parts.append("</body></html>")
    return "".join(html_parts)


@router.post("/reports/section-edit")
async def section_edit(
    request: ReportPromptRequest,
    token: str = Depends(get_token),
    dep=Depends(log_context_dependency),
) -> Dict[str, str]:
    """
    Submit section edit request for a generated report.
    """

    job_id = request.job_id
    logger.info(f"Section edit endpoint called for job_id: {job_id}")
    logger.debug(f"Token received: {token}")
    logger.debug(
        f"Request data: prompt={getattr(request, 'prompt', None)}, section_name={getattr(request, 'section_name', None)}"
    )

    status_tracker = get_monitor(token)
    state: ReportStatus = await status_tracker.get_job(job_id)
    if not state:
        logger.warning(f"Job {job_id} not found")
        raise HTTPException(status_code=404, detail="Job not found")

    prompt_monitor = get_prompt_monitor(token)

    # Create request dict with all fields the graph expects
    request_dict = {
        "prompt_id": request.prompt_id,
        "job_id": job_id,
        "section_id": request.section_id,
        "section_name": request.section_name,
        "prompt": request.prompt,
        "edit_request": request.prompt,  # Alias for graph compatibility
        "target_section": request.section_name,  # Alias for graph compatibility
        "user_section_prompt": request.prompt,  # Store original user prompt
        "previous_prompt_id": request.previous_prompt_id,
    }

    await prompt_monitor.create_prompt_edit(
        prompt_id=request.prompt_id,
        job_id=job_id,
        section_id=request.section_id,
        section_title=request.section_name,
        prompt=request.prompt,
        status=PromptStatusEnum.SECTION_EDIT_QUEUED.value,
        progress=Decimal("0.1"),
        previous_prompt_id=request.previous_prompt_id,
        request=request_dict,
        started_at=datetime.now(),
    )

    await get_publisher().publish_section_edit_prompt(
        job_id=job_id,
        request=request_dict,
        token=token,
        correlation_id=get_correlation_id_logging_context()
    )

    return {"status": "accepted", "message": "section edit queued for processing"}


@router.get("/reports/{job_id}/section-edit/{prompt_id}/poll")
async def get_section_edit(
        job_id: str,
        prompt_id: str,
        token: str = Depends(get_token),
        dep=Depends(log_context_dependency)
) -> Dict[str, Any]:
    logger.info("Polling section edit for job_id=%s prompt_id=%s", job_id, prompt_id)

    status_tracker = get_monitor(token)
    if not await status_tracker.job_exists(job_id):
        logger.warning("Job %s not found during section edit polling", job_id)
        raise HTTPException(status_code=404, detail="Job not found")

    prompt_monitor = get_prompt_monitor(token)
    prompt_edit = await prompt_monitor.get_prompt_edit(prompt_id, job_id)
    if not prompt_edit:
        logger.warning(
            "Prompt edit %s not found or mismatched for job %s", prompt_id, job_id
        )
        raise HTTPException(status_code=404, detail="Prompt edit not found")

    if isinstance(prompt_edit.get("progress"), Decimal):
        prompt_edit["progress"] = float(prompt_edit["progress"])

    return {
        "status": prompt_edit.get("status"),
        "progress": prompt_edit.get("progress"),
        "response": prompt_edit.get("response", {}),
    }


@router.post("/reports/section-edit/approval")
async def approve_section_edit(
    approval: SectionEditApprovalRequest,
    token: str = Depends(get_token),
) -> Dict[str, Any]:
    job_id = approval.job_id
    prompt_id = approval.prompt_id

    logger.info(
        "Section edit approval for job_id=%s prompt_id=%s action=%s",
        job_id,
        prompt_id,
        approval.action,
    )

    status_tracker = get_monitor(token)
    if not await status_tracker.job_exists(job_id):
        logger.warning("Job %s not found during section edit approval", job_id)
        raise HTTPException(status_code=404, detail="Job not found")

    prompt_monitor = get_prompt_monitor(token)
    prompt_edit = await prompt_monitor.get_prompt_edit(prompt_id, job_id)
    if not prompt_edit:
        logger.warning("Prompt edit %s not found for job %s", prompt_id, job_id)
        raise HTTPException(status_code=404, detail="Prompt edit not found")

    action = approval.action.lower()

    # Map action to PromptStatusEnum
    if action == "approve":
        status_enum = PromptStatusEnum.SECTION_EDIT_APPROVED
    elif action == "decline":
        status_enum = PromptStatusEnum.SECTION_EDIT_DECLINED
    elif action == "retry":
        status_enum = PromptStatusEnum.SECTION_EDIT_RETRY
    else:
        raise HTTPException(status_code=400, detail="Unsupported decision action")

    progress_lookup = {
        "approve": Decimal("1.0"),
        "decline": Decimal("1.0"),
        "retry": Decimal("0.1"),
    }
    updates: Dict[str, Any] = {
        "status": status_enum.value,
        "progress": progress_lookup[action],
        "response": {
            "action": action,
            "edited_section": prompt_edit.get("response", {}).get("edited_section", {})
        },
    }

    approval_time = datetime.now()
    if action in {"approve", "decline"}:
        updates["completed_at"] = approval_time
    else:
        updates["started_at"] = approval_time
        updates["completed_at"] = None

    updated = await prompt_monitor.update_prompt_edit(prompt_id, updates)
    if not updated:
        raise HTTPException(status_code=500, detail="Failed to update prompt edit")

    # Publish to queue for all actions (including retry)
    await get_publisher().publish_section_edit_approval(
        job_id=job_id,
        prompt_id=prompt_id,
        status=status_enum.value,
        token=token,
        correlation_id=get_correlation_id_logging_context()
    )

    refreshed_prompt = await prompt_monitor.get_prompt_edit(prompt_id, job_id)
    if refreshed_prompt and isinstance(refreshed_prompt.get("progress"), Decimal):
        refreshed_prompt["progress"] = float(refreshed_prompt["progress"])

    result = {
        "prompt_id": refreshed_prompt.get("prompt_id"),
        "job_id": refreshed_prompt.get("job_id"),
        "status": refreshed_prompt.get("status"),
        "progress": refreshed_prompt.get("progress"),
        "response": refreshed_prompt.get("response", {}),
    }
    return result or {}


@router.get("/feedbacks/{job_id}")
async def list_feedbacks(job_id: str, token: str = Depends(get_token), dep=Depends(log_context_dependency)) -> JSONResponse:
    """
    List all feedbacks for the authenticated user.
    """
    try:
        profile_data = await fetch_user_profile_data(token)
        keyonlineuser = profile_data["KeyOnlineUser"]
        logger.error(keyonlineuser)

        feedbacks = await feedback_queries.list_feedback_records(keyonlineuser, job_id)
        return JSONResponse(status_code=200, content={"feedbacks": feedbacks})

    except Exception as e:
        logger.error(f"Failed to list feedbacks: {str(e)}")
        return JSONResponse(status_code=500, content={"error": f"Failed to list feedbacks: {str(e)}"})

@router.post("/post-feedback")
async def update_feedback(
        feedback: UpdateFeedbackRequest,
        token: str = Depends(get_token),
        dep=Depends(log_context_dependency)
) -> JSONResponse:
    try:

        profile_data = await fetch_user_profile_data(token)
        keyonlineuser = profile_data["KeyOnlineUser"]

        feedback_dict = feedback.model_dump()
        logger.info("update feedback request: %s", feedback_dict)

        file_data = await feedback_queries.save_feedback_record(feedback_dict, keyonlineuser)
        if not file_data:
            return JSONResponse(status_code=404, content={"error": "Document not found or access denied."})

        return JSONResponse(status_code=200, content={"message": "Feedback updated successfully."})
    
    except Exception as e:
        logger.error(f"Failed to update feedback: {e}", exc_info=True)
        return JSONResponse(status_code=500, content={"error": "Internal server error"})


app.include_router(router, prefix=cfg["SYNTHIA_SERVICE_API_PREFIX"])
if os.getenv("DEBUG", "False").lower() == "true":
    app.include_router(router)
