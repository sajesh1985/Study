import BubblePrompt from './BubblePrompt/BubblePrompt';
import { SuggestionBarContainer } from './Suggestion.styles';

interface SuggestionBarProps {
  suggestions: string[];
  onSelect: (suggestion: string) => void;
}

const SuggestionBar: React.FC<SuggestionBarProps> = ({ suggestions, onSelect }) => {
  return (
      <SuggestionBarContainer>
          {suggestions.map((suggestion, index) => (
              <BubblePrompt
                  key={index}
                  text={suggestion}
                  onClick={() => onSelect(suggestion)}
              />
          ))}
      </SuggestionBarContainer>
  );
};


export default SuggestionBar;
