import datetime
import re


_pass_through_types = (str,) # types that are currently not formatted at all (None is handled separately)
_max_trailing_zeroes = 5 # maximum amount of trailing zeroes that can be formatted, increase this number frugally
                         # as it adds up work when encountering a new template

_cached_formatting_directives = {}


class Template:
    def __init__(self, python_format: str, has_percent: bool, has_float_conversion: bool):
        self.python_format = python_format
        self.has_percent = has_percent
        self.has_float_conversion = has_float_conversion


class Directive:
    def __init__(self, default_template: Template, negative_number_template: Template | None, zero_template: Template | None):
        self.default_template = default_template
        self.negative_number_template = negative_number_template
        self.zero_template = zero_template


def reformat(value, excel_format: str) -> str:
    """
    Reintroduces the original display formatting of the Excel cell.
    :param value: cell value
    :param excel_format: cell format
    :return: reformatted value
    """
    if value is None or isinstance(value, _pass_through_types):
        return value

    directive = _cached_formatting_directives.get(excel_format)
    if directive is None:
        directive = _cached_formatting_directives[excel_format] = _create_formatting_directive(excel_format)

    selected_template = _select_template(directive, value)

    # excel % formatting also does the x100 arithmetic
    if selected_template.has_percent:
        value = value * 100

    # excel can format integers with decimals, so we emulate this by converting integers to floats
    if selected_template.has_float_conversion and isinstance(value, int):
        value = float(value)

    try:
        python_format = selected_template.python_format
        formatted = python_format.format(value)
        return formatted.replace('--', '-') # undocumented excel behavior: replacement of double minus with single minus
                                            # implemented it here manually
    except ValueError:
        return str(value)


def _create_formatting_directive(excel_format: str):
    default_excel_format, negative_number_excel_format, zero_excel_format = _extract_subformats(excel_format)

    return Directive(
        _create_template(default_excel_format),
        _create_template_or_none(negative_number_excel_format),
        _create_template_or_none(zero_excel_format)
    )


def _create_template_or_none(excel_format: str | None) -> Template:
    return None if excel_format is None else _create_template(excel_format)


def _create_template(excel_format: str) -> Template:
    # disables a lot of niche features, such as conditional formatting, colors and internationalization
    format_options = _disable_conditionals(excel_format)

    # hack for the common date with multiple escapes that is not supported below
    # in the future the process will be changed to tokenizer and lexer part to better handle such cases
    if 'd\\-mmm\\-yy' in format_options:
        return Template('{0:%d}-{0:%b}-{0:%y}', has_percent=False, has_float_conversion=False)

    # this is basically a pass-through unless a cell is too small which truncates the decimal places or num of decimal places is >7
    if 'General' in format_options:
        return Template('{:1.10g}', has_percent=False, has_float_conversion=False)

    # _ skips next single character
    single_skips = re.findall('_.', format_options)
    for single_skip in single_skips:
        format_options = format_options.replace(single_skip, '')

    # escaped characters (this may need some work as the following regex is not the best at the moment)
    # \x - single character escape
    # "abc" - multi character escape
    maybe_format_heuristic = '[#,0.%:\\-ymdhs ]'
    format_options, prepend_escapes = _extract_escapes(format_options, f'^(.*?){maybe_format_heuristic}+')
    format_options, append_escapes = _extract_escapes(format_options, f'{maybe_format_heuristic}+(.*?)$')

    # Replace '#,##' with ',' to handle thousands separator formatting
    format_options = format_options.replace('#,##', ',')

    # 0.0000 (and similar) is number of decimals
    format_options = _convert_trailing_zeroes_format(format_options)

    # adding signs must be done outside the python format engine
    has_percent = '%' in format_options
    format_options = format_options.replace('%', '')

    # date formatting
    format_options = _prepare_date_format(format_options)

    python_format = ''.join(prepend_escapes) + '{:' + format_options + '}' + ''.join(append_escapes)

    if has_percent:
        python_format += '%'

    return Template(python_format, has_percent, has_float_conversion='f' in python_format)


def _extract_subformats(excel_format: str):
    formats = excel_format.split(';')
    default_format = formats[0]
    negative_number_format = formats[1] if len(formats) > 1 else None
    zero_format = formats[2] if len(formats) > 2 else None
    return default_format, negative_number_format, zero_format


def _select_template(directive: Directive, value: int | float | datetime.datetime):
    if isinstance(value, datetime.datetime):
        return directive.default_template

    if directive.negative_number_template and value < 0:
        return directive.negative_number_template

    if directive.zero_template and value == 0:
        return directive.zero_template

    return directive.default_template


def _disable_conditionals(excel_format: str):
    conditionals = re.findall('\\[.*\\]', excel_format)

    for conditional in conditionals:
        excel_format = excel_format.replace(conditional, '')

    return excel_format


def _convert_trailing_zeroes_format(excel_format: str):
    for trailing_zeroes in range(_max_trailing_zeroes, 0, -1):
        excel_format = excel_format.replace(f'0.{'0' * trailing_zeroes}', f'.{trailing_zeroes}f')

    return excel_format.replace('0', '.0f')


def _extract_escapes(excel_format: str, expression: str):
    escapes = re.findall(expression, excel_format)

    for escape in escapes:
        excel_format = excel_format.replace(escape, '')

    return excel_format, [escape.replace('\\', '').replace('"', '') for escape in escapes]


def _prepare_date_format(format_options):
    format_options = format_options.replace('yyyy', '%Y')
    format_options = format_options.replace('yy', '%y')
    format_options = format_options.replace('mmm', '%b')
    format_options = format_options.replace('mm', '%m')
    format_options = format_options.replace('dd', '%d')
    format_options = format_options.replace('hh', '%H')
    format_options = format_options.replace('h', '%I')
    format_options = format_options.replace('ss..0f', '%S.%f')  # note that we replace 0 with .0f already!
    format_options = format_options.replace('ss', '%S')

    # additional heuristic: m is used both for minutes and for months, so we need to attempt to replace some common time like patterns
    # potential future improvements welcome, though I would not be surprised if exact same code is in Excel
    format_options = format_options.replace('%m:%S', '%M:%S')
    format_options = format_options.replace('%h:%m', '%h:%M')
    format_options = format_options.replace('%m %S', '%M %S')
    format_options = format_options.replace('%h %m', '%h %M')

    return format_options