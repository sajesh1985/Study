// Copyright Notice!
// This document is protected under the trade secret and copyright
// laws as the property of Fidelity National Information Services, Inc.
// Copying, reproduction or distribution should be limited and only to
// employees with a “need to know” to do their job.
// Any disclosure of this document to third parties is strictly prohibited.
// © 2017 Fidelity National Information Services.
// All rights reserved worldwide.

package com.fis.digitalpayments.sdk.core;

/**
 * @author e1035413 on 2/10/2017.
 */

public enum BridgeMessageCode {
    PERMISSION_DENIED,
    PERMISSION_PERMANENTLY_DENIED,
    BRIDGE_EXECUTION_FAILED,
    BRIDGE_REQUEST_PROCESSING_FAILED,
    BRIDGE_RESPONSE_PROCESSING_FAILED,
    EVENT_RAISED,
    NAVIGATE_BACK
}
