from typing import Optional

import pandas as pd

from chatrd.core.thread_utils import submit_to_shared_thread_pool
from chatrd.engine.components.query_analyzer.translator.utils import (
    Get_translation_result,
)
from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.data_service.schema import (
    Analyzer,
    ProcessorInput,
    Retriever,
    Synthesizer,
)
from chatrd.engine.data_service.synthesizer.base import BaseSynthesizer
from chatrd.engine.data_service.synthesizer.utils import (
    full_response,
    get_api_info,
    join_list_of_names,
    sector_information_data_formatter,
    source_description,
    text_response,
)

config_machinery = get_config_machinery()


def leading_line(entities: dict) -> str:
    """
    Generate a leading line for S&P Global Analytical Rating Contacts based on company names.

    Args:
        entities (dict): A dictionary containing company information.

    Returns:
        str: A formatted string with company names and a description of rating contacts.
    """
    companies = entities.get("companies", [])

    if not companies:
        return "Could not find company name"

    company_names = [company["name"] for company in companies]

    if len(company_names) == 1:
        return f"{company_names[0]} has the following S&P Global Ratings Information:"
    elif len(company_names) == 2:
        return f"{company_names[0]} and {company_names[1]} have the following S&P Global Ratings Information:"
    else:
        return f"{', '.join(company_names[:-1])}, and {company_names[-1]} have the following S&P Global Ratings Information:"


class SectorInfoSynthesizer(BaseSynthesizer):
    def synthesize(
        self,
        processor: ProcessorInput = None,
        analyzer: Optional[Analyzer] = None,
        retriever: Retriever = None,
    ) -> Synthesizer:
        # Read Arguments
        df = sector_information_data_formatter(retriever.api_data)
        entities = processor.entities
        count = retriever.total_count

        template = leading_line(entities)
        template = Get_translation_result(template, processor.original_language)
        template = template.result()

        if df.shape[0] > 0:
            response = full_response(template=template, data=df, data_type="table", count=count)
            source_url = source_description(entities=entities)
        else:
            names = [company["name"] for company in entities.get("companies", []) if "name" in company]
            names = join_list_of_names(names)
            template = f"Sorry, CreditCompanion™ couldn't find S&P Global Ratings Information for {names}. Please try another question."
            template = Get_translation_result(template, processor.original_language)
            template = template.result()

            response = [text_response(template, error=True)]
            source_url = []

        api_info = get_api_info(api_method=retriever.api_method, api_type=retriever.api_type, url=retriever.url)
        return Synthesizer(data_service_response=response, source_description=source_url, api_info=api_info)
