import logging
import os

import httpx
import yaml

from src.synthia.config.api_config import get_config
from src.synthia.utils.source import Source

logger = logging.getLogger(__name__)

async def get_company_name(institution_id: str, headers: dict) -> str:
    """
    Get company name from Capital IQ using institution ID.
    Args:
        institution_id: str: Capital IQ institution ID
        headers: dict: Headers for the HTTP request

    Returns: str: Company name
    Raises: HTTPError: If the request fails
    """
    cfg = get_config()
    base_url = f"{cfg['capitaliq_base_url']}"
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            response = await client.get(
                f"{base_url}Ratings/GetEntityHeaderInfo/{institution_id}",
                headers=headers
            )
            if response.status_code != 200:
                logger.warning(f"Failed to fetch company name, status code: {response.status_code}")
                return None
            data = response.json()
            return data.get("InstnName")
    except Exception as e:
        logger.error(f"Error fetching company name: {e}")
        return None


def get_article_document_mapping(article_type: str, article_sub_type: str | None) -> str | None:
    """
    Returns a mapping of (articleType, article_sub_type) tuples to documentType.
    """
    _mapping =  {
        ("CLASSIC", "NARRATIVE"): "Narrative",
        ("COMMENTS", None): "Commentary",
        ("COMMENTS", "CRITERIA"): "Criteria",
        ("COMMENTS", "CRITERIA_GUIDANCE"): "Criteria",
        ("COMMENTS", "GREEN EVALUATION"): "Commentary",
        ("COMMENTS", "SRHL"): "Commentary",
        ("FULL", None): "Full Analysis",
        ("FULL", "NEW ISSUE"): "New Issue",
        ("FULL", "PRESALE"): "Presale Report",
        ("FULL", "RATSTATS"): "Full Analysis",
        ("FULL", "SERVICER EVALUATION"): "Full Analysis",
        ("FULL", "SURVEILLANCE"): "Full Analysis",
        ("FULL", "TRANSACTION UPDATE"): "Full Analysis",
        ("NEWS", "BULLETIN"): "Bulletin",
        ("NEWS", "COMMENTS"): "News",
        ("NEWS", "RATING_ACTION"): "Rating Action News",
        ("RESUPD", "RATING_ACTION"): "Research Update",
        ("SUMMARY", None): "Summary Analysis"
    }
    if article_type:
        article_type = article_type.strip().upper()
    else:
        article_type = None
    if article_sub_type:
        article_sub_type = article_sub_type.strip().upper()
    else:
        article_sub_type = None
    return _mapping.get((article_type, article_sub_type), "")



def get_citation_mapping() -> dict[str, str]:
    """
    Returns a mapping of tool names to their citation strings.
    """
    mapping_file_name = "mcp_tools_to_citation_mapping.yaml"
    current_dir = os.path.dirname(os.path.abspath(__file__))
    mapping_file_path = os.path.join(current_dir, mapping_file_name)
    with open(mapping_file_path, 'r') as file:
        mapping = yaml.safe_load(file)
    return mapping


def get_mcp_tool_citation(mcp_tool_name: str) -> str:
    """
    Returns the citation string for the MCP tool.
    """
    mapping = get_citation_mapping()
    return mapping.get(mcp_tool_name)


async def get_mcp_tool_source(
        mcp_tool_name: str,
        source_url: str,
        institution_id:str,
        headers: dict,
        default_title: str
) -> Source:
    """
    Get the source information for an MCP tool, including dynamic placeholders.
    Args:
        mcp_tool_name: str: Name of the MCP tool
        source_url: str: URL of the source
        institution_id: str: Capital IQ institution ID
        headers: dict: Headers for the HTTP request
        default_title: str: Default title if no citation is found
    Returns:
        Source: Source object with title and URL
    """
    logger.debug(
        "Entering get_mcp_tool_source mcp_tool_name=%s institution_id=%s source_url=%s",
        mcp_tool_name,
        institution_id,
        source_url,
    )
    citation = get_mcp_tool_citation(mcp_tool_name)
    if not citation:
        logger.info("No citation found for MCP tool: %s using default", mcp_tool_name)
        return Source(title=default_title, url=source_url)
    if "{company_name}" in citation:
        if not institution_id:
            logger.info(
                f"Institution ID not provided for tool %s and citation has %s, using default title.",
                mcp_tool_name,
                "{company_name}"
            )
            return Source(title=default_title, url=source_url)

        company_name = await get_company_name(institution_id, headers=headers)

        if not company_name:
            logger.info(f"Company name not found for institution ID: {institution_id}, using default title.")
            return Source(title=default_title, url=source_url)

        logger.info(f"Fetched company name: {company_name} for institution ID: {institution_id}")
        citation = citation.replace("{company_name}", company_name)
        logger.info(f"Final citation: {citation}")
        return Source(title=citation, url=source_url)
    elif citation:
        logger.info(f"Final citation: {citation}")
        return Source(title=citation, url=source_url)
    else:
        logger.info("No citation found for MCP tool: %s using default", mcp_tool_name)
        return Source(title=default_title, url=source_url)