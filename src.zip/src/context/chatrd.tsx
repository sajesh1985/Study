import React, {  useState } from 'react';
import { createInteraction, getChatDetailsFromSession, getStreamingAPIUrl } from '../services/api';
import { Feedback, GridModel, Interaction } from '../types/interaction';
import { ChatHistoryResponse, ChatSessionHistoryRequestPayload, ContentType, GridExport, InteractionRequestPayload, KnowledgeDiscoveryDocuments, KnowledgeDiscoveryResponseNode, PayloadDetails, TableResponseNode, TextResponseNode } from '../types/api';
import { Accordion, AccordionItem, H5 } from '@spglobal/react-components';
import { Size } from '@spglobal/koi-helpers';
import { useUserTraits } from '@spglobal/userprofileservice';
import { ResponseView } from '../components/_common/ResponseView/ResponseView';
import { DivformattedContent } from '../components/_common/Content';
import { getLocalizedDate } from '../utils/dateLocalization';
import { DocumentList } from '../components/_common/KnowledgeDiscoveryView/KnowledgeDiscoveryView.styles';
import { RESEARCH_MAPPING } from '../constants/constants';
import { fetchEventSource } from '@microsoft/fetch-event-source';
import { ExtendedPatch, applyPatches } from '../components/ChatScreen/applyPatches';
import moment from 'moment';


interface IChatRDContextValue {
  session?: string;
  interactions: Interaction[];
  askQuestion: (question: string,tagEntities?:any) => void;
  abortStreaming:()=>void;
  chatHistory: string;
  tableRef: GridModel[];
  copyToClipBoard: (interactionId: any) => GridExport;
  setGridContext: (gridApi: any, interactionId: any) => void;
  newInteraction: (request: string,tagEntities?:any) => void;
  newInteractionChatHistory: (request: ChatHistoryResponse) => void;
  updateInteraction: (id: string, updates: Partial<Interaction>) => void;
  isLoading?: boolean;
  setPayloadDetails : (payload: PayloadDetails[]) => void;
  scrollCompleted?: string;
  payLoad?: PayloadDetails[];
}

const context = React.createContext<IChatRDContextValue>({} as IChatRDContextValue);

const noResponse = (
  <DivformattedContent> Something went wrong. Please try another question.</DivformattedContent>
);

const methodology = (
  <>
    <DivformattedContent className="spg-mb-sm">
    CreditCompanion<sup>TM</sup> is an AI-Powered chatbot that utilizes an LLM (Large Language Model, which is a type of
      conversational Artificial Intelligence system based on advanced machine learning algorithms.
      CreditCompanion<sup>TM</sup> is designed to understand user queries and generate human-like text responses.
      CreditCompanion<sup>TM</sup> is trained specifically on S&P Ratings & Research, including a vast array of documents
      types like, Full Analysis, Research Updates, Commentaries and Criteria. This empowers CreditCompanion<sup>TM</sup> to
      have deep context library and retrieve data from a rich source of information.
    </DivformattedContent>
    <DivformattedContent>
      As is the case with all models, CreditCompanion<sup>TM</sup> is not infallible. The accuracy of responses depends on
      several factors, including the ability to understand the context of a user prompt, the complexity
      of the language tasks it is trained on, the size and architecture of the model and the tuning on
      the model. Users can provide feedback to enhance the performance of CreditCompanion<sup>TM</sup> by submitting feedback
      directly for any responses that may contain any inaccuracies or errors. The feedback will be utilized
      to retrain CreditCompanion<sup>TM</sup> and improve accuracy over time.
    </DivformattedContent>
  </>
);

const capabilities = (
  <>
    <DivformattedContent className="spg-mb-sm">
    CreditCompanion<sup>TM</sup> aims at providing RatingsDirect® users with comprehensive responses to a wide variety of questions pertaining to
      S&P Global Ratings and Research.
    </DivformattedContent>
    <DivformattedContent>
      Trained on a specifically curated corpus of information sourced from S&P Global's Ratings and Research documents, CreditCompanion<sup>TM</sup> empowers
      users to ask questions of a variety of topics including:
      <ul>
        <li>
          Issuers (Global Issuers, US Public Finance, and Structured Finance)
        </li>
        <li>
          Securities
        </li>
        <li>
          Macroeconomics
        </li>
        <li>
          Industries
        </li>
        <li>
          Ratings Methodology & Criteria
        </li>
      </ul>
    </DivformattedContent>
    <DivformattedContent>
      It is important to note that CreditCompanion<sup>TM</sup>'s capabilities are confined to the corpus of information that it has been trained on, thus limiting
      its ability to provide responses beyond this scope. Notably, topics such as broader public and private company details
      (e.g., stock information, corporate structure, public filings) or updates on current events sourced from Dow Jones and Market Intelligence
      News and Market Intelligence Research are outside CreditCompanion<sup>TM</sup>'s scope. Additionally, CreditCompanion<sup>TM</sup> is not designed to deliver general responses that are
      characteristic of a typical LLM (Large Language Model) Chatbot and will restrict its output accordingly.
    </DivformattedContent>
  </>
);

type IntermediateEventType =
  | 'interactionCreated'
  | 'analyzingQuestion'
  | 'planGenerated'
  | 'pullingData'
  | 'dataPullSuccessful'
  | 'generatingResponse'
  | 'generationStarted';
type EventType = IntermediateEventType | 'interactionFinished';

type SpecPatch = ExtendedPatch & {
  path: string;
};

// Immer uses the JSON patch standard except that `path` is an array so we need to transform the patches to what immer understands.
// We also remove the initial `/` (or [""] value) to ensure immer traverses correctly.
function transformPatches(patches: SpecPatch[]): ExtendedPatch[] {
  return patches.map(
    (patch: SpecPatch): ExtendedPatch => ({
      ...patch,
      path: patch.path.split('/').slice(1),
    })
  );
}

// TODO: Handle snake_case to camelCase between patches better.
function patchMessage(
  message: Interaction,
  patches: ExtendedPatch[],
  feedbackEnabled?: boolean
): Interaction {
  // Remove the FE-specific messaging we insert at the top.
  let cleanResponseBody = [...message.responseBody];
  cleanResponseBody.shift();
  let nonStreamedBody = [];
  nonStreamedBody.push(message.responseBody[0]);
  let isComplexType = false;
  
  if (message.responseBody.length > 1) {
    isComplexType = true;
    for(var k=1;k<message.responseBody.length -1;k++)
    {
      nonStreamedBody.push(message.responseBody[k]);
      cleanResponseBody.shift();
    }
  }
  
  // Patches assume snake_case but the FE assumes camelCase so we temporarily put the values in snake_case.
  const messageToPatch = {
    session_id: message.sessionId,
    interaction_id: message.interactionId,
    response_body: cleanResponseBody,
    response_context: message.responseContext,
    type: message.type,
    responseTimestamp:message.responseTimestamp
  };

  // Apply the patches

  const patchedSnakeCase = applyPatches(messageToPatch, patches);


  // Now remove the snake_case attributes in favor of the camelCase ones
  const patchedCamelCase: Interaction = {
    sessionId: patchedSnakeCase.session_id,
    interactionId: patchedSnakeCase.interaction_id,
    responseBody: patchedSnakeCase.response_body,
    responseContext: patchedSnakeCase.response_context,
    feedbackEnabled,
    id: '',
    loading: true,
    responseTimestamp:patchedSnakeCase.responseTimestamp,
    type: patchedSnakeCase.type
  };

  return {
    ...patchedCamelCase,
    responseBody:
      // Add the FE-specific messaging if this is not the final response.
      isComplexType === true
        ?
        //[message.responseBody[0],message.responseBody[1],...patchedCamelCase.responseBody]: feedbackEnabled == false ? [message.responseBody[0],...patchedCamelCase.responseBody] : patchedCamelCase.responseBody
        [...nonStreamedBody, ...patchedCamelCase.responseBody] : feedbackEnabled == false ? [message.responseBody[0], ...patchedCamelCase.responseBody] : feedbackEnabled == true ? [message.responseBody[0], ...patchedCamelCase.responseBody] : patchedCamelCase.responseBody

  };
}

const whatscoming = (<>
  <DivformattedContent>
    We're constantly striving to enhance the capabilities and user experience of CreditCompanion<sup>TM</sup>. Here is a glimpse of what you can expect in the near future:
    <ul>
      <li>
        <b>Expanded Knowledge Base:</b> We're working diligently to enrich CreditCompanion<sup>TM</sup>'s knowledge base by incorporating additional datasets and sources of information.
      </li>
      <li>
        <b>Improved Natural Language Understanding:</b> Our team is dedicated to refining CreditCompanion<sup>TM</sup>'s natural language processing capabilities to better understand complex questions, nuances in language and context.
      </li>
      <li>
        <b>Enhanced Personalization:</b> We recognize the importance of personalization in delivering a tailored user experience. In the coming updates, we plan to deliver suggested follow up questions powered by AI,
        the ability to create lists of prompts based on topics and the ability to translate responses to your preferred language.
      </li>
    </ul>
  </DivformattedContent>
  <DivformattedContent>
    Stay tuned for these exciting updates as we continue to evolve and innovate to provide you with the best possible experience. Thank you for your continued support and feedback!
  </DivformattedContent>
</>);

const desclaimer = (
  <>
    <DivformattedContent className="spg-mb-sm">
    This Credit Chatbot is currently in an experimental
development phase.  It is designed to provide information and to answer
questions using an AI-powered conversational assistant that utilizes an LLM
(Large Language Model) with a corpus that includes S&P Global Ratings
credit ratings data and research to generate its responses. 
    </DivformattedContent>
    <DivformattedContent className="spg-mb-sm">
    Some or all of the content made available to you in
connection with the Credit Chatbot is generated by artificial intelligence
technology.  It may therefore contain errors, omissions, inaccuracies,
hallucinations, biases, inconsistencies or outdated information.  You
should independently verify all content that it generates before you use
it.  S&P Global Market Intelligence and its affiliates do not accept
any responsibility or liability for any decisions you make as a result of, or for
your reliance on or use of the Credit Chatbot content, whether in contract,
tort (including negligence and negligent misstatement), or otherwise. 
Such use is entirely at your own risk.  

    </DivformattedContent>
    
  </>
);
const faq = (
  <Accordion accordionSize={Size.MEDIUM} removeItemSpacing>
    <AccordionItem isDefaultOpen header="What is this?">
      <p className="spg-mb-sm">
      CreditCompanion<sup>TM</sup> aims to be an easy-to-use AI-driven chat interface that specializes in business and
        finance question-answering. This tool is not meant to provide financial advice.
      </p>
      <p className="spg-mb-sm">
        We are looking to test, get feedback, and understand real client use to improve upon our
        model.
      </p>
      <p className="spg-mb-sm">
        Interact with CreditCompanion<sup>TM</sup>. Ask questions in natural language. The model can answer questions
        about a single to multi-company information, including but not limited to company
        organization, professionals, financials, news, acquisitions, etc.
      </p>
    </AccordionItem>
    <AccordionItem header="What we need">
      <p className="spg-mb-sm">
        Ask CreditCompanion<sup>TM</sup> some business and finance specific questions. Thumbs up the “reasonable” answer
        or Thumbs down the “unreasonable” answer. Add additional information in the feedback box if
        you have any.
      </p>
      <p className="spg-mb-sm">
        Note: The model is still a work in progress, so do not be surprised if you find that it
        struggles with questions that you ask. Finding out the useful things that it cannot do is
        very valuable for us on its own. Currently CreditCompanion<sup>TM</sup> does not support conversational
        back-and-forth chat.
      </p>
    </AccordionItem>
    <AccordionItem header="Examples">
      <p className="spg-mb-sm">What was Apple&apos;s stock price on April 1st 2023?</p>
      <p className="spg-mb-sm">What are some recent developments at Apple?</p>
      <p className="spg-mb-sm">What is the total revenue of Apple YTD?</p>
      <p className="spg-mb-sm">Let all CEOs that attended Harvard</p>
      <p className="spg-mb-sm">Who are some of Apple&apos;s competitors?</p>
      <p className="spg-mb-sm">Who is on the board of Apple?</p>
      <p className="spg-mb-sm">Give me an example of 5 private companies operating in Germany.</p>
      <p className="spg-mb-sm">How many acquisitions has S&P Global made in the last five years?</p>
    </AccordionItem>
    <AccordionItem header="Model details ">
      <p className="spg-mb-sm">
        The model currently has access to the following data sets. Though the model has access, it
        may not know yet how to query for a specific table, but don&apos;t let the current list of
        data sets or functionality limit your questions. If there is a question, dataset or API
        service you think would be particularly valuable, let us know.
      </p>
      <p className="spg-mb-sm">
        BMI Index Data, Business Entity Cross Reference Service (BECRS), Business Relationships,
        Company Intelligence, Company Relationships, Competitors, Compustat Snapshot, Corporate
        Tracker, Document Reference, Foundation Company SME, Future Events, Global Events, Global
        Instruments Cross Reference Service (GICRS), Industry Sector Cross Reference Service
        (ISCRS), Key Developments, Key Documents, MI Integrated Market Data, Machine Readable Broker
        Research, Machine Readable Filings, Machine Readable Transcripts, Market Intelligence News,
        Products, Professionals, S&P Capital IQ Base Files, S&P Capital IQ Company Industry GICS,
        S&P Capital IQ Latest Financials, S&P Capital IQ Market Data, S&P Capital IQ Premium
        Financials, S&P Capital IQ Private Company Financials, SNL Branch Data, SNL Corporate Data,
        SNL Real Estate, SNL Reference, SNL Regulatory Data, SNL Sector Financials, Transactions,
        Transactions M&A, Transactions Offerings, Transactions Rounds of Funding
      </p>
    </AccordionItem>
  </Accordion>
);

export const ChatRDProvider: React.FC = ({ children }) => {
  const [session, setSession] = React.useState<string>("");
  const [payLoad, setPayload] = React.useState<PayloadDetails[]>([]);
  const [scrollCompleted, setScrollCompleted] = React.useState<string>("");
  const [ controller, setAbortController ] = useState(new AbortController());
  
  let payloadFinal : PayloadDetails[] = [];
  let [interactions, setInteractions] = React.useState<Interaction[]>([]);
  let [tableRef, setTable] = React.useState<GridModel[]>([]);
  let streamStart = 0;
  const handleCopyToClipboard = (interactionId: any): GridExport => {
    if (tableRef) {
      const rowData: any[] = [];
      let activeGrid = tableRef.find((int: any) => int.interactionId == interactionId);
      let gridExport: GridExport = { rowData: [] };
      activeGrid.gridData.forEachNode((node: any) => rowData.push(node.data));
      gridExport.rowData = rowData;
      return gridExport;
    }
    return null;
  };

  //const [messages, setMessages] = useState([]);


  const isLoading =
    interactions.filter((data: Interaction) => data.loading).length > 0 ? true : false;
  const [chatHistory, setchatHistory] = React.useState<string>();

  const updateInteraction = (id: string, updates: Partial<Interaction>) => {
    setInteractions((pre) =>
      pre.map((t) => {
        if (t.id == id || t.interactionId == id) {
          return { ...t, ...updates };
        } else {
          return t;
        }
      })
    );
  };

  const getLastInteractionId = () => {
    const respondedInteraction = interactions.filter(
      (data: Partial<Interaction>) => (!(data.sessionId == null || data.sessionId == undefined) && data.id.indexOf('-') > -1)
    );
    const lastInteraction = respondedInteraction[respondedInteraction.length - 1];
    return lastInteraction ? lastInteraction.id : undefined;
  };

  const getLastInteractionStreamId = () => {
    const respondedInteraction = interactions.filter(
      (data: Partial<Interaction>) => (!(data.sessionId == null || data.sessionId == undefined) && data.id.indexOf('-') > -1)
    );
    if (respondedInteraction && respondedInteraction.length > 0) {
      const lastInteraction = respondedInteraction[respondedInteraction.length - 1];
      return lastInteraction ? lastInteraction.id : undefined;
    }
    else {
      return interactions && interactions.length > 0 ? (interactions[interactions.length - 1].id !== '') ? interactions[interactions.length - 1].id : interactions[interactions.length - 1].interactionId : undefined;
    }
  };

  const userInformation = useUserTraits(['keyOnlineUser', 'timeZoneAbbreviation', 'culture', 'mSTimeZoneID']);

  const value: IChatRDContextValue = React.useMemo(() => {
    return {
      session,
      interactions,
      isLoading,
      chatHistory,
      tableRef,
      setPayloadDetails : (payload : PayloadDetails[]) => {
          return setPayload([...payload]);
      },
      copyToClipBoard: (interactionId: any) => {
        return handleCopyToClipboard(interactionId);
      },
      setGridContext: (gridApi: any, interactionId: string) => {
        let temp: GridModel = { interactionId: interactionId, gridData: gridApi };
        tableRef.push(temp);
        setTable(tableRef);
      },
      abortStreaming:()=>{
        controller.abort();
        setAbortController(new AbortController());
      },
      askQuestion: async (request: string,tagEntities:any) => {
        setchatHistory("New");

        const interaction: Interaction = {
          sessionId: session,
          type: "user",
          id: new Date().valueOf().toString(),
          date: getLocalizedDate(
            new Date(),
            true,
            userInformation.culture,
            userInformation.mSTimeZoneID
          ),
          req: request,
          loading: true,
        };

        try {
          if (request.toLowerCase() == 'creditcompanion<sup>tm</sup>  legal disclaimer' || request.toLowerCase() == 'full disclaimer') {
            setInteractions([...interactions, interaction]);
            updateInteraction(interaction.id, {
              ...interaction,
              sessionId: null,
              loading: false,
              responseBody: [{ type: ContentType.Text, content: desclaimer }],
              responseContext: [],
              feedbackEnabled: false,
            });

          } else if (request.toLowerCase() == 'how to use creditcompanion') {
            setInteractions([...interactions, interaction]);
            updateInteraction(interaction.id, {
              ...interaction,
              loading: false,
              sessionId: null,
              responseBody: [{ type: ContentType.Text, content: faq }],
              responseContext: [],
              feedbackEnabled: false,
            });
          } else if (request.toLowerCase() == 'capabilities & limitations') {
            setInteractions([...interactions, interaction]);
            updateInteraction(interaction.id, {
              ...interaction,
              sessionId: null,
              loading: false,
              responseBody: [{ type: ContentType.Text, content: capabilities }],
              responseContext: [],
              feedbackEnabled: false,
            });
          } else if (request.toLowerCase() == 'methodology') {
            setInteractions([...interactions, interaction]);
            updateInteraction(interaction.id, {
              ...interaction,
              sessionId: null,
              loading: false,
              responseBody: [{ type: ContentType.Text, content: methodology }],
              responseContext: [],
              feedbackEnabled: false,
            });
          } else if (request.toLowerCase() == "what's coming") {
            setInteractions([...interactions, interaction]);
            updateInteraction(interaction.id, {
              ...interaction,
              sessionId: null,
              loading: false,
              responseBody: [{ type: ContentType.Text, content: whatscoming }],
              responseContext: [],
              feedbackEnabled: false,
            });
          }
          else {
            setInteractions([...interactions, interaction]);

            const args: InteractionRequestPayload = {
              sessionId: session,
              userInput: [
                {
                  type: ContentType.Text,
                  value: request,
                  taggedEntities: tagEntities,
                },
              ],
              previousInteractionId: getLastInteractionStreamId(),
              supportedNodeTypes: [
                ContentType.Text,
                ContentType.Code,
                ContentType.Table,
                ContentType.KnowledgeDiscovery,
              ],
            };

            const APIUrl = getStreamingAPIUrl();
            const baseInit = {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'Accept': 'text/event-stream'
              },
              body: JSON.stringify(args),
              openWhenHidden: true,
            };
            streamStart = 0;
            let streamStartIndex=0;
            let isExecutionAborted = false;
            const { session_id: sessionId, interaction_id: interactionId } = JSON.parse("{}");
            setScrollCompleted("StreamStarted");
            
            fetchEventSource(APIUrl, {
              ...baseInit,
              signal:controller.signal,
              onmessage(ev: any) {
                isExecutionAborted = controller.signal.aborted;
                //if (!controller.signal.aborted) {
                  if (ev.data) {
                    setScrollCompleted("Streaming");
                    const eventType = ev.event as EventType;
                    let patch = {
                      op: '', value: '',
                      path: ''
                    };
                    const patchesArr: any = [];
                    let feedbackEnabled = false;
                    let streamData = JSON.parse(ev.data);
                    const { sessionId: sessionId, interactionId: interactionId, responseBody: responseBody, responseTimestamp: responseTimestamp, op: op } = streamData;
                    if (op == 'add' && session == '') {
                      setSession(sessionId);
                    }
  
                    switch (eventType) {
                      case 'generatingResponse': {
                        if (streamStart == 0) {
                          streamStart = 1;
                          if (op == 'add' && (responseBody[0].answer || responseBody[0].type === 'Table' || responseBody[0].type === 'csd_table')) {
                            setInteractions((prev: any) => {
                              const next = [...prev];
                              const lastMessage = next.pop();
                              lastMessage.session_id = sessionId;
                              lastMessage.sessionId = sessionId;
                              lastMessage.type = "user";
                              lastMessage.id = interactionId;
                              lastMessage.interaction_id = interactionId;
                              lastMessage.interactionId = interactionId;
                              if(!(responseBody[0].type === 'Table' || responseBody[0].type === 'csd_table'))
                              {
                                lastMessage.responseBody[0].content = responseBody[0].answer;
                                lastMessage.responseBody[0].documents = responseBody[0].documents;
                              }
                              else
                              {
                                lastMessage.responseBody = responseBody;
                              }
                              lastMessage.responseTimestamp = responseTimestamp;
                              return prev;
                            });
  
                          }
                          else {
                            const { responseBody: responseBody, op: op } = streamData;
                            if (op == 'add') {
                              patch.op = 'add';
                              patch.value = JSON.parse('{"type":"Text","content":""}');
                              patch.path = '/response_body/0';
                              patchesArr.push(patch);
                              const patches = transformPatches(patchesArr);
  
  
  
                              setInteractions((prev: any) => {
                                const next = [...prev];
                                const lastMessage = next.pop();
                                lastMessage.session_id = sessionId;
                                lastMessage.type = "user";
                                lastMessage.id = interactionId;
                                lastMessage.sessionId = sessionId;
                                lastMessage.interaction_id = interactionId;
                                lastMessage.interactionId = interactionId;
                                lastMessage.responseTimestamp = responseTimestamp;
                                if (lastMessage.responseBody) {
                                  lastMessage.responseBody.push({ type: ContentType.Text, content: responseBody[0].answer, documents: responseBody[0].documents });
                                  const patchedMessage = patchMessage(
                                    lastMessage,
                                    patches,
                                    feedbackEnabled
                                  );
  
                                  next.push(patchedMessage);
                                }
                                return next;
                              });
                              return;
                            }
                          }
                        }
                        else {
                          if (streamStart == 1 || streamStart ==2) {
                            const { responseBody: responseBody, op: op, responseTimestamp: responseTimestamp } = streamData;
                            if (op == 'add') {
                              if (responseBody[0].type === 'Table' || responseBody[0].type === 'csd_table') {
                                setInteractions((prev: any) => {
                                  const next = [...prev];
                                  const lastMessage = next.pop();
                                  lastMessage.sessionId = sessionId;
                                  lastMessage.id = interactionId;
                                  lastMessage.type = "user";
                                  lastMessage.interactionId = interactionId;
                                  lastMessage.responseBody = lastMessage.responseBody.concat(responseBody);
                                  lastMessage.responseTimestamp = responseTimestamp;
                                  return prev;
                                });
                                return;
                              }
                              else if(responseBody[0].answer)
                              {
                                setInteractions((prev: any) => {
                                  const next = [...prev];
                                  const lastMessage = next.pop();
                                  lastMessage.session_id = sessionId;
                                  lastMessage.sessionId = sessionId;
                                  lastMessage.type = "user";
                                  lastMessage.id = interactionId;
                                  lastMessage.interaction_id = interactionId;
                                  lastMessage.interactionId = interactionId;
                                  lastMessage.responseBody.push({ type: ContentType.Text, content: responseBody[0].answer });
                                  //lastMessage.responseBody[0].content = lastMessage.responseBody[0].content.concat("\n\n\n\n" + responseBody[0].answer);
                                  //lastMessage.responseBody[0].documents = lastMessage.responseBody[0].documents.concat(responseBody[0].documents);
                                  lastMessage.responseTimestamp = responseTimestamp;
                                  return prev;
                                });
                              }
                              else {
                                patch.op = 'add';
                                patch.value = JSON.parse('{"type":"Text","content":""}');
                                patch.path = '/response_body/0';
                                patchesArr.push(patch);
                                const patches = transformPatches(patchesArr);
  
  
  
                                setInteractions((prev: any) => {
                                  const next = [...prev];
                                  const lastMessage = next.pop();
                                  lastMessage.session_id = sessionId;
                                  lastMessage.sessionId = sessionId;
                                  lastMessage.id = interactionId;
                                  lastMessage.type = "user";
                                  lastMessage.interaction_id = interactionId;
                                  lastMessage.interactionId = interactionId;
                                  lastMessage.responseTimestamp = responseTimestamp;
                                  //if (!lastMessage || lastMessage.req) return prev;
                                  if (lastMessage.responseBody) {
                                    lastMessage.responseBody.push({ type: ContentType.Text, content: responseBody[0].answer, documents: responseBody[0].documents });
  
                                    const patchedMessage = patchMessage(
                                      lastMessage,
                                      patches,
                                      feedbackEnabled
                                    );
  
                                    next.push(patchedMessage);
                                  }
                                  return next;
                                });
                                return;
                              }
                            }
                            else {
                              streamStart = 2;
                              
                              patch.op = JSON.parse(ev.data).op;
                              patch.value = JSON.parse(ev.data).responseBody[0].answer;
                              patch.path = '/response_body/0/content';
                              
                              patchesArr.push(patch);
                              const patches = transformPatches(patchesArr);
                              
                              //if()  
                                //{
                                  setTimeout(() => {setInteractions((prev: any) => {
                                    const next = [...prev];
                                    streamStartIndex++;
                                    const lastMessage = next.pop();
                                    if(!isExecutionAborted)
                                    {
                                        lastMessage.session_id = sessionId;
                                    lastMessage.id = interactionId;
                                    lastMessage.type = "user";
                                    lastMessage.interaction_id = interactionId;
                                    lastMessage.responseTimestamp = responseTimestamp;
                                    if (patch.op == 'end') {
                                      feedbackEnabled = true;
                                      lastMessage.loading = false;
                                      setScrollCompleted("Completed");
                                    }
                                    else
                                    {
                                      setScrollCompleted("Streaming"+ streamStartIndex);
                                    }
      
                                    const patchedMessage = patchMessage(
                                      lastMessage,
                                      patches,
                                      feedbackEnabled
                                    );
      
                                      next.push(patchedMessage);
                                    return next;
                                      }
                                      else
                                      {
                                        feedbackEnabled = true;
                                        lastMessage.loading = false;
                                        setScrollCompleted("Completed");
                                        const patchedMessage = patchMessage(
                                          lastMessage,
                                          patches,
                                          feedbackEnabled);
      
                                        next.push(patchedMessage);
                                        return next;
                                      }
                                    
                                  })});
                                //}
                                
                              
                              return;
                            }
                            return;
                          }
  
                        }
                      }
                    }
                  }
                //}
              },
              onerror(err: any) {
                setScrollCompleted("Completed");
                throw err;
              },
              async onopen(response: any) {
                if (!response.ok) throw response;
                else{
                  const initialResponse: Interaction = {
                    sessionId,
                    type: "user",
                    interactionId,
                    responseBody: [{ type: ContentType.Text, content: ' ' }],
                    responseContext: [],
                    responseTimestamp:'',
                    id: '',
                    loading: true
      
                  };
      
                  setInteractions((prev: any) => {
                    const next = [...prev];
                    return [...next, initialResponse];
                  });
                }
              },
              onclose() {
                  if(streamStart == 0)
                  {
                    setInteractions((prev: any) => {
                      const next = [...prev];
                      const lastMessage = next.pop();
                      lastMessage.id="sadsadsadsadsad";
                      lastMessage.interaction_id = "sadsadsadsadsad";
                      lastMessage.interactionId = "sadsadsadsadsad";
                      lastMessage.feedbackEnabled = true;
                      lastMessage.loading = false;
                      lastMessage.res = noResponse;
                      lastMessage.responseBody = [{ type: ContentType.Text, content: 'Something went wrong. Please try another question.' }]
                      lastMessage.type = "user";
                      return [...prev];

                    });
                    //setScrollCompleted("Completed");
                    //controller.abort();
                    //setAbortController(new AbortController());
                    return;
                  }
                  else{
                    if(streamStart == 2)
                    {
                      
                    }
                    else
                    {
                      setInteractions((prev: any) => {
                        const next = [...prev];
                        const lastMessage = next.pop();
                        lastMessage.feedbackEnabled = true;
                        lastMessage.loading = false;
                        lastMessage.type = "user";
                        return [...prev];
  
                      });
                      setScrollCompleted("Completed");
                    }
                    
                    //controller.abort();
                    return;
                  }
                 
              },
            }).catch((err:any) => {
              console.log(err);
              setScrollCompleted("Completed");
              throw err;
            });
          }
        } catch (e) {
          setScrollCompleted("Completed");
          updateInteraction(interaction.id, {
            ...interaction,
            sessionId: session,
            loading: false,
            responseBody: [{ type: ContentType.Text, content: noResponse }],
            responseContext: [],
            feedbackEnabled: false,
          });
        }
      },
      newInteraction: async (request: string,tagEntities:any) => {
        setchatHistory("New");
        const interaction: Interaction = {
          sessionId: session,
          type: "user",
          id: new Date().valueOf().toString(),
          date: getLocalizedDate(
            new Date(),
            true,
            userInformation.culture,
            userInformation.mSTimeZoneID
          ),
          req: request,
          loading: true,
        };
        setInteractions([...interactions, interaction]);
        try {
          if (request.toLowerCase() == 'creditcompanion<sup>tm</sup> legal disclaimer' || request.toLowerCase() == 'full legal disclaimer') {
            updateInteraction(interaction.id, {
              ...interaction,
              sessionId: null,
              loading: false,
              responseBody: [{ type: ContentType.Text, content: desclaimer }],
              res: desclaimer,
              responseContext: [],
              feedbackEnabled: false,
            });
          } else if (request.toLowerCase() == 'how to use about creditcompanion') {
            updateInteraction(interaction.id, {
              ...interaction,
              loading: false,
              sessionId: null,
              responseBody: [{ type: ContentType.Text, content: faq }],
              res: faq,
              responseContext: [],
              feedbackEnabled: false,
            });
          } else if (request.toLowerCase() == 'capabilities & limitations') {
            updateInteraction(interaction.id, {
              ...interaction,
              sessionId: null,
              loading: false,
              responseBody: [{ type: ContentType.Text, content: capabilities }],
              res: capabilities,
              responseContext: [],
              feedbackEnabled: false,
            });
          } else if (request.toLowerCase() == 'methodology') {
            updateInteraction(interaction.id, {
              ...interaction,
              sessionId: null,
              loading: false,
              responseBody: [{ type: ContentType.Text, content: methodology }],
              res: methodology,
              responseContext: [],
              feedbackEnabled: false,
            });
          } else if (request.toLowerCase() == "what's coming") {
            updateInteraction(interaction.id, {
              ...interaction,
              sessionId: null,
              loading: false,
              responseBody: [{ type: ContentType.Text, content: whatscoming }],
              res: whatscoming,
              responseContext: [],
              feedbackEnabled: false,
            });
          }
          else {
            const args: InteractionRequestPayload = {
              sessionId: session,
              keyonlineuser: userInformation?.keyOnlineUser,
              userInput: [
                {
                  type: ContentType.Text,
                  value: request,
                  taggedEntities: tagEntities,
                },
              ],
              previousInteractionId: getLastInteractionId(),
              supportedNodeTypes: [
                ContentType.Text,
                ContentType.Code,
                ContentType.Table,
                ContentType.KnowledgeDiscovery,
              ],
            };
            let response = await createInteraction(args);
            if(args)
            {

            }
            //response = JSON.parse('{"sessionId":"ba57a952-aa07-4c14-b199-fa0e3806a1cc","keyonlineuser":-1899994831,"interactionId":"8467c6e4-6456-4ef8-8e22-903db1607db1","responseBody":[{"type":"Text","content":null,"columns":null,"rows":null,"count":0,"answer":"Here is the list of banks with an Issuer Credit Rating (Foreign Currency LT) of AA:","documents":[{"id":"0899f6e2-8825-47dc-a20d-c3dc780dd22a","title":"S&P Global Ratings Database","url":"https://www.capitaliq.spglobal.com/web/client?auth=inherit#office/screener?perspective=266637","details":{"conversionInformation":{"keyCurrency":"USD","measurementStandard":0,"conversionMode":0,"magnitudeOverride":null,"nullValue":"NA","dataLanguage":"en-US","requestCulture":"en-US","reportingBasis":"Current/Restated","dateComparison":"Filing Date","industryClassification":"1"},"clientContext":{"templatedId":null,"clientVersion":"1.0","machineId":"00000000-0000-0000-0000-000000000000","disableLogging":false,"is64Bit":false,"keyClientCodes":null,"isGrouped":false,"randomClientCodes":null,"excelCulture":"en-US","requestSource":5,"forceLocalQueries":false,"enableStatistics":false},"functionRequests":[{"perspective":266637,"requestedPerspective":266637,"operationType":22,"fields":[{"primary":336003,"exportPrimary":"RD_CREDIT_WATCH_OUTLOOK_DATE_GLOBAL","secondary":"Issuer Credit Rating","tertiary":"Foreign Currency LT|0","contextJson":null,"originalSecondary":null,"originalTertiary":null,"context":null},{"primary":336004,"exportPrimary":"RD_CREDIT_RATING_DATE_GLOBAL","secondary":"Issuer Credit Rating","tertiary":"Foreign Currency LT|0","contextJson":null,"originalSecondary":null,"originalTertiary":null,"context":null},{"primary":333832,"exportPrimary":"RD_RATING_ACTION_GLOBAL","secondary":"Issuer Credit Rating","tertiary":"Foreign Currency LT|0","contextJson":null,"originalSecondary":null,"originalTertiary":null,"context":null},{"primary":333833,"exportPrimary":"RD_LAST_REVIEW_DATE_GLOBAL","secondary":"Issuer Credit Rating","tertiary":"Foreign Currency LT|0","contextJson":null,"originalSecondary":null,"originalTertiary":null,"context":null},{"primary":334235,"exportPrimary":"RD_CWOL_GLOBAL","secondary":"Issuer Credit Rating","tertiary":"Foreign Currency LT|0","contextJson":null,"originalSecondary":null,"originalTertiary":null,"context":null},{"primary":334045,"exportPrimary":"RD_CREDIT_RATING_GLOBAL","secondary":"Issuer Credit Rating","tertiary":"Foreign Currency LT|0","contextJson":null,"originalSecondary":null,"originalTertiary":null,"context":null},{"primary":333832,"exportPrimary":"RD_RATING_ACTION_GLOBAL","secondary":"Issuer Credit Rating","tertiary":"Local Currency LT|0","contextJson":null,"originalSecondary":null,"originalTertiary":null,"context":null},{"primary":333832,"exportPrimary":"RD_RATING_ACTION_GLOBAL","secondary":"Issuer Credit Rating","tertiary":"Local Currency ST|0","contextJson":null,"originalSecondary":null,"originalTertiary":null,"context":null},{"primary":333832,"exportPrimary":"RD_RATING_ACTION_GLOBAL","secondary":"Issuer Credit Rating","tertiary":"Foreign Currency LT|0","contextJson":null,"originalSecondary":null,"originalTertiary":null,"context":null},{"primary":333832,"exportPrimary":"RD_RATING_ACTION_GLOBAL","secondary":"Issuer Credit Rating","tertiary":"Foreign Currency ST|0","contextJson":null,"originalSecondary":null,"originalTertiary":null,"context":null},{"primary":334045,"exportPrimary":"RD_CREDIT_RATING_GLOBAL","secondary":"Issuer Credit Rating","tertiary":"Local Currency LT|0","contextJson":null,"originalSecondary":null,"originalTertiary":null,"context":null},{"primary":334045,"exportPrimary":"RD_CREDIT_RATING_GLOBAL","secondary":"Issuer Credit Rating","tertiary":"Foreign Currency LT|0","contextJson":null,"originalSecondary":null,"originalTertiary":null,"context":null},{"primary":334045,"exportPrimary":"RD_CREDIT_RATING_GLOBAL","secondary":"Issuer Credit Rating","tertiary":"Foreign Currency ST|0","contextJson":null,"originalSecondary":null,"originalTertiary":null,"context":null},{"primary":334045,"exportPrimary":"RD_CREDIT_RATING_GLOBAL","secondary":"Issuer Credit Rating","tertiary":"Local Currency ST|0","contextJson":null,"originalSecondary":null,"originalTertiary":null,"context":null},{"primary":334235,"exportPrimary":"RD_CWOL_GLOBAL","secondary":"Issuer Credit Rating","tertiary":"Local Currency LT|0","contextJson":null,"originalSecondary":null,"originalTertiary":null,"context":null},{"primary":334235,"exportPrimary":"RD_CWOL_GLOBAL","secondary":"Issuer Credit Rating","tertiary":"Foreign Currency LT|0","contextJson":null,"originalSecondary":null,"originalTertiary":null,"context":null},{"primary":334235,"exportPrimary":"RD_CWOL_GLOBAL","secondary":"Issuer Credit Rating","tertiary":"Foreign Currency ST|0","contextJson":null,"originalSecondary":null,"originalTertiary":null,"context":null},{"primary":334235,"exportPrimary":"RD_CWOL_GLOBAL","secondary":"Issuer Credit Rating","tertiary":"Local Currency ST|0","contextJson":null,"originalSecondary":null,"originalTertiary":null,"context":null},{"primary":336004,"exportPrimary":"RD_CREDIT_RATING_DATE_GLOBAL","secondary":"Issuer Credit Rating","tertiary":"Local Currency LT|0","contextJson":null,"originalSecondary":null,"originalTertiary":null,"context":null},{"primary":336004,"exportPrimary":"RD_CREDIT_RATING_DATE_GLOBAL","secondary":"Issuer Credit Rating","tertiary":"Foreign Currency LT|0","contextJson":null,"originalSecondary":null,"originalTertiary":null,"context":null},{"primary":336004,"exportPrimary":"RD_CREDIT_RATING_DATE_GLOBAL","secondary":"Issuer Credit Rating","tertiary":"Foreign Currency ST|0","contextJson":null,"originalSecondary":null,"originalTertiary":null,"context":null},{"primary":336004,"exportPrimary":"RD_CREDIT_RATING_DATE_GLOBAL","secondary":"Issuer Credit Rating","tertiary":"Local Currency ST|0","contextJson":null,"originalSecondary":null,"originalTertiary":null,"context":null},{"primary":336003,"exportPrimary":"RD_CREDIT_WATCH_OUTLOOK_DATE_GLOBAL","secondary":"Issuer Credit Rating","tertiary":"Local Currency LT|0","contextJson":null,"originalSecondary":null,"originalTertiary":null,"context":null},{"primary":336003,"exportPrimary":"RD_CREDIT_WATCH_OUTLOOK_DATE_GLOBAL","secondary":"Issuer Credit Rating","tertiary":"Foreign Currency LT|0","contextJson":null,"originalSecondary":null,"originalTertiary":null,"context":null},{"primary":336003,"exportPrimary":"RD_CREDIT_WATCH_OUTLOOK_DATE_GLOBAL","secondary":"Issuer Credit Rating","tertiary":"Foreign Currency ST|0","contextJson":null,"originalSecondary":null,"originalTertiary":null,"context":null},{"primary":336003,"exportPrimary":"RD_CREDIT_WATCH_OUTLOOK_DATE_GLOBAL","secondary":"Issuer Credit Rating","tertiary":"Local Currency ST|0","contextJson":null,"originalSecondary":null,"originalTertiary":null,"context":null},{"primary":334045,"exportPrimary":"RD_CREDIT_RATING_GLOBAL","secondary":"Issuer Credit Rating","tertiary":"Local Currency LT|1","contextJson":null,"originalSecondary":null,"originalTertiary":null,"context":null},{"primary":334045,"exportPrimary":"RD_CREDIT_RATING_GLOBAL","secondary":"Issuer Credit Rating","tertiary":"Foreign Currency LT|1","contextJson":null,"originalSecondary":null,"originalTertiary":null,"context":null},{"primary":334045,"exportPrimary":"RD_CREDIT_RATING_GLOBAL","secondary":"Issuer Credit Rating","tertiary":"Foreign Currency ST|1","contextJson":null,"originalSecondary":null,"originalTertiary":null,"context":null},{"primary":334045,"exportPrimary":"RD_CREDIT_RATING_GLOBAL","secondary":"Issuer Credit Rating","tertiary":"Local Currency ST|1","contextJson":null,"originalSecondary":null,"originalTertiary":null,"context":null},{"primary":334235,"exportPrimary":"RD_CWOL_GLOBAL","secondary":"Issuer Credit Rating","tertiary":"Local Currency LT|1","contextJson":null,"originalSecondary":null,"originalTertiary":null,"context":null},{"primary":334235,"exportPrimary":"RD_CWOL_GLOBAL","secondary":"Issuer Credit Rating","tertiary":"Foreign Currency LT|1","contextJson":null,"originalSecondary":null,"originalTertiary":null,"context":null},{"primary":334235,"exportPrimary":"RD_CWOL_GLOBAL","secondary":"Issuer Credit Rating","tertiary":"Foreign Currency ST|1","contextJson":null,"originalSecondary":null,"originalTertiary":null,"context":null},{"primary":334235,"exportPrimary":"RD_CWOL_GLOBAL","secondary":"Issuer Credit Rating","tertiary":"Local Currency ST|1","contextJson":null,"originalSecondary":null,"originalTertiary":null,"context":null},{"primary":333833,"exportPrimary":"RD_LAST_REVIEW_DATE_GLOBAL","secondary":"Issuer Credit Rating","tertiary":"Local Currency LT","contextJson":null,"originalSecondary":null,"originalTertiary":null,"context":null},{"primary":333833,"exportPrimary":"RD_LAST_REVIEW_DATE_GLOBAL","secondary":"Issuer Credit Rating","tertiary":"Foreign Currency LT","contextJson":null,"originalSecondary":null,"originalTertiary":null,"context":null},{"primary":333833,"exportPrimary":"RD_LAST_REVIEW_DATE_GLOBAL","secondary":"Issuer Credit Rating","tertiary":"Foreign Currency ST","contextJson":null,"originalSecondary":null,"originalTertiary":null,"context":null},{"primary":333833,"exportPrimary":"RD_LAST_REVIEW_DATE_GLOBAL","secondary":"Issuer Credit Rating","tertiary":"Local Currency ST","contextJson":null,"originalSecondary":null,"originalTertiary":null,"context":null},{"primary":321213,"exportPrimary":"IndustryClassification","secondary":null,"tertiary":null,"contextJson":null,"originalSecondary":null,"originalTertiary":null,"context":null}],"groupByField":null,"keys":null,"query":{"keyPerspective":266637,"baseCompany":null,"queryFilters":[],"queryLineGroups":[{"groupName":"QueryLines","queryLines":[{"field":{"fieldKey":334045,"exportFieldKey":334045,"secondaryKeys":[{"key":"Issuer Credit Rating","keyJointHint":"sk_1218","keyOption":0,"value":"Issuer Credit Rating","displayValue":"Issuer Credit Rating","mask":"Issuer Credit Rating"},{"key":"Foreign Currency LT","keyJointHint":"sk_1220","keyOption":0,"value":"Foreign Currency LT","displayValue":"Foreign Currency LT","mask":"Foreign Currency LT"},{"key":"0","keyJointHint":"sk_50018","keyOption":0,"value":"0","displayValue":"Current","mask":"0"}]},"value":"aa","displayText":"","operator":7,"connector":0,"beginGroup":false,"endGroup":false,"relativeOperation":false,"queryItemId":"a1d9201e-7512-4b3c-9f29-180ebe44a75b","supressSelect":false,"valueField":null,"mathOperator":0,"mathValue":null,"sortStyle":null,"sortOrder":null,"functionName":null},{"field":{"fieldKey":321213,"exportFieldKey":321213,"secondaryKeys":[]},"value":"8479","displayText":"","operator":7,"connector":0,"beginGroup":false,"endGroup":false,"relativeOperation":false,"queryItemId":"a1d9201e-7512-4b3c-9f29-180ebe44a75b","supressSelect":false,"valueField":null,"mathOperator":0,"mathValue":null,"sortStyle":null,"sortOrder":null,"functionName":null}]},{"groupName":"WhiteAndBlackListCriteria","queryLines":[]},{"groupName":"RankingCriteria","queryLines":[]}]},"functionId":0,"groomingStrategyApplied":false,"groomedColumnOrdinal":null,"groomedRowOrdinal":null,"conversionInfo":null,"requestedKeys":null,"userDefinedFormulas":[]}],"userDefinedFormulas":null,"userDefinedCriteria":null,"extensionPropertiesJson":{"maximumRowLimit":250000,"maximumColumnLimit":200,"maximumCellLimit":10000000,"queryLineToFieldMappings":{"queryLineToFieldMappings":[{"mappingId":"a1d9201e-7512-4b3c-9f29-180ebe44a75b","reportIndex":0,"queryLineIndex":2,"rankFieldIndex":3}]},"userDefinedFormulas":[],"forceLocalQueries":false,"dotNetFrameworkVersion":null}},"date":null,"type":null,"snippets":[{"text":"Data API Services"}]}]},{"type":"CSDTable","content":null,"response":[{"ItemName": "","ProductCaption": "USD_$M","YEAR_1": "2018 FY","YEAR_2": "2019 FY","YEAR_3": "2020 FY","YEAR_4": "","Sort_Order": 0,"CSD_SubSector": "CORP"},{"ItemName":"CIQ043934","ProductCaption":"Adjusted Assets ($M)","YEAR_1":"3694869.000000","YEAR_2":"3613529.000000","YEAR_3":"3820785.000000","YEAR_4":null,"Sort_Order":40,"CSD_SubSector":null,"definition":{"PropertyName":"CIQ043934","KeyItem":113817,"DataType":"number","Magnitude":"$M","ProductCaption":"Adjusted Assets","ProductDecimals":2,"NotMeaningfulValueHigh":null,"NotMeaningfulValueLow":null,"ProductMagnitude":"$M","ProductMagnitudeMultiplier":-6,"ProductDefinition":"Total assets less commitments and guarantees on the balance sheet, insurance statutory funds, and non-servicing intangibles and interest only strips","CurrencyDomain":"Spot","ProductCaptionShort":"Adjusted Assets","Length":19}},{"ItemName":"CIQ044019","ProductCaption":"Customer Loans (Gross) ($M)","YEAR_1":"1129459.000000","YEAR_2":"1175410.000000","YEAR_3":"1363133.000000","YEAR_4":null,"Sort_Order":50,"CSD_SubSector":null,"definition":{"PropertyName":"CIQ044019","KeyItem":113803,"DataType":"number","Magnitude":"$M","ProductCaption":"Customer Loans (Gross)","ProductDecimals":2,"NotMeaningfulValueHigh":null,"NotMeaningfulValueLow":null,"ProductMagnitude":"$M","ProductMagnitudeMultiplier":-6,"ProductDefinition":"Total customer loans on the companys balance sheet, gross of loan loss reserves","CurrencyDomain":"Spot","ProductCaptionShort":"Customer Loans (Gross)","Length":19}},{"ItemName":"EmptyLine1","ProductCaption":" ","YEAR_1":"&nbsp;","YEAR_2":"&nbsp;","YEAR_3":"&nbsp;","YEAR_4":"&nbsp;","Sort_Order":21,"CSD_SubSector":null,"definition":null},{"ItemName": "Core Ratios","ProductCaption": "Core Ratios","YEAR_1": "&nbsp;","YEAR_2": "&nbsp;","YEAR_3": "&nbsp;","YEAR_4": "&nbsp;","Sort_Order": 23,"CSD_SubSector": null},{"ItemName":"CIQ043946","ProductCaption":"Adjusted Common Equity ($M)","YEAR_1":"196926.000000","YEAR_2":"209806.000000","YEAR_3":"252170.000000","YEAR_4":null,"Sort_Order":60,"CSD_SubSector":null,"definition":{"PropertyName":"CIQ043946","KeyItem":113843,"DataType":"number","Magnitude":"$M","ProductCaption":"Adjusted Common Equity","ProductDecimals":2,"NotMeaningfulValueHigh":null,"NotMeaningfulValueLow":null,"ProductMagnitude":"$M","ProductMagnitudeMultiplier":-6,"ProductDefinition":"Intermediate adjusted common equity less deferred tax assets arising from temporary differences not convertible into cash or government bonds exceeding 10% of intermediate adjusted common equity","CurrencyDomain":"Spot","ProductCaptionShort":"Adjusted Common Equity","Length":19}},{"ItemName":"CIQ044064","ProductCaption":"Operating Revenues ($M)","YEAR_1":"121889.000000","YEAR_2":"127919.000000","YEAR_3":"158186.000000","YEAR_4":null,"Sort_Order":70,"CSD_SubSector":null,"definition":{"PropertyName":"CIQ044064","KeyItem":113717,"DataType":"number","Magnitude":"$M","ProductCaption":"Operating Revenues","ProductDecimals":2,"NotMeaningfulValueHigh":null,"NotMeaningfulValueLow":null,"ProductMagnitude":"$M","ProductMagnitudeMultiplier":-6,"ProductDefinition":"Net interest income plus operating noninterest income","CurrencyDomain":"Average","ProductCaptionShort":"Operating Revenues","Length":19}},{"ItemName":"CIQ044043","ProductCaption":"Noninterest Expense ($M)","YEAR_1":"71675.000000","YEAR_2":"75547.000000","YEAR_3":"87388.000000","YEAR_4":null,"Sort_Order":80,"CSD_SubSector":null,"definition":{"PropertyName":"CIQ044043","KeyItem":113720,"DataType":"number","Magnitude":"$M","ProductCaption":"Noninterest Expense","ProductDecimals":2,"NotMeaningfulValueHigh":null,"NotMeaningfulValueLow":null,"ProductMagnitude":"$M","ProductMagnitudeMultiplier":-6,"ProductDefinition":"Operating expense aside from interest expense, including personnel expense, premises expense, depreciation and amortization, administrative costs, and other operating expenses","CurrencyDomain":"Average","ProductCaptionShort":"Noninterest Expense","Length":19}},{"ItemName":"CIQ044032","ProductCaption":"Net Income ($M)","YEAR_1":"48334.000000","YEAR_2":"37676.000000","YEAR_3":"49552.000000","YEAR_4":null,"Sort_Order":90,"CSD_SubSector":null,"definition":{"PropertyName":"CIQ044032","KeyItem":113731,"DataType":"number","Magnitude":"$M","ProductCaption":"Net Income","ProductDecimals":2,"NotMeaningfulValueHigh":null,"NotMeaningfulValueLow":null,"ProductMagnitude":"$M","ProductMagnitudeMultiplier":-6,"ProductDefinition":"Net income excluding minority interest but including extraordinary gains or losses","CurrencyDomain":"Average","ProductCaptionShort":"Net Income","Length":19}},{"ItemName":"CIQ043938","ProductCaption":"Tier 1 Capital Ratio (%)","YEAR_1":"15.020000","YEAR_2":"14.850000","YEAR_3":"16.590000","YEAR_4":null,"Sort_Order":100,"CSD_SubSector":null,"definition":{"PropertyName":"CIQ043938","KeyItem":113837,"DataType":"number","Magnitude":"%","ProductCaption":"Tier 1 Capital Ratio","ProductDecimals":2,"NotMeaningfulValueHigh":null,"NotMeaningfulValueLow":null,"ProductMagnitude":"%","ProductMagnitudeMultiplier":0,"ProductDefinition":"The tier 1 capital ratio reflects the regulators view of the companys capital to its risk-weighted assets (RWAs). A higher ratio indicates greater ability for the company to absorb future losses. Calculated as tier 1 capital as a percent of regulatory RWAs.","CurrencyDomain":null,"ProductCaptionShort":"Tier 1 Capital Ratio","Length":19}},{"ItemName":"CIQ045339","ProductCaption":"Adjusted Common Equity/ Total Adjusted Capital (%)","YEAR_1":"84.970000","YEAR_2":"NA","YEAR_3":"NA","YEAR_4":null,"Sort_Order":120,"CSD_SubSector":null,"definition":{"PropertyName":"CIQ045339","KeyItem":113873,"DataType":"number","Magnitude":"%","ProductCaption":"Adjusted Common Equity/ Total Adjusted Capital","ProductDecimals":2,"NotMeaningfulValueHigh":null,"NotMeaningfulValueLow":null,"ProductMagnitude":"%","ProductMagnitudeMultiplier":0,"ProductDefinition":"Adjusted common equity as a percent of total adjusted capital. The closer this ratio is to 100%, the less the companys capital position relies on preferred stock and other hybrid issuance.","CurrencyDomain":null,"ProductCaptionShort":"Adjusted Common Equity/ Total Ad","Length":19}},{"ItemName":"CIQ045882","ProductCaption":"Return on Equity (%)","YEAR_1":"18.380000","YEAR_2":"NA","YEAR_3":"NA","YEAR_4":null,"Sort_Order":130,"CSD_SubSector":null,"definition":{"PropertyName":"CIQ045882","KeyItem":113930,"DataType":"number","Magnitude":"%","ProductCaption":"Return on Equity","ProductDecimals":2,"NotMeaningfulValueHigh":null,"NotMeaningfulValueLow":null,"ProductMagnitude":"%","ProductMagnitudeMultiplier":0,"ProductDefinition":"Return on average common equity measures a companys profitability by revealing how much profit a company generates with the money shareholders have invested. Calculated as net income after extraordinary items net of preferred dividends, as a percent of average common equity.  ","CurrencyDomain":null,"ProductCaptionShort":"Return on Equity","Length":19}},{"ItemName":"CIQ043987","ProductCaption":"Net Interest Income/ Operating Revenue (%)","YEAR_1":"43.100000","YEAR_2":"52.480000","YEAR_3":"56.700000","YEAR_4":null,"Sort_Order":140,"CSD_SubSector":null,"definition":{"PropertyName":"CIQ043987","KeyItem":113751,"DataType":"number","Magnitude":"%","ProductCaption":"Net Interest Income/ Operating Revenue","ProductDecimals":2,"NotMeaningfulValueHigh":null,"NotMeaningfulValueLow":null,"ProductMagnitude":"%","ProductMagnitudeMultiplier":0,"ProductDefinition":"Net interest income as a percent of operating revenue. Used to assess how much of the companys revenue results from traditional lending activities.","CurrencyDomain":null,"ProductCaptionShort":"Net Interest Income/ Revenue","Length":19}},{"ItemName":"CIQ043977","ProductCaption":"Fee Income/ Operating Revenue (%)","YEAR_1":"31.140000","YEAR_2":"25.570000","YEAR_3":"20.110000","YEAR_4":null,"Sort_Order":150,"CSD_SubSector":null,"definition":{"PropertyName":"CIQ043977","KeyItem":113740,"DataType":"number","Magnitude":"%","ProductCaption":"Fee Income/ Operating Revenue","ProductDecimals":2,"NotMeaningfulValueHigh":null,"NotMeaningfulValueLow":null,"ProductMagnitude":"%","ProductMagnitudeMultiplier":0,"ProductDefinition":"Fee income as a percent of operating revenue. Used to assess how much of the companys revenue results from fees and commissions as opposed to lending, trading, or other revenues.","CurrencyDomain":null,"ProductCaptionShort":"Fee Income/ Revenue","Length":19}},{"ItemName":"CIQ044012","ProductCaption":"Loan Loss Reserves/ Gross Nonperforming Assets (%)","YEAR_1":"117.340000","YEAR_2":"160.950000","YEAR_3":"187.010000","YEAR_4":null,"Sort_Order":160,"CSD_SubSector":null,"definition":{"PropertyName":"CIQ044012","KeyItem":113785,"DataType":"number","Magnitude":"%","ProductCaption":"Loan Loss Reserves/ Gross Nonperforming Assets","ProductDecimals":2,"NotMeaningfulValueHigh":null,"NotMeaningfulValueLow":null,"ProductMagnitude":"%","ProductMagnitudeMultiplier":0,"ProductDefinition":"Loan loss reserves as a percent of nonperforming assets. Loan loss reserves build up through provisioning, which is an expense to companies. If this ratio is low it may mean that the company is not provisioning enough, which means they may need to incur larger provisioning expenses in the future.","CurrencyDomain":null,"ProductCaptionShort":"Loan Loss Reserves/ Gross Nonper","Length":19}},{"ItemName":"CIQ044050","ProductCaption":"New Loan Loss Provisions/ Average Customer Loans (%)","YEAR_1":"-0.830000","YEAR_2":"0.550000","YEAR_3":"0.730000","YEAR_4":null,"Sort_Order":170,"CSD_SubSector":null,"definition":{"PropertyName":"CIQ044050","KeyItem":113784,"DataType":"number","Magnitude":"%","ProductCaption":"New Loan Loss Provisions/ Average Customer Loans","ProductDecimals":2,"NotMeaningfulValueHigh":null,"NotMeaningfulValueLow":null,"ProductMagnitude":"%","ProductMagnitudeMultiplier":0,"ProductDefinition":"Credit loss provisions, net new, less provisions for loans to banks, as a percent of average customer loans. Indicates the companys best estimate of future losses on their customer loan portfolio.","CurrencyDomain":null,"ProductCaptionShort":"New Loan Loss Provisions/ Averag","Length":19}},{"ItemName":"CIQ043942","ProductCaption":"Net Charge-Offs/ Average Customer Loans (%)","YEAR_1":"0.260000","YEAR_2":"0.250000","YEAR_3":"0.490000","YEAR_4":null,"Sort_Order":180,"CSD_SubSector":null,"definition":{"PropertyName":"CIQ043942","KeyItem":113787,"DataType":"number","Magnitude":"%","ProductCaption":"Net Charge-Offs/ Average Customer Loans","ProductDecimals":2,"NotMeaningfulValueHigh":null,"NotMeaningfulValueLow":null,"ProductMagnitude":"%","ProductMagnitudeMultiplier":0,"ProductDefinition":"Net charge-offs as a percent of average customer loans. Provides an indication of the percentage of customer debt that the company believes it will never collect.","CurrencyDomain":null,"ProductCaptionShort":"Net Charge-Offs/ Average Custome","Length":19}},{"ItemName":"CIQ045333","ProductCaption":"Gross NPAs/ Cust Loans + OREO (%)","YEAR_1":"1.240000","YEAR_2":"NA","YEAR_3":"NA","YEAR_4":null,"Sort_Order":190,"CSD_SubSector":null,"definition":{"PropertyName":"CIQ045333","KeyItem":113869,"DataType":"number","Magnitude":"%","ProductCaption":"Gross NPAs/ Cust Loans + OREO","ProductDecimals":2,"NotMeaningfulValueHigh":null,"NotMeaningfulValueLow":null,"ProductMagnitude":"%","ProductMagnitudeMultiplier":0,"ProductDefinition":"Gross nonperforming assets as a percent of gross customer loans plus other real estate owned. Used to assess the overall quality of the companys customer loan portfolio, with a lower ratio indicating higher quality.","CurrencyDomain":null,"ProductCaptionShort":"Gross NPAs/ Cust Loans + OREO","Length":19}},{"ItemName":"CIQ045335","ProductCaption":"Customer Loans (Net)/ Customer Deposits (%)","YEAR_1":"47.180000","YEAR_2":"NA","YEAR_3":"NA","YEAR_4":null,"Sort_Order":200,"CSD_SubSector":null,"definition":{"PropertyName":"CIQ045335","KeyItem":113871,"DataType":"number","Magnitude":"%","ProductCaption":"Customer Loans (Net)/ Customer Deposits","ProductDecimals":2,"NotMeaningfulValueHigh":null,"NotMeaningfulValueLow":null,"ProductMagnitude":"%","ProductMagnitudeMultiplier":0,"ProductDefinition":"Customer loans, net as a percent of customer deposits. Loan to deposit ratios are used to assess a companys liquidity. A higher ratio indicates low liquidity, while a lower ratio indicates that the company may not be earning as much interest as it could.","CurrencyDomain":null,"ProductCaptionShort":"Customer Loans (Net)/ Customer D","Length":19}},{"ItemName":"CIQ045567","ProductCaption":"Liquidity Coverage Metric (x)","YEAR_1":"3.540000","YEAR_2":"NA","YEAR_3":"NA","YEAR_4":null,"Sort_Order":210,"CSD_SubSector":null,"definition":{"PropertyName":"CIQ045567","KeyItem":113922,"DataType":"number","Magnitude":"x","ProductCaption":"Liquidity Coverage Metric","ProductDecimals":2,"NotMeaningfulValueHigh":null,"NotMeaningfulValueLow":null,"ProductMagnitude":"x","ProductMagnitudeMultiplier":2,"ProductDefinition":"Broad liquid assets as a multiple of short term wholesale funding for banks, finance companies, and business development companies, and as broad liquid assets as a multiple of balance sheet liquidity needs for brokers. The higher the ratio, the more short term assets the company has to cover short term obligations.","CurrencyDomain":null,"ProductCaptionShort":"Liquidity Coverage Metric","Length":19}},{"ItemName":"CIQ046050","ProductCaption":"Stable Funding Ratio (%)","YEAR_1":"147.190000","YEAR_2":"NA","YEAR_3":"NA","YEAR_4":null,"Sort_Order":220,"CSD_SubSector":null,"definition":{"PropertyName":"CIQ046050","KeyItem":113935,"DataType":"number","Magnitude":"%","ProductCaption":"Stable Funding Ratio","ProductDecimals":2,"NotMeaningfulValueHigh":null,"NotMeaningfulValueLow":null,"ProductMagnitude":"%","ProductMagnitudeMultiplier":0,"ProductDefinition":"Available stable funding as a percent of stable funding needs. This ratio is specific to the bank, finance company, and business development company sectors.","CurrencyDomain":null,"ProductCaptionShort":"Stable Funding Ratio","Length":19}}],"count":11,"answer":null,"documents":[{"id":"2bfa059a-bd94-4650-9376-a6c47efbe6e1","title":null,"url":null,"details":"null","date":null,"type":null,"snippets":[{"text":"Data API Services"}]}]}],"responseContext":null,"responseTimestamp":"2024-10-09T09:59:33","op":null}');
            let temp: any[] = [];
            response?.responseBody.map((value: TextResponseNode | TableResponseNode | KnowledgeDiscoveryResponseNode) => {
              if (value?.documents != null && value?.documents.length > 0)
                {
                  let isSourcePres = false;
                  if(value?.type == 'Text' && value?.documents[0].details && value?.documents[0].details !== "null"){
                  let payLoadLocal: PayloadDetails = { interactionId: '', payload: '' };
                  let payLoadDetails: PayloadDetails[] = [];
                      payLoadLocal.interactionId = response.interactionId;
                      payLoadLocal.payload = value?.documents[0].details;
                      
                    if(payLoad && payLoad.length == 0)
                    {
                      payLoadDetails.push(payLoadLocal);
                      setPayload(payLoadDetails);
                    }
                    else
                    {
                      payLoad.push(payLoadLocal);
                      setPayload(payLoad);
                    }
                }
                for(var k=0;k<value?.documents.length ;k++)
                  {
                        if(value?.documents[k].title)
                        {
                          isSourcePres =true;
                          break;
                        }
                  }
                  if(isSourcePres == true)
                    {
                      temp.push(value);
                    }
                }
            });

            setSession(response?.sessionId);
            updateInteraction(interaction.id, {
              ...interaction,
              sessionId: response?.sessionId,
              id: response.interactionId,
              date: interaction.date,
              loading: false,
              res: (
                <>
                  <ResponseView data={response?.responseBody || null} interactionId={response.interactionId} interactionType='user' />
                  <br />
                  <div className="responseDate" style={{ display: 'flex', marginLeft: 'auto', marginRight: '-51px' }}>
                    <span>{getLocalizedDate(
                    response?.responseTimestamp,
                    true,
                    userInformation.culture,
                    userInformation.mSTimeZoneID
                    )}
                      </span>
                  </div>
                  {temp.length > 0 && <H5>Sources:</H5>}
                  <ul style={{ fontSize: '14px' }}>
                    <div>
                      {response?.responseBody.map((value: TextResponseNode | TableResponseNode | KnowledgeDiscoveryResponseNode) =>
                        value?.documents && value?.documents.map((doc: KnowledgeDiscoveryDocuments) => (
                          doc.title && (<DocumentList>
                            <a href={doc.url} target="_blank">{doc.title}</a>
                            <span>{doc.date != null ? " " + RESEARCH_MAPPING[doc.type as keyof typeof RESEARCH_MAPPING] + " published " + moment(doc.date).format('MMMM Do, YYYY') : ''}</span>
                          </DocumentList>)
                        )

                        ))}
                    </div>
                  </ul>

                </>
              ),
              responseContext: response?.responseContext,
              feedbackEnabled: true,
            });
          }
        } catch (e) {
          updateInteraction(interaction.id, {
            ...interaction,
            sessionId: session,
            loading: false,
            res: noResponse,
            responseContext: [],
            feedbackEnabled: false,
          });
        }
      },
      newInteractionChatHistory: async (request: ChatHistoryResponse) => {
        setSession(request.sessionId);
        setPayload([]);
        setchatHistory("History");
        const args: ChatSessionHistoryRequestPayload = {
          sessionId: request.sessionId
        };
        let response = await getChatDetailsFromSession(args);
        let tempInteractions: Interaction[] = [];
        if (response != null) {
          response = response.sort((a, b) => {
            if (a.requestTimeStamp < b.requestTimeStamp) {
              return -1;
            }
            if (a.requestTimeStamp > b.requestTimeStamp) {
              return 1;
            }
            return 0;
          });
          interactions = [];
          for (var k = 0; k < response.length; k++) {
            let feedbackResp: Feedback = {
              sentiment: response[k].feedback?.feedback_sentiment,
              tags: response[k].feedback?.tags,
              text: response[k].feedback?.text_feedback
            };
            let interaction: Interaction = {
              id: response[k].interactionId,
              type: "his",
              feedback: feedbackResp,
              sessionId: response[k].sessionId,
              date: getLocalizedDate(
                response[k]?.requestTimeStamp,
                true,
                userInformation.culture,
                userInformation.mSTimeZoneID
              ),
              req: response[k].userInput[0].value,
              loading: true,
            };
            //setInteractions([...interactions, interaction])
            interactions.push(interaction);
            tempInteractions.push(interaction);
          }
          setInteractions([...interactions]);
          for (var j = 0; j < tempInteractions.length; j++) {
            let tempHis: any[] = [];
            response[j]?.responseBody.map((value: TextResponseNode | TableResponseNode | KnowledgeDiscoveryResponseNode) => {
              if (value?.documents != null && value?.documents.length > 0)
                {
                  let isSourcePres = false;
                  if(value?.type == 'Text' && value?.documents[0].details && value?.documents[0].details !== "null"){
                  let payLoadLocal: PayloadDetails = { interactionId: '', payload: '' };
                  //let payLoadDetails: PayloadDetails[] = [];
                      payLoadLocal.interactionId = tempInteractions[j].id;
                      payLoadLocal.payload = value?.documents[0].details;
                      
                    if(payloadFinal && payloadFinal.length == 0)
                    {
                      payloadFinal.push(payLoadLocal);
                      setPayload([...payloadFinal]);
                    }
                    else
                    {
                      let pay = payLoad.find(x=>x.interactionId == tempInteractions[j].id)
                          if(!pay)
                            {
                              payloadFinal.push(payLoadLocal);
                              setPayload([...payloadFinal]);
                            }
                    }
                  
                }
                for(var k=0;k<value?.documents.length ;k++)
                  {
                        if(value?.documents[k].title)
                        {
                          isSourcePres =true;
                          break;
                        }
                  }
                  if(isSourcePres == true)
                    {
                      tempHis.push(value);
                    }
                
                }
            });
            updateInteraction(tempInteractions[j].id, {
              ...tempInteractions[j],
              sessionId: tempInteractions[j].sessionId,
              feedback: tempInteractions[j].feedback,
              date: getLocalizedDate(
                response[j].requestTimeStamp,
                true,
                userInformation.culture,
                userInformation.mSTimeZoneID
              ),
              loading: false,
              res: (
                <>
                  <ResponseView data={response[j].responseBody || null} interactionId={tempInteractions[j].id} interactionType='his' />
                  <div className="responseDate" style={{ display: 'flex', marginLeft: 'auto', marginRight: '-51px' }}>
                    <span>{getLocalizedDate(
                      response[j].responseTimestamp,
                      true,
                      userInformation.culture,
                      userInformation.mSTimeZoneID
                    )}</span>
                  </div>
                  {tempHis.length > 0 && <H5>Sources:</H5>}
                  <ul style={{ fontSize: '14px' }}>

                    <div>
                      {response[j].responseBody.map((value: TextResponseNode | TableResponseNode | KnowledgeDiscoveryResponseNode) =>
                        value?.documents && value?.documents.map((doc: KnowledgeDiscoveryDocuments) => (
                          doc.title && (<DocumentList>
                            <a href={doc.url} target="_blank">{doc.title}</a>
                            <span>{doc.date != null ? " " + RESEARCH_MAPPING[doc.type as keyof typeof RESEARCH_MAPPING] + " published " + moment(doc.date).format('MMMM Do, YYYY') : ''}</span>
                          </DocumentList>)
                        )

                        )

                      )}
                    </div>
                  </ul>

                </>
              ),
              responseContext: response[j].responseContext,
              feedbackEnabled: true,
            });
          }
        }
      },
      updateInteraction,
      scrollCompleted,
      payLoad
    };
  }, [session, interactions, chatHistory, tableRef, payLoad,scrollCompleted]);

  return <context.Provider value={value}>{children}</context.Provider>;
};

export const useChatRD = () => React.useContext(context);
