import argparse
import json
import logging
import os

from tqdm.auto import tqdm

from chatrd.core.aws_utils.opensearch import get_secret
from chatrd.core.embedding import MiniLMEmbeddingModel
from chatrd.core.vectorstore.opensearch import OpenSearch

parser = argparse.ArgumentParser()
parser.add_argument(
    "--test-case-file-path",
    required=True,
    type=str,
    help="the input file which contains test data",
)
parser.add_argument(
    "--index-value",
    required=True,
    type=str,
    default=None,
    help="index",
)

args = parser.parse_args()
test_case_file_path = args.test_case_file_path
index_value = args.index_value

embedding_model = MiniLMEmbeddingModel()


template_name = "eval"
fh = logging.FileHandler(filename="eval.log")
logger = logging.getLogger(template_name)
logging.basicConfig(
    format="%(asctime)s [%(processName)s/%(process)d] [%(levelname)s] %(name)s:%(lineno)d: %(message)s",
    level=logging.INFO,
    handlers=[fh],
)
logger.info("Test")

master_user_name = "admin123"
password = os.environ["OPENSEARCH_PASSWORD"]
host = "vpc-mi-ds-chatrd-dev-4tlehtxwsndewv4qymmxeerqqu.us-east-1.es.amazonaws.com"
port = 443
index_name = index_value


opensearch_instance = OpenSearch(
    host=host, port=port, user_name=master_user_name, password=password, index_name=index_name, model=embedding_model
)


hits_1 = float()
hits_2 = float()
hits_3 = float()
hits_4 = float()
tries = int()


with open(test_case_file_path, "r") as f:
    dataset = json.load(f)

hits_1, hits_2, hits_3, hits_4 = 0, 0, 0, 0
tries = len(dataset)


for item in tqdm(dataset):
    retrieved = opensearch_instance.get_relevant_documents(item["question"], k=4)
    if item["document_id"] == int(retrieved[0][0].metadata["ARTICLE_ID"]):
        hits_1 += 1
    if item["document_id"] in [int(item.metadata["ARTICLE_ID"]) for item in retrieved[0][:2]]:
        hits_2 += 1
    if item["document_id"] in [int(item.metadata["ARTICLE_ID"]) for item in retrieved[0][:3]]:
        hits_3 += 1
    if item["document_id"] in [int(item.metadata["ARTICLE_ID"]) for item in retrieved[0][:4]]:
        hits_4 += 1


top_1_acc = round(hits_1 / tries, 4)
top_2_acc = round(hits_2 / tries, 4)
top_3_acc = round(hits_3 / tries, 4)
top_4_acc = round(hits_4 / tries, 4)


print(f"top_1_acc: {top_1_acc}, top_2_acc : {top_2_acc}, top_3_acc : {top_3_acc}, top_4_acc : {top_4_acc}")
