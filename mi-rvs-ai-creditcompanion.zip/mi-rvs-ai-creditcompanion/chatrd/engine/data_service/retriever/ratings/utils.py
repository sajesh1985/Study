import json
import logging
from typing import Dict, List, Optional, Tuple

import pandas as pd

from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.data_service.kpqi import KPQI, KPQIPayload
from chatrd.engine.data_service.postprocessing import postprocess_cells_view
from chatrd.engine.data_service.retriever import BaseRetriever
from chatrd.engine.data_service.retriever.query.utils import get_payload_path
from chatrd.engine.data_service.retriever.utils import (
    create_dynamic_column_header,
    update_query_field,
)
from chatrd.engine.data_service.schema import ScreenerPayload
from chatrd.engine.data_service.utils import get_entity_type

logger = logging.getLogger(__name__)
config_machinery = get_config_machinery()

with open(get_payload_path(Constants.PayLoad.DATASERVICE_PAYLOAD_PATH)) as fp:
    DATASERVICE_PAYLOAD = json.load(fp)
DEFAULT_PAYLOAD = DATASERVICE_PAYLOAD["DEFAULT_PAYLOAD"]
SECURITY_GLOBAL_RATING_BASE = DATASERVICE_PAYLOAD["SECURITY_GLOBAL_RATING_BASE"]
SECURITY_USPF_APPEND = DATASERVICE_PAYLOAD["SECURITY_USPF_APPEND"]
USPF_CREDIT_RATING_BASE = DATASERVICE_PAYLOAD["USPF_CREDIT_RATING_BASE"]

DEFAULT_SECURITY_RATING_FUNCTION_FIELDS = {322517}
MAX_RESULTS = config_machinery.get_config_value(Constants.GeneralConstants.NUM_ROWS_TO_DISPLAY)
ENV = config_machinery.get_config_value(Constants.DataService.DATASERVICE_SCREENER_ENV)


def get_entity_name(entities, key):
    name_var = "extracted_name" if key == "securities" else "name"
    entity_name = entities[key][0].get(name_var)
    return entity_name


def normalize(value):
    return ", ".join(value) if isinstance(value, list) else value


def securities_kpqi_identifier(entities):
    securities = entities.get("securities", [])
    if not securities:
        logger.error("No securities found in entities.")

    security = securities[0]
    extracted_name = security.get("extracted_name", "")
    cusip = security.get("cusip", "")
    isin = security.get("isin", "")

    cusip = normalize(cusip)
    isin = normalize(isin)

    dict_cusip = {"entity_type": "CUSIP", "entity_value": cusip, "kpqi_value": KPQI.KPQI_321280.value}
    dict_isin = {"entity_type": "ISIN", "entity_value": isin, "kpqi_value": KPQI.KPQI_321281.value}

    return dict_isin if extracted_name == isin else dict_cusip


def get_kpqi_value(entities):
    if entities["securities"]:
        securities_values = securities_kpqi_identifier(entities)
        return securities_values["kpqi_value"]
    return KPQI.KPQI_361589.value


class RatingsUtils:
    def _build_value_pairs(self, entities, key: str) -> Dict:
        as_id = entities[key][0].get("as_id")
        kpqi_value = get_kpqi_value(entities)
        entity_name = get_entity_name(entities, key)
        logger.info(f"The {key} is {entity_name} with entity id {as_id}.")

        return {
            kpqi_value: {
                "value": entity_name,
                "connector": 0,
                "operator": 0,
                "data_type": "nstring",
            }
        }

    def _payload_build_revenue_sources(
        self, entities, key_value_pairs: dict, key_perspective: int = 321247
    ) -> Tuple[List[Dict], List[Dict]]:
        functions = []
        queries = []
        functions.extend(USPF_CREDIT_RATING_BASE)
        for k, v in key_value_pairs.items():
            default_function_dict = KPQIPayload(KPQI(k)).default_func_field()
            default_query_dict = KPQIPayload(KPQI(k)).default_query_field()
            # default function
            functions.append(default_function_dict)
            # default query
            query_field_updated = update_query_field(v, default_query_dict)
            queries.append(query_field_updated)

        return functions, queries

    def _payload_build_securities(
        self, entities, key_value_pairs: dict, key_perspective: int = 321247
    ) -> Tuple[List[Dict], List[Dict]]:
        queries = []
        functions = []

        # Build default request fields for security summary payload.
        functions = [KPQIPayload(KPQI(k)).default_func_field() for k in DEFAULT_SECURITY_RATING_FUNCTION_FIELDS]
        functions.extend(SECURITY_GLOBAL_RATING_BASE)
        if entities:
            # we need to identify whether security is USPF or not
            # if its a USPF security, we will need to modify the payload
            # with additional fields/KPQIs
            # else, if its non-USPF, or even dual-mapped, we use standard payload
            security_info = entities["securities"]
            if security_info:
                # get the security sector info
                sector_info = security_info[0]["security_sector"]
                # check if its dual-mapped
                num_sectors = len(sector_info)
                # dual_mapped = num_sectors > 1
                # we are interested in non dual-mapped securities only
                if num_sectors == 1:
                    security_sector = sector_info[0]
                    RDKOS_USPF = config_machinery.get_config_value(Constants.GeneralConstants.RDKOS_USPF)
                    if security_sector == RDKOS_USPF:
                        functions.extend(SECURITY_USPF_APPEND)

        for k, v in key_value_pairs.items():
            query_field = KPQIPayload(KPQI(k)).default_query_field()

            query_field_updated = update_query_field(v, query_field)
            queries.append(query_field_updated)

        return functions, queries

    def _payload_build(self, entities, key_value_pairs: dict, key_perspective: Optional[int] = 359303):
        entity_type = get_entity_type(entities)
        payload_build_entities = (
            self._payload_build_revenue_sources if entity_type == "revenue_source" else self._payload_build_securities
        )
        functions, queries = payload_build_entities(
            entities=entities,
            key_value_pairs=key_value_pairs,
            key_perspective=key_perspective,
        )

        payload = DEFAULT_PAYLOAD
        payload["functionRequests"][0]["perspective"] = key_perspective
        payload["functionRequests"][0]["requestedPerspective"] = key_perspective
        payload["functionRequests"][0]["query"]["keyPerspective"] = key_perspective

        payload["functionRequests"][0]["fields"] = functions
        payload["functionRequests"][0]["pagingInfo"]["pageSize"] = MAX_RESULTS
        payload["functionRequests"][0]["query"]["queryLineGroups"][0]["queryLines"] = queries

        return payload

    def _post_process(
        self,
        response,
        entities: Optional[Dict],
        key_perspective: Optional[int],
        key_perspective_str: Optional[str],
        uc_type: str = "ratings",
    ) -> Tuple[pd.DataFrame, int, ScreenerPayload]:
        try:
            response = response.json()
            columns, column_key = create_dynamic_column_header(
                response, key_perspective=key_perspective, uc_type=uc_type
            )
            df = pd.DataFrame(response["functionResponses"][0]["results"], columns=columns)
        except Exception as e:
            logger.error(f"Error happened: {e}.")
            return pd.DataFrame(), 0, None

        df = postprocess_cells_view(key_perspective, ENV, df)
        df = df.loc[:, ~df.columns.duplicated()]

        entity_name = get_entity_name(entities, key_perspective_str)
        kpqi_value = get_kpqi_value(entities)
        screener_payload = ScreenerPayload(
            key_perspective=key_perspective,
            key_perspective_str=key_perspective_str,
            payload_dict={
                "key": kpqi_value,
                "value": {"value": entity_name, "connector": 0, "operator": 0, "data_type": "nstring"},
            },
            text_dict={"key": "company name", "value": {"value": entity_name, "connector": "and", "operator": "equal"}},
            magnitude_dict={},
            model_response_text="",
        )

        return df, len(df), screener_payload
