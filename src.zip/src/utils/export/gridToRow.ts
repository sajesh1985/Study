import { Report, Row } from '@spglobal/exportservice/export.types';
import { CellBuilder, getTable, ReportHelper, row } from '@spglobal/exportservice';

const gridToRow = (tableRows: Row[], style = '', hasAltStyle = 'true', hasBorder = 'true'): Row => {
  const childReport = new ReportHelper()
    .withReportTable(getTable(tableRows, style, hasAltStyle, hasBorder))
    .build();

  const childCell = new CellBuilder()
    .withContent(childReport)
    .withCellType('table')
    .withCssClass('standardgridtable')
    .build();
  const report: Report = new ReportHelper().withReportTable(getTable([row(childCell)])).build();
  const cell = new CellBuilder().withContent(report).withCellType('table').build();
  return row(cell);
};

export default gridToRow;
