import argparse
import json
from typing import List, Optional

from chatrd.core.utils import ChatMessage, MessageRole
from chatrd.engine.components.query_analyzer.guideline_generator import (
    GuidelineGenerator,
)

with open("scripts/guidelines/examples.json") as f:
    TEST_CASES = json.load(f)

guideline_generator = GuidelineGenerator(model_name="haiku", temperature=0.0)

results = []

for test_case in TEST_CASES:
    guidelines_result = guideline_generator.run(
        query=test_case,
        uc_type="flex_arch",
        entity_type=None,
        subrouting_result=None,
        original_message=""
    )
    results.append(f"Test case: {test_case} \n\nGuideline: {guidelines_result}\n\n")
    print(f"Test case: {test_case} \n\nGuideline: {guidelines_result}\n\n")

# Save all results to a single .txt file
with open("scripts/guidelines/all_guidelines.txt", "w") as file:
    file.writelines(results)
