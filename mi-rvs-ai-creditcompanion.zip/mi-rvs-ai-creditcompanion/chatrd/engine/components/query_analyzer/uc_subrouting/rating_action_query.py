from typing import Optional, Union

from chatrd.core.llm import LCLLMFactory
from chatrd.engine.components.query_analyzer.faulttolerantexecutor import (
    FaultTolerantExecutor,
)
from chatrd.engine.components.query_analyzer.uc_subrouting.prompt_templates import (
    RATING_ACTION_SUBROUTING_TEMPLATE,
    parser_rating_action_subrouting,
)


class RatingActionSubrouter(FaultTolerantExecutor):
    def __init__(self, model_name: str, temperature: Optional[float] = 0.0):
        self.model = LCLLMFactory().get_llm(
            deployment_name_or_model_id=model_name,
            temperature=temperature,
        )

        self.output_parser = parser_rating_action_subrouting
        self.prompt_template = RATING_ACTION_SUBROUTING_TEMPLATE

    def run(self, query: str, entities: str) -> Union[bool, None]:
        question_prompt = self.prompt_template.format(question=query, entities=entities)
        output = self.model.invoke(question_prompt)
        retriever_result = self.output_parser.invoke(output)
        retriever_result_dict = retriever_result.model_dump()
        return retriever_result_dict["CompanyInSubject"]
