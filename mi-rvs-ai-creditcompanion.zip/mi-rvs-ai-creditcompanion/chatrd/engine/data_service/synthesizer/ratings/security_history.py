import logging
from typing import Optional

import pandas as pd

from chatrd.engine.components.query_analyzer.translator.utils import (
    Get_translation_result,
)
from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.data_service.schema import (
    Analyzer,
    ProcessorInput,
    Retriever,
    Synthesizer,
)
from chatrd.engine.data_service.synthesizer.base import BaseSynthesizer
from chatrd.engine.data_service.synthesizer.utils import (
    create_security_history_table,
    full_response,
    get_api_info,
    text_response,
)

logger = logging.getLogger(__name__)

config_machinery = get_config_machinery()

NUM_ROWS_TO_DISPLAY = config_machinery.get_config_value(Constants.GeneralConstants.NUM_ROWS_TO_DISPLAY)


def source_description(entity_name, source_url) -> str:
    return [
        (entity_name, source_url),
    ]


def leading_line(entities, entity_name) -> str:
    extracted_name = entities["securities"][0]["extracted_name"]
    value_type = (entities["securities"][0]["value_type"]).upper()
    template = f"""The rating history for {value_type} {extracted_name} of {entity_name} is the following:"""
    return template


class SecurityCreditHistorySynthesizer(BaseSynthesizer):
    def synthesize(
        self,
        processor: Optional[ProcessorInput] = None,
        analyzer: Optional[Analyzer] = None,
        retriever: Retriever = None,
    ) -> Synthesizer:
        """
        Synthesizes a response based on the provided processor, analyzer, and retriever.

        Args:
            processor (Optional[ProcessorInput]): An object containing entity data.
            analyzer (Optional[Analyzer]): An optional analyzer object.
            retriever (Retriever): An object to retrieve API data.

        Returns:
            Synthesizer: An instance of Synthesizer containing the response and source description.
        """
        retriever_data = retriever.api_data
        df_cr = pd.DataFrame(retriever_data["CreditRatings"])
        df_rr = pd.DataFrame(retriever_data["RecoveryRatings"])
        df_ratings = pd.concat([df_cr, df_rr], axis=0).reset_index(drop=True)

        entities = processor.entities
        entity_name = entities["securities"][0]["primary_issuer"]

        template = leading_line(entities, entity_name)
        template = Get_translation_result(template, processor.original_language)

        df_tabular, has_valid_rows = create_security_history_table(df_ratings)
        count = df_tabular.shape[0]

        sourcing_base_url = config_machinery.get_config_value(Constants.SourceGeneration.BASE_URL)
        footnote_url_slug = config_machinery.get_config_value(Constants.SourceGeneration.FOOTNOTE_URL_SLUG)
        url = sourcing_base_url + footnote_url_slug + "#" + entities["securities"][0]["url"][0]
        source_url = source_description(entity_name, url)
        footnote = ""
        if count > NUM_ROWS_TO_DISPLAY:
            df_tabular = df_tabular.head(NUM_ROWS_TO_DISPLAY)
            footnote = f""" For more information about other available debt and rating types, please go to <a href="{url}" target="_blank">Security Details</a> page."""
            footnote = Get_translation_result(footnote, processor.original_language)

        template = template.result()
        if not isinstance(footnote, str):
            try:
                footnote = footnote.result()
            except AttributeError:
                raise TypeError("footnote must be a string or an object with a .result() method")

        response = []
        if has_valid_rows:
            response = full_response(
                template=template,
                data=df_tabular,
                data_type="table",
                count=count,
                footnote=footnote,
            )
        else:
            template = "Sorry, requested information is unavailable. Please try another question."
            template = Get_translation_result(template, processor.original_language)
            template = template.result()
            response = [text_response(template)]
        api_info = get_api_info(api_method=retriever.api_method, api_type=retriever.api_type, url=retriever.url)
        return Synthesizer(data_service_response=response, source_description=source_url, api_info=api_info)
