import pytest
from unittest.mock import patch, MagicMock

def pytest_sessionstart(session):
    # Mock PromptGenerator class to prevent initialization issues during import
    patcher_prompt_generator = patch(
        "chatrd.core.code_generation.prompt_generator.PromptGenerator"
    )
    mock_prompt_generator_class = patcher_prompt_generator.start()
    # Make the class return a MagicMock instance when instantiated
    mock_prompt_generator_class.return_value = MagicMock()

    # Patch get_service_token to return a fake token
    patcher_token = patch(
        "chatrd.engine.auth_api.AuthAPI.get_service_token",
        return_value="Bearer fake-token"
    )
    patcher_token.start()

    # Optional: patch _refresh_loop so background thread does nothing
    patcher_loop = patch(
        "chatrd.engine.auth_api.AuthAPI._refresh_loop",
        return_value=None
    )
    patcher_loop.start()

    # Optional: patch _refresh_token if tests somehow invoke it directly
    patcher_refresh = patch(
        "chatrd.engine.auth_api.AuthAPI._refresh_token",
        return_value="Bearer fake-token"
    )
    patcher_refresh.start()

def pytest_sessionfinish(session, exitstatus):
    from unittest.mock import patch
    patch.stopall()