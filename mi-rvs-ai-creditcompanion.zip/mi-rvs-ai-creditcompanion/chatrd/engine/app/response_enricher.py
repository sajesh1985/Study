import logging
from typing import List, Tuple

from chatrd.engine.app.source_extractor import DocumentTypes, MarkdownSourceExtractor

logger = logging.getLogger(__name__)


class ResponseEnricher:

    def __init__(self):
        super().__init__()
        self._source_extractor = MarkdownSourceExtractor()
        logger.debug(f"Base URL for links generation is set to: {self._source_extractor.base_url}")

    def extract_sources(self, source_docs: List[DocumentTypes]) -> List[str]:
        return self._source_extractor.extract(source_docs)

    def extract_categorized_sources(
        self,
        source_docs: List[DocumentTypes] = None,
        cited_docs: List[DocumentTypes] = None,
        unauthorized_docs: List[DocumentTypes] = None,
    ) -> Tuple[List[str], List[str], List[str]]:
        all_links = self._source_extractor.extract_categorized(
            source_docs=source_docs,
            cited_docs=cited_docs,
            unauthorized_docs=unauthorized_docs,
        )
        return tuple(all_links[category] for category in ["source_links", "cited_links", "unauthorized_links"])

    def get_docs_text_from_response(self, source_docs: List[DocumentTypes]) -> List[str]:
        only_docs_text = []
        source_docs = self._source_extractor.flatten_list(source_docs)

        for doc in source_docs:
            if "articleID" in doc.metadata:
                only_docs_text.append(doc.content)

        data_service_docs = []
        for doc in source_docs:
            if "response_payload" in doc.metadata:
                data_service_docs.append(doc)

        return only_docs_text, data_service_docs
