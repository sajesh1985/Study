import logging
from typing import Optional

from chatrd.core.thread_utils import submit_to_shared_thread_pool
from chatrd.engine.components.query_analyzer.translator.utils import (
    Get_translation_result,
)
from chatrd.engine.data_service.schema import (
    Analyzer,
    ProcessorInput,
    Retriever,
    Synthesizer,
)
from chatrd.engine.data_service.synthesizer.base import BaseSynthesizer
from chatrd.engine.data_service.synthesizer.peers.utils import (
    process_response_data_company,
    process_response_data_country,
    source_description,
)
from chatrd.engine.data_service.synthesizer.utils import (
    company_profile_url,
    full_response,
    get_api_info,
    text_response,
)

logger = logging.getLogger(__name__)


class AnalystPeerSynthesizer(BaseSynthesizer):
    def synthesize(
        self,
        processor: Optional[ProcessorInput] = None,
        analyzer: Optional[Analyzer] = None,
        retriever: Retriever = None,
    ) -> Synthesizer:
        """
        Synthesizes a response based on the provided processor, analyzer, and retriever.

        Args:
            processor (Optional[ProcessorInput]): An object containing entity data.
            analyzer (Optional[Analyzer]): An optional analyzer object.
            retriever (Retriever): An object to retrieve API data.

        Returns:
            Synthesizer: An instance of Synthesizer containing the response and source description.
        """
        company = processor.entities.get("companies", [{}])[0]  # Extract company information safely
        rd_subsector = company.get("subsector_code", "")
        entity_name = company.get("name", "")
        country_id = company.get("url", "").split("keycountry=")[-1]
        entity_id = str(company.get("mi_id", ""))
        extracted_name = company.get("extracted_name", "")

        # Choose the appropriate response processing function
        response_processor = process_response_data_country if rd_subsector == "SOV" else process_response_data_company
        response_data = response_processor(retriever.api_data)

        has_valid_rows = len(response_data) > 0
        source_url = []
        if has_valid_rows:
            source_url = source_description(rd_subsector, country_id, entity_id, entity_name)
            url = source_url[0][1]
            template = f"{entity_name} has the following Analyst Peers:"

            footnote = (
                f"For more information about other debt types and rating types, "
                f"please go to <a href='{url}' target='_blank'>Analyst Peers page</a>"
            )
            template = Get_translation_result(template, processor.original_language)
            footnote = Get_translation_result(footnote, processor.original_language)
            template = template.result()
            footnote = footnote.result()

            response = full_response(
                template=template, data=response_data, data_type="parentchild_table", footnote=footnote
            )
        else:
            url = company_profile_url(entity_id)
            template = (
                f"*CreditCompanion™ is unable to find peers for {extracted_name}. "
                f"Please see the Corporate Profile page <a href='{url}' target='_blank'>here</a> for more information.*"
            )
            template = Get_translation_result(template, processor.original_language)
            template = template.result()
            response = [text_response(template)]

        api_info = get_api_info(api_method=retriever.api_method, api_type=retriever.api_type, url=retriever.url)
        return Synthesizer(data_service_response=response, source_description=source_url, api_info=api_info)
