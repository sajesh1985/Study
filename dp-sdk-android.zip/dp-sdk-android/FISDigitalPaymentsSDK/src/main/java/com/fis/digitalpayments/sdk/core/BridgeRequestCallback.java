// Copyright Notice!
// This document is protected under the trade secret and copyright
// laws as the property of Fidelity National Information Services, Inc.
// Copying, reproduction or distribution should be limited and only to
// employees with a “need to know” to do their job.
// Any disclosure of this document to third parties is strictly prohibited.
// © 2016 Fidelity National Information Services.
// All rights reserved worldwide.


package com.fis.digitalpayments.sdk.core;

/**
 * Interface for receiving the response of a request.
 */
public interface BridgeRequestCallback {
    void onRequestComplete(BridgeResponse bridgeResponse);
}
