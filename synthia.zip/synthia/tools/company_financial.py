from datetime import datetime
from mcp.server.fastmcp import FastMCP, Context
from fastapi import FastAPI, APIRouter
from fastapi import Request
from fastapi import Depends
import logging
from . import auth
from contextlib import asynccontextmanager
import contextlib
from src.synthia.config.api_config import get_config
from src.synthia.utils.logging_config import configure_logging
from src.synthia.utils.source import Source
import urllib.parse
import httpx

# Define the mapping dictionary
metric_caption_map = {
    "CIQ000028": "Total Revenue",
    "CIQ004194": "Total Revenues, 1 Year Growth",
    "CIQ000010": "Gross Profit",
    "CIQ004074": "Gross Profit Margin",
    "CIQ004051": "EBITDA",
    "CIQ004047": "EBITDA Margin",
    "CIQ000400": "EBIT",
    "CIQ004053": "EBIT Margin",
    "CIQ000007": "Earnings from Cont. Ops.",
    "CIQ004181": "Earnings from Cont Ops Margin",
    "CIQ000015": "Net Income",
    "CIQ004094": "Net Income Margin",
    "CIQ000142": "Diluted EPS Excl. Extra Items",
    "CIQ004200": "Diluted EPS Before Extra, 1 Year Growth",
    "CIQ003195": "Owned/Operated Same Store Sales Growth",
    "CIQ000004": "EBT Excl Unusual Items",
    "CIQ004117": "EBT Excluding Non-Recurring Items Margin",
    "CIQ001007": "Total Assets",
    "CIQ004203": "Total Assets, 1 Year Growth",
    "CIQ003074": "Funds From Operations"
}

# Transform keystats_data by replacing metric code keys with captions
def translate_metric_keys(obj):
    if isinstance(obj, dict):
        return {metric_caption_map.get(k, k): translate_metric_keys(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [translate_metric_keys(item) for item in obj]
    else:
        return obj


# Configure logging
configure_logging(log_file='company_financial.log')
logger = logging.getLogger(__name__)

mcp: FastMCP = FastMCP("Company Financial MCP", stateless_http=True)

cfg = get_config()

logger.info("Financial MCP Server starting up...")
capitaliq_base_url = cfg["capitaliq_base_url"]
dataapi_url = cfg["dataapi_url"]
financial_url_infix = "AIReportBuilder/csdFinancials"

router = APIRouter()


# Create a single AsyncClient instance for reuse (performance optimization for Lambda)
async_client: httpx.AsyncClient = None

@mcp.tool()
async def get_company_CSD_financials(inst_id: str, metric_field: str = "",  period: str = "LFY") -> dict:
    """
    Fetch company financials Highlight sourced from CreditStats Direct for the given company.

    Args:
        inst_id (str): The Instn id/ MI Key/ KeyInstn to get financials for
        metric_field (str, optional): By Default field is optional empty string ("") return all data.
            DO NOT USE S&P CapitalIQ field here, Comma-separated list of metric fields for CreditStats Direct. 
            Each value must be a valid 'MetricName' as returned in this API response only.
            To discover available metric fields, first call this endpoint without specifying metric_field, 
            then use the 'MetricName' values from the response.
        period (str): Comma-separated list of periods. Each period should follow these patterns:
            - YEAR + 'Y' for annual (e.g., 2023Y)
            - YEAR + 'Q1', 'Q2', 'Q3', 'Q4' for quarters (e.g., 2024Q1)
            - YEAR + 'H1', 'H2' for semi-annual (e.g., 2023H1)
            - 'LTM' for Last Twelve Months
            - 'LFY' for Latest Fiscal Year
            - 'LYQ' for Latest Fiscal Quarter
            Example: "2023Y,2024Q1,2023H2,LFY,LYQ"
            This field is optional and can be left blank to use the default ("LFY").

    Returns:
        dict: A dictionary containing the financials Highlight sourced from CreditStats Direct for the given company
        example response:
         {
            "KeyInstn": "4000193",
            "MetricValue": "38943.53",
            "MetricName": "CIQ045233",
            "ProductCaption": "Debt, Adjusted",
            "Period": "2023Y ",
            "Magnitude": "$M",
            "KeyCurrency": "USD"
        }
        Field meanings:
        - KeyInstn: The Instn id/ MI Key/ KeyInstn for the company.
        - MetricValue: The value of the financial metric.
        - MetricName: The name of the financial metric. This is a unique identifier for the metric, such as "CIQ045233". Can be used to discover available metric fields.
        - ProductCaption: The caption of the financial Metric.
        - Period: The period for which the financial metric is reported.
        - Magnitude: The magnitude of the financial metric (e.g., $M for millions).
        - KeyCurrency: The currency code for the financial metric (e.g., USD).
    Note:
        Source for this data is CreditStats Direct.
        Only 'MetricName' values present in the API response are supported for 'metric_field'. DO not mix S&P CapitalIQ fields with CreditStats Direct fields.
    """
    logger.info(
        f"get_company_CSD_financials called for: {inst_id}, metric_field: {metric_field}, period: {period}")

    payload = {
        "KeyInstn": str(inst_id),
        "MetricField": metric_field,
        "Period": period
    }
    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    headers = raw_request.headers
    logger.info(f"Headers received: {headers}")
    logger.info(f"get_company_CSD_financials called for: {payload}")
    url = f"{capitaliq_base_url}{financial_url_infix}"
    try:
        global async_client
        response = await async_client.post(url,
                                 headers=auth.build_auth_headers(raw_request), json=payload)
        source = Source(title="Company CSD financials", url=url)
        if response.status_code == 200:
            financial_data = response.json()
            logger.info(f"Financial data returned: {len(financial_data)} records")
            return {"sources": source, "data" : financial_data }
        elif response.status_code == 204:
            logger.info(f"No financial data found for the given company: {inst_id}")
            return {"sources": source, "data": [{"message": "No financial data found for the given company."}] }
        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return {"error": f"{response.status_code} - {response.text}"}
    except httpx.RequestError as e:
        logger.error(f"Request failed: {e}")
        return {"error": f"Request failed: {e}"}



@mcp.tool()
async def get_company_CIQ_financials(
    instnId: str,
    FiscalPeriodGAAP: str = "Years",
    DataSourcePeriod: str = "",
    SortOrder: int = 0
) -> dict:
    """
    Fetch company financials KeyStats sourced from S&P CapitalIQ KeyStats Data for the given company.

    Args:
        instnId (str): The Instn id/ MI Key to get financials for (KeyInstn).
        FiscalPeriodGAAP (str): One of 'Years', 'Quarters', 'LTM', or 'Interim'. Default is 'Years'.
        DataSourcePeriod (str, optional): Comma-separated list of periods.
            - For 'Years': e.g., '2022Y,2023Y,2024Y'
            - For 'Quarters': e.g., '2024Q1,2024Q2,2024Q3,2024Q4'
            - For 'Interim': e.g., '2024H1,2024H2'
            - For 'LTM': e.g., '2024L1,2024L2,2024L3,2024L4'
            If not provided, defaults to last 3 years for 'Years'.
        SortOrder (int, optional): Sort order for the results. Default is 0.

    Returns:
        dict: A dictionary containing the KeyStats financials for the given company. Do not pass these field to CreditStats Direct source.
        Field meanings:
        - CIQ000028:	Total revenue of the company
        - CIQ004194:    Total Revenues, 1 Year Growth - Simple growth in total revenues over one year
        - CIQ000010:    Gross Profit - Total revenue excluding the cost of goods 
        - CIQ004074:    Gross Profit Margin - Gross profit as a percentage of total revenue
        - CIQ004051:    EBITDA - Earnings before interest, taxes, depreciation, and amortization
        - CIQ004047:    EBITDA Margin - EBITDA as a percentage of total revenue
        - CIQ000400:    EBIT - Earnings before interest and taxes
        - CIQ004053:    EBIT Margin - Percent of earnings before interest and taxes to total revenues
        - CIQ000007:    Earnings from Cont. Ops. - Earnings from continuing operations including all items of non-recurring nature before provision for income tax
        - CIQ004181:    Earnings from Cont Ops Margin - Percent of earnings from continuing operations to total revenues
        - CIQ000015:    Net Income - Net income before preferred dividends after adjusting for extraordinary items and accounting changes
        - CIQ004094:    Net Income Margin - Net income as a percent of operating revenue
        - CIQ000142:    Diluted EPS Excl. Extra Items - Diluted earnings per share before adjusting for preferred stock dividends and other adjustments.
        - CIQ004200:    Diluted EPS Before Extra, 1 Year Growth - Simple growth in diluted earnings per share (EPS) before extraordinary items over one year
        - CIQ003195:    Owned/Operated Same Store Sales Growth - Percent growth in sales per owned comparable store over previous year
        - CIQ000004:    EBT Excl Unusual Items - Earnings of the company excluding all items of non-recurring nature before provision for income tax
        - CIQ004117:    EBT Excluding Non-Recurring Items Margin - Profit before taxes but after non-recurring Items divided by total revenues
        - CIQ001007:    Total Assets - All assets (current and long-term) as of the date indicated, as carried on the balance sheet
        - CIQ004203:    Total Assets, 1 Year Growth - Simple growth in total assets over one year
        - CIQ003074:    Funds From Operations - Funds from operations for real estate investment trust (REIT) companies.
        - FiscalPeriodGAAP: Fiscal Period - Together with the KeyInstn and the restatement basis, completes the unique key used to identify a financial period on a fiscal basis. Concatenation of the FiscalYear and FiscalQuarter values.
        - KeyCurrency: Currency Code - Alphabetic code used to identify currencies pursuant to ISO-4217
    
    Note:
        Source for this data is S&P CapitalIQ KeyStats Data.
    """
    logger.info(
        f"get_company_CIQ_financials called for: {instnId}, FiscalPeriodGAAP: {FiscalPeriodGAAP}, DataSourcePeriod: {DataSourcePeriod}, SortOrder: {SortOrder}"
    )

    # Set default DataSourcePeriod if not provided or empty
    if not DataSourcePeriod:
        if FiscalPeriodGAAP == "Years":
            # Default: last 3 years
            this_year = datetime.now().year
            DataSourcePeriod = ",".join([f"{this_year-i}Y" for i in range(2, -1, -1)])
        elif FiscalPeriodGAAP == "Quarters":
            # Default: current year, all quarters
            this_year = datetime.now().year
            DataSourcePeriod = ",".join([f"{this_year}Q{q}" for q in range(1, 5)])
        elif FiscalPeriodGAAP == "Interim":
            # Default: current year, both halves
            this_year = datetime.now().year
            DataSourcePeriod = f"{this_year}H1,{this_year}H2"
        elif FiscalPeriodGAAP == "LTM":
            # Default: current year, 4 LTM periods
            this_year = datetime.now().year
            DataSourcePeriod = ",".join([f"{this_year}L{i}" for i in range(1, 5)])
        else:
            DataSourcePeriod = ""

    # Prepare URL
    base_url = url = f"{dataapi_url}v2/Hydrobs/GetKeyStatsData"
    params = {
        "KeyInstn": instnId,
        "FiscalPeriodGAAP": f"'{FiscalPeriodGAAP}'",
        "DataSourcePeriod": DataSourcePeriod,
        "SortOrder": SortOrder
    }
    url = f"{base_url}?{urllib.parse.urlencode(params)}"

    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    headers = raw_request.headers
    logger.info(f"Headers received: {headers}")
    logger.info(f"get_company_CIQ_financials GET url: {url}")

    try:
        global async_client
        response = await async_client.get(url, headers=auth.build_auth_headers(raw_request))
        if response.status_code == 200:
            keystats_data = response.json()

            logger.info(f"KeyStats data returned: {len(keystats_data) if hasattr(keystats_data, '__len__') else 'unknown'} records")
            translated_data = translate_metric_keys(keystats_data)
            source = Source(title="Company CIQ financials", url=url)
            return {"sources": source, "data": translated_data}
        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return {"error": f"{response.status_code} - {response.text}"}
    except httpx.RequestError as e:
        logger.error(f"Request failed: {e}")
        return {"error": f"Request failed: {e}"}


# Define a custom lifespan for FastAPI with a task to manage MCP


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Initializing MCP server task group...")
    global async_client
    async_client = httpx.AsyncClient(timeout=10)
    async with contextlib.AsyncExitStack() as stack:
        await stack.enter_async_context(mcp.session_manager.run())
        yield
    await async_client.aclose()

@router.get("/financials/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "ok"}


# Create FastAPI app with lifespan
app = FastAPI(lifespan=lifespan)
app.mount("/financials", mcp.streamable_http_app())
app.include_router(router)
logger.info("Financial MCP Server started successfully.")