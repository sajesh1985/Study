import pytest

from chatrd.core.llm.components.providers import (
    LLMInputOption,
    ProviderDetails,
    ProviderMapping,
)


class TestLLMInputOption:

    @pytest.mark.parametrize(
        "value, expected_result",
        [
            ("max_tokens", True),
            ("stop_sequences", True),
            ("MAX_TOKENS", False),
            ("unknown", False),
        ],
    )
    def test_has_value(self, value, expected_result):
        assert expected_result == LLMInputOption.has_value(value)

    @pytest.mark.parametrize(
        "key, expected_result",
        [
            ("MAX_TOKENS", True),
            ("STOP", True),
            ("max_tokens", False),
            ("unknown", False),
        ],
    )
    def test_has_key(self, key, expected_result):
        assert expected_result == LLMInputOption.has_key(key)

    @pytest.mark.parametrize(
        "value, expected_result",
        [
            ("max_tokens", LLMInputOption.MAX_TOKENS),
            ("stop_sequences", LLMInputOption.STOP),
            ("unknown", None),
        ],
    )
    def test_parse(self, value, expected_result):
        assert expected_result == LLMInputOption.parse(value)


class TestProviderDetails:

    @pytest.fixture
    def test_provider(self):
        return ProviderDetails(
            input_key="input_key",
            output_key="output_key",
            input_config_key="input_config_key",
            custom_input_configuration={LLMInputOption.MAX_TOKENS: "maxTokens", LLMInputOption.STOP: "stop"},
        )

    def test_getting_details(self, test_provider):
        assert test_provider.input_key == "input_key"
        assert test_provider.output_key == "output_key"
        assert test_provider.input_config_key == "input_config_key"
        assert isinstance(test_provider.custom_input_configuration, dict)
        assert "maxTokens" == test_provider.custom_input_configuration[LLMInputOption.MAX_TOKENS]
        assert "stop" == test_provider.custom_input_configuration[LLMInputOption.STOP]

    def test_get_input_config_name(self, test_provider):
        assert test_provider.get_input_config_name(LLMInputOption.MAX_TOKENS) == "maxTokens"
        assert test_provider.get_input_config_name("maxTokens") == "maxTokens"
        assert test_provider.get_input_config_name(LLMInputOption.STOP) == "stop"
        assert test_provider.get_input_config_name("stop") == "stop"
        assert test_provider.get_input_config_name("unknown") == "unknown"


class TestProviderMapping:
    PROVIDERS = [
        "ai21",
        "ai21_llm",
        "anthropic",
        "amazon",
        "bedrock",
        "claude",
        "cohere",
        "cohere_llm",
        "llama",
        "meta",
        "mistral",
    ]
    HUMAN_PROMPT_PROVIDERS = ["anthropic", "claude"]

    @pytest.mark.parametrize(
        "provider_str, expected_mapping",
        [
            ("AI21", ProviderMapping.AI21),
            ("AI21-LLM", ProviderMapping.AI21_LLM),
            ("anthropic", ProviderMapping.ANTHROPIC),
            ("amazon", ProviderMapping.AMAZON),
            ("bedrock", ProviderMapping.BEDROCK),
            ("BEDROCK", ProviderMapping.BEDROCK),
            ("claude", ProviderMapping.CLAUDE),
            ("cohere", ProviderMapping.COHERE),
            ("cohere_llm", ProviderMapping.COHERE_LLM),
            ("COHERE-LLM", ProviderMapping.COHERE_LLM),
            ("llama", ProviderMapping.LLAMA),
            ("meta", ProviderMapping.META),
            ("mistral", ProviderMapping.MISTRAL),
        ],
    )
    def test_parse(self, provider_str, expected_mapping):
        assert ProviderMapping.parse(provider_str) == expected_mapping

    @pytest.mark.parametrize(
        "provider_str",
        [*PROVIDERS],
    )
    def test_getting_role_format(self, provider_str):
        user_prompt = "\n\nHuman:" if provider_str in self.HUMAN_PROMPT_PROVIDERS else "\n\nUser:"
        provider = ProviderMapping.parse(provider_str)

        assert provider.get_role_format("system") == "\n\nSystem:"
        assert provider.get_role_format("user") == user_prompt
        assert provider.get_role_format("assistant") == "\n\nAssistant:"
