import logging
from typing import Optional

import pandas as pd

from chatrd.core.thread_utils import submit_to_shared_thread_pool
from chatrd.engine.components.query_analyzer.translator.utils import (
    Get_translation_result,
)
from chatrd.engine.data_service.schema import (
    Analyzer,
    ProcessorInput,
    Retriever,
    Synthesizer,
)
from chatrd.engine.data_service.synthesizer.base import BaseSynthesizer
from chatrd.engine.data_service.synthesizer.utils import (
    company_profile_url,
    create_uspf_ratings_table,
    full_response,
    get_api_info,
    make_source_description,
)

logger = logging.getLogger(__name__)


def source_description(entity_name, entity_id):
    sep = "| "
    info = "Government Institution"
    sources = make_source_description(entity_name, entity_id, sep, info, company_profile_url)

    return sources


def leading_line(
    entity_name,
    df,
) -> str:
    if "Revenue Source Rating".lower() in df["RT_RATINGS_ASID_NAME"][0].lower():
        revenue_name = "Revenue Source Rating"
        name = df["RT_DESCRIPTION"][0]
        template = f"""The {entity_name} has the following {revenue_name} ({name}):"""
    else:
        revenue_name = df["RT_RATINGS_ASID_NAME"][0]
        template = f"""The {entity_name} has the following {revenue_name}:"""

    return template


class USPFSynthesizer(BaseSynthesizer):
    def synthesize(
        self,
        processor: ProcessorInput = None,
        analyzer: Optional[Analyzer] = None,
        retriever: Retriever = None,
    ) -> Synthesizer:
        # Read Arguments
        df = pd.DataFrame(retriever.api_data["EntityRatingSnapshot"])
        entities = processor.entities
        entity_name = entities["companies"][0]["name"]
        entity_id = str(entities["companies"][0]["mi_id"])
        count = len(df)

        template = leading_line(entity_name, df)
        template = Get_translation_result(template, processor.original_language)
        template = template.result()

        df_tabular, has_valid_rows = create_uspf_ratings_table(df)
        response = []
        if has_valid_rows:
            response = full_response(
                template=template,
                data=df_tabular,
                data_type="table",
                count=count,
            )
        source_url = source_description(entity_name, entity_id)

        api_info = get_api_info(api_method=retriever.api_method, api_type=retriever.api_type, url=retriever.url)
        return Synthesizer(data_service_response=response, source_description=source_url, api_info=api_info)
