"""Schema definitions for section structures in reports."""

from typing import List, Optional
from pydantic import BaseModel, Field


class Subsection(BaseModel):
    """Schema for a subsection within a section."""
    
    title: str = Field(..., description="Title of the subsection")
    description:  Optional[str] = Field(..., description="Description of the subsection")
    content: str = Field(..., description="Content of the subsection")
    
    class Config:
        """Configuration for Subsection model."""
        json_schema_extra = {
            "example": {
                "title": "Important Concepts",
                "content": "This subsection explains several key concepts..."
            }
        }


class Section(BaseModel):
    """Model for report sections"""
    
    name: str = Field(description="Name for this section of the report.")
    description: str = Field(description="Content of the section.")
    tools: Optional[List[str]] = Field(default_factory=list, description="Tools used in this section.")
    sources: Optional[List[str]] = Field(default_factory=list, description="Sources used in this section.")
    image: Optional[str] = Field(default=None, description="Image associated with this section.")

        
    class Config:
        """Configuration for Section model."""
        json_schema_extra = {
            "example": {
                "name": "Introduction",
                "description": "This section introduces the topic...",
            }
        }


class Sections(BaseModel):
    """Schema for a collection of sections that make up a report."""
    
    sections: List[Section] = Field(..., description="List of sections in the report")
    
    class Config:
        """Configuration for Sections model."""
        json_schema_extra = {
            "example": {
                "sections": [
                    {
                        "title": "Introduction",
                        "content": "This section introduces the topic...",
                    },
                    {
                        "title": "Methodology",
                        "content": "This section describes the methodology...",
                    }
                ]
            }
        }