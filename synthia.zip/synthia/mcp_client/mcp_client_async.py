import asyncio
import logging
import time
from typing import Dict, Any, Optional

from dotenv import load_dotenv
from langchain_mcp_adapters.client import MultiServerMCPClient

from src.synthia.config.api_config import get_config
from src.synthia.utils.logging_config import configure_logging

# Initialize logger using centralized configuration
logger = configure_logging(
    logger_name=__name__,
    log_file="synthia.log",
    module_levels={__name__: logging.DEBUG},  # Set this module to DEBUG
)

load_dotenv(override=True)

logger = logging.getLogger(__name__)

# Simple async cache for create_report_agent_client
_cached_report_agent_client = None
_cached_report_agent_client_time = 0
_CACHE_TTL_SECONDS = 60 * 60 * 1  # Cache for 1 hour


async def ping_mcp_server(urls, timeout=6.0):
    """
    Async ping one or more MCP server APIs using HTTP POST in parallel.
    Accepts a single URL or a list of URLs.
    Returns a dict: {url: response}
    """
    import httpx
    import asyncio

    if isinstance(urls, str):
        urls = [urls]

    payload = {"jsonrpc": "2.0", "id": "1", "method": "ping"}
    request_headers = {"Accept": "application/json, text/event-stream"}

    async def ping_api(url):
        async with httpx.AsyncClient() as client:
            try:
                response = await client.post(
                    url, json=payload, headers=request_headers, timeout=timeout
                )
                return url, response
            except Exception as e:
                return url, e

    tasks = [ping_api(url) for url in urls]
    results = await asyncio.gather(*tasks)
    return dict(results)


async def _ping_server_with_retries(server_name, config, logger):
    """
    Helper async function to ping a server with retries.
    Returns (server_name, server_config or None, is_critical_missing)
    """
    import asyncio

    url = config["url"]
    is_required = config.get("required", False)
    server_config = {
        "url": url,
        "transport": config["transport"],
    }
    max_retries = 3
    retry_delay = 1.0  # seconds

    for attempt in range(max_retries):
        try:
            responses = await ping_mcp_server(url)
            response = responses[url]

            # Check if response is an exception (from ping_mcp_server)
            if isinstance(response, Exception):
                raise response

            if response.status_code == 200 or response.status_code == 307:
                logger.info(f"MCP server {server_name} is available at {url}")
                return (server_name, server_config, False)
            else:
                logger.warning(
                    f"MCP server {server_name} returned status {response.status_code} (attempt {attempt + 1}/{max_retries}) at {url}"
                )
        except Exception as e:
            logger.warning(
                f"MCP server {server_name} is unavailable: {str(e)} (attempt {attempt + 1}/{max_retries}) at {url}"
            )

        # Only sleep and retry if this isn't the last attempt
        if attempt < max_retries - 1:
            await asyncio.sleep(retry_delay)
            retry_delay *= 1.5

    # All retries failed
    if is_required:
        return (server_name, None, True)
    return (server_name, None, False)


async def create_mcp_client(auth_token: Optional[str] = None):
    available_servers = await get_mcp_servers_list()
    for server in available_servers:
        available_servers[server]["headers"] = {"Authorization": f"{auth_token}"}

    return MultiServerMCPClient(available_servers)


def get_mcp_servers() -> Dict[str, Dict[str, Any]]:
    """Get MCP servers from config."""
    config = get_config(parameter_name="llm-config")
    mcp_servers = config.get("mcp_servers", {})
    if not mcp_servers:
        logger.error("No MCP servers configured in 'mcp_servers'")
        raise ValueError("No MCP servers configured in 'mcp_servers'")
    return mcp_servers


async def get_mcp_servers_list():
    """Async: Create MCP client with available servers, skipping unavailable ones. Pings in parallel."""

    global _cached_report_agent_client, _cached_report_agent_client_time

    now = time.time()
    if (
            _cached_report_agent_client is not None
            and (now - _cached_report_agent_client_time) < _CACHE_TTL_SECONDS
    ):
        logger.debug("Returning cached MCP client server list")
        return _cached_report_agent_client

    logger.info(f"Creating MCP client")
    mcp_servers = get_mcp_servers()
    available_servers = {}
    critical_servers_missing = []

    servers_to_check = [
        (server_name, config) for server_name, config in mcp_servers.items()
    ]

    tasks = [
        _ping_server_with_retries(server_name, config, logger)
        for server_name, config in servers_to_check
    ]
    if tasks:
        results = await asyncio.gather(*tasks)
        for name, server_config, is_critical_missing in results:
            if server_config:
                available_servers[name] = server_config
            if is_critical_missing:
                critical_servers_missing.append(name)

    if critical_servers_missing:
        logger.error(
            f"Critical MCP servers unavailable: {', '.join(critical_servers_missing)}"
        )
        for server_name in critical_servers_missing:
            available_servers[server_name] = {
                "url": mcp_servers[server_name]["url"],
                "transport": mcp_servers[server_name]["transport"],
            }

    logger.info(
        f"Creating MultiServerMCPClient with {len(available_servers)} available servers"
    )
    _cached_report_agent_client = available_servers
    _cached_report_agent_client_time = now
    return available_servers
