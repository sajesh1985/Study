import logging
from typing import Optional

from pydantic import BaseModel

from chatrd.core.llm import LCLLMFactory
from chatrd.core.llm.parsers import PydanticOutputParser
from chatrd.core.llm.prompt.template import SimplePromptTemplate
from chatrd.engine.components.query_analyzer.filter_retrievers.prompts import (
    QuestionIntentClass,
    TimeOutputDates,
)
from chatrd.engine.components.query_analyzer.time_rephraser.prompts import (
    TIME_REPHRASER_EXAMPLES,
    TIME_REPHRASER_PROMPT,
)

logger = logging.getLogger(__name__)


class RephrasedQuestion(BaseModel):
    rephrased_question: Optional[str] = ""


class QuestionRephraser:
    def __init__(self, model_name: str, temperature: Optional[float] = 0.0):
        self.model = LCLLMFactory().get_llm(
            deployment_name_or_model_id=model_name,
            temperature=temperature,
        )
        self.output_parser = PydanticOutputParser(pydantic_object=RephrasedQuestion)
        self.prompt_template = SimplePromptTemplate(
            template=TIME_REPHRASER_PROMPT,
            partial_variables={"examples": TIME_REPHRASER_EXAMPLES},
        )

    def rephrase(self, extracted_dates: TimeOutputDates, question: str) -> str:
        if extracted_dates.Question_Intent not in [
            QuestionIntentClass.UNSPECIFIED,
            QuestionIntentClass.INCLUDES_TODAY,
        ]:
            question_prompt = self.prompt_template.format(question=question)
            output = self.model.invoke(question_prompt)
            result = self.output_parser.invoke(output)
            rephrased_question = result.rephrased_question or question
            logger.info(f"Overwriting the rephrased question with time-rephrased question : {rephrased_question}")
        else:
            rephrased_question = question
        return rephrased_question
