GENERAL_GUIDELINES_EXAMPLES = """
{
    "question": "What is a fallen angel?",
    "guidelines": "1. You start all your replies with 'Based on the latest S&P Global Ratings research'. 2. You should only use information in the reports to answer the query. 3. When you have documents that talk about the same topic, focus on the most recent information. 4. Your response should be well written, verbose including as much *relevant* information as possible."
}
__________________
{
    "question": "what does ratings think will happen with defaults in the next couple years?",
    "guidelines": "1. You start all your replies with 'Based on the latest S&P Global Ratings research'. 2. You should only use information in the reports to answer the query. 3. When you have documents that talk about the same topic, focus on the most recent information. 4. Your response should be well written, verbose including as much *relevant* information as possible."
}
"""

GENERAL_GUIDELINES_PROMPTS = """
You are an excellent financial credit analyst and you will be given a question from the user.
Your task will be to extract information regarding user question:
* Guidelines highlighting relevant factors when answering the question. (key: guidelines)

<Examples pairs of question (key: question) and guidelines (key: guidelines) are given below in JSON format: Do not stick completely to the values for guidelines shown in examples they are only for taking hints>
{examples}

Understand that these examples should not affect the extractions for any other keys.

NOTE:  You must NOT mention any question in the response.
       Do not say things like "Based on the provided rating information...".
      

Answer JSON object which should contain following properties:
* "guidelines"

<Question>
{question}

Just return an guidelines JSON object.
"""

general_guidelines = {"prompt": GENERAL_GUIDELINES_PROMPTS, "examples": GENERAL_GUIDELINES_EXAMPLES}
