from pydantic import BaseModel


class GeographyDecisionOutput(BaseModel):
    geography: bool


GEOGRAPHY_EXTRACTOR_EXAMPLES = """
<example>
{
    "question" : "Research and latest updates on India",
    "answer": {
        "geography": true
    }
}
</example>
<example>
{
    "question" : "What's the outlook for Bank of Australia?",
    "answer": {
        "geography": false
    }
}
</example>
<example>
    {“question” : “what did Canadian speculative graded companies pay for loans in 2024?",
    “answer” : {
        “geography” : true
    }
}
</example>
<example>
    {“question” : “what are the key priorities of the new indonesian government?”,
    “answer” : {
        “geography” : true
    }
}
</example>
<example>
    {“question” : “How does the US tariff change effect to Korean Economy?”,
    “answer” : {
        “geography” :  true
}
}
</example>
<example>
    {“question” : “How does the US tariff change effect to metal industry?”,
    “answer” : {
        “geography” :  false
    }
}
</example>
<example>
    {“question” : “What is the latest research on north american banks?",
    “answer” : {
        “geography” :  true
    }
}
</example>
<example>
    {“question” : “What is the latest research on bank of america and ratings of British Petroleum?”,
    “answer” : {
        “geography” :  false
    }
}
</example>
<example>
    {“question” : “Please conduct a country issuer credit risk assessment on the United States”,
    “answer” : {
        “geography” : true
    }
}
</example> 
<example>
    {“question” : “What are the recent rating downgrades for Air France?”,
    “answer” : {
        “geography” :  false
    }
}
</example>
<example>
    {“question” : “What are the outlook for Singapore Airlines?”,
    “answer” : {
        “geography” :  false
    }
}
</example>
<example>
    {“question” : “what are the fiscal risks in Japan”,
    “answer” : {
        “geography” : true
    }
}
</example>
<example>
    {“question” : “give me industry trends in Eurozone and research on Volkswagen”,
    “answer” : {
        “geography” :  true
    }
}
</example>
<example>
    {“question” : “what is the reserve to surplus ratio for US life reinsurers”,
    “answer” : {
        “geography” :  true
    }
}
</example>
<example>
    {“question” : “what is main financial institutions in EU and give me ratings of Siemens, Philips and Bosch”,
    “answer” : {
        “geography” :  true
    }
}
</example>




"""

GEOGRAPHY_EXTRACTOR_PROMPT_TEMPLATE = """
You are an excellent financial credit analyst, and you will be given a question from the user. 
Your task will be to extract information regarding the user's question: Does the query include geographic reference?

<instructions>
When processing client queries, determine if the query include geographic reference (countries , continents or part of continents) and return true or false.
</instructions>
Rules for identification:
1. Identify ONLY countries and continents from the query.
2. Treat regional abbreviations as countries or continents:
   - US, USA → United States (country) 
   - EU → European Union (treat as region/multi-country entity)
   - UK → United Kingdom (country)
   - UAE → United Arab Emirates (country)
   - Similar common regional abbreviations

3. DO NOT extract:
   - Cities
   - States/provinces
   - Specific locations or landmarks
   - Organizations or companies
   To be exact: States like Alaska, California, New Mexico don't identify as geography, this are states so don't make mistake. 
   E.G.:
   - Query: "Latest updates on Alaska"
   - Output: false (query asks for updates in Alaska, which is a US state and should not be extracted; output must be false)
   - Query: "research forecast for California"
   - Output: false (query asks about California, which is a state, not a country or continent, so output is false)
   
4. Output:
Return true if:
- The query's PRIMARY focus is on countries , continents or part of continents.
- The query asks about BOTH geographical regions AND specific entities (companies, industries, etc.) together.
- The query asks about general entities in a specific region.
Return false if:
- The query focuses ONLY on specific entities (companies, industries, sectors, organizations) WITHOUT geographical context.
- The query does not mention or require information about countries or continents.

Examples:
- Query: "Show me sales data for US, Germany, and Tokyo"
  Output: true (query asks about US and Germany, which are countries)
- Query: "Compare EU and Asia Pacific markets"
  Output: true (query asks about markets of EU and Asia, EU and Asia both are continents)
- Query: "Offices in California and Sydney"
  Output: false (query asks about California and Sydney, California is a state and Sydney is a city)
- Query: "What is the population of New York?"
  Output: false (query asks about New York which is a city/state)
- Query: "How does the US tariff change affect the Korean economy?"
  Output: true (query asks about Korean economy, Korea is a country)
- Query: "What are the recent rating downgrades for Air France?"
  Output: false (query asks about Air France which is a company)

5. EXCEPTION: 
- Please pay attention to examples which contain "US tariff". It's not country-oriented; 
  the main subject here is "tariff" not "US", so in this case if another country or continent is not mentioned, output is false!
- Query: "How does the US tariff change affect the Korean economy?"
- Output: true (query asks about US tariff effect but in a specific country (here Korea), that's why output is true)
- Query: "How does the US tariff change affect the metal industry?"
- Output: false (query asks about US tariff effect but only on a particular industry, not on some country or continent, so output is false)
- Query: "How does the EU regulation affect the Russian economy?"
- Output: true (query asks about regulation effect on a particular country (Russia))
- Query: "How does the EU regulation affect the oil industry?"
- Output: false (query asks about regulation effect on a specific industry only (no country or continent is mentioned here), so output is false)

Example pairs of question (key: question) and answer (key: answer) are given below in JSON format. Do not stick completely to the answer values shown in examples, they are only for taking hints. xyz, abc, 123, mm/dd/yyyy, and other similar terms in examples are placeholders for entity names.
<examples>
{examples}
</examples>

<output_format>
The output JSON object must contain the following property: "geography"
</output_format>

<question>
{question}
</question>

Just return an output JSON object with geography value as true or false.
"""
