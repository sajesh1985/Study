import logging
from typing import Optional

from chatrd.core.thread_utils import submit_to_shared_thread_pool
from chatrd.engine.components.query_analyzer.translator.utils import (
    Get_translation_result,
)
from chatrd.engine.data_service.schema import (
    Analyzer,
    ProcessorInput,
    Retriever,
    Synthesizer,
)
from chatrd.engine.data_service.synthesizer.base import BaseSynthesizer
from chatrd.engine.data_service.synthesizer.rating_action.utils import (
    create_rating_action_table,
    source_description,
    template_leading_line,
)
from chatrd.engine.data_service.synthesizer.utils import (
    full_response,
    get_api_info,
    rating_history_url,
    text_response,
)

logger = logging.getLogger(__name__)


class RatingActionSynthesizer(BaseSynthesizer):
    def synthesize(
        self,
        processor: Optional[ProcessorInput] = None,
        analyzer: Optional[Analyzer] = None,
        retriever: Retriever = None,
    ) -> Synthesizer:
        """
        Synthesizes a response based on the provided processor, analyzer, and retriever.

        Args:
            processor (Optional[ProcessorInput]): An object containing entity data.
            analyzer (Optional[Analyzer]): An optional analyzer object.
            retriever (Retriever): An object to retrieve API data.

        Returns:
            Synthesizer: An instance of Synthesizer containing the response and source description.
        """
        entities = processor.entities
        entity_name = entities["companies"][0]["name"]
        entity_id = str(entities["companies"][0]["mi_id"])
        url = entities["companies"][0]["url"]
        filters = analyzer.response
        action_type = filters.get("MoveDirection", None)

        df_rating_action, has_valid_rows = create_rating_action_table(retriever.api_data, filters)
        count = df_rating_action.shape[0]

        if (len(entities["companies"]) > 0) & (
            entities["companies"][0]["type"] in ["Public Company", "Private Company"]
        ):
            private_company_bool = True
        else:
            private_company_bool = False
        template = template_leading_line(has_valid_rows, action_type, entity_name, entity_id, url, private_company_bool)

        FOOTNOTE_TEMPLATE = "For more information, please go to "
        footnote = (
            FOOTNOTE_TEMPLATE
            + f"""<a href="{rating_history_url(entity_id)}" target="_blank">{entity_name} | Ratings & History</a>"""
        )
        template = Get_translation_result(template, processor.original_language)
        footnote = Get_translation_result(footnote, processor.original_language)
        template = template.result()
        footnote = footnote.result()

        response = []
        if has_valid_rows:
            response = full_response(
                template=template,
                data=df_rating_action,
                data_type="table",
                count=count,
                footnote=footnote,
            )
        else:
            response = [text_response(template=template)]
        source_url = source_description(entity_name, entity_id)
        api_info = get_api_info(api_method=retriever.api_method, api_type=retriever.api_type, url=retriever.url)
        return Synthesizer(data_service_response=response, source_description=source_url, api_info=api_info)
