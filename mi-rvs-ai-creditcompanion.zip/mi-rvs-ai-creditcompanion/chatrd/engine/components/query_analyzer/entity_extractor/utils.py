import json
import logging
import re
from concurrent.futures import as_completed
from copy import deepcopy
from enum import Enum
from typing import List, Optional, Tuple

import Levenshtein
from pydantic import BaseModel

from chatrd.core.thread_utils import submit_to_shared_thread_pool
from chatrd.core.utils import safe_get
from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.ratings_api import RatingsAPI
from chatrd.engine.search_api import SearchAPI
from chatrd.engine.utils import make_unique

config_machinery = get_config_machinery()


logger = logging.getLogger(__name__)

CUSIP_PATTERN = re.compile(r"\b[a-zA-Z0-9]{5}[a-zA-Z0-9*@#]{3}[0-9]\b")
ISIN_PATTERN = re.compile(r"\b[a-zA-Z]{2}[a-zA-Z0-9]{9}[0-9]{1}\b")


class Entity(BaseModel):
    def get_identifier(self) -> Optional[str]:
        """Method to be overridden in subclasses."""
        raise NotImplementedError("Subclasses must implement this method.")

    def __eq__(self, other):
        if not isinstance(other, Entity):
            return NotImplemented
        return self.get_identifier() == other.get_identifier()

    def __hash__(self):
        return hash(self.get_identifier())


class ExtractedSecurities(BaseModel):
    cusip: Optional[List[str]] = []
    isin: Optional[List[str]] = []


class ExtractedEntities(BaseModel):
    entities: Optional[List[str]] = []


class SecurityType(Enum):
    ISIN = "isin"
    CUSIP = "cusip"


class Companies(Entity):
    name: Optional[str] = None
    extracted_name: Optional[str] = None
    type: Optional[str] = None
    is_rd_entity: bool
    mi_id: Optional[int] = None
    id: Optional[str] = None
    base_url: Optional[str] = None
    rating_entity_id: Optional[str] = None
    subsector_code: Optional[str] = None
    url: Optional[str] = None
    rd_sector: Optional[List[str]] = None
    rd_subsector: Optional[List[str]] = None
    rd_industry: Optional[List[str]] = None

    def get_identifier(self) -> Optional[str]:
        return self.mi_id


class RevenueSource(Entity):
    name: str = None
    extracted_name: Optional[str] = None
    asid: int = None
    is_rd_entity: bool
    type: str = None
    url: Optional[str] = None
    base_url: Optional[str] = None
    obligor: Optional[List[str]] = None
    issuer: Optional[List[str]] = None
    issuer_url: Optional[List[str]] = None

    def get_identifier(self) -> Optional[str]:
        return self.asid


class Securities(Entity):
    id: Optional[int] = None
    extracted_name: Optional[str] = None
    is_rd_entity: bool
    value_type: Optional[str] = None
    type: Optional[str] = None
    cusip: Optional[List[str]] = None
    isin: Optional[str] = None
    description: Optional[str] = None
    url: Optional[List[str]] = None
    base_url: Optional[str] = None
    issuer: Optional[List[str]] = None
    issuer_keyinstn: Optional[str] = None
    primary_issuer: Optional[str] = None
    security_sector: Optional[List[int]] = None

    def get_identifier(self) -> Optional[str]:
        if self.isin:
            return self.isin
        elif self.cusip:
            return self.cusip
        else:
            return self.id


class Entities(BaseModel):
    companies: Optional[List[Companies]] = []
    securities: Optional[List[Securities]] = []
    revenue_sources: Optional[List[RevenueSource]] = []


def extract_cusip(string: str) -> List[str]:
    patterns = CUSIP_PATTERN.findall(string)
    return patterns


def extract_isin(string: str) -> List[str]:
    patterns = ISIN_PATTERN.findall(string)
    return patterns


def convert_list_type_string_to_list(input: str) -> List[str]:
    json_string = input.replace("[", '["').replace("]", '"]').replace(", ", '", "')
    try:
        return json.loads(json_string)
    except json.JSONDecodeError as e:
        logger.error(f"JSON decoding error: {e}")
        return []


def post_process(entities: ExtractedEntities, securities: ExtractedSecurities) -> ExtractedEntities:
    updated_entities = deepcopy(entities.entities)
    if entities.entities and ((securities.isin or securities.cusip)):
        for entity in entities.entities:
            for cusip in securities.cusip:
                if cusip in entity:
                    updated_entities.remove(entity)
            for isin in securities.isin:
                if isin in entity:
                    updated_entities.remove(entity)

        entities.entities = updated_entities
    return entities


def find_closest_string_index(query, string_list):
    closest_index = -1
    min_distance = float("inf")

    for index, string in enumerate(string_list):
        distance = Levenshtein.distance(query, string)
        if distance < min_distance:
            min_distance = distance
            closest_index = index

    return closest_index


def process_entity_context(entity_context, url, query_entity, tagged_status=False) -> Entities:
    companies, revenue_sources, securities = [], [], []

    if "CompanyContext" in entity_context:
        rd_sector, rd_subsector, rd_industry = None, None, None
        if rd_sector_str := safe_get(entity_context, ["CompanyContext", "rd_sector"]):
            rd_sector = convert_list_type_string_to_list(rd_sector_str)
        if rd_subsector_str := safe_get(entity_context, ["CompanyContext", "rd_subsector"]):
            rd_subsector = convert_list_type_string_to_list(rd_subsector_str)
        if rd_industry_str := safe_get(entity_context, ["CompanyContext", "rd_industry"]):
            rd_industry = convert_list_type_string_to_list(rd_industry_str)
        # callto companyinfo api
        company_info_response_from_ratings_api, _, _ = RatingsAPI().get_company_info(
            safe_get(entity_context, ["CompanyContext", "keyinstn"])
        )
        name = safe_get(entity_context, ["CompanyContext", "name"])
        companies.append(
            Companies(
                name=name,
                extracted_name=(query_entity if not tagged_status else name),
                mi_id=safe_get(entity_context, ["CompanyContext", "keyinstn"]),
                rating_entity_id=safe_get(entity_context, ["CompanyContext", "rating_entity_id"]),
                type=entity_context.get("Type"),
                url=entity_context.get("URL"),
                subsector_code=safe_get(
                    company_info_response_from_ratings_api, ["CompanyIdentifier", 0, "SubSectorCode"]
                ),
                rd_sector=rd_sector,
                rd_subsector=rd_subsector,
                rd_industry=rd_industry,
                base_url=url,
                is_rd_entity=entity_context.get("RD", False),
            )
        )
    elif "CountryContext" in entity_context:
        name = entity_context.get("Name").replace(" › Country/Region Profile", "").split(")")[-1]
        companies.append(
            Companies(
                name=name,
                extracted_name=(query_entity if not tagged_status else name),
                mi_id=safe_get(entity_context, ["CountryContext", "keyinstn"]),
                type=entity_context.get("Type"),
                url=entity_context.get("URL"),
                subsector_code="SOV",
                base_url=url,
                is_rd_entity=entity_context.get("RD", False),
            )
        )
    elif "RSContext" in entity_context:
        name = safe_get(entity_context, ["RSContext", "name"])
        revenue_sources.append(
            RevenueSource(
                name=name,
                extracted_name=query_entity if not tagged_status else name,
                asid=safe_get(entity_context, ["RSContext", "ASIDId"]),
                type=entity_context.get("Type"),
                url=entity_context.get("URL"),
                obligor=convert_list_type_string_to_list(safe_get(entity_context, ["RSContext", "Obligor"])),
                issuer=convert_list_type_string_to_list(safe_get(entity_context, ["RSContext", "Issuer"])),
                issuer_url=convert_list_type_string_to_list(safe_get(entity_context, ["RSContext", "IssuerUrl"])),
                base_url=url,
                is_rd_entity=entity_context.get("RD", False),
            )
        )
    elif "SecurityContext" in entity_context:
        name = safe_get(entity_context, ["SecurityContext", "RDDescription"])
        securities.append(
            Securities(
                id=safe_get(entity_context, ["SecurityContext", "SecurityID"]),
                extracted_name=(query_entity if not tagged_status else name),
                value_type=(SecurityType.ISIN.value if len(query_entity) == 12 else SecurityType.CUSIP.value),
                type=safe_get(entity_context, ["Type"]),
                isin=safe_get(entity_context, ["SecurityContext", "RDISIN"]),
                cusip=convert_list_type_string_to_list(safe_get(entity_context, ["SecurityContext", "RDCUSIP"])),
                description=safe_get(entity_context, ["SecurityContext", "RDDescription"]),
                issuer=convert_list_type_string_to_list(safe_get(entity_context, ["SecurityContext", "RDIssuerName"])),
                issuer_keyinstn=safe_get(entity_context, ["SecurityContext", "IssuerKeyinstn"]),
                primary_issuer=safe_get(entity_context, ["SecurityContext", "RDPrimaryIssuerName"]),
                url=convert_list_type_string_to_list(safe_get(entity_context, ["SecurityContext", "RDUrl"])),
                security_sector=json.loads(safe_get(entity_context, ["SecurityContext", "RDKOS"])),
                base_url=url,
                is_rd_entity=entity_context.get("RD", False),
            )
        )
    else:
        pass

    return Entities(
        companies=list(set(companies)),
        securities=list(set(securities)),
        revenue_sources=list(set(revenue_sources)),
    )


def get_company_ids_to_exclude():
    return config_machinery.get_config_value(Constants.GeneralConstants.EXCLUDE_COMPANY_ENTITIES_IN_OMNISEARCH)


def verify_for_exclusion(verify_entity: Entities) -> Entities:
    company_ids_to_exclude = get_company_ids_to_exclude()
    verify_entity.companies = [
        company for company in verify_entity.companies if company.mi_id not in company_ids_to_exclude
    ]
    return verify_entity


def extract_info_from_search_api(
    entities: List[str], input_securities: ExtractedSecurities, tagged_entities_status: List[bool]
) -> Entities:
    suggested_entities, companies, securities, revenue_sources = [], [], [], []

    def process_entity(entity: str, tagged_status: bool) -> Tuple[List, List, List, List]:
        try:
            local_companies, local_revenue_sources, local_securities = [], [], []

            security_flag = False
            if entity in input_securities.cusip or entity in input_securities.isin:
                security_flag = True

            # entity has a security pattern or is a tagged security - Fixed Income search tab
            if security_flag:
                top_match_entity_context, url, suggested_entities_context = SearchAPI().get_entity(
                    query=entity, security_indicator=True
                )
                logger.debug(f"Top matched entity from the Search API call: {top_match_entity_context}")
                top_match_entity = Entities()
                if top_match_entity_context:
                    top_match_entity = process_entity_context(top_match_entity_context, url, entity, tagged_status)
                if top_match_entity.securities and (
                    top_match_entity.securities[0].isin in input_securities.isin
                    or (
                        top_match_entity.securities[0].cusip
                        and top_match_entity.securities[0].cusip[0] in input_securities.cusip
                    )
                ):
                    local_securities.extend(top_match_entity.securities)
            # entity does not have a security pattern or there is an empty extraction from the first search api call (e.g. {9_char_entity} that has a cusip pattern but represents a company) - All search tab
            if not security_flag or not local_securities:
                top_match_entity_context, url, suggested_entities_context = SearchAPI().get_entity(
                    query=entity, security_indicator=False
                )
                logger.debug(f"Top matched entity from the Search API call: {top_match_entity_context}")
                top_match_entity = Entities()
                if top_match_entity_context:
                    top_match_entity = process_entity_context(top_match_entity_context, url, entity, tagged_status)
                    top_match_entity = verify_for_exclusion(verify_entity=top_match_entity)
                if top_match_entity.companies:
                    local_companies.extend(top_match_entity.companies)
                if top_match_entity.securities:
                    local_securities.extend(top_match_entity.securities)
                if top_match_entity.revenue_sources:
                    local_revenue_sources.extend(top_match_entity.revenue_sources)

            local_suggested_entities = []
            if len(entities) == 1 and suggested_entities_context:
                for item_context in suggested_entities_context:
                    local_suggested_entities.append(process_entity_context(item_context, url, item_context["Name"]))

            return local_companies, local_securities, local_revenue_sources, local_suggested_entities

        except Exception as e:
            logger.error(f"Error processing entity {entity}: {e}")
            return [], [], [], []

    if entities:
        futures = [
            submit_to_shared_thread_pool(process_entity, entity, tagged_entities_status[i])
            for i, entity in enumerate(entities)
        ]

        for future in futures:
            comp, sec, rev, sugg = future.result()
            companies.extend(comp)
            securities.extend(sec)
            revenue_sources.extend(rev)
            suggested_entities.extend(sugg)

    disambiguated_entities = Entities(
        companies=make_unique(companies),
        securities=make_unique(securities),
        revenue_sources=make_unique(revenue_sources),
    )

    logger.debug(f"Disambiguated Entities Dict : {disambiguated_entities.dict()}")
    logger.debug(f"Suggested Entities Dict : {suggested_entities}")
    return disambiguated_entities, suggested_entities
