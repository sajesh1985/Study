CRITERIA_GUIDELINES_EXAMPLES = """
{
    "question": "Explain business risk for <sector>",
    "guidelines": "1. Write an abstract that will summarize the bullets and call it **Summary**. \n2. Format the **Summary** as a title and paragraph. Summary must contain the conclusions and insights from the keypoints in a paragraph form. \n3. In the summary section do not include sentences like 'The summary of the key points from the provided information is as follows:'  \n4. After the summary paragraph start the response by writing 'Based on the latest S&P Global Ratings criteria,'. \n5. If you can not answer the query based on the information provided state that accordingly. Otherwise write a detailed report of the keypoints: answer the specific question and decide which other keypoints are relevant <critical>When answering, prioritize documents that are most relevant but be verbose.</critical> \n6. Format must be: **Summary** header<paragraph>at least 3-sentences summary starting with 'S&P Global Rating's research '</paragraph> followed by <paragraph><sentence>'Based on the latest S&P Global Ratings criteria, business risk for <sector> is as follows:'</sentence> followed by keypoints and must not contain any conclusion at the end.</paragraph> \n7. Do not include the user query into the response."
}
__________________
{
    "question": "What are the main factors that influence the credit ratings of sovereign entities?",
    "guidelines": "1. Write an abstract that will summarize the bullets and call it **Summary**. \n2. Format the **Summary** as a title and paragraph. Summary must contain the conclusions and insights from the keypoints in a paragraph form. \n3. In the summary section do not include sentences like 'The summary of the key points from the provided information is as follows' \n4. After the summary paragraph start the response by writing 'Based on the latest S&P Global Ratings criteria,' \n5. If you can not answer the query based on the information provided state that accordingly. Otherwise write a detailed report of the keypoints: answer the specific question and decide which other keypoints are relevant. <critical>When answering, prioritize documents that are most relevant.</critical> \n6. Format must be: **Summary** header<paragraph>at least 3-sentences summary starting with 'S&P Global Rating's research '</paragraph> followed by <paragraph><sentence>'Based on the latest S&P Global Ratings criteria, the main factors that influence the credit ratings of sovereign entities are as follows:'</sentence> followed by keypoints and must not contain any conclusion at the end.</paragraph> \n7. Do not include the user query into the response."
} 
___________________
{
    "question": "From the Sovereign Ratings Methodology, what initial economic assessment does a sovereign get",
    "guidelines": "1. Write an abstract that will summarize the bullets and call it **Summary**. \n2. Format the **Summary** as a title and paragraph. Summary must contain the conclusions and insights from the keypoints in a paragraph form. \n3. In the summary section do not include sentences like 'The summary of the key points from the provided information is as follows:' \n4. After the summary paragraph start the response by writing 'Based on the latest S&P Global Ratings criteria,' \n5. If you can not answer the query based on the information provided state that accordingly. Otherwise write a detailed report of the keypoints: answer the specific question and decide which other keypoints are relevant. <critical>When answering, prioritize documents that are most relevant but be verbose.</critical> \n6. Format must be: **Summary** header<paragraph>at least 3-sentences summary starting with 'S&P Global Rating's research '</paragraph> followed by <paragraph><sentence>'Based on the latest S&P Global Ratings criteria, a sovereign gets the following initial economic assessment:'</sentence> followed by keypoints and must not contain any conclusion at the end.</paragraph> \n7. Do not include the user query into the response."
}
___________________
{
    "question": "Explain the difference between a CreditWatch and an Outlook",
    "guidelines": "1. Write an abstract that will summarize the bullets and call it **Summary**. \n2. Format the **Summary** as a title and paragraph. Summary must contain the conclusions and insights from the keypoints in a paragraph form. \n3. In the summary section do not include sentences like 'The summary of the key points from the provided information is as follows:'\n4. After the summary paragraph start the response by writing 'Based on the latest S&P Global Ratings criteria,' \n5. If you can not answer the query based on the information provided state that accordingly. Otherwise write a detailed report of the keypoints: answer the specific question and decide which other keypoints are relevant. <critical>When answering, prioritize documents that are most relevant.</critical> \n6. Format must be: **Summary** header<paragraph>at least 3-sentences summary starting with 'S&P Global Rating's research '</paragraph> followed by <paragraph><sentence>'Based on the latest S&P Global Ratings criteria, the difference between a CreditWatch and an Outlook is the following:'</sentence> followed by keypoints and must not contain any conclusion at the end.</paragraph> \n7. Do not include the user query into the response."
}
___________________
{
    "question": "Summarize the key analytical steps of our BICRA criteria",
    "guidelines": "1. Write an abstract that will summarize the bullets and call it **Summary**. \n2. Format the **Summary** as a title and paragraph. Summary must contain the conclusions and insights from the keypoints in a paragraph form. \n3. In the summary section do not include sentences like 'The summary of the key points from the provided information is as follows:'\n4. After the summary paragraph start the response by writing 'Based on the latest S&P Global Ratings criteria,'\n5. If you can not answer the query based on the information provided state that accordingly. Otherwise write a detailed report of the keypoints: answer the specific question and decide which other keypoints are relevant. <critical>When answering, prioritize documents that are most relevant but be verbose.</critical>\n6. Format must be: **Summary** header<paragraph>at least 3-sentences summary starting with 'S&P Global Rating's research '</paragraph> followed by <paragraph><sentence>'Based on the latest S&P Global Ratings criteria, the key analytical steps of BICRA criteria are the following:'</sentence> followed by keypoints and must not contain any conclusion at the end.</paragraph>\n7. Do not include the user query into the response."
}
___________________
{
    "question": "Explain some potential Business Risks for the Capital Goods sector based off S&P Criteria",
    "guidelines": "1. Write an abstract that will summarize the bullets and call it **Summary**. \n2. Format the **Summary** as a title and paragraph. Summary must contain the conclusions and insights from the keypoints in a paragraph form. \n3. In the summary section do not include sentences like 'The summary of the key points from the provided information is as follows:' \n4. After the summary paragraph start the response by writing 'Based on the latest S&P Global Ratings criteria'.\n5. If you can not answer the query based on the information provided state that accordingly. Otherwise write a detailed report of the keypoints: answer the specific question and decide which other keypoints are relevant. <critical>When answering, prioritize documents that are most relevant but be verbose.</critical>\n6. Format must be: **Summary** header<paragraph>at least 3-sentences summary starting with 'S&P Global Rating's research '</paragraph> followed by <paragraph><sentence>'Based on the latest S&P Global Ratings criteria, the potential Business Risks for the Capital Goods sector are the following:'</sentence> followed by keypoints and must not contain any conclusion at the end.</paragraph>\n7. Do not include the user query into the response."
}
___________________
{
    "question": "How is <Financial Metric> defined for Corporate Issuers",
    "guidelines": "1. Write an abstract that will summarize the bullets and call it **Summary**. \n2. Format the **Summary** as a title and paragraph. Summary must contain the conclusions and insights from the keypoints in a paragraph form. \n3. In the summary section do not include sentences like 'The summary of the key points from the provided information is as follows:'.\n4. After the summary paragraph start the response by writing 'Based on the latest S&P Global Ratings criteria,' \n5. If you can not answer the query based on the information provided state that accordingly. Otherwise write a detailed report of the keypoints: answer the specific question and decide which other keypoints are relevant. <critical>When answering, prioritize documents that are most relevant but be verbose.</critical>\n6. Format must be: **Summary** header<paragraph>at least 3-sentences summary starting with 'S&P Global Rating's research '</paragraph> followed by <paragraph><sentence>'Based on the latest S&P Global Ratings criteria, the <Financial Metric> for Corporate Issuers is defined as follows:'</sentence> followed by keypoints and must not contain any conclusion at the end.</paragraph>\n7. Do not include the user query into the response."
}
____________________
{
  "question": "Summarize US government criteria",
  "guidelines": "1. Write an abstract that will summarize the bullets and call it **Summary**. \n2. Format the **Summary** as a title and paragraph. Summary must contain the conclusions and insights from the keypoints in a paragraph form. \n3. In the summary section do not include sentences like 'The summary of the key points from the provided information is as follows:' \n4. After the summary paragraph start the response by writing 'Based on the latest S&P Global Ratings criteria,'\n5. If you can not answer the query based on the information provided state that accordingly. Otherwise write a detailed report of the keypoints: answer the specific question and decide which other keypoints are relevant. <critical>When answering, prioritize documents that are most relevant but be verbose.</critical>\n6. Format must be: **Summary** header<paragraph>at least 3-sentences summary starting with 'S&P Global Rating's research '</paragraph> followed by <paragraph><sentence>'Based on the latest S&P Global Ratings criteria, the US government criteria are the following:'</sentence> followed by keypoints and must not contain any conclusion at the end.</paragraph>\n7. Do not include the user query into the response."
}

"""

CRITERIA_GUIDELINES_EXAMPLES_TABLE_EXAMPLES = """"""


CRITERIA_GUIDELINES_PROMPTS = """
You are an excellent financial credit analyst and you will be given a question from the user.

Your task will be to extract information regarding user question:
* Guidelines highlighting relevant factors when answering the question (key: guidelines)

Examples pairs of question (key: question) and guidelines (key: guidelines) are given below in JSON format:
<examples>
{examples}
</examples>

Take a deep breath and Understand that these examples should not affect the extractions for any other keys.

NOTE:  You must NOT mention any question in the response.
       Do not say things like "Based on the provided rating information...".

Answer JSON object which should contain following properties:
* "guidelines"

<question>
{question}
</question>

You must return the guidelines in the same format as shown in the examples.
Don't try to answer the questions.
Just return an guidelines JSON object. Return the json only, do not return anything else.
"""

criteria_guidelines = {
    "prompt": CRITERIA_GUIDELINES_PROMPTS,
    "examples": {
        "structured_data_exists": CRITERIA_GUIDELINES_EXAMPLES,
        "structured_data_not_exists": CRITERIA_GUIDELINES_EXAMPLES,
    },
}
