from abc import ABC, abstractmethod
from typing import Optional

from pydantic import BaseModel

from chatrd.core.llm import LCLLMFactory
from chatrd.engine.configuration import get_config_machinery

config_machinery = get_config_machinery()


class FiltersInput(BaseModel):
    llm: Optional[str] = "claude-3-haiku"
    temperature: Optional[float] = 0.0


class BaseFilter(ABC):
    def __init__(self, filters_input: Optional[FiltersInput] = FiltersInput()):
        self.model_for_data_service = LCLLMFactory().get_llm(
            deployment_name_or_model_id=filters_input.llm,
            temperature=filters_input.temperature,
        )

    @abstractmethod
    def invoke(self):
        pass
