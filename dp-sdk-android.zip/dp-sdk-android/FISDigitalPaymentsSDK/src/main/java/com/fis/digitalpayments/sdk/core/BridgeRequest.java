// Copyright Notice!
// This document is protected under the trade secret and copyright
// laws as the property of Fidelity National Information Services, Inc.
// Copying, reproduction or distribution should be limited and only to
// employees with a “need to know” to do their job.
// Any disclosure of this document to third parties is strictly prohibited.
// © 2016 Fidelity National Information Services.
// All rights reserved worldwide.


package com.fis.digitalpayments.sdk.core;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Represents a request for native functionality.
 */
@SuppressWarnings("unused")
public class BridgeRequest {

    private String bridgeId;

    /**
     * Identifier of a Bridge object.
     * @return Identifier of a bridge object
     */
    String getBridgeId() {
        return bridgeId;
    }

    private String method;

    /**
     * Method to execute for a specific Bridge. Each Bridge defines it's own methods.
     * @return Bridge method to execute
     */
    public String getMethod() {
        return method;
    }

    private String callbackMethod;

    /**
     * THe callback used to communicate the information back to javascript.
     * @return Callback to invoke when complete.
     */
    public String getCallbackMethod() {
        return callbackMethod;
    }

    private String callbackKey;

    /**
     * Used to uniquely identify a request. Typically not needed unless multiple requests are in flight at the same time.
     * @return Unique identifier for a callback.
     */
    public String getCallbackKey() {
        return callbackKey;
    }

    private Map<String, String> params;

    /**
     * Parameters for a Bridge request.
     * @return Parameters for a bridge request.
     */
    public Map<String, String> getParams() {
        return params;
    }

    final private static String BRIDGE_PARAM_NAME = "bridge";
    final private static String METHOD_PARAM_NAME = "method";
    final private static String CALLBACK_PARAM_NAME = "callback";
    final private static String CALLBACKkEY_PARAM_NAME = "callbackKey";
    final private static String PARAMS_PARAM_NAME = "params";

    /**
     * Parses a JSON string into a BridgeRequest object.
     * @param jsonRequest Request string in JSON format.
     */
    public BridgeRequest(String jsonRequest) {

        try {
            JSONObject jsonObject = new JSONObject(jsonRequest);

            bridgeId = jsonObject.getString(BRIDGE_PARAM_NAME);
            method = jsonObject.getString(METHOD_PARAM_NAME);
            callbackMethod = jsonObject.getString(CALLBACK_PARAM_NAME);
            callbackKey = jsonObject.getString(CALLBACKkEY_PARAM_NAME);

            JSONObject paramsJSON = jsonObject.getJSONObject(PARAMS_PARAM_NAME);
            params = new HashMap<>();
            if (paramsJSON != null) {
                Iterator<String> keys = paramsJSON.keys();
                while (keys.hasNext()) {
                    String key = keys.next();
                    params.put(key, paramsJSON.getString(key));
                }
            }
        } catch (JSONException e) {
            // TODO: Handle JSON exception
        }
    }
}
