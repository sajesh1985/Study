def enhance(extracted: str | None):
    """
    Function to hold all the enhancements needed for a single extracted cell.
    """
    if extracted is None:
        return None

    return extracted.strip()