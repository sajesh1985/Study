﻿using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;

namespace Fis.Epp.Fusion.Auth
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateWebHostBuilder(args).Build().Run();
        }

        public static IWebHostBuilder CreateWebHostBuilder(string[] args)
        {
            return WebHost.CreateDefaultBuilder(args)
                 .ConfigureKestrel((context, options) =>
                 {
                     // To-Do: Revisit below in case Kestrel issue gets resolved
                     // options.Limits.MaxRequestBodySize = int.MaxValue;
                 })
                 .UseStartup<Startup>();
        }
    }
}
