export const ART_OBJECT_Id = '5475093';
export const LEGAL_CRITERIA = '535';
export const GENERAL_ALL_SECTORS = '520,535,485,491,503,498,540,537,531';
export const REQUEST_FOR_COMMENT_ALL_SECTORS = '490,497,509,502,537,547';
export const CORPORTES_ALL_SECTORS = '521,485,486,487,488,489,490,526';
export const FINANCIAL_INSTITUTIONS_ALL_SECTORS = '522,491,492,493,494,495,496,497,527';
export const INSURANCE_ALL_SECTORS = '523,503,504,506,507,508,505,509,529';
export const GOVERNMENTS_ALL_SECTORS = '524,498,499,502,528,500';
export const SF_ALL_SECTORS = '525,510,511,512,513,514,517,518,519,530';
export const INFRASTRUCTURE_ALL_SECTORS = '539,540,541,543,544,545,546,547,538';

export const RD_KOS=['1134','874','1133','1135'];

export const RESEARCH_MAPPING = {
    "FULL": "Full Analysis",
    "NEWS": "News",
    "RESUPD": "Research Update",
    "SUMMARY": "Summary Analysis",
    "REPORT": "Report",
    "COMMENTS": "Commentary",
	"CLASSIC":"Classic",
	"CRITERIA":"Criteria"
}

export const TYPEAHEAD_CARD_NAMES_ALL = [
  "suggest_typeahead",
  "countries-gss-typeahead",
  "insurance_stats_group-gss-typeahead",
  "company_screener",
  "combined_companies_mi-gss-typeahead",
  "fixed_income_rd-gss-typeahead",
  "revenue_source-gss-typeahead",
  "industry-topictag-gss-typeahead",
]

export const TYPEAHEAD_CARD_NAMES_COMPANIES = [
  "company_screener",
  "combined_companies_mi-gss-typeahead",
  "insurance_stats_group-gss-typeahead"
]

export const TYPEAHEAD_CARD_NAMES_FIXED_INCOMES = [
  "fixed_income_rd-gss-typeahead"
]

export const TYPEAHEAD_CARD_NAMES_TRENDING = [
  "trending_companies-gss-typeahead"
]