from enum import Enum
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field
from typing_extensions import TypedDict, NotRequired

from src.synthia.schemas.template import TemplateSection


class OutlineSection(BaseModel):
    """
    Represents a single section in the report outline with hierarchical structure.

    Fields:
        name (str): The title or heading of the outline section.
        description (str): A detailed description of what the section covers.
        tools (Optional[List[str]]): An optional list of tools or methods to use for this section.
        sections (Optional[List['OutlineSection']]): Child sections for hierarchical structure.
    """

    name: str  # The title/name of the section
    description: str  # Detailed description of what the section covers
    tools: Optional[List[str]] = None  # Optional list of tools/methods to use for this section
    sections: Optional[List['OutlineSection']] = None  # Child sections for hierarchical structure

class PeerCompany(BaseModel):
    name: str
    keyInstn: str

class ReportConfig(BaseModel):
    topic: str  # Keyinstn eg. 100369
    style: str = "business"  # Optional with default "business"
    depth: int = 3  # Optional with default 3
    report_template: str = Field(default="3")  # Optional with default 3
    peers: Optional[List[PeerCompany]] = None  # Optional with default 3
    isPeersChanged: bool = False  # Flag to indicate if peers have been modified in UI
    num_sections: int = 5  # Optional with default 5
    outline_only: bool = False  # Optional with default False
    approved_outline: Optional[List[OutlineSection]] = None  # Optional
    auth_token: Optional[str] = None  # Optional
    refresh_token: Optional[str] = None
    job_id: Optional[str] = None  # Unique identifier for the report generation job
    input_section_title: Optional[str] = None  # user input template section

class Source(BaseModel):
    id: Optional[str] = None
    name: Optional[str] = None
    url: Optional[str] = None

class ReportSection(BaseModel):
    """
    Represents a section of a generated report with hierarchical structure.

    Fields:
        name (str): The title or heading of the section.
        content (Optional[str]): The main textual content of the section.
        sources (Optional[List[str]]): List of unique sources or references used in this section.
        image (Optional[str]): URL or identifier for an image associated with this section.
        sections (Optional[List['ReportSection']]): Child sections for hierarchical structure.
    """
    id:Optional[str] = None
    name: str
    content: Optional[str] = None
    sources: Optional[List[Source]] = None
    #section_index: Optional[int] = None
    chart_data: Optional[List[Any]] = None
    sections: Optional[List['ReportSection']] = None  # Child sections for hierarchical structure

class Report(BaseModel):
    """Schema for a complete report with sections."""
    
    title: str = Field(..., description="Title of the report")
    description: Optional[str] = Field(default="", description="Description of the report")
    sections: List[ReportSection] = Field(default_factory=list, description="List of sections in the report")
    
    class Config:
        """Configuration for Report model."""
        extra = "forbid"
        validate_assignment = True

class ReportStatus(BaseModel):
    """
    Represents the status of a report generation job.

    Fields:
        job_id (str): Unique identifier for the report generation job.
        keyonlineuser (int): User identifier.
        status (str): Current status of the job (e.g., 'initializing', 'in_progress', 'completed', 'failed').
        progress (Optional[float]): Progress percentage (0.0 to 100.0).
        report_title (Optional[str]): Title of the report.
        report_config (Optional[Dict[str, Any]]): Configuration used for report generation.
        outline (Optional[List[Dict[str, Any]]]): Report outline structure.
        sections (Optional[List[Dict[str, Any]]]): Generated report sections.
        error (Optional[str]): Error message if the job failed.
        completed_at (Optional[str]): Timestamp when the job was completed.
        started_at (Optional[str]): Timestamp when the job was started.
        created_at (str): Timestamp when the job was created.
        updated_at (str): Timestamp when the job was last updated.
    """

    job_id: str
    keyonlineuser: Optional[int] = None
    status: Optional[str] = None
    progress: Optional[float] = None
    report_title: Optional[str] = None
    report_config: Optional[ReportConfig] = None
    outline: Optional[List[TemplateSection]] = None
    sections: Optional[List[ReportSection]] = None
    error: Optional[str] = None
    completed_at: Optional[str] = None
    started_at: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None



class ReportStatusEnum(Enum):
    """Enum for report generation job statuses."""
    INITIALIZING = "initializing"
    CREATING_OUTLINE = "creating_outline"
    CREATING_REPORT = "creating_report"
    QUEUED = "queued"
    PROCESSING = "processing"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    AWAITING_APPROVAL = "awaiting_approval"
    OUTLINE_APPROVED = "outline_approved"


class PromptStatusEnum(Enum):
    """Enum for report generation job statuses."""
    SECTION_EDIT_QUEUED = "section_edit_queued"
    SECTION_EDIT_PROCESSING = "section_edit_processing"
    SECTION_EDIT_AWAITING_APPROVAL = "section_edit_awaiting_approval"
    SECTION_EDIT_COMPLETED = "section_edit_completed"
    SECTION_EDIT_APPROVED = "section_edit_approved"
    SECTION_EDIT_DECLINED = "section_edit_declined"
    SECTION_EDIT_GUARDRAIL_DECLINED = "section_edit_guardrail_declined"
    SECTION_EDIT_RETRY = "section_edit_retry"


class SectionGenerationModeEnum(Enum):
    Generate = "Generate"
    Edit = "Edit"

    
ReportSection.model_rebuild()
