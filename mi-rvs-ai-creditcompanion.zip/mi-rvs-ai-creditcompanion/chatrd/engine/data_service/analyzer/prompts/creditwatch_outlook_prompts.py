CREDITWATCH_OUTLOOK_EXTRACTION_PROMPT = """You are an expert financial analyst specialized in S&P credit rating analysis. Your task is to extract specific information about S&P CreditWatch and Outlook actions from user questions.

# CONTEXT
S&P CreditWatch is a tool used by S&P Global Ratings to signal potential near-term changes in a company's credit rating. CreditWatch indicators include:
- "watch pos" (positive): Rating likely to be raised
- "watch neg" (negative): Rating likely to be lowered  
- "watch dev" (developing): Rating direction uncertain

S&P Outlook provides a longer-term view on credit rating direction and can be:
- "positive": Rating may be raised over 6-24 months
- "negative": Rating may be lowered over 6-24 months
- "stable": Rating unlikely to change over 6-24 months
- "developing": Rating direction uncertain over 6-24 months

Additional credit watch outlook statuses include:
- "NM" (Not Meaningful): Outlook is not meaningful for this type of credit rating
- "NR" (Not Rated): No rating has been assigned or rating has been withdrawn

Current date: {current_date}

# INSTRUCTIONS
1. Analyze the user question to identify any mentions of S&P CreditWatch or Outlook actions
2. Extract ONLY the specific credit watch/outlook actions mentioned
3. Extract the time frame for these actions if specified
4. Determine if user wants to display/include credit watch/outlook in results
5. Return your response as a JSON dictionary with the exact structure shown in examples

# OUTPUT FORMAT
Return a JSON dictionary with these keys:
- "value": String containing the specific actions mentioned, or None if none specified
- "time_frame": String in format "MM/DD/YYYY-MM/DD/YYYY" or None if not specified
- "display_column": Boolean - True when user wants to include/display outlook/watch, False otherwise
- Both value and time_frame must be strings (when present) or None (when absent)
- display_column must be boolean (True or False)
- Output must be a valid Python dictionary string format

# RULES
- For single actions: return the exact action (e.g., "watch pos", "positive", "NM", "NR")
- For Multiple/range ratings: Return as comma-separated string of quoted values (e.g., "'watch pos','watch neg','positive','NM'")
- If question asks for "any changes" without specifying actions, include standard actions only (not NM/NR unless explicitly mentioned)
- NM and NR should only be included when explicitly mentioned in the question
- If no specific actions mentioned, return None for value
- Time frame format: "MM/DD/YYYY-MM/DD/YYYY"
- If no time frame specified, return None for time_frame
- Return ONLY the JSON dictionary - no explanations or comments
- ALWAYS return all three keys ("value", "time_frame", "display_column") in the response

{display_column_instructions}

# EXAMPLES
{creditwatch_outlook_extraction_examples}

# USER QUESTION
{user_question}"""


CREDITWATCH_OUTLOOK_EXTRACTION_EXAMPLES = [
    (
        "What are the outlook changes for the companies from 2024 to today?",
        {
            "value": "'positive','developing','stable','negative'",
            "time_frame": "[01/01/2024]-[{TODAY_DATE:%m/%d/%Y}]",
            "display_column": False,
        },
    ),
    (
        "Provide me a list of companies with current value of credit watch positive",
        {
            "value": "watch pos",
            "time_frame": "[{TODAY_DATE + relativedelta(years=-1):%m/%d/%Y}]-[{TODAY_DATE:%m/%d/%Y}]",
            "display_column": False,
        },
    ),
    (
        "List recently downgraded companies with credit watch negative in the last 3 months with their EBITDA and revenue for Q1 and Q2 of 2024.",
        {
            "value": "watch neg",
            "time_frame": "[{TODAY_DATE + relativedelta(months=-3):%m/%d/%Y}]-[{TODAY_DATE:%m/%d/%Y}]",
            "display_column": False,
        },
    ),
    (
        "Provide me list of companies in the last 6 months with outlook change.",
        {
            "value": "'positive','developing','stable','negative'",
            "time_frame": "[{TODAY_DATE + relativedelta(months=-6):%m/%d/%Y}]-[{TODAY_DATE:%m/%d/%Y}]",
            "display_column": False,
        },
    ),
    (
        "Give me companies with credit watch change for Q1 and Q2 of {TODAY_DATE.year}.",
        {
            "value": "'watch pos','watch dev','watch neg'",
            "time_frame": "[01/01/{TODAY_DATE.year}]-[06/30/{TODAY_DATE.year}]",
            "display_column": False,
        },
    ),
    (
        "Show me insurance companies with watch positive or developing outlook in the last 12 months.",
        {
            "value": "'watch pos','developing'",
            "time_frame": "[{TODAY_DATE + relativedelta(months=-12):%m/%d/%Y}]-[{TODAY_DATE:%m/%d/%Y}]",
            "display_column": False,
        },
    ),
    (
        "What were the companies with change in CreditWatch and Outlook in the last 6 months?",
        {
            "value": "'watch pos','watch dev','watch neg','positive','developing','stable','negative'",
            "time_frame": "[{TODAY_DATE + relativedelta(months=-6):%m/%d/%Y}]-[{TODAY_DATE:%m/%d/%Y}]",
            "display_column": False,
        },
    ),
    (
        "List the companies with credit watch changes.",
        {
            "value": "'watch pos','watch dev','watch neg'",
            "time_frame": None,
            "display_column": False,
        },
    ),
    (
        "List me the companies and include their credit watch and outlook changes",
        {
            "value": None,
            "time_frame": None,
            "display_column": True,
        },
    ),
    (
        "Give me all the companies and include their outlook changes in your response.",
        {
            "value": None,
            "time_frame": None,
            "display_column": True,
        },
    ),
    (
        "Are there any companies that are NM?",
        {
            "value": "NM",
            "time_frame": None,
            "display_column": False,
        },
    ),
    (
        "Show me companies with NR status in the last year.",
        {
            "value": "NR",
            "time_frame": "[{TODAY_DATE + relativedelta(months=-12):%m/%d/%Y}]-[{TODAY_DATE:%m/%d/%Y}]",
            "display_column": False,
        },
    ),
    (
        "List companies with NM or NR outlook.",
        {
            "value": "'NM','NR'",
            "time_frame": None,
            "display_column": False,
        },
    ),
    (
        "Show me all companies with any outlook status changes.",
        {
            "value": "'positive','developing','stable','negative'",
            "time_frame": None,
            "display_column": False,
        },
    ),
    (
        "List all companies and show their credit watch status.",
        {
            "value": None,
            "time_frame": None,
            "display_column": True,
        },
    ),
    (
        "Get me technology companies with their outlook information.",
        {
            "value": None,
            "time_frame": None,
            "display_column": True,
        },
    ),
]
