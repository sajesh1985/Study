import logging
from typing import Optional

import pandas as pd

from chatrd.core.thread_utils import submit_to_shared_thread_pool
from chatrd.engine.components.query_analyzer.translator.utils import (
    Get_translation_result,
)
from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.data_service.schema import (
    Analyzer,
    ProcessorInput,
    Retriever,
    Synthesizer,
)
from chatrd.engine.data_service.synthesizer.base import BaseSynthesizer
from chatrd.engine.data_service.synthesizer.utils import (
    create_tranche_table,
    full_response,
    get_api_info,
    text_response,
)
from chatrd.engine.ratings_api import RatingsAPI

logger = logging.getLogger(__name__)

config_machinery = get_config_machinery()

CWOL_MAPPING = config_machinery.get_config_value(Constants.DataService.CWOL_MAPPING)
NUM_ROWS_TO_DISPLAY = config_machinery.get_config_value(Constants.GeneralConstants.NUM_ROWS_TO_DISPLAY)


def get_sourcing_footnote_url(query_params: Optional[str] = "") -> str:
    source_base_url = config_machinery.get_config_value(Constants.SourceGeneration.BASE_URL)
    footnote_url_slug = config_machinery.get_config_value(Constants.SourceGeneration.FOOTNOTE_URL_SLUG)
    return source_base_url + footnote_url_slug + query_params


class SFSingleTrancheSynthesizer(BaseSynthesizer):
    def source_description(self, entity_name, url) -> str:
        sourcing_url = get_sourcing_footnote_url("#" + url)
        return [(entity_name, sourcing_url)]

    def leading_line(self, entities) -> str:
        extracted_name = entities["securities"][0]["extracted_name"]
        value_type = (entities["securities"][0]["value_type"]).upper()
        template = f"""The Issue Credit Rating for {value_type} {extracted_name} is the following:"""
        return template

    def synthesize(
        self,
        processor: ProcessorInput = None,
        analyzer: Optional[Analyzer] = None,
        retriever: Retriever = None,
    ) -> Synthesizer:
        # Read Arguments
        df = pd.DataFrame([retriever.api_data])
        entities = processor.entities
        entity_name = entities["securities"][0]["primary_issuer"]
        url = entities["securities"][0]["url"][0]

        template = self.leading_line(entities)
        df_tabular, has_valid_rows = create_tranche_table(df)
        template = Get_translation_result(template, processor.original_language)
        template = template.result()

        source_url = []
        if has_valid_rows:
            count = df_tabular.shape[0]
            response = full_response(
                template=template,
                data=df_tabular,
                data_type="table",
                count=count,
            )
            source_url = source_url + self.source_description(entity_name, url)
        else:
            template = "Sorry, CreditCompanion<sup>TM</sup> is not able to provide requested information. Please try another question"
            template = Get_translation_result(template, processor.original_language)
            template = template.result()

            response = [text_response(template, error=True)]

        api_info = get_api_info(retriever.api_method, retriever.api_type, retriever.url)
        return Synthesizer(data_service_response=response, source_description=source_url, api_info=api_info)


class SFDealsSynthesizer(BaseSynthesizer):
    def make_url(self, instrument_name, deal_link):
        url = f"""<a href="{get_sourcing_footnote_url(query_params=deal_link)}" target="_blank">{instrument_name}</a>"""
        return url

    def source_description(self, entity_name, entity_id, instrument_id, source_mode="deal") -> str:
        try:
            url_add = "#company/profile?id="
            if source_mode == "deal":
                source_description = [
                    (
                        entity_name + " Structured Finance Issuer",
                        get_sourcing_footnote_url(url_add + entity_id + "&overrideDealOverview=1"),
                    ),
                ]
            elif source_mode == "tranche":
                source_description = [
                    (
                        entity_name + " Deal Profile",
                        get_sourcing_footnote_url(url_add + entity_id + "&instrumentId=" + instrument_id),
                    ),
                ]
            else:
                url_add = "#ratingsdirect/rdsecurities?Id="
                source_description = [
                    (entity_name + " Security Summary", get_sourcing_footnote_url(url_add + entity_id)),
                ]
            return source_description
        except Exception as e:
            logger.error(f"Failed to generate sourcing url: {e}\nNot returning any source description.")
            return None

    def leading_line(self, entities, deals_total_count, deals_active_count) -> str:
        # entity name
        entity_name = entities["companies"][0]["name"]
        plural_t = "s" if deals_total_count > 1 else ""
        if deals_active_count == deals_total_count:
            if deals_active_count == 1:
                active_deals_msg = " which is active.  "
            else:
                active_deals_msg = " all of which are active.  "
        elif deals_active_count == 0:
            if deals_total_count == 1:
                active_deals_msg = " which is not active.  "
            else:
                active_deals_msg = " none of which is active.  "
        elif deals_active_count == 1:
            active_deals_msg = f""" of which {deals_active_count} is active.  """
        else:
            active_deals_msg = f""" of which {deals_active_count} are active.  """
        if deals_total_count > 0:
            template = (
                f"""{entity_name} is a Structured Finance issuer with {deals_total_count} deal{plural_t} in total,"""
                + active_deals_msg
            )
        else:
            template = f"""{entity_name} is a Structured Finance issuer with no active deals."""
        return template

    def synthesize(
        self,
        processor: ProcessorInput = None,
        analyzer: Optional[Analyzer] = None,
        retriever: Retriever = None,
    ) -> Synthesizer:
        """
        Synthesizes a response based on the provided processor, analyzer, and retriever.

        Args:
            processor (Optional[ProcessorInput]): An object containing entity data.
            analyzer (Optional[Analyzer]): An optional analyzer object.
            retriever (Retriever): An object to retrieve API data.

        Returns:
            Synthesizer: An instance of Synthesizer containing the response and source description.
        """
        df = pd.DataFrame(retriever.api_data)
        entities = processor.entities
        df_active = df.copy()
        if not df.empty:
            df_active = df[df["ActiveIndicator"] == True]
        count = len(df)
        deals_active_count = df_active.shape[0]
        entity_name = entities["companies"][0]["name"]
        entity_id = str(entities["companies"][0]["mi_id"])
        instrument_name = ""
        instrument_id = ""

        df_deals = df_active
        deals_count = deals_active_count
        # Take only top NUM_ROWS_TO_DISPLAY deals to display
        df_deal_names = df_deals
        if not df_deals.empty:
            df_deal_names = (
                df_deals[["InstrumentName", "DealLink"]].sort_values(["InstrumentName"]).head(NUM_ROWS_TO_DISPLAY)
            )

        if deals_count > 0:
            df_deal_names["Deals"] = df_deal_names.apply(
                lambda row: self.make_url(row["InstrumentName"], row["DealLink"]), axis=1
            )

        footnote = ""
        if deals_count > NUM_ROWS_TO_DISPLAY:
            link_src = get_sourcing_footnote_url(f"#company/profile?id={entity_id}&overrideDealOverview=1")
            footnote = f"""For more information, please go to <a href="{link_src}">Corporate Profile Page</a> to foresee all deals."""
        df_deals_details = pd.DataFrame()
        if not df_deal_names.empty:
            df_deals_details = df_deal_names[["Deals"]]
        template = self.leading_line(entities, count, deals_active_count)

        template = Get_translation_result(template, processor.original_language)
        footnote = Get_translation_result(footnote, processor.original_language)

        template = template.result()
        footnote = footnote.result()

        response = full_response(
            template=template,
            data=df_deals_details,
            data_type="table",
            count=count,
            footnote=footnote,
        )
        source_url = self.source_description(entity_name, entity_id, instrument_id)
        if count == 1:
            instrument_id = df_deals.iloc[0].InstrumentId
            instrument_name = df_deals.iloc[0].InstrumentName
            instrument_name = instrument_name
            instrument_id = str(instrument_id)

            # Modifying the response if number of active deals is just 1
            link_src = get_sourcing_footnote_url(f"#company/profile?id={entity_id}&instrumentId={instrument_id}")
            content = template + f'<a href="{link_src}" target="_blank">{instrument_name}</a>'
            response = [text_response(content)]

            df_tranches, tranche_url = RatingsAPI().get_sf_tranches(instrument_id)
            df_tabular, has_valid_rows = create_tranche_table(df_tranches)

            if has_valid_rows:
                count = df_tabular.shape[0]
                # Filter out rows with 'NR' rating
                df_tabular = df_tabular[df_tabular["CURRENT RATING"] != "NR"].reset_index(drop=True)
                tranches_count_non_nr = df_tabular.shape[0]

                plural = "s" if count > 1 else ""
                conjunction = "and" if count > 1 else "/"
                template_tranche = f"""This deal has {count} active {conjunction} inactive tranche{plural}:"""
                tranche_footnote = "All data displayed is based on the outstanding ratings.  Securities with an NR rating are not displayed.  "

                if not df_tabular.empty:
                    df_tabular = df_tabular.sort_values(["TRANCHE"]).head(NUM_ROWS_TO_DISPLAY)

                if tranches_count_non_nr > NUM_ROWS_TO_DISPLAY:
                    link_src = get_sourcing_footnote_url(
                        f"#company/profile?id={entity_id}&instrumentId={instrument_id}"
                    )
                    tranche_footnote = (
                        tranche_footnote
                        + "For more information, please go to "
                        + f'<a href="{link_src}" target="_blank">Deal Profile Page</a>'
                        + "to foresee all tranches."
                    )

                response = response + full_response(
                    template=template_tranche,
                    data=df_tabular,
                    data_type="table",
                    count=count,
                    footnote=tranche_footnote,
                )

            source_url = source_url + self.source_description(entity_name, entity_id, instrument_id, "tranche")
        else:
            source_url = source_url + self.source_description(entity_name, entity_id, instrument_id, "security_summary")

        api_info = get_api_info(
            api_method=retriever.api_method,
            api_type=retriever.api_type,
            url=tranche_url if "tranche_url" in locals() else retriever.url,
        )
        return Synthesizer(data_service_response=response, source_description=source_url, api_info=api_info)
