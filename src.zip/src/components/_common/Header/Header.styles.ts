import styled from '@emotion/styled';
import { Breakpoints } from '@spglobal/tokens';
import { DARK } from '@spglobal/koi-helpers';

export const Container = styled.div`
  border-bottom: 1px solid var(--color-border-primary);
  text-align: center;
  display: flex;
  padding: var(--size-space-lg);
  justify-content: space-between;
  align-items: center;
  background: var(--color-bg-primary);
  @media (max-width: ${Breakpoints.MD}) {
    position: sticky;
    width: 100%;
    left: 0;
    top: 0;
  }
  .${DARK} & {
    border-color: var(--color-base-gray-80);
  }
`;
export const StatusChat = styled.div`
  display: inline-block;
  background: none;
  font-size: var(--size-font-1);
  font-weight: var(--font-weight-bold);
  padding: var(--size-space-xs) var(--size-space-sm);
  padding-top: 5px;
  border-radius: 5px;
  letter-spacing: var(--font-letter-space-10);
  color: var(--color-text-secondary);
  margin-left: var(--size-space-xs);
  position: relative;
  bottom: var(--size-space-xs);
  .${DARK} & {
    background: var(--color-base-gray-80);
  }
`;

export const Title = styled.h5`
  display: none;
  margin: 0;
  padding: var(--size-space-2xl) 0;
`;
