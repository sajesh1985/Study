from unittest.mock import Mock, patch
import pytest
from typing import List

from chatrd.core.document import Document, TableDocument
from chatrd.engine.app.response_enricher import ResponseEnricher
from chatrd.engine.configuration.config_key import ConfigKey, Constants


class TestResponseEnricher:
    """Test cases for the ResponseEnricher class."""

    def setup_method(self):
        """Set up test fixtures before each test method."""
        # Mocking the config value fetch
        with patch(
            "chatrd.engine.configuration.config_machinery.ConfigMachinery.get_config_value"
        ) as mock_config_value:

            def side_effect(arg: ConfigKey):
                if arg == Constants.SourceGeneration.BASE_URL:
                    return "BASE_URL"
                elif arg == Constants.SourceGeneration.RESEARCH_ARTICLE_URL_SLUG:
                    return "/RESEARCH"
                else:
                    return f"<{arg.value}>"

            mock_config_value.side_effect = side_effect
            self.enricher = ResponseEnricher()

    def mock_extractor(
        self, extract_side_effect: callable = Mock(), extract_categorized_side_effect: callable = Mock()
    ):
        """Helper method to mock the source extractor methods."""

        def flatten_side_effect(docs):
            flatten = []
            if not docs:
                return flatten
            for doc in docs:
                if isinstance(doc, list):
                    flatten.extend(flatten_side_effect(doc))
                else:
                    flatten.append(doc)
            return flatten

        mock_extractor = Mock()
        mock_extractor.extract.side_effect = extract_side_effect
        mock_extractor.extract_categorized.side_effect = extract_categorized_side_effect
        mock_extractor.flatten_list.side_effect = flatten_side_effect
        self.enricher._source_extractor = mock_extractor
        return mock_extractor

    # Tests for extract_sources method
    @pytest.mark.parametrize(
        "input_content, expected_output",
        [
            (None, []),
            ([], []),
            (["Doc 1"], ["[Title 1](Link for doc 1)"]),
            (["Doc 2", "Doc 3"], ["[Title 2](Link for doc 2)", "[Title 3](Link for doc 3)"]),
            (["Doc 4", "TableDoc 5"], ["[Title 4](Link for doc 4)", "[Title 5](Link for doc 5)"]),
        ],
    )
    def test_extract_sources(self, input_content, expected_output):
        """Test extract_sources with various document inputs."""

        def extract_side_effect(docs: List[Document]):
            """Generate mock link based on input document content."""
            links = []
            if not docs:
                return links
            for doc in docs:
                id = doc.content.split()[-1]
                links.append(f"[Title {id}](Link for doc {id})")
            return links

        mock_extractor = self.mock_extractor(extract_side_effect=extract_side_effect)

        # Prepare input documents
        if not input_content:
            input_docs = None
        else:
            input_docs = []
            for input in input_content:
                if "TableDoc" in input:
                    input_docs.append(TableDocument(content=input))
                else:
                    input_docs.append(Document(content=input))

        self.enricher._source_extractor = mock_extractor
        result = self.enricher.extract_sources(input_docs)

        assert result == expected_output

    @pytest.mark.parametrize(
        "source_docs_size, cited_docs_size, unauthorized_docs_size",
        [
            (0, 0, 0),  # No documents
            (1, 0, 0),  # Single source document
            (0, 1, 0),  # Single cited document
            (0, 0, 1),  # Single unauthorized document
            (2, 2, 2),  # Multiple documents in each category
            (3, 1, 0),  # Documents from partial categories
            (0, 3, 1),
            (1, 0, 3),
        ],
    )
    def test_extract_categorized_sources(self, source_docs_size, cited_docs_size, unauthorized_docs_size):
        """Test extract_categorized_sources with empty document lists."""

        def extract_side_effect(source_docs, cited_docs, unauthorized_docs):
            """Generate mock links based on input documents content and category."""
            all_links = {}
            for docs, category in zip(
                [source_docs, cited_docs, unauthorized_docs], ["source_links", "cited_links", "unauthorized_links"]
            ):
                links = []
                for doc in docs:
                    doc_type, id = doc.content.split(" - ")
                    links.append(f"[Title {id}](Link for {doc_type} {id})")
                all_links[category] = links
            return all_links

        mock_extractor = self.mock_extractor(extract_categorized_side_effect=extract_side_effect)

        # Prepare input documents
        source_docs = [Document(f"Source doc - {i}") for i in range(source_docs_size)]
        cited_docs = [Document(f"Cited doc - {i}") for i in range(cited_docs_size)]
        unauthorized_docs = [Document(f"Unauthorized doc - {i}") for i in range(unauthorized_docs_size)]

        self.enricher._source_extractor = mock_extractor
        source_links, cited_links, unauthorized_links = self.enricher.extract_categorized_sources(
            source_docs, cited_docs, unauthorized_docs
        )

        mock_extractor.extract_categorized.assert_called_once()
        assert all("Link for Source doc" in link for link in source_links)
        assert all("Link for Cited doc" in link for link in cited_links)
        assert all("Link for Unauthorized doc" in link for link in unauthorized_links)

    def test_extract_categorized_sources_without_docs(self):
        source_docs = None
        cited_docs = None
        unauthorized_docs = None

        source_extractor_response = {"source_links": [], "cited_links": [], "unauthorized_links": []}
        with patch.object(
            self.enricher._source_extractor, "extract_categorized", return_value=source_extractor_response
        ):
            result = self.enricher.extract_categorized_sources(source_docs, cited_docs, unauthorized_docs)

            assert result == ([], [], [])

    # Tests for get_docs_text_from_response method
    @pytest.mark.parametrize(
        "sources, expected_only_docs_text, expected_data_service_docs",
        [
            (None, [], []),
            ([], [], []),
            (["article"], ["Article content - 1"], []),
            (["api_source"], [], [{"response_payload": {"sourceID": "1"}}]),
            (["article", "api_source"], ["Article content - 1"], [{"response_payload": {"sourceID": "2"}}]),
            (
                ["article", "article", "api_source"],
                ["Article content - 1", "Article content - 2"],
                [{"response_payload": {"sourceID": "3"}}],
            ),
        ],
    )
    def test_get_docs_text_from_response(self, sources, expected_only_docs_text, expected_data_service_docs):
        """Test get_docs_text_from_response with empty document list."""
        mock_extractor = self.mock_extractor()
        src_id = 1

        # Helper functions to prepare input documents
        def create_article_doc(id):
            return Document(f"Article content - {id}", metadata={"articleID": str(id)})

        def create_api_source_doc(id):
            return Document(
                content=f"API Source content - {id}",
                metadata={"response_payload": {"sourceID": str(id)}},
            )

        # Prepare input documents
        if not sources:
            source_docs = None
        else:
            source_docs = []
            for doc in sources:
                if doc == "article":
                    source_docs.append(create_article_doc(src_id))
                else:
                    source_docs.append(create_api_source_doc(src_id))
                src_id += 1

        self.enricher._source_extractor = mock_extractor
        only_docs_text, data_service_docs = self.enricher.get_docs_text_from_response(source_docs)

        assert only_docs_text == expected_only_docs_text
        for doc, expected_metadata in zip(data_service_docs, expected_data_service_docs):
            assert doc.metadata == expected_metadata

    def test_get_docs_text_from_response_nested_documents(self):
        """Test get_docs_text_from_response handles nested document structures via flatten_list."""
        mock_extractor = self.mock_extractor()

        # Prepare input documents
        doc1 = Document("Article 123", metadata={"articleID": 123})
        doc2 = Document("Article 456", metadata={"articleID": 456})
        nested_source_docs = [[doc1], doc2]

        self.enricher._source_extractor = mock_extractor
        only_docs_text, data_service_docs = self.enricher.get_docs_text_from_response(nested_source_docs)

        assert only_docs_text == ["Article 123", "Article 456"]
        assert data_service_docs == []
