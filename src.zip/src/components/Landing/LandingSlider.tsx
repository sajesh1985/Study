import React from 'react';
import {
  Slider,
  SliderDots,
  SliderImgWrap,
  SliderImgWrapCircle,
  SliderMain,
  SliderText,
} from './Landing.styles';
import { ANGLE_LEFT, ANGLE_RIGHT } from '@spglobal/koi-icons';
import { Icon } from '@spglobal/react-components';
import { Size } from '@spglobal/koi-helpers';

export const LandingSlider: React.FC = () => {
  const [slide, setSlide] = React.useState<number>(1);

  return (
    <SliderMain>
      <Slider>
        <SliderImgWrap className={`slide-${slide}`}>
          <SliderImgWrapCircle />
          <div className="images darkImage">
            <img
              src={require('../../assets/images/illustrative1.svg')}
              className="illustrative-1 animation"
            />
            <img
              src={require('../../assets/images/illustrative2.svg')}
              className="illustrative-2 animation"
            />
            <img
              src={require('../../assets/images/illustrative3.svg')}
              className="illustrative-3 animation"
            />
            <img
              src={require('../../assets/images/illustrative4.svg')}
              className="illustrative-4 animation"
            />
          </div>
          <div className="images lightImage">
            <img
              src={require('../../assets/images/illustrative1Light.svg')}
              className="illustrative-1 animation"
            />
            <img
              src={require('../../assets/images/illustrative2Light.svg')}
              className="illustrative-2 animation"
            />
            <img
              src={require('../../assets/images/illustrative3.svg')}
              className="illustrative-3 animation"
            />
            <img
              src={require('../../assets/images/illustrative4.svg')}
              className="illustrative-4 animation"
            />
          </div>
        </SliderImgWrap>
        <SliderText>
          {slide == 1 && (
            <div>
              Credit<span className="red">Companion</span>™ is trained to answer questions about S&P Global Ratings,
              credit ratings data and research and provide insights to help you get a comprehensive view 
              of credit risk. Credit<span className="red">Companion</span>™ exclusively uses information from S&P Ratings and Research to provide 
              credit-focused responses.
            </div>
          )}
          {slide == 2 && (
            <div>
              What can Credit<span className="red">Companion</span>™ do?
              <br />
              <ul>
                <li>
                  Answer questions about any rated entity or security (all sectors & geographies).  
                </li>
                <li>
                  Provide comprehensive answers that reference relevant ratings research.
                </li>
                <li>
                  Perform the tasks of a research assistant like summarizing research,<br/> 
                  researching a specific topic, and even creating credit memos.  
                </li>
                <li>
                Provide context for better understanding S&P Global Rating’s methodology and criteria.  
                </li>
              </ul>
            </div>
          )}
          {slide == 3 && (
            <div>
             Credit<span className="red">Companion</span>™ is currently in development and is not intended to provide financial advice. 
              Please refer to our full disclosures for more information. Your feedback will help make Credit<span className="red">Companion</span>™ better.
            </div>
          )}
        </SliderText>
      </Slider>
      <SliderDots>
        <Icon
          color="var(--color-text-primary)"
          size={Size.XXSMALL}
          icon={ANGLE_LEFT}
          className={'arrow-back'}
          onClick={() => {
            const prev = slide > 1 ? slide - 1 : 3;
            setSlide(prev);
          }}
        />
        <span className={slide == 1 ? 'active' : ''} onClick={() => setSlide(1)}></span>
        <span className={slide == 2 ? 'active' : ''} onClick={() => setSlide(2)}></span>
        <span className={slide == 3 ? 'active' : ''} onClick={() => setSlide(3)}></span>
        <Icon
          color="var(--color-text-primary)"
          size={Size.XXSMALL}
          icon={ANGLE_RIGHT}
          className={'arrow-next'}
          onClick={() => {
            const next = slide < 3 ? slide + 1 : 1;
            setSlide(next);
          }}
        />
      </SliderDots>
    </SliderMain>
  );
};
