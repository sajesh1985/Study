import logging
from typing import List

import pandas as pd

from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.data_service.synthesizer.base import BaseSynthesizer
from chatrd.engine.data_service.synthesizer.utils import entity_identifier
from chatrd.engine.data_service.utils import parse_csv_string

logger = logging.getLogger(__name__)

config_machinery = get_config_machinery()

DEBT_TYPE_CSV_DATA = config_machinery.get_config_value(Constants.DataService.DEBT_TYPE_CSV_DATA)
RATING_TYPE_CSV_DATA = config_machinery.get_config_value(Constants.DataService.RATING_TYPE_CSV_DATA)


def join_grammar(items: List[str], suffix: str) -> str:
    """
    Joins a list of strings into a grammatically correct human-readable string.

    Examples:
        ["a"] => "a"
        ["a", "b"] => "a and b"
        ["a", "b", "c"] => "a, b, and c"

    Args:
        items (List[str]): A list of strings to join.

    Returns:
        str: A grammatically correct string joined with commas and 'and'.
    """
    if not items:
        return ""

    item_type = suffix.split(" ")[0]
    item_last_word = items[-1].split(" ")[-1]
    if item_last_word == item_type:
        suffix = suffix.replace(f"{item_type} ", "")

    if len(items) == 1:
        return items[0] + f" {suffix}"
    if len(items) == 2:
        return " and ".join(items) + f" {suffix}s"
    return ", ".join(items[:-1]) + ", and " + items[-1] + f" {suffix}s"


def leading_line(entities: list, debt_type: str = "", rating_type: str = "", maturity: str = "") -> str:
    """
    Constructs a descriptive leading sentence for a list of securities based on the provided entities,
    debt type, and maturity date range.

    Args:
        entities (list): A list of entities from which the name is to be extracted using `entity_identifier`.
        debt_type (str, optional): The type of debt (e.g., 'Subordinated', 'Senior Unsecured'). Defaults to an empty string.
        rating_type (str, optional): The type of rating (e.g., 'Foreign Currency LT', 'Local Currency LT'). Defaults to an empty string.
        maturity (str, optional): The maturity date range of the securities. Defaults to an empty string.

    Returns:
        str: A formatted sentence describing the securities associated with the extracted entity name,
             optionally including debt type and maturity year.

    Example:
        >>> leading_line(entities, debt_type="Subordinated", "Foreign Currency LT", maturity="01/01/2030 and 12/31/2030")
        "Here is the list of securities for Insta Corp with Subordinated Debt Type (Foreign Currency LT) and maturing between 01/01/2030 and 12/31/2030:"
    """
    extracted_name = entity_identifier(entities, "name")
    additional_parts = []
    debt_type_str = rating_type_str = ""

    if debt_type:
        parsed = parse_csv_string(DEBT_TYPE_CSV_DATA)
        df_debt_types = pd.DataFrame(parsed)
        debt_type_str = join_grammar(
            list(df_debt_types[df_debt_types["code"].isin(debt_type.split(","))].desc), "Debt Type"
        )

    if rating_type:
        parsed = parse_csv_string(RATING_TYPE_CSV_DATA)
        df_rating_types = pd.DataFrame(parsed)
        rating_type_str = join_grammar(
            list(df_rating_types[df_rating_types["code"].isin(rating_type.split(","))].desc), "Rating Type"
        )
        pre = "(" if debt_type else ""
        suf = ")" if debt_type else ""
        rating_type_str = f"{pre}{rating_type_str}{suf}"

    if debt_type or rating_type:
        additional_parts.append(" ".join([debt_type_str, rating_type_str]))

    if maturity:
        [maturity_start, maturity_end] = maturity.split(" and ")
        maturity_str = f"on {maturity_start}" if maturity_start == maturity_end else f"between {maturity}"
        additional_parts.append(f"maturing {maturity_str}")

    additional_msg = ""
    if additional_parts:
        additional_msg = " with " + " and ".join(additional_parts)

    return f"{extracted_name} has the following S&P Global rated securities{additional_msg}:"


def source_description(entities) -> str:
    sourcing_base_url = config_machinery.get_config_value(Constants.SourceGeneration.BASE_URL)
    footnote_url_slug = config_machinery.get_config_value(Constants.SourceGeneration.FOOTNOTE_URL_SLUG)
    query_params = f"#ratingsdirect/rdSecurities?Id={str(entity_identifier(entities, 'mi_id'))}"
    source_url = sourcing_base_url + footnote_url_slug + query_params
    return [(entity_identifier(entities, "name") + " | Securities Summary Page", source_url)]
