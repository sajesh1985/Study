﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace Fis.Epp.Fusion.WebAPI.Models
{
    public enum LoggerEnum
    {
        [Description("CorrelationId")]
        CorrelationId,
        [Description("BrandId")]
        BrandId,
        [Description("UserId")]
        UserId,
        [Description("MemberId")]
        MemberId,
        [Description("ApplicationId")]
        ApplicationId,
        [Description("ServiceUuid")]
        ServiceUuid,
        [Description("MethodId")]
        MethodId,
        [Description("ClientId")]
        ClientId,
        [Description("Verb")]
        Verb,
        [Description("HTTP_CODE")]
        HTTP_CODE,
        [Description("MessageCode")]
        MessageCode,
        [Description("Duration")]
        Duration,
        [Description("RequestJSON")]
        RequestJSON,
        [Description("ResponseJSON")]
        ResponseJSON,
        [Description("MessageSeverity")]
        MessageSeverity,
        [Description("Message")]
        Message,
        [Description("RequestUrl")]
        RequestUrl,
        [Description("ErrorStack")]
        ErrorStack,
        [Description("ErrorMessage")]
        ErrorMessage,
        [Description("UserIpAddress")]
        UserIpAddress,
        [Description("UserHostName")]
        UserHostName,
        [Description("AcceptEncoding")]
        AcceptEncoding,
        [Description("RequestorId")]
        RequestorId,
        [Description("UserAgent")]
        UserAgent
    }
}
