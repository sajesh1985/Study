import logging
import random
from concurrent.futures import as_completed
from itertools import islice
from typing import List

from chatrd.core.document.schema import Document
from chatrd.core.thread_utils import submit_to_shared_thread_pool
from chatrd.engine.ratings_api import RatingsAPI

logger = logging.getLogger(__name__)


def check_and_set_authorize_flag(unique_articles):
    try:
        unique_article_ids = list[str]()
        for doc in unique_articles:
            unique_article_ids.append(str(doc["articleID"]))
        response, _, _ = RatingsAPI().get_research_kos_access_info(unique_article_ids)
    except Exception as e:
        print(f"Error fetching access info for {unique_article_ids}: {e}")
        return unique_articles
    access_map = {}
    for item in response:
        if isinstance(item, dict):
            try:
                article_id = str(item.get("articleId"))
                has_access = item.get("hasAccess", 0)
                if has_access == 1:
                    access_map[article_id] = True
            except (ValueError, TypeError):
                pass

    for doc in unique_articles:
        article_id = str(doc.get("articleID"))
        doc["authorized"] = access_map.get(article_id, False)
    return unique_articles


def batched(iterable, size):
    """Yield successive batches of given size from iterable"""
    it = iter(iterable)
    while True:
        batch = list(islice(it, size))
        if not batch:
            break
        yield batch


# Process in batches of 5
def set_authorized_flag_on_documents(
    retrieved_documents: List[Document], entitlement_active: int, base_environment: str
):
    if entitlement_active != 1 and base_environment.lower() == "dev":
        logger.info("Entitlement check is disabled. Skipping authorization checks.")
        for doc in retrieved_documents:
            doc.authorized = True
        return
    unique_articles = get_unique_articleids_array(retrieved_documents)

    futures = [submit_to_shared_thread_pool(check_and_set_authorize_flag, unique_articles)]
    for future in as_completed(futures):
        _ = future.result()  # updated in-place

    unique_articles_dict = {item["articleID"]: item["authorized"] for item in unique_articles}
    logger.info(
        " | ".join(f"ArticleID: {doc['articleID']}, Authorized: {doc['authorized']}" for doc in unique_articles)
    )

    for doc in retrieved_documents:
        article_id = doc.metadata.get("articleID")
        if article_id in unique_articles_dict:
            doc.authorized = unique_articles_dict[article_id]


def get_unique_articleids_array(retrieved_documents: List[Document]):
    articleids_set = set()
    for doc in retrieved_documents:
        articleids_set.add(doc.metadata.get("articleID"))
    articleids_array = [{"articleID": item, "authorized": True} for item in articleids_set]
    return articleids_array
