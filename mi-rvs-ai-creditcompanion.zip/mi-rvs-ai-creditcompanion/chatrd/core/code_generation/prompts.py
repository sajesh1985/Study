from chatrd.core.code_generation.agent import AgentCapability, OutputConfig
from chatrd.core.code_generation.prompt_generator import PromptGenerator

generator = PromptGenerator()


def get_prompt_for_single_table(
    prompt,
    table_description,
    sample_data,
    column_description,
    special_instructions,
    examples=None,
    output_type=None,
    answer_template=None,
):

    return generator.generate_prompt_for_single_table(
        prompt=prompt,
        table_description=table_description,
        sample_data=sample_data,
        column_description=column_description,
        special_instructions=special_instructions,
        # capabilities=[AgentCapability.CHART_BUILDER, AgentCapability.MANIPULATION, AgentCapability.ANSWER_GENERATION],
        capabilities=[AgentCapability.MANIPULATION],
        output_config=OutputConfig(output_type=None),
    )


def get_prompt_for_multiple_tables(
    prompt,
    tables,
    examples_text,
    output_type="any",
    answer_template=None,
):

    names, table_descriptions, sample_datas, column_descriptions, special_instructions, table_key_texts = (
        [] for _ in range(6)
    )
    # names, table_descriptions, sample_datas, column_descriptions, table_key_values, special_instructions = [], [], [], [], [], []

    for table in tables:
        data_frame_schema = table.get_schema()
        names.append(table.name)
        table_descriptions.append(data_frame_schema["Table Description"])
        column_descriptions.append(data_frame_schema["Columns"])
        sample_datas.append(data_frame_schema["Sample Data"])
        table_key_texts.append(data_frame_schema["Table Key Text"])
        # table_key_values.append(data_frame_schema["Table Key Values"])
        special_instructions.append(data_frame_schema["Special Instructions"])

    return generator.generate_prompt_for_multiple_tables(
        prompt=prompt,
        names=names,
        table_descriptions=table_descriptions,
        sample_datas=sample_datas,
        column_descriptions=column_descriptions,
        table_key_texts=table_key_texts,
        # table_key_values=table_key_values,
        special_instructions=special_instructions,
        examples_text=examples_text,
        # capabilities=[AgentCapability.CHART_BUILDER, AgentCapability.MANIPULATION, AgentCapability.ANSWER_GENERATION],
        capabilities=[AgentCapability.MANIPULATION],
        output_config=OutputConfig(output_type=None),
    )
