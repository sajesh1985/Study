"""Scripts for CI/CD, quality-gateway checks, and local run"""
import os
import subprocess
from dotenv import load_dotenv


def code_format():
    """Format the code and import statements using black and isort"""
    subprocess.run(["poetry", "run", "black", "./chatrd"])
    subprocess.run(["poetry", "run", "isort", "./chatrd"])


def code_lint():
    """Check for code style issues using black and isort"""
    subprocess.run(["poetry", "run", "black", "--check", "--diff", "--color", "./chatrd"])
    subprocess.run(["poetry", "run", "isort", "--check", "--diff", "./chatrd"])


def test():
    """Run the unit tests with pytest"""
    subprocess.run(["poetry", "run", "pytest", "./tests/"])


def test_with_coverage():
    """Run the unit tests with pytest with code coverage report"""
    subprocess.run(["poetry", "run", "pytest", "--cov-report", "term-missing", "--cov=chatrd", "./tests/"])


def pre_commit():
    """Check code quality before committing changes"""
    code_format()
    code_lint()
    test()


def run_app():
    """Run the Streamlit application"""
    load_dotenv()
    subprocess.run(
        ["streamlit", "run", "chatrd/engine/app/app.py"],
        env={**os.environ},
    )
