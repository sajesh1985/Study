﻿// Copyright Notice! 
// This document is protected under the trade secret and copyright 
// laws as the property of Fidelity National Information Services, Inc. 
// Copying, reproduction or distribution should be limited and only to 
// employees with a “need to know” to do their job. 
// Any disclosure of this document to third parties is strictly prohibited.
// © 2018 Fidelity National Information Services.
// All rights reserved worldwide.

namespace Fis.Epp.Fusion.Auth.Controllers
{
    using Fis.Epp.Fusion.Auth.Common;
    using Fis.Epp.Fusion.Auth.Models;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.Mvc;
    using System;
    using System.Linq;
    using System.Threading.Tasks;

    /// <summary>Represents controller that host angular ui.</summary>    
    public class UIHostingController : FusionAuthControllerBase
    {
        #region Fields

        private readonly IWebHostEnvironment _hostingEnvironment;
        private readonly AppConfiguration _configuration;

        #endregion

        #region Ctor

        public UIHostingController(
            IWebHostEnvironment hostingEnvironment,
            AppConfiguration appConfigurations,
            WSO2AccessHandler wso2AccessHandler,
            RESTAccessHandler restAccessHandler) : base(appConfigurations, wso2AccessHandler, restAccessHandler)
        {
            _hostingEnvironment = hostingEnvironment;
            _configuration = appConfigurations;
        }

        #endregion

        #region SSO Migrate flow
        /// <summary>Captures sso data, validate, decrypt and pass to angular ui. Act as a launcher for angular ui.</summary>
        /// <param name="ssoResponseModel">Maps sso response.</param>   
        /// <returns>Views with user data.</returns>
        [HttpPost]
        [Route("migrate")]
        [CustomExceptionFilter]
        public async Task<IActionResult> Index([Bind(new string[] { "SsoToken,ContextToken,CorrelationId,SessionTimeout,KeepAliveURL,ReturnURL" })] SSOResponseModel ssoResponseModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest();
            }

            UserDataModel userDataModel = new UserDataModel
            {
                WwwRootPath = _hostingEnvironment.WebRootPath
            };

            if (!string.IsNullOrEmpty(ssoResponseModel.ContextToken))
                userDataModel.ContextToken = ssoResponseModel.ContextToken;

            if (!string.IsNullOrEmpty(ssoResponseModel.CorrelationId))
            {
                userDataModel.CorrelationId = ssoResponseModel.CorrelationId;
            }
            if (!string.IsNullOrEmpty(ssoResponseModel.KeepAliveURL))
            {
                userDataModel.KeepAliveURL = ssoResponseModel.KeepAliveURL;
            }
            if (!string.IsNullOrEmpty(ssoResponseModel.ReturnURL))
            {
                userDataModel.ReturnURL = ssoResponseModel.ReturnURL;
            }
            // TODO: ssoResponseModel.SessionTimeout will be received from SSO, then remove below line. By default its value is 900 seconds.
            ssoResponseModel.SessionTimeout = configuration.SessionTimeout.ToString();
            if (!string.IsNullOrEmpty(ssoResponseModel.SessionTimeout))
                userDataModel.SessionTimeout = Convert.ToInt32(ssoResponseModel.SessionTimeout);

            if (!string.IsNullOrEmpty(ssoResponseModel.SsoToken))
            {
                var jwtSSOToken = JwtHelper.ReadToken(ssoResponseModel.SsoToken);
                if (jwtSSOToken != null)
                {
                    var userIdClaim = jwtSSOToken.Claims.SingleOrDefault(x => x.Type == JWTEnum.USER_ID.GetEnumDescription());
                    if (userIdClaim != null)
                    {
                        userDataModel.UserId = userIdClaim.Value;
                    }

                    var feIdClaim = jwtSSOToken.Claims.SingleOrDefault(x => x.Type == JWTEnum.FE_ID.GetEnumDescription());
                    if (feIdClaim != null)
                    {
                        userDataModel.FeId = feIdClaim.Value;
                    }

                    var balanceListClaim = jwtSSOToken.Claims.Where(x => x.Type == JWTEnum.balanceList.GetEnumDescription());

                    if (balanceListClaim != null && balanceListClaim.Count() > 0)
                    {
                        userDataModel.BalanceList = ResolveFundingAccountBalance(balanceListClaim.ToList());
                    }
                }

                if (ValidateJwtAccessToken(ssoResponseModel.SsoToken))
                {
                    _ = await ResolveUserSession(userDataModel);
                }
                else
                {
                    throw new Exception("Invalid Token");
                }
            }
            return View(userDataModel);
        }

        /// <summary>
        /// This action handles the invalid routes to take the user at appropriate UI screen.
        /// </summary>
        /// <returns>View with default user data.</returns>
        [Route("Error/404")]
        public IActionResult PageNotFound()
        {
            UserDataModel user = new UserDataModel() { WwwRootPath = _hostingEnvironment.WebRootPath, PageRefresh = true };
            Response.StatusCode = 200;
            return View("Index", user);
        }

        #endregion

        #region Debug Access flow
        /// <summary>Generate access token, context token, session token for debug mode.</summary>
        /// <param name="model">Represents DebugAccessRequestModel.</param>
        /// <returns>Index view.</returns>
        /// <exception cref="System.ArgumentNullException">throws null if <paramref name="FeId"/> is <see langword="null"/>.</exception>
        /// <exception cref="System.ArgumentNullException">throws null if <paramref name="UserId"/> is <see langword="null"/>.</exception>
        [Route("DebugAccess")]
        [CustomExceptionFilter]
        [HttpGet]
        public async Task<IActionResult> Index([Bind(new string[] { "FeId, UserId, ApplicationId, SourceId, Locale" })] DebugAccessRequestModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest();
            }

            if (!configuration.EnableDebugAccess)
            {
                return NotFound();
            }
            var userDataModel = await PopulateUserDataModel(model);
            return View(userDataModel);
        }

        /// <summary>Generate access token, context token, session token for debug mode.</summary>
        /// <param name="model">Represents DebugAccessRequestModel.</param>
        /// <returns>All tokens required in debug mode.</returns>
        /// <exception cref="System.ArgumentNullException">throws null if <paramref name="FeId"/> is <see langword="null"/>.</exception>
        /// <exception cref="System.ArgumentNullException">throws null if <paramref name="UserId"/> is <see langword="null"/>.</exception>
        [Produces("application/json")]
        [Route("AuthApi/DebugAccess")]
        [HttpPost]
        public async Task<IActionResult> DebugAccess([FromBody][Bind( new string[] { "FeId, UserId, ApplicationId, SourceId, Locale" })] DebugAccessRequestModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest();
            }

            if (!configuration.EnableDebugAccess)
            {
                return NotFound();
            }
            var userDataModel = await PopulateUserDataModel(model);
            return Ok(userDataModel);
        }
        private async Task<UserDataModel> PopulateUserDataModel(DebugAccessRequestModel model)
        {
            if (string.IsNullOrEmpty(model.FeId))
            {
                throw new ArgumentNullException(ExceptionEnum.FeId.GetEnumDescription());
            }
            if (string.IsNullOrEmpty(model.UserId))
            {
                throw new ArgumentNullException(ExceptionEnum.UserId.GetEnumDescription());
            }
            UserDataModel userDataModel = new UserDataModel
            {
                ApplicationId = string.IsNullOrEmpty(Request.Headers[RequestHeader.Application_ID.GetEnumDescription()]) ? model.ApplicationId : Request.Headers[RequestHeader.Application_ID.GetEnumDescription()],
                Locale = string.IsNullOrEmpty(Request.Headers[RequestHeader.Locale.GetEnumDescription()]) ? model.Locale : Request.Headers[RequestHeader.Locale.GetEnumDescription()],
                SourceId = string.IsNullOrEmpty(Request.Headers[RequestHeader.Source_ID.GetEnumDescription()]) ? model.SourceId : Request.Headers[RequestHeader.Source_ID.GetEnumDescription()],
                UserId = model.UserId,
                FeId = model.FeId,
                WwwRootPath = _hostingEnvironment.WebRootPath,
                SessionTimeout = _configuration.SessionTimeout
            };
            _ = await ResolveUserSession(userDataModel);

            return userDataModel;
        }
        #endregion
    }
}
