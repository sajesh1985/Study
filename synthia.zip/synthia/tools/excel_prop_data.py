from mcp.server.fastmcp import FastMCP, Context
from fastapi import FastAPI, APIRouter
from fastapi import Request
from fastapi import Depends
from contextlib import asynccontextmanager
import httpx
import logging
import contextlib
from src.synthia.config.api_config import get_config
from . import auth
from src.synthia.utils.logging_config import configure_logging

# Configure logging
configure_logging(log_file='excel_prod_data.log',)
logger = logging.getLogger(__name__)

logger.info("Excel Prop Data MCP Server starting up...")
mcp: FastMCP = FastMCP("Excel Prop Data MCP Server", stateless_http=True)

cfg = get_config()


router = APIRouter()


# Create a single AsyncClient instance for reuse (performance optimization for Lambda)
async_client: httpx.AsyncClient = None


async def get_excel_prop_data(auth_headers: dict) -> str:
    logger.info(f"To be implemented")
    return "Dummy prop data"

@mcp.tool()
async def get_excel_prop_data(user_name: str, company_name: str) -> dict:
    """
    Retrieve user specific excel prop data containing financial and rating information of a company
    Args:
        company_name (str): The name of the company to search for
        user_name (str): The name of the user for whom the excel prop data is to be retrieved
    Returns:
        str: A string containing company data.
    """
    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    headers = raw_request.headers
    logger.info(f"Headers received: {headers}")
    auth_headers = auth.build_auth_headers(raw_request)
    logger.info(f"get_excel_prop_date called for : {company_name} {user_name}")
    logger.info(f"Request headers: {auth_headers}")
    return await get_excel_prop_data(auth_headers)



# Define a custom lifespan for FastAPI with a task to manage MCP
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Initialize MCP server task group
    logger.info("Initializing MCP server task group...")

    global async_client
    async_client = httpx.AsyncClient(timeout=10)

    async with contextlib.AsyncExitStack() as stack:
        await stack.enter_async_context(mcp.session_manager.run())
        yield

    # Shutdown: Close the AsyncClient
    await async_client.aclose()


@router.get("/excel-prop-data/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "ok"}


app = FastAPI(lifespan=lifespan)
app.mount("/excel-prop-data", mcp.streamable_http_app())
app.include_router(router)
logger.info("Excel prop data MCP Server started successfully.")
