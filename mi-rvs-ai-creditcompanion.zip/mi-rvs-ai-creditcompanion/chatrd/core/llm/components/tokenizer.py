from functools import lru_cache
from typing import AbstractSet, Collection, List, Literal, Optional, Union

import tiktoken


@lru_cache
class Tokenizer:
    """Tokenizer class for encoding and decoding text using tiktoken.
    This class is cached to improve performance by reusing the tokenizer instance.
    The instance will be reused for all subsequent calls with the same parameters,
        since only one Tokenizer instance will be created per provided parameter set.
    """

    def __init__(
        self,
        model_name: Optional[str] = None,
        encoding_name: Optional[str] = "gpt2",
        allowed_special: Union[Literal["all"], AbstractSet[str]] = None,
        disallowed_special: Union[Literal["all"], Collection[str]] = "all",
    ):
        if model_name is not None:
            enc = tiktoken.encoding_for_model(model_name)
        else:
            enc = tiktoken.get_encoding(encoding_name)
        self._tokenizer = enc
        self._allowed_special = allowed_special if allowed_special is not None else set()
        self._disallowed_special = disallowed_special

    def encode(self, text: str) -> List[int]:
        """Encode the text into token IDs."""
        return self._tokenizer.encode(
            text,
            allowed_special=self._allowed_special,
            disallowed_special=self._disallowed_special,
        )

    def decode(self, token_ids: List[int]) -> str:
        """Decode a list of token IDs into a string."""
        return self._tokenizer.decode(token_ids)
