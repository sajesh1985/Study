import logging
from typing import Optional

import pandas as pd

from chatrd.engine.components.query_analyzer.translator.utils import (
    Get_translation_result,
)
from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.data_service.schema import (
    Analyzer,
    ProcessorInput,
    Retriever,
    Synthesizer,
)
from chatrd.engine.data_service.synthesizer.base import BaseSynthesizer
from chatrd.engine.data_service.synthesizer.utils import (
    create_entity_defaultrating_table,
    full_response,
    get_api_info,
    make_source_description,
    rating_history_url,
)

logger = logging.getLogger(__name__)

config_machinery = get_config_machinery()

CWOL_MAPPING = config_machinery.get_config_value(Constants.DataService.CWOL_MAPPING)
NUM_ROWS_TO_DISPLAY = config_machinery.get_config_value(Constants.GeneralConstants.NUM_ROWS_TO_DISPLAY)


def source_description(entity_name, entity_id):
    sep = ": "
    info = "Ratings & History Page"
    sources = make_source_description(entity_name, entity_id, sep, info, rating_history_url)

    return sources


def leading_line(entity_name, source_url, total_count) -> str:
    # Constructing the response template
    if total_count == 1:
        # If only one row is available, display just that row's details (no URL or extra rating types)
        template = f"""Here is a list of {entity_name}'s S&P Credit Rating"""
    elif total_count > NUM_ROWS_TO_DISPLAY:
        template = f"""Here is a list of {entity_name}'s S&P Credit Rating.
        For more information about other available debt and rating types, please go to the <a href="{source_url}" target="_blank">Ratings & History page</a>.
        """
    else:
        # If there are between 2 and 15 rows, show other rating types without the URL
        template = f"""Here is a list of {entity_name}'s S&P Credit Ratings:
        """
    return template


class EntityDefaultRatingSynthesizer(BaseSynthesizer):
    def synthesize(
        self,
        processor: ProcessorInput = None,
        analyzer: Optional[Analyzer] = None,
        retriever: Retriever = None,
    ) -> Synthesizer:
        """
        Synthesizes a response based on the provided processor, analyzer, and retriever.

        Args:
            processor (Optional[ProcessorInput]): An object containing entity data.
            analyzer (Optional[Analyzer]): An optional analyzer object.
            retriever (Retriever): An object to retrieve API data.

        Returns:
            Synthesizer: An instance of Synthesizer containing the response and source description.
        """
        df = pd.DataFrame(retriever.api_data)
        list_of_entities_with_ids = [
            (company["name"], company["mi_id"]) for company in processor.entities.get("companies", [])
        ]
        entity_names = ", ".join(company["name"] for company in processor.entities["companies"])
        count = len(df)

        df_tabular, has_valid_rows = create_entity_defaultrating_table(df, processor.entities["companies"])

        # Get the source description (the URL)
        source_url = []
        for name, entity_id in list_of_entities_with_ids:
            if entity_id in df["KeyInstn"].values:
                source_url_entity = source_description(name, entity_id)
                source_url.extend(source_url_entity)
        template = leading_line(entity_names, source_url, count)
        template = Get_translation_result(template, processor.original_language)
        template = template.result()

        response = []
        if has_valid_rows:
            response = full_response(
                template=template,
                data=df_tabular,
                count=count,
                data_type="table",
            )

        api_info = get_api_info(api_method=retriever.api_method, api_type=retriever.api_type, url=retriever.url)
        return Synthesizer(data_service_response=response, source_description=source_url, api_info=api_info)
