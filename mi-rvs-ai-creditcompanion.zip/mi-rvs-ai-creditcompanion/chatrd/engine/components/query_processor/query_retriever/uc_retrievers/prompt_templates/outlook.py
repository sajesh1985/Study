OUTLOOK_EXAMPLES = """
{
    "question": "What is the Outlook for xyz according to S&P Global Ratings?",
    "answer": {
        "require_data_service": true,
        "require_documents": true,
    }
}
__________________
{
    "question": "What was the previous outlook for xyz?",
    "answer": {
        "require_data_service": true,
        "require_documents": true,
    }
}
__________________
{
    "question": "when was the outlook updated for xyz?",
    "answer": {
        "require_data_service": true,
        "require_documents": true,
    }
}
__________________
{
    "question": "What are the triggers for a downgrade for xyz?",
    "answer": {
        "require_data_service": false,
        "require_documents": true,
    }
}
"""

OUTLOOK_PROMPTS = """
You are an excellent financial credit analyst and you will be given a question from the user.
Your task will be to extract information regarding user question:
    * Does the question involve lookup in database for credit outlook, watch, date. (key: require_data_service)
    * Are research documents required to answer user question (key: require_documents)
    
<Examples pairs of question (key: question) and answer (key: answer) are given below in JSON format: Do not stick completely to the values for answer shown in examples they are only for taking hints>
{examples}

Take a deep breath and understand that these examples should not affect the extractions for any other keys.

Answer JSON object which should contain following properties:
* "require_data_service"
* "require_documents"

<Question>
{question}

Just return an answer JSON object.
"""
