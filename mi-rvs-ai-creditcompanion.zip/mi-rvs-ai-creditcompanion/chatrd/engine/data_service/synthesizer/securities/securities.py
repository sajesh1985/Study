import logging
from typing import List, Optional

import pandas as pd

from chatrd.core.thread_utils import submit_to_shared_thread_pool
from chatrd.engine.components.query_analyzer.translator.utils import (
    Get_translation_result,
)
from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.data_service.schema import (
    Analyzer,
    ProcessorInput,
    Retriever,
    Synthesizer,
)
from chatrd.engine.data_service.synthesizer.base import BaseSynthesizer
from chatrd.engine.data_service.synthesizer.securities.utils import (
    leading_line,
    source_description,
)
from chatrd.engine.data_service.synthesizer.utils import (
    calculate_group_count,
    create_securities_table,
    full_response,
    get_api_info,
    text_response,
)

logger = logging.getLogger(__name__)
config_machinery = get_config_machinery()
NUM_ROWS_TO_DISPLAY = config_machinery.get_config_value(Constants.GeneralConstants.NUM_ROWS_TO_DISPLAY)


class ListOfSecuritiesSynthesizer(BaseSynthesizer):
    def synthesize(
        self,
        processor: ProcessorInput = None,
        analyzer: Optional[Analyzer] = None,
        retriever: Retriever = None,
    ) -> Synthesizer:

        df = pd.DataFrame(retriever.api_data)
        entities = processor.entities
        total_count, count_distribution = calculate_group_count(
            df, debt_type_col="RT_DEBT_TYPE_CODE", rating_type_col="RT_RATING_TYPE_CODE"
        )

        debt_type = maturity = rating_type = ""
        if analyzer is not None:
            debt_type = analyzer.response["DebtType"]
            rating_type = analyzer.response["RoleType"]
            if analyzer.response["MaturityEndDate"]:
                maturity = " and ".join([analyzer.response["MaturityStartDate"], analyzer.response["MaturityEndDate"]])

        template = leading_line(entities, debt_type, rating_type, maturity)

        source_url = []
        if df.shape[0] > 0:
            template = Get_translation_result(template, processor.original_language)
            template = template.result()

            df = create_securities_table(df)
            response = full_response(
                template=template, data=df, data_type="table", count=total_count, count_distribution=count_distribution
            )
            source_url = source_description(entities=entities)
        else:
            template = "CreditCompanion™ is unable to find requested information. Please try another question."
            template = Get_translation_result(template, processor.original_language)
            template = template.result()
            response = [text_response(template, error=True)]

        api_info = get_api_info(
            api_method=retriever.api_method,
            api_type=retriever.api_type,
            url=retriever.url,
            screener_payload=retriever.screener_payload,
        )
        return Synthesizer(data_service_response=response, source_description=source_url, api_info=api_info)
