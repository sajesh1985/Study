"""Report status tracking and storage module for Synthia."""

from decimal import Decimal
import logging
from typing import Dict, List, Optional, Any
from datetime import datetime
import json
from src.synthia.schemas.workflow import ReportConfig, OutlineSection, ReportSection, ReportStatus
from src.synthia.schemas.sections import Section
from src.synthia.persistence.database_manager import get_connection_pool
from src.synthia.user_profile.user_profile_provider import (
    UserProfileData,
    fetch_user_profile_data,
)
from pydantic import TypeAdapter

from src.synthia.utils.logging_config import configure_logging

logger = configure_logging(
    log_file="synthia.log",
    module_levels={__name__: logging.DEBUG},  # Set this module to DEBUG
)


class ReportMonitor:
    """Manages report status tracking and storage using PostgreSQL with async operations."""

    def __init__(self, auth_token: str = None):
        self._connection_pool = None
        self.profile: UserProfileData = None
        self.auth_token = auth_token

    async def _get_keyonline_user(self) -> int:
        """Get the current user's keyonline_user from profile."""
        if self.profile is None:
            self.profile = await fetch_user_profile_data(self.auth_token)
        return self.profile["KeyOnlineUser"]

    def _get_pool(self):
        """Get the connection pool, ensuring it's available."""
        if self._connection_pool is None:
            self._connection_pool = get_connection_pool()
        if self._connection_pool is None:
            raise RuntimeError(
                "Connection pool not initialized. Call initialize_connection_pool() during app startup."
            )
        return self._connection_pool

    async def _execute_procedure(
        self, procedure_name: str, params: List[Any], is_select: bool = False
    ) -> List[Dict[str, Any]]:
        """Execute a stored procedure with optimized psycopg 3 operations."""
        pool = self._get_pool()
        async with pool.connection() as conn:
            query = f"CALL {procedure_name}({', '.join(['%s'] * len(params))})"
            cursor = await conn.execute(query, params)
            
            if cursor.description:
                rows = await cursor.fetchall()
                columns = [desc.name for desc in cursor.description]
                return [dict(zip(columns, row)) for row in rows]
            return []

    async def _execute_function(
        self, function_name: str, params: List[Any]
    ) -> List[Dict[str, Any]]:
        """Execute a stored function that returns a table."""
        pool = self._get_pool()
        async with pool.connection() as conn:
            query = f"SELECT * FROM {function_name}({', '.join(['%s'] * len(params))})"
            cursor = await conn.execute(query, params)
            
            if cursor.description:
                rows = await cursor.fetchall()
                columns = [desc.name for desc in cursor.description]
                return [dict(zip(columns, row)) for row in rows]
            return []

    async def create_job(
        self, job_id: str, report_config: ReportConfig
    ):
        """Create a new job with initial state."""
        keyonline_user = await self._get_keyonline_user()
        started_at = datetime.now()

        await self._execute_procedure(
            procedure_name="Product.report_jobs_insert",
            params=[
                str(job_id),                              # p_job_id (cast to text)
                int(keyonline_user),                      # p_keyonlineuser (cast to integer)
                str(report_config.get("topic", ""))[:50], # p_report_title (cast to text)
                json.dumps(dict(report_config)),          # p_report_config (cast to text/json)
                None,                                     # p_outline
                started_at,                               # p_started_at
                str("initializing"),                      # p_status (cast to text)
                Decimal('0.0'),                           # p_progress (cast to double precision)
            ],
        )

        return

    async def get_job(self, job_id: str) -> Optional[ReportStatus]:
        """Get job state by ID for current user."""
        keyonline_user = await self._get_keyonline_user()
        result = await self._execute_function(
            "Product.report_jobs_select", [job_id, keyonline_user]
        )
        if not result:
            return None

        row = result[0]
        config = row["report_config"]
        config["job_id"] = row["job_id"]

        def to_iso(dt):
            return dt.isoformat() if dt else None

        status_kwargs = {
            "job_id": row["job_id"],
            "keyonlineuser": keyonline_user,
            "status": row["status"],
            "progress": Decimal(row["progress"] or "0.0"),
            "report_title": config.get("topic", ""),
            "report_config": config,
            "error": row["error"],
            "completed_at": to_iso(row["completed_at"]),
            "started_at": to_iso(row["started_at"]),
            "created_at": to_iso(row["started_at"]) or datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat(),
        }

        if row["outline"]:
            outline_adapter = TypeAdapter(List[Section])
            #outline_data = json.loads(row["outline"]).get("outline", [])
            status_kwargs["outline"] = outline_adapter.validate_python(row["outline"])
        if row["sections"]:
            sections_adapter = TypeAdapter(List[ReportSection])
            status_kwargs["sections"] = sections_adapter.validate_python(row["sections"])

        return ReportStatus(**status_kwargs)

    async def update_job(self, job_id: str, updates: ReportStatus) -> bool:
        """Update job state with provided updates for current user."""
        if not job_id or not updates:
            return False
        keyonline_user = await self._get_keyonline_user()
        if not keyonline_user:
            raise RuntimeError("User not authenticated or keyonline_user not found.")
        #current_job = await self.get_job(job_id)

        outline_adapter = TypeAdapter(List[Section])
        outline = outline_adapter.validate_python(updates.outline) if updates.outline else None

        sections_adapter = TypeAdapter(List[ReportSection])
        sections = sections_adapter.validate_python(updates.sections) if updates.sections else None

        await self._execute_procedure(
            "Product.report_jobs_update",
            [
                updates.job_id,
                keyonline_user,
                updates.status,
                self.safe_decimal(updates.progress),
                self.safe_truncate(updates.report_title),
                self.safe_json_dumps(updates.report_config),
                outline_adapter.dump_json(outline).decode('utf-8') if outline else None,
                sections_adapter.dump_json(sections).decode('utf-8') if sections else None,
                updates.error,
                self.safe_parse_dt(updates.completed_at),
                self.safe_parse_dt(updates.started_at),
            ],
        )
        return True

    async def update_job_status(
        self, job_id: str, status: str, progress: Optional[float] = None
    ) -> bool:
        """Update job status and optionally progress."""
        update_data = {"status": status, "job_id": job_id}
        if progress is not None:
            update_data["progress"] = progress
        updates = ReportStatus(**update_data)
        return await self.update_job(job_id, updates)

    async def set_job_error(self, job_id: str, error: str) -> bool:
        """Set job error state."""
        updates = ReportStatus(job_id=job_id, status="failed", error=error)
        return await self.update_job(job_id, updates)

    async def set_job_completed(self, job_id: str) -> bool:
        """Mark job as completed."""
        updates = ReportStatus(
            job_id=job_id,
            status="completed",
            progress=1.0,
            completed_at=datetime.now().isoformat(),
        )
        return await self.update_job(job_id, updates)

    async def cancel_job(self, job_id: str) -> bool:
        """Cancel a job."""
        current_job = await self.get_job(job_id)
        if not current_job or current_job.status in ["completed", "failed"]:
            return False
        updates = ReportStatus(
            job_id=job_id, 
            status="cancelled", 
            error="Job cancelled by user"
        )
        return await self.update_job(job_id, updates)

    async def list_job_ids(self) -> List[str]:
        """Get list of all active job IDs for current user."""
        keyonline_user = await self._get_keyonline_user()
        result = await self._execute_function(
            "Product.report_jobs_list", [keyonline_user]
        )
        return [
            {
            "job_id": row["job_id"], 
            "companyid":row["report_title"],
            "companyname": row["report_title"], 
            "template": row["report_config"]["style"],
            "progress": row["progress"], 
            "status": row["status"],
            "created": row["created_at"]
            } 
            for row in result
        ] if result else []

    async def job_exists(self, job_id: str) -> bool:
        """Check if job exists for current user."""
        return (await self.get_job(job_id)) is not None

    async def reject_outline(
        self, 
        job_id: str, 
        revised_sections: Optional[int] = None, 
        revised_depth: Optional[int] = None
    ) -> bool:
        """Reject an outline and update job config with revised parameters."""
        current_job = await self.get_job(job_id)
        if not current_job:
            return False
        
        # Update config with revised parameters if provided
        updated_config = dict(current_job.report_config)
        if revised_sections is not None:
            updated_config["sections"] = revised_sections
        if revised_depth is not None:
            updated_config["depth"] = revised_depth
        
        updates = ReportStatus(
            job_id=job_id,
            status="initializing",
            progress=0.0,
            report_config=updated_config,
            outline=None  # Clear the outline
        )
        
        return await self.update_job(job_id, updates)

    def safe_json_dumps(self, value):
        return json.dumps(value) if value else None

    def safe_truncate(self, value, length=50):
        return value[:length] if value else None

    def safe_decimal(self, value):
        return Decimal(value) if value else None

    def safe_parse_dt(self, value):
        def parse_dt(dt_str):
            return (
                datetime.fromisoformat(dt_str.replace("Z", "+00:00"))
                if isinstance(dt_str, str) and dt_str
                else dt_str
            )
        return parse_dt(value) if value else None


def get_monitor(auth_token: str = None) -> ReportMonitor:
    """Get the global status tracker instance."""
    return ReportMonitor(auth_token=auth_token)