﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace Fis.Epp.Fusion.Auth.Models
{
    public enum ExceptionEnum
    {
        [Description("CorrelationId")]
        CorrelationId,
        [Description("validationKey")]
        validationKey,
        [Description("claims")]
        claims,
        [Description("token")]
        token,
        [Description("MemberId")]
        MemberId,
        [Description("RequestorId")]
        RequestorId,
        [Description("RequestUrl")]
        RequestUrl,
        [Description("ErrorStack")]
        ErrorStack,
        [Description("ErrorMessage")]
        ErrorMessage,
        [Description("FusionAuth")]
        FusionAuth,
        [Description("FeId")]
        FeId,
        [Description("UserId")]
        UserId,
        [Description("cipherText")]
        cipherText,
        [Description("request")]
        request,
        [Description("Key")]
        Key,
        [Description("IV")]
        IV,
        [Description("plainText")]
        plainText,
        [Description("ContextToken")]
        ContextToken
    }
}
