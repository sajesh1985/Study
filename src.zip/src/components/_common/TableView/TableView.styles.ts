import styled from '@emotion/styled';
import { css } from '@emotion/react';
import { AgGrid } from '@spglobal/koi-grid';
import { DARK } from '@spglobal/koi-helpers';
import { Breakpoints } from '@spglobal/tokens';

export const AgGridStyle = styled(AgGrid)<{ isAutoHeight?: boolean }>`
${({ isAutoHeight }) =>
  isAutoHeight &&
  css`
    .chatRDCustom & .ag-cell {
      display: block !important;
      min-height: 100%;
    }
  `}
  
  && .ag-row .ag-cell{
    align-items: flex-start;
  }

  .ag-cell-value {
    word-break: break-word;
    white-space: initial;
    word-wrap: break-word;
  }

  .ag-body-viewport{
      padding-bottom:15px !important;
  }

  .ag-cell {
    line-height: var(--scale-line-height-150) !important;
    padding: var(--size-space-xs);
  }
  
  .ag-body-horizontal-scroll{
    position: absolute !important;
    bottom: 0 !important;
  }

  .ag-cell-wrapper{
    overflow: hidden;
    display: -webkit-box !important;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
  }

  .ag-overlay-no-rows-center {
    color:var(--color-text-secondary)
  }

  .${DARK} & {
    .ag-header-row {
      background-color: var(--color-base-black);
    }

    .ag-popup-child input[type='date']{
      color-scheme: dark;
    }
  }
}
`;
export const ExportWrapperStyle = styled.div`
  display:flex;
  gap: var(--size-space-xs);
  margin-bottom: var(--size-space-md);
  @media (max-width: ${Breakpoints.SM}) {
    display: none;
  }
}
`;
