import logging
from typing import Optional

from chatrd.core.llm import LCLLMFactory
from chatrd.core.llm.parsers import PydanticOutputParser
from chatrd.core.llm.prompt.template import SimplePromptTemplate
from chatrd.engine.components.query_analyzer.faulttolerantexecutor import (
    FaultTolerantExecutor,
)
from chatrd.engine.components.query_analyzer.uc_subrouting.prompt_templates import (
    OUTLOOK_SUBROUTING_EXAMPLES,
    OUTLOOK_SUBROUTING_PARSER_TEMPLATE,
    OutlookSubrouting,
    OutlookSubroutingValues,
)

logger = logging.getLogger(__name__)


class OutlookSubrouter(FaultTolerantExecutor):
    def __init__(self, model_name: str, temperature: Optional[float] = 0.0):
        self.model = LCLLMFactory().get_llm(
            deployment_name_or_model_id=model_name,
            temperature=temperature,
        )

        self.output_parser = PydanticOutputParser(pydantic_object=OutlookSubrouting)
        self.prompt_template = SimplePromptTemplate(
            template=OUTLOOK_SUBROUTING_PARSER_TEMPLATE,
            partial_variables={
                "format_instructions": self.output_parser.get_format_instructions(),
                "examples": OUTLOOK_SUBROUTING_EXAMPLES,
            },
        )

    def run(self, query: str) -> str:
        question_prompt = self.prompt_template.format(question=query)
        output = self.model.invoke(question_prompt)
        result = self.output_parser.invoke(output)
        if not result.UseCase:
            raise ValueError("No UseCase found in the OutlookSubrouter.")
        elif result.UseCase.value not in [e.value for e in OutlookSubroutingValues]:
            raise ValueError(f"Got unsupported OutlookSubrouting value from the LLM. Result: {result.UseCase}")
        else:
            return result.UseCase.value
