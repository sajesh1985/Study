"""Basic components of LLM utilities."""

from abc import ABC, abstractmethod
from typing import Callable, Generic, Optional, TypeVar

from pydantic import BaseModel, ConfigDict, Field

from chatrd.core.llm.components.constants import LanguageModelInput, LanguageModelOutput
from chatrd.core.llm.components.tokenizer import Tokenizer

Input = TypeVar("Input", contravariant=True)
Output = TypeVar("Output", covariant=True)


class Runnable(Generic[Input, Output], ABC):
    """Unit of work that can be invoked, streamed in sync or async way."""

    name: Optional[str] = None

    @abstractmethod
    def invoke(self, *args, **kwargs):
        """Transform a single input into an output."""
        raise NotImplementedError(f"The '{self.name}' model has not yet implement the 'invoke' method.")

    @abstractmethod
    def ainvoke(self, *args, **kwargs):
        """Asynchronous invoke an LLM with the given arguments."""
        raise NotImplementedError(f"The '{self.name}' model has not yet implement the 'ainvoke' method.")

    @abstractmethod
    def stream(self, *args, **kwargs):
        """Provide stream response from an LLM."""
        raise NotImplementedError(f"The '{self.name}' model has not yet implement the 'stream' method.")

    @abstractmethod
    def astream(self, *args, **kwargs):
        """Provide asynchronous stream response from an LLM."""
        raise NotImplementedError(f"The '{self.name}' model has not yet implement the 'astream' method.")

    def get_name(self, suffix: Optional[str] = None) -> str:
        """Get the name of the model with an optional suffix."""
        name_ = None
        if self.name:
            name_ = self.name
        else:
            name_ = self.__class__.__name__

        if suffix:
            if name_[0].isupper():
                return name_ + suffix.title()
            return name_ + "_" + suffix.lower()
        return name_


class BaseLanguageModel(BaseModel, Runnable[LanguageModelInput, LanguageModelOutput]):
    """Base class for language models integrations.
    All language model wrappers inherited from BaseLanguageModel.
    """

    # Class variables, shared by all instances of BaseLanguageModel
    _LLM_VERBOSE: bool = False
    """Global verbosity setting for all language models."""

    # Pydantic instance fields
    custom_get_token_ids: Optional[Callable[[str], list[int]]] = Field(default=None, exclude=True)
    """Optional encoder to use for counting tokens."""

    model_config = ConfigDict(
        arbitrary_types_allowed=True,
    )

    @classmethod
    def set_verbose(cls, verbose: bool) -> None:
        """Set global verbosity for all language models."""
        if verbose and isinstance(verbose, bool):
            cls._LLM_VERBOSE = verbose
        else:
            raise ValueError("Verbose must be a boolean value.")

    @classmethod
    def get_verbose(cls) -> bool:
        """Get global verbosity setting."""
        return cls._LLM_VERBOSE

    def get_token_ids(self, text: str) -> list[int]:
        """Return the ids of the tokens in order they occur in the text.

        Args:
            text: The string input to tokenize.
        """
        if self.custom_get_token_ids is not None and callable(self.custom_get_token_ids):
            # Use the custom tokenization function if provided.
            return self.custom_get_token_ids(text)
        return self._get_token_ids_default_method(text)

    def get_num_tokens(self, text: str) -> int:
        """Get the number of tokens in the given text.

        Args:
            text: The string input to tokenize.
        """
        return len(self.get_token_ids(text))

    @staticmethod
    def _get_token_ids_default_method(text: str) -> int:
        """Default method to get token ids by encoding the text into tokens IDs."""
        tokenizer = Tokenizer()
        return tokenizer.encode(text)
