import logging
from typing import Any, Dict, List, Optional, Sequence

from chatrd.core.document import Document, TableDocument
from chatrd.core.document.text_splitters import TokenTextSplitter
from chatrd.core.llm.components import BaseLanguageModel
from chatrd.core.llm.prompt.template import LazyPromptTemplate
from chatrd.core.synthesizer import BaseResponseSynthesizer

logger = logging.getLogger(__name__)

DEFAULT_CONTEXT_TMPL = "\n{metadata_str}\n\n{content}"
DEFAULT_METADATA_TMPL = "{key}: {value}"


class CompactAndRefineSynthesizer(BaseResponseSynthesizer):
    context_window: int = 24576
    num_output_tokens: int = 1024
    buffer_tokens: int = 200
    chunk_overlap: int = 256

    context_template: str = DEFAULT_CONTEXT_TMPL
    metadata_template: str = DEFAULT_METADATA_TMPL
    exclude_llm_metadata_super_list: List = []

    def __init__(
        self,
        non_flex_llm: BaseLanguageModel,
        flex_llm: BaseLanguageModel,
        initial_prompt_template_str: str,
        refine_prompt_str: str,
        initial_prompt_template_flex_str: Optional[str] = None,
        expert_guidelines: Optional[str] = None,
        streaming: bool = True,
    ):
        self._non_flex_llm = non_flex_llm
        self._flex_llm = flex_llm
        self._streaming = streaming
        self._base_prompt_template = LazyPromptTemplate(
            template=initial_prompt_template_str,
            partial_variables={"guidelines": expert_guidelines},
            optional_variables=["context_str", "guidelines"],
        )

        self._base_prompt_template_flex = LazyPromptTemplate(
            template=initial_prompt_template_flex_str,
            partial_variables={"guidelines": expert_guidelines},
            optional_variables=["context_str", "query_str", "guidelines", "examples"],
        )

        self._refine_prompt_template = LazyPromptTemplate(
            template=refine_prompt_str,
            partial_variables={"guidelines": expert_guidelines},
            optional_variables=["context_str", "query_str", "guidelines", "examples"],
        )

    def update_prompt_templates(self, new_partial_variables: Dict) -> None:
        self._base_prompt_template.update_variables(**new_partial_variables)
        self._base_prompt_template_flex.update_variables(**new_partial_variables)
        self._refine_prompt_template.update_variables(**new_partial_variables)

    def get_response(
        self,
        message_str: str,
        chat_str: str,
        documents: Sequence[Dict],
        structured_response: Optional[Any] = None,
        **kwargs: Dict[str, Any],
    ) -> Any:
        self.update_prompt_templates(new_partial_variables={"query_str": chat_str})
        docs_string = self._construct_docs_string(documents)
        docs_string_chunks = self._split_docs_string(docs_string, self._base_prompt_template)
        if structured_response:
            initial_prompt_str = self._base_prompt_template_flex.format(
                context_str=docs_string_chunks[0], structured_component=structured_response
            )
            llm = self._flex_llm
        else:
            initial_prompt_str = self._base_prompt_template.format(context_str=docs_string_chunks[0])
            llm = self._non_flex_llm
        logger.info(f"\nIntial Prompt : \n{initial_prompt_str}")
        if self._streaming and (len(docs_string_chunks) == 1):
            response = llm.stream(initial_prompt_str)
            return response
        else:
            response = llm.invoke(initial_prompt_str)
            logger.info(f"\nIntial Response : \n{response if isinstance(response, str) else response.content}")

        if len(docs_string_chunks) > 1:
            while True:
                refine_docs_string_chunks = "\n\n".join(docs_string_chunks[1:])
                docs_string_chunks = self._split_docs_string(refine_docs_string_chunks, self._refine_prompt_template)
                refine_prompt_str = self._refine_prompt_template.format(
                    context_str=docs_string_chunks[0], existing_answer=response.content
                )
                logger.info(f"\nRefined Prompt : \n{refine_prompt_str}")
                if self._streaming and (len(docs_string_chunks) == 1):
                    response = llm.stream(refine_prompt_str)
                    return response
                else:
                    response = llm.invoke(refine_prompt_str)
                    logger.info(f"\nRefined Response : \n{response if isinstance(response, str) else response.content}")
                if len(docs_string_chunks) == 1:
                    return response
        return response

    def _split_docs_string(self, docs_string: str, prompt_template: LazyPromptTemplate) -> List[str]:
        return self._get_text_splitter(prompt_template=prompt_template).split_text(docs_string)

    def _get_text_splitter(self, prompt_template: LazyPromptTemplate):
        prompt_template_tokens = self._non_flex_llm.get_num_tokens(prompt_template.format(context_str=None))
        available_token_space = (
            self.context_window - self.buffer_tokens - self.num_output_tokens - prompt_template_tokens
        )
        return TokenTextSplitter(chunk_size=available_token_space, chunk_overlap=self.chunk_overlap)

    def _construct_docs_string(self, docs: Sequence[Document], **kwargs: Dict[str, Any]) -> str:
        formatted_docs_str = ""
        for doc in docs:
            metadata_str = "\n".join(
                [
                    self.metadata_template.format(key=key, value=str(value))
                    for key, value in doc.metadata.items()
                    if key not in self.exclude_llm_metadata_super_list
                ]
            )
            formatted_docs_str += (
                self.context_template.format(
                    metadata_str=metadata_str,
                    content=doc.original_table if isinstance(doc, TableDocument) else doc.content,
                )
                + "\n\n"
            )
        return formatted_docs_str
