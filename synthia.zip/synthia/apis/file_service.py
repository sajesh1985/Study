import asyncio
import json
import logging
import os
import uuid
from contextlib import asynccontextmanager
from functools import lru_cache
import boto3
from botocore.exceptions import ClientError
from botocore.config import Config
from typing import Dict, Any, Optional, List, Literal
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi import FastAPI, Depends, Header, APIRouter, UploadFile, File, Form, Request
from pydantic import BaseModel
from src.synthia.config.api_config import get_config
from src.synthia.persistence import document_queries
from src.synthia.persistence.database_manager import initialize_main_connection_pool, \
    close_connection_pool, get_postgres_conn_string
from src.synthia.services.document_service import DocumentService
# from src.synthia.user_profile.user_profile_provider import fetch_user_profile_data
from src.synthia.utils.logging_config import configure_logging
from src.synthia.utils.logging_context import set_correlation_id_logging_context, set_api_path_logging_context, \
    clear_logging_context, set_job_id_logging_context, set_file_id_logging_context


logger = configure_logging(logger_name=__name__, log_file="file_service.log", level=logging.DEBUG)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Starting up File Service API...")
    try:
        logger.info("Initializing connection pool...")
        postgres_connection_string = await get_postgres_conn_string()
        await initialize_main_connection_pool(postgres_connection_string, 1)
        logger.info("Connection pool initialized successfully")
    except Exception as e:
        logger.error(f"Failed to initialize database connection pool: {e}")
        raise

    yield
    logger.info("Closing connection pool...")
    await close_connection_pool()
    logger.info("Connection pool closed successfully")
    logger.info("Shutting down File Service API...")

cfg = get_config()
profile_data = {"KeyOnlineUser": -1899994831, "Email": "TestRDComb1@spglobal.com"}

app = FastAPI(
    title="File Service API",
    lifespan=lifespan,
    docs_url=f"{cfg['FILE_SERVICE_API_PREFIX']}/docs",
    redoc_url=f"{cfg['FILE_SERVICE_API_PREFIX']}/redoc",
    openapi_url=f"{cfg['FILE_SERVICE_API_PREFIX']}/openapi.json",
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.middleware("http")
async def add_logging_context(request: Request, call_next):
    """
    Middleware to set correlation_id, and api_path for logging.
    """
    correlation_id = request.headers.get("x-amzn-requestid")
    api_path = request.url.path
    set_correlation_id_logging_context(correlation_id)
    set_api_path_logging_context(api_path)
    try:
        response = await call_next(request)
        return response
    finally:
        clear_logging_context()


router = APIRouter()

ALLOWED_EXTENSIONS = {
    ".pdf", ".docx", ".txt", ".yml", ".yaml"
}

s3 = None
document_service = None

class UpdateDocumentRequest(BaseModel):
    file_id: str
    section_title: List[str]


class DocumentUploadUrlRequest(BaseModel):
    job_id: str
    file_name: str
    content_type: str
    section_title: Optional[List[str]] = None
    file_size: Optional[int] = None


class DocumentUploadUrlResponse(BaseModel):
    presigned_url: str
    file_id: str
    file_name: str
    expires_in: int


class DocumentUploadCompleteRequest(BaseModel):
    file_id: str
    job_id: str

class DocumentUploadCompleteResponse(BaseModel):
    status: Literal["success", "failure"]
    file_id: str
    message: Optional[str] = None

class UploadUrlRequest(BaseModel):
    file_name: str
    content_type: str
    file_size: Optional[int] = None


class UploadUrlResponse(BaseModel):
    presigned_url: str
    file_key: str
    expires_in: int
    

class DownloadUrlRequest(BaseModel):
    file_key: str


class DownloadUrlResponse(BaseModel):
    presigned_url: str
    expires_in: int


@lru_cache(maxsize=1)
def _get_max_file_size_from_config() -> Optional[int]:
    try:
        cfg = get_config()
        return cfg.get("max_file_size_mb")
    except Exception as e:
        logger.error(f"Failed to load config: {e}")
        return None

def get_token(authorization: str = Header(None)):
    """
    Dependency to extract the token from the Authorization header.
    """
    if not authorization:
        logger.warning("No Authorization header provided")
        return None

    return authorization


async def log_context_dependency(request: Request):
    job_id = request.path_params.get("job_id")
    if not job_id:
        try:
            body = await request.body()
            if body:
                data = json.loads(body)
                job_id = data.get("job_id")
        except Exception:
            job_id = None

    set_job_id_logging_context(job_id)

    file_id = request.path_params.get("file_id")
    if not file_id:
        try:
            body = await request.body()
            if body:
                data = json.loads(body)
                file_id = data.get("file_id")
        except Exception:
            file_id = None

    set_file_id_logging_context(file_id)


def correlation_id_dependency(request: Request):
    correlation_id = request.headers.get("x-amzn-requestid")
    return correlation_id


def get_s3_client():
    global s3
    if s3 is None:
        s3 = boto3.client(
            "s3",
            config=Config(
                signature_version='s3v4',
                region_name=os.getenv('AWS_REGION', 'us-east-1')
            )
        )
    return s3

def get_document_service():
    global document_service
    if document_service is None:
        document_service = DocumentService()
    return document_service

def generate_presigned_upload_url(bucket_name: str, file_key: str, content_type: str, expires_in: int = 3600) -> str:
    """
    Generate a presigned URL for uploading a file to S3.
    
    Args:
        bucket_name: S3 bucket name
        file_key: S3 object key (file path)
        content_type: MIME type of the file
        expires_in: URL expiration time in seconds (default: 1 hour)
    
    Returns:
        Presigned URL for uploading
    """
    try:
        s3_client = get_s3_client()
        presigned_url = s3_client.generate_presigned_url(
            'put_object',
            Params={
                'Bucket': bucket_name,
                'Key': file_key,
                'ContentType': content_type
            },
            ExpiresIn=expires_in
        )
        return presigned_url
    except Exception as e:
        logger.error(f"Error generating presigned upload URL: {e}")
        raise


def generate_presigned_download_url(bucket_name: str, file_key: str, expires_in: int = 3600) -> str:
    """
    Generate a presigned URL for downloading a file from S3.
    
    Args:
        bucket_name: S3 bucket name
        file_key: S3 object key (file path)
        expires_in: URL expiration time in seconds (default: 1 hour)
    
    Returns:
        Presigned URL for downloading
    """
    try:
        s3_client = get_s3_client()
        presigned_url = s3_client.generate_presigned_url(
            'get_object',
            Params={
                'Bucket': bucket_name,
                'Key': file_key
            },
            ExpiresIn=expires_in
        )
        return presigned_url
    except Exception as e:
        logger.error(f"Error generating presigned download URL: {e}")
        raise


def get_s3_bucket_name() -> str:
    """
    Get S3 bucket name from configuration.
    """
    try:
        config = get_config()
        # Try to get from config first, fallback to environment variable
        bucket_name = config.get("templates_s3_bucket", "creditmemo-templates-dev.us-east-1.cm-tl")
        return bucket_name
    except Exception as e:
        logger.error(f"Failed to get S3 bucket name: {e}")
        return "creditmemo-templates-dev.us-east-1.cm-tl"

@router.post("/generate-upload-url")
async def generate_upload_url(
        request: UploadUrlRequest,
        token: str = Depends(get_token)
) -> JSONResponse:
    """
    Generate a presigned URL for uploading a file directly to S3.
    """
    try:
        logger.info(f"Received token: {token[:20] + '...' if token and len(token) > 20 else token}")
        
        # Validate authentication
        if not token:
            logger.warning("No token provided in request")
            return JSONResponse(status_code=401, content={"error": "Authentication required"})
        
        # Get user profile for user-specific folder structure
        logger.debug(f"Fetching user profile data with token")
        # profile_data = await fetch_user_profile_data(token)
        keyonlineuser = profile_data["KeyOnlineUser"]
        logger.info(f"User authenticated: {keyonlineuser}")
        
        # Validate file extension
        file_extension = os.path.splitext(request.file_name)[1].lower()
        if file_extension not in ALLOWED_EXTENSIONS:
            return JSONResponse(
                status_code=400, 
                content={"error": f"File type not allowed. Allowed types: {', '.join(ALLOWED_EXTENSIONS)}"}
            )
        
        # Validate file size if provided
        max_file_size = _get_max_file_size_from_config()
        if max_file_size and request.file_size and request.file_size > max_file_size * 1024 * 1024:
            return JSONResponse(
                status_code=400,
                content={"error": f"File size exceeds maximum limit of {max_file_size}MB"}
            )
        
        # Generate unique file key with user-specific folder
        file_id = str(uuid.uuid4())
        # file_key = f"users/{keyonlineuser}/documents/{file_id}_{request.file_name}"
        file_key = request.file_name

        # Get S3 bucket name
        bucket_name = get_s3_bucket_name()
        
        # Generate presigned URL
        expires_in = 3600  # 1 hour
        presigned_url = generate_presigned_upload_url(
            bucket_name=bucket_name,
            file_key=file_key,
            content_type="application/octet-stream",
            expires_in=expires_in
        )
        
        logger.info(f"Generated upload URL for file: {request.file_name}, key: {file_key}")
        
        return JSONResponse(
            status_code=200,
            content=UploadUrlResponse(
                presigned_url=presigned_url,
                file_key=file_key,
                expires_in=expires_in
            ).model_dump()
        )
        
    except Exception as e:
        logger.error(f"Failed to generate upload URL: {e}", exc_info=True)
        return JSONResponse(status_code=500, content={"error": "Failed to generate upload URL"})


@router.post("/generate-download-url")
async def generate_download_url(
        request: DownloadUrlRequest,
        token: str = Depends(get_token)
) -> JSONResponse:
    """
    Generate a presigned URL for downloading a file from S3.
    """
    try:
        # Validate authentication
        if not token:
            return JSONResponse(status_code=401, content={"error": "Authentication required"})
        
        # Get user profile
        # profile_data = await fetch_user_profile_data(token)
        keyonlineuser = profile_data["KeyOnlineUser"]
        
        # Validate that the user has access to this file
        # Check if the file key belongs to the user's folder
        # if not request.file_key.startswith(f"users/{keyonlineuser}/"):
        #     # Also allow access to system/shared files
        #     if not request.file_key.startswith("system/"):
        #         return JSONResponse(status_code=403, content={"error": "Access denied to this file"})
        #
        # Get S3 bucket name
        bucket_name = get_s3_bucket_name()
        
        # Check if file exists in S3
        try:
            s3_client = get_s3_client()
            s3_client.head_object(Bucket=bucket_name, Key=request.file_key)
        except ClientError as e:
            if e.response['Error']['Code'] == '404':
                return JSONResponse(status_code=404, content={"error": "File not found"})
            else:
                logger.error(f"Error checking file existence: {e}")
                return JSONResponse(status_code=500, content={"error": "Error checking file"})
        except Exception as e:
            logger.error(f"Error checking file existence: {e}")
            return JSONResponse(status_code=500, content={"error": "Error checking file"})
        
        # Generate presigned URL
        expires_in = 3600  # 1 hour
        presigned_url = generate_presigned_download_url(
            bucket_name=bucket_name,
            file_key=request.file_key,
            expires_in=expires_in
        )
        
        logger.info(f"Generated download URL for file key: {request.file_key}")
        
        return JSONResponse(
            status_code=200,
            content=DownloadUrlResponse(
                presigned_url=presigned_url,
                expires_in=expires_in
            ).model_dump()
        )
        
    except Exception as e:
        logger.error(f"Failed to generate download URL: {e}", exc_info=True)
        return JSONResponse(status_code=500, content={"error": "Failed to generate download URL"})

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "service": "file-service"}

@app.get("/healthz")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "service": "file-service"}

@router.get("/documents")
async def list_documents(
        job_id: str,
        token: str = Depends(get_token),
        dep=Depends(log_context_dependency)
) -> JSONResponse:
    """
    List all documents for the authenticated user.
    """
    try:
        # profile_data = await fetch_user_profile_data(token)
        keyonlineuser = profile_data["KeyOnlineUser"]

        documents = await document_queries.list_document_records(keyonlineuser, job_id)
        return JSONResponse(status_code=200, content={"documents": documents})

    except Exception as e:
        logger.error(f"Failed to list documents: {str(e)}")
        return JSONResponse(status_code=500, content={"error": f"Failed to list documents: {str(e)}"})


@router.post("/document-upload-url")
async def document_upload_url(
        request: List[DocumentUploadUrlRequest],
        token: str = Depends(get_token),
        dep=Depends(log_context_dependency)
) -> JSONResponse:
    """
    Generate a presigned URL for uploading a file directly to S3.
    """

    async def process_single_request(requestx, keyonline_user, document_service_object):
        """Process a single upload request."""
        section_title = requestx.section_title
        if not requestx.section_title:
            section_title = ["all"]

        logger.info(f"Section title: {section_title}")
        logger.info(f"job id: {requestx.job_id}")

        file_id = str(uuid.uuid4())
        bucket_name, s3_prefix = await document_service_object.validate_and_get_s3_details(requestx.file_name,
                                                                                           requestx.file_size)

        file_key = f"{s3_prefix}{file_id}_{requestx.file_name}"

        await document_queries.save_document_record({
            "id": file_id,
            "file_name": requestx.file_name,
            "s3_uri": f"s3://{bucket_name}/{file_key}",
            "keyonlineuser": keyonline_user,
            "section_title": json.dumps(section_title),
            "file_size": requestx.file_size,
            "file_type": requestx.content_type,
            "job_id": requestx.job_id,
            "status": "pending",
        })

        expires_in = 3600  # 1 hour
        presigned_url = generate_presigned_upload_url(
            bucket_name=bucket_name,
            file_key=file_key,
            content_type="application/octet-stream",
            expires_in=expires_in
        )
        logger.info(f"Generated upload URL for file: {requestx.file_name}, key: {file_key}")

        return DocumentUploadUrlResponse(
            presigned_url=presigned_url,
            file_id=file_id,
            file_name=requestx.file_name,
            expires_in=expires_in
        ).model_dump()

    try:

        # profile_data = await fetch_user_profile_data(token)
        keyonlineuser = profile_data["KeyOnlineUser"]
        document_service_obj = get_document_service()

        tasks = [
            process_single_request(rex, keyonlineuser, document_service_obj)
            for rex in request
        ]

        response = await asyncio.gather(*tasks)

        return JSONResponse(
            status_code=200,
            content=response
        )

    except ValueError as ve:
        logger.warning(f"Validation error: {ve}", exc_info=True)
        return JSONResponse(status_code=400, content={"error": str(ve)})

    except Exception as e:
        logger.error(f"Unhandled exception: {e}", exc_info=True)
        return JSONResponse(status_code=500, content={"error": "Internal server error"})

@router.post("/upload-document-complete")
async def upload_document_complete(
        request: List[DocumentUploadCompleteRequest],
        token: str = Depends(get_token),
        dep=Depends(log_context_dependency)
) -> JSONResponse:
    try:

        # profile_data = await fetch_user_profile_data(token)
        keyonlineuser = profile_data["KeyOnlineUser"]

        response = []
        document_service_obj = get_document_service()
        kb_flag = False
        response_status = "failed"

        async def process_upload_complete_request(requestx, keyonline_user, document_service_object):
            """Process a single upload complete request."""
            file_data = await document_queries.get_document_record(requestx.file_id, keyonline_user)

            if not file_data or file_data['status'] == 'completed':
                if file_data:
                    await document_queries.update_document_status(
                        file_data['id'],
                        "completed" if file_data['status'] == 'completed' else "failed"
                    )

                return {
                    "response": DocumentUploadCompleteResponse(
                        status="failure",
                        file_id=requestx.file_id,
                        message="Document not found or access denied or completed.",
                    ).model_dump(),
                    "kb_flag": False,
                    "success": False
                }

            status = await document_service_object.update_document_complete(keyonline_user, file_data)

            if status["success"] is False:
                logger.error(f"File upload completion processing failed: {status.get('error')}")
                await document_queries.update_document_status(file_data['id'], "failed")

                return {
                    "response": DocumentUploadCompleteResponse(
                        status="failure",
                        file_id=requestx.file_id,
                        message=f"File upload completion processing failed: {status.get('error')}",
                    ).model_dump(),
                    "kb_flag": False,
                    "success": False
                }

            _kb_flag = not status["is_excel"]
            await document_queries.update_document_status(file_data['id'], "completed")

            return {
                "response": DocumentUploadCompleteResponse(
                    status="success",
                    file_id=requestx.file_id,
                ).model_dump(),
                "kb_flag": _kb_flag,
                "success": True
            }

        # Replace the original loop with:
        tasks = [
            process_upload_complete_request(requestx, keyonlineuser, document_service_obj)
            for requestx in request
        ]

        results = await asyncio.gather(*tasks)

        # Process results
        response = []
        kb_flag = False
        response_status = "failed"

        for result in results:
            response.append(result["response"])
            if result["kb_flag"]:
                kb_flag = True
            if result["success"]:
                response_status = "success"

        if kb_flag:
            kb_status = await document_service_obj.synchronize_knowledge_base()
            if not kb_status['success']:
                logger.error(f"Knowledge base synchronization failed: {kb_status.get('error')}")
        else:
            logger.info("No knowledge base synchronization needed.")

        return JSONResponse(status_code=200, content={"status": response_status, "message": f"files uploaded.", "details": response})

    except ValueError as ve:
        logger.warning(f"Validation error: {ve}", exc_info=True)
        return JSONResponse(status_code=400, content={"error": str(ve)})

    except Exception as e:
        logger.error(f"Unhandled exception: {e}", exc_info=True)
        return JSONResponse(status_code=500, content={"error": "Internal server error"})

@router.post("/upload-document")
async def upload_document(
        file: UploadFile = File(...),
        section_title: Optional[List[str]] = Form(None),
        job_id: str = Form(...),
        token: str = Depends(get_token),
        dep=Depends(log_context_dependency)
) -> JSONResponse:
    try:

        # profile_data = await fetch_user_profile_data(token)
        keyonlineuser = profile_data["KeyOnlineUser"]

        if not section_title:
            section_title = ["all"]

        logger.info(f"Section title: {section_title}")
        logger.info(f"job id: {job_id}")

        file_id = str(uuid.uuid4())
        document_service_obj = get_document_service()
        status = await document_service_obj.upload_document(file, file_id, keyonlineuser, section_title, job_id)

        if not status['success']:
            logger.error(f"File upload failed: {status.get('error')}")
            return JSONResponse(status_code=500, content={"error": "File upload failed.", "details": status.get('error')})

        return JSONResponse(status_code=200, content={"message": f"Successfully uploaded {file.filename} file.", "file_id": file_id})

    except ValueError as ve:
        logger.warning(f"Validation error: {ve}")
        return JSONResponse(status_code=400, content={"error": str(ve)})

    except Exception as e:
        logger.error(f"Unhandled exception: {e}", exc_info=True)
        return JSONResponse(status_code=500, content={"error": "Internal server error"})


@router.post("/update-document")
async def update_document(
        update_request: List[UpdateDocumentRequest],
        token: str = Depends(get_token),
        dep=Depends(log_context_dependency)
) -> JSONResponse:
    try:
        logger.info("update_request: %s", update_request)

        # profile_data = await fetch_user_profile_data(token)
        keyonlineuser = profile_data["KeyOnlineUser"]

        logger.info("update_request: %s", update_request)
        document_service_obj = get_document_service()

        for update in update_request:
            file_id = update.file_id
            section_title = update.section_title

            logger.info("file_id type: %s %s", type(file_id), file_id)
            logger.info("section_title type: %s %s", type(section_title), section_title)

            file_data = await document_queries.get_document_record(file_id, keyonlineuser)
            if not file_data:
                return JSONResponse(status_code=404, content={"error": "Document not found or access denied."})


            file_type = file_data['file_type']
            s3_uri = file_data['s3_uri']
            s3_uri = s3_uri.replace("s3://", "")
            _, s3_key = s3_uri.split("/", 1)

            s3_status = await document_service_obj.update_metadata_file(
                file_data['id'], file_data['job_id'], keyonlineuser, section_title, s3_key, file_type)

            if s3_status['success']:
                await document_queries.update_document_record(file_data['id'], section_title)
            else:
                logger.error(f"Failed to update metadata for file_id {file_data['id']}: {s3_status.get('error')}")

        kb_status = await document_service_obj.synchronize_knowledge_base()
        if not kb_status['success']:
            logger.error(f"Knowledge base synchronization failed: {kb_status.get('error')}")

        return JSONResponse(status_code=200, content={"message": "Document updated successfully."})

    except Exception as e:
        logger.error(f"Failed to update document: {e}", exc_info=True)
        return JSONResponse(status_code=500, content={"error": "Internal server error"})


app.include_router(router, prefix=cfg["FILE_SERVICE_API_PREFIX"])
