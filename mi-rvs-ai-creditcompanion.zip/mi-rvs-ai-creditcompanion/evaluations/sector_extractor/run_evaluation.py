import argparse
import pathlib
import time
from tqdm import tqdm

from evaluations.sector_extractor.utils import question_generator, setup_logging, load_model, load_data, convert_list_to_dict, generate_ground_truth_data_for_entity_extraction, compare_entities_and_save_results_to_txt


def init_parser():
    parser = argparse.ArgumentParser(
        description="""

        """
    )
    parser.add_argument(
        "--input-template-questions-path",
        type=str,
        help="input path of generated questions",
        default="evaluations/data/sector_extraction/generated_data/evaluation_questions.json"
    )
    parser.add_argument(
        "--models-list",
        type=lambda s: [str(item).strip() for item in s.split(",")],
        help="comma separated model_id list input",
        default="haiku,sonnet",
    )
    parser.add_argument(
        "--select-keys",
        type=lambda s: [str(item).strip() for item in s.split(",")],
        help="comma separated key list to keep",
        default="sector,subsector,industry",
    )
    parser.add_argument(
        "--prompt-id",
        type=str,
        help="prompt version used for evaluation",
        default="v1",
    )
    parser.add_argument(
        "--class-id",
        type=str,
        help="could be sector or non_sector",
        default="sector",
    )
    parser.add_argument(
        "--samples_per_class",
        type=int,
        help="samples per use case (-1 for all)",
        default=2
    )
    parser.add_argument(
        "--output-path",
        type=str,
        help="path to save the results",
        default="evaluations/sector_extractor/evaluation_results",
    )
    return parser


if __name__ == "__main__":

    parser = init_parser()
    logger = setup_logging()
    args = parser.parse_args()

    for model_id in args.models_list:
        
        logger.info(f"\nModel: {model_id}\nEval data id: {args.class_id}\n")
        
        sector_extractor = load_model(model_id)

        try:
            questions_subset = load_data(input_path = pathlib.Path(args.input_template_questions_path).resolve(), select_keys = args.select_keys, class_id = args.class_id, samples_per_class = args.samples_per_class, print_info = False)
        except Exception as e:
            logger.error(f"error {e} in loading file {args.input_template_questions_path}")
            exit(1)

        sector_extractor_predictions = {}
        sector_extractor_ground_truth = {}
        idx, execution_time = 0, 0.0
        for uc_type, questions_container in questions_subset.items():
            for question in tqdm(questions_container, desc=f"Processing {uc_type}"):
                # get the question and input key used for generating ground truth for sector, subsector, and industry
                input_keys = convert_list_to_dict(question[0])
                input_question = question[1]
                start_time = time.time()
                # predict the uc_type and sector, subsector, industry
                sector_extractor_predictions[idx] = {
                    'question': input_question, 
                    'output': sector_extractor.run(input_question, 'research')
                }
                execution_time += time.time() - start_time
                # ground truth for sector, subsector, industry
                sector_extractor_ground_truth[idx] = {
                    'question': input_question,
                    'output': generate_ground_truth_data_for_entity_extraction(input_keys_dict = input_keys)
                }
                idx += 1

        execution_time /= idx
        logger.info(f"--- Average time per sample: {round(execution_time, 2)} sec ---")
        
        compare_entities_and_save_results_to_txt(sector_extractor_ground_truth, sector_extractor_predictions, model_id, execution_time, args.prompt_id, args.class_id, args.output_path)
        logger.info(f"--- Prompt version: ./prompts/{args.prompt_id}_prompt.txt\n")
