import os

from dotenv import load_dotenv

from src.synthia.config.api_config import get_config

load_dotenv(override=True)

def getEnv():
    if os.getenv("LOCAL_URLS", "true").lower() in ("true", "1", "yes"):
        environment = "local"
    else:
        environment = "nonlocal"
    return environment

def getApiUrl():
    environment = getEnv()
    if(environment=="local"):
        return "http://localhost:8000"
    else:
        cfg = get_config()
        return cfg["credit_memo_api_url"]

def get_mcp_servers():
    """Return MCP server configs based on environment."""

    MCP_SERVER_SETS = {
        "local": {
            "ratings_data": {
                "url": "http://localhost:8111/agency-ratings/mcp",
                "transport": "streamable_http",
                "required": False
            },
            "company_information": {
                "url": "http://localhost:8113/company-overview/mcp",
                "transport": "streamable_http",
                "required": True
            },
            "company_financial": {
                "url": "http://localhost:8115/financials/mcp",
                "transport": "streamable_http",
                "required": False       
            },
            "company_industry": {
                "url": "http://localhost:8117/company-industry/mcp",
                "transport": "streamable_http",
                "required": False
            },
            "viz_chart": {
                "url": "http://localhost:8119/viz-chart/mcp",
                "transport": "streamable_http",
                "required": False
            },
            "company_peerdetails": {
                "url": "http://localhost:8121/company-peerdetails/mcp",
                "transport": "streamable_http",
                "required": False
            },
            "company_outlook": {
                "url": "http://localhost:8123/company-outlook/mcp",
                "transport": "streamable_http",
                "required": False
            },
            "company_news": {
                "url": "http://localhost:8125/company-news/mcp",
                "transport": "streamable_http",
                "required": False
            },
            "research_articles": {
                "url": "http://localhost:8127/research-articles/mcp",
                "transport": "streamable_http",
                "required": False
            },
            "company_keydevelops": {
                "url": "http://localhost:8129/company-keydevs/mcp",
                "transport": "streamable_http",
                "required": False
            },
            "knowledge_base": {
                "url": "http://localhost:8131/knowledge-base/mcp",
                "transport": "streamable_http",
                "required": False
            },
            "kensho_grounding": {
                "url": "http://localhost:8135/kensho-grounding/mcp",
                "transport": "streamable_http", 
                "required": False
            },
            "excel_prop_data": {
                "url": "http://localhost:8136/excel-prop-data/mcp",
                "transport": "streamable_http",
                "required": False
            }
        },
        "nonlocal": {
            "ratings_data": {
                "url": "https://7y73e32fn8.execute-api.us-east-1.amazonaws.com/dev/agency-ratings/mcp",
                "transport": "streamable_http",
                "required": False
            },
            "company_information": {
                "url": "https://7y73e32fn8.execute-api.us-east-1.amazonaws.com/dev/company-overview/mcp",
                "transport": "streamable_http",
                "required": True
            },
            "company_financial": {
                "url": "https://7y73e32fn8.execute-api.us-east-1.amazonaws.com/dev/financials/mcp",
                "transport": "streamable_http",
                "required": False
            },
            "company_industry": {
                "url": "https://7y73e32fn8.execute-api.us-east-1.amazonaws.com/dev/company-industry/mcp",
                "transport": "streamable_http",
                "required": False
            },
            "company_outlook": {
                "url": "https://7y73e32fn8.execute-api.us-east-1.amazonaws.com/dev/company-outlook/mcp",
                "transport": "streamable_http",
                "required": False
            },
            "company_news": {
                "url": "https://7y73e32fn8.execute-api.us-east-1.amazonaws.com/dev/company-news/mcp",
                "transport": "streamable_http",
                "required": False
            },
            "research_articles": {
                "url": "https://7y73e32fn8.execute-api.us-east-1.amazonaws.com/dev/research-articles/mcp",
                "transport": "streamable_http",
                "required": False
            },
            "company_keydevelops": {
                "url": "https://7y73e32fn8.execute-api.us-east-1.amazonaws.com/dev/company-keydevs/mcp",
                "transport": "streamable_http",
                "required": False
            },
            "company_peerdetails": {
                "url": "https://7y73e32fn8.execute-api.us-east-1.amazonaws.com/dev/company-peerdetails/mcp",
                "transport": "streamable_http",
                "required": False
            },
            "knowledge_base": {
                "url": "https://7y73e32fn8.execute-api.us-east-1.amazonaws.com/dev/knowledge-base/mcp",
                "transport": "streamable_http",
                "required": False
            },
            "kensho_grounding": {
                "url": "https://7y73e32fn8.execute-api.us-east-1.amazonaws.com/dev/kensho-grounding/mcp",
                "transport": "streamable_http", 
                "required": False
            },
            "excel_prop_data": {
                "url": "https://7y73e32fn8.execute-api.us-east-1.amazonaws.com/dev/excel-prop-data/mcp",
                "transport": "streamable_http",
                "required": False
            }
        }
    }

    environment = getEnv()

    # Use "local" if ENVIRONMENT is "local", else "nonlocal"
    key = "local" if environment == "local" else "nonlocal"
    return MCP_SERVER_SETS[key]

