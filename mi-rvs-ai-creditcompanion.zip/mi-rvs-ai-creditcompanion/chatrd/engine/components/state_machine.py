import logging
from abc import abstractmethod

from chatrd.engine.exceptions import RDException
from chatrd.engine.utils import ChatResponse, MessageRole

logger = logging.getLogger(__name__)


class StateMachine:
    def __init__(self, machine_role: str, failure_response: str, success_response: str):
        self.machine_role = machine_role
        self.failure_response = failure_response
        self.success_response = success_response

    @abstractmethod
    def _execute_internal(self, *args, **kwargs):
        pass

    def execute(self, *args, **kwargs):
        try:
            logger.info(f"Executing the state machine with the role {self.machine_role}!")
            response = self._execute_internal(*args, **kwargs)
            logger.info(self.success_response)

            return response
        except Exception as e:
            logger.exception(f"Some error occurred in the machine with role {self.machine_role}!")
            chat_response = ChatResponse(
                role=MessageRole.ASSISTANT,
                content=[[{"type": "error", "content": "Unable to process query, please try again!"}]],
                failure_step=self.machine_role,
            )
            raise RDException(response=chat_response, message=self.failure_response, inner_exception=e)
