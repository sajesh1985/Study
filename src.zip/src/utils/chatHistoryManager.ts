import { ChatHistoryResponse } from "@root/types/api";

export interface ChatHistoryGroup {
  [group: string]: any[];
}

function appendToKey(grps:ChatHistoryGroup,key:string,value:ChatHistoryResponse)
{
  if(key in grps){
    grps[key].push(value);
  }
  else
  {
    grps[key] = [value];
  }
}

export const groupChatHistoryOption = (data: ChatHistoryResponse[]) => {
  const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(today.getDate() - 1);

    const last30Days = new Date(today);
    last30Days.setDate(today.getDate() - 30);

    const last7Days = new Date(today);
    last7Days.setDate(today.getDate() - 7);

    let groups : ChatHistoryGroup = {
      'Today': [],
      'Yesterday': [],
      'Past Week':[],
      'Last 30 Days': []
    }; 

    data.forEach((resp: ChatHistoryResponse) => {
      if(resp.lastUpdatedDate)
      {
        let respTimeStamp = new Date(resp.lastUpdatedDate);
        if (respTimeStamp.getFullYear() == today.getFullYear() && today.getMonth() == respTimeStamp.getMonth() && respTimeStamp.getDate() == today.getDate()) {
          groups['Today'].push(resp);
        } else if (respTimeStamp.getFullYear() === yesterday.getFullYear() && yesterday.getMonth() == respTimeStamp.getMonth() && respTimeStamp.getDate() === yesterday.getDate()) {
          groups['Yesterday'].push(resp);
        } else if (respTimeStamp > last7Days) {
          groups['Past Week'].push(resp);
        } else if (respTimeStamp > last30Days) {
          groups['Last 30 Days'].push(resp);
        }else {
          appendToKey(groups,String(respTimeStamp.getFullYear()),resp);
        }
      }
    });

    return groups;

};

export const removeConsecutiveNumbers = (str: any) => {
  var regex = /\n/gi, str, indices = [];
  var result;
  while ( (result = regex.exec(str)) ) {
      indices.push(result.index);
  }
  return indices.filter((num:any,i:any,array:any ) =>{ 
    const prevIsCons = i > 0 && num === array[i-1] +1 ;
    const nextIsCons = i < array.length - 1 && num === array[i+1] -1;
    return !(prevIsCons || nextIsCons);
  })
}


