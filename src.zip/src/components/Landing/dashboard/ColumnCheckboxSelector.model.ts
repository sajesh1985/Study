import { IDateRangeValue, IDateRangeValueItem } from '@spglobal/koi-datepicker';
const feedbackSentiment = { label: 'FEEDBACK SENTIMENT', value: 'feedbackSentiment' };
const feedbackText = { label: 'FEEDBACK TEXT', value: 'feedbackText' };
const feedbackTags = { label: 'FEEDBACK TAGS', value: 'feedbackTags' };
const userInputValue = { label: 'USER INPUT VALUE', value: 'userInputValue' };
const requestTimeStamp = { label: 'REQUEST TIME STAMP', value: 'requestTimeStamp' };
const responseTimeStamp = { label: 'RESPONSE TIME STAMP', value: 'responseTimeStamp' };
const userInputType = { label: 'USER INPUT TYPE', value: 'userInputType' };
const sessionId = { label: 'SESSION ID', value: 'sessionId' };
const interactionId = { label: 'INTERACTION ID', value: 'interactionId' };
const previousInteractionId = { label: 'PREVIOUS INTERACTION ID', value: 'previousInteractionId' };

const dateRangeStart: IDateRangeValueItem = new Date(
  new Date().setMonth(new Date().getMonth() - 6)
);
const dateRangeEnd: IDateRangeValueItem = new Date();
export const dateRange: IDateRangeValue = [dateRangeStart, dateRangeEnd];

export const defaultSelectFiltersOptions = {
  filter1: [
    feedbackSentiment,
    feedbackText,
    feedbackTags,
    userInputValue,
    requestTimeStamp,
    responseTimeStamp,
    sessionId,
    interactionId,
    previousInteractionId
  ],
};
  
export const selectFiltersConfig = {
  filter1: {
    label: 'filter1',
    value: [
      feedbackSentiment,
      feedbackText,
      feedbackTags,
      userInputValue,
      requestTimeStamp,
      responseTimeStamp,
      userInputType,
      sessionId,
      interactionId,
      previousInteractionId,
    ],
  },
  filter2: {
    label: 'filter2',
    value: [
      { label: 'Positive', value: 'positive' },
      { label: 'Negative', value: 'negative' },
    ],
  },
  filter3: {
    label: 'filter3',
    value: [
      { label: 'Accuracy', value: 'accuracy' },
      ,
      { label: 'Completeness', value: 'completeness' },
    ],
  },
  filter4: {
    label: 'filter4',
    value: dateRange,
  },
  userInput: {
    label: 'userInput',
    value: '1',
  },
};

export const defaultSelectFiltersConfig = {
  filter1: {
    label: 'filter1',
    value: defaultSelectFiltersOptions.filter1,
  },
};

export const defaOptions = {
  filter2: [{ label: '', value: '' }],
  filter3: [{ label: '', value: '' }],
  filter4: dateRange,
};

export const defaConfig = {
  filter2: {
    label: 'filter2',
    value: [{ label: '', value: '' }],
  },
  filter3: {
    label: 'filter3',
    value: [{ label: '', value: '' }],
  },
  filter4: {
    label: 'filter4',
    value: dateRange,
  },
  userInput: {
    label: 'userInput',
    value: '',
  },
};
