﻿using Fis.Epp.Fusion.WebAPI.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Threading.Tasks;

namespace Fis.Epp.Fusion.Auth.Common
{
    public class EncryptDecryptHelper
    {
        #region Private Variables
        static byte[] Key = Convert.FromBase64String("+xXZ93MBZ9JBwLvKpBiat/cKpCxOrh3lgKICD9rOuW4=");
        static byte[] IV = Convert.FromBase64String("gtAvSsVEbWis4apMTZOXqg==");
        #endregion

        #region Private Methods
        public static string DecryptStringFromBytes_Aes(string input)
        {
            // Check arguments.
            if (input == null || input.Length <= 0)
                throw new ArgumentNullException(ExceptionEnum.cipherText.GetEnumDescription());
            if (Key == null || Key.Length <= 0)
                throw new ArgumentNullException(ExceptionEnum.Key.GetEnumDescription());
            if (IV == null || IV.Length <= 0)
                throw new ArgumentNullException(ExceptionEnum.IV.GetEnumDescription());

            byte[] cipherText = Convert.FromBase64String(input);
            // Declare the string used to hold
            // the decrypted text.
            string plaintext = null;

            // Create an Aes object
            // with the specified key and IV.
            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = Key;
                aesAlg.IV = IV;

                // Create a decrytor to perform the stream transform.
                ICryptoTransform decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV);

                // Create the streams used for decryption.
                using (MemoryStream msDecrypt = new MemoryStream(cipherText))
                {
                    using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                        {

                            // Read the decrypted bytes from the decrypting 
                            //stream
                            // and place them in a string.
                            plaintext = srDecrypt.ReadToEnd();
                        }
                    }
                }

            }

            return plaintext;
        }
        public static string EncryptStringToBytes_Aes(string plainText)
        {
            // Check arguments.
            if (plainText == null || plainText.Length <= 0)
                throw new ArgumentNullException(ExceptionEnum.plainText.GetEnumDescription());
            //if (Key == null || Key.Length <= 0)
            //    throw new ArgumentNullException(ExceptionHeaders.Key.ToString());
            //if (IV == null || IV.Length <= 0)
            //    throw new ArgumentNullException(ExceptionHeaders.IV.ToString());
            byte[] encrypted;
            // Create an Aes object
            // with the specified key and IV.
            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = Key;
                aesAlg.IV = IV;

                // Create a decrytor to perform the stream transform.
                ICryptoTransform encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);

                // Create the streams used for encryption.
                using (MemoryStream msEncrypt = new MemoryStream())
                {
                    using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                        {

                            //Write all data to the stream.
                            swEncrypt.Write(plainText);
                        }
                        encrypted = msEncrypt.ToArray();
                    }
                }
            }


            // Return the encrypted bytes from the memory stream.
            return Convert.ToBase64String(encrypted);

        }
        #endregion
    }
}
