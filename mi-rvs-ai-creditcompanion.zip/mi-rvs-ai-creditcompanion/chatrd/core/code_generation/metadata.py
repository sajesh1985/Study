import logging
from typing import Optional, Tuple, Union

import pandas as pd

logger = logging.getLogger(__name__)


def convert_column_types(df):
    for col in df.columns:
        converted = []
        for val in df[col]:
            try:
                converted.append(float(val))
            except Exception as e:
                # Else, treat as string
                logger.info(f"Could not convert {val} to float: {e}")
                converted.append(str(val))
        df.loc[:, col] = converted

    return df.fillna("")


def transform_table_passthrough(input_table: pd.DataFrame) -> pd.DataFrame:
    """
    No changes to the table, just return it as is.
    """

    return convert_column_types(input_table)


def transform_table_rename_financials(input_table: pd.DataFrame) -> Tuple:
    """
    Renames the 'Entity Name' and 'Company' column to 'Entity', if it exists.
    """
    keep_columns = None
    if ("Company" in input_table.columns) or ("Entity Name" in input_table.columns):
        input_table.rename(
            columns={
                "Company": "Entity",
                "Entity Name": "Entity",
            },
            inplace=True,
        )
    try:
        input_table["Metric Value"] = input_table.apply(
            lambda x: f"{'{:,.2f}'.format(float(x['Metricvalue']))} {x['Magnitude']} {x['Keycurrency']}",
            axis=1,
        )
        input_table["Metric Value"] = input_table["Metric Value"].str.replace(" None", "", regex=False)
        input_table = input_table[["Entity", "Metricname", "Period", "Metric Value"]]
        input_table.rename(
            columns={
                "Metricname": "Metric Name",
            },
            inplace=True,
        )
        keep_columns = ["Entity", "Metric Name", "Period", "Metric Value"]
    except Exception as e:
        logger.exception("General table format for financials")
        input_table.drop(columns=["definition", "Sort_Order"], inplace=True, errors="ignore")
        return (convert_column_types(input_table), keep_columns)
    return (convert_column_types(input_table), keep_columns)


def transform_table_rename_rating_action(input_table: pd.DataFrame) -> Tuple:
    """
    Renames the 'Entity Name' and 'Company' column to 'Entity', if it exists.
    """
    keep_columns = None
    if ("Company" in input_table.columns) or ("Entity Name" in input_table.columns):
        input_table.rename(
            columns={
                "Company": "Entity",
                "Entity Name": "Entity",
            },
            inplace=True,
        )
    try:
        if "Action Date" in input_table.columns:
            date_column = "Action Date"
        else:
            date_column = "Date"
        input_table["Rating Action"] = input_table.apply(
            lambda x: f"""{x["Action"]} ({x[date_column]}) to {x["To Rating"]} {x["To CreditWatch/Outlook"]} from {x["From Rating"]} {x["From CreditWatch/Outlook"]}""",
            axis=1,
        )
        input_table["Rating Action"] = input_table["Rating Action"].str.replace("|", "-", regex=False)
        input_table = input_table[["Entity", "Debt Type (Rating Type)", "Rating Action"]]
        keep_columns = ["Entity", "Debt Type (Rating Type)", "Rating Action"]
    except Exception as e:
        logger.error(f"Error while preparing Rating Action input: {e}")
        try:
            input_table = input_table[
                [
                    "Entity",
                    "Debt Type (Rating Type)",
                    "Action",
                    "Action Date",
                    "To Rating",
                    "From Rating",
                    "To CreditWatch/Outlook",
                    "From CreditWatch/Outlook",
                ]
            ]
            keep_columns = [
                "Entity",
                "Debt Type (Rating Type)",
                "Action",
                "Action Date",
                "To Rating",
                "From Rating",
                "To CreditWatch/Outlook",
                "From CreditWatch/Outlook",
            ]
            return (convert_column_types(input_table), keep_columns)
        except Exception as e:
            logger.error(f"Error while preparing Rating Action input: {e}")
            return (convert_column_types(input_table), keep_columns)
    return (convert_column_types(input_table), keep_columns)


def transform_table_rename_ratings(input_table: pd.DataFrame) -> Tuple:
    """
    Aligns table key with rating actions key
    """
    keep_columns = None
    if ("Rating Type" in input_table.columns) and ("Debt Type (Rating Type)" not in input_table.columns):
        input_table["Debt Type (Rating Type)"] = input_table["Rating Type"].apply(
            lambda x: "Issuer Credit Rating (" + x + ")" if x else None
        )
        input_table.drop(columns=["Rating Type"], inplace=True)
        input_table = input_table[[input_table.columns[-1]] + list(input_table.columns[:-1])]

    if "Debt Type(Rating Type)" in input_table.columns:
        input_table.rename(columns={"Debt Type(Rating Type)": "Debt Type (Rating Type)"}, inplace=True)

    try:
        input_table["Current Rating"] = input_table.apply(
            lambda x: f"""{x["Rating"]} {x["CreditWatch/Outlook"]}, Last Review Date: {x["Last Review Date"]}""",
            axis=1,
        )

        input_table = input_table[["Entity", "Debt Type (Rating Type)", "Current Rating"]]
        keep_columns = ["Entity", "Debt Type (Rating Type)", "Current Rating"]
    except Exception as e:
        logger.error(f"Error while preparing Ratings input: {e}")
        try:
            input_table = input_table[
                ["Entity", "Debt Type (Rating Type)", "Rating", "CreditWatch/Outlook", "Last Review Date"]
            ]
            keep_columns = ["Entity", "Debt Type (Rating Type)", "Rating", "CreditWatch/Outlook", "Last Review Date"]
            return (convert_column_types(input_table), keep_columns)
        except Exception as e:
            logger.error(f"Error while preparing Ratings input: {e}")
            return (convert_column_types(input_table), keep_columns)
    return (convert_column_types(input_table), keep_columns)


class MetadataEntry:
    def __init__(
        self,
        table_description: str,
        transformation,
        uc_specific_examples: list,
        table_key: Optional[Union[list, None]] = None,
    ):
        self.table_description = table_description
        self.transformation = transformation
        self.uc_specific_examples = uc_specific_examples
        if table_key is None:
            self.table_key = []
        else:
            self.table_key = table_key
        self.keep_columns = None

    def get_examples(self):
        return [f"""Question:\n{question}\n\nAnswer:\n{answer}""" for question, answer in self.uc_specific_examples]

    def transform_data(self, data_in: pd.DataFrame) -> pd.DataFrame:
        """
        Applies the transformation function to the data and returns the transformed DataFrame along with the keep_columns.
        """
        transformed_data, self.keep_columns = self.transformation(data_in)
        return transformed_data

    def prompt_keep_columns(self):
        """
        Adds the keep_columns to the prompt if they are defined.
        """
        output = ""
        if self.keep_columns:
            output = """You ALWAYS MUST KEEP these columns in the output table.\n"""
            output += "\n".join(["- " + col_name for col_name in self.keep_columns])
            if "Debt Type (Rating Type)" in self.keep_columns:
                output += "\n'Debt Type (Rating Type)' column always MUST be present, even if it takes a single value. Follow this instruction closely, make sure to keep it in the output.\n"
            output += "\nAs per the columns unlisted above, you can decide if they are needed in the output or not.\n"

        return output

    def list_table_key(self):
        """
        Lists the table key columns if they are defined.
        """
        output = ""
        if self.table_key:
            output = "\n**Table Key columns:**\n"
            output += "\n".join(["  - " + entry for entry in self.table_key])
            output += "\n\n"
        return output


TABLE_METADATA = {
    "ratings": MetadataEntry(
        table_description="""
                        This DataFrame contains information about credit ratings data of entity mentioned in the provided task.
                        The data includes only current ratings and outlooks.
                        Any question about 'current rating' references the date of the rating, rather than Short Term type of rating. When asked about 'current rating' do not apply additional filters to account for this typw of rating, as the data already contains only current ratings.
                        You MUST NOT filter by debt type or rating type, as the DataFrame already contains only relevant records.
                        """.strip(),
        transformation=transform_table_rename_ratings,
        table_key=["Entity", "Debt Type (Rating Type)"],
        uc_specific_examples=[
            [
                "Show me current ratings for company xyz",
                "# Current ratings data, select all ratings\ncurrent_ratings_df",
            ],
            [
                "Show me current issuer credit rating for abc",
                "# Current ratings data, this dataset contains only issuer credit ratings\ncurrent_ratings_df",
            ],
            [
                "Show me current long term rating for xyz",
                "# Current ratings data, select long term rating\ncurrent_ratings_df['LT' in current_ratings_df['Debt Type (Rating Type)']]",
            ],
            [
                "Show me current Foreign Currency rating",
                "# Current ratings data, select foreign currency rating.\ncurrent_ratings_df[current_ratings_df['Debt Type (Rating Type)'].str.contains('Foreign Currency')]",
            ],
        ],
    ),
    "rating_action": MetadataEntry(
        table_description="""
                        This DataFrame contains information about rating action for entities mentioned in the provided task.
                        Do not sort the DataFrame by date, as all records per a single entity have the same date.
                        Do not filter the DataFrame by date to get the most rating action, as only the most recent date is provided.
                        Do not select top 1 record of the DataFrame, as there are multiple rating actions per entity on the same date.
                        Do not filter the DataFrame by action type (upgrade or downgrade), as the DataFrame is filtered accordingly.
                        You MUST NOT filter by debt type or rating type, as the DataFrame already contains only relevant records, unless the user specifies a specific debt type or rating type.
                        Refer to this table to address queries regarding the latest rating actions for entities (what the most recent rating action was), including indirect questions such as how the ratings have evolved over time.
                        """.strip(),
        transformation=transform_table_rename_rating_action,
        table_key=["Entity", "Debt Type (Rating Type)"],
        uc_specific_examples=[
            [
                "Show me the most recent rating action for company xyz",
                "# Rating action data is already filtered by the most recent date, so no need to filter by date.\n# The query does not specify any requirements about rating action debt type or rating type, no additional filters applied.\nrating_action_df",
            ],
            [
                "Show me the most recent rating update for xyz",
                "# Rating action data is already filtered by the most recent date and rating action type (update), so no need to filter..\n# The query does not specify any requirements about rating action debt type or rating type, no additional filters applied.\nrating_action_df",
            ],
            [
                "Show me the most recent rating action for Local Currency rating",
                "# Rating action data is already filtered by the most recent date, so no need to filter by date.\n# Local currency rating requested, the data needs to be filtered accordingly\nrating_action_df[rating_action_df['Debt Type (Rating Type)'].str.contains('Local Currency')]",
            ],
            [
                "How have ABC's company ratings changed over the last year?",
                "The question refers to how the ratings have evolved over time, so we need to refer to the rating action data.\n# Rating action data is already filtered by the most recent date, so no need to filter by date.\n# The query does not specify any requirements about rating action debt type or rating type, no additional filters applied.\n# Ratings DataFrame contains information about rating action for entities mentioned in the provided task, so there is no need to filter by entity\nrating_action_df",
            ],
        ],
    ),
    "financials": MetadataEntry(
        table_description="""
                        This DataFrame contains different financial metrics for entities mentioned in the task.
                        When user request financial highlights or key financials for a single company,the table will be returned as-is without applying any filters.
                        When the user requests financial highlights, the table will contain a default selection of metrics, and the periods will be provided in columns.
                        When the user specifies metrics, the periods will be kept in a column called Periods.
                        The data covers only requested metrics and periods.
                        When the user specifies entities, assume the data is already filtered to include only the mentioned entities. In such cases, avoid applying additional entity-based filtering, as it is unnecessary and redundant.
                        It may happen, that a different set of metrics is provided than requested by the user. In such case the most similar metrics are already provided. Do not filter the DataFrame by metric name.
                        There is no need to filter by period, as the data already contains only requested periods.
                        Avoid pivoting the table if there is a risk of introducing null values. This includes scenarios where a specific metric is missing for an entity in a given period or when periods are inconsistent across entities (e.g., a mix of annual and quarterly data).
                        When you see that the same set of metrics is available for all entities and periods, you can pivot the table to have periods in columns.
                        When the periods are provided in a column named 'Period', they are already correctly formatted (e.g., '2023Q1' for Q1 2023, '2022Y' for the year 2022). Do not change the format.
                        """.strip(),
        transformation=transform_table_rename_financials,
        table_key=["Entity"],
        uc_specific_examples=[
            [
                "Show me the key financials",
                "# Financial metrics data, contains metrics mentioned in the question, no need to filter\nfinancials_df",
            ],
            [
                "Show me financial highlights for ABC company",
                "# Financial metrics data for a single company, return the table as-is without filtering\nfinancials_df",
            ],
            [
                "Show me adjusted revenue for XYZ company for 2022",
                "# Financial metrics data, contains metrics and entities mentioned in the question for the requested period, no need to filter or change period format\nfinancials_df",
            ],
            [
                "what is ebitda, revenue, debt to income ratio for Q3 and Q4 of 2010 for companies ABC and DEF",
                "# The DataFrame financials_df contains only periods, entities and metrics mentioned in the question, so no need to filter by period nor change period format. Period column format is correct, it needs to be kept as is.",
            ],
            [
                "Show me revenue and net income for ABC company",
                "# The DataFrame financials_df contains financial metrics data, which may include a different set of metrics than requested by the user."
                "# The most similar metrics are already provided. Do not filter the DataFrame by metric name."
                "# The data covers entites mentioned by the user. Do not filter the DataFrame by company name.",
            ],
            [
                "Show me debt to income ratio and income for Q1 2023 for ABC and XYZ companies",
                "# The DataFrame financials_df contains only periods and companies mentioned in the question, so no need to filter by period or company name. Period column format is correct, it needs to be kept as is.",
            ],
        ],
    ),
    "ratings_rating_action_combined": MetadataEntry(
        table_description="""
                        This DataFrame contains combined information about rating actions and curent credit ratings of entities mentioned in the provided task.
                        Use this table when the user requests both current ratings and rating actions, including indirect queries about how ratings have changed over a specific period.
                        There is one record per entity, and only requested entities are provided. Do not filter the data by entity name.
                        The data is provided for the Debt Type (Rating Type) selected by the user. Do not filter by Debt Type (Rating Type), as the DataFrame already contains only relevant records.
                        Ratings data includes only current ratings and outlooks. Do not filter the data by rating date, as the data already contains only current ratings.
                        Rating action data contains the most recent rating actions per entity. Do not sort the DataFrame by date and do not select top 1 record.
                        Do not filter the DataFrame by action type (upgrade or downgrade), as the DataFrame is filtered accordingly.
                        """.strip(),
        transformation=lambda x: x,
        table_key=["Entity", "Debt Type (Rating Type)"],
        uc_specific_examples=[
            [
                "Show me current ratings and rating actions for company xyz",
                "# The data contains only relevant data for ratings and rating action, returning unmodified table\nratings_rating_action_combined_df",
            ],
            [
                "Show me current ratings and the most recent rating action for xyz",
                "# The data contains only relevant data for ratings and rating action, no need to select the most recent rating action. Returning unmodified table\nratings_rating_action_combined_df",
            ],
            [
                "Show me current issuer credit rating and the most recent rating action",
                "# The data contains only relevant data for ratings and rating action, returning unmodified table\nratings_rating_action_combined_df",
            ],
            [
                "Show me current ratings of ABC company and describe how they change over the last year.",
                "# This table addresses questions about current ratings and how they have changed over time (rating change component). It provides all necessary information.\n# The data includes only relevant details for ratings and rating actions, returning the table unmodified.\nratings_rating_action_combined_df",
            ],
        ],
    ),
}
