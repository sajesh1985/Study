from typing import Any, Optional

from pydantic import Field


class BaseMedia:
    """Used to represent media content."""

    id: Optional[str] = Field(default=None, coerce_numbers_to_str=True)
    """An optional identifier for the document, that should be unique across the document collection.
    Formatted as a UUID."""

    metadata: dict = Field(default_factory=dict)
    """Arbitrary metadata associated with the content."""


class MediaDocument(BaseMedia):
    """Class for storing a piece of text and associated metadata."""

    page_content: str

    def __init__(self, page_content: str, **kwargs: Any) -> None:
        self.page_content = page_content
        self.metadata = kwargs.pop("metadata", {})
        self.__dict__.update(kwargs)  # Update the instance with any additional keyword arguments

    def __str__(self) -> str:
        if self.metadata:
            return f"page_content='{self.page_content}' metadata={self.metadata}"
        return f"page_content='{self.page_content}'"

    def __eq__(self, other: Any) -> bool:
        if not isinstance(other, MediaDocument):
            return False
        return self.page_content == other.page_content and self.metadata == other.metadata and self.id == other.id
