import logging
from typing import Dict

from chatrd.core.thread_utils import submit_to_shared_thread_pool
from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.data_service.analyzer import (
    AnalystAndSectorInfoAnalyzer,
    FinancialMetricsAnalyzer,
    ListofSecuritiesAnalyzer,
    QueryAnalyzer,
    RatingActionAnalyzer,
    RatingsAnalyzer,
)
from chatrd.engine.data_service.processor.utils import merge_synthesizer_outputs
from chatrd.engine.data_service.retriever import (
    AnalystSectorRetriever,
    CompanyCreditHistoryRetriever,
    CompanyQueryRetriever,
    CompanyRatingsRetriever,
    EntityDefaultRatingRetriever,
    EntityRecentActionsRetriever,
    FinancialMetricsRetriever,
    FinancialRetriever,
    ListOfSecuritiesRetriever,
    PeersRetriever,
    RatingActionRetriever,
    RevenueSourceRatingsRetriever,
    ScoresModifierRetriever,
    SectorInfoRetriever,
    SecurityCreditHistoryRetriever,
    SecurityRatingsRetriever,
    SFDealsRetriever,
    SFSingleTrancheRetriever,
    USPFRetriever,
)
from chatrd.engine.data_service.schema import ProcessorInput, ProcessorOutput
from chatrd.engine.data_service.synthesizer import (
    AnalystPeerSynthesizer,
    AnalystSectorSynthesizer,
    CompanyCreditHistorySynthesizer,
    CompanyRatingsSynthesizer,
    EntityDefaultRatingSynthesizer,
    FinancialHighlightsSynthesizer,
    FinancialMetricsSynthesizer,
    GenericQuerySynthesizer,
    ListOfSecuritiesSynthesizer,
    MultiEntityRatingActionSynthesizer,
    RatingActionSynthesizer,
    RevenueSourceRatingsSynthesizer,
    ScoresModifiersSynthesizer,
    SectorInfoSynthesizer,
    SecurityCreditHistorySynthesizer,
    SecurityRatingsSynthesizer,
    SFDealsSynthesizer,
    SFSingleTrancheSynthesizer,
    USPFSynthesizer,
)
from chatrd.engine.data_service.utils import get_entity_type, get_rd_sector

logger = logging.getLogger(__name__)
config_machinery = get_config_machinery()
RDKOS_SF = config_machinery.get_config_value(Constants.GeneralConstants.RDKOS_SF)

DEFAULT_MESSAGE = "CreditCompanion<sup>TM</sup> is unable to provide any response."


class Processor:
    def response(self, processor_input: ProcessorInput) -> Dict:
        uc_type = processor_input.uc_type
        entities = processor_input.entities
        entity_type = get_entity_type(entities)
        rd_sector = get_rd_sector(entities)
        multi_uc_type = processor_input.multi_uc_type

        if uc_type == "financial":
            analyzed = FinancialMetricsAnalyzer().analyze(processor_input)
            metrics = analyzed.response["metrics"]
            metrics_processing = metrics and metrics != ["General"]
            if metrics_processing:
                Retriever = FinancialMetricsRetriever
                Synthesizer = FinancialMetricsSynthesizer
                retrieved = Retriever().retrieve(processor=processor_input, analyzer=analyzed)
                synthesized = Synthesizer().synthesize(
                    processor=processor_input, analyzer=analyzed, retriever=retrieved, multi_uc_type=multi_uc_type
                )
                if synthesized.error_flag:
                    processor_input.error_flag = True
                    processor_input.template = synthesized.template
            if not metrics_processing or processor_input.error_flag:
                Retriever = FinancialRetriever
                Synthesizer = FinancialHighlightsSynthesizer
                retrieved = Retriever().retrieve(processor=processor_input)
                synthesized = Synthesizer().synthesize(
                    processor=processor_input, analyzer=analyzed, retriever=retrieved, multi_uc_type=multi_uc_type
                )
            processed = ProcessorOutput(retrieved, synthesized)
        elif uc_type == "peers":
            Retriever = PeersRetriever
            Synthesizer = AnalystPeerSynthesizer
            retrieved = Retriever().retrieve(processor=processor_input)
            synthesized = Synthesizer().synthesize(processor=processor_input, retriever=retrieved)
            processed = ProcessorOutput(retrieved, synthesized)
        elif uc_type == "scores&modifiers":
            Retriever = ScoresModifierRetriever
            Synthesizer = ScoresModifiersSynthesizer
            retrieved = Retriever().retrieve(processor=processor_input)
            synthesized = Synthesizer().synthesize(processor=processor_input, retriever=retrieved)
            processed = ProcessorOutput(retrieved, synthesized)
        elif uc_type == "deals_tranche":
            Retriever = SFDealsRetriever
            Synthesizer = SFDealsSynthesizer
            retrieved = Retriever().retrieve(processor=processor_input)
            synthesized = Synthesizer().synthesize(processor=processor_input, retriever=retrieved)
            processed = ProcessorOutput(retrieved, synthesized)
        elif uc_type == "securities":
            analyzed = ListofSecuritiesAnalyzer().analyze(processor_input)
            Retriever = ListOfSecuritiesRetriever
            Synthesizer = ListOfSecuritiesSynthesizer
            retrieved = Retriever().retrieve(processor=processor_input, analyzer=analyzed)
            synthesized = Synthesizer().synthesize(processor=processor_input, analyzer=analyzed, retriever=retrieved)
            processed = ProcessorOutput(retrieved, synthesized)
        elif uc_type == "info_coverage":
            analyzed = AnalystAndSectorInfoAnalyzer().analyze(processor_input)
            ds_tag = analyzed.ds_tag
            if ds_tag == "analyst_sector":
                Retriever = AnalystSectorRetriever
                Synthesizer = AnalystSectorSynthesizer
                retrieved = Retriever().retrieve(processor=processor_input)
                synthesized = Synthesizer().synthesize(processor=processor_input, retriever=retrieved)
                processed = ProcessorOutput(retrieved, synthesized)
            elif ds_tag == "sector_information":
                Retriever = SectorInfoRetriever
                Synthesizer = SectorInfoSynthesizer
                retrieved = Retriever().retrieve(processor=processor_input)
                synthesized = Synthesizer().synthesize(processor=processor_input, retriever=retrieved)
                processed = ProcessorOutput(retrieved, synthesized)
            else:
                logger.info(DEFAULT_MESSAGE)
                return ProcessorOutput().dict()
        # multi uc_type handling - to be added
        elif uc_type == "rating_action" and ((len(processor_input.entities["companies"]) > 1) or multi_uc_type):
            analyzed = RatingActionAnalyzer().analyze(processor_input)
            Retriever = EntityRecentActionsRetriever
            Synthesizer = MultiEntityRatingActionSynthesizer
            retrieved = Retriever().retrieve(processor=processor_input, analyzer=analyzed, multi_uc_type=multi_uc_type)
            synthesized = Synthesizer().synthesize(processor=processor_input, analyzer=analyzed, retriever=retrieved)
            processed = ProcessorOutput(retrieved, synthesized)
        elif uc_type == "rating_action":
            analyzed = RatingActionAnalyzer().analyze(processor_input)
            Retriever = RatingActionRetriever
            Synthesizer = RatingActionSynthesizer
            retrieved = Retriever().retrieve(processor=processor_input, analyzer=analyzed)
            synthesized = Synthesizer().synthesize(processor=processor_input, analyzer=analyzed, retriever=retrieved)
            processed = ProcessorOutput(retrieved, synthesized)
        elif uc_type in ["ratings", "outlook"]:
            analyzed = RatingsAnalyzer().analyze(processor_input)
            ds_tag = analyzed.ds_tag
            if ds_tag == "current ratings" and ((len(entities["companies"]) > 1) or multi_uc_type):
                Retriever = EntityDefaultRatingRetriever
                Synthesizer = EntityDefaultRatingSynthesizer
                retrieved = Retriever().retrieve(processor=processor_input, analyzer=analyzed)
                synthesized = Synthesizer().synthesize(
                    processor=processor_input, analyzer=analyzed, retriever=retrieved
                )
                processed = ProcessorOutput(retrieved, synthesized)
                return processed.dict()
            elif "U.S. Public Finance" in rd_sector:
                # For both current and historical ratings, USPF is handled via USPFRetriever and USPFSynthesizer
                Retriever = USPFRetriever
                Synthesizer = USPFSynthesizer
                retrieved = Retriever().retrieve(processor=processor_input, analyzer=analyzed)
                if retrieved.total_count == 0 and (
                    "Structured Finance" in rd_sector or "Financial Institutions" in rd_sector
                ):
                    # The previous retriever returned no useful response, go for the SF retriever and synthesizer
                    Retriever = SFDealsRetriever
                    Synthesizer = SFDealsSynthesizer
                    retrieved = Retriever().retrieve(processor=processor_input, analyzer=analyzed)

                synthesized = Synthesizer().synthesize(
                    processor=processor_input, analyzer=analyzed, retriever=retrieved
                )
                processed = ProcessorOutput(retrieved, synthesized)
            else:
                if ds_tag == "current ratings":
                    if entity_type == "security":
                        if RDKOS_SF in entities["securities"][0]["security_sector"]:
                            Retriever = SFSingleTrancheRetriever
                            Synthesizer = SFSingleTrancheSynthesizer
                            retrieved = Retriever().retrieve(processor=processor_input, analyzer=analyzed)
                            synthesized = Synthesizer().synthesize(
                                processor=processor_input, analyzer=analyzed, retriever=retrieved
                            )
                            processed = ProcessorOutput(retrieved, synthesized)
                        else:
                            Retriever = SecurityRatingsRetriever
                            Synthesizer = SecurityRatingsSynthesizer
                            retrieved = Retriever().retrieve(processor=processor_input, analyzer=analyzed)
                            synthesized = Synthesizer().synthesize(
                                processor=processor_input, analyzer=analyzed, retriever=retrieved
                            )
                            processed = ProcessorOutput(retrieved, synthesized)
                    elif entity_type == "revenue_source":
                        Retriever = RevenueSourceRatingsRetriever
                        Synthesizer = RevenueSourceRatingsSynthesizer
                        retrieved = Retriever().retrieve(processor=processor_input, analyzer=analyzed)
                        synthesized = Synthesizer().synthesize(
                            processor=processor_input, analyzer=analyzed, retriever=retrieved
                        )
                        processed = ProcessorOutput(retrieved, synthesized)
                    elif entity_type == "company":
                        # ratingAPI call & output synthesizer
                        Retriever_ratings = ListOfSecuritiesRetriever
                        Synthesizer_ratings = ListOfSecuritiesSynthesizer
                        future_retrieved_ratings = submit_to_shared_thread_pool(
                            Retriever_ratings().retrieve, processor=processor_input
                        )

                        # screenerAPI call
                        Retriever = CompanyRatingsRetriever
                        Synthesizer = CompanyRatingsSynthesizer
                        future_retrieved = submit_to_shared_thread_pool(
                            Retriever().retrieve, processor=processor_input, analyzer=analyzed
                        )

                        retrieved = future_retrieved.result()
                        retrieved_ratings = future_retrieved_ratings.result()

                        if retrieved.total_count == 0:
                            # Go for USPF if screener returns no response
                            if "U.S. Public Finance" in rd_sector:
                                Retriever = USPFRetriever
                                Synthesizer = USPFSynthesizer
                                retrieved = Retriever().retrieve(processor=processor_input, analyzer=analyzed)

                            # Go for SF if screener or USPF returns no response (USPF-SF dual mapped case)
                            if retrieved.total_count == 0 and (
                                "Structured Finance" in rd_sector or "Financial Institutions" in rd_sector
                            ):
                                Retriever = SFDealsRetriever
                                Synthesizer = SFDealsSynthesizer
                                retrieved = Retriever().retrieve(processor=processor_input, analyzer=analyzed)

                            if retrieved.total_count == 0:
                                logger.info(DEFAULT_MESSAGE)
                                return ProcessorOutput().dict()

                            synthesized = Synthesizer().synthesize(
                                processor=processor_input, analyzer=analyzed, retriever=retrieved
                            )
                            processed = ProcessorOutput(retrieved, synthesized)

                        else:
                            retrieved_screener = retrieved
                            # screenerAPI output synthesizer
                            synthesized = Synthesizer().synthesize(
                                processor=processor_input, analyzer=analyzed, retriever=retrieved_screener
                            )

                            if synthesized.source_description != []:
                                # output synthesizer
                                synthesized_ratings = Synthesizer_ratings().synthesize(
                                    processor=processor_input, retriever=retrieved_ratings
                                )

                                synthesized = merge_synthesizer_outputs(synthesized, synthesized_ratings)

                            processed = ProcessorOutput(retrieved_screener, synthesized)
                    else:
                        logger.info(DEFAULT_MESSAGE)
                        return ProcessorOutput().dict()
                if ds_tag == "historical ratings":
                    if entity_type == "company":
                        Retriever = CompanyCreditHistoryRetriever
                        Synthesizer = CompanyCreditHistorySynthesizer
                        retrieved = Retriever().retrieve(processor=processor_input, analyzer=analyzed)
                        synthesized = Synthesizer().synthesize(
                            processor=processor_input, analyzer=analyzed, retriever=retrieved
                        )
                        processed = ProcessorOutput(retrieved, synthesized)
                    elif entity_type == "security":
                        Retriever = SecurityCreditHistoryRetriever
                        Synthesizer = SecurityCreditHistorySynthesizer
                        retrieved = Retriever().retrieve(processor=processor_input, analyzer=analyzed)
                        synthesized = Synthesizer().synthesize(
                            processor=processor_input, analyzer=analyzed, retriever=retrieved
                        )
                        processed = ProcessorOutput(retrieved, synthesized)
                    else:
                        logger.info(DEFAULT_MESSAGE)
                        return ProcessorOutput().dict()
        elif uc_type == "query":
            analyzed = QueryAnalyzer().analyze(processor_input)
            Retriever = CompanyQueryRetriever
            Synthesizer = GenericQuerySynthesizer
            retrieved = Retriever().retrieve(processor=processor_input, analyzer=analyzed)
            synthesized = Synthesizer().synthesize(processor=processor_input, analyzer=analyzed, retriever=retrieved)
            processed = ProcessorOutput(retrieved, synthesized)
        else:
            logger.info(DEFAULT_MESSAGE)
            return ProcessorOutput().dict()

        return processed.dict()
