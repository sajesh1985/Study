﻿namespace Fis.Epp.Fusion.WebAPI.Common
{
    using Fis.Epp.Fusion.WebAPI.Models;
    using Microsoft.IdentityModel.Tokens;
    using System;
    using System.Collections.Generic;
    using System.IdentityModel.Tokens.Jwt;
    using System.IO;
    using System.Security.Claims;
    using System.Security.Cryptography.X509Certificates;

    /// <summary>Represents <see cref="System.IdentityModel.Tokens.Jwt"/> that helps to create and validate JWT tokens.</summary>
    public class JwtHelper
    {
        #region Symmetric JWT Token Generation

        /// <summary>Generate and returns JWT token using secret.</summary> 
        /// <param name="tokenValidationKey">Key to validate the token.</param>
        /// <param name="claims">List of data in key value pairs.</param>
        /// <param name="tokenExpiry">Expiry of jwt token, default is 900 seconds.</param>
        /// <returns>Token in JWT format.</returns>
        /// <exception cref="System.ArgumentNullException">Throw if <paramref name="claims"/> is <see langword="null"/>.</exception>
        public static string GenerateSymmetricToken(string tokenValidationKey, Dictionary<string, string> claims, int tokenExpiry = 900)
        {
            try
            {
                if (string.IsNullOrEmpty(tokenValidationKey))
                    throw new ArgumentNullException(ExceptionEnum.validationKey.GetEnumDescription());
                if (claims == null)
                    throw new ArgumentNullException(ExceptionEnum.claims.GetEnumDescription());

                var symmetricKey = Convert.FromBase64String(tokenValidationKey);
                var now = DateTime.Now;
                List<Claim> claimList = new List<Claim>();
                if (claims.Count > 0)
                {
                    foreach (var claim in claims)
                    {
                        claimList.Add(new Claim(claim.Key, claim.Value));
                    }
                }
                var tokenDescriptor = new SecurityTokenDescriptor
                {
                    Subject = new ClaimsIdentity(claimList),
                    Expires = now.AddSeconds(Convert.ToInt32(tokenExpiry)),
                    SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(symmetricKey), SecurityAlgorithms.HmacSha256Signature)
                };

                var tokenHandler = new JwtSecurityTokenHandler();
                // Removes default flag from token payload.
                tokenHandler.SetDefaultTimesOnTokenCreation = false;
                var stoken = tokenHandler.CreateToken(tokenDescriptor);
                var token = tokenHandler.WriteToken(stoken);
                return token;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        /// <summary>Validates token using secret and returns set of claims.</summary>
        /// <param name="tokenValidationKey">Key to validate the token.</param>
        /// <param name="token">Token in JWT format.</param>
        /// <returns>Set of claims.</returns>
        /// <exception cref="System.ArgumentNullException">Throw if<paramref name="tokenValidationKey"/> is <see langword="null"/>.</exception>
        /// <exception cref="System.ArgumentNullException">Throw if<paramref name="token"/> is <see langword="null"/>.</exception>
        public static ClaimsPrincipal ValidateSymmetricToken(string tokenValidationKey, string token, bool validateLifeTime = true)
        {
            try
            {
                if (string.IsNullOrEmpty(tokenValidationKey))
                    throw new ArgumentNullException(ExceptionEnum.validationKey.GetEnumDescription());

                if (string.IsNullOrEmpty(token))
                    throw new ArgumentNullException(ExceptionEnum.token.GetEnumDescription());

                var symmetricKey = Convert.FromBase64String(tokenValidationKey);
                var validationParameters = new TokenValidationParameters()
                {
                    RequireExpirationTime = true,
                    RequireSignedTokens = true,
                    ValidateAudience = false,
                    ValidateIssuer = false,
                    ValidateLifetime = validateLifeTime,
                    IssuerSigningKey = new SymmetricSecurityKey(symmetricKey),
                    ClockSkew = TimeSpan.Zero
                };

                var tokenHandler = new JwtSecurityTokenHandler();
                var principal = tokenHandler.ValidateToken(token, validationParameters, out SecurityToken securityToken);

                return principal;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        #endregion

        /// <summary>Reads token and returns an object of JWT.</summary>
        /// <param name="token">Token in JWT string format.</param>
        /// <returns>JWT object.</returns>
        /// <exception cref="System.ArgumentNullException">Throw if<paramref name="token"/> is <see langword="null"/>.</exception>
        public static JwtSecurityToken ReadToken(string token)
        {
            if (string.IsNullOrEmpty(token))
                throw new ArgumentNullException(ExceptionEnum.token.GetEnumDescription());

            var tokenHandler = new JwtSecurityTokenHandler();
            var jwtToken = tokenHandler.ReadToken(token) as JwtSecurityToken;
            return jwtToken;
        }


    }
}
