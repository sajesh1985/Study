import logging
from typing import Optional

import pandas as pd

from chatrd.core.thread_utils import submit_to_shared_thread_pool
from chatrd.engine.components.query_analyzer.translator.utils import (
    Get_translation_result,
)
from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.data_service.retriever.utils import process_date_str
from chatrd.engine.data_service.schema import (
    Analyzer,
    ProcessorInput,
    Retriever,
    Synthesizer,
)
from chatrd.engine.data_service.synthesizer.base import BaseSynthesizer
from chatrd.engine.data_service.synthesizer.utils import (
    GenericTemplate,
    date_synthesizer,
    get_api_info,
    text_response,
)

logger = logging.getLogger(__name__)

config_machinery = get_config_machinery()

CWOL_MAPPING = config_machinery.get_config_value(Constants.DataService.CWOL_MAPPING)


class SecurityRatingsSynthesizer(BaseSynthesizer, GenericTemplate):
    def source_description(self, df, entities):

        # first check if we have issuer name returned from screener
        try:
            issuer_name = ""  # Initialize issuer_name with a default value
            if not df["ISSUER NAME"].empty and not pd.isna(df["ISSUER NAME"].iloc[0]):
                # if not empty and not NaN, then we can proceed
                # to generate the sourcing URL
                issuer_name = df["ISSUER NAME"].iloc[0]
        except KeyError:
            # if returned dataframe does not contain issuer name,
            # no sourcing url is generated
            source_description = []
            return source_description

        # get the source description URL from ChatRD
        security_info = entities["securities"]
        # check to see if nything is returned
        if security_info:
            # for now, its a single issuer case, so reading just first element
            security_url_info = security_info[0]["url"]
            if security_url_info:
                try:
                    # add the landing page for the security detail page on capitaliq
                    # again, it can be a list, we only pick the first element
                    url_add = "##" + security_url_info[0]
                except Exception:
                    # typically, it can be an IndexError
                    source_description = []
                    return source_description
        else:
            # empty security info
            source_description = []
            return source_description

        sourcing_base_url = config_machinery.get_config_value(Constants.SourceGeneration.BASE_URL)
        footnote_url_slug = config_machinery.get_config_value(Constants.SourceGeneration.FOOTNOTE_URL_SLUG)
        source_description = [
            (
                issuer_name + ": Security Detail Page",
                sourcing_base_url + footnote_url_slug + url_add,
            )
        ]

        return source_description

    def template_single_icr_first(self, df, entities, rating_col: str) -> str:
        from chatrd.engine.data_service.retriever.ratings.utils import (
            securities_kpqi_identifier,
        )

        # credit rating and type
        debt_type = "Issue Credit Rating"
        credit_rating = df[rating_col].iloc[0]
        rating_type = rating_col.split("RATING")[1].strip()
        # convert to proper formatting
        rating_type_split = rating_type.split()
        rating_type_display = (
            rating_type_split[0].title() + " " + rating_type_split[1].title() + " " + rating_type_split[2]
        )
        # recovery rating
        recovery_rating_col = "S&P CREDIT RATING RECOVERY RATING"
        recovery_rating = df[recovery_rating_col].iloc[0]

        # current cwol
        cwol_col = "S&P CREDITWATCH/OUTLOOK " + rating_type
        cwol = df[cwol_col].iloc[0]

        # issuer name
        issuer_name = df["ISSUER NAME"].iloc[0]

        # entity type and value
        securities_values = securities_kpqi_identifier(entities)
        entity_type = securities_values["entity_type"]
        entity_value = securities_values["entity_value"]

        # issuer description
        issuer_desc = df["S&P RATINGS SECURITY DESCRIPTION"].iloc[0]

        # last review date
        last_review_date_col = "S&P LAST REVIEW DATE " + rating_type
        last_review_date = df[last_review_date_col].iloc[0]
        # convert the date to requested format
        last_review_date = date_synthesizer(last_review_date)

        # Build CWOL description
        if cwol:
            cwol_desc = f"with a {cwol} {CWOL_MAPPING.get(cwol.lower(), '')} ({rating_type_display})"
        else:
            cwol_desc = f"without a creditwatch or outlook ({rating_type_display})"

        # Build recovery rating description
        recovery_desc = f" and the recovery rating is {recovery_rating}" if recovery_rating else ""

        # Combine into final template
        template = (
            f"The {debt_type} is {credit_rating} {cwol_desc}{recovery_desc} "
            f"for {entity_type} {entity_value} described as {issuer_desc}. "
            f"The rating was last reviewed on {last_review_date}. "
            f"The Issuer for the security is {issuer_name}."
        )

        return template

    def template_single_icr_third(self, df) -> str:
        # recovery rating
        recovery_rating_col = "S&P CREDIT RATING RECOVERY RATING"
        recovery_rating_prior_col = recovery_rating_col + " (PRIOR)"
        recovery_rating = df[recovery_rating_col].iloc[0]
        recovery_rating_prior = df[recovery_rating_prior_col].iloc[0]

        # recovery rating date
        recovery_rating_date_col = "S&P CREDIT RATING DATE RECOVERY RATING"
        recovery_rating_date = df[recovery_rating_date_col].iloc[0]
        recovery_rating_date = date_synthesizer(recovery_rating_date)

        if recovery_rating and not recovery_rating_prior:
            template = (
                f"""The recovery rating has not been updated since the initial rating on {recovery_rating_date}."""
            )
        elif recovery_rating and recovery_rating_prior:

            if recovery_rating == recovery_rating_prior:
                template = (
                    f"""The recovery rating has not been updated since the initial rating on {recovery_rating_date}."""
                )
            elif recovery_rating != recovery_rating_prior:
                template = f"""The recovery rating was last updated to {recovery_rating} from {recovery_rating_prior} on {recovery_rating_date}."""
        else:
            return None

        return template

    def template_uspf_single_icr_first(self, df) -> Optional[str]:
        # spur rating column
        rating_col = "S&P CREDIT RATING S&P PUBLISHED UNDERLYING RATING"

        # credit rating and type
        debt_type = "S&P Published Underlying Rating"
        spur_rating = df[rating_col].iloc[0]

        # spur cwol
        cwol_col = "S&P CREDITWATCH/OUTLOOK S&P PUBLISHED UNDERLYING RATING"
        cwol = df[cwol_col].iloc[0]

        # prior cwol
        cwol_col_prior = cwol_col + " (PRIOR)"
        cwol_prior = df[cwol_col_prior].iloc[0]

        # spur last review date
        last_review_date_col = "S&P LAST REVIEW DATE S&P PUBLISHED UNDERLYING RATING"
        last_review_date = df[last_review_date_col].iloc[0]
        last_review_date = date_synthesizer(last_review_date)

        mapping = ""
        mapping_prior = ""
        if cwol:
            mapping = CWOL_MAPPING[cwol.lower()]
        if cwol_prior:
            mapping_prior = CWOL_MAPPING[cwol_prior.lower()]
        # catch NR scenario
        # scenario when current NR but prior not NR
        mapping = mapping or mapping_prior
        # scenario when prior NR bur current not NR
        # do nothing
        # scenario when both NR
        mapping = mapping or "creditwatch/ outlook"

        if spur_rating and cwol:
            template = f"""The {debt_type} is {spur_rating} with a {cwol} {mapping}. The rating was last reviewed on {last_review_date}."""
            return template
        elif spur_rating and not cwol:
            template = f"""The {debt_type} is {spur_rating} without a creditwatch or outlook. The rating was last reviewed on {last_review_date}."""
            return template
        else:
            return None

    def template_uspf_single_icr_second(self, df) -> Optional[str]:
        # spur rating column
        rating_col = "S&P CREDIT RATING S&P PUBLISHED UNDERLYING RATING"

        # current rating
        credit_rating = df[rating_col].iloc[0]

        # prior rating
        rating_col_prior = rating_col + " (PRIOR)"
        credit_rating_prior = df[rating_col_prior].iloc[0]

        # current cwol
        cwol_col = "S&P CREDITWATCH/OUTLOOK S&P PUBLISHED UNDERLYING RATING"
        cwol = df[cwol_col].iloc[0]

        # prior cwol
        cwol_col_prior = cwol_col + " (PRIOR)"
        cwol_prior = df[cwol_col_prior].iloc[0]
        # rating date
        rating_date_col = (
            rating_col.split("CREDIT RATING")[0] + "CREDIT RATING DATE" + rating_col.split("CREDIT RATING")[1]
        )
        rating_date = df[rating_date_col].iloc[0]
        # convert the date to requested format
        rating_date = date_synthesizer(rating_date)

        # rating action
        rating_action_col = (
            rating_col.split("CREDIT RATING")[0] + "CREDIT RATING ACTION" + rating_col.split("CREDIT RATING")[1]
        )

        # if rating action exists
        if df[rating_action_col].iloc[0]:
            # rating action
            try:
                rating_action_split = df[rating_action_col].iloc[0][0][1].split("|")
                if len(rating_action_split) > 1:
                    rating_action = rating_action_split[0].strip()
                else:
                    rating_action = ""
            except Exception:
                logger.error("Error parsing SPUR Rating Action field")
                rating_action = ""
            # rating action date
            try:
                rating_action_date = df[rating_action_col].iloc[0][0][2]
                rating_action_date = date_synthesizer(process_date_str(rating_action_date))
            except Exception:
                logger.error("Error parsing SPUR Rating Action date")
                rating_action_date = ""
        else:
            rating_action = ""
            rating_action_date = ""

        # new rating
        if not credit_rating_prior:
            if (
                (not cwol and not cwol_prior)
                or (cwol == "NM" and cwol_prior == "NM")
                or (not cwol and cwol_prior == "NM")
                or (cwol == "NM" and not cwol_prior)
            ):
                template = f"""The rating has not been updated since the initial rating on {rating_date}."""
            elif cwol and CWOL_MAPPING[cwol.lower()] == "outlook":
                template = (
                    f"""The rating and outlook have not been updated since the initial rating on {rating_date}."""
                )
            elif cwol and CWOL_MAPPING[cwol.lower()] == "creditwatch":
                template = (
                    f"""The rating and creditwatch have not been updated since the initial rating on {rating_date}."""
                )
        # rating change
        elif credit_rating != credit_rating_prior:
            if (
                (not cwol and not cwol_prior)
                or (cwol == "NM" and cwol_prior == "NM")
                or (not cwol and cwol_prior == "NM")
                or (cwol == "NM" and not cwol_prior)
            ):
                template = f"""The latest action was a rating {rating_action} to {credit_rating} from {credit_rating_prior} on {rating_action_date}."""

            # same OL, or CW, or CWOL;
            # i.e., prior and current same outlook/creditwatch
            # or same creditwatch/ outlook for NM scenario
            elif cwol == cwol_prior:
                # no NR
                template_1 = f"""The latest action was a rating {rating_action} to {credit_rating} from {credit_rating_prior} with the {CWOL_MAPPING[cwol.lower()]} remaining {cwol} on {rating_action_date}."""
                # scenario of NR
                template_2 = f"""The latest action was a rating {rating_action} to {credit_rating} from {credit_rating_prior} with the creditwatch/ outlook remaining {cwol} on {rating_action_date}."""
                template = template_1 if CWOL_MAPPING[cwol.lower()] else template_2

            # OL change, or CW change
            # but the mapping remains same
            elif (CWOL_MAPPING[cwol.lower()] == CWOL_MAPPING[cwol_prior.lower()]) and cwol != cwol_prior:
                # in this logic, we will not encounter NR as an option, not even NM
                mapping = CWOL_MAPPING[cwol.lower()]
                prep = "an" if mapping[0] == "o" else "a"
                template = f"""The latest action was a rating {rating_action} to {credit_rating} from {credit_rating_prior} with {prep} {mapping} change to {cwol} from {cwol_prior} on {rating_action_date}."""
            # new OL, or new CW, or new CWOL
            elif cwol and not cwol_prior:
                mapping = CWOL_MAPPING[cwol.lower()]
                # catch NR scenario
                mapping = mapping or "creditwatch/ outlook"
                prep = "an" if mapping[0] == "o" else "a"
                template = f"""The latest action was a rating {rating_action} to {credit_rating} from {credit_rating_prior} with {prep} {mapping} change to {cwol} on {rating_action_date}."""

            # OL changed from CW
            # CW changed from OL
            # other CWOL change to capture NM scenario
            elif CWOL_MAPPING[cwol.lower()] != CWOL_MAPPING[cwol_prior.lower()]:
                mapping = CWOL_MAPPING[cwol.lower()]
                mapping_prior = CWOL_MAPPING[cwol_prior.lower()]
                # catch NR scenario
                # scenario when current NR but prior not NR
                mapping = mapping or mapping_prior
                # scenario when prior NR bur current not NR
                # do nothing
                # scenario when both NR
                mapping = mapping or "creditwatch/ outlook"
                prep = "an" if mapping[0] == "o" else "a"
                if mapping_prior:
                    template = f"""The latest action was a rating {rating_action} to {credit_rating} from {credit_rating_prior} with {prep} {mapping} change to {cwol} from a {cwol_prior} {mapping_prior} on {rating_action_date}."""
                else:
                    # if prior NR
                    template = f"""The latest action was a rating {rating_action} to {credit_rating} from {credit_rating_prior} with {prep} {mapping} change to {cwol} from a {cwol_prior} on {rating_action_date}."""
        # rating remains same
        elif credit_rating == credit_rating_prior:
            # OL, or CW, or CWOL change
            # but previous and current has same mapping, i.e., both OL, or CW, or CWOL (for NM)
            if (CWOL_MAPPING[cwol.lower()] == CWOL_MAPPING[cwol_prior.lower()]) and cwol != cwol_prior:
                # in this logic, we will not encounter NR as an option, not even NM
                mapping = CWOL_MAPPING[cwol.lower()]
                prep = "an" if mapping[0] == "o" else "a"
                template = f"""The latest action was {prep} {mapping} update to {cwol} from {cwol_prior} on {rating_action_date}. The rating has not changed since {rating_date}."""

            # new OL, or new CW, or new CWOL
            elif cwol and not cwol_prior:
                mapping = CWOL_MAPPING[cwol.lower()]
                # catch NR scenario
                mapping = mapping or "creditwatch/ outlook"
                prep = "an" if mapping[0] == "o" else "a"
                template = f"""The latest action was {prep} {mapping} update to {cwol} on {rating_action_date}. The rating has not changed since {rating_date}."""

            # OL changed from CW
            # CW changed from OL
            # other CWOL change to capture NM scenario
            elif CWOL_MAPPING[cwol.lower()] != CWOL_MAPPING[cwol_prior.lower()]:
                mapping = CWOL_MAPPING[cwol.lower()]
                mapping_prior = CWOL_MAPPING[cwol_prior.lower()]
                # catch NR scenario
                # scenario when current NR but prior not NR
                mapping = mapping or mapping_prior
                # scenario when prior NR but current not NR
                # do nothing
                # scenario when both NR
                mapping = mapping or "creditwatch/ outlook"
                prep = "an" if mapping[0] == "o" else "a"
                if mapping_prior:
                    template = f"""The latest action was {prep} {mapping} update to {cwol} from a {cwol_prior} {mapping_prior} on {rating_action_date}. The rating has not changed since {rating_date}."""
                else:
                    # for prior NR scenario
                    template = f"""The latest action was {prep} {mapping} update to {cwol} from a {cwol_prior} on {rating_action_date}. The rating has not changed since {rating_date}."""

        return template

    def synthesize(
        self,
        processor: ProcessorInput = None,
        analyzer: Optional[Analyzer] = None,
        retriever: Retriever = None,
    ) -> Synthesizer:
        """
        Synthesizes a response based on the provided processor, analyzer, and retriever.

        Args:
            processor (Optional[ProcessorInput]): An object containing entity data.
            analyzer (Optional[Analyzer]): An optional analyzer object.
            retriever (Retriever): An object to retrieve API data.

        Returns:
            Synthesizer: An instance of Synthesizer containing the response and source description.
        """
        df = pd.DataFrame(retriever.api_data)
        entities = processor.entities

        spur_rating_col = "S&P CREDIT RATING S&P PUBLISHED UNDERLYING RATING"
        cols_df = df.columns.tolist()
        if spur_rating_col in cols_df:
            uspf_security = True
        else:
            uspf_security = False

        # pick available ICR column
        rating_cols = [
            "S&P CREDIT RATING FOREIGN CURRENCY LT",
            "S&P CREDIT RATING FOREIGN CURRENCY ST",
            "S&P CREDIT RATING LOCAL CURRENCY LT",
            "S&P CREDIT RATING LOCAL CURRENCY ST",
        ]
        cols_df = df.columns.tolist()

        # check if its a ratings related query and which rating
        # for securities based on given ratings default order
        # we only support single rating
        rating_col = None
        try:
            for col in rating_cols:
                if not df[col].empty and not pd.isna(df[col].iloc[0]):
                    if df[col].iloc[0]:
                        rating_col = col
                        break
                else:
                    continue
        except KeyError:
            # no ratings column returned from screener
            logger.error(
                "User query is identified as ratings related, however screener doesn't return any ratings fields."
            )
            raise Exception("No rating fields returned. Data Service response can't be generated.")

        # if ICR available
        if rating_col is not None:
            template = (
                self.template_single_icr_first(df, entities, rating_col)
                + " "
                + self.template_single_icr_second(df, rating_col)
            )
            template_end = self.template_single_icr_third(df)
            if template_end:
                template = template + " " + template_end
            else:
                pass
            # create response
            template = Get_translation_result(template, processor.original_language)
            template = template.result()
            template = template.strip()
            if template:
                icr_response = [text_response(template)]

        # add spur ratings para if uspf security
        # and spur rating exists
        spur_rating_col = "S&P CREDIT RATING S&P PUBLISHED UNDERLYING RATING"
        spur_rating = None
        if uspf_security and not df[spur_rating_col].empty:
            rating_val = df[spur_rating_col].iloc[0]
            if rating_val:
                spur_rating = rating_val
        if spur_rating is not None:
            spur_rating = df[spur_rating_col].iloc[0]
            # create templated response for SPUR
            template = self.template_uspf_single_icr_first(df) + " " + self.template_uspf_single_icr_second(df)
            template = template.strip()
            if template:
                uspf_response = [text_response(template)]

        # if no ratings available, i.e., both icr and spur not available
        if not rating_col and not spur_rating:
            # return a default template
            template = "CreditCompanion<sup>TM</sup> is unable to find any information about the security requested. Please try a different CUSIP or ISIN"
            template = Get_translation_result(template, processor.original_language)
            template = template.result()
            default_response = [text_response(template, error=True)]

        if rating_col is not None and spur_rating is None:
            response = icr_response
        elif spur_rating is not None and rating_col is None:
            response = uspf_response
        elif rating_col is not None and spur_rating is not None:
            response = icr_response + uspf_response
        else:
            response = default_response

        if not df.empty:
            source_url = self.source_description(df=df, entities=entities)
        else:
            source_url = []  # Handle the case where df is empty

        api_info = get_api_info(api_method=retriever.api_method, api_type=retriever.api_type, url=retriever.url)

        return Synthesizer(data_service_response=response, source_description=source_url, api_info=api_info)
