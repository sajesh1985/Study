import pandas as pd

from chatrd.core.code_generation.metadata import TABLE_METADATA, MetadataEntry
from chatrd.core.code_generation.schema import DataFrame
from chatrd.core.document import TableResponse


def check_combine_ratings_rating_actions(documents):
    doc_uc_types = [doc.uc_type for doc in documents]
    combine_ratings_rating_actions = False

    if ("ratings" in doc_uc_types) and ("rating_action" in doc_uc_types):
        RATINGS_INDEX = doc_uc_types.index("ratings")
        RATING_ACTION_INDEX = doc_uc_types.index("rating_action")
        if isinstance(documents[RATINGS_INDEX].content, TableResponse) & isinstance(
            documents[RATING_ACTION_INDEX].content, TableResponse
        ):
            combine_ratings_rating_actions = True

    return combine_ratings_rating_actions


def metadata_entry_ratings_rating_actions_combined(ratings_df: pd.DataFrame, ratings_actions_df: pd.DataFrame):
    uc_type = "ratings_rating_action_combined"
    table_metadata = TABLE_METADATA[uc_type]
    df_modified = pd.merge(ratings_df, ratings_actions_df, on=table_metadata.table_key, how="outer")
    df_modified.fillna("", inplace=True)
    table_metadata.keep_columns = ["Entity", "Debt Type (Rating Type)", "Current Rating", "Rating Action"]

    return table_metadata, df_modified, uc_type


def output_dataframe_combined_ratings_rating_actions(ratings_df: pd.DataFrame, ratings_actions_df: pd.DataFrame):
    table_metadata, df_modified, uc_type = metadata_entry_ratings_rating_actions_combined(
        ratings_df, ratings_actions_df
    )
    description = table_metadata.table_description
    special_instructions = ""
    special_instructions += table_metadata.prompt_keep_columns()
    table_key_text = table_metadata.list_table_key()
    examples = table_metadata.get_examples()

    return DataFrame(df_modified, uc_type + "_df", description, {}, special_instructions, table_key_text), examples
