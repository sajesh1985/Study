﻿// Copyright Notice! 
// This document is protected under the trade secret and copyright 
// laws as the property of Fidelity National Information Services, Inc. 
// Copying, reproduction or distribution should be limited and only to 
// employees with a “need to know” to do their job. 
// Any disclosure of this document to third parties is strictly prohibited.
// © 2018 Fidelity National Information Services.
// All rights reserved worldwide.
namespace Fis.Epp.Fusion.Auth
{
    using System.ComponentModel.DataAnnotations;

    public class ValidateFieldAttribute : ValidationAttribute
    {
        /// <summary>
        ///If required add custom validations
        ///Currently only being used for Veracode Data Annotations
        /// </summary>
        /// <param name="value"></param>
        /// <param name="validationContext"></param>
        /// <returns></returns>
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            return ValidationResult.Success;
        }
    }
}
