# import logging
# from typing import Any, Dict, List, Optional
# from uuid import UUID

# from langchain.callbacks.base import AsyncCallbackHandler

# from src.synthia.utils.logging_config import configure_logging


# class AgentCallbackHandler(AsyncCallbackHandler):
#     """Handler for tool execution callbacks"""

#     def __init__(self, job_id: str = "unknown") -> None:
#         super().__init__()
#         self.job_id = job_id
#         self.logger = configure_logging(
#             log_file="synthia.log", module_levels={__name__: logging.DEBUG}
#         )

#     def _truncate(self, text: Optional[str], max_length: int = 500) -> str:
#         """Return a shortened preview of text showing start and end if long."""
#         if text is None:
#             return "None"
#         try:
#             s = str(text)
#         except Exception:
#             return "<unrepresentable>"
#         if len(s) <= max_length:
#             return s
#         head = s[: max_length // 2 - 25]
#         tail = s[-(max_length // 2 - 25) :]
#         return f"{head}...[{len(s)} chars]...{tail}"

#     async def on_tool_start(
#         self,
#         serialized: Dict[str, Any],
#         input_str: str,
#         *,
#         run_id: UUID,
#         parent_run_id: Optional[UUID] = None,
#         tags: Optional[List[str]] = None,
#         metadata: Optional[Dict[str, Any]] = None,
#         inputs: Optional[Dict[str, Any]] = None,
#         **kwargs: Any,
#     ) -> None:
#         tool_name = serialized.get("name", "Unknown")
#         tool_description = serialized.get("description", "No description")
#         self.logger.info(f"[job_id={self.job_id}] Tool Started: {tool_name} | Run ID: {run_id}")
#         self.logger.debug(
#             f"[job_id={self.job_id}]    Description: {tool_description}\n"
#             f"   Input: {self._truncate(input_str, 400)}\n"
#             f"   Tags: {tags}\n"
#             f"   Parent Run: {parent_run_id if parent_run_id else 'None'}"
#         )

#     async def on_tool_end(
#         self,
#         output: Any,
#         *,
#         run_id: UUID,
#         parent_run_id: Optional[UUID] = None,
#         tags: Optional[List[str]] = None,
#         **kwargs: Any,
#     ) -> None:
#         if hasattr(output, "content"):
#             output_str = str(output.content)
#         else:
#             output_str = str(output)

#         # Truncate long outputs but show first and last parts
#         preview = self._truncate(output_str, 500)
#         self.logger.info(f"[job_id={self.job_id}] Tool Completed: Run ID: {run_id}")
#         self.logger.debug(f"[job_id={self.job_id}]    Output: {preview}")

#     async def on_tool_error(
#         self,
#         error: BaseException,
#         *,
#         run_id: UUID,
#         parent_run_id: Optional[UUID] = None,
#         tags: Optional[List[str]] = None,
#         **kwargs: Any,
#     ) -> None:
#         self.logger.error(
#             f"[job_id={self.job_id}] Tool Error: {type(error).__name__} | Run ID: {run_id}\n"
#             f"   Error: {str(error)}\n"
#             f"   Tags: {tags}",
#             exc_info=True,
#         )

#     async def on_llm_start(
#         self,
#         serialized: Dict[str, Any],
#         prompts: List[str],
#         *,
#         run_id: UUID,
#         parent_run_id: Optional[UUID] = None,
#         tags: Optional[List[str]] = None,
#         metadata: Optional[Dict[str, Any]] = None,
#         **kwargs: Any,
#     ) -> None:
#         llm_name = serialized.get("name", "Unknown LLM")
#         prompt_preview = self._truncate(prompts[0], 400) if prompts else "No prompt"
#         self.logger.info(f"[job_id={self.job_id}] LLM Started: {llm_name} | Run ID: {run_id}")
#         self.logger.debug(f"[job_id={self.job_id}]    Prompt preview: {prompt_preview}")

#     async def on_chat_model_start(
#         self,
#         serialized: Dict[str, Any],
#         messages: List[List[Any]],
#         *,
#         run_id: UUID,
#         parent_run_id: Optional[UUID] = None,
#         tags: Optional[List[str]] = None,
#         metadata: Optional[Dict[str, Any]] = None,
#         **kwargs: Any,
#     ) -> None:
#         """Handle chat model start to avoid NotImplementedError from base class."""
#         model_name = serialized.get("name", "Unknown ChatModel")
#         preview = "No messages"
#         try:
#             if messages and messages[0]:
#                 last_msg = messages[0][-1]
#                 content = getattr(last_msg, "content", str(last_msg))
#                 preview = self._truncate(content, 400)
#         except Exception:
#             preview = "<unavailable>"
#         self.logger.info(f"[job_id={self.job_id}] Chat Model Started: {model_name} | Run ID: {run_id}")
#         self.logger.debug(f"[job_id={self.job_id}]    Message preview: {preview}")

#     async def on_llm_end(
#         self,
#         response: Any,
#         *,
#         run_id: UUID,
#         parent_run_id: Optional[UUID] = None,
#         tags: Optional[List[str]] = None,
#         **kwargs: Any,
#     ) -> None:
#         token_usage = ""
#         try:
#             if hasattr(response, "llm_output") and response.llm_output:
#                 raw = response.llm_output
#                 usage = (
#                     raw.get("token_usage")
#                     or raw.get("usage")
#                     or raw.get("usage_metadata")
#                     or {}
#                 )
#                 if usage:
#                     total = (
#                         usage.get("total_tokens")
#                         or usage.get("total")
#                         or (
#                             (usage.get("prompt_tokens", 0) + usage.get("completion_tokens", 0))
#                             if "prompt_tokens" in usage and "completion_tokens" in usage
#                             else None
#                         )
#                     )
#                     if total is not None:
#                         token_usage = f" | Tokens: {total}"
#         except Exception:
#             self.logger.debug(f"[job_id={self.job_id}] Failed to parse token usage", exc_info=True)
#         self.logger.info(f"[job_id={self.job_id}] LLM Completed: Run ID: {run_id}{token_usage}")

#     async def on_llm_error(
#         self,
#         error: BaseException,
#         *,
#         run_id: UUID,
#         parent_run_id: Optional[UUID] = None,
#         tags: Optional[List[str]] = None,
#         **kwargs: Any,
#     ) -> None:
#         self.logger.error(
#             f"[job_id={self.job_id}] LLM Error: {type(error).__name__} | Run ID: {run_id}\n"
#             f"   Error: {str(error)}",
#             exc_info=True,
#         )

#     async def on_chain_start(
#         self,
#         serialized: Dict[str, Any],
#         inputs: Dict[str, Any],
#         *,
#         run_id: UUID,
#         parent_run_id: Optional[UUID] = None,
#         tags: Optional[List[str]] = None,
#         metadata: Optional[Dict[str, Any]] = None,
#         **kwargs: Any,
#     ) -> None:
#         chain_name = serialized.get("name", "Unknown Chain")
#         self.logger.info(f"[job_id={self.job_id}] Chain Started: {chain_name} | Run ID: {run_id}")
#         self.logger.debug(f"[job_id={self.job_id}]    Inputs: {list(inputs.keys())}")

#     async def on_chain_end(
#         self,
#         outputs: Dict[str, Any],
#         *,
#         run_id: UUID,
#         parent_run_id: Optional[UUID] = None,
#         tags: Optional[List[str]] = None,
#         **kwargs: Any,
#     ) -> None:
#         self.logger.info(f"[job_id={self.job_id}] Chain Completed: Run ID: {run_id}")
#         self.logger.debug(f"[job_id={self.job_id}]    Outputs: {list(outputs.keys())}")

#     async def on_chain_error(
#         self,
#         error: BaseException,
#         *,
#         run_id: UUID,
#         parent_run_id: Optional[UUID] = None,
#         tags: Optional[List[str]] = None,
#         **kwargs: Any,
#     ) -> None:
#         self.logger.error(
#             f"[job_id={self.job_id}] Chain Error: {type(error).__name__} | Run ID: {run_id}\n"
#             f"   Error: {str(error)}",
#             exc_info=True,
#         )

#     async def on_retriever_start(
#         self,
#         serialized: Dict[str, Any],
#         query: str,
#         *,
#         run_id: UUID,
#         parent_run_id: Optional[UUID] = None,
#         tags: Optional[List[str]] = None,
#         metadata: Optional[Dict[str, Any]] = None,
#         **kwargs: Any,
#     ) -> None:
#         retriever_name = serialized.get("name", "Unknown Retriever")
#         query_preview = self._truncate(query, 400)
#         self.logger.info(f"[job_id={self.job_id}] Retriever Started: {retriever_name} | Run ID: {run_id}")
#         self.logger.debug(f"[job_id={self.job_id}]    Query: {query_preview}")

#     async def on_retriever_end(
#         self,
#         documents: Any,
#         *,
#         run_id: UUID,
#         parent_run_id: Optional[UUID] = None,
#         tags: Optional[List[str]] = None,
#         **kwargs: Any,
#     ) -> None:
#         doc_count = len(documents) if hasattr(documents, "__len__") else "Unknown"
#         self.logger.info(f"[job_id={self.job_id}] Retriever Completed: {doc_count} documents | Run ID: {run_id}")

#     async def on_retriever_error(
#         self,
#         error: BaseException,
#         *,
#         run_id: UUID,
#         parent_run_id: Optional[UUID] = None,
#         tags: Optional[List[str]] = None,
#         **kwargs: Any,
#     ) -> None:
#         self.logger.error(
#             f"[job_id={self.job_id}] Retriever Error: {type(error).__name__} | Run ID: {run_id}\n"
#             f"   Error: {str(error)}",
#             exc_info=True,
#         )

