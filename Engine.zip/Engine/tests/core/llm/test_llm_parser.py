import json
from unittest.mock import Mock

import pytest

from chatrd.core.llm.components.message import MessageRole
from chatrd.core.llm.components.providers import ProviderMapping
from chatrd.core.llm.parsers import LLMInputOutputParser


class TestLLMInputOutputParser_GetRoleFormat:

    @pytest.mark.parametrize(
        "provider, expected_role_formats",
        [
            ("ai21", ["System:", "User:", "Assistant:"]),
            ("ai21-llm", ["System:", "User:", "Assistant:"]),
            ("anthropic", ["System:", "Human:", "Assistant:"]),
            ("amazon", ["System:", "User:", "Assistant:"]),
            ("bedrock", ["System:", "User:", "Assistant:"]),
            ("claude", ["System:", "Human:", "Assistant:"]),
            ("cohere", ["System:", "User:", "Assistant:"]),
            ("cohere-llm", ["System:", "User:", "Assistant:"]),
            ("llama", ["System:", "User:", "Assistant:"]),
            ("meta", ["System:", "User:", "Assistant:"]),
            ("mistral", ["System:", "User:", "Assistant:"]),
        ],
    )
    def test_getting_correct_role_format(self, provider, expected_role_formats):
        """Test getting the correct role format for different providers."""
        system_role_format, user_role_format, assistant_role_format = expected_role_formats

        assert LLMInputOutputParser.get_provider_role_format(provider, "system") == f"\n\n{system_role_format}"
        assert LLMInputOutputParser.get_provider_role_format(provider, "user") == f"\n\n{user_role_format}"
        assert LLMInputOutputParser.get_provider_role_format(provider, "assistant") == f"\n\n{assistant_role_format}"

    @pytest.mark.parametrize(
        "input_value, error",
        [
            (MessageRole.USER, None),
            ("user", None),
            ("USER", None),
            (None, ValueError),
            ({"role": "user"}, ValueError),
            (123, ValueError),
            ("", ValueError),
        ],
    )
    def test_getting_role_format_with_invalid_input_type(self, input_value, error):
        if error is None:
            role = LLMInputOutputParser.get_provider_role_format(ProviderMapping.BEDROCK, input_value)
            assert role == "\n\nUser:"
        else:
            with pytest.raises(error, match="Invalid (type for role|role)"):
                LLMInputOutputParser.get_provider_role_format(ProviderMapping.BEDROCK, input_value)


class TestLLMInputOutputParser_PrepareInput:

    SYSTEM_MSG = "System message."
    HISTORY = [{"role": "user", "content": "Hello"}, {"role": "assistant", "content": "Hi there!"}]
    HISTORY_2 = [*HISTORY, {"role": "user", "content": "Can you help me?"}]

    @pytest.mark.parametrize(
        "system_input, messages_input, prompt_input",
        [
            (SYSTEM_MSG, None, None),
            (None, HISTORY_2, None),
            (SYSTEM_MSG, HISTORY_2, None),
            (None, None, "Test prompt"),
            (SYSTEM_MSG, None, "Test prompt"),
            (None, HISTORY, "Test prompt"),
            (SYSTEM_MSG, HISTORY, "Test prompt"),
        ],
    )
    def test_prepare_input_with_different_input_params(
        self,
        system_input,
        messages_input,
        prompt_input,
    ):
        """Test prepare input with prompt only."""
        llm_input = LLMInputOutputParser.prepare_input(
            provider="bedrock",
            model_kwargs={"maxTokenCount": 100, "temperature": 0.42},
            prompt=prompt_input,
            system=system_input,
            messages=messages_input,
        )

        assert isinstance(llm_input, dict)
        assert llm_input["inputTextConfig"]["maxTokenCount"] == 100
        assert llm_input["inputTextConfig"]["temperature"] == 0.42

        prepared_input = llm_input["inputText"]
        assert isinstance(prepared_input, str)
        if system_input:
            assert system_input in prepared_input
        if prompt_input:
            assert prompt_input in prepared_input
        if messages_input:
            for msg in messages_input:
                assert msg["content"] in prepared_input


class TestLLMInputOutputParser_PrepareOutput:

    @pytest.fixture
    def response_mock_factory(self):
        """Factory to create a mock response for LLM output."""

        def response_mock(response_data: dict, input_tokens: int = 10, output_tokens: int = 5):
            llm_response = Mock()
            # Create mock body that handles .read().decode()
            mock_body = Mock()
            mock_body.read.return_value.decode.return_value = json.dumps(response_data)
            # Use side_effect with a dictionary for different keys
            llm_response.get.side_effect = lambda key, *args: {
                "body": mock_body,
                "ResponseMetadata": {
                    "HTTPHeaders": {
                        "x-amzn-bedrock-input-token-count": str(input_tokens),
                        "x-amzn-bedrock-output-token-count": str(output_tokens),
                    }
                },
            }.get(key, args[0] if args else None)
            return llm_response

        return response_mock

    amazon_like_output = {"results": [{"outputText": "Test LLM result!"}]}
    generation_output = {"generations": [{"text": "Test LLM result!"}]}
    completion_output = {"completion": "Test LLM result!"}
    completion_data_text_output = {"completions": [{"data": {"text": "Test LLM result!"}}]}
    content_output = {"content": "Test LLM result!"}
    text_output = {"text": "Test LLM result!"}

    @pytest.mark.parametrize(
        "provider, response_data",
        [
            ("ai21", completion_data_text_output),
            ("ai21-llm", completion_data_text_output),
            ("anthropic", completion_output),
            ("amazon", amazon_like_output),
            ("bedrock", amazon_like_output),
            ("claude", completion_output),
            ("cohere", generation_output),
            ("cohere-llm", generation_output),
            ("llama", content_output),
            ("meta", content_output),
            ("mistral", text_output),
        ],
    )
    def test_prepare_output(self, response_mock_factory, provider, response_data):
        """Test extracting output from LLM response."""
        expected_output = "Test LLM result!"
        llm_response_mock = response_mock_factory(response_data)

        llm_result = LLMInputOutputParser.prepare_output(provider, llm_response_mock)

        assert llm_result["text"] == expected_output
        assert llm_result["body"] == response_data
        assert llm_result["usage"]["prompt_tokens"] == 10
        assert llm_result["usage"]["completion_tokens"] == 5
        assert llm_result["usage"]["total_tokens"] == 15

    def test_prepare_output_with_invalid_output_key(self, response_mock_factory):
        """Test extracting output with invalid index format."""
        invalid_response_data = {"data": []}
        llm_response_mock = response_mock_factory(invalid_response_data)

        llm_result = LLMInputOutputParser.prepare_output("bedrock", llm_response_mock)

        assert llm_result["text"] is None
        assert llm_result["body"] == invalid_response_data
        assert llm_result["usage"]["prompt_tokens"] == 10
        assert llm_result["usage"]["completion_tokens"] == 5
        assert llm_result["usage"]["total_tokens"] == 15

    @pytest.fixture
    def stream_response_mock_factory(self):
        """Factory to create a mock response for streaming."""

        def response_mock(response_data: list, input_tokens: int = 10, output_tokens: int = 5):
            llm_response = Mock()
            response_chunks = []
            for item in response_data:
                chunk_bytes = json.dumps(item).encode()
                response_chunks.append({"chunk": {"bytes": chunk_bytes}})
            llm_response.get.return_value = response_chunks
            return llm_response

        return response_mock

    def test_prepare_output_stream_no_body(self, stream_response_mock_factory):
        """Test stream response parsing with no body."""
        response_data = []
        llm_response_mock = stream_response_mock_factory(response_data)

        llm_result = list(LLMInputOutputParser.prepare_output_stream("claude", llm_response_mock))

        assert llm_result == []

    def test_prepare_output_stream_messages_api(self, stream_response_mock_factory):
        """Test stream response parsing with messages API."""
        chunk_data = {"type": "content_block_delta", "delta": {"text": "Hello"}, "stop_reason": None}
        response_data = [chunk_data]
        llm_response_mock = stream_response_mock_factory(response_data)

        llm_result = list(LLMInputOutputParser.prepare_output_stream("claude", llm_response_mock, messages_api=True))

        assert len(llm_result) == 1
        assert llm_result[0].text == "Hello"

    FULL_STREAM_TEXT = ["Test", "LLM", "result!"]
    amazon_stream_output = [{"results": [{"outputText": chunk}]} for chunk in FULL_STREAM_TEXT]
    generation_stream_output = [{"generations": [{"text": chunk}]} for chunk in FULL_STREAM_TEXT]
    completion_stream_output = [{"completion": chunk} for chunk in FULL_STREAM_TEXT]
    completion_data_text_stream_output = [{"completions": [{"data": {"text": chunk}}]} for chunk in FULL_STREAM_TEXT]
    content_stream_output = [{"content": chunk} for chunk in FULL_STREAM_TEXT]
    text_stream_output = [{"text": chunk} for chunk in FULL_STREAM_TEXT]

    @pytest.mark.parametrize(
        "provider, response_data",
        [
            ("ai21", completion_data_text_stream_output),
            ("ai21-llm", completion_data_text_stream_output),
            ("anthropic", completion_stream_output),
            ("amazon", amazon_stream_output),
            ("bedrock", amazon_stream_output),
            ("claude", completion_stream_output),
            ("cohere", generation_stream_output),
            ("cohere-llm", generation_stream_output),
            ("llama", content_stream_output),
            ("meta", content_stream_output),
            ("mistral", text_stream_output),
        ],
    )
    def test_prepare_output_stream_standard_api(self, stream_response_mock_factory, provider, response_data):
        """Test stream response parsing with standard API."""
        llm_response_mock = stream_response_mock_factory(response_data)

        llm_result = list(LLMInputOutputParser.prepare_output_stream(provider, llm_response_mock))

        assert len(llm_result) == 3
        assert llm_result[0].text == "Test"
        assert llm_result[1].text == "LLM"
        assert llm_result[2].text == "result!"

    def test_prepare_output_stream_with_stop_sequence(self, stream_response_mock_factory):
        """Test stream response parsing with stop sequence."""
        response_data = [
            {"completion": "Test"},
            {"completion": "result"},
            {"stop_sequences": True},
            {"completion": "from LLM!"},
        ]
        llm_response_mock = stream_response_mock_factory(response_data)

        llm_result = list(LLMInputOutputParser.prepare_output_stream("claude", llm_response_mock))

        assert len(llm_result) == 2
        assert all(["from LLM" not in chunk.text for chunk in llm_result])

    @pytest.mark.asyncio
    async def test_aprepare_output_stream_success(self, stream_response_mock_factory):
        """Test async stream response parsing."""
        response_data = [{"completion": "Test"}]
        llm_response_mock = stream_response_mock_factory(response_data)

        llm_result = []
        async for chunk in LLMInputOutputParser.aprepare_output_stream("claude", llm_response_mock):
            llm_result.append(chunk)

        assert len(llm_result) == 1
        assert llm_result[0].text == "Test"
