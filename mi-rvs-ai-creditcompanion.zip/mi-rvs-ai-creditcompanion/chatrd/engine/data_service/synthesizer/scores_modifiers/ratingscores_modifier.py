import logging
from typing import Optional

from chatrd.core.thread_utils import submit_to_shared_thread_pool
from chatrd.engine.components.query_analyzer.translator.utils import (
    Get_translation_result,
)
from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.data_service.schema import (
    Analyzer,
    ProcessorInput,
    Retriever,
    Synthesizer,
)
from chatrd.engine.data_service.synthesizer.base import BaseSynthesizer
from chatrd.engine.data_service.synthesizer.scores_modifiers.utils import (
    add_dict_to_scores_modifiers,
    check_scores_modifiers_fields_in_data,
    expand_rename_company_columns,
    extract_debt_type,
    format_dates_score_modifiers,
    modify_urls_company_rating_scores,
    rating_debt_type_list,
)
from chatrd.engine.data_service.synthesizer.utils import (
    full_response,
    get_api_info,
    text_response,
)

logger = logging.getLogger(__name__)

config_machinery = get_config_machinery()


def source_description(sector, entity_name, entity_id):
    sourcing_base_url = config_machinery.get_config_value(Constants.SourceGeneration.BASE_URL)
    footnote_url_slug = config_machinery.get_config_value(Constants.SourceGeneration.FOOTNOTE_URL_SLUG)
    query_params = f"#ratingsDirect/rdratingsHistory?Id={entity_id}"
    url = sourcing_base_url + footnote_url_slug + query_params
    try:
        if sector in ["Corporates", "Insurance"]:
            sources = [(entity_name + "| Scores & Modifiers", url)]
        elif sector == "Financial Institutions":
            sources = [(entity_name + "| BICRA & Factors", url)]
    except Exception as e:
        logger.error(
            f"Failed to generate source description for entity '{entity_name}' (ID: {entity_id}, sector: {sector}). Error: {e}"
        )
        sources = [("", "")]

    return sources


def leading_line(entity_name, df_scores, data_availability, sector) -> str:
    found_ratings_response = extract_debt_type(df_scores, rating_debt_type_list)
    rating_type = found_ratings_response if found_ratings_response else ""

    if not data_availability["score_modifier"] and data_availability["rating_info"]:
        return f"{entity_name} has the following {rating_type}:"
    else:
        if sector in ["Corporates", "Insurance"]:
            return f"{entity_name} has the following {rating_type} and Scores & Modifiers:"
        elif sector == "Financial Institutions":
            return f"{entity_name} has the following {rating_type} and BICRA & Factors:"
    return ""


def footnote_line(entity_name, data_availability, source_url, sector) -> str:
    if not data_availability["score_modifier"] and data_availability["rating_info"]:
        url_text = f"{entity_name} | Ratings & History"
        if sector in ["Corporates", "Insurance"]:
            return (
                f"Unfortunately, CreditCompanion is unable to find information about "
                f"Scores & Modifiers of {entity_name}. For more information please "
                f'go to <a href="{source_url}" target="_blank">{url_text}</a>.'
            )
        elif sector == "Financial Institutions":
            return (
                f"Unfortunately, CreditCompanion is unable to find information about "
                f"Scores & Modifiers of {entity_name}. For more information please "
                f'go to <a href="{source_url}" target="_blank">{url_text}</a>.'
            )

    return ""


class ScoresModifiersSynthesizer(BaseSynthesizer):
    def synthesize(
        self,
        processor: ProcessorInput = None,
        analyzer: Optional[Analyzer] = None,
        retriever: Retriever = None,
    ) -> Synthesizer:
        # Read Arguments
        entities = processor.entities
        df = retriever.api_data
        entity_name = entities["companies"][0]["name"]
        entity_id = str(entities["companies"][0]["mi_id"])
        sector = entities["companies"][0]["rd_sector"][0]

        adding_entity_name = add_dict_to_scores_modifiers(df, entity_name)
        score_modifier_response = expand_rename_company_columns(adding_entity_name)
        formatted_response = format_dates_score_modifiers(score_modifier_response)
        scores_modifier_url = modify_urls_company_rating_scores(formatted_response)
        df_scores, data_availability = check_scores_modifiers_fields_in_data(scores_modifier_url, sector)
        sources = source_description(sector, entity_name, entity_id)
        source_url = sources[0][1]

        if not data_availability["score_modifier"] and not data_availability["rating_info"]:
            template = "Unfortunately, CreditCompanion™ is unable to find the information you were looking for. Please try another question."
            response = [text_response(template, error=True)]
        else:
            template = leading_line(entity_name, df_scores, data_availability, sector)
            template = Get_translation_result(template, processor.original_language)

            footnote = footnote_line(entity_name, data_availability, source_url, sector)
            footnote = Get_translation_result(footnote, processor.original_language)

            template = template.result()
            footnote = footnote.result()

            response = full_response(
                template=template, data=df_scores, data_type="parentchild_table", footnote=footnote
            )

        api_info = get_api_info(api_method=retriever.api_method, api_type=retriever.api_type, url=retriever.url)
        return Synthesizer(data_service_response=response, source_description=sources, api_info=api_info)
