import json
import logging
import os
from pathlib import Path

import numpy as np
import pandas as pd
from tqdm.auto import tqdm

from chatrd.core.embedding import embedding_factory

# Setup logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)


json_file_path = Path(__file__).parent / "questions.json"

# Convert JSON to DataFrame
if os.path.exists(json_file_path):
    with open(json_file_path, "r") as json_file:
        questions = json.load(json_file)

    questions_list = []
    for category, question_list in questions.items():
        for question in question_list:
            questions_list.append([question, category])

    questions_df = pd.DataFrame(questions_list, columns=["Question", "Category"])
    logger.info(f"Loaded Questions: {len(questions_df)}")
else:
    raise Exception(f"No JSON file exists at {json_file_path}.")

# Initialize the embedding model
model = embedding_factory("cohere-multi")

# Generate embeddings for each question with progress tracking
embeddings_list = []
categories_list = []

for idx, row in tqdm(questions_df.iterrows(), total=len(questions_df), desc="Processing Questions"):
    question = row["Question"]
    category = row["Category"]

    embedding = model.embed_query(question)

    embeddings_list.append(embedding)
    categories_list.append(category)

embeddings_array = np.array(embeddings_list)

# Save the embeddings and categories in a single npz file
np.savez(
    "chatrd/engine/data/use_case_embeddings.npz",
    embeddings=embeddings_array,
    categories=np.array(categories_list),
)

logger.info("Embeddings and categories have been saved to use_case_embeddings.npz.")
