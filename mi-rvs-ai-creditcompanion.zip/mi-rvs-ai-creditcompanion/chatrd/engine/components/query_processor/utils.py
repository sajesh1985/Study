import logging
import re
from types import GeneratorType

from chatrd.engine.components.query_processor.query_retriever.retriever import (
    QueryRetriever,
)
from chatrd.engine.components.schema import QueryProcessorInput
from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.utils import CitedSourceList

logger = logging.getLogger(__name__)

config_machinery = get_config_machinery()


def get_citation_map(synthesized_docs):
    """
    Generate a citation map from synthesized documents.
    Each document is represented by its article ID, and the citation map
    contains the article ID as the key and a list of citation details as the value.
    Each value list contains:
    - URL
    - Source title
    - Citation number (initialized to -1)
    """
    base_url = config_machinery.get_config_value(Constants.SourceGeneration.BASE_URL)
    research_article_slug = config_machinery.get_config_value(Constants.SourceGeneration.RESEARCH_ARTICLE_URL_SLUG)
    url = base_url + research_article_slug

    citation_map = {}
    for doc in synthesized_docs:
        if "articleSubType" in doc.metadata:
            if doc.metadata["articleSubType"] not in ["CRITERIA", "CRITERIA_GUIDANCE"]:
                citation_map[str(doc.metadata["articleID"])] = [
                    f"{url}?auth=inherit#ratingsdirect/creditResearch?rid={doc.metadata['articleID']}",
                    doc.metadata.get("PreferredTitle", doc.metadata.get("SourceTitle")),
                    -1,
                ]

            else:
                citation_map[str(doc.metadata["articleID"])] = [
                    f"{url}?auth=inherit#ratingsdirect/creditResearch?artObjectId={doc.metadata['SourceObjectID']}&html=true",
                    doc.metadata.get("PreferredTitle", doc.metadata.get("SourceTitle")),
                    -1,
                ]

    return citation_map


def fix_wrong_bracket(text):
    """
    Fix the wrong bracket format in the text.
    The function looks for patterns like [SOURCE 1, SOURCE 2,...] and replaces them with
    [SOURCE 1], [SOURCE 2].
    """

    wrong_source_tag_pattern = re.compile(r"\[SOURCE \d+(?:, SOURCE \d+)*\]")
    wrong_source_tag_pattern2 = re.compile(r"\[SOURCE \d+(?:,\s?\d+)+\]")
    if match := wrong_source_tag_pattern.search(text):
        # cut the string from the first index to  last index of match
        replacingText = text[match.start() : match.end()]
        # print('match', match)
        replacingText = text[match.start() : match.end()]
        # change [SOURCE 1, SOURCE 2] to [SOURCE 1], [SOURCE 2]
        replacingText = replacingText.replace(", ", "], [")
        # concatenate the string before match, the match and the string after match
        text = text[: match.start()] + replacingText + text[match.end() :]
    if match := wrong_source_tag_pattern2.search(text):
        # proceed same as above for pattern [SOURCE 1, 2]
        replacingText = text[match.start() : match.end()]
        replacingText = text[match.start() : match.end()]
        # change [SOURCE 1, 2] to [SOURCE 1], [SOURCE 2]
        replacingText = replacingText.replace(", ", "], [SOURCE ")
        # concatenate the string before match, the match and the string after match
        text = text[: match.start()] + replacingText + text[match.end() :]
    return text


def process_buffer(buffer, source_to_number, next_number, citation_map):

    source_tag_pattern = re.compile(r"\[SOURCE (\d+)\]")
    result = []
    text = "".join(buffer)
    buffer.clear()

    text = fix_wrong_bracket(text)

    # Replace complete [SOURCE <id>] tags
    while match := source_tag_pattern.search(text):
        start, end = match.span()
        source_id = match.group(1)

        # Assign a number to the source ID if it's new
        if source_id not in source_to_number:
            source_to_number[source_id] = next_number
            next_number += 1
        citation_number = source_to_number[source_id]

        if source_id in citation_map:
            title = citation_map[source_id][1].replace('"', "'")
            html_link = f'<a href="{citation_map[source_id][0]}" title="{title}" class="ccInTextCitation" target="_blank">[{citation_number}]</a>'
            text = text[:start] + html_link + text[end:]
            citation_map[source_id][2] = citation_number
        else:
            text = text[:start] + f"[{citation_number}]" + text[end:]

    # Yield the processed text as tokens
    if "<a" in text:
        result.append(text)
    else:
        for token in text:
            result.append(token)
    return (result, next_number)


def inline_citations_formatter(llm_generator, synthesized_docs, cited_docs=[], count_of_non_synthesize_sources=0):
    """
    Process LLM output tokens as a generator, replacing [SOURCE <id>] tags with HTML links
    while handling fragmented tags and preserving token integrity.

    Parameters:
    - llm_output: List of tokens (strings) generated by the LLM.
    - synthesized_docs: List of documents that were synthesized by the QuerySynthesizer.

    Yields:
    - Processed tokens with tags replaced.
    """
    filtered_docs = CitedSourceList(sources=[])
    buffer = []

    source_to_number = {}
    docs_as_source = []
    next_number = count_of_non_synthesize_sources + 1

    citation_map = get_citation_map(synthesized_docs)

    for token in llm_generator:
        if "[" in token.content or buffer:
            buffer.append(token.content)
            # If the buffer contains a complete tag, process and flush it
            if "]" in token.content:
                # in case content of token is like ][..xyz..
                if "[" in token.content:
                    buffer = buffer[:-1]
                    idx = token.content.index("]")
                    buffer.append(token.content[: idx + 1])
                    result, next_number = process_buffer(buffer, source_to_number, next_number, citation_map)
                    buffer.clear()
                    yield from result

                    buffer = [token.content[idx + 1 :]]
                    # if  bracket is closed in the same token
                    if "]" in token.content[idx + 1 :]:
                        result, next_number = process_buffer(buffer, source_to_number, next_number, citation_map)
                        buffer.clear()
                        yield from result
                else:
                    result, next_number = process_buffer(buffer, source_to_number, next_number, citation_map)
                    buffer.clear()
                    yield from result
        else:
            # Yield non-tag tokens directly
            yield token.content

    # Process any remaining buffer
    if buffer:
        result, next_number = process_buffer(buffer, source_to_number, next_number, citation_map)
        buffer.clear()
        yield from result
    ids = []
    for source in cited_docs:
        filtered_docs.sources.append(source)

    cited_docs_2 = []
    for doc in synthesized_docs:
        if (
            ("articleID" in doc.metadata)
            and (str(doc.metadata["articleID"]) in citation_map)
            and (citation_map[str(doc.metadata["articleID"])][2] > 0)
        ):
            cited_docs_2.append([doc, citation_map[str(doc.metadata["articleID"])][2]])

    # sort cited_docs_2 based on citation number and
    # remove duplicates
    cited_docs_2.sort(key=lambda x: x[1])
    idx0 = 0
    for doc, idx in cited_docs_2:
        if doc not in filtered_docs.sources:
            if idx0 != idx:
                filtered_docs.sources.append(doc)
                idx0 = idx
    yield filtered_docs


def sort_citations(llm_generator: GeneratorType):
    """
    Sort citations in the generator by their appearance in the text.

    Parameters:
    - generator: Generator of tokens with citations.

    Yields:

    - if token is string and contains hyperlink tag, then add it to buffer while it exists in the generator
    once hyperlink tag is not found, then sort the citations and yield them.
    - format of hyperlink tag [1], [2], [3] etc.
        some text <a href="https://www.capitaliq.spglobal.com/web/client?auth=inherit#ratingsdirect/creditResearch?rid=123456">[2]</a>,
        <a href="https://www.capitaliq.spglobal.com/web/client?auth=inherit#ratingsdirect/creditResearch?rid=1234523">[3]</a>,
        <a href="https://www.capitaliq.spglobal.com/web/client?auth=inherit#ratingsdirect/creditResearch?rid=123457">[1]</a> some_text
    hyperlinks are sorted based on the number in the square brackets.
    first tag may contain string like: some_text <a href="https://www.capitaliq.spglobal.com/web/client?auth=inherit#ratingsdirect/creditResearch?rid=123456">[2]</a>
    """

    buffer = []
    last_string = ""

    for llm_token in llm_generator:

        # check if tokn is string and containes hyperlink tag

        if isinstance(llm_token, str):

            tokens = split_multiple_citations(llm_token)

            for token in tokens:
                if ("<a href=" in token) and "[" in token and "]" in token:
                    # get starting index of hyperlink tag
                    start = token.index("<a href=")
                    # get ending index of hyperlink tag
                    end_index = token.index("</a>")
                    # append hyperlink tag to buffer
                    # if buffer is empty it is first hyperlink in sequence, that is why we need to yield string before hyperlink tag
                    if not buffer:
                        yield token[:start]

                    last_string = token[end_index + 4 :]
                    buffer.append(token[start : end_index + 4])

                # if buffer is not empty and token is not hyperlink tag
                elif buffer and (token in [", ", ",", " , ", " ", ""]):
                    continue
                else:
                    if buffer:
                        buffer.sort(key=lambda x: int(x.split("[")[1].split("]")[0]))
                        buffer = remove_duplicates(buffer)

                        yield ", ".join(buffer)
                        yield last_string
                        last_string = ""
                        buffer.clear()
                    yield token

        else:
            # if buffer is not empty, then sort the citations and yield them
            if buffer:
                buffer.sort(key=lambda x: int(x.split("[")[1].split("]")[0]))
                # remove duplicates from buffer
                buffer = remove_duplicates(buffer)

                yield ", ".join(buffer)
                buffer = []
            yield llm_token


def split_multiple_citations(llm_token):
    """search regrex_links in token
     in case of multiple hyperlinks in the same token like:
    '. <a href="http..." title="3021350">[8]</a>, <a href="htt..." title="2861996">[5]</a>kjbnk'
     we need to split the token into multiple tokens
    """
    regex_links = re.compile(r'<a href=".*?">.*?\[.*?\]</a>')
    tokens = []
    idx = 0
    res1 = regex_links.search(llm_token, idx)
    while res1:
        tokens.append(llm_token[idx : res1.end()])
        idx = res1.end()
        res1 = regex_links.search(llm_token, idx)
    if idx < len(llm_token):
        tokens.append(llm_token[idx:])
    return tokens


def remove_duplicates(buffer):
    """
    Remove duplicates from a list while preserving the order.

    Parameters:
    - buffer: List of elements.

    Returns:
    - List with duplicates removed.
    """
    move = 1
    for i in range(1, len(buffer)):
        if buffer[i - move] == buffer[i]:
            move += 1
        buffer[i - move + 1] = buffer[i]
    buffer = buffer[: len(buffer) - move + 1]
    return buffer


def remove_common_items(list1, list2):
    def clean(lst):
        result = []
        for item in lst:
            if isinstance(item, list):
                cleaned = clean(item)
                if cleaned:
                    result.append(cleaned)
            elif item not in list1:
                result.append(item)
        return result

    return clean(list2)


from chatrd.engine.components.query_analyzer.guideline_generator.prompt_templates.general import (
    general_guidelines,
)


def backup_retriever(inputs: QueryProcessorInput, query_retriever: QueryRetriever):
    """
    Takes QueryProcessorInput and returns both retrieved documents and a copy of the QueryProcessorInput for the rest of the processor.

    ### Args:
        - inputs (QueryProcessorInput): The input to the query processor.
    ### Returns:
        - revised_inputs (QueryProcessorInput): A copy of the original input with uc_type changed for further processing
        - retrieved_docs (List[Document]): The documents retrieved from the input.
        - general_guidelines (Dict[str, str]): General Micro Guidelines
    """

    revised_inputs = inputs.copy(deep=True)
    revised_inputs.analyzer_output.uc_type = "general"
    if revised_inputs.analyzer_output.extracted_timeframe is not None:
        revised_inputs.analyzer_output.extracted_timeframe = None
    retrieved_docs = query_retriever.run(revised_inputs)
    return revised_inputs, retrieved_docs, general_guidelines
