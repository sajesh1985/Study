"""Test cases for TokenTextSplitter to ensure it works similarly to the original code from langchain."""

from typing import Tuple

import pytest

from chatrd.core.document.text_splitters import TokenTextSplitter


class TestTokenTextSplitter(object):
    """Test cases for the TokenTextSplitter class."""

    short_text = "This is a test sentence for token splitting."
    long_text = "This is a very long text that will be used to test the token text splitter functionality, and it might be repeated."

    short_text_test_data = [  # params: text, chunk_size, chunk_overlap
        [short_text, 5, 0],
        [short_text, 10, 0],
        [short_text, 5, 1],
        [short_text, 5, 2],
    ]

    long_text_test_data = [  # params: text_repetition_num, chunk_size, chunk_overlap
        [25, 10, 0],
        [25, 50, 2],
        [50, 100, 0],
        [100, 500, 100],
    ]

    def test_split_empty_text(self):
        """Test splitting an empty string."""
        tt_splitter = TokenTextSplitter()
        text = ""
        tokens = tt_splitter.split_text(text)
        assert tokens == []

    @pytest.mark.parametrize("text, test_chunk_size, test_chunk_overlap", short_text_test_data)
    def test_split_text(self, text, test_chunk_size, test_chunk_overlap):
        """Test splitting text into tokens."""
        tt_splitter = TokenTextSplitter(chunk_size=test_chunk_size, chunk_overlap=test_chunk_overlap)
        tokens = tt_splitter.split_text(text)

        assert isinstance(tokens, list)
        assert len(tokens) > 0

        prev_chunk = None
        for chunk in tokens:
            # Ensure each chunk is a string
            assert isinstance(chunk, str)
            # Ensure chunks contain only the number of words less or equal to chunk_size
            word_count = len(chunk.split())
            assert word_count <= test_chunk_size
            # Ensure first-last words of chunks are overlapped correctly
            if test_chunk_overlap > 0:
                if prev_chunk:
                    is_overlapping, msg = check_for_overlapping(prev_chunk, chunk, test_chunk_overlap)
                    assert is_overlapping, msg
                prev_chunk = chunk  # Store the previous chunk for overlap checking

    @pytest.mark.parametrize("text_repetition, test_chunk_size, test_chunk_overlap", long_text_test_data)
    def test_split_long_text(self, text_repetition, test_chunk_size, test_chunk_overlap):
        """Test splitting text into tokens."""
        tt_splitter = TokenTextSplitter(chunk_size=test_chunk_size, chunk_overlap=test_chunk_overlap)
        very_long_text = " ".join([self.long_text for _ in range(text_repetition)])
        tokens = tt_splitter.split_text(very_long_text)

        prev_chunk = None
        for chunk in tokens:
            # Ensure chunks are overlapped correctly
            if test_chunk_overlap > 0:
                if prev_chunk:
                    is_overlapping, msg = check_for_overlapping(prev_chunk, chunk, test_chunk_overlap)
                    assert is_overlapping, msg
                prev_chunk = chunk  # Store the previous chunk for overlap checking

    def test_invalid_input(self):
        """Test handling of invalid input."""
        tt_splitter = TokenTextSplitter(chunk_size=10, chunk_overlap=2)
        with pytest.raises(TypeError):
            tt_splitter.split_text(None)

        with pytest.raises(TypeError):
            tt_splitter.split_text(12345)


# Helper functions
def check_for_overlapping(prev, current_chunk, overlap) -> Tuple[bool, str]:
    """Check if the last characters of the last chunk overlap with the first characters of the current chunk."""
    # Extend the slicing to ensure have enough characters for checking the overlap
    current_chunk_starting = current_chunk[: overlap * 3].strip()
    last_chunk_ending = prev[-overlap * 10 :].strip()

    # Check if the last characters of the previous chunk match the first characters of the current chunk
    if current_chunk_starting not in last_chunk_ending:
        msg = (
            f"Chunks do not overlap correctly. The beginning of current chunk '{current_chunk_starting}' "
            + f" does not mathch the end of previous chunk '{last_chunk_ending}'."
        )
        return False, msg

    return True, "Chunks overlap correctly."
