import { ChatHistory } from 'types/chatHistory';
import React, { useEffect, useRef, useState } from 'react';
import { useChatRD } from '../../../context/chatrd';
import {  styles, AccordionList, ListHeader, ListText,LeftSideBar, LeftSideBarHeader, ChatHistoryHeader  } from './LeftBar.styles';
import { MouseEventHandler } from 'react';
import { faAngleDoubleLeft,faAngleDoubleRight } from '@fortawesome/free-solid-svg-icons';
import { Accordion,AccordionItem, Icon } from '@spglobal/react-components';
import { Size } from '@spglobal/koi-helpers';
import { ChatHistoryGroup } from '@root/utils/chatHistoryManager';
import { ArchiveSessionRequestPayload, ChatHistoryResponse } from '@root/types/api';
import { HistoryModal } from '../HistoryModal/HistoryModal';
import ArchivalMenu from '../ArchivalMenu/ArchivalMenu';
import { archiveAllSession, archiveSession, fetchAllArchives } from '../../../services/api';
import { ArchivalConfirm } from '../ArchivalMenu/ArchivalConfirmation/ArchivalConfirmation';

interface LeftBarProps {
  chatHistory: ChatHistoryGroup;
  expanded: MouseEventHandler<HTMLSpanElement>;
  isLeftMenuExpanded:boolean;
  isLeftArrowVisible:boolean;

}
export const LeftBar: React.FC<LeftBarProps> = ({ chatHistory,expanded,isLeftMenuExpanded,isLeftArrowVisible }) => {
  const { newInteractionChatHistory,newInteraction } = useChatRD();
  const [activeId,setActiveId] = useState();
  const [isOpen, setIsOpen] = useState(false);
  const [archivedList, setarchivedList] = useState<ChatHistoryResponse[]>([]);

  const loadArchivedList = async () => { 
        // Await make wait until that 
        // promise settles and return its result 
        let response = await fetchAllArchives();
        response = response.sort((a: ChatHistoryResponse, b: ChatHistoryResponse) => {
          return ( (new Date(b.lastUpdatedDate)).getTime() - (new Date(a.lastUpdatedDate)).getTime());
        });
        // After fetching data stored it in posts state. 
        setarchivedList(response); 

  };

  const openModal = () => { setIsOpen(true); loadArchivedList(); }
  const closeModal = () => setIsOpen(false);

  const handleSelection = (value:any) => {
    if(value)
      {
        newInteractionChatHistory(value);
        handleArchive(value.sessionId,false);
        window.scrollTo(0, document.body.scrollHeight);
      }
    closeModal();
  };


  document.querySelector("footer").style.display = "none";
  var aboutList: ChatHistory[] = [
    { 
      header: 'About',
      message: ["Methodology", "Capabilities & Limitations", "What's Coming","Full Legal Disclaimer", "Archived Chats"]
    }
  ];

  const order = ["Today","Yesterday","Past Week","Last 30 Days"];
  const sortGrp = Object.keys(chatHistory).filter(gp=>!order.includes(gp)).sort((a:any,b:any)=>b-a);
  const sortGrpKeys = [...order,...sortGrp];

  function areAnyGroupsPopulated(chatHistArray:ChatHistoryGroup){
    for(const key in chatHistArray)
    {
      if(chatHistArray[key].length > 0)
      {
        return true;
      }
    }
    return false;
  }

  const [refreshKey,setRefreshKey] = useState(0);

  const [isArchivedAll, setArchivedAll] = useState(false);
  const handleArchive = (sessionId:any,isArchivedRequest:boolean = true) =>{
    let archiveRequest: ArchiveSessionRequestPayload = {};
    archiveRequest.sessionId = sessionId;
    archiveRequest.archive = isArchivedRequest;
    archiveSession(archiveRequest);
    if(isArchivedRequest !== true)
      {
        let resp = archivedList.filter(x=>x.sessionId === sessionId);
        let intId: any = resp[0].sessionId + 0;
        chatHistory['Today'].unshift(resp[0]);
        setActiveId(intId);
        setRefreshKey(prev=>prev+1);
      }
      else
      {
        Object.keys(chatHistory).forEach(element => {
              if(activeId)
              {
                if(!((activeId as string).indexOf(sessionId) > -1))
                {
                  let clickedSession = chatHistory[element].filter(x=>x.sessionId === sessionId);

                  if(clickedSession && clickedSession.length > 0)
                  {
                      let filteredSession = chatHistory[element].filter(x=>x.sessionId !== sessionId);
                      chatHistory[element] = filteredSession;
                      setRefreshKey(prev=>prev+1);
                  }
                }
                
              }
              else
              {
                let clickedSession = chatHistory[element].filter(x=>x.sessionId === sessionId);
                if(clickedSession && clickedSession.length > 0)
                {
                  let filteredSession = chatHistory[element].filter(x=>x.sessionId !== sessionId);
                  chatHistory[element] = filteredSession;
                  setRefreshKey(prev=>prev+1);
                }
              }
            
            
        });
      }
   
    
  };

  const reload = () => {
    window.location.reload();
  };

  function handleClick(el:any,index:any)
  {
    setActiveId(el.sessionId + index);
    newInteractionChatHistory(el);
    window.scrollTo(0, document.body.scrollHeight);
    
  }

  function handleAllArchiveClick()
  {
    setArchivedAll(true);
  }

  const divRef = useRef(null);

  // Handle click outside
  useEffect(() => {
    const handleClickOutside = (event:any) => {
      if (divRef.current && !divRef.current.contains(event.target)) {
        setArchivedAll(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  function handleConfirm()
  {
    archiveAllSession();
    setArchivedAll(false);
    Object.keys(chatHistory).forEach(element => {
          chatHistory[element] = [];
          setRefreshKey(prev=>prev+1);
    });

  }

  function handleCancel(){
    setArchivedAll(false);
  }

  return (
    <LeftSideBar>
    <div css={isLeftMenuExpanded ? styles.leftBar:styles.leftBarOpen} key={refreshKey}>
      <span style={{width:'5px',padding:'0px 16px 0px 0px',float:'right'}} data-icon="chevron-left" data-icon-size="xsmall" data-icon-purpose="none" data-testid="icon" onClick={expanded}>
          {isLeftArrowVisible ? (isLeftMenuExpanded ? <Icon icon={faAngleDoubleLeft} /> : <Icon icon={faAngleDoubleRight} />):''}
          </span>
        <LeftSideBarHeader>
          <img style={{verticalAlign: 'middle'}} src={require('../../../assets/images/chatRDAI.svg')} />
          <span style={styles.newChat} onClick={reload}>Start A New Chat</span>
        </LeftSideBarHeader>
        <div css={isLeftMenuExpanded ? '':styles.titlehide }>
        <Accordion accordionSize={Size.SMALL} removeItemSpacing >
          <AccordionItem isDefaultOpen header="Chat History" style={{textTransform:'inherit'}}>
            <AccordionList style={{height:'calc(100vh - 275px)',overflowX:'hidden'}}>
            {Object.keys(chatHistory).length > 0 && areAnyGroupsPopulated(chatHistory) === true && (
            <ListText style={{width:'90%'}} onClick={() => handleAllArchiveClick()}>Archive All</ListText>)}
            {isArchivedAll == true && <div  ref={divRef}><ArchivalConfirm onConfirm={() => handleConfirm()} onCancel={() => handleCancel()} /></div>}
              {Object.keys(chatHistory).length > 0 && sortGrpKeys.map((message:any) => (
                  <div>
                    {chatHistory[message].length >0 && (<ListHeader>
                      {message}
                    </ListHeader>)}
                      {chatHistory[message].map((mess:ChatHistoryResponse,index:number) => (
                        <ChatHistoryHeader style={{display:'flex',width:'100%'}} className={`chat${activeId == mess.sessionId +  index ? 'active':''}`}>
                            <ListText style={{width:'90%'}} className={`chat${activeId == mess.sessionId +  index ? 'active':''}`} title={mess.userInput[0].value} onClick={() => handleClick(mess,index)}>{mess.userInput[0].value}</ListText>
                            <div css={styles.iconcontent} style={{width:'10%',paddingTop:'5px'}}>
                            <ArchivalMenu sessionId={mess.sessionId} isActive={activeId == mess.sessionId +  index ? true:false} onArchive={handleArchive}></ArchivalMenu>
                            </div>
                            </ChatHistoryHeader>
                          )) }
                </div>
              ))}
              {Object.keys(chatHistory).length > 0 && areAnyGroupsPopulated(chatHistory)==false &&
                <div>
                  <ListHeader>
                    No Chat History
                  </ListHeader>
                </div>
              }

            </AccordionList>
            
          </AccordionItem>
          <br/>
          <AccordionItem isDefaultOpen header="About CreditCompanion" style={{textTransform:'inherit',position:'fixed',bottom:'0',width:'240px'}}>
            <span style={{position: 'absolute',bottom:'132px',left:'150px',fontWeight:'700',fontSize:'10px',lineHeight:'13px'}}><sup>TM</sup></span>
          <AccordionList style={{height:'110px'}}>
              {aboutList.map((message:any) => (
                  <div>
                    {message.message.map((mess:any) => (
                      <ListText title={mess} onClick={(e:any) => { if(mess === 'Archived Chats') { e.preventDefault(); openModal();  } else { newInteraction(mess);window.scrollTo(0, document.body.scrollHeight); } }}>{mess}</ListText>
                    )) }
                </div>
              ))}         
          </AccordionList>
          </AccordionItem>
        </Accordion>
        </div>
      </div>
      {isOpen && (
        <HistoryModal onClose={closeModal} onSelect={handleSelection} archiveChat={archivedList}/>
      )}
    </LeftSideBar>
  );
};

