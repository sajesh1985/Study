
import React from 'react';
import { ContextContainer, ContextContent } from './ContextView.styles';

interface ContextViewProps extends React.ComponentPropsWithoutRef<'div'> {
  isOpen?: boolean;
}

export const ContextView: React.FC<ContextViewProps> = ({
  children,
}: ContextViewProps) => {
  return (
    <ContextContainer>
      
      {children && open && (
        <ContextContent>
          <> {children}</>
        </ContextContent>
      )}
    </ContextContainer>
  );
};
