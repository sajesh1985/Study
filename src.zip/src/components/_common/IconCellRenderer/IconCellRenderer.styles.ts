export const styles = {
  customtooltip : {
    fontSize: '12px',
    maxWidth: '200px'
  }
};


