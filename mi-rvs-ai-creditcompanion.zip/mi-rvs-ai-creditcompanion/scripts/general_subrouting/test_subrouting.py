import logging
from importlib.resources import files
from typing import List, Optional

import pandas as pd
from dotenv import load_dotenv
from tqdm import tqdm

from chatrd.core.utils import ChatMessage
from chatrd.engine.components.query_analyzer import QueryAnalyzer
from chatrd.engine.components.query_analyzer.conversational import (
    ConversationalPrompter,
)
from chatrd.engine.components.query_analyzer.translator.translator import (
    InputModerationTranslator,
)
from chatrd.engine.components.query_analyzer.uc_router import EndpointRouter
from chatrd.engine.components.query_analyzer.utils import TaggedEntity
from chatrd.engine.components.schema import QueryAnalyzerInput
from chatrd.engine.configuration import Constants, get_config_machinery

load_dotenv()
logger = logging.getLogger(__name__)

config_machinery = get_config_machinery()
DEFAULT_MODEL_NAME_FOR_ANALYZER = config_machinery.get_config_value(Constants.GeneralConstants.MODEL_NAME_FOR_ANALYZER)
DEFAULT_TEMPERATURE_FOR_ANALYZER = config_machinery.get_config_value(
    Constants.GeneralConstants.TEMPERATURE_FOR_ANALYZER
)
DEFAULT_MODEL_NAME_FOR_SYNTHESIZER = "claude-3-haiku"
# config_machinery.get_config_value(
#     Constants.GeneralConstants.MODEL_NAME_FOR_SYNTHESIZER
# )
DEFAULT_TEMPERATURE_FOR_SYNTHESIZER = 0.0
# config_machinery.get_config_value(
#     Constants.GeneralConstants.TEMPERATURE_FOR_SYNTHESIZER
# )

DEFAULT_MODEL_NAME_FOR_TOOL_CLASSIFIER = config_machinery.get_config_value(
    Constants.GeneralConstants.MODEL_NAME_FOR_TOOL_CLASSIFIER
)

DEFAULT_TEMPERATURE_FOR_TOOL_CLASSIFIER = config_machinery.get_config_value(
    Constants.GeneralConstants.TEMPERATURE_FOR_TOOL_CLASSIFIER
)

DEFAULT_MODEL_NAME_FOR_DATA_SERVICE = config_machinery.get_config_value(
    Constants.DataService.MODEL_NAME_FOR_DATA_SERVICE
)

DEFAULT_TEMPERATURE_FOR_DATA_SERVICE = config_machinery.get_config_value(
    Constants.DataService.TEMPERATURE_FOR_DATA_SERVICE
)


embeddings_uc_type_path = (
    files("chatrd.engine.data")
    .joinpath(config_machinery.get_config_value(Constants.UCType.UC_EMBEDDING_FILE_NAME))
    .resolve()
)
query_analyzer = QueryAnalyzer(
    embeddings_uc_type_path=str(embeddings_uc_type_path),
    uc_embedding_model=config_machinery.get_config_value(Constants.UCType.UC_EMBEDDING_MODEL),
)

model_name_for_analyzer: Optional[str] = DEFAULT_MODEL_NAME_FOR_ANALYZER
temperature_for_analyzer: Optional[float] = DEFAULT_TEMPERATURE_FOR_ANALYZER
model_name_for_synthesizer: Optional[str] = DEFAULT_MODEL_NAME_FOR_SYNTHESIZER
temperature_for_synthesizer: Optional[float] = DEFAULT_TEMPERATURE_FOR_SYNTHESIZER
model_name_for_tool_classifier: Optional[str] = DEFAULT_MODEL_NAME_FOR_TOOL_CLASSIFIER
temperature_for_tool_classfifer: Optional[float] = DEFAULT_TEMPERATURE_FOR_TOOL_CLASSIFIER
model_name_for_data_service: Optional[str] = DEFAULT_MODEL_NAME_FOR_DATA_SERVICE
temperature_for_data_service: Optional[float] = DEFAULT_TEMPERATURE_FOR_DATA_SERVICE
list_of_tagged_entities: Optional[List[TaggedEntity]] = []
chat_history: Optional[List[ChatMessage]] = []
streaming: Optional[bool] = False


list_of_questions = [
    "(FRA)France corporate debt levels",
    "Among the following OEMs, can you tell me which ones have their sales in China realized through consolidated joint ventures and therefore whose sales in China are not visible in revenue: Toyota, Ford, General Motors, Mercedes, BMW, Volvo.",
    "Among the following OEMs, which ones have their sales in China realized through consolidated joint ventures and therefore whose sales in China are not visible in revenue: Toyota, Ford, General Motors, Mercedes, BMW, Volvo?",
    "any insights about large nordic banks results for the second quarter of 2025 ?",
    "Any research done by S&P about esg and net zero mentions by public companies ?",
    "Any research done by S&P about ESG and net zero mentions by public companies?",
    "Are there any research done by S&P about ESG and net zero commitment being on the decline ?",
    "Are there any research done by S&P about ESG and net zero commitment being on the decline?",
]


# %%  Translation


# translator = InputModerationTranslator()
# for i, question in enumerate(tqdm(list_of_questions, "translation")):
#     try:
#         language = translator.run(question)["language"]
#         if language.capitalize() != "English":
#             list_of_questions[i] = translator.translator(question, "English")
#     except:
#         print("error in " + question)
#         pass
# %%

uc_router = EndpointRouter(model_name="endpoint_embedder")

conversational_prompter = ConversationalPrompter(
    model_name=model_name_for_analyzer, temperature=temperature_for_analyzer
)

predicted_uc_types = []

issue_with_conversational_prompter_results = []
rephrases = []
all_sub_routes = []

for message in tqdm(list_of_questions):
    subroutes = []
    decision, conversational_prompter_output = conversational_prompter.run(message, chat_history)
    issue_with_conversational_prompter = (False, conversational_prompter_output)
    if decision.flag == "rephrasing":
        message = conversational_prompter_output.rephrased_initial_question
        rephrases.append(message)
        # get routes for subqueries

        for q in conversational_prompter_output.subqueries:
            subroutes.append(uc_router.run(q)[0])
    else:
        issue_with_conversational_prompter = (True, conversational_prompter_output)
        rephrases.append([])

    all_sub_routes.append(subroutes)

    uc_type = uc_router.run(message)[0]
    predicted_uc_types.append(uc_type)
    issue_with_conversational_prompter_results.append(issue_with_conversational_prompter)

df = pd.DataFrame(
    {
        "questions": list_of_questions,
        "predicted_uc_type": predicted_uc_types,
        "rephras": rephrases,
        "subroutes": all_sub_routes,
        "issue_with_conversational_prompter": issue_with_conversational_prompter_results,
    }
)

df.to_csv("result.csv", index=False)
