"""Document service for handling S3 uploads, deletions, and knowledge base synchronization."""
import asyncio
import time
import boto3
import uuid
import io
import json
import logging
from typing import Dict, Any
from fastapi import UploadFile

from src.synthia.aws_utils.aws_client import get_aws_client, get_secret
from src.synthia.config.api_config import get_config

logger = logging.getLogger(__name__)

class DocumentService:
    def __init__(self):
        self.cfg = get_config()
        self.bedrock_kb_id_key = self.cfg["bedrock_kb_id_key"]
        self.bedrock_kb_datasource_id_key = self.cfg["bedrock_kb_datasource_id_key"]
        self.propdata_s3_bucket_key = self.cfg["propdata_s3_bucket_key"]

    async def _get_secrets(self) -> Dict[str, Any]:
        """Get secrets from AWS Secrets Manager."""
        secrets_manager_client = get_aws_client("secretsmanager")
        return await asyncio.to_thread(get_secret, secrets_manager_client, "crs-rd-creditmemo-synthia")

    async def upload_document(
        self,
        file: UploadFile,
        aws_region: str,
        username: str,
        section_title: str
    ) -> Dict[str, Any]:
        """
        Upload a document to S3 and return its S3 URI.
        """
        s3 = boto3.client("s3", region_name=aws_region)
        s3_key = f"{uuid.uuid4()}_{file.filename}"
        metadata_json_key = s3_key + ".metadata.json"

        synthia_secret = await self._get_secrets()
        propdata_s3_bucket = synthia_secret[self.propdata_s3_bucket_key]
        bucket = propdata_s3_bucket

        try:
            # Prepare metadata for S3 object
            metadata = {
                "userId": username,
                "type": "pdf",
                "sectionTitle": section_title.strip().lower()
            }

            # S3 metadata keys must be lowercase strings
            metadata = {str(k).lower(): str(v) for k, v in metadata.items()}

            s3.upload_fileobj(file.file, bucket, s3_key, ExtraArgs={"Metadata": metadata})

            # Prepare metadata JSON
            metadata_json = {
                "metadataAttributes": {
                    "userId": username,
                    "type": "pdf",
                    "sectionTitle": section_title.strip().lower()
                }
            }
            
            metadata_bytes = io.BytesIO(json.dumps(metadata_json).encode("utf-8"))

            # Upload the metadata JSON file
            s3.upload_fileobj(metadata_bytes, bucket, metadata_json_key, ExtraArgs={"Metadata": metadata})

            return {"success": True, "s3_uri": f"s3://{bucket}/{s3_key}"}
        except Exception as e:
            logger.error(f"Failed to upload document: {str(e)}")
            return {"success": False, "error": str(e)}

    async def delete_documents_by_username(
        self,
        username: str,
        aws_region: str
    ) -> Dict[str, Any]:
        """
        Delete all documents from S3 that have metadata attribute userId equal to the given username.
        """
        synthia_secret = await self._get_secrets()
        propdata_s3_bucket = synthia_secret[self.propdata_s3_bucket_key]
        bucket = propdata_s3_bucket
        s3 = boto3.client("s3", region_name=aws_region)

        try:
            # List all objects in the bucket
            objects = s3.list_objects_v2(Bucket=bucket)
            deleted_keys = []

            contents = objects.get("Contents", [])
            if contents:
                for obj in contents:
                    key = obj["Key"]
                    # Get object metadata
                    head = s3.head_object(Bucket=bucket, Key=key)
                    logger.info(f"S3 Key: {key}, Metadata: {head.get('Metadata', {})}")
                    metadata = head.get("Metadata", {})
                    # S3 metadata keys are lowercase
                    if metadata.get("userid") == username:
                        s3.delete_object(Bucket=bucket, Key=key)
                        deleted_keys.append(key)

            return {
                "success": True,
                "deleted_keys": deleted_keys,
                "message": f"Deleted {len(deleted_keys)} objects for username={username}"
            }
        except Exception as e:
            logger.error(f"Failed to delete documents: {str(e)}")
            return {"success": False, "error": str(e)}

    async def synchronize_knowledge_base(self) -> Dict[str, Any]:
        """
        Synchronize the knowledge base by uploading documents to S3.
        """
        bedrock_client = get_aws_client("bedrock-agent")
        synthia_secret = await self._get_secrets()

        bedrock_kb_id = synthia_secret[self.bedrock_kb_id_key]
        bedrock_kb_datasource_id = synthia_secret[self.bedrock_kb_datasource_id_key]
        data_source_id = bedrock_kb_datasource_id

        try:
            response = bedrock_client.start_ingestion_job(
                dataSourceId=data_source_id,
                knowledgeBaseId=bedrock_kb_id
            )
            ingestion_job_id = response["ingestionJob"]["ingestionJobId"]

            # Poll the ingestion job status every 10 seconds until it completes or fails
            while True:
                status_response = bedrock_client.get_ingestion_job(
                    dataSourceId=data_source_id,
                    ingestionJobId=ingestion_job_id,
                    knowledgeBaseId=bedrock_kb_id
                )
                status = status_response["ingestionJob"]["status"]
                if status in ["COMPLETE", "FAILED", "STOPPED"]:
                    break
                time.sleep(10)

            if status == "COMPLETE":
                logger.info(f"Knowledge base synchronized successfully with job ID: {ingestion_job_id}")
                return {"success": True, "message": "Knowledge base synchronized successfully"}
            else:
                raise Exception("Document was uploaded but embedding process failed")
        except Exception as e:
            logger.error(f"Failed to synchronize knowledge base: {str(e)}")
            return {"success": False, "error": str(e)}
