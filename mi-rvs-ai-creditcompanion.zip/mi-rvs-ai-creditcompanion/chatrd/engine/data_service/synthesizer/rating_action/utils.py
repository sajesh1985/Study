from datetime import datetime

import pandas as pd

from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.data_service.synthesizer.utils import (
    company_profile_url,
    make_source_description,
    rating_history_url,
)

config_machinery = get_config_machinery()


def get_move_direction(RT_CURRENT_CW_OL_ACTION_WORD: str) -> str:
    """
    Applicable to rating action use case. Retrieves information about rating change direction.

    Args:
        RT_CURRENT_CW_OL_ACTION_WORD column value from the API output

    Returns:
        Rating change direction: Upgrade / Downgrade / None
    """
    return (
        "downgrade"
        if RT_CURRENT_CW_OL_ACTION_WORD.startswith("Downgrade")
        else ("upgrade" if RT_CURRENT_CW_OL_ACTION_WORD.startswith("Upgrade") else None)
    )


def get_action_date_format(RT_RATING_DATE: str) -> datetime:
    """
    Formats Rating Date.

    Args:
        RT_RATING_DATE column value from the API output

    Returns:
        A date in datetime format.
    """
    return datetime.strptime(RT_RATING_DATE, "%Y-%m-%dT%H:%M:%S").date()


def filters_to_data_frame(filters_dict: dict) -> pd.DataFrame:
    """
    Presents applied filters as a dataframe, for a future reference.

    Args:
        filters_dict filters to be applied, stored as a dictionary

    Returns:
        Applied filters, in a DataFrame format
    """
    return pd.DataFrame(
        [
            {"filter_name": filter_name, "filter_value": filter_value}
            for filter_name, filter_value in filters_dict.items()
        ]
    )


def source_description(entity_name, entity_id):
    sep = " | "
    info = "Private Company"
    sources = make_source_description(entity_name, entity_id, sep, info, company_profile_url)

    return sources


def template_leading_line(has_valid_rows, action_type, entity_name, entity_id, url, private_company_bool=True) -> str:
    if private_company_bool:
        PRIVATE_COMPANY_STR = " company"
        PRIVATE_COMPANY_PAGE = "Corporate Profile"
    else:
        PRIVATE_COMPANY_STR = ""
        PRIVATE_COMPANY_PAGE = "profile"
    if has_valid_rows:
        # user did not define filtering criteria
        if action_type is None:
            MOVE_DIRECTION = "Rating Action"
        # user defined filtering criteria for rating upgrade / downgrade
        else:
            MOVE_DIRECTION = action_type.capitalize()
        TEMPLATE_LEADING_LINE = f"""{entity_name}{PRIVATE_COMPANY_STR} has the following Latest {MOVE_DIRECTION}:"""
    else:
        if action_type is None:
            TEMPLATE_LEADING_LINE = f"""CreditCompanion™ is unable to find recent rating actions for {entity_name}. Please see the {PRIVATE_COMPANY_PAGE} page <a href="{company_profile_url(entity_id)}" target="_blank">here</a> for more information."""
        else:
            MOVE_DIRECTION = action_type.capitalize()
            TEMPLATE_LEADING_LINE = f"""{entity_name} has not been {MOVE_DIRECTION} recently. For more information, please see the <a href="{rating_history_url(entity_id)}" target="_blank">Ratings & History page</a>"""
    return TEMPLATE_LEADING_LINE


def create_rating_action_table(api_data, filters):
    df_rating_action = pd.DataFrame(api_data)

    df_rating_action["MoveDirection"] = df_rating_action["RT_CURRENT_CW_OL_ACTION_WORD"].apply(get_move_direction)
    df_rating_action["ActionDateFormat"] = df_rating_action["RT_RATING_DATE"].apply(get_action_date_format)
    for column, value in filters.items():
        df_rating_action = df_rating_action[df_rating_action[column] == value]
    df_rating_action.sort_values("ActionDateFormat", inplace=True, ascending=False)

    # find the most recent rating change date
    if df_rating_action.shape[0] > 0:
        most_recent_date = df_rating_action.head(1)["ActionDateFormat"].iloc[0]
        df_rating_action = df_rating_action.loc[df_rating_action["ActionDateFormat"] == most_recent_date]

    df_rating_action["DEBT_RATING_TYPE_CODE_FOR_OUTPUT"] = (
        df_rating_action["RT_DEBT_TYPE_CODE"] + " (" + df_rating_action["RT_RATING_TYPE_CODE"] + ")"
    )

    df_rating_action["ActionDateFormat"] = df_rating_action["ActionDateFormat"].apply(lambda x: x.strftime("%m/%d/%Y"))

    TABLE_COLS = [
        "DEBT_RATING_TYPE_CODE_FOR_OUTPUT",
        "RT_CURRENT_CW_OL_ACTION_WORD",
        "ActionDateFormat",
        "RT_CURRENT_RATING_SYMBOL",
        "RT_CURRENT_CW_OL",
        "RT_PRIOR_RATING_SYMBOL",
        "RT_PRIOR_CW_OL",
    ]

    RATING_ACTION_COLS_DICT = {
        "DEBT_RATING_TYPE_CODE_FOR_OUTPUT": "Debt Type (Rating Type)",
        "RT_CURRENT_CW_OL_ACTION_WORD": "Action",
        "ActionDateFormat": "Action Date",
        "RT_CURRENT_RATING_SYMBOL": "Rating To",
        "RT_CURRENT_CW_OL": "Creditwatch/Outlook To",
        "RT_PRIOR_RATING_SYMBOL": "Rating From",
        "RT_PRIOR_CW_OL": "Creditwatch/Outlook From",
    }

    df_rating_action = df_rating_action[TABLE_COLS].rename(RATING_ACTION_COLS_DICT, axis=1)
    has_valid_rows = len(df_rating_action) > 0
    return df_rating_action, has_valid_rows


def create_multientityrating_action_table(api_data, filters, companies):
    df_rating_action = pd.DataFrame(api_data)

    TABLE_COLS = [
        "name",
        "DEBT_RATING_TYPE_CODE_FOR_OUTPUT",
        "RT_CURRENT_CW_OL_ACTION_WORD",
        "ActionDateFormat",
        "RT_RATING_SYMBOL",
        "RatingDateFormat",
        "RT_CW_OL",
        "RT_CW_OL_DATE",
        "RT_CURRENT_RATING_SYMBOL",
        "RT_CURRENT_CW_OL",
        "RT_CURRENT_CW_OL_DATE",
        "RT_UPD_DATE",
        "RT_PRIOR_CW_OL",
        "RT_PRIOR_RATING_SYMBOL",
        "url",
    ]

    RATING_ACTION_COLS_DICT = {
        "name": "Entity",
        "DEBT_RATING_TYPE_CODE_FOR_OUTPUT": "Debt Type (Rating Type)",
        "RT_CURRENT_CW_OL_ACTION_WORD": "Action",
        "ActionDateFormat": "Action Date",
        "RT_RATING_SYMBOL": "To Rating",
        "RatingDateFormat": "Rating Date",
        "RT_CW_OL": "To Creditwatch/Outlook",
        "RT_CW_OL_DATE": "Creditwatch/Outlook Date",
        "RT_CURRENT_RATING_SYMBOL": "Current Rating",
        "RT_CURRENT_RATING_DATE": "Current Rating Date",
        "RT_CURRENT_CW_OL": "Current Creditwatch/Outlook",
        "RT_CURRENT_CW_OL_DATE": "Current Creditwatch/Outlook Date",
        "RT_UPD_DATE": "Last Review Date",
        "RT_PRIOR_RATING_SYMBOL": "From Rating",
        "RT_PRIOR_CW_OL": "From Creditwatch/Outlook",
        "url": "Citation",
    }
    # No API output
    if df_rating_action.empty:
        columns = list(RATING_ACTION_COLS_DICT.values())
        return pd.DataFrame(columns), False

    df_rating_action["MoveDirection"] = df_rating_action["RT_CURRENT_CW_OL_ACTION_WORD"].apply(get_move_direction)
    df_rating_action["ActionDateFormat"] = df_rating_action["RT_RATING_DATE"].apply(get_action_date_format)
    df_rating_action["RatingDateFormat"] = df_rating_action["RT_RATING_DATE"].apply(get_action_date_format)

    df_rating_action["DEBT_RATING_TYPE_CODE_FOR_OUTPUT"] = (
        df_rating_action["RT_DEBT_TYPE_CODE"] + " (" + df_rating_action["RT_RATING_TYPE_CODE"] + ")"
    )

    companies_df = pd.DataFrame(companies)

    merged_df = df_rating_action.merge(companies_df, left_on="RT_ENTITY_ID", right_on="mi_id", how="inner")

    merged_df["ActionDateFormat"] = merged_df["ActionDateFormat"].apply(lambda x: x.strftime("%m/%d/%Y"))

    sourcing_base_url = config_machinery.get_config_value(Constants.SourceGeneration.BASE_URL)
    footnote_url_slug = config_machinery.get_config_value(Constants.SourceGeneration.FOOTNOTE_URL_SLUG)
    merged_df["url"] = sourcing_base_url + footnote_url_slug + "#" + merged_df["url"]

    merged_df = merged_df[TABLE_COLS].rename(RATING_ACTION_COLS_DICT, axis=1)
    has_valid_rows = len(df_rating_action) > 0
    return merged_df, has_valid_rows
