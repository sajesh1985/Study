﻿// Copyright Notice! 
// This document is protected under the trade secret and copyright 
// laws as the property of Fidelity National Information Services, Inc. 
// Copying, reproduction or distribution should be limited and only to 
// employees with a “need to know” to do their job. 
// Any disclosure of this document to third parties is strictly prohibited.
// © 2017 Fidelity National Information Services.
// All rights reserved worldwide.

namespace Fis.Epp.Fusion.WebAPI.LoggerModels
{
    public class AppExceptionLoggerModel
    {
        public string ErrorMessage;
        public string ErrorStack;
        public string RequestUrl;
        public string UserId;
        public string MemberId;
        public string RequestorId;
        public string CorrelationId;
        public string BrandId;
    }

    public class AppUserLoggerModel
    {
        public string BrandId;
        public string UserId;
        public string MemberId;
        public string RequestorId;
        public string CorrelationId;
    }

    public class ServiceExceptionLoggerModel
    {
        public string CorrelationId;
        public string ServiceUuid;
        public string MethodId;
        public string ApplicationId;
        public string ClientId;
        public string BrandId;
        public string UserId;
        public string MemberId;
        public string SyndicateId;
        public string RequestorId;
        public string Verb;
        public string CultureId;
        public string HTTP_CODE;
        public string MessageSeverity;
        public string MessageCode;
        public string Message;
    }

    public class ServicePerformancLoggerModel
    {
        public string CorrelationId;
        public string ServiceUuid;
        public string MethodId;
        public string ApplicationId;
        public string ClientId;
        public string BrandId;
        public string UserId;
        public string MemberId;
        public string SyndicateId;
        public string RequestorId;
        public string Verb;
        public string CultureId;
        public string HTTP_CODE;
        public string MessageCode;
        public string Duration;
    }

    public class ServicePayloadLoggerModel
    {
        public string CorrelationId;
        public string ServiceUuid;
        public string MethodId;
        public string ApplicationId;
        public string ClientId;
        public string BrandId;
        public string UserId;
        public string MemberId;
        public string SyndicateId;
        public string RequestorId;
        public string Verb;
        public string CultureId;
        public string HTTP_CODE;
        public string MessageCode;
        public string RequestJSON;
        public string ResponseJSON;
    }
}