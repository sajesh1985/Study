"""Parser for mapping the output of LLM calls to Pydantic objects.
The parser expects the output to be a JSON string that can be parsed into the specified Pydantic model.
"""

import json
import logging
import re
from abc import ABC, abstractmethod
from typing import Any, Generic, List, Optional, Type, TypeVar, Union

from pydantic import BaseModel, ValidationError

from chatrd.core.llm.components.base import LanguageModelOutput, Runnable
from chatrd.core.llm.components.generation import Generation
from chatrd.core.llm.components.message import BaseMessage

T = TypeVar("T")
OutputParserLike = Runnable[LanguageModelOutput, T]
TBaseModel = TypeVar("TBaseModel", bound=BaseModel)

logger = logging.getLogger(__name__)


class BaseOutputParser(Generic[T], ABC):
    """Base class for output parsers that can parse the output of LLM calls to a specific type."""

    @abstractmethod
    def parse(self, text: str) -> T:
        """Parse the string output of an LLM call to a specific type."""
        raise NotImplementedError(f"{self.__class__.__name__} must implement this method.")

    @abstractmethod
    def parse_result(self, generations: List[Generation], partial: bool = False) -> Optional[T]:
        """Parse the list of generations from an LLM call result to a specific type.
        This method should handle multiple generations."""
        raise NotImplementedError(f"{self.__class__.__name__} must implement this method.")

    @abstractmethod
    def get_format_instructions(self) -> str:
        """Return the format instructions for the output of the LLM call."""
        raise NotImplementedError(f"{self.__class__.__name__} must implement this method.")


class PydanticOutputParser(Generic[T]):
    """Custom PydanticOutputParser for parsing the output of LLM calls to a pydantic objects.
    The parser expects the output to be a JSON string that can be parsed into the specified pydantic model.

    Public methods:
    - `parse(text: str)`: Parses the json-string output of an LLM call into a pydantic object.
    - `parse_result(generations: List[Generation], partial: bool = False)`: Parses the list of generations
        from an LLM call result to a pydantic object.
    - `get_format_instructions()`: Returns the format instructions for the JSON output.
    - `OutputType`: The type of the pydantic object that the parser will return.
    """

    def __init__(self, pydantic_object: Type[T]):
        """Initialize the PydanticOutputParser with a pydantic model that will be used for parsing LLM results
        to the desired pydantic object.

        """
        self.pydantic_object = pydantic_object

    def parse(self, text: str) -> T:
        """Parse the string output of an LLM call to a pydantic object."""
        if not text or not text.strip():
            raise OutputParserException("Empty input provided", llm_output=text)

        # Sanitize input - remove prefixes, invalid characters, code blocks, and unformed extra data from LLM results.
        text = self._sanitize_input(text.strip())

        try:
            data = self._str_to_dict(text)
            return self.pydantic_object.model_validate(data)
        except json.JSONDecodeError as e:
            raise OutputParserException(f"Invalid input text has been failed to parse: {e}\nInput: {text}") from e
        except AttributeError as e:
            raise OutputParserException(
                f"Unsupported model as pydantic object: {self.pydantic_object.__name__}\nError: {e}"
            ) from e
        except (ValueError, ValidationError) as e:
            raise OutputParserException(f"Failed to parse the input into Pydantic model: {e}\nInput: {text}") from e

    def parse_result(self, generations: List[Generation], partial: bool = False) -> Optional[T]:
        """Parse list of generations from LLM call result to a pydantic object."""
        if not generations:
            raise IndexError("No generations provided")

        # Try multiple generations if available
        for generation in generations:
            try:
                return self.parse(generation.text)
            except OutputParserException as e:
                if partial:
                    continue  # Try next generation
                raise e  # If not partial, raise the original exception

        return None

    def invoke(self, input: Union[str, BaseMessage]) -> T:
        """Parse the string or message type output of an LLM call to a pydantic object."""
        if isinstance(input, str):
            return self.parse(input)
        elif isinstance(input, BaseMessage):
            input_str = input.text()
            return self.parse(input_str)
        else:
            raise TypeError(f"Unsupported input type: {type(input)}. Expected str or BaseMessage.")

    def get_format_instructions(self) -> str:
        """Return the format instructions for the JSON output."""
        # Copy schema to avoid altering original Pydantic schema.
        schema = dict(self.pydantic_object.model_json_schema().items())

        # Remove extraneous fields.
        reduced_schema = schema
        if "title" in reduced_schema:
            del reduced_schema["title"]
        if "type" in reduced_schema:
            del reduced_schema["type"]
        # Ensure json in context is well-formed with double quotes.
        schema_str = json.dumps(reduced_schema, ensure_ascii=False)

        return _PYDANTIC_FORMAT_INSTRUCTIONS.format(schema=schema_str)

    @property
    def OutputType(self) -> Type[T]:
        return self.pydantic_object

    def _str_to_dict(self, text: str) -> dict:
        """Convert a string to a dictionary."""
        try:
            return json.loads(text)
        except json.JSONDecodeError as e:
            raise OutputParserException(f"Failed to parse JSON: {e}\nInput: {text}") from e

    def _sanitize_input(self, text: str) -> str:
        """Remove common LLM artifacts from JSON output."""
        # Remove markdown code blocks
        if text.startswith("```json"):
            text = text[7:]  # Remove ```json
        if text.endswith("```"):
            text = text[:-3]  # Remove ```

        # Remove common prefixes LLMs add
        prefixes = ["Here's the JSON:", "Result:", "Output:"]
        for prefix in prefixes:
            if text.startswith(prefix):
                text = text[len(prefix) :].strip()

        # Remove invalid control characters (ASCII 0-31 and 127) except for \n \r \t.
        text = re.sub(r"[\x00-\x1F\x7F]", "", text)

        # Handle cases where the LLM output might be truncated or malformed.
        text = self._remove_unformed_extra_data(text)

        return text

    @staticmethod
    def _remove_unformed_extra_data(text: str) -> str:
        """Remove unformed extra data from the text.
        LLM output might be truncated when reach the maximum token limit which can result in unformed extra data
        when the model stops generating before completing the JSON structure.
        Try to find and remove any trailing text that is not valid JSON.
        """
        try:
            json.loads(text)
        except json.JSONDecodeError:
            # Find the valid JSON object
            match = re.search(r"\{.*?\}", text, re.DOTALL)
            if match:
                new_text = match.group(0)
                diff = text.replace(new_text, "")
                logger.warning(f"Unformed extra data found in LLM output. Removed: {diff}")
                return new_text

        return text.strip()


_PYDANTIC_FORMAT_INSTRUCTIONS = """The output should be formatted as a JSON instance that conforms to the JSON schema below.

As an example, for the schema {{"properties": {{"foo": {{"title": "Foo", "description": "a list of strings", "type": "array", "items": {{"type": "string"}}}}}}, "required": ["foo"]}}
the object {{"foo": ["bar", "baz"]}} is a well-formatted instance of the schema. The object {{"properties": {{"foo": ["bar", "baz"]}}}} is not well-formatted.

Here is the output schema:
```
{schema}
```"""


class OutputParserException(ValueError):
    """Exception that output parsers should raise to signify a parsing error."""

    def __init__(
        self, error: Any, observation: Optional[str] = None, llm_output: Optional[str] = None, send_to_llm: bool = False
    ):
        """Create an OutputParserException.

        Args:
            error: The error that's being re-raised or an error message.
            observation: String explanation of error which can be passed to a model to try and remediate the issue.
            llm_output: String model output which is error-ing.
            send_to_llm: Whether to send the observation and llm_output back to an Agent when the exception is raised.
        """
        super().__init__(error)
        if send_to_llm and (observation is None or llm_output is None):
            msg = "Arguments 'observation' & 'llm_output' are required if 'send_to_llm' is True"
            raise ValueError(msg)
        self.observation = observation
        self.llm_output = llm_output
        self.send_to_llm = send_to_llm
