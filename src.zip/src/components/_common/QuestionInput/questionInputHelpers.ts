import { CurrentTabEnum } from './QuestionInput.types';

const tabs: CurrentTabEnum[] = [
  CurrentTabEnum.all,
  CurrentTabEnum.companies,
  CurrentTabEnum.fixed_income,
];

export const nextTabIndex = (currentTab: CurrentTabEnum) => {
  const currentIndex = tabs.indexOf(currentTab);
  const newIndex: number = (currentIndex + 1) % tabs.length;

  return tabs[newIndex];
};

export const prevTabIndex = (currentTab: CurrentTabEnum) => {
  const currentIndex = tabs.indexOf(currentTab);
  const newIndex: number = (currentIndex - 1 + tabs.length) % tabs.length;

  return tabs[newIndex];
};
