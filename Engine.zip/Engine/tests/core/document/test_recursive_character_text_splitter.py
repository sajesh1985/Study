import pytest

from chatrd.core.document.text_splitters import RecursiveCharacterTextSplitter


@pytest.fixture
def splitter():
    return RecursiveCharacterTextSplitter(chunk_size=100, chunk_overlap=5)


class TestRecursiveCharacterTextSplitter(object):
    mid_size_line = "This is a mid-size line that too long when it is repeated."  # 58 chars
    long_line = "This is a long line of text that should fit in the chunks size and no need to be split into chunks."  # 99 chars
    too_long_line = (
        "This is a longer text that needs to be split into multiple chunks "
        "because it exceeds the chunk size and hard to process in one chunk only."
    )  # 138 chars

    @pytest.mark.parametrize(
        "text, expected_chunks",
        [
            # Test with empty text
            ("", []),
            # Test with text containing only separators
            ("\n\n\n", []),
            # Test with text that fits within chunk_size
            ("This is a short text.", ["This is a short text."]),
            # Test with text and separators
            (f"{long_line}\n\n{long_line}\n\n{long_line}", [long_line, long_line, long_line]),
            # Test with long text that exceeds chunk_size
            (too_long_line, [too_long_line[:100], too_long_line[95:]]),
            # Test with text in multiple pharagraphs but inside chunk size
            (
                "Paragraph one.\n\nParagraph two.\n\nParagraph three.",
                ["Paragraph one.\n\nParagraph two.\n\nParagraph three."],
            ),
            # Test with text that has multiple separators
            (
                f"{mid_size_line}\n{mid_size_line}\n\n{long_line}\n\n",
                [mid_size_line, mid_size_line, long_line],
            ),
        ],
    )
    def test_split_text(self, splitter, text, expected_chunks):
        chunks = splitter.split_text(text)
        for chunk, expected in zip(chunks, expected_chunks):
            assert chunk.strip() == expected.strip(), f"Expected '{expected}' but got '{chunk}'"
