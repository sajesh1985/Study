import React from 'react';
import { Badge, badgeAppearance, Divider } from '@spglobal/react-components';
import { 
  HighlightedSymbolsStyled,
  SearchItemLeftColumnStyled,
  SearchItemRightColumnStyled,
  SearchItemStyled,
  ItemTitleStyled,
  ItemDescriptionStyled,
} from './QuestionInput.styles';
import { CustomModalListItemType } from './QuestionInput.types';

export function removeTextInParentHeses(str: string) {
  const newStrig = str.replace(/\(.*?\)/g, '');
  return newStrig.trim();
}

export function extractRelevantData(item: { comments: any[] }, searchedType: string) {
  return item.comments.filter((el: { contentType: string }) => el.contentType == searchedType);
}

export const CustomModalListItem: React.FC<CustomModalListItemType> = ({
  item,
  handleSearchItemClick,
  highlightText,
}) => {
  const highlightedText = (text: string | undefined, highlight: string) => {
    const safeText = text || '';

    if (!highlight.trim()) {
      return [<span>{safeText}</span>];
    }

    const parts = safeText.split(new RegExp(`(${highlight})`, 'gi'));

    return parts.map((part: string) =>
      part.toLowerCase() === highlight.toLowerCase() ? (
        <HighlightedSymbolsStyled>{part}</HighlightedSymbolsStyled>
      ) : (
        part
      )
    );
  };

  const name = removeTextInParentHeses(item.name);
  const nameHighlighted = highlightedText(name, highlightText);

  const badgeRD = extractRelevantData(item, 'badge_rd')[0]?.text;
  const badgeCSD = extractRelevantData(item, 'badge_csd')[0]?.text;
  const cardType = extractRelevantData(item, 'card_type')[0]?.text;
  const comment = extractRelevantData(item, 'comment');
  const commentHighlighted = highlightedText(comment[0]?.text, highlightText);

  return (
    <>
      <SearchItemStyled onClick={() => handleSearchItemClick(item)}>
        <SearchItemLeftColumnStyled>
          <ItemTitleStyled>{nameHighlighted}</ItemTitleStyled>
          <ItemDescriptionStyled>{commentHighlighted}</ItemDescriptionStyled>
        </SearchItemLeftColumnStyled>
        <SearchItemRightColumnStyled>
          <ItemDescriptionStyled>{cardType}</ItemDescriptionStyled>
          <div>
            {badgeCSD && (
              <Badge purpose={badgeAppearance.blue} className="spg-mb-sm">
                {badgeCSD}
              </Badge>
            )}
            {badgeRD && (
              <Badge purpose={badgeAppearance.deepRed} className="spg-mb-sm">
                {badgeRD}
              </Badge>
            )}
          </div>
        </SearchItemRightColumnStyled>
      </SearchItemStyled>
      <Divider isSmall/>
    </>
  );
};
