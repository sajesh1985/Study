from chatrd.engine.components.query_analyzer.utils import EntityType

ESG_GUIDELINES_EXAMPLES = """
{
    "question": "What impact do ESG factors have on the credit rating for/of xyz?",
    "guidelines": "1. At the beginning of your response, you MUST provide a concise summary or abstract that encapsulates the main points of your entire response. This summary should give the reader a clear and quick understanding of the key information and insights you will cover. \n 2. Follow-Up Guidelines: After providing the summary, follow the rest of the guidelines as individual instructions to structure the detailed part of your response. \n 3. After that summary on top, mention in paragraph in summary on the following key points: xyz's Environmental profile, Social profile, and Governance. Start with 'Based on the latest S&P Global Rating's research, here is ESG profiles of xyz :' \n 4. Mention if there are any details on how the entity is responding to the ESG challenges. \n 5. Keep in mind that the given rating information documents that you pick to answer this question MUST have '(ESG)' keyword in the chunk_title. If there is no such document then say 'The latest S&P Global Ratings research does not mention specific does not provide any details on xyz's environmental, social or governance initiatives or performance.'."
}
__________________
{
    "question": "What is the ESG Profile/factors of xyz?",
    "guidelines": "1. At the beginning of your response, you MUST provide a concise summary or abstract that encapsulates the main points of your entire response. This summary should give the reader a clear and quick understanding of the key information and insights you will cover. \n 2. Follow-Up Guidelines: After providing the summary, follow the rest of the guidelines as individual instructions to structure the detailed part of your response. \n 3. After that summary on top, mention in bullets a pointwise summary on the following key points saying 'Based on the latest S&P Global Rating's research, here is ESG (Environmental, Social, Governance) profiles of xyz :' : xyz's Environmental profile/factors, Social profile/factors, and Governance profile/factors. \n 4. Keep in mind that the given rating information documents that you pick to answer this question MUST have '(ESG)' keyword in the chunk_title. If there is no such document then say 'The latest S&P Global Ratings research does not mention specific does not provide any details on xyz's environmental, social or governance initiatives or performance.'."
}
__________________
{
    "question": "Compare the ESG profile between xyz and abc",
    "guidelines": "1. At the beginning of your response, you MUST provide a concise summary or abstract that encapsulates the main points of your entire response. This summary should give the reader a clear and quick understanding of the key information and insights you will cover. Findings should include pluses and minuses for xyz and abc and short resume which profile is better in each catagory. \n 2. Follow-Up Guidelines: After providing the summary, follow the rest of the guidelines as individual instructions to structure the detailed part of your response. \n 3. After that summary on top, write comparing of ESG (Environmental, Social, Governance) for xyz vs abc: Comparing of Environmental profiles, Comparing of Social profiles, Comparing of Governance profiles.  Start with 'Based on the latest S&P Global Rating's research, here is a comparison of the ESG profiles xyz and abc:' \n 4. Keep in mind that the given rating information documents that you pick to answer this question MUST have '(ESG)' keyword in the chunk_title. If there is no such document then say 'The latest S&P Global Ratings research does not mention specific does not provide any details on xyz’s or/and abc’s environmental, social or governance initiatives or performance.'."
}

__________________
{
    "question": "What's the difference in the ESG characteristics between xyz and abc?",
    "guidelines": "1. At the beginning of your response, you MUST provide a concise summary or abstract that encapsulates the main points of your entire response. This summary should give the reader a clear and quick understanding of the key information and insights you will cover. Findings should include pluses and minuses for xyz and abc and short resume which profile is better in each catagory. \n 2. Follow-Up Guidelines: After providing the summary, follow the rest of the guidelines as individual instructions to structure the detailed part of your response. \n 3. After that summary on top, write comparing of ESG (Environmental, Social, Governance) for xyz vs abc: Comparing of Environmental profiles, Comparing of Social profiles, Comparing of Governance profiles. Start with 'Based on the latest S&P Global Rating's research, here is a comparison of the ESG profiles xyz and abc:' \n 4. Keep in mind that the given rating information documents that you pick to answer this question MUST have '(ESG)' keyword in the chunk_title. If there is no such document then say 'The latest S&P Global Ratings research does not mention specific does not provide any details on xyz’s or/and abc’s environmental, social or governance initiatives or performance.'."
}
__________________
{
    "question": "ESG Profile of xyz versus abc?",
    "guidelines": "1. At the beginning of your response, you MUST provide a concise summary or abstract that encapsulates the main points of your entire response. This summary should give the reader a clear and quick understanding of the key information and insights you will cover. Findings should include pluses and minuses for xyz and abc and short resume which profile is better in each catagory. \n 2. Follow-Up Guidelines: After providing the summary, follow the rest of the guidelines as individual instructions to structure the detailed part of your response. \n 3. After that summary on top, write comparing of ESG (Environmental, Social, Governance) for xyz vs abc: Comparing of Environmental profiles, Comparing of Social profiles, Comparing of Governance profiles.  Start with 'Based on the latest S&P Global Rating's research, here is a comparison of the ESG profiles of xyz and abc:' \n 4. Keep in mind that the given rating information documents that you pick to answer this question MUST have '(ESG)' keyword in the chunk_title. If there is no such document then say 'The latest S&P Global Ratings research does not mention specific does not provide any details on xyz’s or/and abc’s environmental, social or governance initiatives or performance.'."
}

"""

ESG_GUIDELINES_PROMPTS = """
You are an excellent financial credit analyst and you will be given a question from the user.
Your task will be to extract information regarding user question:
* Guidelines highlighting relevant factors when answering the question. (key: guidelines)

<Examples pairs of question (key: question) and guidelines (key: guidelines) are given below in JSON format: Do not stick completely to the values for guidelines shown in examples they are only for taking hints>
{examples}

Take a deep breath and understand that these examples should not affect the extractions for any other keys.

Answer JSON object which should contain following properties:
* "guidelines"

<Question>
{question}

Just return an guidelines JSON object. Return the JSON object only. Do not return 'Here are the guidelines for answering the question "{question}":' or any other string.
"""

esg_guidelines = {
    "prompt": ESG_GUIDELINES_PROMPTS,
    "examples": {
        EntityType.COMPANY: ESG_GUIDELINES_EXAMPLES,
        EntityType.USPF: ESG_GUIDELINES_EXAMPLES,
        EntityType.REVENUE_SOURCE: ESG_GUIDELINES_EXAMPLES,
        EntityType.SOVEREIGN: ESG_GUIDELINES_EXAMPLES,
    },
}
