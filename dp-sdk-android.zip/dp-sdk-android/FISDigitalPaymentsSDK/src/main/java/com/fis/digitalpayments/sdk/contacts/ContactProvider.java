// Copyright Notice!
// This document is protected under the trade secret and copyright
// laws as the property of Fidelity National Information Services, Inc.
// Copying, reproduction or distribution should be limited and only to
// employees with a “need to know” to do their job.
// Any disclosure of this document to third parties is strictly prohibited.
// © 2016 Fidelity National Information Services.
// All rights reserved worldwide.

package com.fis.digitalpayments.sdk.contacts;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;
import android.text.TextUtils;
import android.util.Base64;

import com.fis.digitalpayments.sdk.core.BridgeException;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.regex.Pattern;

import static com.fis.digitalpayments.sdk.core.BridgeJSONOperationWrapper.putJSON;

/**
 * Encapsulates functionality required to retrieve contacts.
 */
@SuppressWarnings({"unused"}) // Suppression needed to support android API 17
class ContactProvider {

    private final Uri QUERY_URI = ContactsContract.Contacts.CONTENT_URI;
    private final String mPhoneArrayPropertyName = "phones";
    private final String mEmailArrayPropertyName = "emails";
    private static final Pattern mEmailPattern
            = Pattern.compile("[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}");

    JSONObject getContact(Uri uri, Context context) throws BridgeException {
        Cursor cursor = null;
        String contactId = null;
        try {
            cursor = context.getContentResolver().query(uri, new String[]{ContactsContract.Contacts._ID}, null, null, null);
            if (cursor != null && cursor.getCount() > 0 && cursor.moveToFirst()) {
                contactId = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts._ID));
            }
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }

        JSONObject contact = new JSONObject();
        putJSON(contact, "contact", getContact(contactId, context));

        return contact;
    }

    private JSONObject getContact(String contactId, Context context) throws BridgeException {
        JSONObject contact = new JSONObject();

        putJSON(contact, "id", contactId);

        String name = getName(contactId, context);
        putJSON(contact, "name", name);

        JSONArray phoneNumbers = getPhoneNumbers(contactId, context);
        if (phoneNumbers != null) {
            putJSON(contact, mPhoneArrayPropertyName, phoneNumbers);
        }

        JSONArray emailAddresses = getEmailAddresses(contactId, context);
        if (emailAddresses != null) {
            putJSON(contact, mEmailArrayPropertyName, emailAddresses);
        }

        String photo = getPhoto(contactId, context);
        if (photo != null) {
            putJSON(contact, "photo", photo);
        }

        return contact;
    }

    /**
     * Collects id, name, emails, and phone numbers for contacts.
     * @return JSON object representing device contacts.
     * @throws BridgeException on error retrieving contacts.
     */
    JSONObject getContacts(Context context) throws BridgeException {
        String CONTACT_ID = ContactsContract.Contacts._ID;
        String[] projection = new String[]{
                CONTACT_ID,
        };

        ContentResolver contentResolver = context.getContentResolver();
        Cursor cursor = null;
        JSONObject contacts;
        JSONArray contactsArray;

        try {
            cursor = contentResolver.query(QUERY_URI, projection, null, null, null);
            contactsArray = new JSONArray();

            if (cursor != null && cursor.getCount() > 0 && cursor.moveToFirst()) {
                do {
                    String contactId = cursor.getString(cursor.getColumnIndex(CONTACT_ID));
                    JSONObject contact = getContact(contactId, context);
                    if (isValidContact(contact)) {
                        contactsArray.put(contact);
                    }
                } while (cursor.moveToNext());
            }
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }

        contacts = new JSONObject();
        putJSON(contacts, "contacts", contactsArray);

        return contacts;
    }

    private String getName(String contactId, Context context) {
        String CONTACT_ID = ContactsContract.Contacts._ID;
        String DISPLAY_NAME = ContactsContract.Contacts.DISPLAY_NAME;
        String[] projection = new String[] {
                DISPLAY_NAME
        };

        Cursor nameCursor = null;
        String name = null;
        try {
            nameCursor = context.getContentResolver().query(
                    QUERY_URI,
                    projection,
                    CONTACT_ID + " = ?",
                    new String[]{contactId},
                    null);

            if (nameCursor != null && nameCursor.getCount() > 0 && nameCursor.moveToFirst()) {
                name = nameCursor.getString(nameCursor.getColumnIndex(DISPLAY_NAME));
                if (name != null) {
                    name = TextUtils.htmlEncode(name);
                }
            }
        } finally {
            if (nameCursor != null) {
                nameCursor.close();
            }
        }
        return name;
    }

    private JSONArray getPhoneNumbers(String contactId, Context context) throws BridgeException {
        String PHONE_CONTACT_ID = ContactsContract.CommonDataKinds.Phone.CONTACT_ID;
        String PHONE_TYPE = ContactsContract.CommonDataKinds.Phone.TYPE;
        String PHONE_NUMBER = ContactsContract.CommonDataKinds.Phone.NUMBER;
        String[] projection = new String[]{
                PHONE_CONTACT_ID,
                PHONE_TYPE,
                PHONE_NUMBER
        };

        Cursor phoneCursor = null;
        JSONArray phoneNumbers = null;
        try {
            phoneCursor = context.getContentResolver().query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    projection,
                    PHONE_CONTACT_ID + " = ?",
                    new String[]{contactId},
                    null);

            if (phoneCursor != null && phoneCursor.getCount() > 0 && phoneCursor.moveToFirst()) {

                phoneNumbers = new JSONArray();
                do {
                    JSONObject phoneNumber = new JSONObject();
                    if(phoneCursor.getString(phoneCursor.getColumnIndex(PHONE_NUMBER)) != null) {
                        String phoneNumberValue = phoneCursor.getString(phoneCursor.getColumnIndex(PHONE_NUMBER));
                        if (isValidPhoneNumber(phoneNumberValue)) {
                            CharSequence phoneNumberType;
                            try {
                                int phoneTypeId = Integer.parseInt(phoneCursor.getString(phoneCursor.getColumnIndex(PHONE_TYPE)));
                                phoneNumberType = ContactsContract.CommonDataKinds.Phone.getTypeLabel(context.getResources(), phoneTypeId, "");
                            } catch (Exception e) {
                                phoneNumberType = "Custom";
                            }

                            putJSON(phoneNumber, "type", phoneNumberType);
                            putJSON(phoneNumber, "number", phoneNumberValue);

                            phoneNumbers.put(phoneNumber);
                        }
                    }
                } while (phoneCursor.moveToNext());
            }
        } finally {
            if (phoneCursor != null) {
                phoneCursor.close();
            }
        }

        return phoneNumbers;
    }

    private JSONArray getEmailAddresses(String contactId, Context context) throws BridgeException {
        String EMAIL_CONTACT_ID = ContactsContract.CommonDataKinds.Email.CONTACT_ID;
        String EMAIL_ADDRESS = ContactsContract.CommonDataKinds.Email.ADDRESS;

        String[] projection = new String[] {
                EMAIL_CONTACT_ID,
                EMAIL_ADDRESS
        };

        Cursor emailCursor = null;
        JSONArray emailAddresses = null;
        try {
            emailCursor = context.getContentResolver().query(
                    ContactsContract.CommonDataKinds.Email.CONTENT_URI,
                    projection,
                    EMAIL_CONTACT_ID + " = ?",
                    new String[]{contactId},
                    null);

            if (emailCursor != null && emailCursor.getCount() > 0 && emailCursor.moveToFirst()) {

                emailAddresses = new JSONArray();
                do {
                    JSONObject emailAddress = new JSONObject();
                    if (emailCursor.getString(emailCursor.getColumnIndex(EMAIL_ADDRESS)) != null) {
                        String emailAddressValue = TextUtils.htmlEncode(emailCursor.getString(emailCursor.getColumnIndex(EMAIL_ADDRESS)));

                        if (isValidEmailAddress(emailAddressValue)) {
                            putJSON(emailAddress, "address", emailAddressValue);
                            emailAddresses.put(emailAddress);
                        }
                    }
                } while (emailCursor.moveToNext());
            }
        } finally {
            if (emailCursor != null) {
                emailCursor.close();
            }
        }
        return emailAddresses;
    }

    private String getPhoto(String contactId, Context context) {
        Uri contactUri = ContentUris.withAppendedId(QUERY_URI, Long.parseLong(contactId));
        Uri photoUri = Uri.withAppendedPath(contactUri, ContactsContract.Contacts.Photo.CONTENT_DIRECTORY);
        Cursor photoCursor = null;
        String photo = null;

        try {
            photoCursor = context.getContentResolver().query(photoUri, new String[]{ContactsContract.Contacts.Photo.PHOTO}, null, null, null);

            if (photoCursor != null && photoCursor.getCount() > 0 && photoCursor.moveToFirst()) {

                byte[] photoData = photoCursor.getBlob(0);
                if (photoData != null) {
                    photo = Base64.encodeToString(photoData, Base64.NO_WRAP);
                }
            }
        } finally {
            if (photoCursor != null) {
                photoCursor.close();
            }
        }

        return photo;
    }

    // Check contact to determine if it is "valid" to return from SDK
    private boolean isValidContact(JSONObject contact) {
        boolean isValid = false;

        if (contact != null) {
            try {
                String name = contact.getString("name");
                if (name != null) {
                    JSONArray phones = contact.getJSONArray(mPhoneArrayPropertyName);
                    if (phones != null && phones.length() > 0) {
                        isValid = true;
                    }
                    else {
                        JSONArray emails = contact.getJSONArray(mEmailArrayPropertyName);
                        if (emails != null && emails.length() > 0) {
                            isValid = true;
                        }
                    }
                }
            } catch (JSONException e) {  }
        }

        return isValid;
    }

    private boolean isValidEmailAddress(String emailAddress) {
        // Check for basic email structure
        return mEmailPattern.matcher(emailAddress).matches();
    }

    private boolean isValidPhoneNumber(String phoneNumber) {
        boolean isValid = false;
        if (phoneNumber != null) {
            String digits = phoneNumber.replaceAll("[^0-9]", "");
            if (digits.length() >= 7 && digits.length() <= 11) {
                isValid = true;
            }
        }
        return isValid;
    }
}
