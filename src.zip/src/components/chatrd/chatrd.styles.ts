
export const styles = {
  nodisclaimer: {
    marginLeft:'-16px',
  },

  disclaimer:{
    marginLeft:'-16px',
    height:'100%',
    opacity: 0.5,
    pointerEvents: 'none'

  }
};