import json
import os
import time

import pandas as pd
import tqdm.auto as tqdm
from langchain_core.runnables import RunnableLambda
from langchain_aws.chat_models import ChatBedrockConverse

from chatrd.engine.components.query_analyzer.guardrail.input_moderation_guardrail import (
    InputModerationGuardrail,
)


def open_test_questions(q_dir, q_files):
    dfs = []
    for f in q_files:
        path = os.path.join(q_dir, f)
        dfs.append(pd.read_csv(path, sep='*', header=0))

    return pd.concat(dfs).fillna("").reset_index(drop=True)


def filter_content(user_input):

    query = GUARDRAIL_OBJ._process_user_input_into_moderation_prompt(user_input)

    llm = ChatBedrockConverse(model=MODEL_ID)

    messages = [("user", query)]

    model_response = llm.invoke(messages)

    answer = GUARDRAIL_OBJ._postprocess_model_response_text(model_response.text())

    return json.loads(answer.strip())


def run_evaluation():
    filter_step = RunnableLambda(filter_content)
    df = open_test_questions(QUESTIONS_DIR, QUESTIONS_FILES)

    guardrail_outputs = []
    errors = []

    start = time.time()
    for index, row in tqdm.tqdm(df.iterrows()):
        question = row["question"]

        try:
            response = filter_step.invoke(question)
            # response = json.loads(response)

            guardrail_output = response["question_blocked"]
            # guardrail_notes = response.get("notes")

            output_dict = {
                "question": question,
                "ground_truth_blocked": row["ground_truth_blocked"],
                "ground_truth_blocked_reason": row["blocked_reason"],
                "prediction": guardrail_output,
                "full_response": response,
            }

            for c in response["blocked_categories"]:
                output_dict[c] = True

            guardrail_outputs.append(output_dict)
        except Exception as e:
            print(e)
            # print(response)
            errors.append(response)
            continue

    end = time.time()

    total_duration = end - start

    df2 = pd.DataFrame(guardrail_outputs)
    df2["ground_truth_blocked"] = df2["ground_truth_blocked"].astype(str).str.lower()
    df2["prediction"] = df2["prediction"].astype(str).str.lower()
    df3 = df2.loc[df2["ground_truth_blocked"] != df2["prediction"]]
    tp_plus_fp = df2.loc[df2["ground_truth_blocked"] == "true"]
    tp_plus_fn = df2.loc[df2["prediction"] == "true"]
    tp = tp_plus_fp.loc[tp_plus_fp["prediction"] == "true"]
    recall = tp.shape[0] / tp_plus_fp.shape[0]
    precision = tp.shape[0] / tp_plus_fn.shape[0]

    avg_q_time = total_duration / df.shape[0]

    results = {
        "total_questions": df.shape[0],
        "num_questions_answered": df2.shape[0],
        "error_outputs": df.shape[0] - df2.shape[0],
        "avg_query_time_secs": avg_q_time,
        "valid_questions_total": df2.loc[df2["ground_truth_blocked"] == "false"].shape[0],
        "invalid_questions_total": df2.loc[df2["ground_truth_blocked"] == "true"].shape[0],
        "invalid_q_categories": {
            "advice": df2.loc[df2["ground_truth_blocked_reason"] == "advice"].shape[0],
            "malicious": df2.loc[df2["ground_truth_blocked_reason"] == "malicious"].shape[0],
            "opinion": df2.loc[df2["ground_truth_blocked_reason"] == "opinion"].shape[0],
            "internal_operations": df2.loc[df2["ground_truth_blocked_reason"] == "internal_operations"].shape[0],
            "confidential": df2.loc[df2["ground_truth_blocked_reason"] == "confidential"].shape[0],
            "competitors": df2.loc[df2["ground_truth_blocked_reason"] == "competitors"].shape[0],
            "client_support": df2.loc[df2["ground_truth_blocked_reason"] == "client_support"].shape[0],
            # "public_filings": df2.loc[df2["ground_truth_blocked_reason"] == "public_filings"].shape[0],
        },
        "guardrail_acted_correctly": df2.loc[df2["ground_truth_blocked"] == df2["prediction"]].shape[0],
        "guardrail_acted_incorrectly": df3.shape[0],
        "recall": recall,
        "precision": precision,
        "blocked_valid_question": df3.loc[df3["ground_truth_blocked"] == False].shape[0],
        "allowed_invalid_question": df3.loc[df3["ground_truth_blocked"] == True].shape[0],
    }

    filters = [
        "Investment_Advice",
        "Malicious_Prompts",
        "Opinions_of_Quality",
        "SP_Internal_Operations",
        "Confidential_Information",
        "Competitors",
        "Client_Support",
        # "Public_Filings",
        # "public_filings_kw",
        # "competitors_kw",
    ]
    map_filter_to_reason = {
        "Investment_Advice": "advice",
        "Malicious_Prompts": "malicious",
        "Opinions_of_Quality": "opinion",
        "SP_Internal_Operations": "internal_operations",
        "Competitors": "competitors",
        "Confidential_Information": "confidential",
        "Client_Support": "client_support",
        # "Public_Filings": "public_filings",
        # "public_filings_kw": "public_filings_kw",
        # "competitors_kw": "competitors_kw",
    }

    incorrectly_applied_filters = {}
    for f in filters:
        try:
            incorrectly_applied_filters[f] = df3.loc[df3[f] == True].shape[0]
        except:
            pass

    results["incorrectly_applied_filters"] = incorrectly_applied_filters

    failed_to_apply_filters = {}

    for f in filters:
        try:
            reason = map_filter_to_reason[f]
            failed_to_apply_filters[f] = df3.loc[df3["ground_truth_blocked_reason"] == reason].shape[0]
        except:
            pass

    results["failed_to_apply_filters"] = failed_to_apply_filters

    with open(os.path.join(OUTPUT_DIR, "results.json"), "w") as f:
        json.dump(results, f)

    df2.to_csv(os.path.join(OUTPUT_DIR, "guardrail_question_output.csv"), index=False)
    df2.loc[df2["ground_truth_blocked"] != df2["prediction"]].to_csv(
        os.path.join(OUTPUT_DIR, "guardrail_question_output_no_match.csv"), index=False
    )


if __name__ == "__main__":
    QUESTIONS_DIR = "/home/sagemaker-user/creditcompanion-gitlab/creditcompanion/scripts/guardrails/"
    QUESTIONS_FILES = [
        # "advice.csv",
        # "malicious.csv",
        # "opinion.csv",
        # "internal_operations.csv",
        # "competitors.csv",
        # "confiential.csv",
        # "client_support.csv",
        # "public_filings_kw.csv",
        # "valid_public_filings_kw.csv",
        # "non_blocked_questions_full.csv",
        "test.tsv"
    ]

    MODEL_IDS = {
        "claude3sonnet1": "anthropic.claude-3-sonnet-20240229-v1:0",
        "claude3haiku1": "anthropic.claude-3-haiku-20240307-v1:0",
        "claude35sonnet1": "us.anthropic.claude-3-5-sonnet-20240620-v1:0",
        "claude35haiku1": "us.anthropic.claude-3-5-haiku-20241022-v1:0",
        "claude35sonnet2": "us.anthropic.claude-3-5-sonnet-20241022-v2:0",
        "claude37sonnet1": "us.anthropic.claude-3-7-sonnet-20250219-v1:0",
        "novapro1": "us.amazon.nova-pro-v1:0",
        "novalite1": "us.amazon.nova-lite-v1:0",
        "novamicro1": "us.amazon.nova-micro-v1:0",
        "llama33": "us.meta.llama3-3-70b-instruct-v1:0",
        "llama32": "us.meta.llama3-2-11b-instruct-v1:0",
    }

    GUARDRAIL_OBJ = InputModerationGuardrail()

    # choose the model for evaluation
    MODEL = "claude35sonnet2"
    MODEL_ID = MODEL_IDS[MODEL]

    # create output dir
    OUTPUT_DIR = f"outputs/{MODEL}"
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    run_evaluation()
