import argparse
import json
import logging
import pathlib

import numpy as np
import pandas as pd
from tqdm import tqdm

from chatrd.engine.components.query_analyzer.uc_router import EndpointRouter


def init_parser():
    parser = argparse.ArgumentParser(
        description="""
    This script is used to evaluate the query classification using KNN.
    It loads the question set from a JSON file and compares the classification results.
    """
    )
    parser.add_argument(
        "--embedding-file-path",
        type=str,
        help="filename to load the embeddings for evaluation",
    )
    parser.add_argument(
        "--question-file-path",
        type=str,
        help="filename to load the questions for evaluation",
    )
    parser.add_argument(
        "--result-file-path",
        type=str,
        help="filename to save the results",
        default="test_error.csv",
    )
    parser.add_argument(
        "--model-name", type=str, help="name of the model to be used for the router", default="finetuned"
    )

    return parser


def setup_logging():
    import logging

    logging.basicConfig(
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        level=logging.INFO,
    )
    logger = logging.getLogger(__name__)
    return logger


if __name__ == "__main__":
    logger = setup_logging()
    parser = init_parser()
    args = parser.parse_args()

    # Load embeddings
    embeddings = np.load(args.embedding_file_path)

    # Load questions
    try:
        filepath = pathlib.Path(args.question_file_path).resolve()
        with filepath.open("rt") as file:
            questions = json.load(file)
    except Exception as e:
        logger.error(f"Error {e} in loading file {args.question_file_path}")

    logger.info(f"Loaded question set from {args.question_file_path}")

    # Initialize the router
    router = EndpointRouter(model_name='endpoint_embedder')

    df = []
    ques_len = 0
    for uc_name in questions:
        for question in tqdm(questions[uc_name]):
            res = router.run(question)[0]
            if res != uc_name:
                logger.info(f"Question: {question}")
                logger.info(f"Expected: {uc_name}")
                logger.info(f"Got: {res}")
                df.append({"Question": question, "Expected": uc_name, "Got": res})
        ques_len += len(questions[uc_name])

    df = pd.DataFrame(data=df)

    # Save the results
    df.to_csv(args.result_file_path, index=False)
    logger.info(f"Results saved to {args.result_file_path}")

    # Log the accuracy
    accuracy = (ques_len - len(df)) / ques_len
    logger.info(f"Accuracy: {accuracy}")
