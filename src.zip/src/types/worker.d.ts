declare module "*.worker.js"{
  class WorkerClass extends Worker{
	constructor();
  }
export = WorkerClass;
}
