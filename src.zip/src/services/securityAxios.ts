import axios from 'axios';
import * as rax from 'retry-axios';

const axiosSecurityInstance = axios.create();
axiosSecurityInstance.defaults.raxConfig = {
  instance: axiosSecurityInstance,
  retry: 2,
  noResponseRetries: 2,
  retryDelay: 5000,
  httpMethodsToRetry: ['POST'],
  statusCodesToRetry: [
    [100, 199],
    [500, 599],
  ],
  backoffType: 'exponential',
  onRetryAttempt: (err) => {
    const cfg = rax.getConfig(err);
    console.log(`Retry attempt #${cfg.currentRetryAttempt}`);
    return null;
  },
  shouldRetry: (err) => {
    switch (err.message) {
      case 'Network Error':
        return false;
    }
    const cfg = rax.getConfig(err);

    if (cfg) {
      if ((cfg.currentRetryAttempt || 0) >= (cfg.retry || 0)) {
        return false; // ensure max retries is always respected
      }
    }
    return rax.shouldRetryRequest(err);
  },
};
rax.attach(axiosSecurityInstance);

export default axiosSecurityInstance;
