TABLE_DECTECTION_LLM_PROMPT = """
You are a smart assistant designed to detect whether the user explicitly prefers a TABLE format for a financial summary.

Inputs:
- user_query: "{user_query}"
Rules:
1. If the user explicitly mentions "table", "tabular format", "as a table", "in a table", etc. → classify as TABLE.
2. If the user does **not** explicitly mention a table → classify as UNKNOWN.
3. Do **not** infer text preference, only detect if a table is explicitly requested.

Output ONLY in the following format (no extra commentary):

format: <TABLE or UNKNOWN>
"""


PROMPT_FINANCIAL_SYNTHESIZER_TEMPLATE = """
<Instruction>
You are an AI assistant. Based on the provided input_data, generate a well-formatted summary of financial metrics grouped by company and fiscal period.

Each entry in input_data contains:
- "KeyInstn": Institution ID
- "MetricName": The financial metric name (use this exactly as-is)
- "MetricValue": The numerical value
- "Period": The fiscal period (e.g., "2023Q1", "2023Y") — may include whitespace (trim it)
- "Magnitude": The unit or scale (e.g., "$M", "€M") — if present, must be shown
- "KeyCurrency": The currency code (e.g., "USD", "EUR")
- "Company": The company name
- "citation_url": The citation URL in valid HTML anchor tag format

</Instruction>

<Strict Rules>
1. Begin with an introductory line:
   - Use only the unique MetricName(s), Company name(s), and Period(s) present in the input_data.
   - Do not include any companies or periods not present in input_data.
   - Do not assume full quarter/year coverage.
2. Group the data by Company → then by Period (as-is, maintaining input order).
3. For each metric row:
   - Always include: MetricName, MetricValue, and citation_url.
   - Include Magnitude only if it is not null.
4. Do not skip or hallucinate any value, Magnitude, or citation.
5. Do not add any explanations, disclaimers, or commentary about missing data.
6. Do not paraphrase or rename any fields.
</Strict Rules>

<Formatting>
The {{MetricName list}} for {{Company list}} for {{Period list}} {{is/are}} as follows:

* Fiscal Quarter or Year:
    * Metric Name: Value Magnitude (if available) citation_url
</Formatting>

<Example>
The EBIT Interest Coverage, Adjusted and EBITDA Interest Coverage, Adjusted for Apple Inc. for 2024Q1 are as follows:

* Fiscal Quarter 2024Q1:
    * EBIT Interest Coverage, Adjusted: 1.42 <a href="https://capitaliqdev.spglobal.com/web/client#company/csd?Id=4004205" title="Apple Inc.-Financial Highlights" target="_blank" rel="noopener noreferrer" class="ccInTextCitation">[1]</a>
    * EBITDA Interest Coverage, Adjusted: 1.34 <a href="https://capitaliqdev.spglobal.com/web/client#company/csd?Id=4004205" title="Apple Inc.-Financial Highlights" target="_blank" rel="noopener noreferrer" class="ccInTextCitation">[1]</a>
</Example>

<Final Reminder>
- Always use the citation_url from the input_data.
- Show Magnitude if present; omit it if null.
- Do not hallucinate values or mention missing companies/quarters.
- Don't forget that your response must be in {original_language}.
input_data: {input_data}
"""
