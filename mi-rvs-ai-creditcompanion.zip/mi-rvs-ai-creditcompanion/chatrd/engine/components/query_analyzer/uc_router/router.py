import logging
from typing import Dict, List, Optional, Tuple, Union

import numpy as np

from chatrd.core.embedding import embedding_factory
from chatrd.engine.components.query_analyzer.conversational.prompts.rephrasing_prompts import (
    RephrasingOutput,
)
from chatrd.engine.components.query_analyzer.faulttolerantexecutor import (
    FaultTolerantExecutor,
)
from chatrd.engine.components.query_analyzer.uc_router.utils import cosine_similarity

logger = logging.getLogger(__name__)


class UCRouter:
    """
    This class represents the routing functionality for different use case we have.
    Right now, we are dealing with question type (e.g. ratings, outlook, macros, etc).
    """

    def __init__(self, embeddings: Dict[str, List[List[float]]], model_name: str):
        self.classes = list(embeddings)
        self.embeddings = np.array(list(embeddings.values()))
        self.model = embedding_factory(model_name=model_name)

    def run(self, query: str) -> List[Tuple]:
        query_embedding = self.model.embed_query(query)
        return self._get_classes_with_scores(query_embedding)

    def _get_classes_with_scores(self, query_embedding: List[float]):
        if self.embeddings.shape[0] != len(self.classes):
            raise ValueError("Difference in length of embeddings and classes.")
        similarities = cosine_similarity(np.asarray(query_embedding), self.embeddings)
        class_scores = list(zip(self.classes, similarities))
        sorted_class_scores = sorted(class_scores, key=lambda x: x[1], reverse=True)
        logger.debug(f"Sorted scores from different classes with UC Router : {sorted_class_scores}")
        return sorted_class_scores


class EndpointRouter(FaultTolerantExecutor):
    def __init__(self, model_name: str):
        self.model = embedding_factory(model_name=model_name)

    def get_default_value(self) -> List[str]:
        return ["general"]

    def run(self, query: Union[List[str], str]) -> List[str]:
        prediction = self.model.classify_query([query] if isinstance(query, str) else query)["predictions"]
        logger.info(f"Predicted uc_type for UC Router : {prediction}")
        return prediction


class MultiTopicEndpointRouter(FaultTolerantExecutor):

    def get_default_value(self) -> List[str]:
        return ["general"]

    def __init__(self, model_name: str):
        self.model = embedding_factory(model_name=model_name)
        self.tagged_routes_map = {
            "criteria": "criteria",
            "definitions": "definition",
            "dataquery": "query",
            "allresearch": "general",
            "macroresearch": "general",
            "entityresearch": "general",
        }

    def run(self, query: Union[List[str], str], **kwargs) -> List[str]:
        # queries = []
        # if isinstance(query_input, RephrasingOutput):
        #     if multi_topic:
        #         queries = query_input.subqueries
        #     else:
        #         queries = [query_input.rephrased_initial_question]
        # if isinstance(query_input, str):
        #     queries = [query_input]
        # predictions = self.model.classify_query(queries)["predictions"]
        # logger.info(f"Predicted uc_types {list(zip(queries, predictions))}")
        # return predictions
        prediction = self.model.classify_query([query] if isinstance(query, str) else query)["predictions"]
        logger.info(f"Predicted uc_type for UC Router : {prediction}")
        return prediction

    def get_routing(self, query, tagged_routes=[], **kwargs) -> Tuple[List[str], bool]:
        if len(tagged_routes) != 0 and all(isinstance(h_r, str) for h_r in tagged_routes):
            for route in tagged_routes:
                if not (route.lower() in self.tagged_routes_map):
                    logger.error(f"Exception: No tool implemented for this use case type {route}.")
                    return ["suggested route failure"], False
            return [self.tagged_routes_map.get(route.lower()) for route in tagged_routes], True
        else:
            return self.execute(query=query)


# class MultiTopicEndpointRouter:
#     def __init__(self, model_name: str):
#         self.model = embedding_factory(model_name=model_name)

#     def run(self, query_input: Union[RephrasingOutput, str], multi_topic=False):
#         queries = []
#         if isinstance(query_input, RephrasingOutput):
#             if multi_topic:
#                 queries = query_input.subqueries
#             else:
#                 queries = [query_input.rephrased_initial_question]
#         if isinstance(query_input, str):
#             queries = [query_input]
#         predictions = self.model.classify_query(queries)["predictions"]
#         logger.info(f"Predicted uc_types {list(zip(queries, predictions))}")
#         return predictions
