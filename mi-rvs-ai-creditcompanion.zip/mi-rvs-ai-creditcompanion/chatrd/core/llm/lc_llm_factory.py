import logging
from typing import Optional, Tuple

from chatrd.core.aws_utils.bedrock import get_assumed_bedrock_llm_client
from chatrd.core.llm.bedrock_anthropic import AnthropicBedrockChat
from chatrd.core.llm.claude_3 import Claude3
from chatrd.core.llm.components.base import BaseLanguageModel
from chatrd.core.llm.llama_3 import Llama3Bedrock
from chatrd.core.llm.models import Bedrock, BedrockChat
from chatrd.engine.configuration import Constants, get_config_machinery

logger = logging.getLogger(__name__)

config_machinery = get_config_machinery()

SUPPORTERD_LLM_MODELS = config_machinery.get_config_value(Constants.GeneralConstants.SUPPORTERD_LLM_MODELS)
REASONING_MODELS = config_machinery.get_config_value(Constants.GeneralConstants.REASONING_MODELS)


class LCLLMFactory:
    def __init__(self, region_name: str = None):
        role_arn = config_machinery.get_config_value(Constants.Bedrock.BEDROCK_ROLE_ARN)
        region_name = (
            config_machinery.get_config_value(Constants.Bedrock.BEDROCK_REGION_NAME)
            if region_name is None
            else region_name
        )
        # Fetch the client once during initialization and cache it
        self.bedrock_client = get_assumed_bedrock_llm_client(role_arn=role_arn, region_name=region_name)[
            "bedrock-runtime"
        ]

    def get_llm(
        self,
        deployment_name_or_model_id: str,
        *args,
        **kwargs,
    ) -> BaseLanguageModel:
        logger.debug(
            f"LLM factory called with model_name {deployment_name_or_model_id} and temperature : {kwargs['temperature'] if 'temperature' in kwargs else None}."
        )
        platform_to_model_name = self._get_platform_to_model_name(deployment_name_or_model_id)

        if platform_to_model_name:
            platform_name, model_name = platform_to_model_name
            is_reasoning_model = sum([True if model_name in REASONING_MODELS else False])
            if platform_name == "BEDROCK":
                model_kwargs = {}
                if "temperature" in kwargs:
                    model_kwargs = {"temperature": kwargs["temperature"]}
                provider_name = model_name
                if "cohere" in provider_name:
                    model_kwargs["max_tokens_to_sample"] = 1024
                    return Bedrock(client=self.bedrock_client, model_id=model_name, model_kwargs=model_kwargs)
                elif "ai21" in provider_name:
                    model_kwargs["max_tokens_to_sample"] = 1024
                    return Bedrock(client=self.bedrock_client, model_id=model_name, model_kwargs=model_kwargs)
                elif "anthropic" in provider_name:
                    if (
                        ("claude-3" in model_name)
                        or ("claude-opus" in model_name)
                        or ("claude-sonnet" in model_name)
                        or ("claude-haiku" in model_name)
                        or ("haiku-4" in model_name)
                    ):
                        model_kwargs["max_tokens_to_sample"] = 2048
                        if "guardrail_identifier" in kwargs:
                            model_kwargs["guardrail_identifier"] = kwargs["guardrail_identifier"]
                        if "guardrail_version" in kwargs:
                            model_kwargs["guardrail_version"] = kwargs["guardrail_version"]
                        if "reasoning_config" in kwargs and is_reasoning_model:
                            model_kwargs["reasoning_config"] = kwargs["reasoning_config"]
                        updated_model_name = model_name
                        if "claude-3-haiku" in model_name:
                            updated_model_name = config_machinery.get_config_value(
                                Constants.Bedrock.COHERE_HAIKU_INFERENCE_PROFILE_ARN
                            )
                        elif "claude-sonnet-4-20250514-v1:0" in model_name:
                            model_kwargs["max_tokens_to_sample"] = 4096
                        elif "claude-3-5-sonnet-20241022-v2:0" in model_name:
                            # default max_tokens_to_sample value overriden with 8192 for Sonnet 3.5
                            # see: https://docs.anthropic.com/en/docs/about-claude/models/overview
                            model_kwargs["max_tokens_to_sample"] = 8192
                            updated_model_name = config_machinery.get_config_value(
                                Constants.Bedrock.ANTHROPIC_SONNET_35_V2_INFERENCE_PROFILE_ARN
                            )
                        elif "claude-3-7-sonnet-20250219-v1:0" in model_name:
                            updated_model_name = config_machinery.get_config_value(
                                Constants.Bedrock.ANTHROPIC_SONNET_37_V1_INFERENCE_PROFILE_ARN
                            )
                        elif "claude-sonnet-4-20250514-v1:0" in model_name:
                            updated_model_name = config_machinery.get_config_value(
                                Constants.Bedrock.ANTHROPIC_SONNET_4_V1_INFERENCE_PROFILE_ARN
                            )
                        elif "claude-haiku-4-5-20251001-v1:0" in model_name:
                            updated_model_name = config_machinery.get_config_value(
                                Constants.Bedrock.ANTHROPIC_HAIKU_45_V1_INFERENCE_PROFILE_ARN
                            )
                        return Claude3(
                            client=self.bedrock_client, model_id=updated_model_name, model_kwargs=model_kwargs
                        )
                    else:
                        model_kwargs["stop_sequences"] = ["\n\nHuman:"]
                        model_kwargs["max_tokens"] = 2048
                        return AnthropicBedrockChat(
                            client=self.bedrock_client,
                            model_id=updated_model_name,
                            model_kwargs=model_kwargs,
                            provider="anthropic",
                        )
                elif "meta" in provider_name:
                    model_kwargs["max_gen_len"] = 1024
                    if "llama3" in model_name:
                        return Llama3Bedrock(client=self.bedrock_client, model_id=model_name, model_kwargs=model_kwargs)
                    else:
                        return BedrockChat(client=self.bedrock_client, model_id=model_name, model_kwargs=model_kwargs)
                else:
                    return BedrockChat(client=self.bedrock_client, model_id=model_name, model_kwargs=model_kwargs)
            else:
                raise ValueError("Provided model is not supported by any providers.")
        else:
            raise ValueError("Provided model is not supported by any providers/ misspelled model name.")

    def _get_platform_to_model_name(self, deployment_name_or_model_id: str) -> Optional[Tuple[str, str]]:
        supported_models = SUPPORTERD_LLM_MODELS
        platform_to_model_name = next(
            (
                (key, value)
                for key, values in supported_models.items()
                for value in values
                if deployment_name_or_model_id in value
            ),
            None,
        )
        return platform_to_model_name
