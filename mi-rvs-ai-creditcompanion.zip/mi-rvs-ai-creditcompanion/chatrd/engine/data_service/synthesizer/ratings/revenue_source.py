import logging
from typing import Optional

import pandas as pd

from chatrd.engine.components.query_analyzer.translator.utils import (
    Get_translation_result,
)
from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.data_service.schema import (
    Analyzer,
    ProcessorInput,
    Retriever,
    Synthesizer,
)
from chatrd.engine.data_service.synthesizer.base import BaseSynthesizer
from chatrd.engine.data_service.synthesizer.utils import (
    GenericTemplate,
    create_ratings_table,
    full_response,
    get_api_info,
)

logger = logging.getLogger(__name__)

config_machinery = get_config_machinery()

CWOL_MAPPING = config_machinery.get_config_value(Constants.DataService.CWOL_MAPPING)


class RevenueSourceRatingsSynthesizer(BaseSynthesizer, GenericTemplate):
    def source_description(self, df, entities):
        # default source description
        source_description = []

        # first check if we have revenue source name returned from screener
        try:
            rev_source_name = df["S&P RATINGS REVENUE SOURCE NAME"].iloc[0]
        except KeyError:
            # if returned dataframe does not contain issuer name,
            # no sourcing url is generated
            return source_description

        # get the source description URL from ChatRD
        rev_source_info = entities["revenue_sources"]
        # check to see if nything is returned
        if rev_source_info:
            # revenue source url is just a str field returned from search
            # and not a list (as for securities)
            url_add = rev_source_info[0]["url"]
            if not url_add:
                return source_description
        else:
            # empty security info
            return source_description

        sourcing_base_url = config_machinery.get_config_value(Constants.SourceGeneration.BASE_URL)
        footnote_url_slug = config_machinery.get_config_value(Constants.SourceGeneration.FOOTNOTE_URL_SLUG)
        source_description = [
            (
                rev_source_name + ": Revenue Source Profile",
                sourcing_base_url + footnote_url_slug + "?auth=inherit#" + url_add,
            )
        ]

        return source_description

    def leading_line(self, df) -> str:
        # entity name
        rev_source_name = df["S&P RATINGS REVENUE SOURCE NAME"].iloc[0]

        template = f"""{rev_source_name} has the following Revenue Source Ratings:"""
        return template

    def synthesize(
        self,
        processor: ProcessorInput = None,
        analyzer: Optional[Analyzer] = None,
        retriever: Retriever = None,
    ) -> Synthesizer:
        """
        Synthesizes a response based on the provided processor, analyzer, and retriever.

        Args:
            processor (Optional[ProcessorInput]): An object containing entity data.
            analyzer (Optional[Analyzer]): An optional analyzer object.
            retriever (Retriever): An object to retrieve API data.

        Returns:
            Synthesizer: An instance of Synthesizer containing the response and source description.
        """
        df = pd.DataFrame(retriever.api_data)
        entities = processor.entities
        count = retriever.total_count

        rating_cols = [
            "S&P CREDIT RATING LOCAL CURRENCY LT",
            "S&P CREDIT RATING LOCAL CURRENCY ST",
        ]
        template = self.leading_line(df)

        template = Get_translation_result(template, processor.original_language)
        template = template.result()
        # sometimes, the same revenue source name may be associated
        # with two ASIDiDs, one with LC LT and another with LC ST ratings
        # in this case screener will return two rows of data for two ASIDs
        # we need to identify this scenario and create a single table combining these two rows
        if df.shape[0] > 1:
            df_rev_src = df.copy()
            df_tabular_list = []
            for i in range(0, df_rev_src.shape[0]):
                df = df_rev_src.iloc[i].to_frame().T
                df_tabular, _ = create_ratings_table(df, rating_cols, "ICR")
                df_tabular_list.append(df_tabular)
            df_tabular = pd.concat(df_tabular_list)
            df_tabular = df_tabular.replace("", None)
            df_tabular = df_tabular.loc[df_tabular.Rating.notnull()]
            # we order by rating type since we want LC LT first
            df_tabular = df_tabular.sort_values(by=["Rating Type"], ascending=True)
        else:
            df_tabular, has_valid_rows = create_ratings_table(df, rating_cols, "ICR")

        response = full_response(
            template=template,
            data=df_tabular,
            data_type="table",
            count=count,
        )
        source_url = self.source_description(df=df, entities=entities)

        api_info = get_api_info(
            api_method=retriever.api_method,
            api_type=retriever.api_type,
            url=retriever.url,
            screener_payload=retriever.screener_payload,
        )

        return Synthesizer(data_service_response=response, source_description=source_url, api_info=api_info)
