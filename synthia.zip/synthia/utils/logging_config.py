import logging
import os
from typing import Dict, Optional, List

from src.synthia.utils.logging_context import get_logging_context


class ContextLogFilter(logging.Filter):
    """
    Injects correlation_id, job_id, and api_path into log records.
    """

    def filter(self, record):
        ctx = get_logging_context()
        record.correlation_id = ctx["correlation_id"]
        record.job_id = ctx["job_id"]
        record.api_path = ctx["api_path"]
        record.action_handler = ctx["action_handler"]
        record.prompt_id = ctx["prompt_id"]
        record.file_id = ctx["file_id"]
        return True


def configure_logging(
        logger_name: str = "root",
        log_file: str = 'synthia.log',
        level: int = logging.INFO,
        module_levels: Optional[Dict[str, int]] = None,
        quiet_modules: Optional[List[str]] = None
):
    """
    Configure logging with context filter for correlation_id, job_id, and api_path.

    Args:
        logger_name: Name of the root logger.
        log_file: Name of the log file.
        level: Default logging level.
        module_levels: Dict of module names and their specific log levels.
        quiet_modules: List of module names to set to WARNING level.
    """
    logging_handlers = [
        logging.StreamHandler()
    ]

    if os.environ.get("RUNNING_LOCALLY", "true").lower() in ("true", "1", "yes"):
        logging_handlers.append(logging.FileHandler(log_file))

    # Add context filter and formatter to all handlers
    for handler in logging_handlers:
        handler.setFormatter(CustomFormatter(
            fmt="%(asctime)s - %(name)s - %(levelname)s - %(context_info)s%(message)s (%(filename)s:%(lineno)d)"
        ))
        handler.addFilter(ContextLogFilter())

    logging.basicConfig(
        level=level,
        handlers=logging_handlers
    )

    if module_levels:
        for module_name, module_level in module_levels.items():
            logging.getLogger(module_name).setLevel(module_level)

    default_quiet_modules = [
        "httpcore.http11",
        "httpx",
        "urllib3",
        "httpcore",
        "asyncio",
        "charset_normalizer"
    ]
    all_quiet_modules = default_quiet_modules
    if quiet_modules:
        all_quiet_modules.extend(quiet_modules)
    for module in all_quiet_modules:
        logging.getLogger(module).setLevel(logging.WARNING)

    return logging.getLogger(name=logger_name)


class CustomFormatter(logging.Formatter):
    """
    Custom log formatter with color support and dynamic context string.
    Only includes present context fields in the log output.
    """
    blue = "\x1b[34m"
    grey = "\x1b[38m"
    yellow = "\x1b[33m"
    red = "\x1b[31m"
    bold_red = "\x1b[31;1m"
    reset = "\x1b[0m"

    def __init__(self, fmt=None, datefmt=None):
        # Use %(context_info)s in the format string
        fmt = fmt or "%(asctime)s - %(name)s - %(levelname)s - %(message)s (%(filename)s:%(lineno)d)"
        super().__init__(fmt=fmt, datefmt=datefmt)
        self.base_fmt = fmt
        self.FORMATS = {
            logging.DEBUG: self.blue + self.base_fmt + self.reset,
            logging.INFO: self.grey + self.base_fmt + self.reset,
            logging.WARNING: self.yellow + self.base_fmt + self.reset,
            logging.ERROR: self.red + self.base_fmt + self.reset,
            logging.CRITICAL: self.bold_red + self.base_fmt + self.reset
        }

    def format(self, record):
        # Build context_info string dynamically
        context_parts = []
        for field in ("correlation_id", "job_id", "prompt_id", "api_path", "action_handler", "file_id"):
            value = getattr(record, field, None)
            if value and value != "-":
                context_parts.append(f"{field}:{value}")
        record.context_info = f"[{' | '.join(context_parts)}] " if context_parts else ""
        log_fmt = self.FORMATS.get(record.levelno, self.base_fmt)
        formatter = logging.Formatter(log_fmt)
        return formatter.format(record)
