import logging
from datetime import date, timedelta
from typing import Tuple

import regex as re
from dateutil.parser import parse as date_parse
from dateutil.relativedelta import relativedelta
from word2number import w2n

from chatrd.engine.data_service.model_output_parser.variables import (
    GLOBAL_CREDIT_RATING_MAPPING,
    GLOBAL_CREDIT_WATCH_MAPPING,
    TRANS_DATE_MAPPING,
)

logger = logging.getLogger(__name__)


def update_unit_scale(lookup_value: str, magnitude: int) -> str:
    """
    Update the unit scale for numerical filters based on magnitude column in Vector DB.

    Args:
        lookup_value (str): lookup value for filtering.
        magnitude (int): magnitude to scale the value. In Vector DB

    Returns:
        str: updated lookup value.
    """
    if "-" in lookup_value:  # Between two numbers
        value_list = lookup_value.split("-")
        value_list_updated = [str(x).replace("[", "").replace("]", "") for x in value_list]
        value_list_updated = [int(x) / magnitude for x in value_list_updated]
        value_list_str = [f"[{x}]" for x in value_list_updated]
        new_lookup_value = "-".join(value_list_str)
    else:  # One number
        new_lookup_value = str(int(lookup_value) / magnitude)

    return new_lookup_value


def check_dynamic_time_window(kpqi, lookup_value, operator_payload) -> Tuple[str, int]:
    """
    This logic may need to be updated for other date KPQIs. Right now, it's only for
    announced and completion date under Transaction.

    Args:
        lookup_value (str): lookup value for filtering.
        operator_payload (int): operator payload.

    Returns:
        tuple: updated lookup value and operator payload.
    """
    cond_1 = lookup_value.lower() in TRANS_DATE_MAPPING.values()
    cond_2 = "]-[" in lookup_value  # Between two dates, no change needed.

    if lookup_value in TRANS_DATE_MAPPING:
        return TRANS_DATE_MAPPING[lookup_value].upper(), operator_payload
    elif cond_1 | cond_2:
        return lookup_value.upper(), operator_payload
    elif re.findall("^this", lookup_value.strip()):  # This year, this month, this week.
        lookup_value, operator_payload = _format_time_period(lookup_value)
        return lookup_value, operator_payload
    else:  # non default date range.
        lookup_value, operator_payload = _format_num_time_period(lookup_value, operator_payload)
        return lookup_value, operator_payload


def _format_time_period(lookup_value) -> Tuple[str, int]:
    """
    This logic converts time window such as "this week" to date range

    Args:
        lookup_value (str): lookup value for filtering.

    Returns:
        tuple: updated lookup value and operator payload.
    """
    time_unit = lookup_value.strip().split(" ")[-1]  # week, month, or year?
    today = date.today()
    if time_unit == "week":
        start = today - timedelta(days=today.weekday())
        lookup_value = _format_between_two_dates(start_date=start, end_date=today)
    elif time_unit == "month":
        start = today.replace(day=1)
        lookup_value = _format_between_two_dates(start_date=start, end_date=today)
    elif time_unit == "year":
        start = today.replace(day=1, month=1)
        lookup_value = _format_between_two_dates(start_date=start, end_date=today)
    else:
        raise KeyError(f"{lookup_value} is not a supported time range.")
    operator_payload = 17  # Change to "Between" operator.
    return lookup_value, operator_payload


def _format_num_time_period(lookup_value, operator_payload) -> Tuple[str, int]:
    """
    This logic converts time window such as "last x days" to date range

    Args:
        lookup_value (str): lookup value for filtering.

    Returns:
        tuple: updated lookup value and operator payload.
    """
    time_value_list = lookup_value.strip().split(" ")
    today = date.today()
    try:
        time_unit = time_value_list[-2]  # day, month, or year?
    except (IndexError, ValueError) as e:
        # Check if the time_value is a valid date?
        if date_parse(lookup_value):
            return lookup_value, operator_payload
        raise e

    time_range = w2n.word_to_num(time_unit)
    if "day" in lookup_value:
        starting_day = today - relativedelta(days=time_range)
    elif "month" in lookup_value:
        starting_day = today - relativedelta(months=time_range)
    elif "year" in lookup_value:
        starting_day = today - relativedelta(years=time_range)
    elif "week" in lookup_value or "weeks" in lookup_value:
        starting_day = today - relativedelta(days=time_range * 7)
    else:
        raise ValueError(f"The date format {lookup_value} " f"is not supported")
    lookup_value = _format_between_two_dates(start_date=starting_day, end_date=today)
    operator_payload = 17  # Change to "Between" operator.

    return lookup_value, operator_payload


class GenerateRatingList:
    """
    Convert user input value of rating to the correct list of ratings.
    """

    def __init__(self, rating_list=None):
        """
            Init function with rating list to compare.
        Args:
            rating_list (list): List of ratings to compare against and choose from
        """
        if rating_list:
            self.default_rating_types = rating_list
        else:
            self.default_rating_types = GLOBAL_CREDIT_RATING_MAPPING

    def greater_than(self, filter_rating) -> list:
        """
        This logic converts strings to format that accepts by data service api.
        Example: greater than a+ -> ['aaa', 'aa+', 'aa', 'aa-']

        Args:
        filter_rating (str): input rating string

        Returns:
            list: list of correct ratings
        """
        idx = self.default_rating_types.index(filter_rating)
        return self.default_rating_types[:idx]

    def less_than(self, filter_rating) -> list:
        idx = self.default_rating_types.index(filter_rating)
        return self.default_rating_types[idx + 1 :]

    def equal_greater_than(self, filter_rating) -> list:
        idx = self.default_rating_types.index(filter_rating)
        return self.default_rating_types[: idx + 1]

    def equal_less_than(self, filter_rating) -> list:
        idx = self.default_rating_types.index(filter_rating)
        return self.default_rating_types[idx:]

    def between(self, filter_rating) -> list:
        ratings = re.findall(r"\[([A-Za-z+]+|[A-Za-z-]+|[A-Za-z]+)\]", filter_rating)
        if not ratings:
            ratings = filter_rating.split(", ")
        idx_1 = self.default_rating_types.index(ratings[0])
        idx_2 = self.default_rating_types.index(ratings[1])
        return self.default_rating_types[min(idx_1, idx_2) : max(idx_1, idx_2) + 1]


def _format_rating_list_values(rating_list) -> str:
    """
    This logic converts strings to format that accepts by data service api. Example:
    "aaa, b" -> '"'aaa','b'"'

    Args:
        rating_list (list): list of rating strings.

    Returns:
        string: concatenated string of all rating strings.
    """
    if len(rating_list) == 1:
        return rating_list[0]
    else:
        str = '"'
        i = 0
        for s in rating_list:
            str += "'" + s + "'"
            if i < len(rating_list) - 1:
                str += ","
            i += 1
        str += '"'
        return str


def validate_rating_string(kpqi, value_str, operator_payload, operator_text):
    if kpqi == 334045:
        mapping_list = GLOBAL_CREDIT_RATING_MAPPING
        default_value = (
            "'AAA','AA+','AA','AA-','A+','A','A-','BBB+','BBB',"
            "'BBB-','BB+','BB','BB-','B+','B','B-','CCC+','CCC',"
            "'CCC-','CC','C','R','SD','D','NR'".lower()
        )
    elif kpqi == 334235:
        mapping_list = GLOBAL_CREDIT_WATCH_MAPPING
        default_value = (
            "'positive', 'developing', 'stable', 'negative', " "'watch pos', 'watch dev', 'watch neg', 'nm', 'nr'"
        )
    if "," in value_str:
        value_str_list = value_str.split(", ")
        for v in value_str_list:
            if v not in mapping_list:
                logger.error(f"Unsupported input {v}, will convert to defaut value " f"{default_value}")
                value_str = default_value
                operator_payload = 7
                operator_text = "in"
                return value_str, operator_payload, operator_text
        return value_str, operator_payload, operator_text

    elif "[" in value_str:
        value_str_list = re.findall(r"\[([A-Za-z+]+|[A-Za-z-]+|[A-Za-z]+)\]", value_str)
        for v in value_str_list:
            if v not in mapping_list:
                logger.error(f"Unsupported input {v}, will convert to defaut value " f"{default_value}")
                value_str = default_value
                operator_payload = 7
                operator_text = "in"
                return value_str, operator_payload, operator_text
        return value_str, operator_payload, operator_text
    else:
        if value_str not in mapping_list:
            logger.error(f"Unsupported input {value_str}, will convert to defaut value " f"{default_value}")
            value_str = default_value
            operator_payload = 7
            operator_text = "in"
            return value_str, operator_payload, operator_text
        else:
            return value_str, operator_payload, operator_text


def _format_between_two_dates(start_date, end_date) -> str:
    """
    Format the date range string for filtering.

    Args:
        start_date (datetime.date): start date
        end_date (datetime.date): end date

    Returns:
        str: formatted date range string
    """
    end_date = end_date.strftime("%m/%d/%Y")
    start_date = start_date.strftime("%m/%d/%Y")

    return f"[{start_date}]-[{end_date}]"
