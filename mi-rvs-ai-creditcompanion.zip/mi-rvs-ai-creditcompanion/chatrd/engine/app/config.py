ASSISTANT_ROLE = "✨"
USER_ROLE = "🧑‍💻"

MAIN_LLMS = [
    # Claude3
    "claude-3-haiku",
    "claude-3-sonnet",
    "claude-3-7-sonnet-20250219",
    "claude-opus-4",
    "claude-sonnet-4-20250514",
    # Llama3Bedrock
    "llama3-8b",
    "llama3-70b",
]

DATA_SERVICE_LLMS = [
    # Claude3
    "claude-3-haiku"
]
