COMPANY_CLASSIFICATION = """You will receive a USER QUESTION. Your task is to classify the question as either a "company" question or a "non-company" question.

CLASSIFICATION RULES:

DEFAULT CLASSIFICATION: "company" - Unless the question specifically contains securities-related keywords listed below.

A "non-company" question MUST contain one or more of these SECURITIES KEYWORDS:
- Securities
- Bonds
- Senior Unsecured
- Senior secured
- Subordinated
- Commercial paper
- Maturities
- Instruments
- Debentures
- CLO
- CDO
- Issue rating

IMPORTANT NOTES:
1. ONLY classify as "non-company" if the question explicitly mentions one or more of the securities keywords above, including "issue rating" (but not "issuers").
2. If the question contains securities keywords but is primarily asking about companies (e.g., "list telecom companies who have bonds"), classify as "company"
3. Questions about geographic locations, industry sectors, rating actions, upgrades, downgrades, or corporate entities should be classified as "company" unless they specifically focus on the securities keywords above
4. When in doubt, default to "company"

OUTPUT FORMAT:
Respond with exactly one word: either "company" or "non-company"
Do not provide explanations or additional text.

EXAMPLES:
{company_classification_examples}


`USER QUESTION`:
{user_question}
"""

COMPANY_CLASSIFICATION_EXAMPLES = [
    # Company examples - default classification
    ("What are the top 20 automotive companies with positive outlook in Japan?", "company"),
    ("What are the recently downgraded corporates with their industry, credit rating and geography?", "company"),
    (
        "List the BBB rated retail companies with watch neg values for 2024 in the UK, including their credit watch actions in the last 24 months.",
        "company",
    ),
    (
        "List the top-rated consumer goods and hardware entities in the last 12 months in France with their recent credit actions, credit watch changes, and net income values for Q1 and Q2.",
        "company",
    ),
    ("Provide me list of security software companies with their credit ratings and outlooks in the US?", "company"),
    ("What are the countries with BB or higher ratings?", "company"),
    ("Provide me a list of Japanese entities with their credit ratings and outlooks?", "company"),
    ("Give me top rated states in US", "company"),
    ("Can you show me downgrades for 2025", "company"),
    ("Can you provide information about default rating actions that occurred within June?", "company"),
    # Non-company examples - contain securities keywords
    ("list all telecom industry company who has bb issue rating in the uk", "non-company"),
    ("Provide the list of maturities got rating recently", "non-company"),
    ("Generate a table of bonds that banks have issued in Q1 2023", "non-company"),
    ("show me a list of high yield UK bonds on positive watch", "non-company"),
    ("give me a list of asset backed securities covered by S&P", "non-company"),
    ("Provide me investment grade senior unsecured notes", "non-company"),
    ("data center debt securities rated by S&P", "non-company"),
    (
        "i need a list of all debt securities issued for data centers in the US and are rated BBB+ and higher by S&P",
        "non-company",
    ),
    ("Provide a list of CDOs issued by asset managers", "non-company"),
    ("Show me senior unsecured notes issued by US banks", "non-company"),
    ("Provide me a list of maturities expiring before 10/28/2031", "non-company"),
    ("Please provide high yield instruments issued within France in 2023", "non-company"),
    ("Show me recently issued corporate debentures that are rated above B+", "non-company"),
    ("Create a list of commercial paper issuances that are speculative", "non-company"),
    ("What are the securities downgraded in 2024", "non-company"),
    ("What are the top-rated bonds in the US?", "non-company"),
]
