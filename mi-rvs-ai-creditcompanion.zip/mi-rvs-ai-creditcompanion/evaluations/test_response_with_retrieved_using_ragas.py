import argparse
import logging
import time

import pandas as pd
from dotenv import load_dotenv
from tqdm import tqdm

from chatrd.core.document import Document
from chatrd.engine.app.engine_initiator import get_chat_engine
from evaluations.metrics.ragas import RagasMetrics
from evaluations.utils import create_dataset_from_predictions

load_dotenv()

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)
parser = argparse.ArgumentParser()
parser.add_argument(
    "--questions-csv",
    required=True,
    type=str,
    help="give the path of questions list input file as a csv with a column questions",
)
parser.add_argument(
    "--report-file-path",
    required=True,
    type=str,
    help="give the path of output file",
)
parser.add_argument(
    "--analyzer",
    required=True,
    type=str,
    help=" options are claude-instant-v1, gpt-4, chat-gpt",
)
parser.add_argument(
    "--synthesizer",
    required=True,
    type=str,
    help="Type -> options are chat-gpt or haiku",
)


args = parser.parse_args()
q_list = pd.read_csv(args.questions_csv)["question"].to_list()

final_eval_report = []


# model configs
model_name_for_analyzer = args.analyzer
temperature_for_analyzer = 0.0
model_name_for_synthesizer = args.synthesizer
temperature_for_synthesizer = 0.0
version = "default"


def run():
    CHAT.set_callback_fn(None)
    for i in tqdm(range(len(q_list))):
        prompt = q_list[i]
        question_dic = {}
        question_dic["question"] = prompt
        start_time = time.time()
        response = CHAT.chat(
            prompt,
            model_name_for_analyzer,
            temperature_for_analyzer,
            model_name_for_synthesizer,
            temperature_for_synthesizer,
            streaming=False,
        )
        end_time = time.time()
        question_dic["response_time"] = end_time - start_time

        if response and hasattr(response.content_text, "content"):
            resp = response.content_text.content
            question_dic["chatrd_response"] = resp
        else:
            question_dic["chatrd_response"] = response.content_text
        if len(response.source_docs) > 1:
            response.source_docs = [
                doc
                for doc in response.source_docs
                if (isinstance(doc, Document)) and ("**Data Service API** error" not in doc.text)
            ]
        question_dic["chatrd_source_docs"] = str(response.source_docs)
        final_eval_report.append(question_dic)

    batches = [final_eval_report[i : i + 50] for i in range(0, len(final_eval_report), 50)]
    metrics_report = pd.DataFrame()
    for batch in batches:
        dataset = create_dataset_from_predictions(batch, version="only_precision")
        ragas_metrics = RagasMetrics()
        consolidated = ragas_metrics.evaluate_metrics(dataset)
        metrics_report = pd.concat([metrics_report, consolidated], axis=0)

    final_report_df = pd.DataFrame(final_eval_report)
    final_report_df = pd.merge(final_report_df, metrics_report, on=["question"], how="inner")
    final_report_df.to_csv(args.report_file_path)
    logging.info(
        f"""Faithfulness(Avg) : {final_report_df['faithfulness'].mean()},
        Context Precision(Avg):{final_report_df['context_precision'].mean()},
        Context Recall(Avg): {final_report_df['context_recall'].mean()}"""
    )


if __name__ == "__main__":
    CHAT = get_chat_engine()
    run()
    logging.info("Execution Done Successfully")
