import React from 'react';
import { CustomModalListItem } from './CustomModalListItem';
import {
  LoaderOverlay,
  LoaderPosition,
  LoadingIndicator,
  LoaderType,
} from '@spglobal/react-components';
import { CustomModalListType } from './QuestionInput.types';

export const CustomModalList: React.FC<CustomModalListType> = ({
  isLoading,
  listData,
  handleItemClick,
  highlightText,
}) => {
  return (
    <>
      {isLoading ? (
        <LoadingIndicator
          overlay={LoaderOverlay.DEFAULT}
          position={LoaderPosition.STATIC}
          type={LoaderType.CENTER}
        />
      ) : (
        listData &&
        listData.map((el, i) => (
          <CustomModalListItem
            handleSearchItemClick={handleItemClick}
            highlightText={highlightText}
            key={i}
            item={el}
          />
        ))
      )}
    </>
  );
};
