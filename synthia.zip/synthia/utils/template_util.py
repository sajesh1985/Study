import os
import json
from typing import Dict, List
from dotenv import load_dotenv
from pathlib import Path
from functools import lru_cache

load_dotenv(override=True)
# support Linux & Windows paths
DEFAULT_TEMPLATES_DIR = Path(__file__).parent.parent / "resources" / "templates"
TEMPLATES_DIR = Path(os.getenv("TEMPLATES_DIR", str(DEFAULT_TEMPLATES_DIR)))


@lru_cache(maxsize=1)
def load_all_templates() -> Dict[str, dict]:
    templates = {}
    for filename in os.listdir(TEMPLATES_DIR):
        if filename.endswith(".json"):
            path = os.path.join(TEMPLATES_DIR, filename)
            with open(path, "r", encoding="utf-8") as f:
                templates[filename] = json.load(f)
    return templates


def get_sections(template_name: str) -> List[str]:
    templates = load_all_templates()
    template = templates.get(template_name)
    if not template or "sections" not in template:
        return []
    return [
        section.get("section_title", "")
        for section in template["sections"]
        if "section_title" in section
    ]


def get_subsections(template_name: str, section: str) -> List[Dict]:
    templates = load_all_templates()
    template = templates.get(template_name)
    if not template or "sections" not in template:
        return []
    for section_obj in template["sections"]:
        if section_obj.get("section_title") == section:
            subsections = section_obj.get("subsections", [])
            return subsections
    return []


def get_tools_for_subsection(template_name: str, subsection: dict) -> List:
    tools = subsection.get("tools", [])
    return tools

def get_template_prompt(template_name:str) -> str:
    templates = load_all_templates()
    template = templates.get(template_name)
    return template["template_prompt"]



def get_tools_for_subsection_title(template_name: str, sub_section_title: str) -> List[str]:
    """
    Retrieve the list of tools for a given subsection in a template.
    Returns an empty list if not found.
    """
    templates = load_all_templates()
    template = templates.get(template_name)
    if not template or "sections" not in template:
        return []
    for section_obj in template["sections"]:
        for sub_section_obj in section_obj.get("subsections", []):
            if sub_section_obj.get("title", "").strip().lower() == sub_section_title.strip().lower():
                return sub_section_obj.get("tools", [])
    return []


def load_section_options(template):
    """
    Returns a list of all subsection titles for the given template.
    """
    subsection_titles = []
    for section in get_sections(f"{template}.json"):
        subsections = get_subsections(f"{template}.json", section)
        for subsection in subsections:
            title = subsection.get("title")
            if title:
                subsection_titles.append(title)
    return subsection_titles
# for section in get_sections("company_analysis.json"):
#     print(section)
#     print(f"subsections: {get_subsections('company_analysis.json', section)}")
#     print(f" tools: {get_tools_for_section('company_analysis.json', section)}")
