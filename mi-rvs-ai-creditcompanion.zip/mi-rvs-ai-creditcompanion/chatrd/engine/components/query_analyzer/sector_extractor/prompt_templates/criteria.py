CRITERIA_SECTOR_EXAMPLES = """
{
    "question": "Explain business risk for corporates",
    "answer": {
        "sector" : "Corporates"
    }
}
__________________
{
    "question": "What are the main factors that influence the credit ratings of sovereign entities?",
    "answer": {
        "sector" : "Governments"
    }
}
"""

CRITERIA_SECTOR_PROMPTS = """
You are an excellent financial credit analyst and you will be given a question from the user.
Your task will be to extract information regarding user question:
    * Please identify the sector-specific methodology type that can answer the question.
        The sectors can be Governments, Corporates, Structured Finance, Insurance, Infrastructure, Financial Institutions.
        If the sector type isn't clearly indicated by the question, refer to the subsector mapping to identify the appropriate criteria methodology.
        If question is not mentioning about any sector/subsector and asking for general related methodolgy which can be applied to any sector, return 'General' as the type of sector. (key: sector)

<Subsector mapping>
| TYPE_OF_SECTORS       | SUBTYPE_OF_SECTORS                            |
|-----------------------|-----------------------------------------------|
| Structured Finance    | CDOs                                          |
| Structured Finance    | Commercial Mortgage-Backed Securities (CMBS)  |
| Structured Finance    | Asset-Backed Securities (ABS)                 |
| Structured Finance    | Residential Mortgage-Backed Securities (RMBS) |
| Structured Finance    | Legal                                         |
| Structured Finance    | Asset-Backed Commercial Paper (ABCP)          |
| Structured Finance    | Covered Bonds                                 |
| Structured Finance    | Real Estate Companies                         |
| Structured Finance    | Servicer Evaluations                          |
| Structured Finance    | Structured Credit                             |
| Governments           | U.S. Public Finance                           |
| Governments           | Sovereigns                                    |
| Governments           | International Public Finance                  |
| Insurance             | Specialty                                     |
| Insurance             | Health                                        |
| Insurance             | Reinsurance                                   |
| Insurance             | Life                                          |
| Insurance             | Property/Casualty                             |
| Insurance             | Bond                                          |
| Financial Institutions| Fixed-Income Funds                            |
| Financial Institutions| Banks                                         |
| Financial Institutions| Asset Managers                                |
| Financial Institutions| Broker Dealers                                |
| Financial Institutions| Financial Companies                           |
| Corporates            | Utilities                                     |
| Corporates            | Industrials                                   |
| Corporates            | Project Finance                               |
| Infrastructure        | Social                                        |
| Infrastructure        | Energy and Oil & Gas                          |
| Infrastructure        | Power Generation and Transmission             |
| Infrastructure        | Transportation                                |

<Examples pairs of question (key: question) and answer (key: answer) are given below in JSON format: Do not stick completely to the values for answer shown in examples they are only for taking hints>
{examples}

Take a deep breath and understand that these examples should not affect the extractions for any other keys.

Answer JSON object which should contain following properties:
* "sector"

<Question>
{question}

Just return an answer JSON object.
"""
