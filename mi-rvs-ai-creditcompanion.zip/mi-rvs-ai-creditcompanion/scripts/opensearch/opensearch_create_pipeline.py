import json

import boto3
import requests
import yaml
from opensearch_py_ml.ml_commons import MLCommonClient
from opensearchpy import OpenSearch, RequestsHttpConnection
from opensearchpy.client.utils import _make_path
from requests_aws4auth import AWS4Auth

from chatrd.core.aws_utils.bedrock import get_assume_bedrock_credentials
from chatrd.engine.configuration import Constants, get_config_machinery

config_machinery = get_config_machinery()

region = config_machinery.get_config_value(Constants.Bedrock.BEDROCK_REGION_NAME)
host = config_machinery.get_config_value(Constants.OpenSearch.OPENSEARCH_HOST)
port = config_machinery.get_config_value(Constants.OpenSearch.OPENSEARCH_PORT)
user_name = config_machinery.get_config_value(Constants.OpenSearch.OPENSEARCH_USER_NAME)
password = config_machinery.get_config_value(Constants.OpenSearch.OPENSEARCH_PASSWORD)

service = "es"
vector_field = "vector_field"
headers = {"Content-Type": "application/json"}
ingestion_pipeline_id = "cohere-multilingual-ingestion-pipeline"
search_pipeline_id = "cohere-multilingual-search-pipeline"
role_arn = "arn:aws:iam::339712941790:role/mi-crs-chatrd-dev-role"
bedrock_url = "https://bedrock-runtime." + region + ".amazonaws.com/model/cohere.embed-multilingual-v3/invoke"


credentials = get_assume_bedrock_credentials()
awsauth = AWS4Auth(
    credentials["aws_access_key"],
    credentials["aws_secret_key"],
    region,
    service,
    session_token=credentials["aws_session_token"],
)
# credentials = boto3.Session().get_credentials()
# awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, service, session_token=credentials.token)


aos_client = OpenSearch(
    hosts=[{"host": host, "port": 443}],
    http_auth=(user_name, password),
    use_ssl=True,
    verify_certs=True,
    connection_class=RequestsHttpConnection,
)

# Creating Bedrock Model Group
path = "_plugins/_ml/model_groups/_register"
url = "https://" + host + "/" + path

payload = {"name": "Bedrock Embedding Model", "description": "A model group for bedrock embedding models."}

r = requests.post(url, auth=awsauth, json=payload, headers=headers)
print(r.status_code)
if r.status_code == 200:
    data = json.loads(r.text)

    model_group_id = data["model_group_id"]
    print("model group id:" + model_group_id)
else:
    raise Exception("There is error in creating model groups" + str(r.text))


# Creating Bedrock Connector
path = "_plugins/_ml/connectors/_create"
url = "https://" + host + "/" + path

payload = {
    "name": "Amazon Bedrock Connector: cohere multilingual",
    "description": "The connector to bedrock cohere.embed-multilingual-v3 embedding model.",
    "version": 1,
    "protocol": "aws_sigv4",
    "parameters": {
        "region": region,
        "service_name": "bedrock",
        "input_type": "search_document",
    },
    "credential": {
        "roleArn": role_arn,
    },
    "actions": [
        {
            "action_type": "predict",
            "method": "POST",
            "url": bedrock_url,
            "headers": {"content-type": "application/json", "x-amz-content-sha256": "required"},
            "request_body": '{ "texts": ${parameters.texts}, "input_type": "${parameters.input_type}" }',
            "pre_process_function": "connector.pre_process.cohere.embedding",
            "post_process_function": "connector.post_process.cohere.embedding",
        }
    ],
}

r = requests.post(url, auth=awsauth, json=payload, headers=headers)
print(r.status_code)
if r.status_code == 200:
    data = json.loads(r.text)

    bedrock_connector_id = data["connector_id"]
    print("Bedrock connector id:" + bedrock_connector_id)
else:
    raise Exception("There is error in creating connector" + str(r.text))

# Register Model
path = "_plugins/_ml/models/_register"
url = "https://" + host + "/" + path

bedrock_payload = {
    "name": "bedrock-cohere-multilingual-embedding",
    "function_name": "remote",
    "model_group_id": model_group_id,
    "description": "The bedrock's cohere.embed-multilingual-v3 embedding model.",
    "connector_id": bedrock_connector_id,
}

r = requests.post(url, auth=awsauth, json=bedrock_payload, headers=headers)
print(r.status_code)
if r.status_code == 200:
    data = json.loads(r.text)

    model_id = data["model_id"]
    print(model_id)
else:
    raise Exception("There is error in registering model" + str(r.text))

# Deploy Model
ml_client = MLCommonClient(aos_client)

load_model_output = ml_client.deploy_model(model_id)

print(load_model_output)


# Test Embedding Model
path = "_plugins/_ml/models/" + model_id + "/_predict"
url = "https://" + host + "/" + path


bedrock_payload = {"parameters": {"texts": ["this is test"]}}

r = requests.post(url, auth=awsauth, json=bedrock_payload, headers=headers)
print(r.status_code)
if r.status_code == 200:
    data = json.loads(r.text)
    print(data)
else:
    raise Exception("There is error in calling model" + str(r.text))

# Create Ingestion Pipeline
ingestion_pipeline = {
    "description": "An embedding ingestion pipeline for opensearch for cohere multilingual model.",
    "processors": [{"text_embedding": {"model_id": model_id, "field_map": {"text": "vector_field"}}}],
}
aos_client.ingest.put_pipeline(id=ingestion_pipeline_id, body=ingestion_pipeline)

print("ingestion pipeline created")

# Create Search Pipelne
search_pipeline = {
    "description": "Post processor for hybrid search for cohere multilingual model.",
    "phase_results_processors": [
        {
            "normalization-processor": {
                "normalization": {"technique": "min_max"},
                "combination": {"technique": "arithmetic_mean", "parameters": {"weights": [0.3, 0.7]}},
            }
        }
    ],
}

aos_client.transport.perform_request(
    "PUT",
    _make_path("_search", "pipeline", search_pipeline_id),
    body=search_pipeline,
)

print("search pipeline created")

# Load the YAML file
with open("chatrd/configuration/configs/pipeline.yaml", "r") as f:
    config = yaml.load(f, Loader=yaml.FullLoader)

config["model_group_id"] = model_group_id
config["model_id"] = model_id
config["bedrock_connector_id"] = bedrock_connector_id
config["ingestion_pipeline_id"] = ingestion_pipeline_id
config["search_pipeline_id"] = search_pipeline_id

with open("chatrd/configuration/configs/pipeline.yaml", "w") as f:
    yaml.dump(config, f)
