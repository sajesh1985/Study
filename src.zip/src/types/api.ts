import { Feedback } from './interaction';

export enum ContentType {
  Text = 'Text',
  Code = 'Code',
  Table = 'Table',
  CSDTable = 'csd_table',
  KnowledgeDiscovery = 'KnowledgeDiscovery',
}

export interface TextResponseNode {
  type: ContentType.Text;
  content: string;
  count?:string;
  answer?:string;
  documents?: Array<KnowledgeDiscoveryDocuments>;
  suggestedPrompts?: Array<SuggestedPrompts>;
}

export interface TableColumnNode {
  name: string;
  type: 'string' | 'number' | 'boolean' | 'date' | 'datetime';
}

export interface TableResponseNode {
  type: ContentType.Table;
  columns: Array<TableColumnNode>;
  rows: Array<{ [nameKey: string]: string }>;
  count?:string;
  documents?: Array<KnowledgeDiscoveryDocuments>;
  suggestedPrompts?: Array<SuggestedPrompts>;
}

export interface CSDTableResponseNode {
  type: ContentType.CSDTable;
  response: any[];
  csdTable: any[];
  count?:string;
  documents?: Array<KnowledgeDiscoveryDocuments>;
  suggestedPrompts?: Array<SuggestedPrompts>;
}

export interface Snippet {
  text: string;
}
export interface KnowledgeDiscoveryDocuments {
  id: string;
  url:string;
  title: string;
  type:string;
  details:string | null;
  date: string | null;
  snippets: Array<Snippet>;
}

export interface SuggestedPrompts {
  text: string;
}

export interface KnowledgeDiscoveryResponseNode {
  type: ContentType.KnowledgeDiscovery;
  answer: string;
  documents?: Array<KnowledgeDiscoveryDocuments>;
  suggestedPrompts?: Array<SuggestedPrompts>;
}

export interface CodeResponseNode {
  type: ContentType.Code;
  metadata: ContextMetaData;
  content: string;
}

interface ContextMetaData {
  language: string;
  origin: string;
}

interface TextUserInput {
  type: ContentType.Text;
  value: string;
  taggedEntities?: Array<{ type: string; id: string,name:string }>;
}

interface ContextResponseBody {
  type: ContentType.Code;
  metadata: ContextMetaData;
  content: string;
}

export interface TextResponseBody {
  type: ContentType.Text;
  content: string;
}

export interface PayloadDetails {
  interactionId: string;
  payload: string;
}

export interface MIToken {
  access_token: string;
  expires_in: number;
}

export interface InteractionRequestPayload {
  userInput: TextUserInput[];
  sessionId?: string;
  keyonlineuser?: number;
  previousInteractionId?: string;

  supportedNodeTypes?: Array<
    ContentType.Text | ContentType.Table | ContentType.Code | ContentType.KnowledgeDiscovery
  >;
}

export interface ArchiveSessionRequestPayload {
  sessionId?: string;
  archive? : boolean;
}

export interface ArchiveSessionResponse {
  isArchived?: boolean;
}

export interface InteractionRequestResponse {
  sessionId: string;
  interactionId: string;
  responseBody:
    | Array<TextResponseNode | TableResponseNode | KnowledgeDiscoveryResponseNode>
    | TextResponseBody[];
  responseContext: CodeResponseNode[] | ContextResponseBody[];
  responseTimestamp:string;
}

export interface ChatHistoryRequestPayload {
  keyonlineuser?: number;
}

export interface ChatSessionHistoryRequestPayload {
  sessionId?:string;
}

export interface ChatHistoryResponse {
  feedback:InteractionFeedbackRequestPayload;
  sessionId: string;
  interactionId: string;
  previousInteractionId:string;
  keyonlineuser?: number;
  userInput: TextUserInput[];
  responseBody:
    | Array<TextResponseNode | TableResponseNode | KnowledgeDiscoveryResponseNode>
    | TextResponseBody[];
  responseContext: CodeResponseNode[] | ContextResponseBody[];
  responseTimestamp:string;
  requestTimeStamp:string;
  lastUpdatedDate?:string;
}

export interface SessionFeedbackRequestPayload {
  session: string;
  feedback_sentiment: Feedback['sentiment'];
  text_feedback?: Feedback['text'];
  tags?: Feedback['tags'];
}

export interface InteractionFeedbackRequestPayload {
  sessionId:string;
  interactionId: string;
  feedback_sentiment: Feedback['sentiment'];
  text_feedback?: Feedback['text'];
  tags?: Feedback['tags'];
}

export interface GridExport{
  rowData:Array<string>;
}
