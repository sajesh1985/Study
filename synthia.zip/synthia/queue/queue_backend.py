# backends.py
import os
import json
import logging
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Iterable

from src.synthia.queue.queue_manager import get_queue_manager, QueueMessage  # your existing in-memory manager

logger = logging.getLogger(__name__)

@dataclass
class InboundMessage:
    """Unified message shape for consumers across backends."""
    id: str                         # in-memory: message.id; SQS: MessageId
    payload: Dict[str, Any]         # parsed JSON payload with "action", "payload"
    raw: Any                        # backend-specific raw (e.g., SQS full dict or QueueMessage)
    attributes: Dict[str, Any]      # backend attributes if any
    retry_count: int                # in-memory: QueueMessage.retry_count; SQS: ApproximateReceiveCount as int
    receipt_handle: Optional[str] = None  # SQS only


class BaseQueueBackend:
    """Interface used by both publisher and consumer."""
    async def send_message(self, payload: Dict[str, Any]) -> str:
        raise NotImplementedError

    async def receive_batch(self, max_messages: int = 10, wait_time_seconds: int = 20) -> List[InboundMessage]:
        raise NotImplementedError

    async def ack(self, message: InboundMessage) -> None:
        raise NotImplementedError

    async def nack(self, message: InboundMessage, error: Optional[str] = None, retry_in_seconds: Optional[int] = None) -> None:
        """Requeue (or let redrive happen)."""
        raise NotImplementedError

    async def extend_visibility(self, message: InboundMessage, extend_by_seconds: int) -> None:
        """Optional. No-op for in-memory."""
        return


# ---------- In-memory backend (wraps your existing InMemoryQueue) ----------
class InMemoryQueueBackend(BaseQueueBackend):
    def __init__(self, queue_name: str = "report_tasks"):
        self.queue_name = queue_name
        self.manager = get_queue_manager()

    async def send_message(self, payload: Dict[str, Any]) -> str:
        return await self.manager.send_message(self.queue_name, payload)

    async def receive_batch(self, max_messages: int = 10, wait_time_seconds: int = 20) -> List[InboundMessage]:
        # Simple polling: pull up to max_messages (non-blocking).
        out: List[InboundMessage] = []
        for _ in range(max_messages):
            msg: Optional[QueueMessage] = await self.manager.receive_message(self.queue_name)
            if not msg:
                break
            out.append(
                InboundMessage(
                    id=msg.id,
                    payload=msg.payload,
                    raw=msg,
                    attributes={},
                    retry_count=msg.retry_count,
                    receipt_handle=None,
                )
            )
        return out

    async def ack(self, message: InboundMessage) -> None:
        await self.manager.delete_message(message.id)

    async def nack(self, message: InboundMessage, error: Optional[str] = None, retry_in_seconds: Optional[int] = None) -> None:
        # In-memory queue has built-in retry counter & failure handling
        await self.manager.return_message_to_queue(message.id, error)

    # extend_visibility is a no-op for in-memory


# ---------- SQS backend ----------
class SQSQueueBackend(BaseQueueBackend):
    def __init__(self, queue_url: str, region: Optional[str] = None):
        import aioboto3
        self.aioboto3 = aioboto3
        self.queue_url = queue_url
        self.region = region or os.getenv("AWS_REGION", "us-east-1")

    def _session_client(self):
        session = self.aioboto3.Session(region_name=self.region)
        return session.client("sqs")

    async def send_message(self, payload: Dict[str, Any]) -> str:
        async with self._session_client() as client:
            resp = await client.send_message(
                QueueUrl=self.queue_url,
                MessageBody=json.dumps(payload),
            )
            return resp["MessageId"]

    async def receive_batch(self, max_messages: int = 10, wait_time_seconds: int = 20) -> List[InboundMessage]:
        async with self._session_client() as client:
            resp = await client.receive_message(
                QueueUrl=self.queue_url,
                MaxNumberOfMessages=min(max_messages, 10),
                WaitTimeSeconds=min(wait_time_seconds, 20),
                VisibilityTimeout=int(os.getenv("VISIBILITY_TIMEOUT", "60")),
                AttributeNames=["All"],
                MessageAttributeNames=["All"],
            )
            msgs = resp.get("Messages", [])
            out: List[InboundMessage] = []
            for m in msgs:
                body_raw = m.get("Body", "{}")
                try:
                    payload = json.loads(body_raw)
                except Exception:
                    payload = {"raw": body_raw}

                attrs = m.get("Attributes", {})
                retry_count = int(attrs.get("ApproximateReceiveCount", "1"))
                out.append(
                    InboundMessage(
                        id=m["MessageId"],
                        payload=payload,
                        raw=m,
                        attributes=attrs,
                        retry_count=retry_count,
                        receipt_handle=m["ReceiptHandle"],
                    )
                )
            return out

    async def ack(self, message: InboundMessage) -> None:
        if not message.receipt_handle:
            return
        async with self._session_client() as client:
            await client.delete_message(
                QueueUrl=self.queue_url,
                ReceiptHandle=message.receipt_handle,
            )

    async def nack(self, message: InboundMessage, error: Optional[str] = None, retry_in_seconds: Optional[int] = None) -> None:
        # With SQS, "nack" = shorten visibility timeout to trigger quicker retry.
        if not message.receipt_handle or not retry_in_seconds:
            # Do nothing → visibility will expire naturally
            return
        async with self._session_client() as client:
            await client.change_message_visibility(
                QueueUrl=self.queue_url,
                ReceiptHandle=message.receipt_handle,
                VisibilityTimeout=int(retry_in_seconds),
            )

    async def extend_visibility(self, message: InboundMessage, extend_by_seconds: int) -> None:
        if not message.receipt_handle:
            return
        async with self._session_client() as client:
            await client.change_message_visibility(
                QueueUrl=self.queue_url,
                ReceiptHandle=message.receipt_handle,
                VisibilityTimeout=int(extend_by_seconds),
            )

from src.synthia.config.api_config import get_config
cfg = get_config()
queue_url = cfg["QUEUE_URL"]

# ---------- Factory ----------
def get_queue_backend() -> BaseQueueBackend:
    backend = os.getenv("QUEUE_BACKEND", "local").lower()
    if backend == "sqs":
        if not queue_url:
            raise RuntimeError("QUEUE_URL must be set when QUEUE_BACKEND=sqs")
        return SQSQueueBackend(queue_url=queue_url, region=os.getenv("AWS_REGION", "us-east-1"))
    # default local
    return InMemoryQueueBackend(queue_name=os.getenv("QUEUE_NAME", "report_tasks"))
