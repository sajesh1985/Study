import json
import logging
import random
import re
from pathlib import Path

# Set a different random seed for test data generation
random.seed(84)

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

NUM_RUNS = 8


def extract_keys(template):
    """Extract placeholders from the template."""
    keys = re.findall(r"{(.*?)}", template)
    return keys


def get_dictionary_from_folders(directory_path: str):
    """Load JSON files from a directory into a dictionary."""
    json_dict = {}
    directory = Path(directory_path)
    for file_path in directory.iterdir():
        if file_path.is_file() and file_path.suffix == ".json":
            with file_path.open("r") as file:
                json_content = json.load(file)
            key = file_path.stem  # Filename without extension
            json_dict[key] = json_content
    return json_dict


# Load mappings and templates
test_mappings = get_dictionary_from_folders("scripts/uc_embedding_generation/template_values")
logger.info(f"Template Values Mapping: {test_mappings}")

test_template_values = get_dictionary_from_folders("scripts/uc_embedding_generation/templates")
logger.info(f"Template Mapping: {test_template_values}")


def generate_questions(mappings, template_values, num_runs=1, existing_questions=None):
    """Generate questions based on templates and mappings, ensuring no overlap with existing questions."""
    questions = {}
    for key, templates in template_values.items():
        # Adjust n_times based on your requirements
        n_times = {
            "definition": 15,
            "criteria": 6,
            "peers": 6,
            "query": 7,
            "outlook": 10,
            "sNw": 8,
            "ratings": 8,
            "research": 5,
            "general": 10,
            "deals_tranche": 5,
            "credit_memo": 5,
            "esg": 5,
        }.get(key, 1)
        for template in templates:
            unique_questions = set()
            N = num_runs * n_times
            for _ in range(N):
                present_keys = extract_keys(template)
                all_pairs = {}
                try:
                    for mp_key in present_keys:
                        all_pairs[mp_key] = random.choice(mappings[mp_key])
                    question = template.format(**all_pairs)
                    # Check for overlap with existing questions
                    if existing_questions and question in existing_questions.get(key, []):
                        continue
                    unique_questions.add(question)
                except KeyError as e:
                    logger.error(f"Missing mapping for key: {e}")
                    continue
            if key in questions:
                questions[key].extend(list(unique_questions))
            else:
                questions[key] = list(unique_questions)
    return questions


# Load existing training questions from a JSON file
train_questions_path = Path("scripts/uc_embedding_generation/questions.json")
with train_questions_path.open("r") as json_file:
    train_questions = json.load(json_file)
logger.info(f"Loaded {sum(len(v) for v in train_questions.values())} training questions.")

# Generate test questions, ensuring no overlap with training questions
test_questions = generate_questions(
    test_mappings, test_template_values, num_runs=NUM_RUNS, existing_questions=train_questions
)

# Save test questions
output_directory = Path("evaluations/data/uc_router")
output_directory.mkdir(parents=True, exist_ok=True)  # Ensure the directory exists
test_questions_path = output_directory / "test_questions.json"
with test_questions_path.open("w") as json_file:
    json.dump(test_questions, json_file)
logger.info(f"Generated {sum(len(v) for v in test_questions.values())} test questions.")
