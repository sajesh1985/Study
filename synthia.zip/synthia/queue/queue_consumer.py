import os
import sys
import asyncio
import logging
import signal
from functools import lru_cache
from src.synthia.persistence.database_manager import initialize_connection_pool, close_connection_pool

from typing import Dict, Any

from src.synthia.queue.queue_backend import get_queue_backend, InboundMessage, BaseQueueBackend
from src.synthia.queue.queue_handler import ACTION_HANDLERS

logger = logging.getLogger(__name__)

MAX_CONCURRENCY      = int(os.getenv("MAX_CONCURRENCY", "10"))
BATCH_SIZE           = int(os.getenv("BATCH_SIZE", "10"))
WAIT_TIME_SECONDS    = int(os.getenv("WAIT_TIME_SECONDS", "20"))
HEARTBEAT_EVERY_SEC  = int(os.getenv("HEARTBEAT_EVERY_SEC", "30"))
HEARTBEAT_EXTEND_BY  = int(os.getenv("HEARTBEAT_EXTEND_BY", "60"))
MAX_RETRIES_PER_MSG  = int(os.getenv("MAX_RETRIES_PER_MSG", "3"))

class ReportQueueConsumer:
    def __init__(self):
        self.backend: BaseQueueBackend = get_queue_backend()
        self._stop = asyncio.Event()
        self._sem = asyncio.Semaphore(MAX_CONCURRENCY)
        self._pending: set[asyncio.Task] = set()

    async def _heartbeat(self, msg: InboundMessage):
        """Extend visibility for in-flight work (no-op on in-memory)."""
        try:
            while not self._stop.is_set():
                await asyncio.sleep(HEARTBEAT_EVERY_SEC)
                await self.backend.extend_visibility(msg, HEARTBEAT_EXTEND_BY)
                logger.debug("Extended visibility id=%s by %ss", msg.id, HEARTBEAT_EXTEND_BY)
        except asyncio.CancelledError:
            try:
                await self.backend.extend_visibility(msg, 10)
            except Exception:
                pass
            raise

    async def _handle_one(self, msg: InboundMessage):
        async with self._sem:
            env = msg.payload or {}
            action = env.get("action") or env.get("type")
            inner = env.get("payload", env)

            handler = ACTION_HANDLERS.get(action)
            if not handler:
                logger.error("Unknown action '%s' id=%s; acking to drop.", action, msg.id)
                await self.backend.ack(msg)
                return

            hb = asyncio.create_task(self._heartbeat(msg))
            try:
                await handler(inner)
            except Exception as e:
                hb.cancel()
                await asyncio.gather(hb, return_exceptions=True)

                if msg.retry_count >= MAX_RETRIES_PER_MSG:
                    logger.exception("Permanent failure after %s tries id=%s; leaving for redrive. err=%s",
                                     msg.retry_count, msg.id, e)
                    await self.backend.nack(msg, error=str(e), retry_in_seconds=None)
                    return

                backoff = min(2 ** max(1, msg.retry_count), 60)
                logger.warning("Error try=%s id=%s; requeue in %ss; err=%s", msg.retry_count, msg.id, backoff, e)
                await self.backend.nack(msg, error=str(e), retry_in_seconds=backoff)
                return

            hb.cancel()
            await asyncio.gather(hb, return_exceptions=True)
            await self.backend.ack(msg)

    async def run_forever(self):
        logger.info("Consumer starting (backend=%s)…", os.getenv("QUEUE_BACKEND", "local"))
        try:
            while not self._stop.is_set():
                batch = await self.backend.receive_batch(max_messages=BATCH_SIZE, wait_time_seconds=WAIT_TIME_SECONDS)
                if not batch:
                    await asyncio.sleep(0.01)
                    continue
                for m in batch:
                    if self._stop.is_set():
                        break
                    t = asyncio.create_task(self._handle_one(m))
                    self._pending.add(t)
                    t.add_done_callback(self._pending.discard)
        finally:
            logger.info("Draining %s in-flight tasks…", len(self._pending))
            await asyncio.gather(*self._pending, return_exceptions=True)
            logger.info("Consumer stopped.")

    async def stop(self):
        self._stop.set()

@lru_cache(maxsize=1)
def get_consumer() -> ReportQueueConsumer:
    return ReportQueueConsumer()


# async def _main():
#     logger.info("Initializing connection pool...")
#     await initialize_connection_pool()
#     logger.info("Connection pool initialized successfully")
#     consumer = ReportQueueConsumer()
#     loop = asyncio.get_running_loop()
#
#     def _sig():
#         logger.warning("Shutdown signal received. Draining…")
#         asyncio.create_task(consumer.stop())
#         logger.info("Closing connection pool...")
#         asyncio.create_task(close_connection_pool())
#         logger.info("Connection pool closed successfully")
#
#     for sig in (signal.SIGINT, signal.SIGTERM):
#         try:
#             loop.add_signal_handler(sig, _sig)
#         except NotImplementedError:
#             pass  # Windows
#
#     await consumer.run_forever()
#
# if __name__ == "__main__":
#     if sys.platform == "win32":
#         asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
#     asyncio.run(_main())
