import styled from '@emotion/styled';
import { DARK } from '@spglobal/koi-helpers';

export const ArchivalConfirmContainer = styled.div`
    background-color: #f0f0f0;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0,0,0,0.1);
    width: 493px;
    height: 100px;
    margin: 0 auto;
    display: table;
    position: absolute;
    left: 70px;
    right: 0;
    top: 20%;
    border: 1px solid var(--border-color);
    -webkit-transform: translateY(-50%);
    -moz-transform: translateY(-50%);
    -ms-transform: translateY(-50%);
    -o-transform: translateY(-50%);
    transform: translateY(-50%);
    h1 {
      font-size: 24px;
      margin-bottom: 20px;
    }
    
    p {
      font-size: 16px;
      margin-bottom: 20px;
    }
    
    label {
      font-size: 16px;
    }
    
    .${DARK} & {
      background-color: #272727;
      border-right:#3b3b3b;
    }

`;

export const ArchivalConfirmButton = styled.button`
      margin-top: 10px;
      padding: 10px 20px;
      font-size: 16px;
      cursor: pointer;
      float: right;
      margin-right: 5px;
      background-color: #3D6DAC;
      border-radius: var(--size-radius-1);
      font-family: var(--font-family-base);
      font-size: var(--size-font-3);
      color: white;
      border:1px solid var(--color-base-gray-30);
      .${DARK} & {
        background-color: #3D6DAC;
      }

`;

export const ArchivalCancelButton = styled.button`
      margin-top: 10px;
      padding: 10px 20px;
      font-size: 16px;
      cursor: pointer;
      float: right;
      border-radius: var(--size-radius-1);
      font-family: var(--font-family-base);
      font-size: var(--size-font-3);
      border:1px solid var(--color-base-gray-30);
      .${DARK} & {
        background-color: var(--color-dark-gray-75);
        color: white;
      }

`;





