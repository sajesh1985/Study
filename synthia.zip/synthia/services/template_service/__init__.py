from src.synthia.services.template_service.dto import CompanyTemplate
from src.synthia.services.template_service.service import Template, TemplateService

CompanyTemplate = CompanyTemplate
Template = Template
TemplateService = TemplateService