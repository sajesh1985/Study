from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List, Optional


class OutputType(Enum):
    CHART = "chart"
    DATAFRAME = "dataframe"
    STRING = "string"
    DATAFRAME_AND_STRING = "dataframe_and_string"


class AgentCapability(Enum):
    CHART_BUILDER = "CHART_BUILDER"
    MANIPULATION = "MANIPULATION"
    ANSWER_GENERATION = "ANSWER_GENERATION"


@dataclass
class OutputConfig:
    output_type: OutputType
    format_options: Optional[Dict[str, Any]] = None


@dataclass
class CapabilityDefinition:
    name: str
    id: str
    description: str
    guidelines: str
    examples: List[Dict[str, str]]
    required_imports: List[str]
    best_practices: List[str]
    common_patterns: List[str]
    output_types: List[OutputType]
    trigger_indicators: List[str]


CAPABILITY_DEFINITIONS = {
    AgentCapability.CHART_BUILDER: CapabilityDefinition(
        name="Chart Builder",
        id="CHART_BUILDER",
        description="Create interactive visualizations using Plotly with professional styling and comprehensive chart types",
        guidelines="""
- Use Plotly for all visualizations (plotly.express and plotly.graph_objects)
- Apply consistent color schemes and professional styling
- Include proper titles, axis labels, and legends
- Ensure charts are interactive and responsive
- Handle missing data appropriately in visualizations
- Use appropriate chart types for different data patterns
        """,
        examples=[],
        required_imports=["import plotly.express as px", "import plotly.graph_objects as go", "import pandas as pd"],
        best_practices=[
            "Always include meaningful titles and axis labels",
            "Use consistent color palettes across related charts",
            "Ensure charts are readable on different screen sizes",
            "Add hover information for better interactivity",
            "Handle edge cases like empty datasets gracefully",
            "Values in the same unit should be stacked on one plot using different colors, while those in different units should not be stacked.",
            "Always pick data from latest year from given dataframe if user query does not mention about any time information",
        ],
        common_patterns=[
            "px.line()",
            "px.bar()",
            "px.scatter()",
            "px.histogram()",
            "go.Figure()",
            "fig.update_layout()",
            "fig.add_trace()",
        ],
        output_types=[OutputType.CHART],
        trigger_indicators=[
            "User wants to CREATE, SHOW, DISPLAY, or VISUALIZE data",
            "Request mentions: chart, graph, plot, visualization, trend, pattern",
            "User asks to 'create a chart', 'plot this', 'visualize'",
            "If user ask for SHOW, then they should explicitly mention about showing the chart",
            "Specific chart types mentioned: line, bar, scatter, pie, histogram",
            "Visual comparison or trend analysis requested",
        ],
    ),
    AgentCapability.MANIPULATION: CapabilityDefinition(
        name="Data Manipulation",
        id="MANIPULATION",
        description="Perform comprehensive data cleaning, filtering, transformation, and analysis using pandas with robust error handling",
        guidelines="""<instructions>- Use pandas for all data manipulation operations.
- Pay attention to cover all user query requirements regarding entities and use cases, but only if valid data is available. Do not fabricate data or give any explanations if data is not provided in input.
- Handle missing values, duplicates, and data type issues and implement proper error handling and validation. Example: do not attempt to get argmax of an empty sequence before checking if the sequence is empty.
- Ensure data quality and consistency throughout operations.
- Document data transformations with clear variable names.
- Utilize formatted Python strings for textual outputs and insert values using variables.
- Use proper markdown formatting for textual outputs with bullet points, and keep it concise and simple.
</instructions>
        """,
        examples=[],
        required_imports=["import pandas as pd", "import numpy as np"],
        best_practices=[
            "Always work on copies of original data",
            "Validate data types and ranges after transformations",
            "Use vectorized operations for better performance",
            "Handle edge cases and missing data explicitly",
            "Document complex transformations with comments",
            "Include specific numbers and percentages",
            "Use business-appropriate language and terminology for textual outputs",
        ],
        common_patterns=[
            "df.fillna()",
            "df.groupby()",
            "pd.to_datetime()",
            "df.drop_duplicates()",
            "df.apply()",
            "f-strings for formatting",
            "markdown formatting",
            "bullet points",
        ],
        output_types=[OutputType.DATAFRAME_AND_STRING],
        trigger_indicators=[
            "User wants to SHOW, DISPLAY, ANALYZE, PROCESS, CLEAN, FILTER, RETRIEVE or TRANSFORM data",
            "Request mentions: show, display, filter, calculate, compute, sum, average, analyze, explain, interpret, understand, insights",
            "Data operations: sort, rank, reshape, filter",
            "User asks to 'find', 'get', 'calculate', 'filter', 'group by', 'show me', 'what are'",
            "Mathematical operations or statistical calculations needed",
            "Data cleaning or preparation tasks mentioned",
            "User asks for single/complex data retrieval which requires data processing into table or textual output report",
        ],
    ),
    AgentCapability.ANSWER_GENERATION: CapabilityDefinition(
        name="Answer Generation",
        id="ANSWER_GENERATION",
        description="Generate comprehensive analytical insights and formatted reports with statistical analysis",
        guidelines="""
- Provide clear, structured analysis with specific insights.
- Include relevant statistics and data points.
- Use proper formatting and bullet points where applicable, and keep it concise and simple.
- Present findings in business-friendly language.
- Utilize formatted Python strings for the output and insert values using variables.
        """,
        examples=[],
        required_imports=["import pandas as pd", "import numpy as np"],
        best_practices=[
            "Structure reports with clear titles and sections",
            "Include specific numbers and percentages",
            "Provide context for all findings",
            "Offer actionable recommendations",
            "Use business-appropriate language and terminology",
        ],
        common_patterns=[
            "f-strings for formatting",
            "statistical calculations",
            "trend analysis",
            "comparative analysis",
            "markdown formatting",
        ],
        output_types=[OutputType.STRING],
        trigger_indicators=[
            "User wants INSIGHTS, ANALYSIS, or EXPLANATIONS",
            "Request mentions: analyze, explain, interpret, understand, insights",
            "Questions starting with: what, why, how, tell me, describe, analyze",
            "User asks for recommendations, conclusions, or implications",
            "Comparative analysis: compare, contrast, difference, better/worse",
            "Seeking understanding rather than just data processing",
            "General Analysis/Explanation of the user query",
            "User asks for simple/single data retrieval which does not require any chart creation or data/table manipulation",
        ],
    ),
}


# MERGE_INSTRUCTIONS = """
# You can merge multiple tables on their table keys to put two tables together to produce a more concise output, when:
# - the contents of the tables are related to each other, for example financial ratings and rating actions
# - those tables have common table keys
# - table keys have the same values

# For example:

# Table Merging Example 1
# -------------
# Table 1: Financial Ratings
# **Sample Data**:
# | A   | B   | C   |
# |:----|:----|:----|
# | a1  | b1  | c1  |
# | a2  | b2  | c2  |

# **Table Key Values**:
# | A   | B   |
# |:----|:----|
# | a1  | b1  |
# | a2  | b2  |

# Table 2: Rating Actions
# **Sample Data**:
# | A   | B   | D   |
# |:----|:----|:----|
# | a1  | b1  | d1  |
# | a2  | b2  | d2  |

# **Table Key Values**:
# | A   | B   |
# |:----|:----|
# | a1  | b1  |
# | a2  | b2  |

# These tables can be merged, because table contents are related (ratings and rating actions), they have the same table keys and their values match.

# Table Merging Example 2
# -------------
# Table 1: Financial Ratings
# **Sample Data**:
# | A   | B   | C   |
# |:----|:----|:----|
# | a1  | b1  | c1  |
# | a2  | b2  | c2  |

# **Table Key Values**:
# | A   | B   |
# |:----|:----|
# | a1  | b1  |
# | a2  | b2  |

# Table 2: Rating Actions
# **Sample Data**:
# | A   | B   | D   |
# |:----|:----|:----|
# | a1  | b1  | d1  |
# | a2  | b2  | d2  |

# **Table Key Values**:
# | A   | B   |
# |:----|:----|
# | a1  | b1  |
# | a2  | b3  |

# These tables cannot be merged. The table keys are the same, but their values do not match. The value for table key B in Table 2 is b3, while in Table 1 it is b2.

# To merge tables, apply python function
# ```python
# pd.merge(table1, table2, on=table_key, how='inner')
# ```

# where `table1` and `table2` are the pandas DataFrames you want to merge, and `table_key` is the column name of the table key. Do not merge table by all columns, only by the table key. If there are multiple table keys, merge by all of them.

# Additionally, if you decide to merge tables you must follow these rules:
# - Do not rename any of the columns, unless specifically told to do so
# - Do not select a subset of columns
# """.strip()
