import logging
from typing import Dict, Union

from botocore.client import BaseClient
from pydantic import BaseModel

from chatrd.core.vectorstore import OpenSearch
from chatrd.engine.components.query_analyzer.entity_extractor.utils import (
    Companies,
    Entities,
    RevenueSource,
)
from chatrd.engine.components.query_processor.query_retriever.reranker import (
    get_reranked_documents,
)
from chatrd.engine.components.query_processor.query_retriever.uc_retrievers.base import (
    UCRetriever,
)
from chatrd.engine.components.query_processor.query_retriever.uc_retrievers.utils import (
    UCRetrieverType,
)
from chatrd.engine.components.query_processor.query_retriever.utils import (
    add_unstructured_source,
    get_filters_for_research,
    get_sorted_docs_by_date,
    post_process_retrieved_docs,
)
from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.responses import get_default_answer

logger = logging.getLogger(__name__)

config_machinery = get_config_machinery()


class CommonResearchRetriever(UCRetriever):
    def __init__(self, vector_stores_dict: Dict[str, OpenSearch], reranker_client: BaseClient):
        self.vector_stores_dict = vector_stores_dict
        self.top_k_text_research = config_machinery.get_config_value(Constants.GeneralConstants.TOP_K_TEXT_RESEARCH)
        self.top_k_text_research_rerank = config_machinery.get_config_value(
            Constants.GeneralConstants.TOP_K_TEXT_RESEARCH_RERANK
        )
        self.top_k_research_double_rerank = config_machinery.get_config_value(
            Constants.GeneralConstants.TOP_K_TEXT_RESEARCH_DOUBLE_RERANK
        )
        self.top_k_research_recency_bias_final = config_machinery.get_config_value(
            Constants.GeneralConstants.TOP_K_TEXT_RESEARCH_RECENCY_BIAS_FINAL
        )
        self.reranker_client = reranker_client
        self.reranker_endpoint_name = config_machinery.get_config_value(
            Constants.SageMaker.SAGEMAKER_RERANKER_ENDPOINT_NAME
        )

    def retrieve(
        self,
        query: str,
        entities: Entities,
        uc_type: str,
        model_name_for_data_service: str,
        temperature_for_data_service: float,
        sectors: BaseModel,
        original_language: str,
        original_query: str,
        recency_bias: bool = False,
        multi_uc_type: bool = False,
    ):
        vector_db_retrieved_documents = []
        all_entities = entities.companies + entities.revenue_sources

        if not all_entities and uc_type == UCRetrieverType.SWOT.value:
            retrieved_documents = self.vector_db_retrieval(
                query=query,
                entity=None,
                uc_type=uc_type,
                original_language=original_language,
                recency_bias=True,
                index_name="commentary",
            )
            vector_db_retrieved_documents.extend(retrieved_documents)
        elif all_entities and uc_type == UCRetrieverType.SWOT.value:
            for entity in all_entities:
                retrieved_documents = self.vector_db_retrieval(
                    query=query,
                    entity=entity,
                    uc_type=uc_type,
                    original_language=original_language,
                    recency_bias=True,
                    index_name="research",
                )
                vector_db_retrieved_documents.extend(retrieved_documents)
        else:
            for entity in all_entities:
                retrieved_documents = self.vector_db_retrieval(
                    query=query,
                    entity=entity,
                    uc_type=uc_type,
                    original_language=original_language,
                    recency_bias=recency_bias,
                    index_name="research",
                )
                vector_db_retrieved_documents.extend(retrieved_documents)

        logger.info(f"Total number of retrieved documents : {len(vector_db_retrieved_documents)}")
        vector_db_retrieved_documents = add_unstructured_source(vector_db_retrieved_documents)
        return vector_db_retrieved_documents

    def vector_db_retrieval(
        self,
        query: str,
        entity: Union[Companies, RevenueSource],
        uc_type: str,
        original_language: str,
        recency_bias: bool,
        index_name: str,
    ):
        query = self.rephrased_query(query, entity)
        if entity:
            filters, relevant_article_ids = get_filters_for_research(
                vector_stores_dict=self.vector_stores_dict, entity=entity, uc_type=uc_type
            )
            if not relevant_article_ids:
                return get_default_answer(
                    entity=entity, reason="no_relevant_articles", original_language=original_language, query=query
                )
        else:
            filters = None

        logger.info(f"filter applied for research docs : {filters}")
        retrieved_documents, scores = self.vector_stores_dict[index_name].get_relevant_documents(
            query,
            efficient_filter=filters,
            model_id=config_machinery.get_config_value(Constants.OpenSearch.NEURAL_SEARCH_MODEL_ID),
            search_pipeline=config_machinery.get_config_value(Constants.OpenSearch.HYBRID_SEARCH_SEARCH_PIPELINE_ID),
            top_k_text_chunks=self.top_k_text_research,
        )
        if not recency_bias:
            reranker_threshold, top_k = None, self.top_k_text_research_rerank
            if uc_type in [UCRetrieverType.RESEARCH.value, UCRetrieverType.FINANCIALS.value]:
                self.top_k_text_research_rerank = self.top_k_text_research_rerank * 2
            else:
                if not isinstance(entity, RevenueSource):
                    reranker_threshold = config_machinery.get_config_value(
                        Constants.GeneralConstants.DEFAULT_RERANKER_THRESHOLD
                    )
        else:
            reranker_threshold, self.top_k_text_research_rerank = None, self.top_k_research_double_rerank

        retrieved_documents = get_reranked_documents(
            query=query,
            retrieved_documents=retrieved_documents,
            entity=entity,
            reranker_client=self.reranker_client,
            reranker_endpoint_name=self.reranker_endpoint_name,
            reranker_threshold=reranker_threshold,
            top_k_text_chunks=self.top_k_text_research_rerank,
        )
        retrieved_documents = post_process_retrieved_docs(retrieved_documents)
        retrieved_documents = self.add_additional_metadata_to_documents(
            uc_type=uc_type, user_query=query, entity=entity, documents=retrieved_documents
        )
        if not retrieved_documents:
            return get_default_answer(entity=entity, reason="no_relevant_articles", query=query)
        if recency_bias:
            retrieved_documents = get_sorted_docs_by_date(retrieved_documents, self.top_k_research_recency_bias_final)

        return retrieved_documents
