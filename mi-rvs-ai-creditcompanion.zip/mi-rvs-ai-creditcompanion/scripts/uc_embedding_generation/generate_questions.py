"""
This file will generate questions from templates/template_values
"""

import json
import logging
import os
import random
import re

random.seed(42)

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

logger = logging.getLogger(__name__)

NUM_RUNS = 30


def extract_keys(template):
    keys = re.findall(r"{(.*?)}", template)
    return keys


def get_dictionary_from_folders(directory_path: str):
    json_dict = {}

    for filename in os.listdir(directory_path):
        if filename.endswith(".json"):
            file_path = os.path.join(directory_path, filename)

            with open(file_path, "r") as file:
                json_content = json.load(file)

            key = os.path.splitext(filename)[0]

            json_dict[key] = json_content

    return json_dict


mappings = get_dictionary_from_folders("scripts/uc_embedding_generation/template_values")
logger.info(f"Template Values Mapping : {mappings}")

template_values = get_dictionary_from_folders("scripts/uc_embedding_generation/templates")
logger.info(f"Template Mapping : {template_values}")


def generate_questions(mappings, template_values, num_runs=1):
    questions = {}
    for key, values in template_values.items():
        templates = values
        if key == "definition":
            n_times = 15
        if key == "financials":
            n_times = 3
        elif key == "criteria":
            n_times = 6
        elif key == "peers":
            n_times = 6
        elif key == "query":
            n_times = 7
        elif key == "outlook":
            n_times = 10
        elif key == "sNw":
            n_times = 8
        elif key == "ratings":
            n_times = 5
        elif key == "research":
            n_times = 5
        elif key == "general":
            n_times = 10
        elif key == "macro":
            n_times = 5
        elif key == "deals_tranche":
            n_times = 5
        elif key == "credit_memo":
            n_times = 5
        else:
            n_times = 1
        for template in templates:
            unique_questions = set()
            N = num_runs * n_times
            for _ in range(N):
                present_keys = extract_keys(template)
                all_pairs = {}
                for mp_key in present_keys:
                    all_pairs[mp_key] = random.choice(
                        mappings[mp_key],
                    )
                question = template.format(**all_pairs)
                unique_questions.add(question)
            if key in questions:
                questions[key].extend(list(unique_questions))
            else:
                questions[key] = list(unique_questions)
    return questions


questions = generate_questions(mappings, template_values, num_runs=NUM_RUNS)
with open("scripts/uc_embedding_generation/questions.json", "w") as json_file:
    json.dump(questions, json_file, indent=4)
