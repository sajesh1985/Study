from enum import Enum
from typing import Optional

from pydantic import BaseModel


class UCType(Enum):
    CRITERIA = "criteria"
    RESEARCH = "research"
    ESG = "esg"
    RATINGS = "ratings"
    OUTLOOK = "outlook"
    PEERS = "peers"
    DEFINITION = "definition"
    FINANCIALS = "financials"
    SWOT = "sNw"
    SECURITIES = "securities"
    QUERY = "query"
    CREDIT_MEMO = "credit_memo"
    GENERAL = "general"
    MACRO = "macro"
    DEALS_TRANCHE = "deals_tranche"
    RATING_ACTION = "rating_action"
    SELECTED_ARTICLE = "selected_article"
    FLEX_ARCH = "flex_arch"


class EntityType(Enum):
    COMPANY = "Company"
    REVENUE_SOURCE = "Revenue Source"
    USPF = "USPF"
    SECURITY = "Security"
    SOVEREIGN = "Sovereign"
    STRUCTURED_FINANCE = "Structured Finance"


class TaggedEntity(BaseModel):
    type: str
    id: str
    name: str
    country_code: Optional[str] = None
    start: Optional[int] = None
    end: Optional[int] = None
