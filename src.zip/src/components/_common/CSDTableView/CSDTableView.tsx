import React from 'react';
import { AgGridStyle, ExportWrapperStyle } from './CSDTableView.styles';
import { ExcelStyle, GetContextMenuItemsParams, ITooltipParams, LicenseManager } from 'ag-grid-enterprise';
import { config } from '@spglobal/spa';
import { Button, NotificationType, useNotification } from '@spglobal/react-components';
import { Purpose, Size } from '@spglobal/koi-helpers';
import { useChatRD } from '../../../context/chatrd';
import { getlocalizedCurrencyAsString } from '../../../utils/urlUtilities';
import { useUserTraits } from '@spglobal/userprofileservice';
import { getLocalizedDate } from '../../../utils/dateLocalization';
import moment from 'moment';
//import { IconCellRenderer } from '../IconCellRenderer/IconCellRenderer';
const AG_GRID_LICENSE_KEY = config('agGridLicenseKey');
LicenseManager.setLicenseKey(AG_GRID_LICENSE_KEY);


interface CSDTableViewProps extends React.ComponentPropsWithoutRef<'div'> {
  rows: any[];
  interactionId:string;
  totalcount?:string;
  magnitude?:string;
}

export const CSDTableView: React.FC<CSDTableViewProps> = ({ rows,interactionId,magnitude}:CSDTableViewProps) => {
  const [gridApi, setGridApi] = React.useState(null);
     
  const culture  = useUserTraits(['culture']);
  let { setGridContext } = useChatRD();
  const onGridReady = (params: any) => {
    setGridApi(params.api);
    if(params.api.context)
    {
        setGridContext(params.api,interactionId);
    }
    
  };

  function headerHeightGetter() {
    var columnHeaderTexts = [
        ...document.querySelectorAll('.ag-header-cell-text'),
    ];
    var clientHeights = columnHeaderTexts.map(
        headerText => headerText.clientHeight
    );
    var tallestHeaderTextHeight = Math.max(...clientHeights);

    return tallestHeaderTextHeight;
  }

  const excelStyles: ExcelStyle[] = [
    {
      id: "redFont",
      font: {
        color: "#FF0000",
      }
    }];
  

  function getCustomColumnDef(data:any){
    const keys = Object.keys(data[1]);
      let colDefs:any = [];
       keys.forEach((key:any,index:any) => {
            if(data[0][key] !== '' && index !== 0 && index<5)
            {
              colDefs.push({ 
                field: key, 
                headerName: data[0][key].indexOf('_$M') > -1 ? (magnitude == '$M'? "CURRENCY: " + data[0][key].substring(0,data[0][key].indexOf('_')) + "* TEMPLATE: ADJUSTED": "CURRENCY: " +  data[0][key].substring(0,data[0][key].indexOf('_')) +"*"):data[0][key],
                minWidth:index == 1 ? 300:150,
                sortable:false,
                tooltipValueGetter: index == 1? function(p: ITooltipParams) {
                  return p.data.definition ? (p.data.definition.productDefinition):null;
                }:null,
                cellRenderer: index == 1? function(params:any) {
                  //return params.value;
                  
                  if(magnitude)
                  {
                    params.value = params.value.replace('$M',magnitude);
                  }
                  return !params.data.definition ? "<b>" + params.value + "</b>" : params.value;
                }:function(params:any) { if(!isNaN(params.value)){
                  return getlocalizedCurrencyAsString(params.value,culture)
                }
                else if(!isNaN(new Date(params.value).getTime())){
                  {return getLocalizedDate(
                    params.value,
                    true,
                    culture.culture,
                    culture.mSTimeZoneID,
                    true
                      )}
                }
                else{return params.value}},
                cellStyle: index == 1 ? function(params:any) {
                  if (params.data.definition) {
                      //mark police cells as red
                      return {color: 'var(--color-text-link)'};
                  }
                  return null;
                }:function(params:any) { if(params && params.value && (params.value.indexOf('(')> -1 || params.value.indexOf('-')> -1)){
                  return {color: 'red'};
                }else return null;},
                cellClassRules:{
                  redFont: (params:any) => {
                    return index !==1 && (params && params.value && (params.value.indexOf('(')> -1 || params.value.indexOf('-')> -1) && !isDate(params.value));
                },
              },
              });
          }
      });
      return colDefs;
    
  }

  function isDate(value:any) {
    const formats = ['MM/DD/YYYY','DD/MM/YYYY','YYYY/DD/MM','YYYY/MM/DD','YYYY-MM-DD','MM.DD.YYYY','DD-M-YYYY','DD.M.YYYY','DD.MM.YYYY','YYYY.MM.DD','YYYY.DD.MM','DD-MM-YYYY','MM-DD-YYYY','M-D-YYYY','M.D.YYYY','D-M-YYYY','D.M.YYYY','YYYY-M-D','YYYY.M.D','YYYY-D-M','YYYY.D.M','YYYY/MM/DD','YYYY/DD/MM','YYYY-MM-DD','YYYY.MM.DD','YYYY.DD.MM','YYYY-DD-MM','YYYY-M-D','YYYY.D-M','YYYY-M-DD','YYYY-DD-M','YYYY-MM-D','YYYY-DD-M','YYYY-MMM-DD','YYYY-MMM-D','YYYY-MMM-D'];
    let isvalid = moment(value,formats,true).isValid();
    return isvalid;
  }

  const headerHeightSetter = (params: any) => {
    var padding = 20;
    var height = headerHeightGetter() + padding;
    params.api.setHeaderHeight(height);
  };

  var headerComponentParams = {
    template:
      '<div class="ag-cell-label-container" role="presentation">' +
      '  <span ref="eMenu" class="ag-header-icon ag-header-cell-menu-button"></span>' +
      '  <div ref="eLabel" class="ag-header-cell-label" role="presentation">' +
      '    <span ref="eSortOrder" class="ag-header-icon ag-sort-order"></span>' +
      '    <span ref="eSortAsc" class="ag-header-icon ag-sort-ascending-icon"></span>' +
      '    <span ref="eSortDesc" class="ag-header-icon ag-sort-descending-icon"></span>' +
      '    <span ref="eSortNone" class="ag-header-icon ag-sort-none-icon"></span>' +
      '    <span ref="eText" class="ag-header-cell-text" role="columnheader" style="white-space: normal;"></span>' +
      '    <span ref="eFilter" class="ag-header-icon ag-filter-icon"></span>' +
      '  </div>' +
      '</div>',
  };

  const { addNotification } = useNotification() || {};

  
  const exlExport = async () => {
    addNotification("Export started: may take more than 2 mins", NotificationType.INFO);
    gridApi.exportDataAsExcel({processCellCallback: (params:any) => processCells(params)});
  };

  function processCells(params: any) {
    if(params && params.value === '&nbsp;')
    {
      params.value = '';
    }
    else
    {
      if(!(isNaN(params.value) || params.value == ' ')){ 
        return getlocalizedCurrencyAsString(params.value,culture);
      }
      else if(!isNaN(new Date(params.value).getTime())){
        {return getLocalizedDate(
          params.value,
          true,
          culture.culture,
          culture.mSTimeZoneID,
          true
            )}
      }
      else{
        if(magnitude && params.value != null && params.value.toString().includes('$M'))
        {
            params.value = params.value.replace('$M',magnitude);
        }
        return params.value
      }
    }
    return params.value;
  }

  return (
    <div>
      <ExportWrapperStyle>
        <Button size={Size.MEDIUM} purpose={Purpose.SECONDARY} onClick={() => exlExport()}>
          Excel Export
        </Button>
      </ExportWrapperStyle>
      <AgGridStyle
        enableRangeSelection={true}
        suppressContextMenu={false}
        isAutoHeight={true}
        tooltipShowDelay={500}
        onColumnResized={() => {
          document.body.classList.remove('chatRDCustom');
          setTimeout(() => document.body.classList.add('chatRDCustom'), 2000);
        }}
        defaultCsvExportParams={{
          fileName: 'TableCsvExport',
        }}
        defaultExcelExportParams={{
          fileName: 'TableExlExport',
          processCellCallback: params => {
            if(params.value != null && params.value.toString().includes('<a '))
            {
                return params.value.toString().split('>')[1].split('<')[0];
            }
            else
            {
               return params.value;
            }
          }
        }}
        getContextMenuItems={(params: GetContextMenuItemsParams) => {
          return [
            'copy',
            'copyWithHeaders',
            'separator',
            {
              name: 'Excel Export',
              action: () => params.api.exportDataAsExcel(),
            },
          ];
        }}
        defaultColDef={{
          sortable: false,
          wrapText: true,
          autoHeight: false,
          resizable: true,
          filter: true,
          suppressMenu:true,
          headerComponentParams: headerComponentParams,
        }}
        //frameworkComponents={{iconCellRenderer:IconCellRenderer}}
        columnDefs={getCustomColumnDef(rows)}
        onGridReady={onGridReady}
        excelStyles={excelStyles}
        onFirstDataRendered = {headerHeightSetter}
        isMobileAutoSize
        rowData={rows.slice(1)}
      />
    </div>
  );
};


