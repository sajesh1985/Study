from enum import Enum


class EsgGridDataDimension(Enum):
    TOTAL_SUSTAINABILITY_SCORE = "Total Sustainability Score"
    ENVIRONMENTAL = "Environmental"
    SOCIAL = "Social"
    GOVERNANCE_AND_ECONOMIC = "Governance & Economic"


class EsgChartDataScoreType(Enum):
    ESG_SCORE = "ESG Score"
    ENVIRONMENTAL_SCORE = "Environmental Score"
    SOCIAL_SCORE = "Social Score"
    GOVERNANCE_AND_ECONOMIC_SCORE = "Governance & Economic Score"
