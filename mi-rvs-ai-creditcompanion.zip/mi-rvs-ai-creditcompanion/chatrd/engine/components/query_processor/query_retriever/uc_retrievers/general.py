import logging
from datetime import datetime
from typing import Dict, List, Union

from botocore.client import BaseClient
from pydantic import BaseModel

from chatrd.core.document.schema import Document
from chatrd.core.llm import LCLLMFactory
from chatrd.core.llm.components.message import AIMessage
from chatrd.core.llm.parsers import OutputParserException, PydanticOutputParser
from chatrd.core.llm.prompt.template import SimplePromptTemplate
from chatrd.core.utils import dict_coalesce
from chatrd.core.vectorstore import OpenSearch
from chatrd.engine.components.query_analyzer.entity_extractor.utils import (
    Companies,
    Entities,
    RevenueSource,
)
from chatrd.engine.components.query_analyzer.filter_retrievers.prompts import (
    TimeOutputDates,
)
from chatrd.engine.components.query_processor.query_retriever.reranker import (
    get_reranked_documents,
)
from chatrd.engine.components.query_processor.query_retriever.uc_retrievers.base import (
    UCRetriever,
)
from chatrd.engine.components.query_processor.query_retriever.uc_retrievers.prompt_templates import (
    GENERAL_EXAMPLES,
    GENERAL_PROMPTS,
)
from chatrd.engine.components.query_processor.query_retriever.uc_retrievers.utils import (
    GeneralRetrieverModel,
    ProcessedRetrieverDates,
)
from chatrd.engine.components.query_processor.query_retriever.utils import (
    add_unstructured_source,
    get_custom_logic_filters_for_date_range,
    get_filters_for_research,
    get_sorted_docs_by_date,
    post_process_analyzer_output_dates,
)
from chatrd.engine.configuration import Constants, get_config_machinery

config_machinery = get_config_machinery()
logger = logging.getLogger(__name__)


class GeneralRetriever(UCRetriever):
    def __init__(self, vector_stores_dict: Dict[str, OpenSearch], reranker_client: BaseClient):
        self.vector_stores_dict = vector_stores_dict
        self.top_k_text_research = config_machinery.get_config_value(Constants.GeneralConstants.TOP_K_TEXT_RESEARCH)
        self.top_k_table_research = int(
            config_machinery.get_config_value(Constants.GeneralConstants.TOP_K_TABLE_RESEARCH)
        )
        self.top_k_text_research_rerank_general = config_machinery.get_config_value(
            Constants.GeneralConstants.TOP_K_TEXT_RESEARCH_RERANK_GENERAL
        )
        self.top_k_text_research_double_rerank = config_machinery.get_config_value(
            Constants.GeneralConstants.TOP_K_TEXT_RESEARCH_DOUBLE_RERANK
        )
        self.top_k_text_research_recency_bias_final = config_machinery.get_config_value(
            Constants.GeneralConstants.TOP_K_TEXT_RESEARCH_RECENCY_BIAS_FINAL
        )
        self.reranker_client = reranker_client
        self.reranker_endpoint_name = config_machinery.get_config_value(
            Constants.SageMaker.SAGEMAKER_RERANKER_ENDPOINT_NAME
        )

    def retrieve(
        self,
        query: str,
        entities: Entities,
        model_name_for_data_service: str,
        temperature_for_data_service: float,
        uc_type: str,
        sectors: BaseModel,
        extracted_timeframe: TimeOutputDates,
        tagged_routes: str = None,
        multi_uc_type: bool = False,
        macro_micro_routing: bool = False,
        is_geo_or_region: bool = False,
    ):
        router_result = (
            GeneralRetrieverModel(question=query, is_micro=True, is_macro=True)
            if macro_micro_routing
            else self.run_router(
                query, model_name_for_data_service, temperature_for_data_service, tagged_routes=tagged_routes
            )
        )
        sorted_commentary_retrieved_documents = None
        # enable table retrieval only for macro queries
        if router_result.is_macro is False:
            self.top_k_table_research = 0
        processed_dates = post_process_analyzer_output_dates(extracted_timeframe)
        all_documents = []
        all_entities = []
        if tagged_routes is None or tagged_routes == "":
            all_entities = entities.companies + entities.revenue_sources
        num_entities = len(all_entities)
        if (router_result.is_macro and router_result.is_micro) or macro_micro_routing:
            if all_entities:
                for entity in all_entities:
                    retrieved_documents = self.vector_db_retrieval(
                        query=query,
                        entity=entity,
                        uc_type=uc_type,
                        index_name="research",
                        processed_dates=processed_dates,
                    )
                    all_documents.extend(retrieved_documents)

            else:
                retrieved_documents = self.vector_db_retrieval(
                    query=query,
                    entity=None,
                    uc_type=uc_type,
                    index_name="research",
                    processed_dates=processed_dates,
                )
                all_documents.extend(retrieved_documents)
            retrieved_documents = self.vector_db_retrieval(
                query=query,
                entity=None,
                uc_type=uc_type,
                index_name="commentary",
                processed_dates=processed_dates,
            )
            all_documents.extend(retrieved_documents)
        elif router_result.is_macro:
            if all_entities:
                for entity in all_entities:
                    retrieved_documents = self.vector_db_retrieval(
                        query=query,
                        entity=entity,
                        uc_type=uc_type,
                        index_name="research",
                        processed_dates=processed_dates,
                    )
                    all_documents.extend(retrieved_documents)
            retrieved_documents = self.vector_db_retrieval(
                query=query,
                entity=None,
                uc_type=uc_type,
                index_name="commentary",
                processed_dates=processed_dates,
            )
            all_documents.extend(retrieved_documents)
        elif router_result.is_micro:
            if all_entities:
                for entity in all_entities:
                    retrieved_documents = self.vector_db_retrieval(
                        query=query,
                        entity=entity,
                        uc_type=uc_type,
                        index_name="research",
                        processed_dates=processed_dates,
                    )
                    all_documents.extend(retrieved_documents)
            else:
                retrieved_documents = self.vector_db_retrieval(
                    query=query,
                    entity=None,
                    uc_type=uc_type,
                    index_name="research",
                    processed_dates=processed_dates,
                )
                all_documents.extend(retrieved_documents)
            if is_geo_or_region:
                commentary_retrieved_documents, scores = self.vector_stores_dict["commentary"].get_relevant_documents(
                    query,
                    efficient_filter=None,
                    model_id=config_machinery.get_config_value(Constants.OpenSearch.NEURAL_SEARCH_MODEL_ID),
                    search_pipeline=config_machinery.get_config_value(
                        Constants.OpenSearch.HYBRID_SEARCH_SEARCH_PIPELINE_ID
                    ),
                    top_k_text_chunks=self.top_k_text_research,
                )

                ranked_commentary_retrieved_documents = get_reranked_documents(
                    query=query,
                    retrieved_documents=commentary_retrieved_documents,
                    entity=None,
                    reranker_client=self.reranker_client,
                    reranker_endpoint_name=self.reranker_endpoint_name,
                    reranker_threshold=None,
                    top_k_text_chunks=self.top_k_text_research_double_rerank,
                )

                sorted_commentary_retrieved_documents = get_sorted_docs_by_date(
                    ranked_commentary_retrieved_documents, self.top_k_text_research_recency_bias_final
                )

        if processed_dates.start_date and processed_dates.end_date:
            retrieved_documents = get_reranked_documents(
                query=query,
                retrieved_documents=all_documents,
                entity=None,
                reranker_client=self.reranker_client,
                reranker_endpoint_name=self.reranker_endpoint_name,
                reranker_threshold=None,
                top_k_text_chunks=self.top_k_text_research_rerank_general,
            )
            retrieved_documents = get_sorted_docs_by_date(retrieved_documents, self.top_k_text_research_rerank_general)
        else:
            retrieved_documents = self.double_reranker(
                retrieved_documents=all_documents, query=query, entity=None, num_entities=num_entities
            )

        (
            retrieved_documents.extend(sorted_commentary_retrieved_documents)
            if sorted_commentary_retrieved_documents is not None
            else None
        )

        logger.info(f"General retriever total number of documents: {len(retrieved_documents)}")

        retrieved_documents = add_unstructured_source(retrieved_documents)
        return retrieved_documents

    def vector_db_retrieval(
        self,
        query: str,
        entity: Union[Companies, RevenueSource],
        uc_type: str,
        index_name: str,
        processed_dates: ProcessedRetrieverDates,
    ):
        query = self.rephrased_query(query, entity)
        if entity:
            filters, relevant_article_ids = get_filters_for_research(
                vector_stores_dict=self.vector_stores_dict,
                entity=entity,
                processed_dates=processed_dates,
                uc_type=uc_type,
            )
            if not relevant_article_ids:
                filters = get_custom_logic_filters_for_date_range(processed_dates=processed_dates)
        else:
            filters = get_custom_logic_filters_for_date_range(processed_dates=processed_dates)

        logger.info(
            f"VectorDB - using index {index_name}, top_k_text_research : {self.top_k_text_research}, top_k_table_research: {self.top_k_table_research} and filter {filters}"
        )
        retrieved_documents, scores = self.vector_stores_dict[index_name].get_relevant_documents(
            query=query,
            top_k_text_chunks=self.top_k_text_research,
            top_k_table_chunks=self.top_k_table_research if index_name == "commentary" else 0,
            model_id=config_machinery.get_config_value(Constants.OpenSearch.NEURAL_SEARCH_MODEL_ID),
            search_pipeline=config_machinery.get_config_value(Constants.OpenSearch.HYBRID_SEARCH_SEARCH_PIPELINE_ID),
            efficient_filter=filters,
        )

        for doc in retrieved_documents:
            if doc.metadata.get("chunk_title") is None:
                doc.metadata["chunk_title"] = ""

        if processed_dates.start_date and processed_dates.end_date:
            retrieved_documents = get_reranked_documents(
                query=query,
                retrieved_documents=retrieved_documents,
                entity=entity,
                reranker_client=self.reranker_client,
                reranker_endpoint_name=self.reranker_endpoint_name,
                reranker_threshold=None,
                top_k_text_chunks=self.top_k_text_research_rerank_general,
            )
        else:
            retrieved_documents = self.double_reranker(
                retrieved_documents=retrieved_documents, query=query, entity=entity
            )

        retrieved_documents = self.add_additional_metadata_to_documents(
            uc_type=uc_type, user_query=query, entity=entity, documents=retrieved_documents
        )
        return retrieved_documents

    def run_router(self, query: str, model_name: str, temperature: float, tagged_routes: List[str] = []):
        parser = PydanticOutputParser(pydantic_object=GeneralRetrieverModel)
        if not tagged_routes:
            prompt_template = SimplePromptTemplate(GENERAL_PROMPTS)
            prompt = prompt_template.format(
                **{
                    "question": query,
                    "examples": GENERAL_EXAMPLES,
                }
            )
            llm = LCLLMFactory().get_llm(
                deployment_name_or_model_id=model_name,
                temperature=temperature,
            )
            logger.debug(f"General router prompt : {prompt}")
            response = llm.invoke(prompt)

            if isinstance(response, AIMessage):
                response = response.content
        else:
            if tagged_routes[0].lower() == "allresearch":
                response = f"""
                    \"question\":\"{query}\",
                    \"is_micro\":true,
                    \"is_macro\":true
                
                """
            elif tagged_routes[0].lower() == "macroresearch":
                response = f"""
                    \"question\":\"{query}\",
                    \"is_micro\":false,
                    \"is_macro\":true
                """
            elif tagged_routes[0].lower() == "entityresearch":
                response = f"""
                    \"question\":\"{query}\",
                    \"is_micro\":true,
                    \"is_macro\":false
                """
            else:
                raise Exception(f"there is no such tagged routes called {tagged_routes}")
            response = "{" + response + "}"

        try:
            parsed_query = parser.parse(response)
            logger.info(f"Parsed Query for General router : {parsed_query}")
            return parsed_query
        except OutputParserException as e:
            logger.error(f"Validation error at from General router llm extraction {e}.")
            raise e

    def double_reranker(
        self,
        retrieved_documents: List[Document],
        query: str,
        entity: Union[Companies, RevenueSource],
        num_entities: int = 0,
    ):
        retrieved_documents = get_reranked_documents(
            query=query,
            retrieved_documents=retrieved_documents,
            entity=entity,
            reranker_client=self.reranker_client,
            reranker_endpoint_name=self.reranker_endpoint_name,
            reranker_threshold=None,
            top_k_text_chunks=(
                self.top_k_text_research_double_rerank * num_entities
                if num_entities > 0
                else self.top_k_text_research_double_rerank
            ),
        )
        table_docs = [
            doc for doc in retrieved_documents if dict_coalesce(doc.metadata, ["chunk_type"], default="") == "table"
        ]
        non_table_docs = [
            doc for doc in retrieved_documents if dict_coalesce(doc.metadata, ["chunk_type"], default="") != "table"
        ]
        sorted_text_docs = get_sorted_docs_by_date(
            non_table_docs,
            (
                self.top_k_text_research_recency_bias_final * num_entities
                if num_entities > 0
                else self.top_k_text_research_recency_bias_final
            ),
        )
        sorted_all_docs = get_sorted_docs_by_date(sorted_text_docs + table_docs, len(sorted_text_docs + table_docs))
        logger.info(
            f"Double reranker - Number of chunks after double reranker: {len(sorted_all_docs)} => table chunks: {len(table_docs)} --- text chunks: {len(sorted_text_docs)}"
        )
        return sorted_all_docs
