from typing import List, Optional, Union

from pydantic import BaseModel, field_validator


class RephrasingOutput(BaseModel):
    initial_question: Optional[str] = None
    rephrased_initial_question: str
    subqueries: Union[dict[str, str], List[str]]

    @field_validator("rephrased_initial_question")
    def validate_rephased_initial_question(cls, v):
        if not isinstance(v, str):
            raise ValueError("Rephased initial question must be a string.")
        return v

    @field_validator("subqueries")
    def validate_subqueries(cls, v):
        if not isinstance(v, dict):
            raise ValueError("Subqueries must be a dict.")
        concatenated_keys = {}

        for key, value in v.items():
            if value in concatenated_keys:
                concatenated_keys[value].append(key)
            else:
                concatenated_keys[value] = [key]

        output_list = [" ".join(keys) for keys in concatenated_keys.values()]
        return output_list

    @field_validator("initial_question")
    def validate_initial_question(cls, v):
        if not isinstance(v, str) and v is not None:
            raise ValueError("Initial question must be a string.")
        return v

    def set_initial_question(self, question: str):
        if not isinstance(question, str):
            raise ValueError("Initial question must be a string.")
        self.initial_question = question


REPHRASING_OUTPUT_PROMPT_FORMAT = """Provide a JSON object with the following structure:
{
    "rephrased_initial_question": str(<A minimally rephrased follow-up-question>)
    "subqueries": dict{<A minimally rephrased questions that captures the intention of the user>: <defined use case of subquery>}
}
"""

REPHRASING_EXAMPLES = """<example>
{
    "chat_history": [
        {
            "question": "What is the trend for oil prices this year?"
        }
    ],
    "follow_up_question": "What is the impact on xyz?",
    "output": {
        "rephrased_initial_question": "What is the trend for oil prices this year?",
        "subqueries": {"What is the impact of this year's oil price trend on xyz?": "general"}]
    }
}
</example>
<example>
{
    "chat_history": [
        {
            "question": "What is the financial performance of xyz?"
        },
        {
            "question": "Can you provide the debt-to-equity ratio for it?"
        }
    ],
    "follow_up_question": "Give me the same for uvw?",
    "output": {
        "rephrased_initial_question": "Give me the same for uvw?",
        "subqueries": {"Can you provide the debt-to-equity ratio for uvw?": “financials”}
    }
}
</example>
<example>
{
    "chat_history": [
        {
            "question": "for xyz?"
        },
        {
            "question": "Give me the rating for it."
        },
        {
            "question": "Also, give me the upgrade scenario for it."
        }
    ],
    "follow_up_question": "Give me the same thing but for uvw?",
    "output": {
        "rephrased_initial_question": "Give me the same thing but for uvw?",
        "subqueries": {"What is the upgrade scenario for uvw?": “rating_action”}
    }
}
</example>
<example>
{
    "chat_history": [
        {
            "question": "Outlook for <entity1>?"
        },
        {
            "question": "Give me the SWOT for it."
        }
    ],
    "follow_up_question": "Same for <entity2>?",
    "output": {
        "rephrased_initial_question": "Same for <entity2>?",
        "subqueries": {"What is SWOT for <entity2>?": “SWOT”}
    }
}
</example>
<example>
{
    "chat_history": [
        {
            "question": "What are the factors for xyz?"
        },
        {
            "question": "Summary/updates about abc?"
        }
    ],
    "follow_up_question": "How is the wildfire risk impacting credit ratings?",
    "output": {
        "rephrased_initial_question": "How is the wildfire risk impacting credit ratings?",
        "subqueries": {"How is the wildfire risk impacting credit ratings?": “ratings”}
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "What is the latest research for xyz?",
    "output": {
        "rephrased_initial_question": "What is the latest research for xyz?",
        "subqueries": {"What is the latest research for xyz?": “research”},
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "Compare xyz to abc?",
    "output": {
        "rephrased_initial_question": "Can you provide a comparison of xyz and abc?",
        "subqueries": {"Can you provide a comparison of xyz and abc?": “general”},
    }
}
</example>
<example>
{
    "chat_history": [
        {
            "question": "What is the Rating of abc?"
        },
        {
            "question": "What is the outlook of uvw?"
        },
    ],
    "follow_up_question": "Provide a list of key players in the metals and mining industry from xyz",
    "output": {
        "rephrased_initial_question": "Provide a list of key players in the metals and mining industry from xyz.",
        "subqueries": {"Provide a list of key players in the metals and mining industry from xyz": “query”}
    }
}
</example>
<example>
{
    "chat_history": [
        {
            "question": "what is the outlook for charter schools industry?"
        }
    ],
    "follow_up_question": "“can you give me the states medians report?",
    "output": {
        "rephrased_initial_question": "Can you give me the states medians report?",
        "subqueries": {"Can you give me the states medians report?": “general”}
    }
}
</example>
<example>
{
    "chat_history": [
        {
            "question": "Summary/updates about xyz?"
        },
        {
            "question": "What is the SWOT analysis for abc?"
        }
    ],
    "follow_up_question": "Compare the downgrade of uvw to klm",
    "output": {
        "rephrased_initial_question": "Compare the downgrade of uvw to klm.",
        "subqueries": {"Compare the downgrade of uvw to klm.": “rating_action”}
    }
}
</example>
<example>
{
    "chat_history": [
        {
            "question": "What is the outlook for the company?"
        },
        {
            "question": "and for xyz?"
        }
    ],
    "follow_up_question": "Can you make a peer comparison?",
    "output": {
        "rephrased_initial_question": "Can you provide a peer comparison for xyz?",
        "subqueries": {"Can you provide a peer comparison for xyz?": “peers”}
    }
}
</example>
<example>
{
    "chat_history": [
        {
            "question": "What is the outlook for <entity1>?"
        },
        {
            "question": "Ratings for <entity2>?"
        }
    ],
    "follow_up_question": "Can you make a peer comparison for it?",
    "output": {
        "rephrased_initial_question": "Can you provide a peer comparison for <entity2>?",
        "subqueries": {"Can you provide a peer comparison for <entity2>?": “peers”}
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "Find me cases where airports expanded recently and summarize the credit impact",
    "output": {
        "rephrased_initial_question": "Find me cases where airports expanded recently and summarize the credit impact.",
        "subqueries": {"Find me cases where airports expanded recently and summarize the credit impact.": “general”}
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "Summarize recent research on American airlines",
    "output": {
        "rephrased_initial_question": "Summarize recent research on American airlines.",
        "subqueries": {"Summarize recent research on American airlines.": “research”}
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "Current Rating for SF Company Children's Trust, Puerto Rico",
    "output": {
        "rephrased_initial_question": "Current Rating for SF company Children's Trust, Puerto Rico.",
        "subqueries": {"Current Rating for SF company Children's Trust, Puerto Rico.": “ratings”}
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "give me a real-world applicable example regarding floating rate debt",
    "output": {
        "rephrased_initial_question": "Give me a a real-world applicable example regarding floating rate debt.",
        "subqueries": {"Give me a a real-world applicable example regarding floating rate debt.": “financials”}
    }
}
</example>
<example>
{
    "chat_history": [
        {
            "question": what are trends for the aerospace industry"
        },
        {
            "question": "what is the outlook for the aerospace industry"
        },
        {
            "question": "what is the outlook for the aerospace industry"
        }
    ],
    "follow_up_question": "compare boeing and airbus",
    "output": {
        "rephrased_initial_question": "Compare Boeing and Airbus.",
        "subqueries": {"Compare Boeing and Airbus.": “peers”}
    }
}
</example>
<example>
{
    "chat_history": [
        {
            "question": "GDP growth rate for <country>?"
        }
    ],
    "follow_up_question": "Election results?",
    "output": {
        "rephrased_initial_question": "Could you provide information about election results in <country>?",
        "subqueries": {"Could you provide information about election results in <country>?": “info_coverage”}
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "What are the factors for xyz?",
    "output": {
        "rephrased_initial_question": "What are the factors for xyz?",
        "subqueries": {"What are the factors for xyz?": “rating_action”}
    }
}
</example>
<example>
{
    "chat_history": [
        {
            "question": "Provide a credit report list for <entity>?",
        },
        {
            "question": "Show me a list of articles/latest research for <entity>?"
        }
    ]
    "follow_up_question": "List of research for <entity>?",
    "output": {
        "rephrased_initial_question": "List of research for <entity>?",
        "subqueries": {"List of research for <entity>?": “research”}
    }
}
<example>
{
    "chat_history": [],
    "follow_up_question": "Who is analyst for xyz and abc?",
    "output": {
        "rephrased_initial_question": "Who is the analyst for xyz and abc?",
        "subqueries": {"Who is the analyst for xyz and abc?": “info_coverage”}
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "Can you provide a summary of recent research for xyz?",
    "output": {
        "rephrased_initial_question": "Can you provide a summary of recent research for xyz?",
        "subqueries": {"Can you provide a summary of recent research for xyz?": “research”}
    }
}
</example>
<example>
{
    "chat_history": [
        {
            "question": "Show me Financial modifiers of <entity1>",
        },
        {
            "question": "What is Financial Risk Modifier for <entity2>?"
        }
    ],
    "follow_up_question": "What is Credit Rating score for <entity3>?",
    "output": {
        "rephrased_initial_question": "What the is Credit Rating score for <entity3>?",
        "subqueries": {"What is the Credit Rating score for <entity3>?": “ratings”}
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "what is credit rating of US$<integer> mil <float>% due <date>",
    "output": {
        "rephrased_initial_question": "What is the credit rating of US$<integer> mil <float>% due <date>?",
        "subqueries": {"What is the credit rating of US$<integer> mil <float>% due <date>?": “ratings”}
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "Can you provide interest coverage ratios and EBITDA margin for <entity1>, <entity2>, and <entity3>?",
    "output": {
        "rephrased_initial_question": "Can you provide interest coverage ratios and EBITDA margin for <entity1>, <entity2>, and <entity3>?",
        "subqueries": {"Can you provide interest coverage ratios and EBITDA margin for <entity1>, <entity2>, and <entity3>?": “financials”}
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "What are the cash flow trends and financial highlights for <entity1>, <entity2>, <entity3>, <entity4> and <entity5>?",
    "output": {
        "rephrased_initial_question": "What are the cash flow trends and financial highlights for <entity1>, <entity2>, <entity3>, <entity4> and <entity5>?",
        "subqueries": {"What are the cash flow trends and financial highlights for <entity1>, <entity2>, <entity3>, <entity4> and <entity5>?": “financials”}
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "Ratings for xyz. Can you provide financial highlights for it?",
    "output": {
        "rephrased_initial_question": "Can you provide ratings and financial highlights for xyz?",
        "subqueries": {"Can you provide ratings for xyz?": “ratings”,
        "Can you provide financial highlights for xyz?": “financials”}
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "Can you show the rating action for <entity1>? Ratings for <entity2> and <entity3>",
    "output": {
        "rephrased_initial_question": "Can you show the rating action for <entity1> and ratings for <entity2> and <entity3>?",
        "subqueries": {"Can you show the rating action for <entity1>?": “rating_action”,
        "Can you show ratings for <entity2> and <entity3>": “ratings”}
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "Financial insights for xyz. Ratings. Rating action.",
    "output": {
        "rephrased_initial_question": "Can you provide financial insights, ratings and rating action for xyz?",
        "subqueries": {"Can you provide financial insights for xyz?": “financials”,
        "Can you provide ratings for xyz?": “ratings”,
        "Can you provide rating action for xyz?": “rating_action”}
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "Ratings and upgrade for <entity1>, <entity2> and <entity3>?",
    "output": {
        "rephrased_initial_question": "Can you provide ratings and upgrade for <entity1>, <entity2> and <entity3>?",
        "subqueries": {"Can you provide ratings for <entity1>, <entity2> and <entity3>?": “ratings”,
        "Can you provide upgrade for <entity1>, <entity2> and <entity3>?": “rating_action”]
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "what are the financial highlights and ratings for <entity1>, <entity2>, <entity3>, <entity4> and <entity5>",
    "output": {
        "rephrased_initial_question": "What are the financial highlights and ratings for <entity1>, <entity2>, <entity3>, <entity4> and <entity5>?",
        "subqueries": {"What are the financial highlights for <entity1>, <entity2>, <entity3>, <entity4> and <entity5>?": “financials”,
        "What are the ratings for <entity1>, <entity2>, <entity3>, <entity4> and <entity5>?": “ratings”}
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "Can you provide financial highlights for <entity1>, <entity2>, <entity3>, <entity4>, and <entity5>?",
    "output": {
        "rephrased_initial_question": "Can you provide financial highlights for <entity1>, <entity2>, <entity3>, <entity4>, and <entity5>?",
        "subqueries": {"Can you provide financial highlights for <entity1>, <entity2>, <entity3>, <entity4>, and <entity5>?": financials”}
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "credit ratings for <entity1> compared to <entity2>",
    "output": {
        "rephrased_initial_question": "What are the credit ratings for <entity1> and <entity2>?",
        "subqueries": {"What are the credit ratings for <entity1> and <entity2>?": ratings”}
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "Can you provide the rating action for <entity1> and <entity2>?",
    "output": {
        "rephrased_initial_question": "Can you provide the rating action for <entity1> and <entity2>?",
        "subqueries": {"Can you provide the rating action for <entity1> and <entity2>?": “rating_action”}
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "Action taken for <entity1>, <entity2>, <entity3>? How has their revenue changed for last 3 years?",
    "output": {
        "rephrased_initial_question": "Can you provide the rating action taken for <entity1>, <entity2>, <entity3>? How has their revenue changed for last 3 years?",
        "subqueries": {"Can you provide the rating action taken for <entity1>, <entity2>, <entity3>?": “rating_action”,
        "How has revenue of <entity1>, <entity2>, <entity3> changed for last 3 years?": "financials"}
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "Can you provide the cash flow trends and EBITDA ratio for <entity1>, <entity2>, and <entity3>?",
    "output": {
        "rephrased_initial_question": "Can you provide the cash flow trends and EBITDA ratio for <entity1>, <entity2>, and <entity3>?",
        "subqueries": {"Can you provide the cash flow trends and EBITDA ratio for <entity1>, <entity2>, and <entity3>?": “financials”}
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "Credit rating for: <entity1>, <entity2>, <entity3>",
    "output": {
        "rephrased_initial_question": "Can you share the credit ratings for <entity1>, <entity2>, and <entity3>?",
        "subqueries": {"Can you share the credit ratings for <entity1>, <entity2>, and <entity3>?": “ratings”}
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "Show me a report on the Net income and credit rating for <entity1>, <entity2>, <entity3>",
    "output": {
        "rephrased_initial_question": "Show me a report on the Net income and credit rating for <entity1>, <entity2>, <entity3>",
        "subqueries": {"Show me a report on the Net income for <entity1>, <entity2>, <entity3>": “financials”,
                        "Show me credit rating for <entity1>, <entity2>, <entity3>": “ratings”}
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "List of upgraded companies that were rated in 2023",
    "output": {
        "rephrased_initial_question": "List of upgraded companies that were rated in 2023",
        "subqueries": {"List of upgraded companies that were rated in 2023": “query”}
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "Show me upgraded companies",
    "output": {
        "rephrased_initial_question": "Can you provide a list of companies that have been upgraded?",
        "subqueries": {"Can you provide a list of companies that have been upgraded?": “query”}
    }
}
</example>
</example>
{
    "chat_history": [],
    "follow_up_question": "List of downgraded companies that were rated in 2025",
    "output": {
        "rephrased_initial_question": "List of downgraded companies that were rated in 2025",
        "subqueries": {"List of downgraded companies that were rated in 2025": “query”}
    }
}
</example>
{
    "chat_history": [],
    "follow_up_question": "What are some rating actions for xyz?",
    "output": {
        "rephrased_initial_question": "What are some rating actions for xyz?",
        "subqueries": {"What are some rating actions for xyz?": “rating_action”}
    }
}
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "Summarize the outlook and credit rating details for these companies  xyz abc and  uvw",
    "output": {
        "rephrased_initial_question": "Summarize the outlook and credit rating details for these companies xyz, abc, and uvw.",
        "subqueries": {
            "Summarize the outlook for xyz, abc, and uvw.": “outlook”,
            "Summarize the credit rating details for xyz, abc, and uvw.": “ratings”
        }
    }
</example>
<example>
{
    "chat_history": [],
    "follow_up_question": "give me indian banks with actions",
    "output": {
        "rephrased_initial_question": "Can you provide a list of banks in India with their rating actions?",
        "subqueries": {
            "Can you provide a list of banks in India with their rating actions?": “query”
        }
    }
</example>
"""

USE_CASE_DEFINITIONS = """
1. ratings: Ratings are letter grades given to companies by the S&P Global generally concerning the likelihood of default. We classify things as ratings when the question is asking for the rating of a company. Keywords are Credit Rating, Credit Rating History, Servicer Evaluations Ranking, historical ratings, past ratings assigned, current ratings, S&P Global Ratings, national scale ratings, and other sneakier ways of asking for ratings like asking for "outlook changes" over the years. This category will retrieve the information, if we are asking about the impact of a rating then we would be in the general category.
2. rating_action: Rating actions give information about why ratings change. We classify queries to rating actions when we are asking about rating actions, asking about latest actions, upgrades and downgrades to the outlook or rating of an entity, and rating rationale.
3. peers: Peers category retrieves a table of information regarding the S&P Global's view of an entity and its competitors. Within the financial domain, peers has a specific meaning, we generally classify as peers when we are asking about competitors and the word "peers" or "competitors" is in the user query. Other phrases we look out for are "analyst peers", "list of competitors", "list of peers", "top peers". Asking about something other than the retrieval of this information, for example impact, needs to go to "general".
4. outlook: The outlook category retrieves the S&P Globals opinion about what would need to happen in the future for a rating to upgrade or downgrade. Most of the time questions that ask about outlook need to be in this category.
5. research: The research category will pull a list of articles about the given user query. For example, Show me a research list on entity/topic, list of articles on Apple, reports on IBM, etc.
6. criteria: The criteria category will retrieve information related to guidelines/methedology about assigning ratings for different industries, soverign entities, entities, etc. Additionally, these guidlines outline different risks entities might face such as business risk or financial risk. This can also include impact of being in a specific group key on the methodology. This also covers how various properties of an entity impact rating, like SACP (Stand Alone Credit Profile) on Credit Issuer Ratings.
Keyword heavy: Categories financials, scores and modifiers, definitions, info and coverage, are all retrieiving information about specific keywords the user is requesting. Ensure that the appropriate keyword from this category is included in the user query.
7. scores&modifiers: Very keyword heavy, essentially if the user asks for a score : scores of an entity, but not if the user is asking how a score impacts a company, impact falls into general. Always check if the user is asking about a score
8. financials: Financials pulls financial data. When the user asks for a financial highlights, insights, trends, financial persormance, financial spread, key ratio, profitability, cash flow trends, revenue, EBITDA ratio, interest ratio scores, debts and other financial metrics.
9. definitions: Definitions in this context does not refer to if the user is asking for a definition of any arbirtrary term, but if the user is asking for the meaning of a term that is present in the S&P Global's definition page, these terms are listed as terminology, if the user is asking for the definition of a term not in terminology, classify as general, the definitions retrieval will fail otherwise.
10. ESG: Classification as esg will pull environmental, social, and governance information from the S&P Global database for entities. Essentially any question asking for the ESG profile, ESG factors, or environmental, social, and governance factors for an entity or multiple entities falls under ESG. If the user is specifically asking to compare the ESG factors of two entities it goes into esg not peers. If the user is asking for impact, classify as general.
11. info_coverage: The info coverage category covers the following attributes for a company's metadata, additionally aswell as information about the people (analysts) covering the entity, such as their email, name, address, mobile number, and other personal info.
12. query: The query category covers generating various lists, for example, companies that are fallen angels in the last twelve months list of US public finance securities in industry in the region. Generally speaking, if a more specific category covers the user question such as financials, securities, scores and modifiers prefer that.
13. securities: The securities category covers requesting a list of securities, senior unsecured securities, securities with an associated maturity date, maturity based, debt based, and ratings of the securities of an entity.
14. SWOT: The sNw category retrieves information from the S&P Global database covering what the Strengths, Weaknesses, Opportunities, Threats of an entity. This category covers user queries about strengths and weaknesses. Can be asked in a few ways, SWOT analysis, Strengths, Weaknesses, Opportunities, Threats) analysis, strengths and weaknesses. Also covers comparisons of between two entities.
15. deals_tranche: The deals tranche category retrieves information from the S&P Global database about deals, asset classes, and tranches. User queries that get classified as deals_tranche will generally be asking for details about deals, active deals, tranches, ratings of tranches, overview of historical tranches, ABS or MBS deals, etc.
16. credit_memo: The credit memo category will call an external service that will create a credit memo for an entity. This can be called a few specific things, "credit memo", "credit brief", "credit analysis", "credit research report", and/or credit report.
17. general: The general category acts a catchall for queries that don't need a specific tool. If we misclassify a query, the entire system may fail, therefore when we are uncertain about categories or a question does not fit cleanly into a different more specific category we should return "general"
"""

REPHRASING_PROMPT = """
You are a helpful assistant answering questions in the credit and financial domain.

You have access to the user's <chat_history> and their <follow_up_question> and your goal is to analyze and return the <rephrased_initial_question>, <subqueries> and <use_case> to represent the users intent based on the <chat_history> and <follow_up_question>. 

Your tasks:
1. Provide <rephrased_initial_question>: the rephrased <follow_up_question> based on <chat_history>. Rephrasing includes grammar checking. Important note: while using <chat_history>, pay more attention on last question.
2. Analyze the complexity of the <follow_up_question> split it based on <use_cases_categories> if needed. If <follow_up_question> asks about multiple use cases, it' a complex quesry that should be divided into <subqueries>. Define the use case for each subquery. If a <follow_up_question> asks about one or multiple entities and the single use case, it's a simple query. In this case, you MUST return a single question in <subqueries>. You have to divide question ONLY according to the principle of defining <use_cases_categories>. You should split the question ONLY when it's complex query. Critical: You MUST avoid oversplitting.

<instructions>
Based on the <chat_history> and <follow_up_question>, analyze a standalone question that captures relevant context, and return a rephrased question can be understood without the chat history.

An entity could be a company name, a geografical unit, a bank or a sector.

Use the below guidelines to rephrase the <follow_up_question>:

1. If a question is asked about several entities but falls under the same use case category, it's NOT a complex question. The sign of this case: the entities are listed separated by commas or "and". In this case, you MUST NOT split <follow_up_question>. You MUST return <rephrased_initial_question> as a single <subqueries>. The number of elements in the <subqueries> list MUST be equal to ONE. This single subquery MUST include ALL entities from the <follow_up_question>.
2. If a question is inquiring about multiple use cases, it is a complex query. In this case, split it into individual questions that will be returned in <subqueries>. Split the question ONLY by use case and NOT by the entity. 
3. If the <follow_up_question> refers to a new entity and requests the same information as the previous question, focus on the questions from the <chat_history> to determine the user's intent and infer the desired details based on the context of the questions and apply them to the new entity mentioned in the <follow_up_question>.
4. You MUST NOT add any terms and phrases that are NOT present in the <follow_up_question> or the <chat_history> to the <rephrased_initial_question> nor <subqueries>. For example, you MUST NOT add "latest", "recent", etc. if query asks about 'rating actions'.
5. You MUST NOT replace any acronyms, abbreviation, synonyms or truncation in the <follow_up_question>. They should be returned as is.
6. If the <follow_up_question> is a question that does not require rephrasing, return it as is word for word.
</instructions>

<use_cases_categories>
{use_case_definitions}
</use_cases_categories>

<formatting>
{output_prompt_format}
</formatting>

<examples>
{examples}
</examples>

<chat_history>
{list_of_questions}
</chat_history>

<follow_up_question>
{question}
</follow_up_question>

Return only the valid JSON output without anything else.
Think step by step and return the JSON.
"""
