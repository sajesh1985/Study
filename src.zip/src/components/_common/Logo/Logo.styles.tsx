import styled from '@emotion/styled';
import { DARK } from '@spglobal/koi-helpers';
import { Breakpoints } from '@spglobal/tokens';

export const Container = styled.div<{ small?: boolean; leftAligned?: boolean }>`
  font-style: normal;
  font-weight: 300;
  font-size: ${({ small }) => (small ? 'var(--size-font-9)' : 'var(--size-font-13)')};
  text-align: ${({ leftAligned }) => (leftAligned ? 'left' : 'center')};
  display: table;
  margin: auto;
  margin-left: ${({ leftAligned }) => leftAligned && '0px'};
  letter-spacing: 0;
  cursor: pointer;
  font-family: "Akkurat";
  font-size: 40px;
  line-height: normal;
  letter-spacing: -1.44px;
  padding-top:20px;
  
  .text{
    font-family: 'AKKURAT';
    color: var(--color-base-red-55);
    font-weight: 700;
    font-size: 40px;
  }

  .beta{
    color: #525252;
    font-weight: 400;
    font-size: 30px;
    font-family: 'Akkurat';
  }
  
  .trademark{
    font-weight: 700;
    font-size: 10px;
    font-family: 'Akkurat';
    vertical-align: text-top;
  }
  
  .${DARK} & span .text{
    color: white;
  }

  .${DARK} & .beta{
    color: #AFAFAF;
  }

  @media (max-width: ${Breakpoints.MD}) {
    font-size: ${({ small }) => (small ? 'var(--size-font-9)' : 'var(--size-font-11)')};
  }
`;
