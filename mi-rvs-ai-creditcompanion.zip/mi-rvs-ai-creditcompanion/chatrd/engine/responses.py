from copy import deepcopy
from typing import List, Union

from chatrd.core.document import Document
from chatrd.core.utils import MessageRole
from chatrd.engine.components.query_analyzer.entity_extractor.utils import (
    Companies,
    RevenueSource,
)
from chatrd.engine.components.query_analyzer.suggested_entity_rephrase.suggested_routes import (
    SuggestedContent,
    SuggestedRoute,
    SuggestedRoutesContent,
    SuggestedRoutesResponse,
)
from chatrd.engine.components.query_analyzer.suggested_entity_rephrase.utils import (
    SuggestedEntities,
    SuggestedEntitiesContent,
    SuggestedEntitiesResponse,
    SuggestedEntity,
)
from chatrd.engine.components.query_analyzer.translator.utils import (
    Get_translation_result,
)
from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.utils import ChatResponse

config_machinery = get_config_machinery()


def get_tagged_routes_suggestions(original_language, original_query):
    tagged_routes_classes = [
        "Macro Research",
        "Entity Research",
        "All Research",
        "Criteria",
        "Definitions",
        "Data Query",
    ]
    tagged_routes_queries = [
        "- Focus on macroeconomic and industry-level commentaries",
        "- Focus on entity-level analyses and rating action updates",
        "- Look broadly - search through all research including macro and entity-level insights",
        "- Focus on methodology and criteria documents",
        "- Focus on the definition document that explains key terms and concepts",
        "- Build a list of companies using our database of S&P Ratings data (no research). Filter by Rating, Sector, Geography, or Financials (CSD Financials).<i> <b> Note</b>: Does not yet support US Public Finance or Structured Finance.</i>",
    ]
    tagged_routes_queries = [
        Get_translation_result(h_query, original_language=original_language) for h_query in tagged_routes_queries
    ]
    tagged_routes_queries = [tagged_routes_query.result() for tagged_routes_query in tagged_routes_queries]
    tagged_routes_entities = [
        SuggestedRoute(name=n, definition=q, query=original_query)
        for n, q in zip(tagged_routes_classes, tagged_routes_queries)
    ]
    return tagged_routes_entities


def get_default_response_output(original_language, original_query):
    answer = "CreditCompanion couldn't find the information you were looking for."
    message1 = "<b>We’re here to help</b> - please contact ratings.direct@spglobal.com for assistance or use the thumbs down to leave your feedback."
    message2 = "Troubleshooting Tips:"
    message3 = 'Try rephrasing your question or use "@" to look up a specific entity'
    message4 = "Guide CreditCompanionTM by focusing it on a specific set of research or data:"

    answer = Get_translation_result(answer, original_language)
    message1 = Get_translation_result(message1, original_language)
    message2 = Get_translation_result(message2, original_language)
    message3 = Get_translation_result(message3, original_language)
    message4 = Get_translation_result(message4, original_language)

    answer = answer.result()
    message1 = message1.result()
    message2 = message2.result()
    message3 = message3.result()
    message4 = message4.result()

    responses = [
        {
            "type": "text",
            "content": answer,
        },
    ]
    suggestions = [
        SuggestedContent(text=message3, routes=None),
        SuggestedContent(
            text=message4, routes=get_tagged_routes_suggestions(original_language, original_query=original_query)
        ),
    ]

    responses.append(
        {
            "type": "route_suggestion",
            "content": SuggestedRoutesContent(
                title="",
                content=[
                    SuggestedRoutesResponse(text=message1),
                    SuggestedRoutesResponse(text=message2),
                    SuggestedRoutesResponse(suggestions=suggestions),
                ],
                behavior=None,
            ),
        }
    )

    DEFAULT_RESPONSE_OUTPUT = ChatResponse(
        role=MessageRole.ASSISTANT,
        content=responses,
        source_docs=[],
    )
    return DEFAULT_RESPONSE_OUTPUT


def get_default_clarification_response_output(original_language, message):

    responses = [
        {
            "type": "text",
            "content": message,
        },
    ]

    DEFAULT_RESPONSE_OUTPUT = ChatResponse(
        role=MessageRole.ASSISTANT,
        content=responses,
        source_docs=[],
    )
    return DEFAULT_RESPONSE_OUTPUT


def get_default_answer_for_non_rd_entity(
    original_language: str, entity_name: str, suggested_entities: SuggestedEntities
):
    message1 = f"CreditCompanion™ is unable to provide any information about {entity_name} because it is either not currently covered by S&P Global Ratings and within RatingsDirect® or is outside of your subscription. For access inquiries or further assistance, please contact Customer Support at ratings.direct@spglobal.com."
    message2 = "We found other close matches. Select an entity from the list below to re-run your question:"
    message3 = "Tip: Use the @ symbol in your question to pull up search results and select the company you'd like to see info for. The RD badge indicates Ratings coverage."
    message4 = f"CreditCompanion™ is unable to provide any information about {entity_name} because it is either not currently covered by S&P Global Ratings and within RatingsDirect® or is outside of your subscription. For access inquiries or further assistance, please contact Customer Support at ratings.direct@spglobal.com.\n\nTip: Use the @ symbol in your question to pull up search results and select the company you'd like to see info for. The RD badge indicates Ratings coverage."
    title_entity = "Not the right entity?"

    message1 = Get_translation_result(message1, original_language)
    message2 = Get_translation_result(message2, original_language)
    message3 = Get_translation_result(message3, original_language)
    message4 = Get_translation_result(message4, original_language)
    title_entity = Get_translation_result(title_entity, original_language)

    message1 = message1.result()
    message2 = message2.result()
    message3 = message3.result()
    message4 = message4.result()
    title_entity = title_entity.result()

    if suggested_entities:
        entities = suggested_entities.entities
        names = []
        queries = []
        for entity in entities:
            names.append(Get_translation_result(entity.name, original_language))
            queries.append(Get_translation_result(entity.query, original_language))

        for entity, name, query in zip(entities, names, queries):
            entity.name = name.result()
            entity.query = query.result()

        content = [
            {
                "type": "text",
                "content": message1,
            },
            {
                "type": "suggestion",
                "content": SuggestedEntitiesContent(
                    title=title_entity,
                    content=[
                        SuggestedEntitiesResponse(text=message2),
                        SuggestedEntitiesResponse(suggestions=entities),
                        SuggestedEntitiesResponse(text=message3),
                    ],
                    behavior="collapse" if suggested_entities.query_entity_is_rd else "expand",
                ),
            },
        ]
    else:
        content = [
            {
                "type": "text",
                "content": message4,
            }
        ]

    return ChatResponse(
        role=MessageRole.ASSISTANT,
        content=content,
        source_docs=[],
    )


def get_default_answer_for_no_relevant_articles(
    original_language, entity: Union[Companies, RevenueSource], query: str
) -> List[Document]:
    if isinstance(entity, Companies):
        base_url = config_machinery.get_config_value(Constants.SourceGeneration.BASE_URL)
        entity_url = "/web/client#" + entity.url
    else:
        base_url = config_machinery.get_config_value(Constants.SourceGeneration.BASE_URL)
        entity_url = "/web/client#" + entity.url

    message = f"CreditCompanion™ is unable to find relevant research about {entity.name}, please review the entity's [profile page]({base_url}{entity_url}) for more information."
    message = Get_translation_result(message, original_language)
    message = message.result()
    return [
        Document(
            content=message,
            synthesize=False,
            user_query=query,
            entity=entity.name,
            error_docs=True,
        )
    ]


def get_default_answer(reason="default", original_language="English", **kwargs):
    if reason == "default":
        original_query = kwargs.get("original_query")
        return get_default_response_output(original_language, original_query)
    elif reason == "custom_message":
        original_query = kwargs.get("original_query")
        answer = deepcopy(get_default_response_output(original_language, original_query=original_query))
        answer.content[0]["content"] = kwargs.get(
            "message", get_default_response_output(original_language, original_query).content[0]["content"]
        )
        return answer
    elif reason == "clarifying":
        answer = get_default_clarification_response_output(original_language, kwargs.get("message"))
        return answer
    elif reason == "get_default_answer_for_non_rd_entity":
        return get_default_answer_for_non_rd_entity(original_language, **kwargs)
    elif reason == "no_relevant_articles":
        return get_default_answer_for_no_relevant_articles(original_language, **kwargs)
    else:
        raise Exception(f"There is no default response for reason: {reason} with args: {kwargs}")
