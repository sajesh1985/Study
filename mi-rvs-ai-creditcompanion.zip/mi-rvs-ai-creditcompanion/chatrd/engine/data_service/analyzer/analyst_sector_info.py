from chatrd.core.llm import LCLLMFactory
from chatrd.core.llm.components.message import AIMessage
from chatrd.engine.configuration import get_config_machinery
from chatrd.engine.data_service.analyzer.base import BaseAnalyzer
from chatrd.engine.data_service.analyzer.prompts.prompts import ANALYST_SECTOR_PROMPT
from chatrd.engine.data_service.schema import Analyzer, ProcessorInput

config_machinery = get_config_machinery()


class AnalystAndSectorInfoAnalyzer(BaseAnalyzer):

    def analyze(self, processor: ProcessorInput) -> Analyzer:

        prompt = ANALYST_SECTOR_PROMPT + " " + processor.user_input
        llm = LCLLMFactory().get_llm(deployment_name_or_model_id="claude-3-haiku", temperature=0.0)
        response = llm.invoke(prompt)

        if isinstance(response, AIMessage):
            response = response.content
        else:
            response = None

        return Analyzer(user_input=processor.user_input, uc_type=processor.uc_type, response={}, ds_tag=response)
