############################### table filtering logic ###############################

import json
from concurrent.futures import ThreadPoolExecutor, as_completed

# Add these imports to the existing ones
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple, Union


@dataclass
class TableInfo:
    """Structure to hold extracted table information for relevance assessment."""

    table_id: str
    title: str
    description: str
    column_names: List[str]
    sample_rows: List[Dict]
    row_count: int
    metadata: dict
    source_info: str


@dataclass
class RelevanceResult:
    """Structure to hold relevance assessment result."""

    table_id: str
    relevance_score: int  # 1, 0, or -1
    reasoning: str
    confidence: float = 0.0


def prepare_tables(
    retrieved_docs: List, user_question: str, model_id: str, temperature: float = 0.0
) -> Tuple[List, List[TableDocument]]:
    """
    Extract TableDocuments from retrieved documents and prepare for relevance assessment.

    Args:
        retrieved_docs: List of all retrieved documents
        user_question: The user's original question
        model_id: LLM model identifier
        temperature: LLM temperature setting

    Returns:
        Tuple of (non_table_docs, table_docs)
    """
    table_docs = []
    non_table_docs = []

    for doc in retrieved_docs:
        if isinstance(doc, TableDocument):
            table_docs.append(doc)
        else:
            non_table_docs.append(doc)

    logger.info(f"Prepared {len(table_docs)} TableDocuments and {len(non_table_docs)} other documents for processing")

    return non_table_docs, table_docs


def table_content_extraction(table_doc: TableDocument, table_id: str) -> TableInfo:
    """
    Extract relevant information from TableDocument for LLM analysis.

    Args:
        table_doc: The TableDocument to extract info from
        table_id: Unique identifier for the table

    Returns:
        TableInfo object with extracted information
    """
    try:
        # Extract basic metadata
        metadata = table_doc.metadata or {}
        title = metadata.get("table_title", metadata.get("SourceTitle", "Unknown Table"))
        description = metadata.get("table_description", "")
        source_info = metadata.get("source_description", "")

        # Handle different table content types
        if isinstance(table_doc.content, TableResponse):
            column_names = [col.get("name", "") for col in (table_doc.content.column_schema or [])]
            rows = table_doc.content.rows or []
            row_count = table_doc.content.count or len(rows)

            # Get sample rows (first 3 rows for analysis)
            sample_rows = rows[:3] if rows else []

        elif isinstance(table_doc.content, CSDTableResponse):
            data = table_doc.content.data or []
            row_count = len(data)

            # Extract column names from CSD data structure
            column_names = []
            sample_rows = []

            if data:
                # CSD tables have specific structure - extract meaningful columns
                first_row = data[0]
                column_names = list(first_row.keys())

                # Get sample rows (first 3 meaningful rows)
                sample_rows = data[:3]

        elif isinstance(table_doc.content, ParentChildTableResponse):
            # Handle ParentChildTableResponse structure
            column_names = ["ParentChild Table"]  # Placeholder
            sample_rows = [{"info": "ParentChild table structure"}]
            row_count = 1

        else:
            # Fallback for unknown table types
            column_names = ["Unknown"]
            sample_rows = []
            row_count = 0

        return TableInfo(
            table_id=table_id,
            title=title,
            description=description,
            column_names=column_names,
            sample_rows=sample_rows,
            row_count=row_count,
            metadata=metadata,
            source_info=str(source_info),
        )

    except Exception as e:
        logger.error(f"Error extracting table content for table {table_id}: {e}")
        return TableInfo(
            table_id=table_id,
            title="Error extracting table",
            description="",
            column_names=[],
            sample_rows=[],
            row_count=0,
            metadata=metadata,
            source_info="",
        )


def create_relevance_prompt(user_question: str, table_infos: List[TableInfo]) -> str:
    """
    Create a structured prompt for table relevance assessment.

    Args:
        user_question: The user's original question
        table_infos: List of TableInfo objects to assess

    Returns:
        Structured prompt string for LLM
    """

    prompt = f"""You are an expert data analyst tasked with determining the relevance of tables to a user's question.

USER QUESTION: "{user_question}"

Your task is to assess the relevance of each table below and assign a relevance score:
- Score 1: MOST RELEVANT - Table directly answers or significantly helps answer the user's question
- Score 0: SOMEWHAT RELEVANT - Table contains related information but doesn't directly answer the question
- Score -1: IRRELEVANT - Table has no meaningful connection to the user's question

For each table, provide your assessment in this exact JSON format:
{{
    "table_id": "table_id_here",
    "relevance_score": score_here,
    "reasoning": "brief explanation of your decision"
}}

TABLES TO ASSESS:
"""

    for i, table_info in enumerate(table_infos, 1):
        prompt += f"""
--- TABLE {i} (ID: {table_info.table_id}) ---
Title: {table_info.title}
Description: {table_info.description}
Source: {table_info.source_info}
Columns ({len(table_info.column_names)}): {', '.join(table_info.column_names[:10])}{'...' if len(table_info.column_names) > 10 else ''}
Row Count: {table_info.row_count}
Sample Data: {table_info.sample_rows[:2] if table_info.sample_rows else 'No sample data'}
"""

    prompt += f"""

Please provide your relevance assessment for all {len(table_infos)} tables as a JSON array:
[
    {{"table_id": "table_1", "relevance_score": score, "reasoning": "explanation"}},
    {{"table_id": "table_2", "relevance_score": score, "reasoning": "explanation"}},
    ...
]
"""

    return prompt


def parse_relevance_response(llm_response, table_ids: List[str]) -> List[RelevanceResult]:
    """
    Parse LLM response to extract relevance scores.

    Args:
        llm_response: Raw LLM response (could be string or AIMessage object)
        table_ids: List of expected table IDs

    Returns:
        List of RelevanceResult objects
    """
    results = []

    try:
        # Handle different response types (AIMessage vs string)
        if hasattr(llm_response, "content"):
            # AIMessage object - extract content
            response_text = llm_response.content.strip()
        elif isinstance(llm_response, str):
            # String response
            response_text = llm_response.strip()
        else:
            # Convert to string as fallback
            response_text = str(llm_response).strip()

        # Find JSON array in response
        start_idx = response_text.find("[")
        end_idx = response_text.rfind("]") + 1

        if start_idx >= 0 and end_idx > start_idx:
            json_text = response_text[start_idx:end_idx]
            assessments = json.loads(json_text)

            for assessment in assessments:
                table_id = assessment.get("table_id", "")
                score = assessment.get("relevance_score", 0)
                reasoning = assessment.get("reasoning", "No reasoning provided")

                # Validate score
                if score not in [-1, 0, 1]:
                    logger.warning(f"Invalid relevance score {score} for table {table_id}, defaulting to 0")
                    score = 0

                results.append(RelevanceResult(table_id=table_id, relevance_score=score, reasoning=reasoning))

    except Exception as e:
        logger.error(f"Error parsing relevance response: {e}")
        logger.debug(f"Response type: {type(llm_response)}")
        logger.debug(f"Response content: {llm_response}")

    # Ensure we have results for all tables (default to somewhat relevant if parsing fails)
    result_ids = {r.table_id for r in results}
    for table_id in table_ids:
        if table_id not in result_ids:
            logger.warning(f"No relevance result for table {table_id}, defaulting to somewhat relevant")
            results.append(
                RelevanceResult(
                    table_id=table_id,
                    relevance_score=0,
                    reasoning="Failed to parse relevance assessment, defaulting to somewhat relevant",
                )
            )

    return results


def batch_process_tables(
    table_docs: List[TableDocument], user_question: str, model_id: str, temperature: float = 0.0, batch_size: int = 5
) -> List[RelevanceResult]:
    """
    Process tables in batches for relevance assessment.

    Args:
        table_docs: List of TableDocument objects to assess
        user_question: User's original question
        model_id: LLM model identifier
        temperature: LLM temperature setting
        batch_size: Number of tables to process per LLM call

    Returns:
        List of RelevanceResult objects
    """
    if not table_docs:
        return []

    # Initialize LLM
    llm = LCLLMFactory().get_llm(deployment_name_or_model_id=model_id, temperature=temperature)

    all_results = []

    # Process tables in batches
    for i in range(0, len(table_docs), batch_size):
        batch = table_docs[i : i + batch_size]

        try:
            # Extract table information for this batch
            table_infos = []
            for j, table_doc in enumerate(batch):
                table_id = f"table_{i + j + 1}"
                table_info = table_content_extraction(table_doc, table_id)
                table_infos.append(table_info)

            # Create prompt for this batch
            prompt = create_relevance_prompt(user_question, table_infos)

            # Call LLM
            logger.info(f"Processing batch {i//batch_size + 1} with {len(table_infos)} tables")
            llm_response = llm.invoke(prompt)

            # Parse response
            table_ids = [info.table_id for info in table_infos]
            batch_results = parse_relevance_response(llm_response, table_ids)

            all_results.extend(batch_results)

            logger.info(f"Completed relevance assessment for batch {i//batch_size + 1}")

        except Exception as e:
            logger.error(f"Error processing table batch {i//batch_size + 1}: {e}")
            # Default to somewhat relevant for failed batch
            for j, table_doc in enumerate(batch):
                table_id = f"table_{i + j + 1}"
                all_results.append(
                    RelevanceResult(
                        table_id=table_id, relevance_score=0, reasoning=f"Error during processing: {str(e)}"
                    )
                )

    return all_results


def filter_tables_by_relevance(
    table_docs: List[TableDocument], user_question: str, model_id: str, temperature: float = 0.0
) -> Tuple[List[TableDocument], List[RelevanceResult]]:
    """
    Filter TableDocuments based on relevance to user question.

    Args:
        table_docs: List of TableDocument objects to filter
        user_question: User's original question
        model_id: LLM model identifier
        temperature: LLM temperature setting

    Returns:
        Tuple of (filtered_table_docs, relevance_results)
    """
    if not table_docs:
        return [], []

    logger.info(f"Starting relevance filtering for {len(table_docs)} tables")

    # Process tables for relevance assessment
    relevance_results = batch_process_tables(table_docs, user_question, model_id, temperature)

    # Filter tables based on relevance scores
    filtered_tables = []
    relevance_stats = {1: 0, 0: 0, -1: 0}

    for i, result in enumerate(relevance_results):
        if i < len(table_docs):  # Safety check
            relevance_stats[result.relevance_score] += 1

            # Keep tables that are most relevant (1) or somewhat relevant (0)
            if result.relevance_score >= 0:
                filtered_tables.append(table_docs[i])
                logger.info(f"Keeping table {result.table_id} (score: {result.relevance_score}): {result.reasoning}")
            else:
                logger.info(
                    f"Filtering out table {result.table_id} (score: {result.relevance_score}): {result.reasoning}"
                )

    logger.info(
        f"Relevance filtering complete. Stats: {relevance_stats[1]} most relevant, "
        f"{relevance_stats[0]} somewhat relevant, {relevance_stats[-1]} irrelevant. "
        f"Kept {len(filtered_tables)} out of {len(table_docs)} tables"
    )

    return filtered_tables, relevance_results


############################### table filtering logic end ###############################


def contains_markdown_table(content: str) -> bool:
    """Check if content contains a markdown table."""
    if not content or not isinstance(content, str):
        return False

    lines = content.strip().split("\n")
    for i, line in enumerate(lines):
        if "|" in line and i + 1 < len(lines):
            next_line = lines[i + 1]
            # Check if next line is a separator row (contains |, :, -)
            if re.match(r"^[\s\|:\-]+$", next_line):
                return True
    return False


def parse_markdown_table_to_dataframe(content: str) -> pd.DataFrame:
    """Parse markdown table to pandas DataFrame."""
    lines = [line.strip() for line in content.strip().split("\n") if line.strip()]

    if len(lines) < 3:  # Need at least header, separator, and one data row
        return pd.DataFrame()

    # Find the header row and separator row
    header_idx = None
    separator_idx = None

    for i, line in enumerate(lines):
        if "|" in line:
            if i + 1 < len(lines) and re.match(r"^[\s\|:\-]+$", lines[i + 1]):
                header_idx = i
                separator_idx = i + 1
                break

    if header_idx is None or separator_idx is None:
        return pd.DataFrame()

    # Extract headers
    header_line = lines[header_idx]
    headers = [col.strip() for col in header_line.split("|") if col.strip()]

    if not headers:
        return pd.DataFrame()

    # Extract data rows
    data_rows = []
    for line in lines[separator_idx + 1 :]:
        if "|" in line:
            cells = [cell.strip() for cell in line.split("|")]
            # Remove empty cells at the beginning and end
            while cells and not cells[0]:
                cells.pop(0)
            while cells and not cells[-1]:
                cells.pop()

            if cells:
                # Ensure we have the right number of columns
                while len(cells) < len(headers):
                    cells.append("")
                data_rows.append(cells[: len(headers)])

    if not data_rows:
        return pd.DataFrame()

    # Create DataFrame
    df = pd.DataFrame(data_rows, columns=headers)

    return df


def filter_rows_by_fill_percentage(df: pd.DataFrame, threshold: float = 0.7) -> pd.DataFrame:
    """Filter rows where more than threshold% of cells are filled."""
    if df.empty:
        return df

    # Calculate fill percentage for each row (non-empty strings)
    fill_percentages = df.apply(lambda row: (row.astype(str).str.strip() != "").sum() / len(row), axis=1)

    # Filter rows that meet the threshold
    filtered_df = df[fill_percentages > threshold]

    return filtered_df


def dataframe_to_table_response(df: pd.DataFrame) -> TableResponse:
    """Convert pandas DataFrame to TableResponse."""
    if df.empty:
        return TableResponse(column_schema=[], rows=[], count=0)

    # Create column schema
    column_schema = []
    for i, col in enumerate(df.columns):
        column_schema.append({"name": str(col), "type": "string", "index": i})

    # Convert rows to list of dictionaries
    rows = []
    for _, row in df.iterrows():
        row_dict = {}
        for col in df.columns:
            row_dict[str(col)] = str(row[col])
        rows.append(row_dict)

    return TableResponse(column_schema=column_schema, rows=rows, count=len(rows), count_distribution=None)


def convert_document_to_table_document(doc: Document) -> TableDocument:
    """Convert Document with markdown table to TableDocument with TableResponse."""
    try:
        # Parse markdown table to DataFrame
        df = parse_markdown_table_to_dataframe(doc.content)
        doc.synthesize = False

        if df.empty:
            logger.warning("Failed to parse markdown table - empty DataFrame")
            return TableDocument(
                content=TableResponse(column_schema=[], rows=[], count=0),
                metadata=doc.metadata,
                synthesize=doc.synthesize,
                original_table=doc.content,
            )

        # Filter rows by fill percentage (70% threshold)
        filtered_df = filter_rows_by_fill_percentage(df, threshold=0.7)

        # Convert to TableResponse
        table_response = dataframe_to_table_response(filtered_df)

        # Create TableDocument
        table_doc = TableDocument(
            content=table_response, metadata=doc.metadata, synthesize=doc.synthesize, original_table=doc.content
        )

        logger.info(
            f"Converted document to TableDocument with TableResponse containing {len(filtered_df)} rows (from {len(df)} original rows)"
        )

        return table_doc

    except Exception as e:
        logger.error(f"Error converting document to table document: {e}")
        # Return empty TableDocument if conversion fails
        return TableDocument(
            content=TableResponse(column_schema=[], rows=[], count=0),
            metadata=doc.metadata,
            synthesize=doc.synthesize,
            original_table=doc.content,
        )
