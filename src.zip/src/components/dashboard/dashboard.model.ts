import { getHeadlessHydraAPIRequest } from '@spglobal/dataapiservice';
import { IBlog } from '../blog/Blog';

const getHeadlessHydraDataForBlogs = (parameters: Record<string, any>): Promise<any> => {
  parameters = { urlparam: parameters };

  return getHeadlessHydraAPIRequest('402629', parameters, false, {
    method: 'POST',
    data: JSON.stringify(parameters),
  }).then((result: any) => result?.Data || null);
};

export const getBlogsDataSet = async (parameters: Record<string, any>): Promise<IBlog> => {
  const resultDTO = await getHeadlessHydraDataForBlogs(parameters);
  return resultDTO
    ? {
        EditorsPicksData: resultDTO.EditorsPicksData?.data?.value || [],
        FeatureActiveResult: resultDTO.FeatureActiveResult?.data?.value || [],
        FeatureNameData: resultDTO.FeatureNameData?.data?.value || [],
        FeatureNewsData: resultDTO.FeatureNewsData?.data?.value || [],
      }
    : {};
};
