import logging
import traceback
from typing import TypedDict, List, Optional
import httpx
from src.synthia.config.api_config import get_config
from src.synthia.utils.logging_config import configure_logging

logger = configure_logging(
    logger_name=__name__,
    log_file="synthia.log",
    module_levels={__name__: logging.DEBUG},  # Set this module to DEBUG
)

# Shared client for connection pooling
_client: Optional[httpx.AsyncClient] = None

async def get_http_client(timeout: float = 30.0) -> httpx.AsyncClient:
    """Get or create shared HTTP client for connection pooling."""
    global _client
    if _client is None:
        _client = httpx.AsyncClient(
            timeout=timeout,
            limits=httpx.Limits(max_keepalive_connections=20, max_connections=100)
        )
    return _client

async def close_http_client():
    """Close the shared HTTP client. Call this on application shutdown."""
    global _client
    if _client is not None:
        try:
            await _client.aclose()
            logger.info("HTTP client closed successfully")
        except Exception as e:
            logger.error(f"Error closing HTTP client: {e}", exc_info=True)
        finally:
            _client = None

class UserProfileData(TypedDict):
    """TypedDict for user profile data from Capital IQ API."""

    KeyOnlineUser: int
    Email: str
    KeyOnlineServices: List[int]


async def fetch_user_profile_data(auth_token: str) -> UserProfileData:
    """
    Fetch user profile data from Capital IQ API.

    Returns:
        UserProfileData: A dictionary containing user profile information.

    Raises:
        httpx.HTTPError: If the API request fails.
        ValueError: If data doesn't match expected format.
    """
    config = get_config()
    url = config["capitaliq_kou_url"]
    max_retries = 3
    
    for attempt in range(max_retries):
        try:
            client = await get_http_client(timeout=3.0)
            logger.info(f"Sending get request to {url} (attempt {attempt + 1}/{max_retries + 1})")
            logger.debug(f"Auth token used: {auth_token}")
            response = await client.get(
                url + ",KeyOnlineServices", headers={"Authorization": f"{auth_token}"}
            )
            response.raise_for_status()
            data = response.json()

            user_data = data.get("value", data)

            return UserProfileData(
                KeyOnlineUser=user_data["KeyOnlineUser"],
                Email=user_data["Email"],
                KeyOnlineServices=user_data["KeyOnlineServices"],
            )
        except httpx.HTTPStatusError as e:
            logger.error(f"HTTP error occurred: {e.response.status_code} - {e.response.text}\n{traceback.format_exc()}")
            if attempt == max_retries:
                raise
        except httpx.RequestError as e:
            logger.error(f"Request error occurred: {str(e)}\n{traceback.format_exc()}")
            if attempt == max_retries:
                raise
        except KeyError as e:
            logger.error(f"Missing required field in API response: {e.args[0]}\n{traceback.format_exc()}")
            raise ValueError(f"Missing required field: {e.args[0]}") from e
        except (TypeError, AttributeError) as e:
            logger.error(f"Invalid data structure in API response: {str(e)}\n{traceback.format_exc()}")
            raise ValueError(f"Invalid data structure: {str(e)}") from e
        except Exception as e:
            logger.error(f"Unexpected error occurred: {str(e)}\n{traceback.format_exc()}")
            if attempt == max_retries:
                raise


async def fetch_company_name(auth_token: str) -> str:
    """User profile data above does not expose the user's unique company name, so we are getting it from the underlying odata service"""
    user_profile: UserProfileData = await fetch_user_profile_data(auth_token)
    user_id = user_profile["KeyOnlineUser"]
    config = get_config()
    base_url = config["origin"] # all other config options have hard coded service paths for some reason
                                # additional note: we might want to introduce the internal routes at some point for speed (post-PoC?)
    url = f'{base_url}/SNL.Services.Security.Service/v1/Context/UserProfiles/Context.GetCurrent?$select=InstnName'
    headers = {
        "Authorization": f"{auth_token}",
        # parameters below proposed by Yitinn Chopra
        "kou": f"{user_id}",
        "Cookie": "SNLStack=STACK1"
    }
    client = await get_http_client()
    logger.info(f"Sending get request to get profile InstName: {url}")
    response = await client.get(url, headers=headers)
    response.raise_for_status()
    data = response.json()
    company_name = data["InstnName"]
    logger.info(f"Received InstName: {company_name}")
    return company_name

