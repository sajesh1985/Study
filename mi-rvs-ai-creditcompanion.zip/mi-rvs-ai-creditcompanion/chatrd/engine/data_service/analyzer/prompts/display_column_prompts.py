DISPLAY_COLUMN_PROMPT = """
**DISPLAY COLUMN EXTRACTION RULES:**
- Set to True when user explicitly asks to include, display, or show {value} in results
- Keywords indicating display_column=True:
  • "include {value}" or "include their {value}"
  • "and {value}" or "and their {value}"
  • "display {value}" or "display their {value}" 
  • "show {value}" or "show their {value}"
  • "with {value}" or "with their {value}"
  • "highlighting their {value}"
  • "show me their {value}"
  • "showcase the {value}"
  • "highlight the {value}" 
  • "outlining the {value}"
- Set to False when user is filtering by specific {value} (normal {value} extraction)
- Set to False when no mention of displaying/including {value} in output
- Remember: There's a difference between filtering BY {value} vs wanting to DISPLAY {value} in the output
"""
