import copy
from importlib.resources import files
from typing import Dict, List

import pandas as pd

from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.data_service.kpqi import KPQI
from chatrd.engine.data_service.synthesizer.utils import text_response


def return_unsupported_response():
    config_machinery = get_config_machinery()
    source_base_url = config_machinery.get_config_value(Constants.SourceGeneration.BASE_URL)
    footnote_url_slug = config_machinery.get_config_value(Constants.SourceGeneration.FOOTNOTE_URL_SLUG)
    query_param = "?auth=inherit#office/screener?perspective=321247"
    screener_url = source_base_url + footnote_url_slug + query_param

    content = (
        f'Sorry, CreditCompanion<sup>TM</sup> is unable to provide any response. Please try a different question or proceed to <a href="{screener_url}">Screener</a>.',
    )
    data_service_response = [text_response(content)]

    return {
        "data": data_service_response,
        "source_description": [],
        "api_info": {
            "method": "POST",
            "type": "screener",
            "url": screener_url,
            "payload": {"data": None, "parameters": {}},
            "extra": {"additional_info": ""},
        },
    }


def get_payload_path(payload_file: str):
    config_machinery = get_config_machinery()
    payload_path = str(
        files("chatrd.engine.data.data_service").joinpath(config_machinery.get_config_value(payload_file)).resolve()
    )
    return payload_path


def update_query_field(input_dict: Dict, query_field: Dict) -> Dict:
    """
    Dynamically update the query field based on users input.
    Args:
        input_dict (Dict): A dictionary that contains users input data.
        query_field (Dict): A query field with default values.

    Returns: A dictionary of updated query field.

    """
    value, connector, operator = (
        input_dict["value"],
        input_dict["connector"],
        input_dict["operator"],
    )

    query_field["value"] = value
    query_field["connector"] = connector
    query_field["operator"] = operator

    return query_field


def get_ratings_payload(payload: Dict):
    ratings_payload = copy.deepcopy(payload)
    if len(ratings_payload["functionRequests"][0]["fields"]) > 0:
        df_ratings = pd.DataFrame(ratings_payload["functionRequests"][0]["fields"])
        df_ratings_sl = df_ratings[
            (
                df_ratings["primary"].isin(
                    [KPQI.RD_SECTOR.value, KPQI.IndustryClassification.value, KPQI.Geography.value]
                )
            )
            | (
                df_ratings["tertiary"].isin(
                    ["Foreign Currency LT|0", "Local Currency LT|0", "Foreign Currency LT|4", "Local Currency LT|4"]
                )
            )
        ]

        df_ratings_sl = (
            df_ratings_sl.drop_duplicates().sort_values(["tertiary", "exportPrimary"]).reset_index(drop=True)
        )
        ratings_payload["functionRequests"][0]["fields"] = df_ratings_sl.to_dict("records")
    return ratings_payload


def build_payload_for_count_query(payload: Dict):
    count_payload = copy.deepcopy(payload)
    _ = count_payload["functionRequests"][0].pop("pagingInfo", None)
    count_payload["functionRequests"][0]["query"]["countsQuery"] = True
    return count_payload


def get_full_payload(payload: Dict):
    full_payload = copy.deepcopy(payload)
    _ = full_payload["functionRequests"][0].pop("pagingInfo", None)
    return full_payload


def map_metrics_to_field(metrics_data: List[Dict], time_period: str) -> Dict:
    """
    Transform metrics data from metrics list to field for display column in Screener.

    Args:
        metrics_data (list): List of metric dictionaries.
        timePeriod (str): a array of time periods.

    Returns:
        dict: A dictionary with 'displayFields' as the key and a list of transformed metrics as the value.
    """

    # Create a list to hold the transformed metrics
    transformed_metrics_list = []
    unique_metrics = []
    for metric in metrics_data:
        for time in time_period:
            # Only process metrics that have both required fields
            if metric.get("MetricKPQI") and metric.get("MetricAliases"):
                metric_code = metric.get("MetricCode", "")
                metric_code += f"|{time}"
                if metric_code in unique_metrics:
                    continue
                unique_metrics.append(metric_code)
                transformed_metric = {
                    "primary": metric.get("MetricKPQI", ""),
                    "exportPrimary": metric.get("MetricAliases", ""),
                    "secondary": time,  # Use the current timePeriod
                    "tertiary": None,
                    "contextJson": None,
                    "originalSecondary": None,
                    "originalTertiary": None,
                    "context": None,
                }
                # Append the transformed metric to the list
                transformed_metrics_list.append(transformed_metric)

    # Return the dictionary with 'displayFields' as the key
    return {"displayFields": transformed_metrics_list}


def transform_time_periods(timePeriods: list) -> list:
    """
    Transforms an array of timePeriod strings based on specific rules:
    - Replace 'LFY' with 'FY0'
    - Replace 'LFQ' with 'FQ0'
    - Replace 'LHY' with 'FH0'
    - Transform year values appended by 'Y' (e.g., '2023Y' → 'FY2023')
    - Transform year values appended by 'Q' and a quarter number (e.g., '2023Q1' → 'FQ12023')
    - Transform year values appended by 'H' and a half-year number (e.g., '2023H1' → 'FH12023')

    Args:
        timePeriods (list): A list of time period strings.

    Returns:
        list: A list of transformed time period strings.
    """
    transformed_periods = []
    for timePeriod in timePeriods:
        if "LFY" in timePeriod:
            timePeriod = timePeriod.replace("LFY", "FY0")
        if "LFQ" in timePeriod:
            timePeriod = timePeriod.replace("LFQ", "FQ0")
        if "LHY" in timePeriod:
            timePeriod = timePeriod.replace("LHY", "FH0")
        if timePeriod.endswith("Y") and timePeriod[:-1].isdigit():
            year = timePeriod[:-1]  # Extract the year part
            timePeriod = f"FY{year}"  # Transform to 'FY<year>'
        if "Q" in timePeriod and timePeriod[:-2].isdigit() and timePeriod[-1].isdigit():
            year = timePeriod[:-2]  # Extract the year part
            quarter = timePeriod[-1]  # Extract the quarter part
            timePeriod = f"FQ{quarter}{year}"  # Transform to 'FQ<quarter><year>'
        if "H" in timePeriod and timePeriod[:-2].isdigit() and timePeriod[-1].isdigit():
            year = timePeriod[:-2]  # Extract the year part
            half_year = timePeriod[-1]  # Extract the half-year part
            timePeriod = f"FH{half_year}{year}"  # Transform to 'FH<half-year><year>'
        transformed_periods.append(timePeriod)

    return transformed_periods


def rename_duplicated_columns(df):
    cols = pd.Series(df.columns)
    for dup in cols[cols.duplicated()].unique():
        cols[cols[cols == dup].index.values.tolist()] = [
            dup + "_" + str(i) if i != 0 else dup for i in range(sum(cols == dup))
        ]
    df.columns = cols
    return df
