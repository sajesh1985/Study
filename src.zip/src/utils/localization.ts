export const mapLocalizationKeyValues = (t: any, keys: string[]) => {
  const maps = new Map(keys.map((x) => [x, t(x)]));
  return Object.fromEntries(maps.entries());
};

export enum Cultures {
  DEFAULT_CULTURE = 'en-US',
  CULTURE_CA= 'en-CA',
  CULTURE_HK= 'zh-HK',
  CULTURE_SG= 'zh-SG',
  CULTURE_PH= 'fil-PH',
  CULTURE_ID= 'id-ID',
  CULTURE_DE_AT = 'de-AT',
  CULTURE_DE_CH = 'de-CH',
  CULTURE_DE_DE = 'de-DE',
  CULTURE_ES_ES = 'es-ES',
  CULTURE_EN_GB = 'en-GB',
  CULTURE_FR_BE = 'fr-BE',
  CULTURE_FR_FR = 'fr-FR',
  CULTURE_HI_IN = 'hi-IN',
  CULTURE_ID_ID = 'id-ID',
  CULTURE_IT_IT = 'it-IT',
  CULTURE_JA_JP = 'ja-JP',
  CULTURE_NB_NO = 'nb-NO',
  CULture_PL_PL = 'pl-PL',
  CULTURE_RW_RW = 'rw-RW',
  CULTURE_TH_TH = 'th-TH',
  CULTURE_TA_IN = 'ta-IN',
  CULTURE_TN_ZA = 'tn-ZA',
  CULTURE_XH_ZA = 'xh-ZA',
  CULTURE_ZH_SH = 'zh-SH',
  CULTURE_ZU_ZA = 'zu-ZA',
}

export const getLanguageLocaleNameForDate = (culture: string): string => {
  const overwrittenCultures:any = {
    //following cultures are oveerwritten
    [Cultures.CULTURE_DE_AT]: Cultures.CULTURE_EN_GB, // from 8.4.2024 to 08.04.2024
    [Cultures.CULTURE_ES_ES]: Cultures.CULTURE_EN_GB, // from 16/2/2024 to 16/02/2024
    [Cultures.CULTURE_TA_IN]: Cultures.CULTURE_EN_GB, // from 16/2/2024 to 16/02/2024
    [Cultures.CULTURE_ID_ID]: Cultures.CULTURE_EN_GB, // from 8/4/2024 to 08/04/2024
    [Cultures.CULTURE_IT_IT]: Cultures.CULTURE_EN_GB, // from 8/4/2024 to 08/04/2024
    [Cultures.CULTURE_NB_NO]: Cultures.CULTURE_EN_GB, // from 16/2/2024 to 16/02/2024
    [Cultures.CULTURE_RW_RW]: Cultures.DEFAULT_CULTURE, //from 8/4/2024 to 08/04/2024
    [Cultures.CULTURE_TH_TH]: 'th-TH-u-ca-gregory',
    [Cultures.CULTURE_TN_ZA]: Cultures.CULTURE_EN_GB, // from 2/16/2024 to 16/02/24
    [Cultures.CULTURE_ZU_ZA]: Cultures.CULTURE_EN_GB, // from 2/16/2024 to 16-02-2024
    [Cultures.CULTURE_XH_ZA]: Cultures.CULTURE_EN_GB, // from 2/16/2024 to 2024/04/08
  };

  const updatedCulture = overwrittenCultures[culture];

  return updatedCulture ?? culture;
};

export const getLanguageLocaleNameForNumbers = (culture: string): string => {
  const overwrittenCultures:any = {
    //following cultures are oveerwritten
    [Cultures.CULTURE_DE_AT]: Cultures.CULTURE_DE_DE, // from 5 117 960 258 to 5.117.960.258
    [Cultures.CULTURE_XH_ZA]: Cultures.CULTURE_EN_GB, // from 5.117.960.258 to 5,117,960,258
    [Cultures.CULTURE_FR_BE]: Cultures.CULTURE_DE_DE, // from 5 117 960 258 to 5.117.960.258
    [Cultures.CULTURE_RW_RW]: Cultures.CULTURE_FR_BE, // from 5,117,960,258 to 5 117 960 258
  };

  const updatedCulture = overwrittenCultures[culture];

  return updatedCulture ?? culture;
};
