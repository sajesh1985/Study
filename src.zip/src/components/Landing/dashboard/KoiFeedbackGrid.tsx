import React from 'react';

import { AgGrid } from '@spglobal/koi-grid';

// import { CsvExportModule } from "@ag-grid-community/csv-export";
// import { ExcelExportModule } from "@ag-grid-enterprise/excel-export";

// import { config } from '@spglobal/spa';
// import { LicenseManager } from '@ag-grid-enterprise/core';
// const AG_GRID_LICENSE_KEY = config('agGridLicenseKey');
// LicenseManager.setLicenseKey(AG_GRID_LICENSE_KEY);

import {
  // ColDef,
  // GridApi,
  // GridReadyEvent,
  ModuleRegistry,
} from '@ag-grid-community/core';
import { ServerSideRowModelModule } from '@ag-grid-enterprise/server-side-row-model';

ModuleRegistry.registerModules([
  ServerSideRowModelModule,
  // ExcelExportModule,
  // CsvExportModule,
]);

import { TransformedResponseType, ColumnDefType } from './helpers';

interface KoiFeedBackGridType {
  row_data: TransformedResponseType[];
  column_defs: ColumnDefType[];
  onGridReady: (params: any) => void;
}

const excelStyles= [
  {
    id: "header",
    font: {
      bold: true,
    }
  }];
  
const KoiFeedBackGrid: React.FC<KoiFeedBackGridType> = ({ row_data, column_defs,onGridReady }) => {
  // const gridRef = useRef();

  // const onGridReady = () => {
  // setRowData(row_data)
  // }

  // const onBtExport = useCallback(() => {
  //   if ( gridRef.current && gridRef.current.api) {gridRef.current.api.exportDataAsExcel();}
  // }, []);

  return <AgGrid columnDefs={column_defs} rowData={row_data} onGridReady={onGridReady} excelStyles={excelStyles}/>;
};

export default KoiFeedBackGrid;
