from chatrd.core.llm.components import BaseLanguageModel
from chatrd.engine.app.chat_engine import RDChatEngine

# Set global verbosity for all language models
BaseLanguageModel.set_verbose(True)

CHAT_ENGINE = None


def get_chat_engine():
    global CHAT_ENGINE
    if not CHAT_ENGINE:
        CHAT_ENGINE = RDChatEngine()
    return CHAT_ENGINE
