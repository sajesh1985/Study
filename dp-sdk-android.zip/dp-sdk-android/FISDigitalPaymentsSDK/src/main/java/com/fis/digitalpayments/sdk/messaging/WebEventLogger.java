package com.fis.digitalpayments.sdk.messaging;

import android.util.Log;

public class WebEventLogger implements WebEventListener {
    @Override
    public void onEventReceived(WebEvent event) {
        switch (event.getEventType()) {
            case ERROR:
                Log.e(this.toString(), event.toString());
                break;
            default:
                Log.i(this.toString(), event.toString());
                break;
        }
    }
}
