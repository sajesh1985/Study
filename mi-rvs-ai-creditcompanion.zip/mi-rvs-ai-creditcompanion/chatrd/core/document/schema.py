import logging
from collections import OrderedDict
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Literal, NamedTuple, Optional, Union

logger = logging.getLogger(__name__)


class ArticleType(Enum):
    RESEARCH = 0
    CRITERIA = 1
    DEFINITIONS = 2
    COMMENTARY = 3


class TableResponse(NamedTuple):
    column_schema: List[Dict] = None
    rows: List[Dict] = None
    count: Optional[int] = None
    count_distribution: Optional[Dict] = None


class CSDTableResponse(NamedTuple):
    data: List[Dict] = None


class ParentChildTableResponse(NamedTuple):
    data: List[Dict] = None


def make_hashable(obj: Any) -> Any:
    """Recursively convert an object to a hashable type."""
    try:
        if isinstance(obj, dict):
            return frozenset((key, make_hashable(value)) for key, value in obj.items())
        elif isinstance(obj, list):
            return tuple(make_hashable(x) for x in obj)
        elif isinstance(obj, set):
            return frozenset(make_hashable(x) for x in obj)
        else:
            return obj
    except Exception as e:
        logger.error(f"Error while making object hashable: {e}\nObject type_ {type(obj)}\nObject: {obj}")
        return {}


@dataclass
class Document:
    content: str = ""
    metadata: dict = field(default_factory=dict)
    synthesize: bool = True
    uc_type: Optional[str] = None
    authorized: bool = True
    source: Optional[Literal["structured", "unstructured"]] = None
    user_query: str = ""
    entity: str = ""
    error_docs: bool = False

    def __eq__(self, other):
        if isinstance(other, Document):
            return (self.content, make_hashable(self.metadata), self.synthesize, self.authorized) == (
                other.content,
                make_hashable(other.metadata),
                other.synthesize,
                other.authorized,
            )
        return False

    def __hash__(self):
        return hash((self.content, make_hashable(self.metadata), self.synthesize, self.authorized))


@dataclass
class TableDocument:
    content: Union[TableResponse, CSDTableResponse, ParentChildTableResponse] = None
    metadata: dict = field(default_factory=dict)
    synthesize: bool = False
    uc_type: Optional[str] = None
    authorized: bool = True
    original_table: Optional[str] = None
    user_query: str = ""
    entity: str = ""
    error_docs: bool = False

    def __eq__(self, other):
        if isinstance(other, TableDocument):
            return (
                self._make_hashable(self.content),
                make_hashable(self.metadata),
                self.synthesize,
                self.authorized,
            ) == (
                self._make_hashable(other.content),
                make_hashable(other.metadata),
                other.synthesize,
                other.authorized,
            )
        return False

    def __hash__(self):
        return hash((self._make_hashable(self.content), make_hashable(self.metadata), self.synthesize, self.authorized))

    def _make_hashable(self, table_response):
        if table_response is None:
            return None

        if isinstance(table_response, TableResponse):
            return (
                frozenset(frozenset(make_hashable(row) for row in table_response.column_schema)),
                frozenset(frozenset(make_hashable(row) for row in table_response.rows)),
                table_response.count,
            )
        else:
            return frozenset(make_hashable(table_response.data))


class OrderedSet:
    def __init__(self):
        self.ordered_dict = OrderedDict()

    def add(self, item):
        self.ordered_dict[item] = None

    def extend(self, items):
        for item in items:
            self.add(item)

    def __repr__(self):
        return repr(list(self.ordered_dict.keys()))

    def __len__(self):
        return len(self.ordered_dict)

    def __iter__(self):
        return iter(self.ordered_dict.keys())
