import logging
import re
from typing import Dict, List, Union

from botocore.client import BaseClient
from pydantic import BaseModel

from chatrd.core.document import Document, TableDocument
from chatrd.core.vectorstore import OpenSearch
from chatrd.engine.components.query_analyzer.entity_extractor.utils import (
    Companies,
    Entities,
    RevenueSource,
)
from chatrd.engine.components.query_processor.query_retriever.data_service_retriever import (
    call_data_service,
)
from chatrd.engine.components.query_processor.query_retriever.reranker import (
    get_reranked_documents,
)
from chatrd.engine.components.query_processor.query_retriever.uc_retrievers.base import (
    UCRetriever,
)
from chatrd.engine.components.query_processor.query_retriever.uc_retrievers.utils import (
    UCRetrieverType,
)
from chatrd.engine.components.query_processor.query_retriever.utils import (
    add_structured_source,
    add_unstructured_source,
    fetch_relevant_article_ids,
    get_custom_logic_filters_for_entities,
    get_custom_logic_filters_for_peer_comparison,
    get_filters_for_research,
    get_sorted_docs_by_date,
    post_process_retrieved_docs,
)
from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.responses import get_default_answer

logger = logging.getLogger(__name__)

config_machinery = get_config_machinery()


class PeersRetriever(UCRetriever):
    def __init__(self, vector_stores_dict: Dict[str, OpenSearch], reranker_client: BaseClient):
        self.vector_stores_dict = vector_stores_dict
        self.top_k_text_research = config_machinery.get_config_value(Constants.GeneralConstants.TOP_K_TEXT_RESEARCH)
        self.top_k_text_research_double_rerank = config_machinery.get_config_value(
            Constants.GeneralConstants.TOP_K_TEXT_RESEARCH_DOUBLE_RERANK
        )
        self.top_k_text_research_recency_bias_final = config_machinery.get_config_value(
            Constants.GeneralConstants.TOP_K_TEXT_RESEARCH_RECENCY_BIAS_FINAL
        )
        self.reranker_client = reranker_client
        self.reranker_endpoint_name = config_machinery.get_config_value(
            Constants.SageMaker.SAGEMAKER_RERANKER_ENDPOINT_NAME
        )

    def _combine_documents(
        self, structured_documents: Union[Document, TableDocument], unstructured_documents: List[Document]
    ) -> Union[List[Document], TableDocument]:
        if structured_documents and unstructured_documents:
            combined_result_document = []
            combined_result_document.extend(structured_documents)
            combined_result_document.extend(unstructured_documents)
            return combined_result_document
        elif structured_documents:
            return structured_documents
        elif unstructured_documents:
            return unstructured_documents
        else:
            return []

    def retrieve(
        self,
        query: str,
        entities: Entities,
        uc_type: str,
        model_name_for_data_service: str,
        temperature_for_data_service: float,
        sectors: BaseModel,
        original_language: str,
        original_query: str,
        multi_uc_type: bool = False,
    ):

        vector_db_retrieved_documents = []
        all_entities = entities.companies + entities.revenue_sources
        data_service_documents = call_data_service(
            query=query,
            model_name_for_data_service=model_name_for_data_service,
            entities=entities,
            uc_type="peers",
            sectors=sectors,
            original_language=original_language,
            original_query=original_query,
            multi_uc_type=multi_uc_type,
        )

        if not len(data_service_documents) == 1:
            pattern = r"\?id=(\d+)"
            entity_ids = [
                int(match.group(1))
                for value in data_service_documents[1].content[0][1].values()
                if (match := re.search(pattern, str(value), re.IGNORECASE))
            ]
            peers_ids = entity_ids[1:11]

            for entity in all_entities:
                retrieved_documents = self.vector_db_retrieval(
                    query=query,
                    entity=entity,
                    uc_type=uc_type,
                    peers_ids=peers_ids,
                    original_language=original_language,
                )
                vector_db_retrieved_documents.extend(retrieved_documents)

        data_service_documents = add_structured_source(data_service_documents)
        vector_db_retrieved_documents = add_unstructured_source(vector_db_retrieved_documents)
        query_documents = self._combine_documents(
            structured_documents=data_service_documents, unstructured_documents=vector_db_retrieved_documents
        )
        logger.info(f"Total number of retrieved documents : {len(query_documents)}")
        return query_documents

    def vector_db_retrieval(
        self,
        query: str,
        entity: Union[Companies, RevenueSource],
        uc_type: str,
        peers_ids: List[int],
        original_language: str,
    ):
        recency_bias_top_k = 20
        recency_bias_final_top_k = 10
        query = self.rephrased_query(query, entity)

        retrieved_reranked_docs = []

        filters, relevant_article_ids = get_filters_for_research(
            vector_stores_dict=self.vector_stores_dict, entity=entity, uc_type=uc_type
        )
        peer_filter = get_custom_logic_filters_for_peer_comparison(
            relevant_article_ids,
        )

        if not relevant_article_ids:
            return get_default_answer(
                entity=entity, reason="no_relevant_articles", original_language=original_language, query=query
            )

        retrieved_documents, scores = self.vector_stores_dict["research"].get_relevant_documents(
            query,
            efficient_filter=filters,
            model_id=config_machinery.get_config_value(Constants.OpenSearch.NEURAL_SEARCH_MODEL_ID),
            search_pipeline=config_machinery.get_config_value(Constants.OpenSearch.HYBRID_SEARCH_SEARCH_PIPELINE_ID),
            top_k_text_chunks=self.top_k_text_research,
        )

        for doc in retrieved_documents:
            if doc.metadata.get("chunk_title") == "Peer Comparison":
                retrieved_documents.remove(doc)

        peer_comparison_documents, _ = self.vector_stores_dict["research"].get_relevant_documents(
            query,
            efficient_filter=peer_filter,
            model_id=config_machinery.get_config_value(Constants.OpenSearch.NEURAL_SEARCH_MODEL_ID),
            search_pipeline=config_machinery.get_config_value(Constants.OpenSearch.HYBRID_SEARCH_SEARCH_PIPELINE_ID),
            top_k_text_chunks=self.top_k_text_research,
        )

        reranker_threshold = None
        if not isinstance(entity, RevenueSource):
            reranker_threshold = config_machinery.get_config_value(
                Constants.GeneralConstants.DEFAULT_RERANKER_THRESHOLD
            )
        retrieved_documents = get_reranked_documents(
            query=query,
            retrieved_documents=retrieved_documents,
            entity=entity,
            reranker_client=self.reranker_client,
            reranker_endpoint_name=self.reranker_endpoint_name,
            reranker_threshold=reranker_threshold,
            top_k_text_chunks=self.top_k_text_research_double_rerank,
        )

        retrieved_documents = get_sorted_docs_by_date(retrieved_documents, self.top_k_text_research_recency_bias_final)

        entity_name = retrieved_documents[0].metadata["aggLegalEntityName"]
        retrieved_reranked_docs.append(
            Document(
                content=(f"<{entity_name}>"),
            ),
        )
        if peer_comparison_documents != []:
            retrieved_reranked_docs.extend(peer_comparison_documents)
        retrieved_reranked_docs.extend(retrieved_documents)

        retrieved_reranked_docs.append(
            Document(
                content=(f"</{entity_name}>"),
            ),
        )
        retrieved_reranked_docs.append(
            Document(
                content=("<peer documents>"),
            ),
        )

        for peer_id in peers_ids:

            relevant_article_ids_single_peer = fetch_relevant_article_ids(self.vector_stores_dict["research"], peer_id)
            filters_single_peer = get_custom_logic_filters_for_entities(relevant_article_ids_single_peer)
            if not relevant_article_ids_single_peer:
                continue

            retrieved_documents_single_peer, scores = self.vector_stores_dict["research"].get_relevant_documents(
                query,
                efficient_filter=filters_single_peer,
                model_id=config_machinery.get_config_value(Constants.OpenSearch.NEURAL_SEARCH_MODEL_ID),
                search_pipeline=config_machinery.get_config_value(
                    Constants.OpenSearch.HYBRID_SEARCH_SEARCH_PIPELINE_ID
                ),
                top_k_text_chunks=self.top_k_text_research,
            )

            retrieved_documents_single_peer_reranked = get_reranked_documents(
                query=query,
                retrieved_documents=retrieved_documents_single_peer,
                entity=entity,
                reranker_client=self.reranker_client,
                reranker_endpoint_name=self.reranker_endpoint_name,
                reranker_threshold=reranker_threshold,
                top_k_text_chunks=self.top_k_text_research_double_rerank,
            )
            retrieved_documents_single_peer_reranked = get_sorted_docs_by_date(
                retrieved_documents_single_peer_reranked, self.top_k_text_research_recency_bias_final
            )

            peer_name = retrieved_documents_single_peer_reranked[0].metadata["aggLegalEntityName"]
            retrieved_reranked_docs.append(
                Document(
                    content=(f"<{peer_name}>"),
                )
            )
            retrieved_reranked_docs.extend(retrieved_documents_single_peer_reranked)
            retrieved_reranked_docs.append(
                Document(
                    content=(f"</{peer_name}>"),
                )
            )
        retrieved_reranked_docs.append(
            Document(
                content=("</peer documents>"),
            ),
        )

        if not retrieved_reranked_docs:
            return get_default_answer(
                entity=entity, reason="no_relevant_articles", original_language=original_language, query=query
            )

        retrieved_documents = self.add_additional_metadata_to_documents(
            uc_type=uc_type, user_query=query, entity=entity, documents=retrieved_documents
        )
        return retrieved_reranked_docs
