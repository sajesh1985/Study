import React from 'react';
import { ModalOverlay,ModalContent, ArchivalCloseButton, Unarchival } from './HistoryModal.styles';
import { ChatHistoryResponse } from '@root/types/api';
//import moment from 'moment';
import { getLocalizedDate } from '../../../utils/dateLocalization';
import { useUserTraits } from '@spglobal/userprofileservice';


interface HistoryModalProps {
  onClose : () => void;
  onSelect : (el:any) =>void;
  archiveChat: ChatHistoryResponse[];

}
export const HistoryModal: React.FC<HistoryModalProps> = ({ onClose, onSelect,archiveChat }) => {
  const userInformation = useUserTraits(['keyOnlineUser','timeZoneAbbreviation', 'culture', 'mSTimeZoneID']);
  return (
    <>
    <ModalOverlay>
      <ModalContent>
        <h1>Archived Chats</h1>
        <div style={{display:'flex',paddingBottom:'8px'}}>
            <div style={{textAlign: 'left',flex:'3',borderBottom:'1px solid var(--color-base-gray-11)',paddingBottom:'7px'}}>Name</div>
            <div style={{textAlign: 'left',flex:'1',borderBottom:'1px solid var(--color-base-gray-11)',paddingBottom:'7px'}}>Date Created</div>
            <div style={{textAlign: 'left',flex:'1',borderBottom:'1px solid var(--color-base-gray-11)',paddingBottom:'7px'}}>Last Accessed</div>
        </div>
        <div style={{height:'80%',overflowX: 'hidden'}}>
          
        <div style={{width:'100%'}}>
            {archiveChat.map((mess:ChatHistoryResponse) => (
              <div style={{display:'flex'}}>
                <div style={{paddingTop: '10px',width: '66%'}}>
                <div style={{maxWidth:'100%'}}>
                  <div style={{float:'left'}}>
                    <svg style={{width:'var(--size-icon-md)',marginRight:'4px'}} fill="var(--color-icon-primary)" focusable="false" viewBox="0 0 16 16"><path d="M12 1c2 0 3 1.892 3 4v2c0 2.015-1 4-4.008 4L7 13.918V11H4c-2 0-3-2.036-3-4V5c0-1.986 1-4 3-4z" fill-rule="evenodd"></path></svg>
                  </div>
                  <Unarchival title={mess.userInput[0].value} onClick={(e) => { e.preventDefault(); onSelect(mess); }}>
                      {mess.userInput[0].value}
                  </Unarchival>
                  
                </div>
                </div>
                <div style={{fontSize:'12px',paddingTop: '10px',fontFamily: 'Akkurat',fontStyle:'normal',fontWeight:'400',lineHeight:'19px',width:'22%'}}>
                {getLocalizedDate(
              mess.requestTimeStamp,
              true,
              userInformation.culture,
              userInformation.mSTimeZoneID
                )}
                  
                </div>
                <div style={{fontSize:'12px',paddingTop: '10px',fontFamily: 'Akkurat',fontStyle:'normal',fontWeight:'400',lineHeight:'19px',width:'20%'}}>
                {getLocalizedDate(
              mess.lastUpdatedDate,
              true,
              userInformation.culture,
              userInformation.mSTimeZoneID
                )}
                </div>
              </div>
             
            )) }
            
        </div>
        </div>
        <br/>
        <div style={{borderTop: '1px solid var(--color-base-gray-11)'}}></div>
        <div style={{fontSize:'12px',paddingTop:'12px'}}>
          Clicking on a chat from the above list will unarchive that chat session and return it to the top of your chat history.
          <ArchivalCloseButton onClick={onClose}>Close</ArchivalCloseButton>
        </div>
      </ModalContent>
    </ModalOverlay>
    
    </>


  );
};

