
######################################################

company_description = """
<GENERAL GUIDELINES>

1. Ensure all figures are correctly attributed to the values exactly mentioned on provided data source. 
2. Analysis must rely exclusively on the data source, files provided and must not reference any external data or publicly available sources.   
3. Provide only limited major financial metrics.

</GENERAL GUIDELINES>

<CONTENT GUIDELINES>

Subsection A. Make an introducing paragraph(max 100 words) with the following content:
Focus on entity's headquarters location, presence in other locations, core business, operational scope, Core Purpose & Vision, Value Proposition and key organizational characteristics(e.g. Key Officials, number of employees, Sector, Industry), Credit Ratings.   
Overview of the company's ownership structure, group companies structure and strategy.

Subsection B. Make a set of Bullet Points (max 4-5 points, IMP: total word limit for subsection B should be upto ~ 100 words) talking about:  
1. Company's primary business activities, outlining the products and/or services it offers.
2. Business Strategies, this would focus on Target Audience, Key Differentiators, Impact & Ambition & any major Financial Metric  
3. Any significant shifts or expansions/contractions in the company's core business over the past years.

</CONTENT GUIDELINES>
"""

######################################################

# Modifications: support for "last 3 available years" | Inclusion of "period end dates" | pull line items CSD if available
key_financials = """
Provide a comprehensive summary of the entity's key financials using the available data. Include the following:

1. Income Statement Summary: Highlight revenue, EBITDA, and net profit figures for the last 3 **available** years, including the **period end date** for each year.
2. Balance Sheet Highlights: Summarize total assets, liabilities, and shareholders' equity for the same periods, including the period end dates.
3. Cash Flow Summary: Present key values from operating, investing, and financing cash flows, again including period end dates.
4. Key Financial Ratios: Include relevant financial ratios, both standard and from Credit Stats Direct (CSD) if available. These may include:
   - Liquidity: Current Ratio, Quick Ratio
   - Profitability: ROE, ROA, Net Profit Margin
   - Leverage: Debt/Equity, Interest Coverage, FFO to Debt
   - Efficiency: Asset Turnover, Inventory Turnover
   - Any other available metrics from CSD or financials section
5. generate one chart with metrics Revenue, EBITDA, Net Income, etc. on primary y-axis and Margins on secondary y-axis
"""

######################################################
sector_and_risk_analysis = """Provide a detailed analysis of the sector and industry in which the entity operates, focusing on the following:

1. Sector Overview: Describe the overall market structure, size, and growth trends of the sector.
2. Competitive Landscape: Highlight the company’s relative market position and key competitors.
3. Regulatory Environment: Outline relevant regulations, compliance requirements, or government policies affecting the sector.
4. Cyclicality & Demand Trends: Discuss whether the sector is cyclical or stable and the current demand environment.
5. Peer Comparison: Briefly compare the company’s financial or operational metrics to industry peers.

"""

######################################################
# Modifications: mention of Rating and Debt Type | Inclusion of "Last Review Date" | insights can be borrowed from Credit Companion if available
credit_ratings= """
Provide a detailed summary of the entity's credit ratings, specifically as issued by **S&P Global**. Include the following:

1. Current Credit Rating: Present the most recent S&P Global rating assigned to the company, clearly mentioning the **rating level (e.g., BBB+)**, the **type of debt or instrument rated** (e.g., senior unsecured, issuer rating), and the **last review date**.
2. Outlook: State whether the rating outlook is Stable, Positive, Negative, or Developing. Include any available S&P commentary on the outlook.
3. Rating History: Highlight any upgrades, downgrades, or affirmations in the rating over the last {n} years (or as far back as data is available).
4. Rationale Behind Ratings: Summarize the rationale provided by S&P Global for the current rating — including aspects like financial strength, market position, risk factors, and sector outlook. You may include insights from **Credit Companion**, if available via tools.

"""

######################################################
sp_current_rating = """
<GENERAL GUIDELINES>

1. Ensure all figures are correctly attributed to the values exactly mentioned on provided data source.     
2. Analysis must rely exclusively on the data source, files provided and must not reference any external data or publicly available sources.   
3. Avoid speculation or assumptions not backed by provided data source. Things like rating indicates future abc.. are strictly not allowed. If such content is present in the data source only then it can be used.
4. For any of the mentioned specific points if it doesn't have any relevant information, we can just skip it and do not say no data available
5. In case if there's no data available completely for the whole section then we show the Section Header and then we add a message "Information Not Available."
6. Exclude any data related to affiliated or related entities  

</GENERAL GUIDELINES>

<CONTENT GUIDELINES>

Content in Paragraph Format: (Table of Current Ratings, para with max 4 -5 points, max 100 words):
1. Provide the current latest ratings of the entity by S&P Ratings, Moody's, Fitch, along with the credit rating date, last review date in table format with following columns:
   a) Rating Agency 
   b) Rating Type Debt Type | Current Rating 
   c) Rating Date / Last Review Date*
   d) CreditWatch/Outlook 
   e) CreditWatch/Outlook Date 
2. Prioritize long-term current ratings over short-term ratings when both are available. Here it means don't even show the lower priority rows if the higher priority one is available for that agency. And make only 1 row for each agency. If there's no data available for a specific agency, then we just skip that agency and do not show it in the table.
3. Present a concise summary that includes any latest relevant rating action rationale, internal qualitative research, expert commentary, financial metrics, rating trends, or regional reports. 
4. The summary must be placed below the table and be specifically related to credit rating changes with the mentioning of Respective Rating Agency. If there's no data from a particular agency, then do not talk about it in the summary. Avoid speculation or assumptions not backed by provided data source. Things like this rating indicates future abc.. are strictly not allowed. If such content is present in the data source, then it can be used.

</CONTENT GUIDELINES>
"""

######################################################
# Modifications: commentary should only be provided for the most recent rating action | include ratings from the last 5 years up to the most recent change, not the full history
sp_ratings_history = """
Present a historical summary of the entity’s credit ratings as assigned by **S&P Global**, focusing on the **last 5 years up to the most recent rating change**. Include the following:

1. Timeline of Rating Actions: Provide a chronological list of rating events (e.g., upgrades, downgrades, affirmations) within this 5-year window.
2. Rating Levels & Outlooks: For each event, include the assigned rating level (e.g., BBB+) and the associated outlook (e.g., Stable, Negative).
3. Commentary or Rationale: **Only include the rationale or commentary for the most recent rating action** — summarize the stated reason or context behind the latest change if available.

"""

######################################################
# Modifications: Use only the raw data retrieved from the available APIs
credit_outlook = """
Provide a forward-looking credit outlook for the entity using **only the raw data retrieved from the available APIs**. Your task is to rephrase or summarize that content into a clear, structured narrative without generating any new insights or assumptions.

Focus on:
1. Near-Term Credit Trends: Rephrase what the API states regarding short-term changes in the credit profile.
2. Drivers of Outlook: Summarize factors affecting the outlook such as leverage, liquidity, earnings visibility, or refinancing risks — only if explicitly stated in the API response.
3. Rating Triggers: List only those triggers that are clearly mentioned in the API content.
4. Agency Commentary: Include excerpts from credit rating agencies (like S&P Global) only if provided via API.

"""

######################################################
analyst_peers = """
Provide a peer comparison for the entity by rephrasing the content into a clean and structured narrative. Do not generate or interpret data beyond what is provided.

Focus on:
1. Comparable Peers: Rephrase the list of peer companies in the same sector or industry as provided by the API.
2. Financial Comparison: Use only API data to summarize key financial metrics such as revenue, EBITDA, net profit, and leverage ratios across peers.
3. Market Positioning: Reword available API information regarding the entity’s relative position in terms of size, market share, or credit profile.
4. Analyst Commentary: Include analyst insights only if they are directly available in the API output.

"""

######################################################
news_key_developments = """
Summarize the most relevant and recent news or key developments related to the company. Focus on:

1. Significant Events: Highlight major announcements such as mergers, acquisitions, management changes, or regulatory actions.
2. Financial Developments: Include any recent earnings releases, capital raises, or credit-related events.
3. Strategic Moves: Mention expansions, new product launches, partnerships, or divestitures.
4. Market Impact: If available, note how these developments have affected the company's stock price, investor sentiment, or credit outlook.

**Ensure all news items are pulled strictly from available tool data and are time-stamped (e.g., last 6–12 months).**  
Do not create or assume events — if no relevant news is found, clearly state that no significant developments are available.
"""
#######################################################
swot_analysis = """
<GENERAL GUIDELINES>

1. Provide a TABLE for the content with the heading "Strengths Vs Risks". It should have 2 columns Strengths (Strengths + Opportunities) and Risks (Risks + Threats).
2. IMPORTANT: Avoid use of ratings values or outlook values into the content.
3. IMPORTANT: Always end with the table and do not add any additional content/paragraph etc after the table.
4. Ensure all figures are correctly attributed to the values exactly mentioned on provided data source.     
5. Analysis must rely exclusively on the data source, files provided and must not reference any external data or publicly available sources.       
6. Provide only limited major financial metrics.
7. Make sure to integrate any relevant internal qualitative research, expert commentary, or regional reports from the provided data source. 
8. Provide appropriate reasoning for each trend or a change, based on the appropriate relevant content from the provided data source.    
9. Consider Past 3 years of Historic Financials data where required.
10. For any of the mentioned specific points if it doesn't have any relevant information, we can just skip it and do not say no data available.
11. In case if there's no data available completely for the whole section then we show the Section Header and then we add a message "Information Not Available."
12. Each section must present its content in 3 to 5 concise, major impactful bullet points, with each point on a new line and not as a continuous paragraph. 

</GENERAL GUIDELINES>

<CONTENT GUIDELINES>

Column A: Strengths (Internal Factors Benefiting Credit Risk Management) (2 to 3 Points): 

1. Identify internal capabilities that reduce the likelihood of default, enhance liquidity, or improve funding access, major impactful internal capabilities, operational efficiencies, or strategic advantages. 
2. Include competitive advantages (MOATs), this would be based on non-financial factors like strong brand reputation, superior management, or unique operational processes that enhance financial stability or reduce credit risk, and other key internal strengths that positively influence our credit rating or the risk profile of our financial instruments.  
3. For each strength, explain in 1 or 2 sentences its qualitative credit risk relevance and direct positive impact on financial stability/creditworthiness, incorporating any relevant numbers .
      e.g. "Experienced management team (average 15 years tenure) enhancing strategic stability," "Strong brand loyalty (90% customer retention) reducing churn risk," "Efficient operational processes ensuring consistent cash flow generation " 

4. Cite any governance or operational structures that improve strategic stability, cash flow consistency, or debt service coverage. 
5. For each strength, describe how it enhances financial resilience, access to capital, or reduces credit spread risk. 

Column B: Opportunities (External Factors to Leverage for Credit Risk Improvement) (2 to 3 Points):

1. Focus on market, regulatory, or macroeconomic trends that could enhance liquidity, reduce earnings risk, or strengthen credit metrics. If possible, compare it with the entity’s sector with respect to how that sector is moving and how much the entity is aligned to it. 
2. Include potential market expansions, new partnerships, or technological enablers that improve risk monitoring or reduce portfolio volatility. 
3. For each opportunity, describe in 1 to 2 sentences how it can improve the company’s credit profile through stronger margins, broader revenue base, or enhanced risk management systems.  
4. Include metrics if available & Quantify when possible and necessary. 


Column C: Risks (Internal Factors Amplifying Credit Risk Exposure) (2 to 3 Points):

1. Identify impactful internal limitations, deficiencies in governance, or operational disadvantages.
2. Highlight key areas that reduce the company’s financial flexibility and/or credit rating/Outlook. 
3. Clarify how each weakness could negatively influence brand reputation, liquidity, solvency, credit ranking or access to debt markets. 
4. For each weakness, explain in 1 or 2 sentences how it introduces credit negative conditions, such as increased default risk, cash flow volatility, or weakened covenant compliance.  
5. Include metrics if available & Quantify when possible and necessary. 

Column D: Threats (External Factors Posing Credit Risk Challenges) (2 to 3 Points):

1. Highlight macro, geopolitical, technological, or competitive pressures that could deteriorate credit metrics. 
2. Include threats that may impact brand value, cost of capital, erode margins, or increase volatility in earnings/cash flows or any such relevance. 
3. For each threat, describe in 1 or 2 sentences the magnitude of potential impact, and whether it could lead to rating/outlook downgrades, loss of investor confidence, or financing difficulties or any such relevant items.  
4. Include metrics if available & Quantify when possible and necessary. 

</CONTENT GUIDELINES>
"""

#######################################################
moody_fitch_analysis = """
1. For each provider (Moody's and Fitch), make a separate section with the provider's name as the title.
2. Present the entity’s credit ratings as assigned by the provider, focusing on the **last 5 years up to the most recent rating change**. 
"""
