import logging
import openpyxl

from os import PathLike

from src.synthia.excel_prop_data.extraction.enhancer import enhance
from src.synthia.excel_prop_data.extraction.reformatter import reformat
from typing import IO

logger = logging.getLogger(__name__)

def extract(
        config: dict,
        file_handle: str | PathLike[str] | IO[bytes],
        sheet_name: str | None = None
    ) -> list[dict]:
    """
    Extracts Excel cells based on a predetermined configuration from a spreadsheet file to a JSON entity.
    :param config: extract configuration
    :param file_handle: excel file path or file-like object open in binary mode
    :param sheet_name: excel sheet name, leave blank to extract all sheets
    :return: list of extracted Excel tables in JSON
    """
    # read_only=True to not trigger data download, data_only=True to get last saved data
    workbook = openpyxl.load_workbook(file_handle, data_only=True, read_only=True)
    logger.info(f"workbook loaded successfully with sheets")

    extracted = []
    for workbook_sheet_name in workbook.sheetnames:
        # optional filter of a single sheet based on sheet_name
        if sheet_name is not None and sheet_name != workbook_sheet_name:
            continue

        sheet = workbook[workbook_sheet_name]

        # it is possible we do not have a config for a given sheet, in that case we ignore that sheet
        sheet_config = config['sheets'].get(workbook_sheet_name)
        if not sheet_config:
            continue

        extracted.append({
            "sheet_name": workbook_sheet_name,
            'tables': _extract_all_configured_tables_with_metadata(sheet, sheet_config)
        })

    return extracted


def _extract_all_configured_tables_with_metadata(sheet, sheet_config):
    return [_extract_table_with_metadata(sheet, table_config) for table_config in sheet_config['tables']]


def _extract_table_with_metadata(sheet, table_config):
    metrics = [[_extract_cell_value(cell) for cell in row] for row in sheet[table_config['range']]]

    table = {
        'table_name': table_config['name'],
        'metrics': metrics
    }

    if 'unit' in table_config:
        table['unit'] = sheet[table_config['unit']].value

    return table


def _extract_cell_value(cell):
    return enhance(reformat(cell.value, cell.number_format))