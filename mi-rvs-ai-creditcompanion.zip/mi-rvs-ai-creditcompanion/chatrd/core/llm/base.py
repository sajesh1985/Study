from abc import ABC, abstractmethod
from typing import Any


class LLM(ABC):
    @abstractmethod
    def invoke(self, inputs: Any):
        pass

    @abstractmethod
    def stream(self, inputs: Any):
        pass
