from abc import ABC, abstractmethod


class BaseAnalyzer(ABC):
    """Base Query Analyzer Class, define aseparate subclass per each use case"""

    @abstractmethod
    def analyze(self):
        """Analyzes user query, outputs applicable filters"""
        pass
