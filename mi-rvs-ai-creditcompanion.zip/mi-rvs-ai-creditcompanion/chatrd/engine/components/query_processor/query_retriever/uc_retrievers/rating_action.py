import logging
from copy import deepcopy
from typing import Dict, List, Union

from botocore.client import BaseClient
from pydantic import BaseModel

from chatrd.core.document import Document, TableDocument
from chatrd.core.llm import LCLLMFactory
from chatrd.core.vectorstore import OpenSearch
from chatrd.engine.components.query_analyzer.entity_extractor.utils import (
    Companies,
    Entities,
    RevenueSource,
)
from chatrd.engine.components.query_processor.query_retriever.data_service_retriever import (
    call_data_service,
)
from chatrd.engine.components.query_processor.query_retriever.reranker import (
    get_reranked_documents,
)
from chatrd.engine.components.query_processor.query_retriever.uc_retrievers.base import (
    UCRetriever,
)
from chatrd.engine.components.query_processor.query_retriever.uc_retrievers.utils import (
    RetrieverModel,
)
from chatrd.engine.components.query_processor.query_retriever.utils import (
    add_structured_source,
    add_unstructured_source,
    get_filters_for_research,
    post_process_retrieved_docs,
)
from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.responses import get_default_answer

logger = logging.getLogger(__name__)

config_machinery = get_config_machinery()


class RatingActionRetriever(UCRetriever):
    def __init__(self, vector_stores_dict: Dict[str, OpenSearch], reranker_client: BaseClient):
        self.vector_stores_dict = vector_stores_dict
        self.top_k_text_research = config_machinery.get_config_value(Constants.GeneralConstants.TOP_K_TEXT_RESEARCH)
        self.top_k_text_research_rerank = config_machinery.get_config_value(
            Constants.GeneralConstants.TOP_K_TEXT_RESEARCH_RERANK
        )
        self.reranker_client = reranker_client
        self.reranker_endpoint_name = config_machinery.get_config_value(
            Constants.SageMaker.SAGEMAKER_RERANKER_ENDPOINT_NAME
        )

    def retrieve(
        self,
        query: str,
        entities: Entities,
        model_name_for_tool_classifier: str,
        temperature_for_tool_classfifer: float,
        model_name_for_data_service: str,
        temperature_for_data_service: float,
        sectors: BaseModel,
        original_language: str,
        original_query: str,
        multi_uc_type: bool = False,
    ):

        vector_db_retrieved_documents, data_service_documents = [], []
        all_entities = entities.companies + entities.revenue_sources

        if entities.companies or entities.revenue_sources:
            data_service_documents = call_data_service(
                query=query,
                model_name_for_data_service=model_name_for_data_service,
                entities=entities,
                uc_type="rating_action",
                sectors=sectors,
                original_language=original_language,
                original_query=original_query,
                multi_uc_type=multi_uc_type,
            )

        is_table_present = any([isinstance(document, TableDocument) for document in data_service_documents])

        if (data_service_documents) and (not is_table_present):
            return [
                Document(
                    content=data_service_documents[0].content,
                    synthesize=False,
                )
            ]

        # Temporary approach for multi-entity rating action
        if not is_table_present:
            return [
                Document(
                    content="No rating action data is available for the provided action type.",
                    synthesize=False,
                )
            ]

        index = 0
        if (not multi_uc_type) and (len(all_entities) == 1):
            index = 1

        if len(all_entities) > 1:
            entity_date_map = {}

            for row in data_service_documents[index].content.rows:
                entity_name = row.get("Entity")
                entity_object = [entity for entity in all_entities if entity.name == entity_name][0]
                if entity_object not in entity_date_map:
                    entity_date_map[entity_object] = row.get("Action Date")

            for entity, date in entity_date_map.items():
                retrieved_documents = self.vector_db_retrieval(
                    query=query, entity=entity, uc_type="rating_action", date=date, original_language=original_language
                )
                vector_db_retrieved_documents.extend(retrieved_documents)

        else:
            date_extracted_from_table = data_service_documents[index].content[1][0]["Action Date"]
            entity = all_entities[0]

            retrieved_documents = self.vector_db_retrieval(
                query=query,
                entity=entity,
                uc_type="rating_action",
                date=date_extracted_from_table,
                original_language=original_language,
            )
            vector_db_retrieved_documents.extend(retrieved_documents)

        data_service_documents_2 = []
        if multi_uc_type or (len(all_entities) > 1):
            for doc in data_service_documents:
                if isinstance(doc, TableDocument) and len(data_service_documents_2) == 0:
                    new_doc = deepcopy(doc)
                    new_doc.synthesize = True
                    data_service_documents_2.append(new_doc)

            if data_service_documents_2:
                data_service_documents = data_service_documents_2

        data_service_documents = add_structured_source(data_service_documents)
        vector_db_retrieved_documents = add_unstructured_source(vector_db_retrieved_documents)
        query_documents = self._combine_documents(
            structured_documents=data_service_documents, unstructured_documents=vector_db_retrieved_documents
        )
        logger.info(f"Total number of retrieved documents : {len(query_documents)}")

        return query_documents

    def vector_db_retrieval(
        self, query: str, entity: Union[Companies, RevenueSource], uc_type: str, date: str, original_language: str
    ):
        query = self.rephrased_query(query, entity)

        filters, relevant_article_ids = get_filters_for_research(  # year = None, date=APIresponse
            vector_stores_dict=self.vector_stores_dict, entity=entity, date=date, uc_type=uc_type
        )

        if not relevant_article_ids:
            return get_default_answer(
                entity=entity, reason="no_relevant_articles", original_language=original_language, query=query
            )

        logger.info(f"filter applied for research docs : {filters}")
        retrieved_documents, scores = self.vector_stores_dict["research"].get_relevant_documents(
            query,
            efficient_filter=filters,
            model_id=config_machinery.get_config_value(Constants.OpenSearch.NEURAL_SEARCH_MODEL_ID),
            search_pipeline=config_machinery.get_config_value(Constants.OpenSearch.HYBRID_SEARCH_SEARCH_PIPELINE_ID),
            top_k_text_chunks=self.top_k_text_research,
        )

        retrieved_documents = get_reranked_documents(
            query=query,
            retrieved_documents=retrieved_documents,
            entity=entity,
            reranker_client=self.reranker_client,
            reranker_endpoint_name=self.reranker_endpoint_name,
            reranker_threshold=(
                None
                if isinstance(entity, RevenueSource)
                else config_machinery.get_config_value(Constants.GeneralConstants.DEFAULT_RERANKER_THRESHOLD)
            ),
            top_k_text_chunks=self.top_k_text_research_rerank,
        )
        retrieved_documents = post_process_retrieved_docs(retrieved_documents)
        retrieved_documents = self.add_additional_metadata_to_documents(
            uc_type=uc_type, user_query=query, entity=entity, documents=retrieved_documents
        )

        if not retrieved_documents:
            return get_default_answer(
                entity=entity, reason="no_relevant_articles", original_language=original_language, query=query
            )

        entity_name = retrieved_documents[0].metadata.get("aggLegalEntityName", "").partition(";")[0].strip()
        vector_db_retrieved_documents = []
        vector_db_retrieved_documents.append(
            Document(
                content=(f"<{entity_name}>"),
            ),
        )
        vector_db_retrieved_documents.extend(retrieved_documents)
        vector_db_retrieved_documents.append(
            Document(
                content=(f"</{entity_name}>"),
            ),
        )
        return vector_db_retrieved_documents

    def _combine_documents(
        self, structured_documents: Union[Document, TableDocument], unstructured_documents: List[Document]
    ) -> Union[List[Document], TableDocument]:
        if structured_documents and unstructured_documents:
            combined_result_document = []
            combined_result_document.extend(structured_documents)
            combined_result_document.extend(unstructured_documents)
            return combined_result_document
        elif structured_documents:
            return structured_documents
        elif unstructured_documents:
            return unstructured_documents
        else:
            return []
