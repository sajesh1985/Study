﻿if (typeof Sys !== "undefined" && Sys) {
    Type.registerNamespace("Fis.Epp.EPaymentsUI.Integration");
    Fis.Epp.EPaymentsUI.Integration.isMicrosoftAjaxLoaded = true;
}
else {
    Function.createDelegate = function (instance, method) {
        return function () {
            return method.apply(instance, arguments);
        }
    };
    Type = (typeof Type == "undefined" || !Type) ? {} : Type;
    Type.registerNamespace = function (namespace) {
        var parts = namespace.split(".");
        var root = window;
        for (var i = 0; i < parts.length; i++) {
            if (typeof (root[parts[i]]) == "undefined") {
                root[parts[i]] = {};
            }
            root = root[parts[i]];
        }
        return root;
    };
    Type.registerNamespace("Fis.Epp.EPaymentsUI.Integration");
    Fis.Epp.EPaymentsUI.Integration.isMicrosoftAjaxLoaded = false;
}