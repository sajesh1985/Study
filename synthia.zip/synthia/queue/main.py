import sys
import asyncio
import signal
import os
from src.synthia.persistence.database_manager import (
    initialize_connection_pool,
    close_connection_pool,
)
import logging
from contextlib import asynccontextmanager, suppress
from src.synthia.queue.queue_consumer import ReportQueueConsumer
from src.synthia.user_profile.user_profile_provider import close_http_client

logger = logging.getLogger(__name__)

class GracefulShutdown:
    def __init__(self, loop: asyncio.AbstractEventLoop | None = None):
        self.loop = loop
        self.shutdown_event = asyncio.Event()
        self.is_shutting_down = False
        self.shutdown_signal = None

    def _on_signal(self, signame: str):
        if not self.is_shutting_down:
            self.is_shutting_down = True
            self.shutdown_signal = signame
            logger.info(f"Received {signame}, initiating graceful shutdown...")
            self.shutdown_event.set()

    def setup_signal_handlers(self):
        # Prefer asyncio-native signal handlers on POSIX (ECS), fallback to signal.signal elsewhere.
        try:
            loop = self.loop or asyncio.get_running_loop()
            if hasattr(loop, "add_signal_handler") and sys.platform != "win32":
                loop.add_signal_handler(signal.SIGTERM, self._on_signal, "SIGTERM")# ECS sends this
                loop.add_signal_handler(signal.SIGINT, self._on_signal, "SIGINT")# Ctrl+C for local testing
            else:
                signal.signal(signal.SIGTERM, lambda s, f: self._on_signal("SIGTERM")) 
                signal.signal(signal.SIGINT, lambda s, f: self._on_signal("SIGINT"))
        except Exception as e:
            logger.warning(f"Failed to set signal handlers: {e}")

    def request_shutdown(self, reason: str = ""):
        if not self.is_shutting_down:
            self.is_shutting_down = True
            if reason:
                logger.info(f"Initiating graceful shutdown... {reason}")
            else:
                logger.info("Initiating graceful shutdown...")
            self.shutdown_event.set()

    async def wait_for_shutdown(self):
        await self.shutdown_event.wait()


@asynccontextmanager
async def app_lifespan():
    logger.info("Initializing Database connection pool...")
    await initialize_connection_pool()
    logger.info("Database Connection pool initialized successfully")
    try:
        yield
    finally:
        logger.info("Closing Database connection pool...")
        await close_connection_pool()
        logger.info("Database Connection pool closed successfully")
        await close_http_client()
        logger.info("HTTPx Connection pool closed successfully")


async def _main() -> int:
    async with app_lifespan():
        loop = asyncio.get_running_loop()
        consumer = ReportQueueConsumer()
        shutdown_manager = GracefulShutdown(loop)
        shutdown_manager.setup_signal_handlers()

        # Run consumer and shutdown waiter; react to whichever completes first.
        consumer_task = asyncio.create_task(consumer.run_forever(), name="consumer.run_forever")
        shutdown_task = asyncio.create_task(shutdown_manager.wait_for_shutdown(), name="shutdown.wait")

        done, _ = await asyncio.wait({consumer_task, shutdown_task}, return_when=asyncio.FIRST_COMPLETED)

        exit_code = 0
        if shutdown_task in done:
            logger.info("Shutdown signal received, stopping consumer...")
            # Set exit code 143 for SIGTERM (standard Docker/ECS termination)
            if shutdown_manager.shutdown_signal == "SIGTERM":
                exit_code = 143
        else:
            # Consumer finished first (could be normal or due to an error).
            logger.error("Consumer task finished unexpectedly; triggering shutdown.")
            shutdown_manager.request_shutdown("consumer task finished")
            # Log exception, if any.
            if consumer_task.done() and not consumer_task.cancelled():
                exc = consumer_task.exception()
                if exc:
                    logger.exception("Consumer task raised an exception", exc_info=exc)
                    exit_code = 1

        # Attempt graceful stop with bounded timeout (default 25s for ECS before SIGKILL).
        shutdown_timeout = 25 #float(os.getenv("SHUTDOWN_TIMEOUT", "25"))
        try:
            await asyncio.wait_for(consumer.stop(), timeout=shutdown_timeout)
        except asyncio.TimeoutError:
            logger.error(f"Timed out after {shutdown_timeout}s while stopping consumer; cancelling task.")
        except Exception as e:
            logger.error(f"Error during consumer.stop(): {e}")

        # After requesting stop, give the consumer task a chance to finish before force-cancelling.
        if not consumer_task.done():
            try:
                await asyncio.wait_for(consumer_task, timeout=shutdown_timeout)
            except asyncio.TimeoutError:
                logger.error("Timed out waiting for consumer task to finish; cancelling task.")
                consumer_task.cancel()
                with suppress(asyncio.CancelledError):
                    await consumer_task

        # If the consumer task ended with an exception during shutdown, log it and set exit code.
        if consumer_task.done() and not consumer_task.cancelled():
            exc = consumer_task.exception()
            if exc:
                logger.exception("Consumer task raised an exception during shutdown", exc_info=exc)
                exit_code = 1

        # Ensure shutdown waiter is cleaned up.
        if not shutdown_task.done():
            shutdown_task.cancel()
            with suppress(asyncio.CancelledError):
                await shutdown_task

        return exit_code


if __name__ == "__main__":
    if sys.platform == "win32":
        logger.info("Setting WindowsSelectorEventLoopPolicy for Windows platform.")
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

    exit_code = 0 #clean shutdown
    try:
        exit_code = asyncio.run(_main())
    except KeyboardInterrupt:
        logger.info("Application interrupted")
        exit_code = 130 #Interrupted by signal (Ctrl+C/SIGINT)
    except Exception as e:
        logger.error(f"Application failed: {e}", exc_info=True)
        exit_code = 1 #General error
    sys.exit(exit_code) #ECS to handle based on exit code
