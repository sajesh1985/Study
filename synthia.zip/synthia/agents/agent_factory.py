import asyncio
import logging
import os
from typing import Any, Dict, List, Optional, Union

from langchain.callbacks.base import AsyncCallbackHandler
from langgraph.prebuilt import create_react_agent
from langchain_core.language_models import BaseChatModel, BaseLLM

from src.synthia.config.llm_config import LLMType, get_llm
from src.synthia.mcp_client.mcp_client_async import create_mcp_client
from src.synthia.prompts.system_prompts import (
    section_system_prompt,
    synthesizer_system_prompt,
)
from src.synthia.prompts.utils import SectionTitle
from src.synthia.utils.logging_config import configure_logging


class AgentCallbackHandler(AsyncCallbackHandler):
    """Handler for tool execution callbacks"""

    def __init__(self):
        super().__init__()
        self.logger = configure_logging(
            log_file="synthia.log", module_levels={__name__: logging.DEBUG}
        )

    async def on_tool_start(
        self, serialized: Dict[str, Any], input_str: str, **kwargs
    ) -> None:
        tool_name = serialized.get("name", "Unknown")
        self.logger.debug(f"\n\n Using tool: {tool_name} \n      Input: {input_str}")

    async def on_tool_end(self, output: str, **kwargs) -> None:
        if hasattr(output, "content"):
            output_str = str(output.content)
        else:
            output_str = str(output)
        self.logger.debug(f"  Tool Output: {output_str[1:100]}\n")

    async def on_tool_error(self, error: Exception, **kwargs) -> None:
        self.logger.error(f"Tool Error: {error}\n")

    async def on_llm_error(self, error: Exception, **kwargs) -> None:
        self.logger.error(f"LLM Error: {error}\n")

    async def on_retriever_error(self, error: Exception, **kwargs) -> None:
        self.logger.error(f"Retriever Error: {error}\n")


class AgentFactory:
    """Factory for creating different types of agents."""

    def __init__(
        self,
        auth_token: str,
        callbacks: Optional[List[Any]] = None,
        mlflow_enabled: bool = False,
    ):
        self.llm = get_llm(temperature=0.2, streaming=False, callbacks=callbacks)
        self.llm_claude3_5 = get_llm(
            temperature=0.2,
            streaming=False,
            callbacks=callbacks,
            llm_type=LLMType.CLAUDE_3_5,
        )
        self.llm_claude3_7 = get_llm(
            temperature=0.2,
            streaming=False,
            callbacks=callbacks,
            llm_type=LLMType.CLAUDE_3_7,
        )
        self.llm_claude4 = get_llm(
            temperature=0.2,
            streaming=False,
            callbacks=callbacks,
            llm_type=LLMType.CLAUDE_4,
        )
        self.llm_claude3_5_cached = get_llm(
            temperature=0.2,
            streaming=False,
            callbacks=callbacks,
            llm_type=LLMType.CLAUDE_3_5,
            use_llm_cache=True,
        )
        self.llm_claude3_7_cached = get_llm(
            temperature=0.2,
            streaming=False,
            callbacks=callbacks,
            llm_type=LLMType.CLAUDE_3_7,
            use_llm_cache=True,
        )
        self.llm_claude4_cached = get_llm(
            temperature=0.2,
            streaming=False,
            callbacks=callbacks,
            llm_type=LLMType.CLAUDE_4,
            use_llm_cache=True,
        )
        self.auth_token = auth_token
        self._all_tools = None
        self.callbacks = callbacks or []
        self.callbacks.append(AgentCallbackHandler())
        self.debug = False
        self._tools_lock = asyncio.Lock()
        self.mlflow_enabled = mlflow_enabled
        self.logger = configure_logging(
            log_file="synthia.log", module_levels={__name__: logging.DEBUG}
        )

        if self.mlflow_enabled:
            try:
                import mlflow
                import mlflow.langchain

                mlflow.langchain.autolog()
                mlflow.set_tracking_uri("http://localhost:5000")
                mlflow.set_experiment("Synthia")
            except ImportError:
                print(
                    "Warning: MLflow is not installed. Proceeding without MLflow logging."
                )
            except Exception as e:
                print(f"Warning: MLflow setup failed: {e}")

    async def _get_tools(self):
        if self._all_tools is None:
            async with self._tools_lock:
                if self._all_tools is None:
                    client = await create_mcp_client(self.auth_token)
                    self._all_tools = await client.get_tools() or []
        return self._all_tools

    async def _create_agent(self, name: str = "report_agent"):
        tools = await self._get_tools()
        return create_react_agent(
            self.llm,
            tools,
            name=name,
            debug=self.debug,
        )

    async def _get_report_synthesizer_agent(self, name: str = "synthesizer_agent"):
        return create_react_agent(
            self.llm_claude3_7,
            tools=[],
            name=name,
            debug=self.debug,
            prompt=synthesizer_system_prompt,
        )

    async def _get_section_agent(self, report_template: str, section_name: str):
        import re

        from src.synthia.utils.template_util import get_tools_for_subsection_title

        def sanitize(name: str) -> str:
            return re.sub(r"[^a-zA-Z0-9_-]", "_", name)

        def select_llm_for_section(
            section_title: SectionTitle,
        ) -> Union[BaseLLM, BaseChatModel]:
            """Selects the appropriate LLM based on the section title."""
            # Check if caching is enabled
            if os.getenv("ENABLE_CACHE", "false").lower() in ("false", "0", "no"):
                self.logger.info("LLM caching is disabled. Using uncached LLM.")
                return self.llm_claude3_7
            # Use cached LLM for specific sections
            if section_title in [
                SectionTitle.COMPANY_DESCRIPTION,
                SectionTitle.KEY_FINANCIALS,
                SectionTitle.SECTOR_RISK_ANALYSIS,
                SectionTitle.NEWS_KEY_DEVELOPMENTS,
                SectionTitle.SWOT_ANALYSIS,
                SectionTitle.GEOGRAPHIC_MIX,
                SectionTitle.SEGMENT_MIX,
                SectionTitle.SHAREPRICE,
                SectionTitle.SUMMARY_ANALYSIS,
            ]:
                self.logger.info(f"Using cached LLM for section: {section_title.value}")
                return self.llm_claude3_7_cached
            self.logger.info(f"Using uncached LLM for section: {section_title.value}")
            return self.llm_claude3_7

        tool_names = set(
            get_tools_for_subsection_title(f"{report_template}.json", section_name)
        )
        all_tools = await self._get_tools()
        agent_name = f"{sanitize(report_template)[:4]}_{sanitize(section_name)}"[:30]
        if not tool_names:
            return None
        filtered_tools = [tool for tool in all_tools if tool.name in tool_names]
        if not filtered_tools:
            return None

        llm = select_llm_for_section(SectionTitle(section_name))
        # Use ReportSection schema for response_format
        return create_react_agent(
            llm,
            filtered_tools,
            name=f"{agent_name}_agent",
            debug=self.debug,
            prompt=section_system_prompt,
        )

    async def _get_outline_agent(self):
        tools = await self._get_tools()
        from src.synthia.schemas.sections import Section  # ensure correct import

        return create_react_agent(
            self.llm,
            tools,
            response_format=Section,  # Use Section, not List[Section]
            name="outline_agent",
            debug=self.debug,
            prompt=section_system_prompt,
        )

    async def get_agent(
        self,
        agent_type: str = "default",
        report_template: Optional[str] = None,
        section_name: Optional[str] = None,
    ):
        if agent_type == "report" or agent_type == "default" or agent_type == "custom":
            return await self._create_agent(name="agent")
        elif agent_type == "outline":
            return await self._get_outline_agent()
        elif agent_type == "synthesizer":
            return await self._get_report_synthesizer_agent(name="synthesizer_agent")
        elif agent_type == "section":
            if not report_template or not section_name:
                return await self._create_agent(name="agent")
            return await self._get_section_agent(report_template, section_name)
        else:
            raise ValueError(f"Unknown agent_type: {agent_type}")
