﻿using Fis.Epp.Fusion.Auth.Common;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using NLog.Extensions.Logging;
using System.IO;

namespace Fis.Epp.Fusion.Auth
{
    public class Startup
    {
        private readonly IConfiguration _configuration;

        public Startup(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddScoped<ValidateSessionTokenAttribute>();
            services.AddMvc();

            services.AddTransient<WSO2AccessHandler>();
            services.AddTransient<RESTAccessHandler>();

            services.AddTransient<IStartupFilter, SettingValidationStartupFilter>();
            services.AddTransient<IServiceCollection, ServiceCollection>();

            // Bind the configuration using IOptions
            services.Configure<AppConfiguration>(_configuration.GetSection("AppConfiguration"));

            // Explicitly register the settings object so IOptions not required (optional)
            services.AddSingleton(resolver =>
                resolver.GetRequiredService<IOptions<AppConfiguration>>().Value);

            // Register as an IValidatable
            services.AddSingleton<IValidatable>(resolver =>
                 resolver.GetRequiredService<IOptions<AppConfiguration>>().Value);


            services.AddCorsPolicy();
            services.AddHealthChecks();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILoggerFactory loggerFactory)
        {
            if (env.EnvironmentName == "Development")
            {
                app.UseDeveloperExceptionPage();
            }
            // Configured nlog.
            loggerFactory.AddNLog();
            loggerFactory.ConfigureNLog("nlog.config");
            app.UseStaticFiles();
            // Added middleware to handle exception.
            app.UseMiddleware(typeof(ExceptionHandlingMiddleware));
            // Added middleware for Content security policy.
            app.UseCustomHeaderConfigMiddleware();

            app.Use(async (context, next) =>
            {
                await next();
                if (context.Response.StatusCode == 404 && !Path.HasExtension(context.Request.Path.Value))
                {
                    context.Request.Path = "/error/404";
                    await next();
                }
            });

            app.UseRouting();
            app.UseCorsPolicy();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute("default", "{controller=UIHosting}/{action=Index}/{id?}");
            });
            app.UseHealthChecks("/health");
        }
    }
}
