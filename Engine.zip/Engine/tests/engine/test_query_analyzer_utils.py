# tests/test_query_analyzer_utils.py

import pytest

from chatrd.engine.components.query_analyzer.utils import UCType


class TestUCType:
    def test_uctype_values(self):
        """Test that all UCType enum values are correctly defined"""
        # Test each enum value individually
        assert UCType.CRITERIA.value == "criteria"
        assert UCType.RESEARCH.value == "research"
        assert UCType.ESG.value == "esg"
        assert UCType.RATINGS.value == "ratings"
        assert UCType.OUTLOOK.value == "outlook"
        assert UCType.PEERS.value == "peers"
        assert UCType.DEFINITION.value == "definition"
        assert UCType.FINANCIALS.value == "financials"
        assert UCType.SWOT.value == "sNw"
        assert UCType.SECURITIES.value == "securities"
        assert UCType.QUERY.value == "query"
        assert UCType.CREDIT_MEMO.value == "credit_memo"
        assert UCType.GENERAL.value == "general"
        assert UCType.MACRO.value == "macro"
        assert UCType.DEALS_TRANCHE.value == "deals_tranche"
        assert UCType.RATING_ACTION.value == "rating_action"
        assert UCType.SELECTED_ARTICLE.value == "selected_article"
        assert UCType.FLEX_ARCH.value == "flex_arch"

    def test_uctype_count(self):
        """Test that the UCType enum has the expected number of values"""
        # Count the number of enum values
        assert len(list(UCType)) == 18

    def test_uctype_names(self):
        """Test that all UCType enum names are correctly defined"""
        # Get all enum names
        enum_names = [uc_type.name for uc_type in UCType]

        # Check that all expected names are present
        expected_names = [
            "CRITERIA",
            "RESEARCH",
            "ESG",
            "RATINGS",
            "OUTLOOK",
            "PEERS",
            "DEFINITION",
            "FINANCIALS",
            "SWOT",
            "SECURITIES",
            "QUERY",
            "CREDIT_MEMO",
            "GENERAL",
            "MACRO",
            "DEALS_TRANCHE",
            "RATING_ACTION",
            "SELECTED_ARTICLE",
            "FLEX_ARCH",
        ]

        for name in expected_names:
            assert name in enum_names

    def test_selected_article_uctype(self):
        """Test specifically that the SELECTED_ARTICLE type is properly defined"""
        # Check that SELECTED_ARTICLE is in the enum
        assert hasattr(UCType, "SELECTED_ARTICLE")

        # Check that its value is correct
        assert UCType.SELECTED_ARTICLE.value == "selected_article"

        # Check that it can be accessed by value
        assert UCType("selected_article") == UCType.SELECTED_ARTICLE

    def test_uctype_uniqueness(self):
        """Test that all UCType values are unique"""
        # Get all enum values
        enum_values = [uc_type.value for uc_type in UCType]

        # Check that there are no duplicates
        assert len(enum_values) == len(set(enum_values))

    def test_uctype_string_conversion(self):
        """Test that UCType values can be converted to strings"""
        # Check string representation
        assert str(UCType.SELECTED_ARTICLE) == "UCType.SELECTED_ARTICLE"

        # Check value access
        assert UCType.SELECTED_ARTICLE.value == "selected_article"
