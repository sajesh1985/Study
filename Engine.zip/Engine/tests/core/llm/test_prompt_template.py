import pytest

from chatrd.core.llm.prompt.template import LazyPromptTemplate, SimplePromptTemplate

WRONG_TYPE_TEMPLATE = 123  # Not a string type template
WRONG_TYPED_PLACEHOLDER_TEMPLATE = ("First place: {1}",)  # Wrong type of placeholder
EMPTY_TEMPLATE = ""  # Empty template
NO_PLACEHOLDER_TEMPLATE = "Hello, World!"  # No placeholders in the template
SIMPLE_TEMPLATE = "Hello, {name}!"
TEMPLATE_WITH_VARS = "Hello, {name}! You are {age} years old."
TEMPLATE_WITH_USER_VARS = "Welcome, {user}! Your role is {role}."


class TestSimplePromptTemplate(object):
    """Test cases for chatrd.core.llm.prompt.template.SimplePromptTemplate class."""

    data_for_invalid_init = [
        [WRONG_TYPE_TEMPLATE, None, TypeError],
        [WRONG_TYPED_PLACEHOLDER_TEMPLATE, None, TypeError],
        [SIMPLE_TEMPLATE, 13, TypeError],
        [SIMPLE_TEMPLATE, {1: "The One"}, TypeError],  # Wrong type of key for partial_variable
        [SIMPLE_TEMPLATE, {"age": "18"}, KeyError],  # Missing variable in template
    ]

    @pytest.mark.parametrize("template, partial_vars, error", data_for_invalid_init)
    def test_invalid_initialization(self, template, partial_vars, error):
        """Test cases for validation errors during initialization."""
        with pytest.raises(error):
            SimplePromptTemplate(template, partial_variables=partial_vars)

    data_for_valid_init = [
        [EMPTY_TEMPLATE, None, EMPTY_TEMPLATE, []],
        [NO_PLACEHOLDER_TEMPLATE, None, NO_PLACEHOLDER_TEMPLATE, []],
        [SIMPLE_TEMPLATE, None, SIMPLE_TEMPLATE, ["name"]],
        [SIMPLE_TEMPLATE, {"name": "Alice"}, "Hello, Alice!", []],
        [TEMPLATE_WITH_VARS, {"name": "Alice", "age": "30"}, "Hello, Alice! You are 30 years old.", []],
        [TEMPLATE_WITH_VARS, {"name": "Bob"}, "Hello, Bob! You are {age} years old.", ["age"]],
    ]

    @pytest.mark.parametrize("template, partial_vars, expected_template, expected_vars", data_for_valid_init)
    def test_valid_initialization(self, template, partial_vars, expected_template, expected_vars):
        prompt = SimplePromptTemplate(template, partial_variables=partial_vars)
        assert prompt.template == expected_template
        assert prompt.input_variables == expected_vars

    data_for_invalid_formatting = [
        [SIMPLE_TEMPLATE, 13, None, TypeError],  # Wrong type of variable
        [SIMPLE_TEMPLATE, {1: "The One"}, None, TypeError],  # Wrong type of key for partial_variable
        [SIMPLE_TEMPLATE, {"age": "18"}, None, KeyError],  # Missing variable in template
        [TEMPLATE_WITH_VARS, {"name": "Alice"}, True, ValueError],  # Missing variable to fill placeholder
    ]

    @pytest.mark.parametrize("template, input_kwargs, force_validation, error", data_for_invalid_formatting)
    def test_invalid_formatting(self, template, input_kwargs, force_validation, error):
        with pytest.raises(error):
            prompt = SimplePromptTemplate(template, enforce_full_replacement=force_validation)
            prompt.format(**input_kwargs)

    data_for_valid_formatting = [
        [SIMPLE_TEMPLATE, {"name": "John"}, {}, "Hello, John!"],
        [SIMPLE_TEMPLATE, {}, {"name": "John"}, "Hello, John!"],
        [TEMPLATE_WITH_USER_VARS, {"user": "John"}, {"role": "Developer"}, "Welcome, John! Your role is Developer."],
    ]

    @pytest.mark.parametrize("template, partial_vars, input_kwargs, expected_output", data_for_valid_formatting)
    def test_valid_formatting(self, template, partial_vars, input_kwargs, expected_output):
        """Test cases for valid formatting of the prompt template."""
        prompt = SimplePromptTemplate(template, partial_variables=partial_vars)
        result = prompt.format(**input_kwargs)
        assert result == expected_output

    @pytest.mark.parametrize(
        "template, partial_vars, optional_vars, expected_prompt",
        [
            (TEMPLATE_WITH_USER_VARS, {"user": "John"}, ["role"], "Welcome, John! Your role is {role}."),
            (TEMPLATE_WITH_USER_VARS, {"user": "John", "role": "Admin"}, [], "Welcome, John! Your role is Admin."),
        ],
    )
    def test_format_with_optional_variables(self, template, partial_vars, optional_vars, expected_prompt):
        """Test formatting with optional variables."""
        prompt = SimplePromptTemplate(
            template=template, partial_variables=partial_vars, optional_variables=optional_vars
        )
        result = prompt.format()
        assert result == expected_prompt

    @pytest.mark.parametrize(
        "template, expected_input_vars",
        [
            ("This a template with 2 variables: {user}, and {email}", ["user", "email"]),
            (
                "Hello, {user}! Your role is {role} at {company_name} in {city-and-country}.",
                ["user", "role", "company_name", "city-and-country"],
            ),
            ("This is a {nested {template} in a template string.", ["template"]),
        ],
    )
    def test_precise_placeholder_extraction(self, template, expected_input_vars):
        """Test precise placeholder extraction from the template."""
        prompt = SimplePromptTemplate(template)
        assert prompt.input_variables == expected_input_vars


class TestLazyPromptTemplate(object):
    """Test cases for chatrd.core.llm.prompt.helper.LazyPromptTemplate class."""

    data_for_invalid_init = [
        [WRONG_TYPE_TEMPLATE, None, TypeError],
        [WRONG_TYPED_PLACEHOLDER_TEMPLATE, None, TypeError],
        [SIMPLE_TEMPLATE, 13, TypeError],
        [SIMPLE_TEMPLATE, {1: "One"}, TypeError],  # Wrong type of key for partial_variable
        [SIMPLE_TEMPLATE, {"age": "18"}, KeyError],  # Missing variable in template
    ]

    @pytest.mark.parametrize("template, partial_vars, error", data_for_invalid_init)
    def test_invalid_initialization(self, template, partial_vars, error):
        """Test cases for validation errors during initialization."""
        with pytest.raises(error):
            LazyPromptTemplate(template, partial_variables=partial_vars)

    data_for_valid_init = [
        [EMPTY_TEMPLATE, None, "", []],
        [NO_PLACEHOLDER_TEMPLATE, None, NO_PLACEHOLDER_TEMPLATE, []],
        [SIMPLE_TEMPLATE, None, SIMPLE_TEMPLATE, ["name"]],
        [SIMPLE_TEMPLATE, {"name": "Alice"}, SIMPLE_TEMPLATE, ["name"]],
        [TEMPLATE_WITH_VARS, {"name": "Alice", "age": "30"}, TEMPLATE_WITH_VARS, ["name", "age"]],
    ]

    @pytest.mark.parametrize("template, partial_vars, expected_template, expected_vars", data_for_valid_init)
    def test_valid_initialization(self, template, partial_vars, expected_template, expected_vars):
        prompt = LazyPromptTemplate(template, partial_variables=partial_vars)
        assert prompt.template == expected_template
        assert prompt.input_variables == expected_vars

    # Resetting the partial variables in the prompt template
    def test_resetting_partial_variables(self):
        template = "Hello, {name}!"
        prompt = LazyPromptTemplate(template, partial_variables={"name": "Alice"})
        assert prompt.template_variables == {"name": "Alice"}

        prompt.reset_variables()
        assert prompt.template_variables == {}

    # Updating the partial variables in the prompt template
    test_data_for_invalid_variable_update = [
        [SIMPLE_TEMPLATE, {"name": "Alice"}, 13, TypeError],  # Wrong type of partial_variable
        [SIMPLE_TEMPLATE, {"name": "Alice"}, {"age": "21"}, KeyError],  # Missing variable in template
    ]

    @pytest.mark.parametrize("template, partial_vars, update_kwargs, error", test_data_for_invalid_variable_update)
    def test_updating_partial_variables_with_errors(self, template, partial_vars, update_kwargs, error):
        prompt = LazyPromptTemplate(template, partial_variables=partial_vars)
        with pytest.raises(error):
            prompt.update_variables(**update_kwargs)

    test_data_for_valid_variable_update = [
        [SIMPLE_TEMPLATE, {"name": "Alice"}, {}],  # Clearing partial_variables
        [SIMPLE_TEMPLATE, {"name": "Alice"}, {"name": "Bob"}],
        [TEMPLATE_WITH_VARS, {"name": "Alice", "age": "30"}, {"name": "Charlie", "age": "26"}],
    ]

    @pytest.mark.parametrize("template, partial_vars, update_kwargs", test_data_for_valid_variable_update)
    def test_updating_partial_variables(self, template, partial_vars, update_kwargs):
        prompt = LazyPromptTemplate(template, partial_variables=partial_vars)
        prompt.update_variables(**update_kwargs)

        assert prompt.template == template
        assert prompt.template_variables == update_kwargs

    # Formatting the prompt template
    data_for_invalid_formatting = [
        [SIMPLE_TEMPLATE, 13, None, TypeError],  # Wrong type of variable
        [SIMPLE_TEMPLATE, {1: "One"}, None, TypeError],  # Wrong type of key for partial_variable
        [SIMPLE_TEMPLATE, {"age": "18"}, None, KeyError],  # Missing variable in template
        [TEMPLATE_WITH_VARS, {"name": "Alice"}, True, ValueError],  # Missing variable to fill placeholder
    ]

    @pytest.mark.parametrize("template, input_kwargs, force_validation, error", data_for_invalid_formatting)
    def test_invalid_formatting(self, template, input_kwargs, force_validation, error):
        with pytest.raises(error):
            prompt = LazyPromptTemplate(template, enforce_full_replacement=force_validation)
            prompt.format(**input_kwargs)

    data_for_valid_formatting = [
        [SIMPLE_TEMPLATE, {"name": "John"}, {}, "Hello, John!"],
        [SIMPLE_TEMPLATE, {}, {"name": "John"}, "Hello, John!"],
        [TEMPLATE_WITH_USER_VARS, {"user": "John"}, {"role": "Developer"}, "Welcome, John! Your role is Developer."],
    ]

    @pytest.mark.parametrize("template, partial_vars, input_kwargs, expected_output", data_for_valid_formatting)
    def test_valid_formatting(self, template, partial_vars, input_kwargs, expected_output):
        """Test cases for valid formatting of the prompt template."""
        prompt = LazyPromptTemplate(template, partial_variables=partial_vars)
        assert prompt.template == template
        assert prompt.template_variables == partial_vars

        result = prompt.format(**input_kwargs)
        assert result == expected_output

    @pytest.mark.parametrize(
        "template, partial_vars, optional_vars, expected_prompt",
        [
            (TEMPLATE_WITH_USER_VARS, {"user": "John"}, ["role"], "Welcome, John! Your role is {role}."),
            (TEMPLATE_WITH_USER_VARS, {"user": "John", "role": "Admin"}, [], "Welcome, John! Your role is Admin."),
        ],
    )
    def test_format_with_optional_variables(self, template, partial_vars, optional_vars, expected_prompt):
        """Test formatting with optional variables."""
        prompt = LazyPromptTemplate(template=template, partial_variables=partial_vars, optional_variables=optional_vars)
        result = prompt.format()
        assert result == expected_prompt

    @pytest.mark.parametrize(
        "template, expected_input_vars",
        [
            ("This a template with 2 variables: {user}, and {email}", ["user", "email"]),
            (
                "Hello, {user}! Your role is {role} at {company_name} in {city-and-country}.",
                ["user", "role", "company_name", "city-and-country"],
            ),
            ("This is a {nested {template} in a template string.", ["template"]),
        ],
    )
    def test_precise_placeholder_extraction(self, template, expected_input_vars):
        """Test precise placeholder extraction from the template."""
        prompt = LazyPromptTemplate(template)
        assert prompt.input_variables == expected_input_vars
