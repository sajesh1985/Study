from chatrd.engine.components.query_analyzer.entity_extractor.utils import (
    ExtractedEntities,
    ExtractedSecurities,
    extract_cusip,
    extract_isin,
    find_closest_string_index,
    post_process,
)


def test_extract_cusip():
    # one ID
    string = "what is the rating of 012345678?"
    expected = ["012345678"]
    assert extract_cusip(string) == expected

    string = "what is the rating of Q8773@AH1?"
    expected = ["Q8773@AH1"]
    assert extract_cusip(string) == expected

    string = "what is the rating of q8773@ah1?"
    expected = ["q8773@ah1"]
    assert extract_cusip(string) == expected

    string = "what is the rating of 03834*AC0?"
    expected = ["03834*AC0"]
    assert extract_cusip(string) == expected

    # two IDs
    string = "blala G4939*AA9 dalala 23386#AS1."
    expected = ["G4939*AA9", "23386#AS1"]
    assert extract_cusip(string) == expected

    # wrong length
    string = "what is the rating of 01234567?"
    expected = []
    assert extract_cusip(string) == expected

    string = "what is the rating of 0123456789?"
    expected = []
    assert extract_cusip(string) == expected

    # the last digit is not a number
    string = "what is the rating of 01234567A from snp??"
    expected = []
    assert extract_cusip(string) == expected

    # no IDs
    string = "what are the financial trends for xyz?"
    expected = []
    assert extract_cusip(string) == expected


def test_extract_isin():
    # one ID
    string = "what is the rating of Ab0a2B4c6D80?"
    expected = ["Ab0a2B4c6D80"]
    assert extract_isin(string) == expected

    # two ID
    string = "blala Ab0a2B4c6D80 dalala CD0123456789."
    expected = ["Ab0a2B4c6D80", "CD0123456789"]
    assert extract_isin(string) == expected

    # the last digit is not a number
    string = "what is the rating of AB012345678C?"
    expected = []
    assert extract_isin(string) == expected


def test_postprocess_parsed_response():
    # cusip
    extracted_entities = ExtractedEntities(
        entities=["G4939*AA9"],
    )
    extracted_securities = ExtractedSecurities(
        cusip=["G4939*AA9"],
        isin=[],
    )
    expected_extracted_entities = ExtractedEntities(
        entities=[],
    )

    assert post_process(extracted_entities, extracted_securities) == expected_extracted_entities

    # isin
    extracted_entities = ExtractedEntities(
        entities=["Ab0a2B4c6D80"],
    )
    extracted_securities = ExtractedSecurities(
        cusip=[],
        isin=["Ab0a2B4c6D80"],
    )
    expected_extracted_entities = ExtractedEntities(
        entities=[],
    )
    assert post_process(extracted_entities, extracted_securities) == expected_extracted_entities

    # multiple ids what is the rating for Ab0a2B4c6D80, Microsoft and G4939*AA9?
    extracted_entities = ExtractedEntities(
        entities=["G4939*AA9", "Ab0a2B4c6D80", "Microsoft"],
    )
    extracted_securities = ExtractedSecurities(
        cusip=["G4939*AA9"],
        isin=["Ab0a2B4c6D80"],
    )
    expected_extracted_entities = ExtractedEntities(
        entities=["Microsoft"],
    )
    assert post_process(extracted_entities, extracted_securities) == expected_extracted_entities

    # multiple ids what is the rating for Ab0a2B4c6D80, Microsoft and G4939*AA9 and along with cusip term
    extracted_entities = ExtractedEntities(
        entities=["G4939*AA9", "Ab0a2B4c6D80", "Microsoft", "CUSIP 36186XAB3"],
    )
    extracted_securities = ExtractedSecurities(
        cusip=["G4939*AA9", "36186XAB3"],
        isin=["Ab0a2B4c6D80"],
    )
    expected_extracted_entities = ExtractedEntities(
        entities=["Microsoft"],
    )
    assert post_process(extracted_entities, extracted_securities) == expected_extracted_entities

    # cusip term is extracted by entity extractor
    extracted_entities = ExtractedEntities(
        entities=["CUSIP 36186XAB3"],
    )
    extracted_securities = ExtractedSecurities(
        cusip=["36186XAB3"],
        isin=[],
    )
    expected_extracted_entities = ExtractedEntities(
        entities=[],
    )
    assert post_process(extracted_entities, extracted_securities) == expected_extracted_entities


def test_find_closest_string_index():
    string = "Tesla, Inc. (NASDAQGS:TSLA)"
    list_of_strings = ["Tesla", "Apple", "tesl"]
    expected = 0
    assert find_closest_string_index(string, list_of_strings) == expected

    string = "(NASDAQ:AAPL) apple"
    list_of_strings = ["Tesla", "Apple", "msft", "meta", "apple ltd"]
    expected = 1
    assert find_closest_string_index(string, list_of_strings) == expected

    string = "City of New York, New York"
    list_of_strings = [
        "City of New York, NY",
        "City of New York",
        "New York",
        "New York City",
    ]
    expected = 0
    assert find_closest_string_index(string, list_of_strings) == expected

    string = "Yale Univ, General CT Obligation"
    list_of_strings = [
        "Yale University",
        "Yale University General CT Obligation",
        "Yale",
        "Yale Univ",
        "General CT Obligation",
        "Yale Univ, CT General Obligation CP Program",
    ]
    expected = 1
    assert find_closest_string_index(string, list_of_strings) == expected
