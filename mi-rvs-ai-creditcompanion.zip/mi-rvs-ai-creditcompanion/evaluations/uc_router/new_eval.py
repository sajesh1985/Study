# %%
from dotenv import load_dotenv
load_dotenv()

from chatrd.engine.components.query_analyzer.conversational.prompter import ConversationalPrompter
from chatrd.engine.components.query_analyzer.uc_router.router import EndpointRouter

# %%
import pandas as pd
from functools import cache
import json
import time
import datetime
import time 
# %%
import os
import re
from collections import defaultdict
import random
import json

def extract_keys(template):
    keys = re.findall(r"{(.*?)}", template)
    return keys


def get_dictionary_from_folders(directory_path: str):
    json_dict = {}

    for filename in os.listdir(directory_path):
        if filename.endswith(".json"):
            file_path = os.path.join(directory_path, filename)

            with open(file_path, "r") as file:
                json_content = json.load(file)

            key = os.path.splitext(filename)[0]

            json_dict[key] = json_content

    return json_dict
    
mappings = get_dictionary_from_folders("/home/sagemaker-user/creditcompanion/scripts/uc_embedding_generation/template_values")
template_values = get_dictionary_from_folders("/home/sagemaker-user/creditcompanion/scripts/uc_embedding_generation/templates")

def generate_questions(mappings, template_values, num_runs, K):
    questions = {}
    n_timer = defaultdict(lambda: 1, {key : (K // len(template_values[key])) + 1 for key in template_values.keys()})
    questions = {}
    for key, values in template_values.items():
        unique_questions = defaultdict(lambda: set())
        templates = values
        for template in templates:
            N = num_runs * n_timer[key]
            for _ in range(N):
                present_keys = extract_keys(template)
                all_pairs = {}
                for mp_key in present_keys:
                    all_pairs[mp_key] = random.choice(
                        mappings[mp_key],
                    )
                question = template.format(**all_pairs)
                unique_questions[template].add(question)
        questions[key] = unique_questions
    return questions

# %%
qtree = generate_questions(mappings, template_values, 1, 200)
qdf = pd.DataFrame([(q, qt, uc) for uc in qtree.keys() for qt in qtree[uc] for q in qtree[uc][qt]], columns = ["question", "questiontemplate", "uc"])
set(template_values.keys()) - set(qdf.uc.value_counts().index)

# %%
rp = ConversationalPrompter(model_name="haiku")
em = EndpointRouter('endpoint_embedder')

# %%
from chatrd.engine.components.query_analyzer.conversational.prompts.clarifying_prompts import ClarifyingOutput

def get_prompt(query : str):
    try:
        start_time = time.perf_counter()
        out = rp.run(query, [])
        end_time = time.perf_counter()
        elapsed_time = end_time - start_time
        if isinstance(out[1], ClarifyingOutput):
            resp = query
        else:
            resp = out[1].rephrased_initial_question if out[1].rephrased_initial_question is not None else query
        return True, resp, elapsed_time
    except Exception as e:
        return False, repr(e), None
    return True, out, None

# %%
def process_question(question):
    ret = {
        "sucess" : False,
        "exception" : None,
        "rephrased" :None,
        "question" : question,
        "predicted_uc" : None,
        "endpoint_log" : None,
        "rephraser_time" : None,
        "endpoint_time" : None,
    }
    try:
        v, q, t = get_prompt(question)
        if not v:
            ret["exception"] = q
            return ret
        if q is None:
            return ret
        ret["rephrased"] = q
        ret["rephraser_time"] = t
        start_time = time.perf_counter()
        log = em.model.classify_query([q])
        end_time = time.perf_counter()
        elapsed_time = end_time - start_time
        ret["endpoint_log"] = log
        if log["success"]:
            ret["sucess"] = True
            ret["predicted_uc"] = log["predictions"][0]
            ret["endpoint_time"] = elapsed_time
    except Exception as e:
        ret["exception"] = repr(e)
    return ret    

# %%
from tqdm import tqdm
tqdm.pandas()

testing = qdf.question.progress_apply(process_question)


qdf.to_csv(f"test_info_records_{datetime.datetime.now().strftime('%Y-%m-%d')}.csv", index=False)
json.dump(testing.tolist(), open(f"test_records_{datetime.datetime.now().strftime('%Y-%m-%d')}", "w+"), indent=4)

# %%



