from typing import AsyncGenerator, Dict, Iterable, List, Optional, Sequence, Union

from pydantic import Field

from chatrd.core.llm.components.message import (
    AIMessage,
    AIMessageChunk,
    BaseMessage,
    BaseMessageChunk,
    HumanMessage,
    MessageRole,
    SystemMessage,
)
from chatrd.core.llm.models import Bedrock
from chatrd.core.thread_utils import run_in_executor


class BedrockChat(Bedrock):
    """Initialize a chat model implementation for Amazon Bedrock models with conversation support.

    Core-args:
        model_id (str): The ID of the Bedrock model to use.
        provider (Optional[str]): The model provider, e.g., amazon, cohere, ai21, etc.
            Required when model ARN is provided as model_id.
        client (Any): A pre-configured Bedrock client. If not provided, a new client will be created.
    Authentication args
        region_name (Optional[str]): The AWS region where the model is hosted.
            Fallback to the default region from Boto3 if not provided.
        aws_profile_name (Optional[str]): The name of the AWS credentials profile to use.
            Fallback to the default profile if not provided.
        aws_keys (Optional[Dict[str, str]]): A dictionary containing AWS access and secret keys.
            Fallback to the desired or default AWS profile if not provided.
        client_config (Optional[Config]): Configuration for creation the Boto3 client.
            For more details, refer to the Boto3 documentation.
            https://boto3.amazonaws.com/v1/documentation/api/latest/guide/configuration.html
    Model-config args
        streaming (bool): Whether to enable streaming for the model. Defaults to False.
        model_kwargs (Optional[Dict[str, Any]]): Additional keyword arguments for the model such as,
            temperature, max_tokens_to_sample, guardrail_identifier, guardrail_version, etc.
        guardrails (Optional[Dict[str, Any]]): Guardrails configuration for the model,
            including id, version, and trace.
        verbose (bool): Whether to enable verbose logging. Defaults to False.
    """

    history: list[BaseMessage] = Field(
        default_factory=list, description="History of messages in the conversation.", exclude=True
    )

    def invoke(self, messages: list[BaseMessage], **kwargs) -> AIMessage:
        """Invoke the chat model with a list of messages and return the AI's response."""
        prepared_input, prepared_kwargs = self._prepare_chat_inputs(messages, **kwargs)

        # Call BedrockLLM to interact with the bedrock model
        response = super().invoke(inputs=prepared_input, **prepared_kwargs)
        result = None
        if isinstance(response, AIMessage):
            result = response
        elif isinstance(response, BaseMessageChunk):
            result = AIMessage(
                content=response.content,
                response_metadata=response.response_metadata,
                additional_kwargs=response.additional_kwargs,
            )
        elif isinstance(result, str) or isinstance(result, Sequence):
            # If the result is a string or a sequence, create an AIMessage from it
            result = AIMessage(content=response)
        else:
            raise ValueError(f"Unexpected result type from Bedrock: {type(result)}.")
        self._add_to_history(result)
        return result

    async def ainvoke(self, messages: list[BaseMessage], **kwargs) -> AIMessage:
        """Asynchronously invoke the chat model with a list of messages and return the AI's response."""
        return await run_in_executor(executor=None, func=self.ainvoke, messages=messages, **kwargs)

    def stream(self, messages: list[BaseMessage], **kwargs) -> Iterable[AIMessageChunk]:
        """Stream the chat model response."""
        prepared_input, prepared_kwargs = self._prepare_chat_inputs(messages, **kwargs)

        messages = super().stream(prepared_input, **prepared_kwargs)
        ai_message_chunks = []
        for chunk in messages:
            if not isinstance(chunk, AIMessageChunk):
                raise ValueError(f"Expected AIMessageChunk, got {type(chunk)}.")
            ai_message_chunks.append(chunk)
            yield chunk
        self._add_to_history(AIMessage.from_chunks(ai_message_chunks))

    async def astream(self, messages: list[BaseMessage], **kwargs) -> AsyncGenerator[AIMessageChunk, None]:
        """Asynchronously stream the chat model response."""
        prepared_input, prepared_kwargs = self._prepare_chat_inputs(messages, **kwargs)

        ai_message_chunks = []
        async for chunk in super().astream(prepared_input, **prepared_kwargs):
            if not isinstance(chunk, AIMessageChunk):
                raise ValueError(f"Expected AIMessageChunk, got {type(chunk)}.")
            ai_message_chunks.append(chunk)
            yield chunk
        self._add_to_history(AIMessage.from_chunks(ai_message_chunks))

    def chat(self, message: str, role: Union[MessageRole, str] = MessageRole.USER, **kwargs) -> AIMessage:
        """Interact with the chat model using single messages."""
        messages = [{"role": role, "content": message}]
        return self.invoke(messages=[self._format_messages(messages, kwargs)], **kwargs)

    def achat(self, message: str, role: Union[MessageRole, str] = MessageRole.USER, **kwargs) -> AIMessage:
        """Interact asynchronously with the chat model using single messages."""
        messages = [{"role": role, "content": message}]
        return self.ainvoke(messages=[self._format_messages(messages, kwargs)], **kwargs)

    def _prepare_chat_inputs(self, messages: Union[BaseMessage, list[BaseMessage]], **kwargs) -> str:
        """Prepare the chat inputs, history, and context to send to the model."""
        if not isinstance(messages, list):
            messages = [messages]
        messages = self._format_messages(messages, kwargs)
        for message in messages:
            self._add_to_history(message)

        prepared_input = self.get_history()[-1]
        prepared_kwargs = {
            **kwargs,
            "system": kwargs.pop("system", None),
            "messages": self.get_history()[:-1],
        }
        return prepared_input, prepared_kwargs

    def _get_provider_based_prompt_format(self, role: MessageRole) -> str:
        """Get the prompt format based on the model provider."""
        if not isinstance(role, MessageRole):
            role = MessageRole.from_string(role)
        if role == MessageRole.SYSTEM or role == MessageRole.ASSISTANT:
            return f"{role.value.capitalize()}: "
        # Handle USER role differently based on provider
        match self.get_provider():
            case "anthropic" | "claude":
                return "Human"
            case "ai21" | "ai21-llm" | "amazon" | "bedrock" | "cohere" | "cohere-llm" | "llama" | "meta" | "mistral":
                return "User"
            # Default case for unsupported providers
            case _:
                raise ValueError(f"Unsupported provider: {self.get_provider()}")

    def _format_messages(self, messages: list[Union[BaseMessage, Dict]], kwargs: Optional[Dict] = None) -> BaseMessage:
        """Format the prompt for the chat model."""

        output = []
        for msg in messages:
            if isinstance(msg, BaseMessage):
                output.append(msg)
                continue
            elif isinstance(msg, dict):
                if not all(key in msg for key in ["role", "content"]):
                    raise ValueError(f"Invalid dictionary format: {msg}. Expected keys: 'role' and 'content'.")
                role = MessageRole.from_string(msg["role"])
                prompt = msg.get("content", "")
            elif isinstance(msg, str):
                role = MessageRole.USER
                prompt = msg
            else:
                raise ValueError(f"Invalid message type: {type(msg)}. Expected dict, BaseMessage.")
            # Create message instance based on role
            if role == MessageRole.USER:
                output.append(HumanMessage(content=prompt, additional_kwargs=kwargs))
            elif role == MessageRole.ASSISTANT:
                output.append(AIMessage(content=prompt, additional_kwargs=kwargs))
            elif role == MessageRole.SYSTEM:
                output.append(SystemMessage(content=prompt, additional_kwargs=kwargs))
            else:
                raise ValueError(f"Unsupported message role: {role}")
        return output

    def _add_to_history(self, message: BaseMessage) -> None:
        """Add a message to the conversation history."""
        self.history.append(message)

    def get_history(self) -> List[BaseMessage]:
        """Get the conversation history."""
        return self.history

    def clear_history(self) -> None:
        """Clear the conversation history."""
        self.history = []
