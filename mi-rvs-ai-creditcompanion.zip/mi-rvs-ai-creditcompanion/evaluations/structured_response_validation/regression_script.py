import argparse
import logging
import rich
from lxml import etree
from chatrd.engine.app.engine_initiator import get_chat_engine
import csv

parser = argparse.ArgumentParser(description="Regression Test Script")
parser.add_argument("--in_file", type=str, help="Questions File")
parser.add_argument("--out_file", type=str, help="Responses File")
parser.add_argument("--log_file", type=str, help="Log File")
parser.add_argument("--structured_only", action="store_true", help="Process Structured Only")
args = parser.parse_args()

structured_only = args.structured_only
in_file = args.in_file
out_file = args.out_file
log_file = args.log_file

logging.basicConfig(filename=log_file)
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

CHAT = get_chat_engine()
questionAndResponse = []


def get_response(qn):
    """
    Sends a question to the chat engine and retrieves the response.

    Args:
        qn (str): The question to be sent to the chat engine.

    Returns:
        AIMessage: The response from the chat engine.
    """
    response = CHAT.chat(
        message=qn,
        streaming=False,
    )
    return response


def extract_info_and_criteria(data):
    """
    Extracts the  leading line, 'Query Criteria', and total count from the given ChatResponse.

    Args:
        response (ChatResponse): An instance of ChatResponse containing the response data.

    Returns:
        tuple: A tuple containing  leading line, Query Criteria content, and total count.
    """
    leading_line = None
    query_criteria = None
    total_count = None
    for item in data:
        if item['type'] == 'text' and 'content' in item:
            # Set leading line to the first text entry
            if leading_line is None:
                leading_line = item['content']
            # Check for Query Criteria
            if 'Query Criteria' in item['content']:
                query_criteria = item['content']      
        if item['type'] == 'table' and 'content' in item and hasattr(item['content'], 'count'):
            total_count = item['content'].count
    return query_criteria, leading_line, total_count


# Read the text file into a list
with open(in_file, 'r') as file:
    lines = file.readlines()

# Clean up the lines by stripping whitespace
lines = [line.strip() for line in lines if line.strip()]
qns = lines


for qn in qns:
    """
    Processes each question, retrieves the response, extracts query criteria, 
    and stores the results in a list.

    Steps:
        1. Print the question to the console.
        2. Log the question.
        3. Send the question to the chat engine and get the response.
        4. Extract query criteria from the response.
        5. Parse the query criteria using lxml if available.
        6. Store the question and response in the `questionAndResponse` list.
    """
    try:
        # print to console
        rich.print(qn)
        questionAndResponse.append({"question": qn, "response": None, "leading_line": None, "total_count": None, "query_criteria_found": None})
        # print to logger
        logger.info(qn)
        response = get_response(qn)
       
        query_criteria, leading_line, total_count = extract_info_and_criteria(response.content)
        if query_criteria:
            parser = etree.HTMLParser()
            tree = etree.fromstring(query_criteria, parser)
            plain_text = '\n'.join(tree.xpath('//text()')).strip()             
            questionAndResponse[-1]["response"] = plain_text
            questionAndResponse[-1]["leading_line"] = leading_line
            questionAndResponse[-1]["total_count"] = total_count        
            questionAndResponse[-1]["query_criteria_found"] = True
        else:
            questionAndResponse[-1]["response"] = f"No query criteria found.\n response :{response.content}"
            questionAndResponse[-1]["leading_line"] = leading_line
            questionAndResponse[-1]["total_count"] = total_count
            questionAndResponse[-1]["query_criteria_found"] = False
        
    except Exception as e:
        logger.error(f"Error processing question '{qn}': {e}")
        questionAndResponse[-1]["response"] = f"Error: {e}"
        questionAndResponse[-1]["leading_line"] = "Error occurred"


with open(f"{out_file}", "w", newline="", encoding="utf-8") as csvfile:
    """
    Writes the processed questions and responses to a CSV file.

    Args:
        out_file (str): The output file path for the CSV.
    """
    # Use the keys of the first dictionary as the column headers
    fieldnames = questionAndResponse[0].keys()
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

    # Write the header row
    writer.writeheader()

    # Write the data rows
    writer.writerows(questionAndResponse)

print("Done")
