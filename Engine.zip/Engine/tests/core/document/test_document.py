import os
import re
import string
from pathlib import Path

import pandas as pd
from lxml import etree

from chatrd.core.document import Document, documents_as_dataframe
from chatrd.core.document.utils import (
    __clean_str,
    _clean_criteria_xml,
    _clean_definitions_xml,
    _clean_multiple_whitespaces,
    _clean_research_xml,
    _is_valid_chunk,
    _split_commentary_md,
    _split_commentary_xml,
    _split_criteria_xml,
    _split_definitions_xml,
    _split_research_xml,
    convert_xml_section_to_markdown,
    get_tablerow_text,
    parse_definitions_list,
    parse_definitions_table,
)

ROOT_FOLDER = Path(__file__).parents[3]

def test_documents_as_dataframe():
    documents = [
        Document(content="haha", metadata={"a": 0, "b": 3}),
        Document(content="lala", metadata={"a": 9, "b": 7}),
    ]

    df_expected = pd.DataFrame(data=[[0, 3, "haha"], [9, 7, "lala"]], columns=["a", "b", "text"])
    df_expected.reindex(sorted(df_expected.columns), axis=1)

    df_output = documents_as_dataframe(documents)
    df_output.reindex(sorted(df_output.columns), axis=1)

    pd.testing.assert_frame_equal(df_output, df_expected)


def test__clean_multiple_whitespaces():
    assert _clean_multiple_whitespaces("") == ""
    assert _clean_multiple_whitespaces(" ") == ""
    assert _clean_multiple_whitespaces(string.whitespace) == ""
    assert _clean_multiple_whitespaces("\t test \ntest  ") == "test test"


def test__is_valid_chunk():
    assert not _is_valid_chunk("")
    assert not _is_valid_chunk("this paragraph has been deleted.")
    assert _is_valid_chunk("a valid chunk")


def test__clean_criteria_xml():
    input_xml = """
    <spdoc>
      <commentary>
        <body>
          <EditorsNote>EditorsNote</EditorsNote>
          <object>object</object>
          <Disclaimer>Disclaimer</Disclaimer>
          <sptable>sptable</sptable>
          <Boilerplate>Boilerplate</Boilerplate>
          <chart>chart</chart>
          <page_break>page_break</page_break>
          <table>table</table>
        </body>
      </commentary>
    </spdoc>
    """
    assert re.sub(r"\s+", "", _clean_criteria_xml(input_xml)) == "<spdoc><commentary><body></body></commentary></spdoc>"

    input_xml = """
    <spdoc>
      <commentary>
        <body>
          <section name="Related Research">related research</section>
          <section name="Related Criteria">related criteria</section>
          <section name="Revisions and Updates">revisions and updates</section>
          <section name="Related Criteria and Research">related criteria and research</section>
          <section name="Related Publications">related publications</section>
          <section name="Superseded Criteria">superseded criteria</section>
        </body>
      </commentary>
    </spdoc>
    """
    assert re.sub(r"\s+", "", _clean_criteria_xml(input_xml)) == "<spdoc><commentary><body></body></commentary></spdoc>"


def test__clean_research_xml():
    input_xml = """
    <spdoc>
      <analysis>
        <body>
          <EditorsNote>EditorsNote</EditorsNote>
          <object>object</object>
          <Disclaimer>Disclaimer</Disclaimer>
          <sptable>sptable</sptable>
          <Boilerplate>Boilerplate</Boilerplate>
          <chart>chart</chart>
          <page_break>page_break</page_break>
          <preformat>preformat</preformat>
        </body>
      </analysis>
    </spdoc>
    """
    assert re.sub(r"\s+", "", _clean_research_xml(input_xml)) == "<spdoc><analysis><body></body></analysis></spdoc>"

    input_xml = """
    <spdoc>
      <analysis>
        <body>
          <section name="Related Research">related research</section>
          <section name="Related Criteria">related criteria</section>
          <section name="Revisions and Updates">revisions and updates</section>
          <section name="Related Criteria and Research">related criteria and research</section>
          <section name="Related Publications">related publications</section>
          <section name="Superseded Criteria">superseded criteria</section>
        </body>
      </analysis>
    </spdoc>
    """
    assert re.sub(r"\s+", "", _clean_research_xml(input_xml)) == "<spdoc><analysis><body></body></analysis></spdoc>"

    input_xml = """
    <spdoc>
        <analysis>
            <body>
                <section name="Credit Highlights">
                    <table>keep</table>
                </section>
                <table>remove</table>
            </body>
        </analysis>
    </spdoc>
    """
    assert (
        re.sub(r"(?<=>)\s+(?=<)", "", _clean_research_xml(input_xml))
        == """<spdoc><analysis><body><section name="Credit Highlights">"""
        """<table>keep</table></section></body></analysis></spdoc>"""
    )

    input_xml = """
    <spdoc>
        <analysis>
            <body>
                <section name="Credit Highlights">
                    <section name="">
                        <table>keep</table>
                    </section>
                </section>
                <table>remove</table>
            </body>
        </analysis>
    </spdoc>
    """
    assert (
        re.sub(r"(?<=>)\s+(?=<)", "", _clean_research_xml(input_xml))
        == """<spdoc><analysis><body><section name="Credit Highlights"><section name="">"""
        """<table>keep</table></section></section></body></analysis></spdoc>"""
    )


def test__split_criteria_xml():
    input_xml = """
    <spdoc>
        <commentary>
            <body>
                <section name="XXX">
                    <para>para</para>
                    <paranum>paranum</paranum>
                    <subsection>subsection</subsection>
                    <section>section</section>
                </section>
            </body>
        </commentary>
    </spdoc>
    """
    chunks, metadata = _split_criteria_xml(input_xml)
    assert chunks == ["para", "paranum", "subsection", "section"]
    assert metadata == [{"chunk_title": "XXX"}, {"chunk_title": "XXX"}, {"chunk_title": "XXX"}, {"chunk_title": "XXX"}]

    input_xml = """
    <spdoc>
        <commentary>
            <body>
                <section name="XXX">
                    <list>
                        <listitem>item1</listitem>
                        <listitem>item2</listitem>
                    </list>
                </section>
            </body>
        </commentary>
    </spdoc>
    """
    chunks, metadata = _split_criteria_xml(input_xml)
    assert chunks == ["- item1\n- item2"]
    assert metadata == [{"chunk_title": "XXX"}]

    input_xml = """
    <spdoc>
        <commentary>
            <body>
                <section name="XXX">
                    <para>YYY : </para>
                    <list>
                        <listitem>item1</listitem>
                        <listitem>item2</listitem>
                    </list>
                </section>
            </body>
        </commentary>
    </spdoc>
    """
    chunks, metadata = _split_criteria_xml(input_xml)
    assert chunks == ["YYY :\n- item1\n- item2"]
    assert metadata == [{"chunk_title": "XXX"}]

    input_xml = """
    <spdoc>
        <commentary>
            <body>
                <section name="XXX">
                    <paranum>  YYY : </paranum>
                    <list>
                        <listitem>item1</listitem>
                        <listitem>item2</listitem>
                    </list>
                </section>
            </body>
        </commentary>
    </spdoc>
    """
    chunks, metadata = _split_criteria_xml(input_xml)
    assert chunks == ["YYY :\n- item1\n- item2"]
    assert metadata == [{"chunk_title": "XXX"}]

    input_xml = """
    <spdoc>
        <commentary>
            <body>
                <section name="XXX">
                    <subsection> YYY :  </subsection>
                    <list>
                        <listitem>item1</listitem>
                        <listitem>item2</listitem>
                    </list>
                </section>
            </body>
        </commentary>
    </spdoc>
    """
    chunks, metadata = _split_criteria_xml(input_xml)
    assert chunks == ["YYY :\n- item1\n- item2"]
    assert metadata == [{"chunk_title": "XXX"}]

    input_xml = """
    <spdoc>
        <commentary>
            <body>
                <section name="XXX">
                    <subsection name="ZZZ "> YYY :  </subsection>
                    <list>
                        <listitem>item1</listitem>
                        <listitem>item2</listitem>
                    </list>
                </section>
            </body>
        </commentary>
    </spdoc>
    """
    chunks, metadata = _split_criteria_xml(input_xml)
    assert chunks == ["ZZZ\nYYY :\n- item1\n- item2"]
    assert metadata == [{"chunk_title": "XXX"}]


def test__split_research_xml():
    input_xml = """
    <spdoc>
        <analysis>
            <body>
                <section name="XXX">
                    <para>para</para>
                    <paranum>paranum</paranum>
                    <subsection>subsection</subsection>
                    <section>section</section>
                </section>
            </body>
        </analysis>
    </spdoc>
    """
    chunks, metadata = _split_research_xml(input_xml)
    assert chunks == ["para", "paranum", "subsection", "section"]
    assert metadata == [{"chunk_title": "XXX"}, {"chunk_title": "XXX"}, {"chunk_title": "XXX"}, {"chunk_title": "XXX"}]

    input_xml = """
    <spdoc>
        <analysis>
            <body>
                <section name="XXX">
                    <list>
                        <listitem>item1</listitem>
                        <listitem>item2</listitem>
                    </list>
                </section>
            </body>
        </analysis>
    </spdoc>
    """
    chunks, metadata = _split_research_xml(input_xml)
    assert chunks == ["- item1\n- item2"]
    assert metadata == [{"chunk_title": "XXX"}]

    input_xml = """
    <spdoc>
        <analysis>
            <body>
                <section name="XXX">
                    <para> YYY :  </para>
                    <list>
                        <listitem>item1</listitem>
                        <listitem>item2</listitem>
                    </list>
                </section>
            </body>
        </analysis>
    </spdoc>
    """
    chunks, metadata = _split_research_xml(input_xml)
    assert chunks == ["YYY :\n- item1\n- item2"]
    assert metadata == [{"chunk_title": "XXX"}]

    input_xml = """
    <spdoc>
        <analysis>
            <body>
                <section name="XXX">
                    <paranum> YYY: </paranum>
                    <list>
                        <listitem>item1</listitem>
                        <listitem>item2</listitem>
                    </list>
                </section>
            </body>
        </analysis>
    </spdoc>
    """
    chunks, metadata = _split_research_xml(input_xml)
    assert chunks == ["YYY:\n- item1\n- item2"]
    assert metadata == [{"chunk_title": "XXX"}]

    input_xml = """
    <spdoc>
        <analysis>
            <body>
                <section name="XXX">
                    <subsection> YYY: </subsection>
                    <list>
                        <listitem>item1</listitem>
                        <listitem>item2</listitem>
                    </list>
                </section>
            </body>
        </analysis>
    </spdoc>
    """
    chunks, metadata = _split_research_xml(input_xml)
    assert chunks == ["YYY:\n- item1\n- item2"]
    assert metadata == [{"chunk_title": "XXX"}]

    input_xml = """
    <spdoc>
        <analysis>
            <body>
                <section name="XXX">
                    <subsection name="ZZZ">YYY:</subsection>
                    <list>
                        <listitem>item1</listitem>
                        <listitem>item2</listitem>
                    </list>
                </section>
            </body>
        </analysis>
    </spdoc>
    """
    chunks, metadata = _split_research_xml(input_xml)
    assert chunks == ["ZZZ\nYYY:\n- item1\n- item2"]
    assert metadata == [{"chunk_title": "XXX"}]

    input_xml = """
    <spdoc>
        <analysis>
            <body>
                <section name="XXX">
                    <table>
                        <tablerow><tablecell>item1</tablecell><tablecell>item2</tablecell></tablerow>
                        <tablerow><tablecell>item3</tablecell><tablecell>item4</tablecell></tablerow>
                    </table>
                </section>
            </body>
        </analysis>
    </spdoc>
    """
    chunks, metadata = _split_research_xml(input_xml)
    assert chunks == ["item1 | item2\nitem3 | item4"]
    assert metadata == [{"chunk_title": "XXX"}]

    input_xml = """
    <spdoc>
        <analysis>
            <body>
                <section name="Outlook">
                    <para>para</para>
                    <subsection name="downside">
                    subsection
                    <list>
                        <listitem>First row</listitem>
                        <listitem>Second row</listitem>
                    </list>
                    </subsection>
                    <para>para2</para>
                    <section name="upside">upside</section>
                    <section name="unknown">hello</section>
                </section>
                <section name="Environmental, Social, And Governance">
                <para> environmental </para>
                <para> social </para>
                <para> governance </para>
                </section>
                <section name="we see environmental factors as less relevant (than social and governance factors) to the creditworthiness of cba.">
                <para> environmental </para>
                <para> social </para>
                <para> governance </para>
                </section>
                <section name="CreditWatch">
                    <para>para</para>
                    <subsection name="downside">
                    subsection
                    <list>
                        <listitem>First row</listitem>
                        <listitem>Second row</listitem>
                    </list>
                    </subsection>
                    <para>para2</para>
                    <section name="upside">upside</section>
                    <section name="unknown">hello</section>
                </section>
                <section name="Peer Comparison">
                    <para>peer</para>
                    <subsection name="peer 1">
                    subsection
                    </subsection>
                    <para>peer</para>
                    <section name="peer2">peer2</section>
                </section>
                <section name="Peer Comparison">
                </section>
                <section name="Peer Comparison">
                <para></para>
                <section name="">
                </section>
                <para></para>
                </section>
                <section name="Peer Comparison"><section name="XYZ"></section></section>
            </body>
        </analysis>
    </spdoc>
    """
    chunks, metadata = _split_research_xml(input_xml)
    assert chunks == [
        "para\n\ndownside or Downgrade Triggers:\n\nsubsection\n\n- First row\n- Second row\npara2\n\nupside or Upgrade Triggers:\n\nupside\n\nunknown:\n\nhello",
        "environmental\nsocial\ngovernance",
        "environmental\nsocial\ngovernance",
        "para\n\ndownside or Downgrade Triggers:\n\nsubsection\n\n- First row\n- Second row\npara2\n\nupside or Upgrade Triggers:\n\nupside\n\nunknown:\n\nhello",
        "peer\n\npeer 1:\n\nsubsection\npeer\n\npeer2:\n\npeer2",
    ]
    assert metadata == [
        {"chunk_title": "Outlook"},
        {"chunk_title": "Environmental, Social, And Governance (ESG)"},
        {
            "chunk_title": "we see environmental factors as less relevant (than social and governance factors) to the creditworthiness of cba. (ESG)"
        },
        {"chunk_title": "CreditWatch"},
        {"chunk_title": "Peer Comparison"},
    ]


def test_get_tablerow_text():
    extable = etree.fromstring(
        """
                 <table>
                    <tablerow>
                        <tablecolhead align="left">Category</tablecolhead>
                        <tablecolhead align="left">Definition</tablecolhead>
                    </tablerow>
                    <tablerow>
                        <tabletext>test</tabletext>
                        <tabletext>test</tabletext>
					</tablerow>
                 </table>
                 """
    )
    assert get_tablerow_text(extable) == ["Category", "Definition", "test", "test"]


def test_parse_definitions_table():
    extable = etree.fromstring(
        """
                 <table>
                    <tablerow>
                        <tablecolhead align="left">Category</tablecolhead>
                        <tablecolhead align="left">Definition</tablecolhead>
                    </tablerow>
                    <tablerow>
                        <tabletext>test</tabletext>
                        <tabletext>test</tabletext>
					</tablerow>
                 </table>
                 """
    )
    extable2 = etree.fromstring(
        """
                 <table>
                    <tablerow>
                        <tablecolhead align="left">NotaCategory</tablecolhead>
                        <tablecolhead align="left">Definition</tablecolhead>
                    </tablerow>
                    <tablerow>
                        <tabletext>test</tabletext>
                        <tabletext>test</tabletext>
					</tablerow>
                 </table>
                 """
    )
    assert parse_definitions_table(extable) == "- test: test"
    assert parse_definitions_table(extable2) is None


def test_parse_definitions_list():
    exlist = etree.fromstring(
        """<list type="bullet">
	    					<listitem>test1</listitem>
		    				<listitem>tes32</listitem>
			    			<listitem>test3</listitem>
				    	</list>"""
    )
    assert parse_definitions_list(exlist) == "- test1\n- tes32\n- test3"


def test__clean_definitions_xml():
    exxml = """<body>
    <table><tableenvelope1></tableenvelope1></table>
    <EditorsNote></EditorsNote>
    <section name="X.  RELATED CRITERIA AND RESEARCH"></section>
    <section name="XI.  CONTACT INFORMATION"></section>
    <section name="IX. REVISIONS AND UPDATES"></section>
    <para> Hello World! </para>
    </body>"""
    assert _clean_definitions_xml(exxml) == "<body>\n    <table/>\n    <para> Hello World! </para>\n    </body>"


def test__split_definitions_xml():
    exxml = """
<body>
    <section name="section 1">
        <para>para</para>
        <paranum>paranum</paranum>
        <para> </para>
        <para></para>
    </section>
    <section name = "VIII. APPENDIX">
        <list type="bullet">
            <listitem>test1</listitem>
            <listitem>tes32</listitem>
            <listitem>test3</listitem>
        </list>
    </section>
    <section name = "After Appendix">
        <table>
            <tablerow>
                <tablecolhead align="left">
                NotaCategory</tablecolhead>
                <tablecolhead align="left">
                Definition</tablecolhead>
            </tablerow>
            <tablerow>
                <tabletext>test</tabletext>
                <tabletext>test</tabletext>
            </tablerow>
        </table>
        <para> in appendix </para>
        <section name = "1. Not in appendix">
            <table>
            <tablerow>
                <tablecolhead align="left">Category</tablecolhead>
                <tablecolhead align="left">Definition</tablecolhead>
            </tablerow>
            <tablerow>
                <tabletext>test</tabletext>
                <tabletext>test</tabletext>
            </tablerow>
        </table>
        </section>
    </section>
</body>"""
    split_defs = _split_definitions_xml(exxml)
    chunks = set(split_defs[0])
    metadata = split_defs[1]
    assert chunks == {
        "# **VIII. APPENDIX**\n- test1\n- tes32\n- test3",
        "# **section 1**\npara\nparanum",
        "# **1. Not in appendix**\n- test: test",
        "# **After Appendix**\n in appendix",
    }
    correct_metadata = [
        {"chunk_title": "After Appendix", "subsection_chunk_titles": ["After Appendix"]},
        {"chunk_title": "VIII. APPENDIX", "subsection_chunk_titles": ["VIII. APPENDIX"]},
        {"chunk_title": "section 1", "subsection_chunk_titles": ["section 1"]},
        {"chunk_title": "1. Not in appendix", "subsection_chunk_titles": ["1. Not in appendix"]},
    ]
    for metadatum in metadata:
        assert any([metadatum == correct_data for correct_data in correct_metadata])


def test__split_commentary_md():
    file_path = ROOT_FOLDER.joinpath("tests/data/2005.14165v4.md")
    with open(file_path, "rt") as md:
        md_content = md.read()
        chunks1 = _split_commentary_md(md_content, 1000)
        chunks2 = _split_commentary_md(md_content, 5000)
        chunks3 = _split_commentary_md(md_content, 200000)
        chunks4 = _split_commentary_md(md_content, 500000)
        chunks5 = _split_commentary_md("", 1000)
        assert len(chunks1) == 4
        assert len(chunks2) == 3
        assert len(chunks3) == 1
        assert len(chunks4) == 1
        assert len(chunks5) == 0
