﻿namespace Fis.Epp.Fusion.WebAPI
{
    using Fis.Epp.Fusion.WebAPI.Common;
    using Microsoft.AspNetCore.Builder;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.FileProviders;
    using Microsoft.Extensions.Options;
    using Newtonsoft.Json.Serialization;
    using System.IO;
    using System.Linq;

    public class Startup
    {
        private readonly IConfiguration _configuration;

        public Startup(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.Configure<AppSettings>(_configuration.GetSection("AppSettings"));
            services.AddSingleton(resolver =>
               resolver.GetRequiredService<IOptions<AppSettings>>().Value);

            services.AddMvc();
            services.AddControllers().AddNewtonsoftJson(options =>
            {
                options.SerializerSettings.ContractResolver = new DefaultContractResolver();
            });
            services.AddCorsPolicy();
            services.AddHealthChecks();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.EnvironmentName == "Development")
            {
                app.UseDeveloperExceptionPage();
            }

            if (Directory.Exists(Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/res")))
            {
                app.UseFileServer(new FileServerOptions
                {
                    FileProvider = new PhysicalFileProvider(
                    Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/res")),
                    RequestPath = "/wwwroot/res"
                });
            }

            app.UseRouting();
            app.UseCorsPolicy();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
            app.UseMiddleware(typeof(ExceptionHandlingMiddleware));
            app.UseHealthChecks("/health");
        }

        #region Private methods

        private string[] ResolveConfiguration(string configValue)
        {
            string[] resolvedValue = new string[] { };

            if (!string.IsNullOrEmpty(configValue))
            {
                resolvedValue = configValue.Split(',').Select(x => x.Trim()).ToArray();
            }
            return resolvedValue;
        }

        #endregion
    }
}
