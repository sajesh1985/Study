// Copyright Notice!
// This document is protected under the trade secret and copyright
// laws as the property of Fidelity National Information Services, Inc.
// Copying, reproduction or distribution should be limited and only to
// employees with a “need to know” to do their job.
// Any disclosure of this document to third parties is strictly prohibited.
// © 2016 Fidelity National Information Services.
// All rights reserved worldwide.


package com.fis.digitalpayments.sdk.core;

import android.content.Context;

/**
 * Generic definition of a Bridge that handles requests for device functionality.
 */
public abstract class Bridge {

    @SuppressWarnings({"SameReturnValue", "unused"})
    public abstract String getBridgeId();

    /**
     * The main processor of a bridge request. This is where the request is inspected, appropriate result is created, and then returned through the callback.
     * @param bridgeRequest Object describing the request.
     * @param bridgeRequestCallback Callback to be called when the request is complete.
     */
    public abstract void handleRequest(BridgeRequest bridgeRequest, BridgeRequestCallback bridgeRequestCallback, Context context) throws BridgeException;

    static void createWarningResponse(final BridgeRequest bridgeRequest, final BridgeRequestCallback bridgeRequestCallback, final BridgeMessageCode bridgeMessageCode) {
        new Thread(new Runnable() {
            @Override
            public void run() {

                BridgeMessage bridgeMessage = BridgeMessage.CreateWarning(bridgeMessageCode, bridgeMessageCode.toString());
                BridgeResponse bridgeResponse = new BridgeResponse(bridgeRequest.getCallbackMethod(), null, null, bridgeRequest.getCallbackKey(), false, bridgeMessage);

                bridgeRequestCallback.onRequestComplete(bridgeResponse);
            }
        }).start();
    }

    protected void executeWithPermission(@SuppressWarnings("SameParameterValue") String permissionId, RestrictedOperation restrictedOperation, Context context, boolean isDisclosureEnabled) {
        RestrictedExecutor.executeWithPermission(permissionId, restrictedOperation, context, isDisclosureEnabled);
    }
}
