import ast
import json
from pathlib import Path
from unittest.mock import patch

import pytest

from chatrd.engine.configuration import Constants, ConfigKey
from chatrd.engine.search_api import SearchAPI

# Load test data from JSON file
ROOT_FOLDER = Path(__file__).parents[2]
with open(ROOT_FOLDER.joinpath("tests/data/test_search_api.json")) as f:
    test_data = json.load(f)


@pytest.fixture
def resource_url_config_mock():
    with patch("chatrd.engine.components.query_processor.utils.config_machinery.get_config_value") as mock_config_value:

        def side_effect(arg: ConfigKey):
            return f"<{arg.value}>"

        mock_config_value.side_effect = side_effect
        yield mock_config_value


@pytest.mark.parametrize(
    "input, output", [(data["input"], data.get("output")) for data in test_data["test_get_entity_context"]]
)
def test_get_entity_context(resource_url_config_mock, input, output):
    search_api = SearchAPI()
    top_match, _ = search_api._get_top_matches(ast.literal_eval(input))
    disambiguated_entity_context = search_api._get_entity_context(top_match)
    output_eval = ast.literal_eval(output)

    all_keys = set(disambiguated_entity_context.keys()).union(set(output_eval.keys()))
    for key in all_keys:
        if key in ["score", "mi_entity_score", "calculated_score"]:
            continue
        assert disambiguated_entity_context[key] == output_eval[key]
