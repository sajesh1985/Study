from .extractor import SectorExtractor
