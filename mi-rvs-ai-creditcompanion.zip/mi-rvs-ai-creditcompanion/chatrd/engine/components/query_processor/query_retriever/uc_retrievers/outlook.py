import logging
from typing import Dict, List, Union

from botocore.client import BaseClient
from pydantic import BaseModel

from chatrd.core.document import Document, TableDocument
from chatrd.core.llm import LCLLMFactory
from chatrd.core.llm.components import BaseLanguageModel
from chatrd.core.llm.components.message import AIMessage
from chatrd.core.llm.parsers import OutputParserException, PydanticOutputParser
from chatrd.core.llm.prompt.template import SimplePromptTemplate
from chatrd.core.vectorstore import OpenSearch
from chatrd.engine.components.query_analyzer.entity_extractor.utils import (
    Companies,
    Entities,
    RevenueSource,
)
from chatrd.engine.components.query_processor.query_retriever.data_service_retriever import (
    call_data_service,
)
from chatrd.engine.components.query_processor.query_retriever.reranker import (
    get_reranked_documents,
)
from chatrd.engine.components.query_processor.query_retriever.uc_retrievers.base import (
    UCRetriever,
)
from chatrd.engine.components.query_processor.query_retriever.uc_retrievers.prompt_templates import (
    OUTLOOK_EXAMPLES,
    OUTLOOK_PROMPTS,
)
from chatrd.engine.components.query_processor.query_retriever.uc_retrievers.utils import (
    OutlookRetrieverModel,
)
from chatrd.engine.components.query_processor.query_retriever.utils import (
    add_structured_source,
    add_unstructured_source,
    get_filters_for_research,
    get_sorted_docs_by_date,
    post_process_retrieved_docs,
)
from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.responses import get_default_answer

logger = logging.getLogger(__name__)

config_machinery = get_config_machinery()


class OutlookRetriever(UCRetriever):
    def __init__(self, vector_stores_dict: Dict[str, OpenSearch], reranker_client: BaseClient):
        self.vector_stores_dict = vector_stores_dict
        self.top_k_text_research = config_machinery.get_config_value(Constants.GeneralConstants.TOP_K_TEXT_RESEARCH)
        self.top_k_text_research_double_rerank = config_machinery.get_config_value(
            Constants.GeneralConstants.TOP_K_TEXT_RESEARCH_DOUBLE_RERANK
        )
        self.top_k_text_reduced_research = config_machinery.get_config_value(
            Constants.GeneralConstants.TOP_K_TEXT_REDUCED_RESEARCH
        )
        self.top_k_text_research_recency_bias_final = config_machinery.get_config_value(
            Constants.GeneralConstants.TOP_K_TEXT_RESEARCH_RECENCY_BIAS_FINAL
        )
        self.reranker_client = reranker_client
        self.reranker_endpoint_name = config_machinery.get_config_value(
            Constants.SageMaker.SAGEMAKER_RERANKER_ENDPOINT_NAME
        )

    def retrieve(
        self,
        query: str,
        entities: Entities,
        model_name_for_tool_classifier: str,
        temperature_for_tool_classfifer: float,
        model_name_for_data_service: str,
        temperature_for_data_service: float,
        sectors: BaseModel,
        subrouting_result: str,
        original_language: str,
        original_query: str,
        multi_uc_type: bool = False,
        is_geo_or_region: bool = False,
    ):
        uc_type = "outlook"
        commentary_retrieved_documents = []
        llm = LCLLMFactory().get_llm(
            deployment_name_or_model_id=model_name_for_tool_classifier,
            temperature=temperature_for_tool_classfifer,
        )
        all_entities = entities.companies + entities.revenue_sources
        if subrouting_result == "entity":
            outlook_retriever = self.get_retrieval_path(query=query, llm=llm)
            vector_db_retrieved_documents, data_service_documents = [], []
            is_multiple_entity = True if len(all_entities) > 1 else False

            if outlook_retriever.require_documents:
                for entity in all_entities:
                    retrieved_documents = self.vector_db_retrieval(
                        query=query,
                        entity=entity,
                        subrouting_result=subrouting_result,
                        original_language=original_language,
                        uc_type=uc_type,
                    )
                    vector_db_retrieved_documents.extend(retrieved_documents)
            if is_geo_or_region:
                sorted_commentary_retrieved_documents = []
                commentary_retrieved_documents, scores = self.vector_stores_dict["commentary"].get_relevant_documents(
                    query,
                    efficient_filter=None,
                    model_id=config_machinery.get_config_value(Constants.OpenSearch.NEURAL_SEARCH_MODEL_ID),
                    search_pipeline=config_machinery.get_config_value(
                        Constants.OpenSearch.HYBRID_SEARCH_SEARCH_PIPELINE_ID
                    ),
                    top_k_text_chunks=self.top_k_text_research,
                )

                ranked_commentary_retrieved_documents = get_reranked_documents(
                    query=query,
                    retrieved_documents=commentary_retrieved_documents,
                    entity=None,
                    reranker_client=self.reranker_client,
                    reranker_endpoint_name=self.reranker_endpoint_name,
                    reranker_threshold=None,
                    top_k_text_chunks=self.top_k_text_research_double_rerank,
                )

                sorted_commentary_retrieved_documents.append(Document(content=("<commentary>")))

                sorted_commentary_retrieved_documents.extend(
                    get_sorted_docs_by_date(
                        ranked_commentary_retrieved_documents, self.top_k_text_research_recency_bias_final
                    )
                )

                sorted_commentary_retrieved_documents.append(Document(content=("</commentary>")))

                vector_db_retrieved_documents.extend(sorted_commentary_retrieved_documents)

            # vector_db_retrieved_documents = get_sorted_docs_by_date(vector_db_retrieved_documents, 20)

            if outlook_retriever.require_data_service and ((not is_multiple_entity) or entities.revenue_sources):
                data_service_documents = call_data_service(
                    query=query,
                    model_name_for_data_service=model_name_for_data_service,
                    entities=entities,
                    uc_type=uc_type,
                    sectors=sectors,
                    original_language=original_language,
                    original_query=original_query,
                    multi_uc_type=multi_uc_type,
                )

            vector_db_retrieved_documents = add_unstructured_source(vector_db_retrieved_documents)
            data_service_documents = add_structured_source(data_service_documents)
            query_documents = self._combine_documents(
                structured_documents=data_service_documents, unstructured_documents=vector_db_retrieved_documents
            )
            logger.info(f"Total number of retrieved documents : {len(query_documents)}")
            return query_documents
        elif subrouting_result == "macro":
            all_documents = []
            if all_entities:
                for entity in all_entities:
                    retrieved_documents = self.vector_db_retrieval(
                        query=query,
                        entity=entity,
                        subrouting_result=subrouting_result,
                        original_language=original_language,
                        uc_type=uc_type,
                    )
                    all_documents.extend(retrieved_documents)

            retrieved_documents = self.vector_db_retrieval(
                query=query,
                entity=None,
                subrouting_result=subrouting_result,
                original_language=original_language,
                uc_type=uc_type,
            )
            all_documents.extend(retrieved_documents)
            vector_db_retrieved_documents = get_reranked_documents(
                query=query,
                retrieved_documents=all_documents,
                entity=None,
                reranker_client=self.reranker_client,
                reranker_endpoint_name=self.reranker_endpoint_name,
                reranker_threshold=None,
                top_k_text_chunks=self.top_k_text_research_double_rerank,
            )
            vector_db_retrieved_documents = get_sorted_docs_by_date(
                vector_db_retrieved_documents, self.top_k_text_research_recency_bias_final
            )
            logger.info(f"Total number of retrieved documents : {len(vector_db_retrieved_documents)}")
            return vector_db_retrieved_documents
        else:
            raise ValueError(f"Invalid subrouting result: {subrouting_result}")

    def vector_db_retrieval(
        self,
        query: str,
        entity: Union[Companies, RevenueSource],
        subrouting_result: str,
        original_language: str,
        uc_type: str,
    ):
        if subrouting_result == "entity":
            query = self.rephrased_query(query, entity)
            filters, relevant_article_ids = get_filters_for_research(
                vector_stores_dict=self.vector_stores_dict, entity=entity, uc_type=uc_type
            )
            if not relevant_article_ids:
                return get_default_answer(
                    entity=entity, reason="no_relevant_articles", original_language=original_language, query=query
                )

            logger.info(f"filter applied for research docs : {filters}")
            retrieved_documents, scores = self.vector_stores_dict["research"].get_relevant_documents(
                query,
                efficient_filter=filters,
                model_id=config_machinery.get_config_value(Constants.OpenSearch.NEURAL_SEARCH_MODEL_ID),
                search_pipeline=config_machinery.get_config_value(
                    Constants.OpenSearch.HYBRID_SEARCH_SEARCH_PIPELINE_ID
                ),
                top_k_text_chunks=self.top_k_text_research,
            )

            retrieved_documents = get_reranked_documents(
                query=query,
                retrieved_documents=retrieved_documents,
                entity=entity,
                reranker_client=self.reranker_client,
                reranker_endpoint_name=self.reranker_endpoint_name,
                reranker_threshold=(
                    None
                    if isinstance(entity, RevenueSource)
                    else config_machinery.get_config_value(Constants.GeneralConstants.DEFAULT_RERANKER_THRESHOLD)
                ),
                top_k_text_chunks=self.top_k_text_research_double_rerank,
            )

            retrieved_documents = self.add_additional_metadata_to_documents(
                uc_type="outlook", user_query=query, entity=entity, documents=retrieved_documents
            )
            retrieved_documents = post_process_retrieved_docs(retrieved_documents)
            if not retrieved_documents:
                return get_default_answer(
                    entity=entity, reason="no_relevant_articles", original_language=original_language, query=query
                )
            retrieved_documents_with_tags = []
            entity_name = retrieved_documents[0].metadata.get("aggLegalEntityName", "").partition(";")[0].strip()
            retrieved_documents_with_tags.append(
                Document(
                    content=(f"<{entity_name}>"),
                ),
            )
            retrieved_documents = get_sorted_docs_by_date(
                retrieved_documents, self.top_k_text_research_recency_bias_final
            )
            retrieved_documents_with_tags.extend(retrieved_documents)
            retrieved_documents_with_tags.append(
                Document(
                    content=(f"</{entity_name}>"),
                ),
            )
            return retrieved_documents_with_tags

        elif subrouting_result == "macro":
            query = self.rephrased_query(query, entity)
            if entity:
                filters, relevant_article_ids = get_filters_for_research(
                    vector_stores_dict=self.vector_stores_dict, entity=entity, uc_type=subrouting_result
                )
                if not relevant_article_ids:
                    filters = None
            else:
                filters = None
            index_name = "commentary" if entity is None else "research"
            logger.info(f"filter applied for research docs : {filters}")
            retrieved_documents, scores = self.vector_stores_dict[index_name].get_relevant_documents(
                query,
                efficient_filter=filters,
                model_id=config_machinery.get_config_value(Constants.OpenSearch.NEURAL_SEARCH_MODEL_ID),
                search_pipeline=config_machinery.get_config_value(
                    Constants.OpenSearch.HYBRID_SEARCH_SEARCH_PIPELINE_ID
                ),
                top_k_text_chunks=self.top_k_text_research,
            )
            for doc in retrieved_documents:
                if doc.metadata.get("chunk_title") is None:
                    doc.metadata["chunk_title"] = ""

            retrieved_documents = get_reranked_documents(
                query=query,
                retrieved_documents=retrieved_documents,
                entity=entity,
                reranker_client=self.reranker_client,
                reranker_endpoint_name=self.reranker_endpoint_name,
                reranker_threshold=None,
                top_k_text_chunks=self.top_k_text_research_double_rerank,
            )
            retrieved_documents = self.add_additional_metadata_to_documents(
                uc_type="outlook", user_query=query, entity=entity, documents=retrieved_documents
            )

            top_k_text_final = (
                self.top_k_text_reduced_research
                if (entity and not filters)
                else self.top_k_text_research_recency_bias_final
            )
            retrieved_documents = get_sorted_docs_by_date(retrieved_documents, top_k_text_final)

            return retrieved_documents
        else:
            raise ValueError(f"Invalid subrouting result: {subrouting_result}")

    def _combine_documents(
        self, structured_documents: Union[Document, TableDocument], unstructured_documents: List[Document]
    ) -> Union[List[Document], TableDocument]:
        if structured_documents and unstructured_documents:
            combined_result_document = []
            combined_result_document.extend(structured_documents)
            combined_result_document.extend(unstructured_documents)
            return combined_result_document
        elif structured_documents:
            return structured_documents
        elif unstructured_documents:
            return unstructured_documents
        else:
            return []

    def get_retrieval_path(self, query: str, llm: BaseLanguageModel):
        prompt_template = SimplePromptTemplate(OUTLOOK_PROMPTS)
        prompt = prompt_template.format(
            **{
                "question": query,
                "examples": OUTLOOK_EXAMPLES,
            }
        )
        parser = PydanticOutputParser(pydantic_object=OutlookRetrieverModel)

        logger.debug(f"Outlook's finding retriever's path for LLM : {prompt}")
        response = llm.invoke(prompt)

        if isinstance(response, AIMessage):
            response = response.content

        try:
            parsed_query = parser.parse(response)
            logger.info(f"Parsed Query for Outlook retriever path LLM's parsed query : {parsed_query}")
            return parsed_query
        except OutputParserException as e:
            logger.error(f"Validation error at from Outlook retriever path's llm extraction {e}.")
            raise e

    # def process_retrieved_documents(
    #     self,
    #     retrieved_documents,
    #     query,
    #     entity,
    #     original_language,
    #     top_k_text_sorted_chunks=None,
    #     is_geo_or_region=False,
    # ):

    #     if is_geo_or_region:
    #         top_k = self.top_k_text_research_rerank if top_k_text_sorted_chunks is None else top_k_text_sorted_chunks
    #         retrieved_documents = get_sorted_docs_by_date(retrieved_documents, top_k)
    #     else:
    #         retrieved_documents = self.add_additional_metadata_to_documents(
    #             uc_type="outlook", user_query=query, entity=entity, documents=retrieved_documents
    #         )
    #         if not retrieved_documents:
    #             return get_default_answer(
    #                 entity=entity, reason="no_relevant_articles", original_language=original_language, query=query
    #             )
    #         retrieved_documents_with_tags = []
    #         entity_name = retrieved_documents[0].metadata.get("aggLegalEntityName", "").partition(";")[0].strip()
    #         retrieved_documents_with_tags.append(
    #             Document(
    #                 content=(f"<{entity_name}>"),
    #             ),
    #         )
    #         top_k = self.top_k_text_research_rerank if top_k_text_sorted_chunks is None else top_k_text_sorted_chunks
    #         retrieved_documents = get_sorted_docs_by_date(retrieved_documents, top_k)
    #         retrieved_documents_with_tags.extend(retrieved_documents)
    #         retrieved_documents_with_tags.append(
    #             Document(
    #                 content=(f"</{entity_name}>"),
    #             ),
    #         )
    #     return retrieved_documents_with_tags
