import { IBlog } from '../blog/Blog';

export function mockBlogsData(isEmptyResult?: boolean, overrides?: Partial<IBlog>): IBlog {
  return overrides || isEmptyResult
    ? {
        EditorsPicksData: [],
        FeatureActiveResult: [],
        FeatureNameData: [],
        FeatureNewsData: [],
      }
    : {
        EditorsPicksData: [],
        FeatureActiveResult: [],
        FeatureNameData: [],
        FeatureNewsData: [
          {
            KeyDoc: 34319613,
            KeyArticleType: 72,
            ArticleType: 'Conference Chatter',
            Headline: "Sony's PlayStation event dazzles during Paris Games Week",
            ArticlePostDateAll: '2021-12-06T12:19:00',
            ArticleAmendmentCount: null,
            ArticleMarketingBadge: 'Blog',
            ArticleTypeBlog: 1,
            ArticleTypeGroup: 'Blog',
            KeyDoc_ImageKeyDoc: 11205361,
            FilePath_FilePath: 'Articles\\hpimages\\9560281.jpg',
            FormOrder: 1000,
            DocAbstract:
              "While the import of the announcements at Sony's invite-only Oct. 27 event was not as big as that of news released earlier this year during E3, Sony still managed to keep the audience pumped, with announcements about exclusive deals, new titles and VR tie-ins.",
            IndustryShortName: 'Internet and Direct Marketing Retail',
            Id: 0,
          },
          {
            KeyDoc: 36824014,
            KeyArticleType: 72,
            ArticleType: 'Conference Chatter',
            Headline: 'All Xbox, all day at E3',
            ArticlePostDateAll: '2021-12-06T12:19:00',
            ArticleAmendmentCount: null,
            ArticleMarketingBadge: 'Blog',
            ArticleTypeBlog: 1,
            ArticleTypeGroup: 'Blog',
            KeyDoc_ImageKeyDoc: 36823954,
            FilePath_FilePath: 'Articles\\hpimages\\34741666.jpg',
            FormOrder: 1000,
            DocAbstract:
              'Microsoft came out with all guns blazing at the 2016 Xbox E3 press conference.',
            IndustryShortName: 'Systems Software',
            Id: 1,
          },
          {
            KeyDoc: 66397936,
            KeyArticleType: 36,
            ArticleType: 'Street Talk',
            Headline: 'Pickup in bank M&A could have domino effect',
            ArticlePostDateAll: '2021-12-01T13:42:00',
            ArticleAmendmentCount: null,
            ArticleMarketingBadge: 'Blog',
            ArticleTypeBlog: 1,
            ArticleTypeGroup: 'Blog',
            KeyDoc_ImageKeyDoc: null,
            FilePath_FilePath: 'Platform09/features/largewp_streettalk.jpg',
            FormOrder: 3800,
            DocAbstract:
              'In the latest Street Talk podcast, Collyn Gilbert, director of strategy at Valley National Bancorp, discussed M&A, balancing branches against digital channels, competition from neobanks, and operating with dual markets in the Northeast and Florida.',
            IndustryShortName: 'Banking',
            Id: 2,
          },
        ],
      };
}
