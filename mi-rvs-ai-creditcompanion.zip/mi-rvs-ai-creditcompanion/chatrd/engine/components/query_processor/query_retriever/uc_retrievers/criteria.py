import logging
from typing import Dict

from botocore.client import BaseClient
from pydantic import BaseModel

from chatrd.core.vectorstore import OpenSearch
from chatrd.engine.components.query_analyzer.entity_extractor.utils import Entities
from chatrd.engine.components.query_processor.query_retriever.reranker import (
    get_reranked_documents,
)
from chatrd.engine.components.query_processor.query_retriever.uc_retrievers.base import (
    UCRetriever,
)
from chatrd.engine.components.query_processor.query_retriever.utils import (
    add_unstructured_source,
)
from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.utils import (
    get_custom_criteria_type_filter,
    get_default_criteria_type_filter,
    sector_map,
)

logger = logging.getLogger(__name__)

config_machinery = get_config_machinery()


class CriteriaRetriever(UCRetriever):
    def __init__(self, vector_stores_dict: Dict[str, OpenSearch], reranker_client: BaseClient):
        self.vector_stores_dict = vector_stores_dict
        self.model_id = config_machinery.get_config_value(Constants.OpenSearch.HYBRID_SEARCH_SEARCH_PIPELINE_ID)
        self.filters = get_default_criteria_type_filter()
        self.reranker_client = reranker_client
        self.reranker_endpoint_name = config_machinery.get_config_value(
            Constants.SageMaker.SAGEMAKER_RERANKER_ENDPOINT_NAME
        )
        self.top_k_text_criteria = config_machinery.get_config_value(Constants.GeneralConstants.TOP_K_TEXT_CRITERIA)
        self.top_k_table_criteria = config_machinery.get_config_value(Constants.GeneralConstants.TOP_K_TABLE_CRITERIA)
        self.top_k_text_criteria_rerank = config_machinery.get_config_value(
            Constants.GeneralConstants.TOP_K_TEXT_CRITERIA_RERANK
        )

    def retrieve(self, query: str, entities: Entities, sectors: BaseModel, multi_uc_type: bool = False):
        vector_db_retrieved_documents = self.vector_db_retrieval(query=query, entities=entities, sector=sectors.sector)
        logger.info(f"Total number of retrieved documents : {len(vector_db_retrieved_documents)}")
        vector_db_retrieved_documents = add_unstructured_source(vector_db_retrieved_documents)
        return vector_db_retrieved_documents

    def vector_db_retrieval(self, query: str, entities: Entities, sector: BaseModel):
        filters = self.filters
        if sector and sector.lower() != "general":
            # match_list, field = sector_map[sector.lower()]
            filters = None
        else:
            filters = None
        logger.info(f"filter applied for criteria docs : {filters}")
        retrieved_documents, scores = self.vector_stores_dict["criteria"].get_relevant_documents(
            query=query,
            efficient_filter=filters,
            model_id=config_machinery.get_config_value(Constants.OpenSearch.NEURAL_SEARCH_MODEL_ID),
            search_pipeline=config_machinery.get_config_value(Constants.OpenSearch.HYBRID_SEARCH_SEARCH_PIPELINE_ID),
            top_k_text_chunks=self.top_k_text_criteria,
            top_k_table_chunks=self.top_k_table_criteria,
        )
        logger.info(f"Number of Retrieved Documents: {len(retrieved_documents)}")

        retrieved_documents = get_reranked_documents(
            query=query,
            retrieved_documents=retrieved_documents,
            entity=None,
            reranker_client=self.reranker_client,
            reranker_endpoint_name=self.reranker_endpoint_name,
            reranker_threshold=None,
            top_k_text_chunks=self.top_k_text_criteria_rerank,
        )
        retrieved_documents = self.add_additional_metadata_to_documents(
            uc_type="criteria", user_query=query, entity=None, documents=retrieved_documents
        )

        logger.info(f"Number of Retrieved Documents after reranking: {len(retrieved_documents)}")

        if entities.companies:
            # return retrieved_documents[: self.top_k]
            return retrieved_documents[: self.top_k_text_criteria]

        return retrieved_documents
