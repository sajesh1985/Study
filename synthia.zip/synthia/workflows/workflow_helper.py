import os
from typing import Any, List, Optional
import traceback
from langgraph.types import Command
import logging
from datetime import datetime
from src.synthia.agents.agent_factory import AgentFactory
from src.synthia.schemas.workflow import ReportConfig, ReportStatus, ReportStatusEnum
from src.synthia.utils.logging_config import configure_logging
from src.synthia.workflows.simple_graph import create_report_graph
from src.synthia.agents.report_builder import ReportBuilder
from src.synthia.persistence.report_monitor import ReportMonitor


# Initialize logger using centralized configuration
logger = configure_logging(
    log_file="synthia.log",
    module_levels={__name__: logging.DEBUG},  # Set this module to DEBUG
)


class ReportWorkflow:
    def __init__(self, graph, initial_state, agent_factory: AgentFactory, config=None):
        self.graph = graph
        self.initial_state = initial_state
        self.agent_factory = agent_factory
        self.config = config
        self.thread_id = None

    @classmethod
    async def create_workflow(
        cls, data: ReportConfig, callbacks: Optional[List[Any]] = None
    ):

        logger.info(f"Creating LangGraph report for report config: {data}")

        thread_id = data["job_id"]
        config = {"configurable": {"thread_id": thread_id}}

        if data["auth_token"]:
            auth_token = data["auth_token"]
        else:
            auth_token = os.getenv("MCP_AUTH_TOKEN")

        agent_factory = AgentFactory(auth_token, callbacks=callbacks)
        thread_config = {"callbacks": None, "thread_id": thread_id}
        report_builder = ReportBuilder(agent_factory, thread_config)
        graph = await create_report_graph(report_builder=report_builder)

        # Initialize the graph with the starting state
        initial_state = {
            "report_config": data,
            "current_section_idx": 0 if data.get("approved_outline") else None,
            "status": "initializing",
            "progress": 0.0,
            "error": None,
            "human_approved_outline": (True if data.get("approved_outline") else False),
            "human_approved_report": False,
            "human_feedback_report": None,
            "job_id": data["job_id"],
            "report_outline": [],
            "all_sections": [],
        }
        return cls(graph, initial_state, agent_factory, config)

    async def start_workflow(self, status_tracker: Optional[ReportMonitor] = None):
        """Start the workflow and handle all initial scenarios."""
        self.thread_id = self.config["configurable"]["thread_id"]
        job_id = self.thread_id

        try:
            logger.info(f"Starting workflow with thread_id: {self.thread_id}")
            
            if status_tracker:
                await status_tracker.update_job_status(job_id, ReportStatusEnum.CREATING_OUTLINE)
            
            result = await self.graph.ainvoke(self.initial_state, config=self.config)
            
            # Handle result and update status tracker if provided
            workflow_result = self._handle_result(result)
            
            if status_tracker:
                await self._update_status_from_result(workflow_result, status_tracker)
            
            return workflow_result
            
        except Exception as e:
            logger.error(f"Error starting workflow: {str(e)}")
            logger.error(traceback.format_exc())
            
            if status_tracker:
                tb = traceback.format_exc()
                await status_tracker.set_job_error(job_id, f"{str(e)}\n\nStack trace:\n{tb}")
            
            return {"error": str(e)}

    async def resume_workflow(self, user_input: Any = None, approved: bool = True, status_tracker: Optional[ReportMonitor] = None):
        """Resume workflow after any type of human input."""
        if not self.config:
            raise ValueError("Workflow not started. Call start_workflow() first.")

        self.thread_id = self.config["configurable"]["thread_id"]
        job_id = self.thread_id

        try:
            logger.info(f"Resuming workflow with input: {user_input}, approved: {approved}")

            if status_tracker:
                await status_tracker.update_job_status(job_id, ReportStatusEnum.CREATING_REPORT)

            if not approved and status_tracker:
                # Handle rejection - restart workflow
                report_state = await status_tracker.get_job(job_id)
                await status_tracker.restart_job(job_id)
                
                # Create new workflow with updated config
                config = report_state.report_config
                config["job_id"] = job_id
                new_workflow = await self.create_workflow(config)
                return await new_workflow.start_workflow(status_tracker)

            result = await self.graph.ainvoke(Command(resume=user_input), config=self.config)
            workflow_result = self._handle_result(result)
            
            if status_tracker:
                await self._update_status_from_result(workflow_result, status_tracker)
            
            return workflow_result

        except Exception as e:
            logger.error(f"Error resuming workflow: {str(e)}")
            logger.error(traceback.format_exc())
            
            if status_tracker:
                tb = traceback.format_exc()
                await status_tracker.set_job_error(job_id, f"{str(e)}\n\nStack trace:\n{tb}")
            
            return {"error": str(e)}

    async def _update_status_from_result(self, workflow_result: dict, status_tracker: ReportMonitor):
        """Update status tracker based on workflow result."""
        job_id = self.thread_id
        status = workflow_result.get("status")
        data = workflow_result.get("data", {})
        
        if status == "interrupted":
            if "report_outline" in data:
                # Outline approval interrupt
                outline_result = data.get("report_outline", []) or data.get("outline", [])
                report = ReportStatus(outline=outline_result, job_id=job_id, status=ReportStatusEnum.AWAITING_APPROVAL)
                await status_tracker.update_job(job_id, report)
                logger.info("Outline generated, awaiting user approval")
                
            elif "final_report" in data:
                # Final report already generated
                all_sections = data.get("all_sections")
                if all_sections:
                    import json
                    final_report = json.dumps(all_sections, indent=2)
                else:
                    final_report = data.get("final_report")
                
                report = ReportStatus(sections=final_report, job_id=job_id, status=ReportStatusEnum.COMPLETED)
                await status_tracker.update_job(job_id, report)
                logger.info("Final report generated and completed")
                
        elif status == "interrupt_final_report_approval":
            # Final report approval interrupt
            final_report_data = data
            all_sections = final_report_data.get("all_sections")
            if all_sections:
                import json
                final_report = json.dumps(all_sections, indent=2)
            else:
                final_report = final_report_data.get("final_report", "")
            await status_tracker.set_awaiting_final_approval(job_id, final_report)
            logger.info("Final report generated, awaiting user approval")
            
        elif status == "completed":
            # Workflow completed
            final_report = data.get("final_report")
            
            await status_tracker.update_job(
                job_id,
                ReportStatus(
                    job_id=job_id,
                    sections=final_report,
                    status="completed",
                    progress=1.0,
                    completed_at=datetime.now().isoformat(),
                ),
            )
            logger.info(f"Workflow completed successfully")

    def _handle_result(self, result: Any):
        """Handle the result and determine workflow status."""
        logger.debug(f"Handling workflow result: {type(result)}")

        # Interrupts (LangGraph)
        if isinstance(result, dict) and "__interrupt__" in result:
            interrupts = result["__interrupt__"]
            if interrupts:
                interrupt_data = interrupts[0].value
                if "final_report" in interrupt_data:
                    logger.info("Detected final report approval interrupt")
                    final_report = result.get("final_report") or interrupt_data.get("final_report")
                    if final_report:
                        import json
                        interrupt_data["final_report"] = json.dumps(final_report, indent=2)
                    return {
                        "status": "interrupt_final_report_approval",
                        "data": interrupt_data,
                        "thread_id": self.thread_id,
                    }
                if "report_outline" in interrupt_data:
                    logger.info("Detected outline approval interrupt")
                    return {
                        "status": "interrupted",
                        "data": interrupt_data,
                        "thread_id": self.thread_id,
                    }
        
        # Completed workflow
        if self._is_workflow_complete(result):
            return {
                "status": "completed",
                "data": result,
                "thread_id": self.thread_id,
            }
            
        return {
            "status": "unknown",
            "data": result,
            "thread_id": self.thread_id,
        }

    def _is_workflow_complete(self, result):
        """Check if the workflow has completed."""
        if isinstance(result, dict):
            return (
                result.get("final_report") is not None
                or result.get("status") == "completed"
                or (result.get("all_sections") and not result.get("final_report"))
            )
        return False
        
    # @classmethod
    # async def set_titles(cls, report_state, outline):
    #     if report_state.outline:
    #         from src.synthia.workflows.report_graph import generate_title
            
    #         # Collect all title generation tasks
    #         title_tasks = []
    #         for idx, user_section in enumerate(report_state.outline):
    #             selected_content = user_section.description
    #             logger.info(
    #                 f"Updating outline for section {idx} with section content: {selected_content}"
    #             )
    #             title_tasks.append(generate_title(user_prompt=selected_content))
            
    #         # Execute all title generation tasks in parallel
    #         generated_titles = await asyncio.gather(*title_tasks)
            
    #         # Update the outline with the generated titles
    #         for idx, (user_section, selected_title) in enumerate(zip(report_state.outline, generated_titles)):
    #             selected_content = user_section.description
    #             logger.info(f"Generated title for section: {selected_title}")
    #             # Update the Section object directly
    #             if selected_title is None or selected_title.strip() == "":
    #                 outline[idx].name = selected_content.strip()
    #             else:
    #                 outline[idx].name = selected_title.strip()
    #             outline[idx].description = selected_content

    # @classmethod
    # async def restart_report_generation(
    #     cls,
    #     job_id: str,
    #     token: str,
    #     status_tracker,
    #     num_sections: Optional[int] = None,
    #     depth: Optional[int] = None,
    # ):
    #     """Restart report generation with new parameters."""
    #     await status_tracker.restart_job(job_id, num_sections, depth)
    #     state = await status_tracker.get_job(job_id)
    #     await cls.process_report_generation(
    #         job_id=job_id,
    #         topic=state.get("topic"),
    #         style=state.get("style", "business"),
    #         depth=state.get("depth", 3),
    #         num_sections=state.get("num_sections", 5),
    #         token=token,
    #         status_tracker=status_tracker,
    #     )
