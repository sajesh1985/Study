from dataclasses import dataclass
from typing import Dict, List, Optional, Union

from chatrd.core.document import Document, TableDocument
from chatrd.core.utils import MessageRole

sector_map = {
    "corporates": (["Corporates", "Utilities"], "primarySubSectorDesc"),
    "financial institutions": (["Financial Institutions"], "primarySubSectorDesc"),
    "governments": (["Governments", "Sovereign Related", "Sovereigns", "Public Finance"], "primarySubSectorDesc"),
    "insurance": (["Insurance"], "primarySubSectorDesc"),
    "infrastructure": (
        [
            "Corporates",
            "Utilities",
            "Social",
        ],
        "primarySubSectorDesc",
    ),
    "structured finance": (["Structured Finance"], "primarySectorDesc"),
}


def get_default_criteria_type_filter():
    return {
        "bool": {
            "must": [
                {"match": {"metadata.aggRDSectorDesc": None}},
            ],
            "must_not": [
                {"match": {"metadata.SourceTitle": "Table Of Contents:"}},
            ],
        }
    }


def get_custom_criteria_type_filter(match_list: List[str], field: str) -> Dict:
    """
    Returns a filter for the given match list and field

    Args:
        match_list : List of values to match
        field : Field to match with

    Returns:
        Dict : Filter dictionary
    """
    return {
        "bool": {
            "must": [
                {"terms": {f"metadata.{field}.keyword": match_list}},
            ],
            "must_not": [
                {"match": {"metadata.SourceTitle": "Table Of Contents:"}},
            ],
        }
    }


def get_default_criteria_nested_type_filter():
    return {
        "nested": {
            "path": "metadata",
            "query": {
                "bool": {
                    "must": [
                        {"match": {"metadata.TYPE_OF_CRITERIA": None}},
                    ]
                }
            },
        }
    }


def get_default_research_type_filter():
    return {"bool": {"should": [{"regexp": {"metadata.aggPrimarykeyInstn": None}}]}}


def get_default_research__nested_type_filter():
    return {
        "nested": {
            "path": "metadata",
            "query": {"bool": {"should": [{"regexp": {"metadata.aggPrimarykeyInstn": None}}]}},
        }
    }


@dataclass
class ChatResponse:
    """Chat response."""

    role: MessageRole = MessageRole.ASSISTANT
    content: List[Optional[Dict]] = None
    source_docs: List[Optional[Union[Document, TableDocument]]] = None
    cited_docs: List[Optional[Union[Document, TableDocument]]] = None
    unauthorized_docs: List[Optional[Union[Document, TableDocument]]] = None
    failure_step: Optional[str] = None


@dataclass
class CitedSourceList:
    """Chat response. As filtered sources"""

    sources: List[Optional[Document]] = None


def make_unique(items, exclude=None):
    """
    Remove duplicates from a list while preserving order.
    Optionally exclude specific items.

    Args:
        items (list): The input list.
        exclude (list, optional): List of items to exclude. Defaults to None.

    Returns:
        list: A list with duplicates removed, order preserved, and excluded items filtered out.
    """
    if exclude is None:
        exclude = []

    seen = set()
    result = []
    for item in items:
        if item in exclude:
            continue
        if item not in seen:
            seen.add(item)
            result.append(item)
    return result
