import logging

from pydantic import BaseModel

from chatrd.engine.components.query_analyzer.entity_extractor.utils import Entities
from chatrd.engine.components.query_processor.query_retriever.data_service_retriever import (
    call_data_service,
)
from chatrd.engine.components.query_processor.query_retriever.uc_retrievers.base import (
    UCRetriever,
)
from chatrd.engine.components.query_processor.query_retriever.utils import (
    add_structured_source,
)

logger = logging.getLogger(__name__)


class InfoCoverageUCRetriever(UCRetriever):
    def retrieve(
        self,
        query: str,
        uc_type: str,
        entities: Entities,
        model_name_for_data_service: str,
        temperature_for_data_service: float,
        sectors: BaseModel,
        original_language: str,
        original_query: str,
        multi_uc_type: bool = False,
    ):
        query_documents = call_data_service(
            query=query,
            uc_type=uc_type,
            model_name_for_data_service=model_name_for_data_service,
            entities=entities,
            sectors=sectors,
            original_language=original_language,
            original_query=original_query,
            multi_uc_type=multi_uc_type,
        )
        logger.info(f"Total number of retrieved documents : {len(query_documents)}")
        query_documents = add_structured_source(query_documents)
        return query_documents

    def vector_db_retrieval(
        self,
    ):
        pass
