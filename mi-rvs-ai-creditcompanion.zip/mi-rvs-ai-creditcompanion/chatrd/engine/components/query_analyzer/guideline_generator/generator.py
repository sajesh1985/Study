import logging
from datetime import date
from typing import Dict, Optional

from pydantic import BaseModel

from chatrd.core.llm import LCLLMFactory
from chatrd.core.llm.components.message import AIMessage
from chatrd.core.llm.parsers import OutputParserException, PydanticOutputParser
from chatrd.core.llm.prompt.template import SimplePromptTemplate
from chatrd.engine.components.query_analyzer.faulttolerantexecutor import (
    FaultTolerantExecutor,
)
from chatrd.engine.components.query_analyzer.guideline_generator.map_guidelines import (
    MAPPED_UC_GUIDELINES_TEMPLATE,
)
from chatrd.engine.components.query_analyzer.guideline_generator.utils import (
    ExtractedGuidelines,
)
from chatrd.engine.components.query_analyzer.uc_subrouting.outlook_macro_entity import (
    OutlookSubrouting,
)
from chatrd.engine.components.query_analyzer.utils import EntityType, UCType
from chatrd.engine.components.schema import ComponentsOutput
from chatrd.engine.prompts import EXPERT_GUIDELINES
from chatrd.engine.responses import get_default_answer

logger = logging.getLogger(__name__)


class GuidelineGenerator(FaultTolerantExecutor):
    def __init__(self, model_name: str, temperature: Optional[float] = 0.0):
        self.model = LCLLMFactory().get_llm(
            deployment_name_or_model_id="haiku",
            temperature=temperature,
        )

    def run(
        self,
        query: str,
        uc_type: str,
        entity_type: EntityType,
        original_message: str,
        subrouting_result: Optional[OutlookSubrouting] = None,
        structured_data_exists: Optional[bool] = False,
    ) -> ComponentsOutput(ExtractedGuidelines):
        if entity_type == EntityType.SECURITY:
            return ExtractedGuidelines(guidelines="")
        if uc_type == "general":
            uc_type = "macro"
        if uc_type in [
            UCType.RATINGS.value,
            UCType.RATING_ACTION.value,
            UCType.ESG.value,
            UCType.FINANCIALS.value,
            UCType.RESEARCH.value,
            UCType.PEERS.value,
            UCType.CREDIT_MEMO.value,
            UCType.SECURITIES.value,
        ]:
            prompt, guidelines = MAPPED_UC_GUIDELINES_TEMPLATE[uc_type].get_template(type=entity_type)
            utilities = self._get_utils_for_llm(
                query,
                prompt,
                guidelines,
                ExtractedGuidelines,
            )
        elif uc_type in [
            UCType.SWOT.value,
        ]:
            if entity_type:
                prompt, guidelines = MAPPED_UC_GUIDELINES_TEMPLATE[uc_type].get_template(type=entity_type)
            else:
                prompt, guidelines = MAPPED_UC_GUIDELINES_TEMPLATE[uc_type].get_template(type="macro")
            utilities = self._get_utils_for_llm(
                query,
                prompt,
                guidelines,
                ExtractedGuidelines,
            )

        elif uc_type in [
            UCType.OUTLOOK.value,
        ]:
            if subrouting_result == "macro":
                prompt, guidelines = MAPPED_UC_GUIDELINES_TEMPLATE[uc_type].get_template(type="macro")
                today_date = date.today()
                utilities = self._get_utils_for_llm(
                    query,
                    prompt,
                    guidelines,
                    ExtractedGuidelines,
                    examples_kwargs={"today_date": today_date, "current_year": today_date.year},
                )
            else:
                prompt, guidelines = MAPPED_UC_GUIDELINES_TEMPLATE[uc_type].get_template(type=entity_type)
                utilities = self._get_utils_for_llm(
                    query,
                    prompt,
                    guidelines,
                    ExtractedGuidelines,
                )
        elif uc_type in [
            UCType.DEFINITION.value,
            UCType.DEALS_TRANCHE.value,
            UCType.FLEX_ARCH.value,
        ]:
            prompt, guidelines = MAPPED_UC_GUIDELINES_TEMPLATE[uc_type].get_template(type=None)
            utilities = self._get_utils_for_llm(
                query,
                prompt,
                guidelines,
                ExtractedGuidelines,
            )
        elif uc_type == UCType.QUERY.value:
            logger.info("No guidelines prompt is implemented for query uc_type related question.")
            return ExtractedGuidelines(guidelines="")
        elif uc_type in [
            UCType.GENERAL.value,
            UCType.CRITERIA.value,
        ]:
            if structured_data_exists is True:
                prompt, guidelines = MAPPED_UC_GUIDELINES_TEMPLATE[uc_type].get_template(type="structured_data_exists")
            else:
                prompt, guidelines = MAPPED_UC_GUIDELINES_TEMPLATE[uc_type].get_template(
                    type="structured_data_not_exists"
                )

            utilities = self._get_utils_for_llm(
                query,
                prompt,
                guidelines,
                ExtractedGuidelines,
            )
        elif uc_type in [
            UCType.MACRO.value,
        ]:
            today_date = date.today()
            if structured_data_exists is True:
                prompt, guidelines = MAPPED_UC_GUIDELINES_TEMPLATE[uc_type].get_template(
                    type="structured_data_exists",
                )
                utilities = self._get_utils_for_llm(
                    query,
                    prompt,
                    guidelines,
                    ExtractedGuidelines,
                    examples_kwargs={"today_date": today_date},
                    today_date=today_date,
                )
            else:
                prompt, guidelines = MAPPED_UC_GUIDELINES_TEMPLATE[uc_type].get_template(
                    type="structured_data_not_exists",
                )
                utilities = self._get_utils_for_llm(
                    query,
                    prompt,
                    guidelines,
                    ExtractedGuidelines,
                    examples_kwargs={
                        "today_date": today_date,
                        "current_year": today_date.year,
                        "next_year": today_date.year + 1,
                        "last_year": today_date.year - 1,
                    },
                    today_date=today_date,
                )
        else:
            msg = f"No prompts relevant to provided use case type: {uc_type}"
            logger.error(msg)
            return get_default_answer()

        prompt, parser = utilities["prompt"], utilities["parser"]

        response = self.model.invoke(prompt)

        if isinstance(response, AIMessage):
            response = response.content

        logger.debug(f"Guideline generation prompt for LLM : {prompt}")

        try:
            guidelines = parser.parse(response)
            logger.debug(f"Generated Guidelines : {guidelines}")
            return guidelines
        except OutputParserException as e:
            logger.error(f"Validation error at from Guidelines' llm extraction {e}.")
            raise e

    def get_default_value(self) -> ComponentsOutput(ExtractedGuidelines):
        return ComponentsOutput(
            ExtractedGuidelines(
                guidelines=f"{EXPERT_GUIDELINES}",
            )
        )

    def _get_utils_for_llm(
        self,
        query: str,
        prompt_template_str: str,
        examples: str,
        pydantic_object: BaseModel,
        examples_kwargs: dict | None = None,
        **kwargs,
    ) -> Dict:
        if examples_kwargs is None:
            examples_kwargs = {}
        prompt_template = SimplePromptTemplate(template=prompt_template_str)
        formatted_examples = SimplePromptTemplate(template=examples).format(**examples_kwargs)
        prompt = prompt_template.format(**{"question": query, "examples": formatted_examples, **kwargs})
        parser = PydanticOutputParser(pydantic_object=pydantic_object)

        return {"prompt": prompt, "parser": parser}
