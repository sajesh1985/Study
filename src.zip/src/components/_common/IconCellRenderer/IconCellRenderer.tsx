import { faInfoCircle } from '@fortawesome/free-solid-svg-icons';
import { Icon } from '@spglobal/react-components';
//import { useState } from 'react';
import ReactTooltip from 'react-tooltip';
import { styles } from './IconCellRenderer.styles';

export const IconCellRenderer = (props:any) => {
  //const [tooltipVisible, setTooltipVisible] = useState(false);

  /*const checkHeader = (header:any) => {
    let keys = Object.keys(header);
    let isHeader = false;
    keys.forEach((key:any,index:any) => {
      if(key !== 'ItemName' && index<5)
      {
        if(header[key] === 'Product')
        {
          isHeader = true;
        }
      }
    });
  };

  const isHeader = checkHeader(props.data);*/

  return (
    <>
      {props.value && props.value !== '&nbsp;' ? (
        <div>
          <span dangerouslySetInnerHTML={{__html: !props.data.definition ? "<b>" + props.value + "</b>" : props.value }}></span>
          { props.data.definition && (<Icon icon={faInfoCircle} style={{ cursor: 'pointer' }} 
            data-tip={props.data.definition.ProductDefinition} data-for={`tooltip-${props.rowIndex}`} 
            />)}
          
          {props.data.definition && (
            <ReactTooltip id={`tooltip-${props.rowIndex}`} css={styles.customtooltip}>
              { props.data.definition.ProductDefinition} 
            </ReactTooltip>
          )}
          
        </div>
      ) : null}
    </>
  );
};
