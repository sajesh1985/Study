import json
import logging
from typing import Any, Optional, Type

from langchain_community.cache import SQLAlchemyCache
from langchain_core.caches import RETURN_VAL_TYPE
from langchain_core.load.dump import dumps
from langchain_core.load.load import loads
from langchain_core.outputs import Generation
from sqlalchemy import (
    Column,
    Integer,
    Sequence,
    String,
    Text,
    UniqueConstraint,
)

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy import delete
from sqlalchemy.engine.base import Engine
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()
logger = logging.getLogger(__file__)


class HashedLLMCache(Base):  # type: ignore
    """Postgres table for a hash-indexed LLM Cache."""

    __tablename__ = "llm_pg_cache"
    id = Column(Integer, Sequence("cache_id"), primary_key=True)
    # The prompt_hash is a unique hash of the prompt, used for fast lookups.
    prompt_hash = Column(String(64), nullable=False)

    # llm hash
    llm_hash = Column(String(64), nullable=False)

    llm = Column(Text, nullable=False)

    # The original prompt can be stored for debugging but is not indexed.
    constructed_prompt = Column(Text, nullable=False)

    original_prompt = Column(Text, nullable=False)

    idx = Column(Integer)
    response = Column(Text)

    __table_args__ = (
        # a unique, composite B-Tree index
        # It's unique because for a given LLM, a prompt should only have one cached response.
        UniqueConstraint(
            "llm_hash", "prompt_hash", name="uq_llm_prompt_mixhash_sha256"
        ),
    )


class AsyncPostGreSQLCache(SQLAlchemyCache):
    """Cache that uses an async PostGreSQL connection pool."""

    def __init__(
        self,
        engine: Engine,
        cache_schema: Type[HashedLLMCache] = HashedLLMCache,
    ):
        """Initialize by creating the async engine."""
        # Use create_async_engine for non-blocking connections
        # This will use psycopg_pool automatically with the "psycopg" driver
        self.engine = engine
        self.cache_schema = cache_schema

    async def initialize_schema(self) -> None:
        """A separate async method to create tables."""
        async with self.engine.begin() as conn:
            await conn.run_sync(self.cache_schema.metadata.create_all)

    @staticmethod
    def generate_prompt_hash(prompt: str) -> str:
        """Generate a unique hash for the prompt."""
        import hashlib

        return hashlib.sha256(prompt.encode("utf-8")).hexdigest()

    @staticmethod
    def extract_human_content(prompt: str) -> str:
        # Parse the JSON data
        data = json.loads(prompt)

        # Extract content where type is "human"
        human_contents = []
        for item in data:
            if item.get("kwargs", {}).get("type") == "human":
                human_contents.append(item["kwargs"]["content"])

        return " |||| ".join(human_contents)

    @staticmethod
    def construct_cache_prompt(prompt: str) -> str:
        def extract_human_content(element: dict, type: str) -> str | None:
            """Extract human content from a dictionary element."""
            try:
                if isinstance(element, dict):
                    return f"{type}: {element.get('kwargs', {}).get('content', '')}"
            except KeyError:
                logger.warning(
                    f"KeyError while extracting {type} content from element: {element}"
                )
            return None

        def extract_ai_content(element: dict, type: str) -> str | None:
            """Extract AI content from a dictionary element."""
            try:
                if isinstance(element, dict):
                    return f"{type}: {element.get('kwargs', {}).get('name', '')}"
            except KeyError:
                logger.warning(
                    f"KeyError while extracting {type} content from element: {element}"
                )
            return None

        def extract_tool_content(element: dict, type: str) -> str | None:
            """Extract tool content from a dictionary element."""
            try:
                if (status := element.get("kwargs", {}).get("status")) != "success":
                    return None
                if isinstance(element, dict):
                    return f"{type}: {element.get('kwargs', {}).get('name', '')} Status: {status}"
            except KeyError:
                logger.warning(
                    f"KeyError while extracting {type} content from element: {element}"
                )
            return None

        prompt_string = ""
        data = json.loads(prompt)
        for item in data:
            if (type := item.get("kwargs", {}).get("type")) in ["human", "system"]:
                content = extract_human_content(item, type)
                if content:
                    prompt_string += f"{content} |||| "

            if item.get("kwargs", {}).get("type") == "ai":
                content = extract_ai_content(item, type)
                if content:
                    prompt_string += f"{content} |||| "

            if item.get("kwargs", {}).get("type") == "tool":
                content = extract_tool_content(item, type)
                if content:
                    prompt_string += f"{content} |||| "

        prompt_string = prompt_string.strip()
        if prompt_string:
            return prompt_string
        else:
            logger.warning("No valid content found in the prompt for caching.")
            return ""

    async def alookup(self, prompt: str, llm_string: str) -> Optional[RETURN_VAL_TYPE]:
        """Look up based on prompt and llm_string, ignoring the ID."""
        logger.info(f"Async Looking up prompt: {prompt[:100]}...")  # Log first 100 chars
        constructed_prompt = self.construct_cache_prompt(prompt)
        llm_hash = self.generate_prompt_hash(llm_string)
        if not constructed_prompt:
            logger.warning("Constructed prompt is empty, skipping cache lookup.")
            return None
        prompt_hash = self.generate_prompt_hash(constructed_prompt)

        stmt = (
            select(self.cache_schema.response)
            .where(self.cache_schema.prompt_hash == prompt_hash)
            .where(self.cache_schema.llm_hash == llm_hash)
            .order_by(self.cache_schema.idx)
        )

        async with AsyncSession(self.engine) as session:
            # The execute call is now awaited
            result = await session.execute(stmt)
            rows = result.fetchall()
            if rows:
                try:
                    logger.info(f"Cache hit for prompt: {constructed_prompt[:100]}...")
                    return [loads(row[0]) for row in rows]
                except Exception:
                    logger.warning(
                        "Deserialization error. Recreating cache is recommended."
                    )
                    return [Generation(text=row[0]) for row in rows]
            logger.info(f"Cache miss for prompt: {constructed_prompt[:100]}...")
        return None

    async def aupdate(
        self, prompt: str, llm_string: str, return_val: RETURN_VAL_TYPE
    ) -> None:
        """Update based on prompt and llm_string, ignoring the ID."""
        constructed_prompt = self.construct_cache_prompt(prompt)
        prompt_hash = self.generate_prompt_hash(constructed_prompt)
        llm_hash = self.generate_prompt_hash(llm_string)
        items = [
            self.cache_schema(
                constructed_prompt=constructed_prompt,
                llm=llm_string,
                llm_hash=llm_hash,
                response=dumps(gen),
                idx=i,
                original_prompt=prompt,
                prompt_hash=prompt_hash,
            )
            for i, gen in enumerate(return_val)
        ]

        async with AsyncSession(self.engine) as session:
            async with session.begin():
                for item in items:
                    # merge is an awaitable operation in the async context
                    await session.merge(item)
            await session.commit()

    async def aclear(self, **kwargs: Any) -> None:
        """Clear cache asynchronously."""
        async with AsyncSession(self.engine) as session:
            async with session.begin():
                # modern delete syntax for async
                await session.execute(delete(self.cache_schema))
            await session.commit()
