# from dotenv import load_dotenv
# from mcp.server.fastmcp import FastMCP
# from fastapi import FastAPI, APIRouter
# import logging
# import matplotlib.pyplot as plt
# import pandas as pd
# import os
# from contextlib import asynccontextmanager
# import contextlib
# from src.synthia.utils.logging_config import configure_logging

# mcp: FastMCP = FastMCP("Charting MCP")

# # Configure logging
# configure_logging(log_file='viz_chart.log')
# load_dotenv(override=True)



# save_path = "../resources/chart_images/"
# save_path = os.environ.get("CHART_IMAGE_PATH", save_path)
# image_path_prefix = "chart_images/"

# @mcp.tool()
# async def create_bar_chart(data: dict, x_column: str, y_column: str = 'Y Column', title: str = "Bar_Chart") -> str:
#     """
#     Create a bar chart from the provided data.
    
#     Args:
#         data (dict): The data to create the bar chart from.
#         x_column (str): The column name for the x-axis.
#         y_column (str): The column name for the y-axis.
#         title (str): The title of the chart.
    
#     Returns:
#         str: Chart image relative path.
#     """
#     logger.info(f"Creating bar chart for {title} using x: {x_column}, y: {y_column}")

#     # Convert data to DataFrame
#     df = pd.DataFrame(data)
#     plt.figure(figsize=(10, 6))
#     plt.bar(df[x_column], df[y_column])
#     plt.title(title)
#     plt.xlabel(x_column)
#     plt.ylabel(y_column)
#     plt.xticks(rotation=45)
    
#     chart_path, return_path = generate_chart_paths(title)
#     plt.savefig(chart_path)
#     plt.close()
#     logger.info(f"chart for {title} created")
    
#     return return_path

# def generate_chart_paths(title):
#     chart_path = f"{save_path}{title}.png"
#     return_path = f"{image_path_prefix}{title}.png"
#     logger.info(f"Saving chart to {chart_path}, chart relative path: {return_path}")
#     return chart_path,return_path

# @mcp.tool()
# async def create_pie_chart(values: list, labels: list, title: str = "Pie Chart") -> str:
#     """
#     Create a pie chart from the provided values and labels.
    
#     Args:
#         values (list): The values for the pie chart.
#         labels (list): The labels for the pie chart.
#         title (str): The title of the chart.
    
#     Returns:
#         str: Chart image relative path.
#     """
#     logger.info(f"Creating pie chart for {title}")

#     plt.figure(figsize=(8, 8))
#     plt.pie(values, labels=labels, autopct='%1.1f%%', startangle=90)
#     plt.title(title)
#     plt.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle
    
#     chart_path = f"{save_path}{title}.png"
#     return_path = f"{image_path_prefix}{title}.png"
#     logger.info(f"Saving chart to {chart_path}, chart relative path: {return_path}")
#     plt.savefig(chart_path)
#     plt.close()
    
#     return return_path

# @mcp.tool()
# async def create_line_chart(data: dict, x_column: str, y_columns: list, title: str = "Line Chart") -> str:
#     """
#     Create a line chart from the provided data.
    
#     Args:
#         data (dict): The data to create the line chart from.
#         x_column (str): The column name for the x-axis.
#         y_columns (list): The column names for the y-axis.
#         title (str): The title of the chart.
    
#     Returns:
#         str: Chart image relative path.
#     """
#     logger.info(f"Creating line chart for {title} using x: {x_column} and y: {y_columns}")

#     # Convert data to DataFrame
#     df = pd.DataFrame(data)
#     plt.figure(figsize=(10, 6))
#     for y_column in y_columns:
#         plt.plot(df[x_column], df[y_column], label=y_column)
#     plt.title(title)
#     plt.xlabel(x_column)
#     plt.ylabel("Values")
#     plt.legend()
    
#     chart_path, return_path = generate_chart_paths(title)
#     logger.info(f"Saving chart to {chart_path}, chart relative path: {return_path}")
#     plt.savefig(chart_path)
#     plt.close()
    
#     return return_path

# @mcp.tool()
# async def create_area_chart(data: dict, x_column: str, y_columns: list, title: str = "Area Chart") -> str:
#     """
#     Create an area chart from the provided data.
    
#     Args:
#         data (dict): The data to create the area chart from.
#         x_column (str): The column name for the x-axis.
#         y_columns (list): The column names for the y-axis.
#         title (str): The title of the chart.
    
#     Returns:
#         str: Chart image relative path.
#     """
#     logger.info(f"Creating area chart for {title} using x: {x_column} and y: {y_columns}")

#     # Convert data to DataFrame
#     df = pd.DataFrame(data)
#     plt.figure(figsize=(10, 6))
#     for y_column in y_columns:
#         plt.fill_between(df[x_column], df[y_column], label=y_column, alpha=0.5)
#     plt.title(title)
#     plt.xlabel(x_column)
#     plt.ylabel("Values")
#     plt.legend()
    
#     chart_path, return_path = generate_chart_paths(title)
#     logger.info(f"Saving chart to {chart_path}, chart relative path: {return_path}")
#     plt.savefig(chart_path)
#     plt.close()
    
#     return return_path

# @mcp.tool()
# async def create_scatter_chart(data: dict, x_column: str, y_column: str, title: str = "Scatter Chart") -> str:
#     """
#     Create a scatter chart from the provided data.
    
#     Args:
#         data (dict): The data to create the scatter chart from.
#         x_column (str): The column name for the x-axis.
#         y_column (str): The column name for the y-axis.
#         title (str): The title of the chart.
    
#     Returns:
#         str: Chart image relative path.
#     """
#     logger.info(f"Creating scatter chart for {title} using x: {x_column} and y: {y_column}")

#     # Convert data to DataFrame
#     df = pd.DataFrame(data)
#     plt.figure(figsize=(10, 6))
#     plt.scatter(df[x_column], df[y_column])
#     plt.title(title)
#     plt.xlabel(x_column)
#     plt.ylabel(y_column)
#     filter
#     chart_path, return_path = generate_chart_paths(title)
#     logger.info(f"Saving chart to {chart_path}, chart relative path: {return_path}")
#     plt.savefig(return_path)
#     plt.close()
    
#     return return_path

# # Define a custom lifespan for FastAPI with a task to manage MCP
# @asynccontextmanager
# async def lifespan(app: FastAPI):
#     # Startup: Initialize MCP server task group
#     logger.info("Initializing MCP server task group...")

#     async with contextlib.AsyncExitStack() as stack:
#         await stack.enter_async_context(mcp.session_manager.run())
#         yield

# router = APIRouter()

# @router.get("/viz-chart/health")
# async def health_check():
#     """Health check endpoint."""
#     return {"status": "ok"}

# # Create FastAPI app with lifespan
# app = FastAPI(lifespan=lifespan)
# app.mount("/viz-chart", mcp.streamable_http_app())