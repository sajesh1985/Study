import logging
import re

from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.data_service.retriever.base import BaseRetriever
from chatrd.engine.data_service.retriever.utils import (
    _retrieve,
    get_keyinstn_id,
    get_security_info,
)
from chatrd.engine.data_service.schema import Analyzer, ProcessorInput, Retriever

logger = logging.getLogger(__name__)
config_machinery = get_config_machinery()


class SecurityCreditHistoryRetriever(BaseRetriever):
    def retrieve(self, processor: ProcessorInput = None, analyzer: Analyzer = None):
        if not processor.entities or len(processor.entities["securities"]) == 0:
            return Retriever()
        endpoint_path = Constants.RatingsAPI.RATINGS_API_SECURITY_HISTORY_ENDPOINT_PATH
        keyinstn_id, instrument_id, security_symbol_value = get_security_info(processor.entities)
        parameter = f"{keyinstn_id}/{instrument_id}/{security_symbol_value}"
        return _retrieve(endpoint_path, parameter)


class CompanyCreditHistoryRetriever(BaseRetriever):
    def retrieve(self, processor: ProcessorInput = None, analyzer: Analyzer = None):
        if not processor.entities or len(processor.entities["companies"]) == 0:
            return Retriever()
        endpoint_path = Constants.RatingsAPI.RATINGS_API_GIS_ENDPOINT_PATH
        parameter = get_keyinstn_id(processor.entities)
        return _retrieve(endpoint_path, parameter)
