import json
import logging
import re
import uuid
from abc import ABC, abstractmethod
from collections import namedtuple
from datetime import datetime
from string import Template
from typing import Any, Dict, List, NamedTuple, Optional, Tuple, Union

from chatrd.core.document import Document, TableDocument
from chatrd.engine.app.utils import convert_date_string
from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.utils import ChatResponse

DocumentTypes = Union[Document, TableDocument]
OutputFormat = Union[Dict[str, Any], Dict]

COMMON_FIELDS = ["article_id", "date", "document_type", "article_type", "source_object_id"]
StructuredData = namedtuple("StructuredData", ["title", "link", "details", "source_type"])
UnstructuredData = namedtuple(
    "UnstructuredData", [*COMMON_FIELDS, "title", "raw_date", "document_type_name", "url", "is_criteria"]
)
DocumentMetadata = namedtuple(
    "DocumentMetadata", [*COMMON_FIELDS, "document_title", "id", "article_sub_type", "release_date"]
)

RESEARCH_TYPE_MAPPING = {
    "FULL": "FULL ANALYSIS",
    "NEWS": "NEWS",
    "RESUPD": "RESEARCH UPDATE",
    "SUMMARY": "SUMMARY ANALYSIS",
    "REPORT": "REPORT",
    "COMMENTS": "COMMENTARY",
}

# Default fallback template
TEMPLATED_SOURCE = [
    {
        "id": str(uuid.uuid4()),
        "title": None,
        "date": None,
        "type": None,
        "details": "null",
        "link": None,
        "name": "Templated Response",
    }
]

DEFAULT_RESPONSE = {
    "response_type": "text",
    "response": "CreditCompanion™ couldn't find the information you were looking for. Please try rephrasing your question, and feel free to share your feedback.",
    "sources": TEMPLATED_SOURCE,
}

logger = logging.getLogger(__name__)


class SourceExtractor(ABC):
    """Abstract base class for generating source information from documents.

    Provides common functionality for extracting metadata from Document and TableDocument objects and
    generating appropriate source representations to utilize them in subclasses for output formatting.

    Handles both structured (API-based) and unstructured (article-based) sources.
    - Data API sources have "response_payload" in document metadata.
    - Article sources have "articleID" in document metadata.

    Data Flow:
    - Documents → filter_documents_by_type() >> [structured, unstructured] : DocumentMetadata
    - DocumentMetadata → extract_structured/unstructured_data() >> StructuredData, UnstructuredData
    - StructuredData, UnstructuredData → format_structured/unstructured_source() >> [formatted output]
    """

    def __init__(self):
        config_machinery = get_config_machinery()
        sourcing_base_url = config_machinery.get_config_value(Constants.SourceGeneration.BASE_URL)
        url_slug = config_machinery.get_config_value(Constants.SourceGeneration.RESEARCH_ARTICLE_URL_SLUG)
        self.base_url = sourcing_base_url + url_slug

        # URL patterns
        self.link_pattern_research = Template("$base_url?auth=inherit#ratingsdirect/creditResearch?rid=$id")
        self.link_pattern_criteria = Template(
            "$base_url?auth=inherit#ratingsdirect/creditResearch?artObjectId=$id&html=true"
        )
        logger.debug(f"SourceGenerator initialized with base URL: {self.base_url}")

    @abstractmethod
    def extract(self, documents: DocumentTypes) -> List[OutputFormat]:
        """Extract sources from documents in the desired format."""
        pass

    @abstractmethod
    def _format_structured_source(self, source_data: Dict) -> Any:
        """Format a single structured source data into the desired output format."""
        pass

    @abstractmethod
    def _format_unstructured_source(self, source_data: Dict) -> Any:
        """Format a single unstructured source data into the desired output format."""
        pass

    # ========== Metadata and source extraction logic ==========
    def _filter_documents_by_type(self, docs: List[Union[Document, TableDocument]]) -> Tuple[List, List]:
        """Filter documents into structured and unstructured categories."""
        if not isinstance(docs, list):
            docs = list(docs) if docs else []
        else:
            docs = self.flatten_list(docs)

        structured = [doc for doc in docs if self._is_structured_source(doc)]
        unstructured = [doc for doc in docs if self._is_unstructured_source(doc)]

        return (structured, unstructured)

    def _extract_document_metadata(self, doc: Union[Document, TableDocument]) -> DocumentMetadata:
        """Extract metadata from a document into a standardized structure."""
        metadata = doc.metadata

        # Extract basic information
        article_id = metadata.get("articleID")
        source_object_id = metadata.get("SourceObjectID")
        article_type = metadata.get("articleType")
        article_sub_type = metadata.get("articleSubType")
        release_date = metadata.get("articleReleaseDate")
        title = metadata.get("PreferredTitle") or metadata.get("SourceTitle")

        # Determine document type
        if article_sub_type in ["CRITERIA", "CRITERIA_GUIDANCE"]:
            document_type = "criteria"
        elif article_type and article_type in RESEARCH_TYPE_MAPPING:
            document_type = RESEARCH_TYPE_MAPPING[article_type].lower()
        else:
            document_type = "research article"

        processed_date = convert_date_string(self._extract_date(str(release_date))) if release_date else None
        if source_object_id:
            doc_id = int(source_object_id)
        elif article_id:
            doc_id = int(article_id)
        else:
            doc_id = None

        return DocumentMetadata(
            document_type=document_type,
            document_title=title,
            date=processed_date,
            id=doc_id,
            article_id=int(article_id) if article_id else None,
            source_object_id=int(source_object_id) if source_object_id else None,
            article_type=article_type,
            article_sub_type=article_sub_type,
            release_date=release_date,
        )

    # ========== Helper functions ==========
    def _extract_date(self, input_string) -> str:
        """Extracts a date from a string in the format YYYY-MM-DD."""
        if not input_string:
            return ""
        date_pattern = re.compile(r"(\d{4}-\d{2}-\d{2})")
        match = re.search(date_pattern, input_string)

        if match:
            date_str = match.group(1)
            date_obj = datetime.strptime(date_str, "%Y-%m-%d")
            return date_obj.date()

        return ""

    def flatten_list(self, nested_list):
        """Flatten a nested list into a single-level list."""
        flattened = []
        if not nested_list:
            return flattened
        for element in nested_list:
            if isinstance(element, List):
                flattened.extend(self.flatten_list(element))
            else:
                flattened.append(element)
        return flattened

    def _generate_url(self, doc_metadata: DocumentMetadata) -> str:
        """Generate right URL for a document."""
        if self._is_criteria_document(doc_metadata):
            return self.link_pattern_criteria.substitute(
                base_url=self.base_url, id=doc_metadata.source_object_id or doc_metadata.id
            )
        else:
            return self.link_pattern_research.substitute(
                base_url=self.base_url, id=doc_metadata.article_id or doc_metadata.id
            )

    # ========== Document type checks ==========
    def _is_structured_source(self, doc: Union[Document, TableDocument]) -> bool:
        """Check if a document represents a structured data source (API-based)."""
        return ("articleID" not in doc.metadata) and ("response_payload" in doc.metadata)

    def _is_unstructured_source(self, doc: Union[Document, TableDocument]) -> bool:
        """Check if a document represents an unstructured source (article-based)."""
        return "articleID" in doc.metadata

    def _is_criteria_document(self, doc_metadata: DocumentMetadata) -> bool:
        """Check if a document is a criteria document."""
        return doc_metadata.article_sub_type in ["CRITERIA", "CRITERIA_GUIDANCE"]

    # ========== Data extraction methods ==========
    def _extract_structured_data(self, docs: List[Union[Document, TableDocument]]) -> List[StructuredData]:
        """Extract structured data from API-based documents."""
        structured_data = []

        for doc in docs:
            metadata = doc.metadata
            doc_details = metadata.get("response_payload", {})
            src_type = "Data API Services"
            if metadata.get("source_description"):
                # Multiple sources from source_description list
                for source_info in metadata["source_description"]:
                    if isinstance(source_info, (list, tuple)) and len(source_info) > 1:
                        src_title, src_link, *_ = source_info
                    else:
                        src_title = source_info
                        src_link = None

                    structured_data.append(
                        StructuredData(title=src_title, link=src_link, details=doc_details, source_type=src_type)
                    )
            else:
                # Single source without description
                structured_data.append(StructuredData(title=None, link=None, details=doc_details, source_type=src_type))

        return structured_data

    def _extract_unstructured_data(self, docs: List[Union[Document, TableDocument]]) -> List[UnstructuredData]:
        """Extract unstructured data from article-based documents."""
        unstructured_data = []

        for doc in docs:
            doc_metadata = self._extract_document_metadata(doc)
            if not doc_metadata.article_id:
                continue  # Skip documents without article_id

            url = self._generate_url(doc_metadata)
            document_type_name = "Criteria Article" if self._is_criteria_document(doc_metadata) else "Research Article"

            unstructured_data.append(
                UnstructuredData(
                    article_id=doc_metadata.article_id,
                    title=doc_metadata.document_title,
                    date=doc_metadata.date,  # Processed date
                    raw_date=doc_metadata.release_date,  # Raw date for compatibility
                    article_type=doc_metadata.article_type,
                    document_type=doc_metadata.document_type,
                    document_type_name=document_type_name,
                    url=url,
                    source_object_id=doc_metadata.source_object_id,
                    is_criteria=self._is_criteria_document(doc_metadata),
                )
            )

        return unstructured_data


class DetailedSourceExtractor(SourceExtractor):
    """DetailedSourceExtractor creates structured dictionary representations of sources.

    This class provides enhanced functionality for creating detailed source dictionaries suitable for API responses.
    It handles both structured (API-based) and unstructured (article-based) sources.
    """

    def extract(self, docs: List[Union[Document, TableDocument]]) -> List[Dict]:
        """Extract detailed source information from documents."""
        if not docs:
            return TEMPLATED_SOURCE

        structured_docs, unstructured_docs = self._filter_documents_by_type(docs)
        structured_data: List[StructuredData] = self._extract_structured_data(structured_docs)
        unstructured_data: List[UnstructuredData] = self._extract_unstructured_data(unstructured_docs)

        # Format the extracted data
        structured_sources = [self._format_structured_source(data) for data in structured_data]
        unstructured_sources = [self._format_unstructured_source(data) for data in unstructured_data]
        unstructured_sources = self.remove_duplicates(unstructured_sources)

        # Combine all sources
        all_sources = []
        all_sources.extend(structured_sources)
        all_sources.extend(unstructured_sources)

        if not all_sources:
            return TEMPLATED_SOURCE

        return all_sources

    def _format_structured_source(self, src: StructuredData) -> Dict:
        """Format structured source data into detailed dictionary format."""
        return {
            "id": str(uuid.uuid4()),
            "title": src.title,
            "date": None,
            "type": None,
            "details": json.dumps(src.details),
            "link": src.link,
            "name": src.source_type,
        }

    def _format_unstructured_source(self, src: UnstructuredData) -> Dict:
        """Format unstructured source data into detailed dictionary format."""
        return {
            "id": str(src.article_id),
            "title": src.title,
            "date": src.raw_date,  # Use raw date for compatibility
            "type": src.article_type,
            "details": None,
            "link": src.url,
            "name": src.document_type_name,
        }

    def remove_duplicates(self, sources: List[Dict]) -> List[Dict]:
        """Remove duplicate sources based on the link URLs."""
        seen_links = set()
        unique_sources = []

        for source in sources:
            link = source.get("link")
            if link not in seen_links:
                unique_sources.append(source)
                seen_links.add(link)

        return unique_sources


class MarkdownSourceExtractor(SourceExtractor):
    """MarkdownSourceExtractor creates formatted citation links.

    This class provides enhanced functionality for generating Markdown-formatted citation links with rich metadata.
    It focuses only on unstructured (article-based) sources and provides categorization capabilities.
    """

    def __init__(self):
        super().__init__()

        # Markdown-formatted link templates
        self.link_pattern_unstructured = Template(
            "[$title]($base_url?auth=inherit#ratingsdirect/creditResearch?rid=$id), $document_type document from $date"
        )

        self.link_pattern_criteria_markdown = Template(
            "[$title]($base_url?auth=inherit#ratingsdirect/creditResearch?artObjectId=$id&html=true), $document_type document from $date"
        )

    def extract(self, docs: List[Union[Document, TableDocument]]) -> List[str]:
        """Extract Markdown citation links from documents."""
        if not docs:
            return []

        structured_docs, unstructured_docs = self._filter_documents_by_type(docs)
        structured_data: List[StructuredData] = self._extract_structured_data(structured_docs)
        unstructured_data: List[UnstructuredData] = self._extract_unstructured_data(unstructured_docs)

        # Format the extracted data
        structured_links = [self._format_structured_source(data) for data in structured_data]
        unstructured_links = [self._format_unstructured_source(data) for data in unstructured_data]

        # Combine and filter out empty strings
        all_links = []
        all_links.extend([link for link in structured_links if link])  # Filter empty strings
        all_links.extend([link for link in unstructured_links if link])

        return all_links

    def extract_categorized(self, source_docs=None, cited_docs=None, unauthorized_docs=None) -> Dict[str, List[str]]:
        """Extract categorized Markdown links from different document categories."""
        result = {"source_links": [], "cited_links": [], "unauthorized_links": []}

        if source_docs:
            result["source_links"] = self.extract(source_docs)

        if cited_docs:
            result["cited_links"] = self.extract(cited_docs)

        if unauthorized_docs:
            result["unauthorized_links"] = self.extract(unauthorized_docs)

        return result

    def _format_structured_source(self, src: StructuredData) -> str:
        """Formatting structured source data is not supported for Markdown generation."""
        logger.debug("Ignoring structured source for Markdown source generation")
        return ""

    def _format_unstructured_source(self, src: UnstructuredData) -> str:
        """Format unstructured source data into Markdown citation link."""
        # Use processed date with fallback
        date_value = src.date or src.raw_date or "UNKNOWN"
        title_value = src.title

        # Format the link based on document type
        if src.is_criteria:
            link = self.link_pattern_criteria_markdown.substitute(
                base_url=self.base_url,
                title=title_value,
                id=src.source_object_id or src.article_id,
                date=date_value,
                document_type=src.document_type,
            )
        else:
            link = self.link_pattern_unstructured.substitute(
                base_url=self.base_url,
                title=title_value,
                id=src.article_id,
                date=date_value,
                document_type=src.document_type,
            )

        if link.endswith("from UNKNOWN"):
            # Shorten the link info if date is missing
            link = link.replace(" from UNKNOWN", "")

        return link
