import React from 'react';
import { faAngleRight, faAngleLeft } from '@fortawesome/free-solid-svg-icons';
import { Icon } from '@spglobal/react-components';
import { Size } from '@spglobal/koi-helpers';
import styled from '@emotion/styled';

export const TextStyled = styled.span`
  font-size: var(--size-font-4);
`

export const TabNavigationKeys: React.FC = () => {
  return (
    <>
      <TextStyled>
        <i>press shift</i> +
      </TextStyled>
      <Icon icon={faAngleLeft} size={Size.MEDIUM} />
      <Icon icon={faAngleRight} size={Size.MEDIUM} />
      <TextStyled>to switch categories</TextStyled>
    </>
  );
};
