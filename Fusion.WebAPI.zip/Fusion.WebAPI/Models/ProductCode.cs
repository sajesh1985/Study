﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fis.Epp.Fusion.WebAPI.Models
{
    public enum ProductCode
    {
        PeoplePay,
        BillPay,
        Fusion
    }
}