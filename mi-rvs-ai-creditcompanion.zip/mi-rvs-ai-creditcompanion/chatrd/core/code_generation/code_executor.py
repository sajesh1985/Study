import base64
import io
import logging
import re
import traceback
from copy import deepcopy
from typing import List, Union

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import plotly.graph_objects as go
import seaborn as sns
from matplotlib.figure import Figure

from chatrd.core.code_generation.schema import DataFrame

logger = logging.getLogger(__name__)


def parse_python_code(text):
    """Extract Python code from markdown code blocks"""
    pattern = r"```python\s*\n(.*?)\n```"
    matches = re.findall(pattern, text, re.DOTALL)
    return matches[0].strip() if matches else None


class CodeExecutor:
    def __init__(self, prompt_processor, max_retries=2):
        self.prompt_processor = prompt_processor
        self.max_retries = max_retries

    def execute_code(
        self,
        code: str,
        prompt: str,
        dfs: Union[DataFrame, List[DataFrame]],
        examples_text: str = "",
    ):
        for attempt in range(self.max_retries + 1):
            parsed_code = parse_python_code(code)
            logger.info("Parsed Code: \n" + parsed_code)
            dfs2 = deepcopy(dfs)
            try:
                allowed_builtins = {"pd": pd, "np": np, "plt": plt, "sns": sns}
                if isinstance(dfs2, DataFrame):
                    allowed_builtins["df"] = dfs.df.copy(deep=True)
                else:
                    for df in dfs2:
                        allowed_builtins[df.name] = df.df.copy(deep=True)

                local_namespace = {}

                exec(parsed_code, allowed_builtins, local_namespace)

                if "result" in local_namespace:
                    result = local_namespace["result"]
                else:
                    result = None

                if result is None:
                    return {"type": "error", "content": None}
                if isinstance(result, list) and all(
                    isinstance(item, dict) and (isinstance(v, pd.DataFrame) or isinstance(v, str))
                    for item in result
                    for v in item.values()
                ):
                    return {"type": "table_text_list", "content": result, "count": len(result)}
                elif isinstance(result, (int, float, str)):
                    return {"type": "text", "content": result}
                elif isinstance(result, Figure):
                    buf = io.BytesIO()
                    result.savefig(buf, format="png")
                    buf.seek(0)
                    image_base64 = base64.b64encode(buf.read()).decode("utf-8")
                    result.close()
                    return {"type": "plot", "content": image_base64}
                elif isinstance(result, go.Figure):
                    return {"type": "plot", "content": result}
                else:
                    raise Exception(
                        f"Got different format from `result` variable. Here is the output of result: {result}"
                    )

            except Exception as e:
                code_lines = parsed_code.strip().splitlines()
                tb_str = traceback.format_exc()
                tb_str = "An error occurred:\n" + tb_str
                line_err_str = ""
                # Identify the line number from the exception and print the corresponding code
                tb = traceback.extract_tb(e.__traceback__)
                user_frame = None
                for frame in reversed(tb):
                    if frame.filename == "<string>":
                        user_frame = frame
                        break
                if tb:
                    # Get the last call (the one that raised the exception)
                    if user_frame:
                        lineno = user_frame.lineno
                        line_err_str += f"\nError occurred at line {lineno} in generated code:\n"
                        if lineno <= len(code_lines):
                            line_err_str += f">>> {code_lines[lineno - 1].strip()}  # Error here"
                        else:
                            line_err_str += f"Line number {lineno} is out of range for the provided code."
                    else:
                        line_err_str += "\nError occurred in external library code, not directly in your input."

                error_message = tb_str + line_err_str
                if attempt < self.max_retries:
                    logger.info("Retrying code generation...\n" + error_message)
                    code = self.prompt_processor.process_prompt(
                        prompt,
                        dfs,
                        examples_text,
                        error_message=error_message,
                        last_generated_code=code,
                    )
                    continue
                else:
                    return {"type": "error", "data": error_message}
