from src.synthia.persistence.template_metadata_repository import DatabaseTemplateMetadataRepository
from src.synthia.schemas.template import Template


def choose_by_metadata(filenames_to_content: dict, metadata_if_found: dict | None) -> Template | None:
    if not metadata_if_found:
        return None
    prompt_file_name = metadata_if_found[DatabaseTemplateMetadataRepository.Columns.TemplateConfigFileName]
    return filenames_to_content.get(prompt_file_name)