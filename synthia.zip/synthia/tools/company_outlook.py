import contextlib
import logging
from contextlib import asynccontextmanager
from typing import Any

import httpx
from fastapi import FastAPI, APIRouter
from fastapi import Request
from mcp.server.fastmcp import FastMCP, Context

from src.synthia.config.api_config import get_config
from src.synthia.utils.logging_config import configure_logging
from . import auth
from .mcp_responses import (
    Source,
    TransformedOutlook,
    ErrorResponse,
    QuarterInfo,
    MetricEntry,
    FinancialOutlookThresholdResponse,
    MCPResponse,
    MacroEconomicStandardDataRecord,
    EconomyInPerspectiveRecord
)
from .mcp_utils import get_mcp_tool_source
import pandas as pd

# Configure logging
logger = configure_logging(logger_name=__name__, log_file='company_outlook.log')

mcp: FastMCP = FastMCP("Company Outlook MCP", stateless_http=True)

logger.info("Outlook MCP Server starting up...")

router = APIRouter()


@router.get("/company-outlook/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "ok"}


# Create a single AsyncClient instance for reuse (performance optimization for Lambda)
async_client: httpx.AsyncClient = None


def transform_financial_outlook_response(financial_outlook_response: dict) -> TransformedOutlook | ErrorResponse:
    """
    Transforms the financial outlook response into a structured dictionary with downside and upside metrics.

    Args:
        financial_outlook_response (dict): The raw financial outlook response.
    Returns:
        TransformedOutlook | ErrorResponse: The transformed outlook data or an error message.
    """
    # Handle error dicts from fetch_threshold_data
    if not financial_outlook_response or "error" in financial_outlook_response:
        return ErrorResponse(error=financial_outlook_response.get("error", "Unknown error in threshold response"))

    data = financial_outlook_response.get("data")
    if not data or "value" not in data or not isinstance(data["value"], list) or not data["value"]:
        return ErrorResponse(error="No valid threshold data found")

    value = financial_outlook_response["data"]["value"]

    # Helper to get period end and last update dates
    def get_dates(value_list) -> tuple:
        """
        Extracts the period end date and last update date from the value list.
        Args:
            value_list (list): The list of values containing date information.
        Returns:
            tuple: A tuple containing the period end date and last update date.
        """
        period_end = None
        last_update = None
        for _item in value_list:
            if _item.get("CreditStatsMetricId") == "PeriodDateEnded":
                period_end = _item.get("LatestQuarter")
            if _item.get("CreditStatsMetricId") == "RDCSDLastUpdate":
                last_update = _item.get("LatestQuarter")
        return period_end, last_update

    period_end_date, last_update_date = get_dates(value)

    downside = []
    upside = []

    # Helper to get Ltm last update date
    def get_ltm_last_update(value_list: list[dict]) -> str | None:
        """
        Extracts the LTM last update date from the value list.
        Args:
            value_list (list): The list of values containing LTM last update information.
        Returns:
            str | None: The LTM last update date or None if not found.
        """
        for _item in value_list:
            if _item.get("CreditStatsMetricId") == "RDCSDLastUpdate":
                return _item.get("Ltm")
        return None

    ltm_last_update = get_ltm_last_update(value)
    quarter_name = value[0].get("LatestQuarter")
    ltm_name = value[0].get("Ltm")
    for item in value:
        action = item.get("Action")
        if action in ("downside", "upside"):
            latest_quarter = QuarterInfo(
                name=quarter_name,
                value=item.get("LatestQuarter"),
                periodEndDate=period_end_date if period_end_date else None,
                LastUpdateDate=last_update_date if last_update_date else None
            )
            ltm = QuarterInfo(
                name=ltm_name,
                value=item.get("Ltm"),
                periodEndDate=last_update_date if last_update_date else None,
                LastUpdateDate=ltm_last_update if ltm_last_update else None
            )
            entry = MetricEntry(
                CreditStatsMetricCaption=item.get("CreditStatsMetricCaption"),
                Threshold=item.get("Threshold"),
                LatestQuarter=latest_quarter,
                Ltm=ltm,
                ReportedCurrency=item.get("ReportedCurrency")
            )
            if action == "downside":
                downside.append(entry)
            else:
                upside.append(entry)
    if not downside and not upside:
        return ErrorResponse(error="No downside or upside metrics found in threshold data")
    return TransformedOutlook(downside=downside, upside=upside)


# Helper: Get outlook data
async def fetch_outlook_data(
        keyInstn: str,
        company_id: str,
        core_id: str,
        debt_type: str,
        rating_type: str,
        auth_headers: dict
) -> dict | str:
    """
    Fetch outlook data for a given company ID and core ID.
    Args:
        keyInstn (str): The Inst ID for which to fetch the company ID and core ID.
        company_id (str): The company ID for which to fetch outlook data.
        core_id (str): The core ID (Rating Entity Id) for which to fetch outlook data.
        debt_type (str): The debt type, e.g., 'ICR' (Issuer Credit Rating).
        rating_type (str): The rating type, e.g., 'FCLONG' (Foreign Currency Long Term).
        auth_headers (dict): The authentication headers for the request.

    Returns:
        dict: A dictionary containing the outlook data or an error message.
        str: An error message if the request fails.
    """
    # Get configuration
    cfg = get_config()
    capital_iq_base_url = cfg["capitaliq_base_url"]
    entity_outlook_url_infix = "ratings/getEntityOutlookResearchAndMetadata/"

    global async_client
    url = f"{capital_iq_base_url}{entity_outlook_url_infix}{company_id}/{core_id}/{debt_type}/{rating_type}"
    logger.info(f"Request URL: {url}")
    try:
        response = await async_client.get(url, headers=auth_headers)
        if response.status_code == 200:
            outlook_data = response.json()
            logger.info(f"Outlook data returned : {len(outlook_data)} records")
            outlook_data.pop("metadata", None)
            return {"sources": Source(title="Company Outlook data", url=url), "data": outlook_data}
        elif response.status_code == 204:
            logger.info(f"No outlook data found for keyInstn: {keyInstn}.")
            source = Source(title="Company Outlook data", url=url)
            return {"sources": source, "data": {"message": "No outlook data found for the given company."}}
        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return f"Error: {response.status_code} - {response.text}"
    except httpx.RequestError as e:
        logger.error(f"Request failed: {e}")
        return f"Request failed: {e}"


# Helper: Get threshold data
async def fetch_threshold_data(keyInstn: str, article_id: str, auth_headers: dict) -> dict:
    """
    Fetch threshold data for a given institution ID and article ID.
    Args:
        keyInstn (str): The Inst ID for which to fetch the company ID and core ID.
        article_id (str): The article ID for which to fetch threshold data.
        auth_headers (dict): The authentication headers for the request.

    Returns:
        dict: A dictionary containing the threshold data or an error message.
    """
    # Get configuration
    cfg = get_config()
    capital_iq_base_url = cfg["capitaliq_base_url"]
    entity_outlook_threshold_url_infix = "ratings/getEntityOutlookTriggerAndMetadata/"

    url = f"{capital_iq_base_url}{entity_outlook_threshold_url_infix}{keyInstn}/{article_id}"
    global async_client
    logger.info(f"Fetching threshold data for keyInstn={keyInstn}, article_id={article_id}")
    logger.debug(f"Request URL: {url}")
    source_url = f"{cfg['capitaliq_base_inherit_auth_url']}&id={keyInstn}"
    try:
        response = await async_client.get(url, headers=auth_headers)
        logger.info(f"Company threshold api response: {response.json()}, status code: {response.status_code}")
        if response.status_code == 200:
            logger.debug("Threshold data fetched successfully.")
            return {"sources": source_url, "data": response.json()}
        elif response.status_code == 204:
            logger.info("No threshold data found for the given company.")
            return {"sources": source_url, "data": {"message": "No threshold data found for the given company."}}
        logger.error(f"Error fetching threshold data: {response.status_code} - {response.text}")
        return {"error": f"Error: {response.status_code} - {response.text}"}
    except httpx.RequestError as e:
        logger.error(f"Request failed while fetching threshold data: {e}")
        return {"error": f"Request failed: {e}"}


async def get_ciqcompany_rating_entity_id(keyInstn: str, auth_headers: dict) -> tuple:
    """
    Retrieve the CIQCompanyId (company ID) and Rating Entity Id (core ID) for a given Inst ID.
    Args:
        keyInstn (str): The Inst ID for which to fetch the company ID and core ID.
        auth_headers (dict): The authentication headers for the request.
    Returns:
        tuple: A tuple containing the CIQCompanyId and Rating Entity Id.
    """
    # Get configuration
    cfg = get_config()
    capital_iq_base_url = cfg["capitaliq_base_url"]
    ciq_company_id_url_infix = "AIReportBuilder/companyDesc/"

    logger.info(f"Fetching CIQCompanyId and Rating Entity Id for Inst ID: {keyInstn}")
    url = f"{capital_iq_base_url}{ciq_company_id_url_infix}{keyInstn}"
    logger.info(f"URL for CIQCompanyId and Rating Entity Id: {url}")
    try:
        global async_client
        response = await async_client.get(url, headers=auth_headers)
        logger.info(f"Response status code: {response.status_code}")
        if response.status_code == 200:
            response_data = response.json()
            logger.info(f"Response data: {response_data}")
            ciq_company_id = response_data.get("CIQCompanyId")
            rating_entity_id = response_data.get("RatingEntityId")
            return ciq_company_id, rating_entity_id
        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return None, None
    except httpx.RequestError as e:
        logger.error(f"Request failed: {e}")
        return None, None


def extract_article_id_from_outlook_data(outlook_data: list[dict]) -> str:
    """
    Extract the ArticleId from the outlook data.
    Args:
        outlook_data (list[dict]): The outlook data from which to extract the ArticleId.
    Returns:
        article_id (str): The extracted ArticleId or an empty string if not found.
    """
    if outlook_data and isinstance(outlook_data, list) and isinstance(outlook_data[0], dict):
        logger.info(f"First item in outlook data: {outlook_data[0]}")
        return outlook_data[0].get("ArticleId", "")
    return ""


# @mcp.tool()
async def get_company_outlook(keyInstn: str, debtTypeCode: str = 'ICR', ratingTypeCode: str = 'FCLONG') -> dict:
    """
    Retrieve outlook information for a given company institution id.

    Args:
        Inst ID/KeyInstn/MI Key - S&P's unique key to identify institutions. Institutions are corporations, partnerships, proprietorships, not-for-profit organizations, government agencies, and any other chartered organization.
        debtTypeCode (str): The debt type code, default is 'ICR' (Issuer Credit Rating).
        ratingTypeCode (str): The rating type code, default is 'FCLONG' (Foreign Currency Long Term).

    Returns:
        dict: A dictionary containing the outlook information for the specified company.
        
    """
    logger.info(f"Outlook request for institution Id: {keyInstn}")

    # Simulate a request to the ratings URL
    logger.info(f"get_company_outlook called for : {keyInstn}")
    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    auth_headers = auth.build_auth_headers(raw_request)
    global async_client
    company_id, core_id = await get_ciqcompany_rating_entity_id(keyInstn, auth_headers)
    if not company_id or not core_id:
        logger.error(f"Failed to retrieve company ID or core ID for keyInstn: {keyInstn}")
        return {"error": "Failed to retrieve company ID or core ID"}
    return await fetch_outlook_data(keyInstn, company_id, core_id, debtTypeCode, ratingTypeCode, auth_headers)


# @mcp.tool()
async def get_company_financial_outlook_threshold_current(
        keyInstn: str,
        debt_type_code: str = 'ICR',
        rating_type_code: str = 'FCLONG'
) -> FinancialOutlookThresholdResponse | ErrorResponse:
    """
    Retrieve the current financial outlook threshold for a given company institution id.
    Args:
        keyInstn (str): Inst ID/KeyInstn/MI Key - S&P's unique key to identify institutions. Institutions are corporations, partnerships, proprietorships, not-for-profit organizations, government agencies, and any other chartered organization.
        debt_type_code (str): The debt type code, default is 'ICR' (Issuer Credit Rating).
        rating_type_code (str): The rating type code, default is 'FCLONG' (Foreign Currency Long Term).
    Returns:
        FinancialOutlookThresholdResponse | ErrorResponse: Company's financial outlook threshold data or an error message.

        The response will be either a FinancialOutlookThresholdResponse or ErrorResponse.

        FinancialOutlookThresholdResponse:
            sources (Source): Information about the data source, including title and link.
            value (TransformedOutlook | ErrorResponse): The transformed financial outlook data or an error message.

        TransformedOutlook:
            downside (list[MetricEntry]): List of downside metrics.
            upside (list[MetricEntry]): List of upside metrics.

        MetricEntry:
            CreditStatsMetricCaption (str): Caption for the credit stats metric.
            Threshold (str): Threshold value for the metric.
            LatestQuarter (QuarterInfo): Information about the latest quarter.
            Ltm (QuarterInfo): Information about the last twelve months.
            ReportedCurrency (str): Currency in which the metric is reported.

        QuarterInfo:
            name (str): Name of the quarter or period.
            value (str): Value for the quarter or period.
            periodEndDate (str | None): End date of the period.
            LastUpdateDate (str | None): Last update date for the period.

        Source:
            title (str): Title for the data source.
            url (str): Url to the data source.

        ErrorResponse:
            error (str): Error message describing the issue.
        Examples:
            {
              "sources": {
                "text": "Capital IQ platform",
                "href": "https://www.capitaliqdev.spglobal.com/web/client?auth=inherit&id=3004222 "
              },
              "value": {
                "downside": [
                  {
                    "CreditStatsMetricCaption": "FFO/ Debt, Adjusted (%)",
                    "Threshold": "<18%",
                    "LatestQuarter": {
                      "name": "2024 FQ2",
                      "value": "15.215475",
                      "periodEndDate": "6/30/2024 12:00:00 AM",
                      "LastUpdateDate": "9/17/2024 5:41:00 AM"
                    },
                    "Ltm": {
                      "name": "LTM",
                      "value": "18.616185",
                      "periodEndDate": "9/17/2024 5:41:00 AM",
                      "LastUpdateDate": "9/9/2024 11:27:00 AM"
                    },
                    "ReportedCurrency": "USD_$M"
                  }
                ],
                "upside": [
                  {
                    "CreditStatsMetricCaption": "FFO/ Debt, Adjusted (%)",
                    "Threshold": ">16%",
                    "LatestQuarter": {
                      "name": "2024 FQ2",
                      "value": "15.215475",
                      "periodEndDate": "6/30/2024 12:00:00 AM",
                      "LastUpdateDate": "9/17/2024 5:41:00 AM"
                    },
                    "Ltm": {
                      "name": "LTM",
                      "value": "18.616185",
                      "periodEndDate": "9/17/2024 5:41:00 AM",
                      "LastUpdateDate": "9/9/2024 11:27:00 AM"
                    },
                    "ReportedCurrency": "USD_$M"
                  }
                ]
              }
            }
    """
    logger.info(f"Outlook threshold request for Institution Id: {keyInstn}")
    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    auth_headers = auth.build_auth_headers(raw_request)

    company_id, core_id = await get_ciqcompany_rating_entity_id(keyInstn, auth_headers)
    if not company_id or not core_id:
        logger.error(f"Failed to retrieve company ID or core ID for keyInstn: {keyInstn}")
        return ErrorResponse(error="Failed to retrieve company ID or core ID")

    logger.info(f"Company ID: {company_id}, Core ID: {core_id}")
    outlook_result = await fetch_outlook_data(
        keyInstn=keyInstn,
        company_id=company_id,
        core_id=core_id,
        debt_type=debt_type_code,
        rating_type=rating_type_code,
        auth_headers=auth_headers
    )

    if isinstance(outlook_result, str):
        logger.error(f"Error fetching articleId for {keyInstn}, outlook api response: {outlook_result}")
        return ErrorResponse(error=outlook_result)

    outlook_data = outlook_result.get("data", {}).get("value", [])

    if not outlook_data:
        return ErrorResponse(error="Failed to get outlook data")

    article_id: str = extract_article_id_from_outlook_data(outlook_data)

    if not article_id:
        return ErrorResponse(error="ArticleId not found in outlook data")

    logger.info(f"Article ID for keyInstn {keyInstn}: {article_id}")
    threshold_data = await fetch_threshold_data(keyInstn, article_id, auth_headers)
    return FinancialOutlookThresholdResponse(
        sources=Source(title="Capital IQ platform", url=threshold_data.get("sources")),
        value=transform_financial_outlook_response(threshold_data)
    )


async def get_company_key_country(keyInstn: str, auth_headers: dict) -> tuple[Any, Any]:
    """
    Utility to fetch only the KeyCountry for a given KeyInstn.
    Creates a temporary httpx client if the global one is not available.
    """
    logger.info(f"[Util] Fetching KeyCountry for keyInstn: {keyInstn}")

    cfg = get_config()
    capitaliq_base_url = cfg["capitaliq_base_url"]
    url = f"{capitaliq_base_url}AIReportBuilder/companyDesc/{keyInstn}"

    # Use a local client if the global one is not initialized
    client = async_client
    should_close_client = False
    if client is None:
        logger.warning("[Util] Global async_client is None. Creating a temporary client for get_company_key_country.")
        client = httpx.AsyncClient()
        should_close_client = True

    try:
        response = await client.get(url, headers=auth_headers)
        response.raise_for_status()  # Raise an exception for bad status codes

        response_json = response.json()
        key_country = response_json.get("KeyCountry")
        country_key_instn = response_json.get("countryKeyInstn")
        logger.info(f"[Util] Retrieved KeyCountry: {key_country}, countryKeyInstn: {country_key_instn} for keyInstn: {keyInstn}")
        return key_country, country_key_instn

    except httpx.HTTPStatusError as e:
        logger.error(f"[Util] HTTP error fetching KeyCountry for {keyInstn}: {e.response.status_code}")
        return None, None
    except Exception as e:
        logger.error(f"[Util] An unexpected error occurred in get_company_key_country for {keyInstn}: {e}")
        return None, None
    finally:
        # If we created a temporary client, close it.
        if should_close_client and client:
            await client.aclose()


@mcp.tool()
async def get_macroEconomic_Standard_data(
        keyInstn: str,
        period_Range: str = "2023Y,2024Y,2025Y,2026Y,2027Y"
) -> MCPResponse:
    """
    Macro Economic - Economic & Demographic (Standard Data)

    Retrieves macro-economic - Economic & Demographic (Standard Data) for the company's country based on KeyInstn.
    Automatically resolves the country code and fetches data for the specified period range.
    Deduplicates records by KeyECRMacroPeriod.

    Flow:
    1. Resolves company's country code via get_company_description_data
    2. Uses the provided period_Range (or default 5-year range if not specified)
    3. Fetches data from Capital IQ macroEconomicIndicators endpoint
    4. Deduplicates and returns raw indicator records

    Args:
        keyInstn (str): Company KeyInstn/MI Key (S&P unique institution identifier)
        period_Range (str): Comma-separated list of years with 'Y' suffix (e.g., "2023Y,2024Y,2025Y").
                           Default: "2023Y,2024Y,2025Y,2026Y,2027Y"

    Returns:
        MCPResponse with:
            data: List[MacroEconomicStandardDataRecord] - Raw indicator records
            sources: Source with title and URL to Capital IQ platform
            message: Summary of records retrieved
            isError: Boolean indicating success/failure

    Available Data Fields (selected examples):
        - DataSourcePeriodDisplay: Year of the data point (e.g., "2024")
        - RealGDPGrowthAR: Real GDP growth rate (%)
        - NominalGDPAR: Nominal GDP in billions (typically USD)
        - NominalGDPLCUAR: Nominal GDP in billions local currency units
        - ConsumerPriceInflationAR: CPI inflation rate (%)
        - ECRUnemploymentRateAR: Unemployment rate (%)
        - TradeBalanceAR: Trade balance in billions
        - CurrentAccountBalanceAR: Current account balance in billions

    Example request:
        await get_macroEconomic_Standard_data("12345", period_Range="2022Y,2023Y,2024Y")

    Example response:
        MCPResponse(
            sources=Source(
                title="Macro Economy Standardized Indicators",
                url="https://www.capitaliq.spglobal.com/web/client?auth=inherit#country/economicDemographic?keycountry=US"
            ),
            data=[
                MacroEconomicStandardDataRecord(
                    KeyECRMacroPeriod=14086798,
                    DataSourcePeriodDisplay="2024",
                    RealGDPGrowthAR=0.73,
                    RealGDPLCUAR=1934.45,
                    NominalGDPAR=2372.82,
                    NominalGDPLCUAR=2192.18,
                    ConsumerPriceInflationAR=1.09,
                    ECRUnemploymentRateAR=6.49,
                    CurrentAccountBalanceAR=26.76,
                    TradeBalanceAR=59.28
                ),
                MacroEconomicStandardDataRecord(
                    KeyECRMacroPeriod=14086684,
                    DataSourcePeriodDisplay="2023",
                    RealGDPGrowthAR=0.72,
                    RealGDPLCUAR=1920.51,
                    NominalGDPAR=2304.67,
                    NominalGDPLCUAR=2128.00,
                    ConsumerPriceInflationAR=5.90,
                    ECRUnemploymentRateAR=7.67,
                    CurrentAccountBalanceAR=-0.25,
                    TradeBalanceAR=36.78
                )
            ],
            isError=False,
            message="Retrieved 5 macro-economic records for US"
        )

    Notes:
        - Specify period_Range to get specific years (forecasts or historical)
        - Currency values are typically in billions of respective currency
        - Percentage values like GDP growth and inflation are expressed as decimal values (e.g., 5.9 means 5.9%)
    """
    global async_client
    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    auth_headers = auth.build_auth_headers(raw_request)

    logger.info("[MacroEcon] ENTER get_macroEconomic_Standard_data keyInstn=%s period_Range=%s", keyInstn, period_Range)

    cfg = get_config()
    capitaliq_base_url = cfg["capitaliq_base_url"]
    old_ciqpro_url = cfg["old_ciqpro_url"]
    # Ensure client
    client = async_client or httpx.AsyncClient(timeout=30.0)

    # Resolve KeyCountry
    try:
        # Assign the returned string directly to key_country
        key_country, country_key_instn = await get_company_key_country(str(keyInstn), auth_headers)
    except Exception as e:
        logger.error("[MacroEcon] Exception calling get_company_key_country for keyInstn=%s: %s", keyInstn, e)
        if async_client is None:
            await client.aclose()
        source_obj = await get_mcp_tool_source(
            mcp_tool_name=get_macroEconomic_Standard_data.__name__,
            source_url="",
            institution_id=str(keyInstn),
            headers=auth.build_auth_headers(raw_request),
            default_title="Macro Economy Standardized Indicators",
        )
        return MCPResponse(
            sources=source_obj,
            data=None,
            isError=True,
            message=f"An exception occurred while resolving company country: {e}"
        )

    # Directly check if key_country (which is now a string or None) is falsy
    if not key_country:
        if async_client is None:
            await client.aclose()

        source_obj = await get_mcp_tool_source(
            mcp_tool_name=get_macroEconomic_Standard_data.__name__,
            source_url="",
            institution_id=str(keyInstn),
            headers=auth.build_auth_headers(raw_request),
            default_title="Macro Economy Standardized Indicators",
        )
        return MCPResponse(
            sources=source_obj,
            data=None,
            isError=True,
            message="KeyCountry not found for keyInstn."
        )

    key_country = str(key_country).strip().upper()[:2]

    # Use the provided period_Range directly
    period_path = period_Range

    url = f"{capitaliq_base_url}AIReportBuilder/macroEconomicIndicators/{key_country}/{period_path}/1?formOrder=1"

    source_obj = await get_mcp_tool_source(
        mcp_tool_name=get_macroEconomic_Standard_data.__name__,
        source_url=f"{old_ciqpro_url}#country/economicDemographic?keycountry={key_country}",
        institution_id=str(country_key_instn) if country_key_instn else str(keyInstn),
        headers=auth.build_auth_headers(raw_request),
        default_title="Macro Economy Standardized Indicators",
    )

    logger.info("Fetching data using this url: %s", url)

    headers = {**auth_headers, "Accept": "application/json"}

    logger.info("[MacroEcon] Request keyInstn=%s keyCountry=%s periods=%s url=%s",
                keyInstn, key_country, period_path, url)

    try:
        resp = await client.get(url, headers=headers)
    except Exception as e:
        logger.error("[MacroEcon] HTTP failure keyInstn=%s keyCountry=%s error=%s", keyInstn, key_country, e)
        if async_client is None:
            await client.aclose()
        return MCPResponse(sources=source_obj, data=None, isError=True, message=f"Request failed: {e}")

    if resp.status_code == 204:
        if async_client is None:
            await client.aclose()
        return MCPResponse(
            sources=source_obj,
            data=[],
            isError=False,
            message="No macro-economic data (204)."
        )
    if resp.status_code != 200:
        if async_client is None:
            await client.aclose()
        return MCPResponse(
            sources=source_obj,
            data=None,
            isError=True,
            message=f"{resp.status_code} - {resp.text}"
        )

    try:
        payload = resp.json()
    except ValueError:
        if async_client is None:
            await client.aclose()
        return MCPResponse(sources=source_obj, data=None, isError=True, message="Non-JSON response")

    if not isinstance(payload, list):
        if async_client is None:
            await client.aclose()
        return MCPResponse(sources=source_obj, data=None, isError=True, message="Unexpected payload structure")

    # Deduplicate merge
    merged: dict[str | int, dict] = {}
    for item in payload:
        if not isinstance(item, dict):
            continue
        k = item.get("KeyECRMacroPeriod")
        if k is None:
            merged[f"__row_{id(item)}"] = item
        elif k not in merged:
            merged[k] = item
        else:
            existing = merged[k]
            for fk, fv in item.items():
                if existing.get(fk) in (None, "", []) and fv not in (None, "", []):
                    existing[fk] = fv

    records: list[MacroEconomicStandardDataRecord] = []
    for row in merged.values():
        try:
            records.append(MacroEconomicStandardDataRecord(**row))
        except Exception:
            continue

    logger.info("[MacroEcon] DONE keyInstn=%s keyCountry=%s periods=%s records=%d",
                keyInstn, key_country, period_Range, len(records))

    if async_client is None:
        await client.aclose()

    source_obj = await get_mcp_tool_source(
        mcp_tool_name=get_macroEconomic_Standard_data.__name__,
        source_url=f"{old_ciqpro_url}#country/economicDemographic?keycountry={key_country}",
        institution_id=str(country_key_instn) if country_key_instn else str(keyInstn),
        headers=auth.build_auth_headers(raw_request),
        default_title="Macro Economy Standardized Indicators",
    )
    return MCPResponse(
        sources=source_obj,
        data=records,  # Raw MacroEconomicStandardDataRecord objects
        isError=False,
        message=f"Retrieved {len(records)} macro-economic records for {key_country}"
    )


@mcp.tool()
async def get_economy_in_perspective_data(
        keyInstn: str,
        period: int = 2025,
        sort_by: str = "NominalGDP"
) -> MCPResponse:
    """
    Economy In Perspective

    Retrieves a comparative economic snapshot for a company's country against other global regions,
    sorted by a specified metric to assess its relative position.

    Flow:
    1. Resolves the company's country code (e.g., 'US') from the keyInstn.
    2. Uses the provided period (defaults to 2025).
    3. Fetches data from the Capital IQ 'economyInPerspective' endpoint.
    4. Deduplicates and sorts the records by the 'sort_by' metric in descending order.
    5. Returns the sorted list of raw data records.

    Args:
        keyInstn (str): Company KeyInstn/MI Key to identify the primary country.
        period (int, optional): The target year for the data. Defaults to 2025.
        sort_by (str, optional): The metric to sort the results by. Defaults to "NominalGDP".
                                 Valid options include: "NominalGDP", "RealGDPGrowth", "GDPPerCapita",
                                 "PublicDebtGDP", "ConsumerPriceInflation".

    Returns:
        MCPResponse with:
            data: List[EconomyInPerspectiveRecord] - A sorted list of economic data records.
            sources: Source with title and URL to the Capital IQ platform.
            message: A summary of the operation.
            isError: Boolean indicating success or failure.

    Example Request:
        await get_economy_in_perspective_data(keyInstn="3001792", period=2025, sort_by="NominalGDP")

    Example Response:
        MCPResponse(
            sources=Source(
                title="Economy In Perspective",
                url="https://www.capitaliq.spglobal.com/web/client?auth=inherit#country/countryEconomyInPerspective?keycountry=US"
            ),
            data=[
                EconomyInPerspectiveRecord(
                    Country='US',
                    CountryRegion='USA',
                    NominalGDP=30728.57,
                    RealGDPGrowth=2.32,
                    ECRPopulation=344.7,
                    GDPPerCapita=89147.12,
                    BudgetBalanceGDP=-6.32,
                    PublicDebtGDP=134.97,
                    ConsumerPriceInflation=2.89,
                    DataSourcePeriod='2025'
                ),
                EconomyInPerspectiveRecord(
                    Country='CN',
                    CountryRegion='China',
                    NominalGDP=19199.44,
                    RealGDPGrowth=4.28,
                    ECRPopulation=1416.1,
                    GDPPerCapita=13558.01,
                    BudgetBalanceGDP=-5.5,
                    PublicDebtGDP=68.11,
                    ConsumerPriceInflation=0.17,
                    DataSourcePeriod='2025'
                )
            ],
            isError=False,
            message="Retrieved and sorted 8 unique economy-in-perspective records by NominalGDP."
        )
    """
    global async_client
    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    auth_headers = auth.build_auth_headers(raw_request)

    logger.info("[EconPersp] ENTER get_economy_in_perspective_data keyInstn=%s period=%s sort_by=%s", keyInstn, period,
                sort_by)

    cfg = get_config()
    capitaliq_base_url = cfg.get("capitaliq_base_url", "")
    old_ciqpro_url = cfg.get("old_ciqpro_url", "")

    client = async_client or httpx.AsyncClient(timeout=30.0)

    try:
        key_country, country_key_instn = await get_company_key_country(str(keyInstn), auth_headers)
    except Exception as e:
        logger.error("[EconPersp] Exception in get_company_key_country for keyInstn=%s: %s", keyInstn, e)
        if async_client is None: await client.aclose()
        return MCPResponse(sources=None, data=None, isError=True, message=f"Failed to resolve company country: {e}")

    if not key_country:
        if async_client is None: await client.aclose()
        return MCPResponse(sources=None, data=None, isError=True, message="KeyCountry not found for keyInstn.")

    key_country = str(key_country).strip().upper()[:2]

    url = f"{capitaliq_base_url}AIReportBuilder/economyInPerspective/{key_country}/{period}/?globalRegion=ALL"

    source_obj = await get_mcp_tool_source(
        mcp_tool_name=get_economy_in_perspective_data.__name__,
        source_url=f"{old_ciqpro_url}#country/countryEconomyInPerspective?keycountry={key_country}",
        institution_id=str(country_key_instn) if country_key_instn else str(keyInstn),
        headers=auth.build_auth_headers(raw_request),
        default_title="Economy In Perspective",
    )

    headers = {**auth_headers, "Accept": "application/json"}

    logger.info("[EconPersp] Requesting URL: %s", url)

    try:
        resp = await client.get(url, headers=headers)
        resp.raise_for_status()
        payload = resp.json()
    except Exception as e:
        logger.error("[EconPersp] HTTP request failed for keyInstn=%s: %s", keyInstn, e)
        if async_client is None: await client.aclose()
        return MCPResponse(sources=source_obj, data=None, isError=True, message=f"Request failed: {e}")

    if not isinstance(payload, list):
        if async_client is None: await client.aclose()
        return MCPResponse(sources=source_obj, data=None, isError=True, message="Unexpected payload structure")

    # Deduplicate and sort the records
    unique_records_json = [dict(t) for t in {tuple(d.items()) for d in payload}]

    # Sort by the specified metric in descending order. Handle None values gracefully.
    sorted_records_json = sorted(
        unique_records_json,
        key=lambda x: x.get(sort_by) if x.get(sort_by) is not None else float('-inf'),
        reverse=True
    )[:50]  # Limit to top 50 records 

    records = [EconomyInPerspectiveRecord(**row) for row in sorted_records_json]
    if sorted_records_json:
        df = pd.DataFrame(sorted_records_json)
        csv_data = df.to_csv(index=False)
    else:
        csv_data = ""
    logger.info("[EconPersp] DONE keyInstn=%s, retrieved and sorted %d unique records by %s.", keyInstn, len(records),
                sort_by)

    if async_client is None:
        await client.aclose()

    return MCPResponse(
        sources=source_obj,
        data=csv_data,
        isError=False,
        message=f"Retrieved and sorted {len(records)} unique economy-in-perspective records by {sort_by}."
    )


# Define a custom lifespan for FastAPI with a task to manage MCP


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Initialize MCP server task group
    logger.info("Initializing MCP server task group...")
    global async_client
    async_client = httpx.AsyncClient(timeout=10)
    async with contextlib.AsyncExitStack() as stack:
        await stack.enter_async_context(mcp.session_manager.run())
        yield
    await async_client.aclose()


# Create FastAPI app with lifespan
app = FastAPI(lifespan=lifespan)
app.mount("/company-outlook", mcp.streamable_http_app())
app.include_router(router)
logger.info("Outlook MCP Server started successfully.")
