import argparse
import asyncio
import logging
import sys
import time
from concurrent.futures import ProcessPoolExecutor
from functools import partial
from typing import Optional, Sequence

import pandas as pd
from dotenv import load_dotenv
from tqdm import tqdm
from unstructured.partition.xml import partition_xml

from chatrd.core.document import Document, XMLDocumentSplitter, documents_as_dataframe
from chatrd.core.embedding import embedding_factory
from chatrd.core.vectorstore import OpenSearch
from chatrd.engine.configuration import Constants, get_config_machinery

load_dotenv()


logger = logging.getLogger(__name__)

config_machinery = get_config_machinery()


def _parse_xml(text: str, xml_keep_tags: bool) -> str:
    elements = partition_xml(text=text, xml_keep_tags=xml_keep_tags)
    return "\n\n".join([str(e) for e in elements])


def load_documents(
    df: pd.DataFrame,
    text_col_name: str,
    metadata_col_names: Sequence[str],
    xml_keep_tags: bool = False,
    max_workers: Optional[int] = None,
) -> Sequence[Document]:
    df = df.copy()
    with ProcessPoolExecutor(max_workers=max_workers) as executor:
        parsed_xml = list(
            tqdm(executor.map(partial(_parse_xml, xml_keep_tags=xml_keep_tags), df[text_col_name]), total=len(df))
        )
    df[text_col_name] = parsed_xml

    documents = []
    for _, r in df.iterrows():
        text = r[text_col_name]
        metadata = {k: r[k] for k in metadata_col_names}
        documents.append(Document(content=text, metadata=metadata))
    return documents


async def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--index-name", required=True, type=str, help="OpenSearch index name for the documents")
    parser.add_argument(
        "--input-file-path", required=True, type=str, help="the input file which contains text and metatdata"
    )
    parser.add_argument("--text-col-name", required=True, type=str, help="the column name for text")
    parser.add_argument(
        "--metadata-col-names", required=True, type=str, help="the column names for metadata using ',' as separator"
    )
    parser.add_argument(
        "--output-file-path", required=True, type=str, help="the output file which contains splitted documents"
    )
    parser.add_argument("--n-samples", required=False, type=int, default=None, help="use a smaller subset for testing")
    parser.add_argument("--is-criteria", required=False, action="store_true", help="document type")
    parsed = parser.parse_args()
    logger.info(f"running ingestion with the input arguments: {parsed}")

    index_name = parsed.index_name
    input_file_path = parsed.input_file_path
    text_col_name = parsed.text_col_name
    metadata_col_names = parsed.metadata_col_names.split(",")
    output_file_path = parsed.output_file_path
    n_samples = parsed.n_samples
    is_criteria = parsed.is_criteria

    embedding_model = embedding_factory(model_name="cohere")
    user_name = config_machinery.get_config_value(Constants.OpenSearch.OPENSEARCH_USER_NAME)
    password = config_machinery.get_config_value(Constants.OpenSearch.OPENSEARCH_PASSWORD)
    host = config_machinery.get_config_value(Constants.OpenSearch.OPENSEARCH_HOST)
    port = config_machinery.get_config_value(Constants.OpenSearch.OPENSEARCH_PORT)
    open_search = OpenSearch(host, port, user_name, password, index_name, embedding_model)

    logger.info(f"load data from {input_file_path}")
    df = pd.read_csv(input_file_path).fillna(value="")
    if n_samples is not None:
        df = df.sample(n=n_samples, random_state=42)
    logger.info(f"loaded {df.shape[0]} articles with {df.shape[1]} columns {df.columns.tolist()}")

    logger.info("reading xml docs")
    documents = load_documents(
        df, text_col_name=text_col_name, metadata_col_names=metadata_col_names, xml_keep_tags=True
    )
    logger.info(
        f"created {len(documents)} docs with the text column {text_col_name} "
        f"and the metadata columns {metadata_col_names}"
    )

    logger.info("splitting docs")
    splitter = XMLDocumentSplitter(is_criteria=is_criteria)
    splitted_documents = splitter.split_documents(documents)
    logger.info(f"{len(splitted_documents)} chunks generated")

    logger.info(f"saving splitting docs to {output_file_path}")
    documents_as_dataframe(splitted_documents).to_parquet(output_file_path)
    logger.info(f"{len(splitted_documents)} splitting docs saved")

    logger.info(f"creating an index {index_name}")
    # start_time = time.time()
    # open_search.add_documents(splitted_documents, 32)
    # print(f"Elapsed time for Indexing: {time.time() - start_time} seconds")
    start_time = asyncio.get_event_loop().time()
    await open_search.aadd_documents(splitted_documents, 64)
    end_time = asyncio.get_event_loop().time()
    elapsed_time = end_time - start_time
    print(f"Elapsed time for Indexing: {elapsed_time} seconds")
    logger.info(f"a new index {index_name} created and ingesting done")


if __name__ == "__main__":
    logging.basicConfig(
        stream=sys.stdout,
        format="%(asctime)s [%(processName)s/%(process)d] [%(levelname)s] %(name)s:%(lineno)d: %(message)s",
        level=logging.INFO,
    )
    start_time = time.time()
    asyncio.run(main())
    print("Total time : ", time.time() - start_time)
