from fastapi import Request
default_auth_token = '<TOKEN>'

def build_auth_headers(request: Request) -> dict:
    """Extract Authorization header from the request and build headers for downstream API."""
    auth_token = request.headers.get("authorization")
    if not auth_token:
        auth_token = default_auth_token
    return {"Authorization": auth_token, "Content-Type": "application/json"}

