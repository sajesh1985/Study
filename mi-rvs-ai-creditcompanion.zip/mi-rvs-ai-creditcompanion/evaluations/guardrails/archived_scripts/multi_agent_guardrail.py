import boto3
import json

# Initialize AWS Bedrock client
bedrock_runtime = boto3.client("bedrock-runtime")



# modelId = "us.amazon.nova-lite-v1:0"

modelId = "arn:aws:bedrock:us-east-1:339712941790:inference-profile/us.anthropic.claude-3-7-sonnet-20250219-v1:0"

import boto3
import pandas as pd
import json
import tqdm.auto as tqdm
import os


path_for_question_csv = "questions/test_questions_dataset.csv"

# prompt_version = "separate_17_03"
prompt_version = "all_cat_vs_keywords"

questions_dir = "../data/guardrails/questions/"
questions_files = [
    "advice.csv", 
   "malicious.csv", 
   "opinion.csv", 
   "internal_operations.csv", 
   "competitors.csv",
    "confiential.csv",
    "client_support.csv",
    "public_filings.csv",
   "non_blocked_questions_full.csv"
]


def open_test_questions():
    dfs = []
    for f in questions_files:
        path = os.path.join(questions_dir, f)
        if f != questions_files[-1]:
            dfs.append(pd.read_csv(path).head(10))
        else:
            dfs.append(pd.read_csv(path).head(80))
            

    return pd.concat(dfs).fillna("").reset_index(drop=True)

def open_definition_file(topic):
    with open(f"../data/guardrails/moderation_prompts/{prompt_version}/{topic}.txt", 'r') as f:
        return f.read()
        
# topics = ["advice", 
#            'malicious', 
#            'opinion', 
#            'internal_operations', 
#            'confidential', 
#            'competitors', 
#            'client_support',
#            'public_filings']
topics = ["all_categories_minus_kw", 
           'keywords_public_filings_competitors']

topic_definitions = {}
for t in topics:
    topic_definitions[t] = open_definition_file(t)

    
df = open_test_questions()

import concurrent.futures
import pandas as pd
from langchain_aws import ChatBedrockConverse
from tqdm import tqdm
import asyncio
from ast import literal_eval
import time

# Initialize the LLM
llm = ChatBedrockConverse(model=modelId)

SLEEP = 2

# # Load the template
# with open("moderation_prompts/separate_17_03/template.txt", 'r') as f:
#     template = f.read()

def fill_prompt_template(question, topic):
    """Fill the prompt template with the given question and topic."""
    return template.replace("[[user_question]]", question).replace("[[topic]]", topic)

async def invoke_llm(question, topic):
    """Invoke the LLM synchronously inside a separate thread."""
    prompt = fill_prompt_template(question, topic)
    return llm.invoke(prompt).text()  # Extract response text

async def process_single_question(question):
    """Processes a single question by running all topic-related prompts in parallel threads."""
    results = []

    results = await asyncio.gather(*[invoke_llm(question, topic) for topic in topic_definitions])

    return list(zip(topics, results))

async def process_questions_sequentially(df, results=[], start_idx=0):
    """Processes each question one by one, but executes topic-related prompts in parallel threads."""

    for idx, question in tqdm(enumerate(df["question"].values[start_idx:])):
        time.sleep(SLEEP)
        try:
            result = await process_single_question(question)
    
            record = {}
            record["question"] = question
            for r in literal_eval(str(result)):
                record[r[0]] = r[1]
            results.append(record)
        except:
            print(f"Failed at idx {idx+start_idx}")
            with open("start_idx.txt", "w") as f:
                f.write(str(idx + start_idx))
            return results

    print(f"Finished.")
    with open("start_idx.txt", "w") as f:
        f.write("0")
    return results


async def main():

    with open("start_idx.txt", "r") as f:
        start_idx = int(f.read())
    start = time.time()
    # Run LLM processing
    print(start_idx)
    results = await process_questions_sequentially(df, start_idx=start_idx)
    end = time.time()

    duration = end-start
    results = pd.DataFrame.from_records(results)

    try:
        existing_results = pd.read_csv("llm_output.csv")
        existing_results = pd.concat([existing_results, results])
        existing_results.to_csv("llm_output.csv", index=False)
    except: 
        results.to_csv("llm_output.csv", index=False)

    try:
        if start_idx == 0:
            running_duration = 0
        else:
            with open("duration.txt", "r") as f:
                running_duration = f.read()
        with open("duration.txt", "w") as f:
            f.write(str(duration + int(running_duration)))

    except:
        with open("duration.txt", "w") as f:
            f.write(str(duration + int(running_duration)))
    
    return results

results = await main()


map_filter_to_reason ={
    "Investment_Advice":"advice",
    "Malicious_Prompts":"malicious",
    "Opinions_of_Quality":"opinion",
    "SP_Internal_Operations":"internal_operations",
    "Competitors":"competitors",
    "Confidential_Information":"confidential",
    "Client_Support":"client_support",
    'Public_Filings':"public_filings"
}

filters = ["Investment_Advice", 
           'Malicious_Prompts', 
           'Opinions_of_Quality', 
           'SP_Internal_Operations', 
           'Confidential_Information', 
           'Competitors', 
           'Client_Support',
           'Public_Filings']
inv = {}

for k, v in map_filter_to_reason.items():
    inv[v] = k

for c in inv.keys():
    results[inv[c]] = results[c] == "BLOCK"

results["prediction"] = results[map_filter_to_reason.keys()].any(axis=1)
cols = ["question", "prediction"] + filters

final = df.merge(results[cols], on="question")

with open("duration.txt", "r") as f:
    duration = float(f.read())
rows_processed = df.shape[0]

remove_delay = rows_processed*5

duration -= remove_delay

duration_single = duration/rows_processed

df2 = pd.DataFrame(final)
df2 = df2.rename(columns={"blocked_reason":"ground_truth_blocked_reason"})
# df2["ground_truth_blocked"] = df2["ground_truth_blocked"].astype(str).str.lower()
df3 = df2.loc[df2['ground_truth_blocked'] != df2['prediction']]
tp_plus_fp = df2.loc[df2['ground_truth_blocked'] == True]
tp_plus_fn = df2.loc[df2['prediction'] == True]
tp = tp_plus_fp.loc[tp_plus_fp["prediction"] == True]

print(tp_plus_fp.shape[0], tp_plus_fn.shape[0], tp.shape[0])
recall = tp.shape[0]/tp_plus_fp.shape[0]
precision = tp.shape[0]/tp_plus_fn.shape[0]

# avg_q_time = total_duration/df.shape[0]

results = {

    
    "total_questions": df.shape[0],
    "num_questions_answered": df2.shape[0],
    "error_outputs": df.shape[0] - df2.shape[0],
    "avg_query_time_secs": duration_single,
    "valid_questions_total": df2.loc[df2['ground_truth_blocked'] == 'false'].shape[0],
    "invalid_questions_total": df2.loc[df2['ground_truth_blocked'] == 'true'].shape[0],
    "invalid_q_categories": {
        "advice": df2.loc[df2['ground_truth_blocked_reason'] == 'advice'].shape[0],
        "malicious": df2.loc[df2['ground_truth_blocked_reason'] == 'malicious'].shape[0],
        "opinion": df2.loc[df2['ground_truth_blocked_reason'] == 'opinion'].shape[0],
        "internal_operations": df2.loc[df2['ground_truth_blocked_reason'] == 'internal_operations'].shape[0],
        "confidential": df2.loc[df2['ground_truth_blocked_reason'] == 'confidential'].shape[0],
        "competitors": df2.loc[df2['ground_truth_blocked_reason'] == 'competitors'].shape[0],
        "client_support": df2.loc[df2['ground_truth_blocked_reason'] == 'client_support'].shape[0],
        "public_filings": df2.loc[df2['ground_truth_blocked_reason'] == 'public_filings'].shape[0],
    },
    "guardrail_acted_correctly": df2.loc[df2['ground_truth_blocked'] == df2['prediction']].shape[0],
    "guardrail_acted_incorrectly": df3.shape[0],
    "recall": recall,
    "precision": precision,
    "blocked_valid_question": df3.loc[df3['ground_truth_blocked'] == False].shape[0],
    "allowed_invalid_question": df3.loc[df3['ground_truth_blocked'] == True].shape[0],
}

filters = ["Investment_Advice", 
           'Malicious_Prompts', 
           'Opinions_of_Quality', 
           'SP_Internal_Operations', 
           'Confidential_Information', 
           'Competitors', 
           'Client_Support',
           'Public_Filings']
map_filter_to_reason ={
    "Investment_Advice":"advice",
    "Malicious_Prompts":"malicious",
    "Opinions_of_Quality":"opinion",
    "SP_Internal_Operations":"internal_operations",
    "Competitors":"competitors",
    "Confidential_Information":"confidential",
    "Client_Support":"client_support",
    'Public_Filings':"public_filings"
}

incorrectly_applied_filters = {}
for f in filters:
    try:
        incorrectly_applied_filters[f] = df3.loc[df3[f] == True].shape[0]
    except:
        pass

results["incorrectly_applied_filters"] = incorrectly_applied_filters

failed_to_apply_filters = {}


for f in filters:
    try:
        reason = map_filter_to_reason[f]
        failed_to_apply_filters[f] = df3.loc[df3['ground_truth_blocked_reason'] == reason].shape[0]
    except:
        pass

results["failed_to_apply_filters"] = failed_to_apply_filters

try:
    os.mkdir(f"outputs/{model}_multi_agent")
except:
    pass

with open(f"outputs/{model}_multi_agent/results.json", 'w') as f:
    json.dump(results, f)

df2.to_csv(f"outputs/{model}_multi_agent/guardrail_question_output.csv", index=False)
df2.loc[df2["ground_truth_blocked"] != df2["prediction"]].to_csv(f"outputs/{model}_multi_agent/guardrail_question_output_no_match.csv")