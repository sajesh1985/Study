package com.fis.digitalpayments.sdk.core;

import android.content.Context;

import com.fis.digitalpayments.sdk.SDKManager;

import static com.fis.digitalpayments.sdk.core.BridgeJSONOperationWrapper.putJSON;

import org.json.JSONObject;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * This bridge returns metadata about the SDK
 */
public class MetadataBridge extends Bridge {

    private final HashMap<String, String[]> mSupportedMethods;

    MetadataBridge() {
        mSupportedMethods = new HashMap<>();
        mSupportedMethods.put("contacts", new String[] {"GET_CONTACTS", "PICK_CONTACT"});
        mSupportedMethods.put("events", new String[] {"REGISTER_NATIVE_MESSAGE_HANDLER", "RAISE_EVENT", "NAVIGATE_BACK" });
    }

    @Override
    public String getBridgeId() {
        return "deviceMetadataBridge";
    }

    @Override
    public void handleRequest(final BridgeRequest bridgeRequest, final BridgeRequestCallback bridgeRequestCallback, final Context context) {
        if (bridgeRequest.getMethod().equals("getMetadata")) {
            createMetadataResponse(bridgeRequest, bridgeRequestCallback, context);
        }
    }

    private void createMetadataResponse(final BridgeRequest bridgeRequest, final BridgeRequestCallback bridgeRequestCallback, final Context context) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                BridgeResponse bridgeResponse;
                try {
                    SemVer version = SDKManager.getVersion(context);

                    JSONObject metadata = new JSONObject();
                    putJSON(metadata, "versionMajor", version.getMajor());
                    putJSON(metadata, "versionMinor", version.getMinor());
                    putJSON(metadata, "versionPatch", version.getPatch());
                    putJSON(metadata, "versionPrerelease", version.getPrerelease());
                    putJSON(metadata, "versionString", version.getVersionString());

                    JSONObject supportedMethods = new JSONObject();
                    for (Map.Entry<String, String[]> entry : mSupportedMethods.entrySet()) {
                        putJSON(supportedMethods, entry.getKey(), Arrays.asList(entry.getValue()));
                    }

                    putJSON(metadata, "supportedMethods", supportedMethods);

                    bridgeResponse = new BridgeResponse(bridgeRequest.getCallbackMethod(), metadata, bridgeRequest.getCallbackKey());
                } catch (BridgeException e) {
                    BridgeMessage bridgeMessage = BridgeMessage.CreateError(BridgeMessageCode.BRIDGE_EXECUTION_FAILED, e.getMessage());
                    bridgeResponse = new BridgeResponse(bridgeRequest.getCallbackMethod(), null, null, bridgeRequest.getCallbackKey(), false, bridgeMessage);
                }

                bridgeRequestCallback.onRequestComplete(bridgeResponse);
            }
        }).start();
    }
}
