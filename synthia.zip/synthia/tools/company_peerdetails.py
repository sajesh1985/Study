import collections
import contextlib
import copy
import logging
import re
from contextlib import asynccontextmanager

import httpx
import unicodedata
from bs4 import BeautifulSoup
from fastapi import FastAPI, APIRouter
from fastapi import Request
from mcp.server.fastmcp import FastMCP, Context

from src.synthia.config.api_config import get_config
from src.synthia.config.payload_config import BANKS_PEER_ANALYTICS_PAYLOAD
from src.synthia.config.payload_config import COMPS_PEER_ANALYTICS_PAYLOAD
from src.synthia.tools.denim_request import CommonDenimRequest, send_ciq_denim_request, get_ciq_company_id
from src.synthia.tools.mcp_responses import MCPResponse, CorporateStructureItem , ReducedDenimResponse
from src.synthia.user_profile.user_profile_provider import fetch_user_profile_data
from src.synthia.utils.logging_config import configure_logging
from . import auth
from src.synthia.utils.source import Source
from .mcp_utils import get_mcp_tool_source
from src.synthia.tools.mappings import PEER_COMPANY_DETAILS_FIELDS

def clean_plain_text(raw):
    if not raw:
        return ""
    soup = BeautifulSoup(raw, "html.parser")
    text = soup.get_text(separator=" ", strip=True)
    # Remove bullet points and non-breaking spaces
    text = text.replace('\u2022', '').replace('\u00a0', '').replace('\u2019', '')
    # Normalize unicode spaces
    text = ''.join(' ' if unicodedata.category(c) == 'Zs' else c for c in text)
    text = text.lstrip()
    # Remove leading headings with optional punctuation, whitespace, and case-insensitivity
    text = re.sub(
        r'^(Outlook|Downside scenario|Upside scenario)[\s:\-–—\.]*', '', text, flags=re.IGNORECASE
    )
    return text.strip()


# Configure logging
logger = configure_logging(logger_name=__name__, log_file='company_peerdetails.log')

mcp: FastMCP = FastMCP("Company Peer Details MCP", stateless_http=True)

logger.info("Peer Details MCP Server starting up...")

router = APIRouter()

# Create a single AsyncClient instance for reuse (performance optimization for Lambda)
async_client: httpx.AsyncClient = None


def set_keyinstn_in_peer_analytics_payload(payload_template: dict, keyinstn: str) -> dict:
    """
    Returns a deep copy of the given peer analytics payload template with keyinstn
    set for baseCompany and all relevant displayValue/value fields.
    """
    payload = copy.deepcopy(payload_template)
    # Set baseCompany
    payload["functionRequests"][0]["query"]["baseCompany"] = keyinstn
    # Set displayValue and value in RankingCriteria -> secondaryKeys for fieldKey "336466"
    ranking_criteria_lines = payload["functionRequests"][0]["query"]["queryLineGroups"][2]["queryLines"]
    for line in ranking_criteria_lines:
        field = line.get("field", {})
        if field.get("fieldKey") == "336466":
            if "secondaryKeys" in field and len(field["secondaryKeys"]) > 0:
                field["secondaryKeys"][0]["displayValue"] = keyinstn
                field["secondaryKeys"][0]["value"] = keyinstn
    return payload


# @mcp.tool()
async def get_company_peerdetails(keyInstn: str) -> MCPResponse:
    """
        Retrieves peer company details for a given company ID using the Capital IQ API.

        Features:
            - Fetches peer company ratings, financial highlights, and market-derived signals.
            - Processes and structures peer data for analytics or downstream services.
            - Logs request and response details.

        Endpoint:
            GET /company-peerdetails/{keyInstn}

        Args:
            keyInstn (str): The unique identifier for the company (e.g., 4574287).

        Returns:
            MCPResponse:
                source (Source): Information about the data source, including title and link.
                data (dict): {
                    <company_name> (dict): {
                        RT_ENTITY_NAME (str): The full legal name of the rated entity.
                        Institution Id (str): Unique identifier for the institution or company.
                        Issuer Credit Rating (Foreign Currency LT) (Optional[str]): Long-term issuer credit rating in foreign currency.
                        Rating Date (Optional[str]): Date when the current credit rating was assigned.
                        Last Review Date (Optional[str]): Date when the rating was last reviewed.
                        CreditWatch/Outlook (Optional[str]): Current outlook or watch status.
                        CreditWatch/Outlook Date (Optional[str]): Date when the outlook or watch status was last updated.
                        Scores & Modifiers (Optional[str]): Additional scores or rating modifiers, if any.
                        Scores & Modifiers Date (Optional[str]): Date when scores or modifiers were last updated.
                        Scores (Optional[str]): Detailed scoring information, if available.
                        Business Risk (Optional[str]): Assessment of the company's business risk profile.
                        Industry Risk (Optional[str]): Risk level associated with the industry.
                        Country Risk (Optional[str]): Risk level associated with the country of operation.
                        CICRA (Optional[str]): Composite Industry and Country Risk Assessment.
                        Competitive Position (Optional[str]): Evaluation of the company's competitive standing.
                        Financial Risk (Optional[str]): Assessment of the company's financial risk profile.
                        Anchor (Optional[str]): Baseline rating before applying modifiers.
                        Modifiers (Optional[str]): Additional rating modifiers, if any.
                        Diversification/ Portfolio Effect (Optional[str]): Impact of diversification or portfolio on the rating.
                        Capital Structure (Optional[str]): Assessment of the company's capital structure.
                        Financial Policy (Optional[str]): Evaluation of the company's financial policy.
                        Liquidity (Optional[str]): Assessment of the company's liquidity position.
                        Management And Governance (Optional[str]): Evaluation of management quality and governance.
                        Comparable Rating Analysis (Optional[str]): Impact of comparable rating analysis.
                        Captive Finance (Optional[str]): Information about captive finance operations, if any.
                        Stand Alone Credit Profile (Optional[str]): Stand-alone credit profile rating.
                        Fiscal Period (Optional[str]): Fiscal year or period for the financial data.
                        Period End Date (Optional[str]): End date of the fiscal period.
                        Currency Code (Optional[str]): Currency in which financials are reported.
                        Adjustment Status (Optional[str]): Status of the rating adjustment.
                        Key Figures (Optional[str]): Key financial figures, if available.
                        Revenue, Adjusted($M) (Optional[str]): Adjusted revenue in millions of USD.
                        EBITDA, Adjusted($M) (Optional[str]): Adjusted EBITDA in millions of USD.
                        Operating Income (After D&A), Adjusted($M) (Optional[str]): Adjusted operating income after depreciation and amortization, in millions.
                        EBIT, Adjusted($M) (Optional[str]): Adjusted earnings before interest and taxes, in millions.
                        FFO, Adjusted($M) (Optional[str]): Adjusted funds from operations, in millions.
                        Cash Flow from Ops, Adjusted (Pensions Normalized)($M) (Optional[str]): Adjusted cash flow from operations, pensions normalized, in millions.
                        Capital Expenditures, Adjusted($M) (Optional[str]): Adjusted capital expenditures, in millions.
                        Free Operating Cash Flow, Adjusted($M) (Optional[str]): Adjusted free operating cash flow, in millions.
                        Dividends, Adjusted($M) (Optional[str]): Adjusted dividends paid, in millions.
                        Share Repurchases($M) (Optional[str]): Value of share repurchases, in millions.
                        Discretionary Cash Flow, Adjusted($M) (Optional[str]): Adjusted discretionary cash flow, in millions.
                        Cash & Short-Term Investments, Adjusted($M) (Optional[str]): Adjusted cash and short-term investments, in millions.
                        Debt, Adjusted($M) (Optional[str]): Adjusted total debt, in millions.
                        Equity, Adjusted($M) (Optional[str]): Adjusted total equity, in millions.
                        Debt and Equity, Adjusted($M) (Optional[str]): Combined adjusted debt and equity, in millions.
                        Core Ratios (Optional[str]): Key financial ratios, if available.
                        Debt/ EBITDA, Adjusted(x) (Optional[str]): Adjusted debt to EBITDA ratio.
                        FFO/ Debt, Adjusted(%) (Optional[str]): Adjusted funds from operations to debt ratio, as a percentage.
                        Supplemental Ratios - Cash Flow Payback (Optional[str]): Additional cash flow payback ratios, if available.
                        Operating Cash Flow/ Debt, Adjusted(%) (Optional[str]): Adjusted operating cash flow to debt ratio, as a percentage.
                        Free Operating Cash Flow/ Debt, Adjusted(%) (Optional[str]): Adjusted free operating cash flow to debt ratio, as a percentage.
                        Discretionary Cash Flow/ Debt(%) (Optional[str]): Discretionary cash flow to debt ratio, as a percentage.
                        Supplemental Ratios - Interest Coverage (Optional[str]): Additional interest coverage ratios, if available.
                        EBITDA Interest Coverage, Adjusted(x) (Optional[str]): Adjusted EBITDA to interest coverage ratio.
                        FFO Cash Interest Coverage, Adjusted(x) (Optional[str]): Adjusted FFO to cash interest coverage ratio.
                        Profitability Metrics (Optional[str]): Key profitability metrics, if available.
                        EBITDA Margin, Adjusted(%) (Optional[str]): Adjusted EBITDA margin, as a percentage.
                        Return on Capital, Adjusted(%) (Optional[str]): Adjusted return on capital, as a percentage.
                        EBIT Margin(%) (Optional[str]): EBIT margin, as a percentage.
                        Other Sector Specific Ratios (Optional[str]): Other ratios specific to the sector, if available.
                        Debt/ Debt and Equity, Adjusted(%) (Optional[str]): Adjusted debt to debt and equity ratio, as a percentage.
                        Debt/ Debt and Equity Underpreciated Basis(%) (Optional[str]): Debt to debt and equity ratio on an underappreciated basis, as a percentage.
                        Debt Fixed Charge Coverage(%) (Optional[str]): Debt fixed charge coverage ratio, as a percentage.
                        Return on Common Equity Adj for AFUDC, Adjusted(%) (Optional[str]): Adjusted return on common equity, adjusted for AFUDC, as a percentage.
                        EBIT Interest Coverage, Adjusted(x) (Optional[str]): Adjusted EBIT to interest coverage ratio.
                        Other Operating Metrics (Optional[str]): Other operating metrics, if available.
                        Annual Revenue Growth, Adjusted(%) (Optional[str]): Adjusted annual revenue growth, as a percentage.
                        Operating Income (After D&A)/ Revenues, Adjusted(%) (Optional[str]): Adjusted operating income after D&A to revenues ratio, as a percentage.
                        Common Dividend Payout Ratio, Adjusted(%) (Optional[str]): Adjusted common dividend payout ratio, as a percentage.
                        Last Updated Date (Optional[str]): Date when the data was last updated.
                        OUTLOOK (Optional[str]): Internal or external outlook code or identifier.
                        Summary (Optional[str]): HTML-formatted summary of the rating rationale or outlook.
                        Downside Scenario (Optional[str]): HTML-formatted description of downside risks or scenarios.
                        Downside Financial Thresholds** (Optional[str]): Financial thresholds for downside scenarios, if any.
                        Upside Scenario (Optional[str]): HTML-formatted description of upside potential or scenarios.
                        Upside Financial Thresholds** (Optional[str]): Financial thresholds for upside scenarios, if any.
                        MARKET DERIVED SIGNALS (Optional[str]): Market-derived signals, if available.
                        Credit Default Swap Based Signal (Optional[str]): Signal based on credit default swap data, if available.
                        Signal (Optional[str]): Additional signal or rating indicator.
                        Signal Date (Optional[str]): Date when the signal was last updated.
                        Spread (bps) (Optional[str]): Credit spread in basis points.
                        Z-Score (Optional[str]): Z-score, a statistical measure of credit risk.
                        Probability of Default Based Signal (Optional[str]): Probability of default signal, if available.
                    }
                    ...
                }
            }

        Example:
            {
                "sources": "https://www.capitaliqdev.spglobal.com/apisv3/spg-ratingsresearch-service/api/v3/chatrd/peerDetails/4574287",
                "data": {
                    "Tesla, Inc.": {
                        "RT_ENTITY_NAME": "Tesla, Inc.",
                        "Institution Id": "4574287",
                        "Issuer Credit Rating (Foreign Currency LT)": "BBB",
                        "Rating Date": "10/7/2022",
                        "Last Review Date": "3/19/2025"
                    },
                    "Aston Martin Holdings (UK) Limited": {
                        "RT_ENTITY_NAME": "Aston Martin Holdings (UK) Limited",
                        "Institution Id": "1234567",
                        "Issuer Credit Rating (Foreign Currency LT)": null,
                        "Rating Date": "5/12/2021",
                        "Last Review Date": "2/15/2024"
                    }
                }
            }

     
        """

    logger.info(f"Peer Details request for keyInstn: {keyInstn}")

    # Get configuration
    cfg = get_config()
    capitaliq_base_url = cfg["capitaliq_base_url"]
    peerdetails_url_infix = "chatrd/peerDetails/"
    old_ciqpro_url = cfg["old_ciqpro_url"]

    # Simulate a request to the peerdetails URL
    logger.info(f"get_company_peerdetails called for : {keyInstn}")
    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    url = f"{capitaliq_base_url}{peerdetails_url_infix}{keyInstn}"
    global async_client
    try:
        response = await async_client.get(url, headers=auth.build_auth_headers(raw_request))
        source = await get_mcp_tool_source(
            mcp_tool_name=get_company_peerdetails.__name__,
            source_url=f'{old_ciqpro_url}#ratingsDirect/company/analystpeers?Id={keyInstn}',
            institution_id=str(keyInstn),
            headers=auth.build_auth_headers(raw_request),
            default_title="Company Peer Details",
        )
        if response.status_code == 200:
            peerdetails_data = response.json()

            mnemonics_list = peerdetails_data["CompanyAnalystRatingsPeerResult"][
                "CompanyAnalystPeerRatingMnemonicsList"]
            company_names = {}

            # First, find the row with DataField == "RT_ENTITY_NAME" to get company names
            for item in mnemonics_list:
                if item.get("DataField") == "RT_ENTITY_NAME":
                    for company_field in [k for k in item if k.startswith("Company")]:
                        company_names[company_field] = item[company_field]
                    break

            company_data = collections.defaultdict(dict)

            for item in mnemonics_list:
                mnemonic_name = item.get("MnemonicName")
                if mnemonic_name == "FINANCIAL HIGHLIGHTS" or mnemonic_name == "":
                    continue  # Skip this item
                key = "Institution Id" if mnemonic_name == "RATINGS & SCORES" else (
                            mnemonic_name or item.get("DataField"))

                for company_field, company_name in company_names.items():
                    value = item.get(company_field)
                    if company_name:
                        company_data[company_name][key] = value

            company_data = dict(company_data)

            # Strip HTML from specific fields
            for company, details in company_data.items():
                for field in ["Summary", "Downside Scenario", "Upside Scenario"]:
                    if field in details and details[field]:
                        details[field] = clean_plain_text(details[field])

            logger.info(f"Processed company peers data: {len(company_data)} records")
            return MCPResponse(
                sources=source,
                data=company_data,
                isError=False,
                message=None
            )

        elif response.status_code == 204:
            logger.info(f"No peer details found for the given keyInstn: {keyInstn}")
            return MCPResponse(
                sources=source,
                data=None,
                isError=True,
                message="No peer details found for the given company."
            )
        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return MCPResponse(
                sources=source,
                data=None,
                isError=True,
                message=f"Error: {response.status_code} - {response.text}"
            )
    except httpx.RequestError as e:
        logger.error(f"Request failed: {e}")
        return MCPResponse(
            sources=None,
            data=None,
            isError=True,
            message=f"Request failed: {e}"
        )


@mcp.tool()
async def get_corporate_structure(keyInstn: str, depth: int = 1) -> MCPResponse:
    """
        Retrieves comprehensive corporate structure and ownership data for a given company using the Capital IQ API.

        This function provides detailed information about corporate hierarchies, including parent-subsidiary 
        relationships, ownership percentages, and organizational structure across multiple levels.

        Features:
            - Fetches complete corporate ownership structure and parent-subsidiary relationships
            - Supports configurable depth levels for hierarchical data traversal (1-2 levels)
            - Returns structured data with industry classifications and geographic information
            - Automatically validates and constrains depth parameters for API compatibility


        Args:
            keyInstn (str): The unique Capital IQ institution identifier for the target company.
                          This should be a valid numeric string (e.g., "4000193", "4574287").
            depth (int, optional): The hierarchical depth level for structure retrieval.
                                  - 1 (default): Direct subsidiaries and immediate relationships
                                  - 2: Extended hierarchy including second-level relationships
                                  Values outside 1-2 range are automatically constrained to 1.

        Returns:
            MCPResponse: A comprehensive response object containing:
                sources (Source): Metadata about the data source, including:
                    - title: "Company structure Details"
                    - url: Direct link to the corporate structure view in Capital IQ Pro
                
                data (list[CorporateStructureItem]): Ordered list of corporate entities with:
                    - PercentOwned (Optional[float]): Ownership percentage (0-100). 
                      None if ownership data unavailable.
                    - InstnName (Optional[str]): Full legal name of the institution/entity.
                    - IndustryLongName (Optional[str]): Complete industry classification string.
                    - Country (Optional[str]): Country of incorporation or primary operation.
                    - CompanyRelationshipType (Optional[str]): Type of corporate relationship
                      (e.g., "Subsidiary", "Affiliate", "Joint Venture", "Parent").
                    - KeyInstn (Optional[int]): Unique Capital IQ key for this institution.
                    - KeyInstnParent (Optional[int]): Unique Capital IQ key for the parent entity.
                    - SortOrder (int): Display order based on API response ID field (0-indexed).
                
                isError (bool): False for successful operations, True for errors.
                message (Optional[str]): Error description if isError is True, None otherwise.

   

        Example Response:
            ```json
            {
                "sources": {
                    "title": "Company structure Details",
                    "url": "https://www.capitaliqpro.com/corporate-structure/4574287?depth=1"
                },
                "data": [
                    {
                        "PercentOwned": 100.0,
                        "InstnName": "Tesla Motors Netherlands B.V.",
                        "IndustryLongName": "Automobile Manufacturing",
                        "Country": "Netherlands",
                        "CompanyRelationshipType": "Subsidiary",
                        "KeyInstn": 4000194,
                        "KeyInstnParent": 4574287,
                        "SortOrder": 0
                    },
                    {
                        "PercentOwned": 100.0,
                        "InstnName": "Tesla International B.V.",
                        "IndustryLongName": "Automobile Manufacturing", 
                        "Country": "Netherlands",
                        "CompanyRelationshipType": "Subsidiary",
                        "KeyInstn": 4000195,
                        "KeyInstnParent": 4574287,
                        "SortOrder": 1
                    }
                ],
                "isError": false,
                "message": null
            }
            ```

     
        """

    logger.info(f"Corporate Structure request for keyInstn: {keyInstn}, depth: {depth}")

    # Validate depth parameter
    if depth < 1 or depth > 2:
        logger.warning(f"Invalid depth parameter: {depth}. Defaulting to 1.")
        depth = 1

    # Get configuration
    cfg = get_config()

    capitaliq_base_snl_service_url = cfg["capitaliq_base_snl_service_url"]
    old_ciqpro_url = cfg["old_ciqpro_url"]
    api_endpoint = "Hydrobs/CorporateStructure_GetMultiParentDataNew_V2"
    url = f"{capitaliq_base_snl_service_url}{api_endpoint}?KeyInstn={keyInstn}&KeyGovernmentArea={keyInstn}&KeyWebpartType=2&KeyInstnParent={keyInstn}&ViewSequence={depth}&CompanyRelationshipType=0,2&ActiveGICSCoverage=true&PreqinPremium=false&format=json"
    logger.info(f"get_corporate_structure called for keyInstn: {keyInstn}, depth: {depth}")

    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request

    global async_client
    try:
        source = await get_mcp_tool_source(
            mcp_tool_name=get_corporate_structure.__name__,
            source_url=f'{old_ciqpro_url}#company/corporateStructure?Id={keyInstn}',
            institution_id=str(keyInstn),
            headers=auth.build_auth_headers(raw_request),
            default_title="Company structure Details",
        )
        response = await async_client.get(url, headers=auth.build_auth_headers(raw_request))
        if response.status_code == 200:
            corporate_data = response.json()

            # Process the response data
            processed_data = []

            raw_items = corporate_data.get("value", [])

            for item in raw_items:
                if isinstance(item, dict):
                    # Create Pydantic model instance
                    processed_item = CorporateStructureItem(
                        PercentOwned=item.get("PercentOwned"),
                        InstnName=item.get("InstnName"),
                        IndustryLongName=item.get("IndustryLongName"),
                        Country=item.get("Country"),
                        CompanyRelationshipType=item.get("CompanyRelationshipType"),
                        KeyInstn=item.get("KeyInstn"),
                        KeyInstnParent=item.get("KeyInstnParent"),
                        SortOrder=item.get("Id", 0)  # Use Id field as SortOrder
                    )
                    processed_data.append(processed_item)

            # Sort by SortOrder
            processed_data.sort(key=lambda x: x.SortOrder)

            logger.info(f"Processed corporate structure data: {len(processed_data)} records")
            return MCPResponse(
                sources=source,
                data=processed_data,
                isError=False,
                message=None
            )

        elif response.status_code == 204:
            logger.info(f"No corporate structure data found for keyInstn: {keyInstn}")
            return MCPResponse(
                sources=source,
                data=None,
                isError=True,
                message="No corporate structure data found for the given company."
            )
        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return MCPResponse(
                sources=source,
                data=None,
                isError=True,
                message=f"Error: {response.status_code} - {response.text}"
            )
    except httpx.RequestError as e:
        logger.error(f"Request failed: {e}")
        return MCPResponse(
            sources=None,
            data=None,
            isError=True,
            message=f"Request failed: {e}"
        )


async def get_company_filing_currency(
    keyinstn: str
) -> dict:
    """
    Fetches the filing currency for a company using Denim SOAP request.
    Args:
        symbol (str): The company symbol (e.g., IQ716384).
    Returns:
        dict: Filing currency data.
    """
    # Prepare DenimRequest
   

    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    token = auth.build_auth_headers(raw_request).get("Authorization")
    user_profile = await fetch_user_profile_data(token)
    email = user_profile.get("Email")
   
    metrics = ["IQ_FILING_CURRENCY"]
    logger.info(f"get_company_filing_currency called for symbol: {keyinstn}, metric: {metrics}")
    symbol = await get_ciq_company_id(keyinstn, auth.build_auth_headers(raw_request), async_client=async_client, logger=logger)
    logger.info(f"symbol: {symbol}")
    denim_request = CommonDenimRequest(
        symbol=symbol,
        metrics=metrics
    )

    try:
        logger.info(f"Sending Denim SOAP request for filing currency... {raw_request.method} {raw_request.url}")
        data = await send_ciq_denim_request(
            token=token,
            email=email,
            request_data=denim_request,
            logger=logger
        )
        logger.info(f"Denim response received. Records: {len(data) if data else 0}")
        currency_id = None

        if data and isinstance(data, list):
            for item in data:
                # Check for IQ_FILING_CURRENCY
                if hasattr(item, "Metric") and item.Metric == "IQ_FILING_CURRENCY":
                    currency_id = getattr(item, "CurrencyId", None)
                    if not currency_id or currency_id != "EUR":
                        currency_id = "USD"
                    logger.info(f"Extracted CurrencyId: {currency_id}")

        if not currency_id:
            logger.warning("CurrencyId not found in Denim response.")
            currency_id = "USD"
        return {"data": data}
    except Exception as e:
        logger.error(f"Error in Denim filing currency request: {e}")
        return {"error": str(e)}



from src.synthia.tools.mcp_responses import MCPResponse


@mcp.tool()
async def get_company_peer_analytics(
        keyinstn: str
) -> MCPResponse:
    """
    Retrieves peer analytics data for a given company using its Capital IQ institution ID.

    Args:
        keyinstn (str): The Capital IQ institution ID of the company for which peer analytics are requested.

    Returns:
        MCPResponse: An object containing:
            - sources (Source): Metadata about the data source, including title and URL.
            - data (list[dict] | None): List of peer analytics records, each as a dictionary of metrics and values.
            - isError (bool): Indicates if the request was successful.
            - message (str | None): Error or status message, if applicable.

    Example Response:
        {
            "sources": {
                "title": "{company_name} | Peer Analysis",
                "url": "https://..."
            },
            "data": [
                {
                    "Issuer Rating S&P": "BBB",
                    "Net Income": 1200000,
                    "Total Debt": 500000,
                    "Total Equity": 800000,
                    "Net Financial Position/EBITDA": 2.5,
                    "P/BV": 1.2,
                    ...
                },
                ...
            ],
            "isError": false,
            "message": null
        }
    """
    import json

    global async_client
    logger.info(f"get_company_peer_analytics called for symbol: {keyinstn}")

    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request

    try:
        filing_currency_result = await get_company_filing_currency(keyinstn)
        logger.info(f"Filing currency result: {filing_currency_result}")

        currency_id = "USD"
        template_value = None
        cfg = get_config()
        url = cfg["capitaliq_product_query_url"]
        data = filing_currency_result.get("data")
        if data and isinstance(data, list):
            for item in data:
                if hasattr(item, "Metric") and item.Metric == "IQ_FILING_CURRENCY":
                    currency_id = getattr(item, "CurrencyId", None) or "USD"
                    logger.info(f"Filing currency result: {currency_id}")
                if hasattr(item, "Metric") and item.Metric == "IQ_TEMPLATE":
                    template_value = getattr(item, "value", None)
                    logger.info(f"Filing template result: {template_value}")
    except Exception as e:
        logger.error(f"Error in peer analytics request: {e}")
        return MCPResponse(
            sources=None,
            data=None,
            isError=True,
            message=f"Error in peer analytics request: {e}"
        )
    try:
        payload_str = ""
        payload_dict = {}
        if template_value and template_value.strip().lower() == "banks":
            logger.info(f"It's Banks: {template_value}")
            payload_dict = BANKS_PEER_ANALYTICS_PAYLOAD
        else:
            payload_dict = COMPS_PEER_ANALYTICS_PAYLOAD

        payload_dict["conversionInformation"]["keyCurrency"] = currency_id

        # payload_str = payload_str.replace('"keyCurrency":"USD"', f'"keyCurrency":"{currency_id}"')
        payload_dict["functionRequests"][0]["query"]["baseCompany"] = keyinstn
        payload_dict["functionRequests"][0]["query"]["value"] = keyinstn
        if template_value and template_value.strip().lower() == "banks":
            payload_dict = set_keyinstn_in_peer_analytics_payload(BANKS_PEER_ANALYTICS_PAYLOAD, keyinstn)
        else:
            payload_dict = set_keyinstn_in_peer_analytics_payload(COMPS_PEER_ANALYTICS_PAYLOAD, keyinstn)

        payload_str = json.dumps(payload_dict)

        payload_utf8 = payload_str.encode('utf-8')
        logger.info(f"{payload_utf8}")

        headers = {
            "accept": "application/json, text/javascript, */*; q=0.01",
            "accept-language": "en-US,en;q=0.9,en-IN;q=0.8",
            "com-gmi-application-id": "MI-Web",
            "com-gmi-call-name": f"company/peerAnalyticsMain?id={keyinstn}",
            "content-type": "application/json",
            "origin": cfg["origin"],
            "referer": cfg["old_ciqpro_url"],
            "authorization": auth.build_auth_headers(raw_request).get("Authorization", "")
        }

        response = await async_client.post(
            url,
            headers=headers,
            data=payload_utf8
        )
        text = await response.aread()
        response_text = text.decode("utf-8") if isinstance(text, bytes) else str(text)

        if response.status_code == 200:
            response_data = response.json()
            logger.info(f"Full peer analytics API response: {response_data}")

            # Validate response structure
            if not response_data.get('functionResponses') or len(response_data['functionResponses']) == 0:
                logger.error("Invalid response structure: missing functionResponses")
                raise ValueError("Invalid response structure: missing functionResponses")

            function_response = response_data['functionResponses'][0]
            header_information = function_response.get('headerInformation')
            results = function_response.get("results", [])

            # Validate essential data
            if not header_information:
                logger.error("Invalid response structure: missing headerInformation")
                raise ValueError("Invalid response structure: missing headerInformation")

            if not isinstance(results, list):
                logger.error(f"Invalid results structure: expected list, got {type(results)}")
                raise ValueError("Invalid results structure: expected list")

            captions = [h.get("displayCaption", f"Col{i}") for i, h in enumerate(header_information)]
            logger.info(f"Extracted captions: {captions}")
            logger.info(f"Results count: {len(results) if results else 0}")

            # Check if we have any data to process
            if not results or len(results) == 0:
                logger.warning("No results data found in peer analytics response")
                source = await get_mcp_tool_source(
                    mcp_tool_name=get_company_peer_analytics.__name__,
                    source_url=f'{cfg["old_ciqpro_url"]}#company/peerAnalyticsMain?id={keyinstn}',
                    institution_id=str(keyinstn),
                    headers=auth.build_auth_headers(raw_request),
                    default_title="Company Peer Analytics",
                )
                return MCPResponse(
                    sources=source,
                    data=[],
                    isError=False,
                    message="No peer data available for this company"
                )

            if template_value and template_value.strip().lower() == "banks":
                # Mapping for display captions to user-friendly names (banks)
                caption_map = {
                    "amortizedloans/deposits": "Loan to Deposit Ratio",
                    "costtoincome": "Cost/Income",
                    "problemloansgrosscustomerloans": "NPL Ratio",
                    "roae": "Consolidated ROE",
                    "pricebook": "P/BV",
                    "totalemployees": "Number of Employees",
                    "netprofitconsolidated": "Net Income",
                    "tier1ratio": "Tier 1",
                    "s&pcreditrating": "Issuer Rating S&P",
                    "fitchltissuerdefaultcreditrating": "Issuer Rating Fitch",
                    "moody'slongtermrating": "Issuer Rating Moody's"
                }
                cleaned = []
                for i, c in enumerate(captions):
                    if c and c.strip().lower() == "period ended":
                        continue
                    if c and c.strip().lower() == "geography":
                        continue
                    key = c.replace(" ", "").replace("-", "").replace("/", "").replace("(", "").replace(")", "").lower()
                    mapped_caption = caption_map.get(key, c)
                    cleaned.append((i, mapped_caption))
                parsed_rows = []
                for row in results:
                    parsed_row = {caption: row[i] if i < len(row) else None for i, caption in cleaned if
                                  caption.strip().lower() != "period ended"}
                    parsed_rows.append(parsed_row)
            else:
                # Mapping for display captions to user-friendly names (non-banks)
                caption_map = {
                    "netfinancialposition": "Total Debt",
                    "s&pcreditrating": "Issuer Rating S&P",
                    "moody'slongtermrating": "Issuer Rating Moody's",
                    "esgscoreindustry": "ESG Score",
                    "netincome/loss": "Net Income"
                }
                cleaned = []
                for i, c in enumerate(captions):
                    key = c.replace(" ", "").replace("-", "").replace("/", "").replace("(", "").replace(")", "").lower()
                    mapped_caption = caption_map.get(key, c)
                    cleaned.append((i, mapped_caption))
                parsed_rows = []
                for row in results:
                    parsed_row = {caption: row[i] if i < len(row) else None for i, caption in cleaned}
                    parsed_rows.append(parsed_row)

            # Add ratios if not banks
            if template_value and template_value.strip().lower() != "banks":
                # Use mapped keys from caption_map for calculations
                # caption_map = {
                #     "netfinancialposition": "Total Debt",
                #     "s&pcreditrating": "Issuer Rating S&P",
                #     "moody'slongtermrating": "Issuer Rating Moody's",
                #     "esgscoreindustry": "ESG Score",
                #     "netincome/loss": "Net Income"
                # }
                if parsed_rows and isinstance(parsed_rows, list):
                    add_non_banks_ratios(parsed_rows)
                else:
                    logger.warning("Skipping ratio calculations: parsed_rows is invalid")

            logger.info(f"Peer analytics response data: {parsed_rows}")
            source = await get_mcp_tool_source(
                mcp_tool_name=get_company_peer_analytics.__name__,
                source_url=f'{cfg["old_ciqpro_url"]}#company/peerAnalyticsMain?id={keyinstn}',
                institution_id=str(keyinstn),
                headers=auth.build_auth_headers(raw_request),
                default_title="Company Peer Analytics",
            )
            return MCPResponse(
                sources=source,
                data=parsed_rows,
                isError=False,
                message=None
            )
        else:
            logger.info(f"response.status_code: {response.status_code}")
            logger.info(f"No peer data found for the given company: {keyinstn}")
            source = await get_mcp_tool_source(
                mcp_tool_name=get_company_peer_analytics.__name__,
                source_url=f'{cfg["old_ciqpro_url"]}#company/peerAnalyticsMain?id={keyinstn}',
                institution_id=str(keyinstn),
                headers=auth.build_auth_headers(raw_request),
                default_title="Company Peer Analytics",
            )
            return MCPResponse(
                sources=source,
                data=None,
                isError=True,
                message="No peer data found for the given company."
            )

    except Exception as e:
        logger.error(f"Error in peer analytics request: {e}")
        return MCPResponse(
            sources=None,
            data=None,
            isError=True,
            message=f"Error in peer analytics request: {e}"
        )

@mcp.tool()
async def get_bank_peer_analytics(
    keyinstn: str
) -> MCPResponse:
    """
    Fetches peer analytics specifically for banking institutions using banking-specific metrics and industry filters.
    
    This function is designed for banking companies and uses banking industry codes to ensure 
    only financial services peers are returned in the analysis.

    Args:
        keyinstn (str): The unique Capital IQ institution identifier for the bank.

    Returns:
        MCPResponse: Banking peer analytics data with bank-specific metrics like:
            - Loan to Deposit Ratio
            - Cost/Income Ratio  
            - NPL Ratio
            - Tier 1 Capital Ratio
            - ROE
            - Credit Ratings
    """
    import json

    global async_client
    logger.info(f"get_bank_peer_analytics called for keyinstn: {keyinstn}")

    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request

    try:
        filing_currency_result = await get_company_filing_currency(keyinstn)
        logger.info(f"Filing currency result: {filing_currency_result}")

        currency_id = "USD"
        cfg = get_config()
        url = cfg["capitaliq_product_query_url"]
        
        data = filing_currency_result.get("data")
        if data and isinstance(data, list):
            for item in data:
                # Check for IQ_FILING_CURRENCY
                if hasattr(item, "Metric") and item.Metric == "IQ_FILING_CURRENCY":
                    currency_id = getattr(item, "CurrencyId", None)
                    if not currency_id or currency_id != "EUR":
                        currency_id = "USD"
                    logger.info(f"Extracted CurrencyId: {currency_id}")

        # Use BANKS_PEER_ANALYTICS_PAYLOAD for enhanced banking analytics
        payload_dict = set_keyinstn_in_peer_analytics_payload(BANKS_PEER_ANALYTICS_PAYLOAD, keyinstn)
        payload_dict["conversionInformation"]["keyCurrency"] = currency_id
        
        payload_str = json.dumps(payload_dict)
        payload_utf8 = payload_str.encode('utf-8')

        logger.info(f"Request URL: {url}")
        logger.info(f"Payload length: {len(payload_utf8)} bytes")

        headers = {
            "accept": "application/json, text/javascript, */*; q=0.01",
            "accept-language": "en-US,en;q=0.9,en-IN;q=0.8",
            "com-gmi-application-id": "MI-Web",
            "com-gmi-call-name": f"company/peerAnalyticsMain?id={keyinstn}",
            "content-type": "application/json",
            "origin": cfg["origin"],
            "referer": cfg["old_ciqpro_url"],
            "authorization": auth.build_auth_headers(raw_request).get("Authorization", "")
        }

        response = await async_client.post(url, headers=headers, data=payload_utf8)

        if response.status_code == 200:
            response_data = response.json()
            logger.info(f"Bank peer analytics API response received")
            
            function_response = response_data['functionResponses'][0]
            header_information = function_response.get('headerInformation')
            results = function_response.get("results", [])
            
            if not header_information or not isinstance(results, list):
                raise ValueError("Invalid response structure")
            
            captions = [h.get("displayCaption", f"Col{i}") for i, h in enumerate(header_information)]
            
            if not results:
                logger.warning("No bank peer data found")
                source = Source(title="Bank Peer Analytics", url=f'{cfg["old_ciqpro_url"]}#peerAnalytics/id={keyinstn}')
                return MCPResponse(
                    sources=source,
                    data=[],
                    isError=False,
                    message="No bank peer data available for this company"
                )

            # Banking-specific caption mapping
            caption_map = {
                "amortizedloans/deposits": "Loan to Deposit Ratio",
                "costtoincome": "Cost/Income",
                "problemloansgrosscustomerloans": "NPL Ratio",
                "roae": "Consolidated ROE",
                "pricebook": "P/BV",
                "totalemployees": "Number of Employees",
                "netprofitconsolidated": "Net Income",
                "tier1ratio": "Tier 1",
                "s&pcreditrating": "Issuer Rating S&P",
                "fitchltissuerdefaultcreditrating": "Issuer Rating Fitch",
                "moody'slongtermrating": "Issuer Rating Moody's"
            }
            
            cleaned = []
            for i, c in enumerate(captions):
                if c and c.strip().lower() in ["period ended", "geography"]:
                    continue
                key = c.replace(" ", "").replace("-", "").replace("/", "").replace("(", "").replace(")", "").lower()
                mapped_caption = caption_map.get(key, c)
                cleaned.append((i, mapped_caption))
            
            parsed_rows = []
            for row in results:
                parsed_row = {caption: row[i] if i < len(row) else None for i, caption in cleaned}
                parsed_rows.append(parsed_row)

            logger.info(f"Bank peer analytics response data: {len(parsed_rows)} records")
            source = Source(title="Bank Peer Analytics", url=f'{cfg["old_ciqpro_url"]}#company/peerAnalyticsMain?id={keyinstn}')
            return MCPResponse(
                sources=source,
                data=parsed_rows,
                isError=False,
                message=None
            )
        else:
            logger.error(f"Bank peer analytics API error: {response.status_code}")
            source = Source(title="Bank Peer Analytics", url=f'{cfg["old_ciqpro_url"]}#company/peerAnalyticsMain?id={keyinstn}')
            return MCPResponse(
                sources=source,
                data=None,
                isError=True,
                message="No bank peer data found for the given company."
            )

    except Exception as e:
        logger.error(f"Error in bank peer analytics request: {e}")
        return MCPResponse(
            sources=None,
            data=None,
            isError=True,
            message=f"Error in bank peer analytics request: {e}"
        )



@mcp.tool()
async def get_corporate_peer_analytics(
    keyinstn: str
) -> MCPResponse:
    """
    Fetches peer analytics specifically for corporate/industrial companies using corporate-specific metrics.
    
    This function is designed for non-banking companies and includes corporate-specific 
    calculations and ratios relevant to industrial and commercial entities.

    Args:
        keyinstn (str): The unique Capital IQ institution identifier for the corporation.

    Returns:
        MCPResponse: Corporate peer analytics data with corporate-specific metrics like:
            - Revenue and EBITDA metrics
            - Debt ratios and financial leverage
            - Market valuation multiples
            - ESG scores
            - Credit ratings
    """
    import json

    global async_client
    logger.info(f"get_corporate_peer_analytics called for keyinstn: {keyinstn}")

    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request

    try:
        filing_currency_result = await get_company_filing_currency(keyinstn)
        logger.info(f"Filing currency result: {filing_currency_result}")

        currency_id = "USD"
        cfg = get_config()
        url = cfg["capitaliq_product_query_url"]
        
        data = filing_currency_result.get("data")
        if data and isinstance(data, list):
            for item in data:
                if hasattr(item, "Metric") and item.Metric == "IQ_FILING_CURRENCY":
                    currency_id = getattr(item, "CurrencyId", None)
                    if not currency_id or currency_id != "EUR":
                        currency_id = "USD"
                    logger.info(f"Filing currency result: {currency_id}")

        # Use COMPS_PEER_ANALYTICS_PAYLOAD for corporate analytics
        payload_dict = set_keyinstn_in_peer_analytics_payload(COMPS_PEER_ANALYTICS_PAYLOAD, keyinstn)
        payload_dict["conversionInformation"]["keyCurrency"] = currency_id
        
        payload_str = json.dumps(payload_dict)
        payload_utf8 = payload_str.encode('utf-8')

        logger.info(f"Request URL: {url}")
        logger.info(f"Payload length: {len(payload_utf8)} bytes")

        headers = {
            "accept": "application/json, text/javascript, */*; q=0.01",
            "accept-language": "en-US,en;q=0.9,en-IN;q=0.8",
            "com-gmi-application-id": "MI-Web",
            "com-gmi-call-name": f"company/peerAnalyticsMain?id={keyinstn}",
            "content-type": "application/json",
            "origin": cfg["origin"],
            "referer": cfg["old_ciqpro_url"],
            "authorization": auth.build_auth_headers(raw_request).get("Authorization", "")
        }

        response = await async_client.post(url, headers=headers, data=payload_utf8)
        
        # Log the response details for debugging
        logger.info(f"[DEBUG] get_corporate_peer_analytics - Response status: {response.status_code}")
        logger.info(f"[DEBUG] get_corporate_peer_analytics - Response headers: {dict(response.headers)}")
        logger.info(f"[DEBUG] get_corporate_peer_analytics - Response content length: {len(response.content) if hasattr(response, 'content') else 'N/A'}")

        if response.status_code == 200:
            response_data = response.json()
            logger.info(f"Corporate peer analytics API response received")
            
            function_response = response_data['functionResponses'][0]
            header_information = function_response.get('headerInformation')
            results = function_response.get("results", [])
            
            if not header_information or not isinstance(results, list):
                raise ValueError("Invalid response structure")
            
            captions = [h.get("displayCaption", f"Col{i}") for i, h in enumerate(header_information)]
            
            if not results:
                logger.warning("No corporate peer data found")
                source = Source(title="Corporate Peer Analytics", url=f'{cfg["old_ciqpro_url"]}#peerAnalytics/id={keyinstn}')
                return MCPResponse(
                    sources=source,
                    data=[],
                    isError=False,
                    message="No corporate peer data available for this company"
                )

            # Corporate-specific caption mapping
            caption_map = {
                "netfinancialposition": "Total Debt",
                "s&pcreditrating": "Issuer Rating S&P",
                "moody'slongtermrating": "Issuer Rating Moody's",
                "esgscoreindustry": "ESG Score",
                "netincome/loss": "Net Income"
            }
            
            cleaned = []
            for i, c in enumerate(captions):
                key = c.replace(" ", "").replace("-", "").replace("/", "").replace("(", "").replace(")", "").lower()
                mapped_caption = caption_map.get(key, c)
                cleaned.append((i, mapped_caption))
            
            parsed_rows = []
            for row in results:
                parsed_row = {caption: row[i] if i < len(row) else None for i, caption in cleaned}
                parsed_rows.append(parsed_row)

            # Add corporate-specific ratios
            if parsed_rows and isinstance(parsed_rows, list):
                add_non_banks_ratios(parsed_rows)

            logger.info(f"Corporate peer analytics response data: {len(parsed_rows)} records")
            source = Source(title="Corporate Peer Analytics", url=f'{cfg["old_ciqpro_url"]}#company/peerAnalyticsMain?id={keyinstn}')
            return MCPResponse(
                sources=source,
                data=parsed_rows,
                isError=False,
                message=None
            )
        else:
            logger.error(f"Corporate peer analytics API error: {response.status_code}")
            source = Source(title="Corporate Peer Analytics", url=f'{cfg["old_ciqpro_url"]}#company/peerAnalyticsMain?id={keyinstn}')
            return MCPResponse(
                sources=source,
                data=None,
                isError=True,
                message="No corporate peer data found for the given company."
            )

    except Exception as e:
        logger.error(f"Error in corporate peer analytics request: {e}")
        return MCPResponse(
            sources=None,
            data=None,
            isError=True,
            message=f"Error in corporate peer analytics request: {e}"
        )

@mcp.tool()
async def get_adaptive_peer_analytics(
        keyinstn: str,
        peer_companies: str
) -> MCPResponse:
    """
    Gets peer analysis data based on keyinstn,peer_companies
    
    Args:
        keyinstn (str): The Capital IQ institution ID of the company for analysis.
        peer_companies (str): This is a json array of peer companies with fields name and keyinstn/keyInstn/companyID.
  
    Returns:
        MCPResponse with sources, data, isError, and message fields
    """
    import json
    
    logger.info(f"[MCP] get_adaptive_peer_analytics called for keyinstn: {keyinstn}")
    logger.info(f"[MCP] peer_companies parameter received: '{peer_companies}'")
    logger.info(f"[MCP] peer_companies type: {type(peer_companies)}")
    logger.info(f"[MCP] peer_companies length: {len(peer_companies) if peer_companies else 0}")
    logger.info(f"[MCP] peer_companies is None: {peer_companies is None}")
    logger.info(f"[MCP] peer_companies is empty string: {peer_companies == ''}")
    logger.info(f"[MCP] peer_companies repr: {repr(peer_companies)}")
    
    # Check if peer_companies is actually empty or just whitespace
    if peer_companies:
        logger.info(f"[MCP] peer_companies stripped length: {len(peer_companies.strip())}")
        logger.info(f"[MCP] peer_companies after strip: '{peer_companies.strip()}'")
    else:
        logger.warning(f"[MCP] peer_companies is falsy - will use standard peer analytics")
    
    try:
        # First, get standard corporate peer analytics
        logger.info(f"[MCP] Calling get_corporate_peer_analytics for keyinstn: {keyinstn}")
        standard_peer_response = await get_corporate_peer_analytics(keyinstn)
        
        if standard_peer_response.isError or not standard_peer_response.data:
            logger.warning(f"[MCP] Standard peer analytics failed or returned no data: {standard_peer_response.message}")
            # If standard peer analytics fails, return the error
            return standard_peer_response
        
        # Early return if peer_companies is empty or just whitespace
        if not peer_companies or not peer_companies.strip():
            logger.info(f"[MCP] peer_companies is empty or whitespace. Using standard peer analytics")
            return standard_peer_response
        
        # Extract Entity IDs from standard peer analytics response
        standard_entity_ids = set()
        if isinstance(standard_peer_response.data, list):
            logger.info(f"[MCP] Standard peer response data type: list with {len(standard_peer_response.data)} items")
            for i, peer_data in enumerate(standard_peer_response.data):
                logger.info(f"[MCP] Standard peer[{i}]: {peer_data}")
                if isinstance(peer_data, dict) and 'Entity ID' in peer_data:
                    entity_id = str(peer_data['Entity ID']).strip()
                    if entity_id:
                        standard_entity_ids.add(entity_id)
                        logger.info(f"[MCP] Added Entity ID to standard set: {entity_id}")
        
        logger.info(f"[MCP] Standard peer analytics returned {len(standard_entity_ids)} entity IDs: {standard_entity_ids}")
        
        # Parse UI peer companies
        ui_entity_ids = set()
        if peer_companies and peer_companies.strip():
            try:
                logger.info(f"[MCP] Parsing UI peer companies JSON...")
                logger.info(f"[MCP] Raw peer_companies before JSON parse: '{peer_companies}'")
                logger.info(f"[MCP] peer_companies type before parse: {type(peer_companies)}")
                peer_list = json.loads(peer_companies)
                logger.info(f"[MCP] UI peer_list: {peer_list}")
                logger.info(f"[MCP] UI peer_list type: {type(peer_list)}")
                logger.info(f"[MCP] UI peer_list length: {len(peer_list)}")
                
                if not peer_list:
                    logger.warning(f"[MCP] peer_list is empty after JSON parsing!")
                
                for i, peer in enumerate(peer_list):
                    logger.info(f"[MCP] UI peer[{i}]: {peer}")
                    if isinstance(peer, dict):
                        # Handle both field name formats: keyInstn/keyinstn (schema) and companyID (UI)
                        entity_id_value = peer.get('keyInstn') or peer.get('keyinstn') or peer.get('companyID')
                        if entity_id_value:
                            entity_id = str(entity_id_value).strip()
                            if entity_id:
                                ui_entity_ids.add(entity_id)
                                logger.info(f"[MCP] Added Entity ID to UI set: {entity_id}")
                logger.info(f"[MCP] UI peer companies contain {len(ui_entity_ids)} entity IDs: {ui_entity_ids}")
            except (json.JSONDecodeError, TypeError) as e:
                logger.error(f"[MCP] Failed to parse peer_companies JSON: {e}")
                # If parsing fails, use standard peer analytics
                return standard_peer_response
        else:
            logger.info(f"[MCP] peer_companies is empty or whitespace - no UI peer companies to parse")
        
        # Compare sets to determine if there's a mismatch
        logger.info(f"[MCP] Comparing peer company sets:")
        logger.info(f"[MCP] UI entities: {ui_entity_ids}")
        logger.info(f"[MCP] Standard entities: {standard_entity_ids}")
        logger.info(f"[MCP] Are they equal? {ui_entity_ids == standard_entity_ids}")
        
        # Special case: if UI entities has just one value matching keyinstn, use standard peer response
        if ui_entity_ids and len(ui_entity_ids) == 1 and keyinstn in ui_entity_ids:
            logger.info(f"[MCP] UI entities contains only keyinstn ({keyinstn}). Using standard peer analytics")
            return standard_peer_response
        
        if ui_entity_ids and ui_entity_ids != standard_entity_ids:
            logger.info(f"[MCP] Peer company mismatch detected. UI entities: {ui_entity_ids}, Standard entities: {standard_entity_ids}")
            logger.info(f"[MCP] Using get_company_peer_details_from_finhighlights for custom peer selection")
            
            # Convert UI entity IDs to comma-separated string for keyInstn parameter
            keyinstn_list = ",".join(ui_entity_ids)
            logger.info(f"[MCP] Converted UI entities to keyInstn list: {keyinstn_list}")
            
            # Call custom peer highlights function with proper keyInstn parameter
            custom_peer_response = await get_company_peer_details_from_finhighlights(
                keyInstn=keyinstn_list
            )
            
            # Add metadata to indicate this used custom peer selection
            if not custom_peer_response.isError:
                logger.info("[MCP] Successfully retrieved custom peer analytics data")
            else:
                logger.error(f"[MCP] Custom peer analytics failed: {custom_peer_response.message}")
            
                # Log the full response object
                logger.info(f"[MCP] Full response: {custom_peer_response}")
            return custom_peer_response
        else:
            logger.info("[MCP] No peer company mismatch detected. Using standard corporate peer analytics")
            # Log the full response object
            logger.info(f"[MCP] Full response: {standard_peer_response}")
            return standard_peer_response
            
    except Exception as e:
        logger.error(f"Error in adaptive peer analytics: {e}", exc_info=True)
        return MCPResponse(
            sources=None,
            data=None,
            isError=True,
            message=f"Error in adaptive peer analytics: {e}"
        )



async def get_company_peer_details_from_finhighlights(
        keyInstn: str,
        period_start: str = "FY(now)-5",
        period_end: str = "FY(now)",
        filing_mode: str = "P",
        restatement_type: str = "LA",
        target_currency: str = "USD",
        currency_conversion_mode: str = "SpotRate",
        metric_field: str = ""
) -> MCPResponse:
    """
    Fetches company Peer Details for from CIQ Denim based on a list of requested fields and parameters.
    Args:
        keyinstn (str): List of the Instn id/MI Key/KeyInstn for the company in comma seperated format.
        period_start (str, optional): The start of the reporting period. Defaults to "FY(now)-5". Example: "FY(now)-2".
        period_end (str, optional): The end of the reporting period. Defaults to "FY(now)".
        filing_mode (str, optional): The filing mode. Defaults to "P" (Period).
            P: Period, Used when we want to get the latestvalue for a given period
            F: Filing, needed when user wants to get the value for a specific date for a given period
        restatement_type (str, optional): The restatement type. Defaults to "LA".
            Available options:
            - L: Latest instance; but depends on your prop financials setting.
            - O: Only original instances.
            - P: Only press release instance.
            - LFR: Excludes press release instances.
            - LRI: Excludes instances without any data, but stays in the same period as Latest.
            - LRP: Excludes instances without any data, but can go back periods compared to Latest.
            - LC: Latest instance, but excludes prop financials.
            - LP: Latest instance, but excludes CIQ financials.
            - LA: Latest instance, including both CIQ and prop financials.
            - LPC: Latest instance, but if there are prop financials for that period, use that only.
            - CHP: CHP Chain built with Press Release, Original and Encore instances.
        target_currency (str, optional): The target currency for financial data. Defaults to "USD".
        currency_conversion_mode (str, optional): The currency conversion mode. Defaults to "SpotRate".
    Returns:
        MCPResponse: MCPResponse with sources, data, isError, and message fields.
    """
    cfg = get_config()
    old_ciqpro_url = cfg["old_ciqpro_url"]
    logger.info(f"get_company_peer_details_from_finhighlights called for: {keyInstn} ")

    metrics = [key.strip() for key in metric_field.split(',')] if metric_field.strip() else list(
        PEER_COMPANY_DETAILS_FIELDS.keys())

    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    headers = raw_request.headers
    auth_headers = auth.build_auth_headers(raw_request)
    token = auth_headers.get("Authorization")
    
    # Process keyInstn parameter - can be comma-separated list of institution IDs
    keyInstn_list = []
    if keyInstn and keyInstn.strip():
        # Split by comma and clean up each ID
        keyInstn_list = [id.strip() for id in keyInstn.split(',') if id.strip()]
        logger.info(f"[MCP] Processing {len(keyInstn_list)} company IDs: {keyInstn_list}")
    else:
        logger.error("[MCP] No keyInstn provided")
        return MCPResponse(
            sources=None,
            data=None,
            isError=True,
            message="keyInstn parameter is required"
        )
    results = {}
    errors = []
    last_source = None
    try:
        # Fetch user profile data to get the user's email
        user_profile = await fetch_user_profile_data(token)
        email = user_profile.get("Email")

        for instn in keyInstn_list:
            logger.info(f"[DenimPeerDetails] Starting processing for keyinstn: {instn}")
            try:
                source = await get_mcp_tool_source(
                    mcp_tool_name=get_company_peer_details_from_finhighlights.__name__,
                    source_url=old_ciqpro_url,
                    institution_id=instn,
                    headers=auth_headers,
                    default_title="Company Peer Details"
                )
                logger.info(f"[DenimPeerDetails] Attempting to resolve CIQ company id for keyinstn: {instn}")
                company_id = await get_ciq_company_id(instn, auth_headers, async_client=async_client, logger=logger)
                logger.info(f"[DenimPeerDetails] CIQ company id resolved for {instn}: {company_id}")
                if not company_id:
                    logger.error(f"[DenimPeerDetails] Failed to resolve company_id for keyinstn: {instn}")
                    errors.append(f"Failed to resolve company_id for keyinstn: {instn}")
                    continue

                peer_companies_details_request = CommonDenimRequest(
                    symbol=company_id,
                    metrics=metrics,
                    period_start=period_start,
                    period_end=period_end,
                    filing_mode=filing_mode,
                    restatement_type=restatement_type,
                    target_currency=target_currency,
                    currency_conversion_mode=currency_conversion_mode
                )

                logger.info(f"[DenimPeerDetails] Sending SOAP request for keyinstn {instn} with company_id {company_id}")
                data = await send_ciq_denim_request(
                    token=token,
                    email=email,
                    request_data=peer_companies_details_request,
                    logger=logger
                )

                logger.info(f"[DenimPeerDetails] SOAP response received for {instn}. Raw data count: {len(data) if data else 0}")
                reduced_data: list[ReducedDenimResponse] = []
                for entry in data:
                    if entry.value is not None and entry.value != "":
                        reduced_data.append(ReducedDenimResponse(
                            date=entry.date,
                            value=entry.value,
                            CurrencyId=entry.CurrencyId,
                            display_name=PEER_COMPANY_DETAILS_FIELDS[entry.Metric]
                        ))
                logger.info(f"[DenimPeerDetails] SOAP request complete for {instn}. Filtered records: {len(reduced_data)}")
                results[instn] = reduced_data
                logger.info(f"[DenimPeerDetails] Successfully added {instn} to results")
                last_source = source
            except Exception as e:
                logger.error(f"[DenimPeerDetails] Exception occurred for {instn}: {e}", exc_info=True)
                errors.append(f"{instn}: {str(e)}")
        
        logger.info(f"[DenimPeerDetails] Processing complete. Results for companies: {list(results.keys())}")
        logger.info(f"[DenimPeerDetails] Errors encountered: {errors}")
        
        if errors and not results:
            return MCPResponse(
                sources=None,
                data=None,
                isError=True,
                message="; ".join(errors)
            )
        return MCPResponse(
            sources=last_source,
            data=results,
            isError=bool(errors),
            message="; ".join(errors) if errors else None
        )
    except Exception as e:
        logger.error(f"[DenimPeerDetails] Exception occurred: {e}", exc_info=True)
        return MCPResponse(
            sources=None,
            data=None,
            isError=True,
            message=str(e)
        )


def add_non_banks_ratios(parsed_rows):
    """
    Adds calculated ratio fields to parsed_rows for non-banks using mapped keys.
    """
    if not parsed_rows or not isinstance(parsed_rows, list):
        logger.warning("add_non_banks_ratios: parsed_rows is None or not a list")
        return

    for parsed_row in parsed_rows:
        try:
            net_fin_pos = float(parsed_row.get("Net Financial Position", 0) or parsed_row.get("Total Debt", 0) or 0)
            ebitda = float(parsed_row.get("EBITDA", 0) or 0)
            total_equity = float(parsed_row.get("Total Equity", 0) or 0)
            total_revenue = float(parsed_row.get("Total Revenue", 0) or 0)
            market_cap_raw = parsed_row.get("Market Capitalization", 0)

            parsed_row["Net Financial Position/EBITDA"] = round(net_fin_pos / ebitda, 4) if ebitda else None
            parsed_row["Net Financial Position/Total Equity"] = round(net_fin_pos / total_equity,
                                                                      4) if total_equity else None

            if market_cap_raw == "NA":
                parsed_row["P/BV"] = None
                parsed_row["Multiplo EV (Mkt Cap+PFN) / EBITDA"] = None
            else:
                try:
                    mc = float(market_cap_raw)
                except Exception:
                    mc = 0
                parsed_row["P/BV"] = round(mc / total_equity, 4) if total_equity else None
                parsed_row["Multiplo EV (Mkt Cap+PFN) / EBITDA"] = round((mc + net_fin_pos) / ebitda,
                                                                         4) if ebitda else None

            parsed_row["EBITDA Margin"] = round((ebitda / total_revenue) * 100, 2) if total_revenue else None
        except Exception:
            parsed_row["Net Financial Position/EBITDA"] = None
            parsed_row["Net Financial Position/Total Equity"] = None
            parsed_row["P/BV"] = None
            parsed_row["Multiplo EV (Mkt Cap+PFN) / EBITDA"] = None
            parsed_row["EBITDA Margin"] = None

        # Define a custom lifespan for FastAPI with a task to manage MCP


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Initialize MCP server task group
    logger.info("Initializing MCP server task group...")
    global async_client
    async_client = httpx.AsyncClient(timeout=10)
    async with contextlib.AsyncExitStack() as stack:
        await stack.enter_async_context(mcp.session_manager.run())
        yield
    await async_client.aclose()


@router.get("/company-peerdetails/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "ok"}


# Create FastAPI app with lifespan
app = FastAPI(lifespan=lifespan)
app.mount("/company-peerdetails", mcp.streamable_http_app())
app.include_router(router)
logger.info("Company Peer Details MCP Server started successfully.")
