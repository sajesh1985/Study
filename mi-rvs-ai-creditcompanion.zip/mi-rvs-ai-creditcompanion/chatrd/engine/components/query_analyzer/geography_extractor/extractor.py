import logging
from typing import Optional

from chatrd.core.llm import LCLLMFactory
from chatrd.core.llm.components.message import AIMessage
from chatrd.core.llm.parsers import OutputParserException, PydanticOutputParser
from chatrd.core.llm.prompt.template import SimplePromptTemplate
from chatrd.engine.components.query_analyzer.faulttolerantexecutor import (
    FaultTolerantExecutor,
)
from chatrd.engine.components.query_analyzer.geography_extractor.prompts import (
    GEOGRAPHY_EXTRACTOR_EXAMPLES,
    GEOGRAPHY_EXTRACTOR_PROMPT_TEMPLATE,
    GeographyDecisionOutput,
)

logger = logging.getLogger(__name__)


class GeographyExtractor(FaultTolerantExecutor):
    def __init__(self, model_name: str, temperature: Optional[float] = 0.0):
        self.model = LCLLMFactory().get_llm(
            deployment_name_or_model_id=model_name,
            temperature=temperature,
        )

    def run(self, query: str) -> bool:
        prompt_template = SimplePromptTemplate(template=GEOGRAPHY_EXTRACTOR_PROMPT_TEMPLATE)
        prompt = prompt_template.format(
            **{
                "question": query,
                "examples": GEOGRAPHY_EXTRACTOR_EXAMPLES,
            }
        )

        response = self.model.invoke(prompt)
        if isinstance(response, AIMessage):
            response = response.content

        logger.debug(f"Geography Extractor prompt for LLM : {prompt}")

        parser = PydanticOutputParser(pydantic_object=GeographyDecisionOutput)
        try:
            geography_decision_output = parser.parse(response)
            is_geography = geography_decision_output.geography
            return is_geography
        except OutputParserException as e:
            msg = f"Validation error analyzing from Geography Extractor's llm output {e}.\nResponse is : {response}"
            logger.error(msg)
            raise e
