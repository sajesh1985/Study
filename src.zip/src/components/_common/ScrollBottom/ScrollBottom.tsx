import { useState, useEffect } from 'react';
import { ScrollToBottomButtonContainer } from './ScrollBottom.styles';

const ScrollToBottomButton = () => {
  const [showButton, setShowButton] = useState(false);

  const checkScrollPosition = () => {
    // Show the button if the user has scrolled down more than 300px
    //setShowButton(true);
    setShowButton(window.scrollY < document.documentElement.scrollHeight - window.innerHeight - 300);
  };

  const scrollToBottom = () => {
    window.scrollTo({
      top: document.documentElement.scrollHeight,
      behavior: 'smooth',
    });
  };

  useEffect(() => {
    window.addEventListener('scroll', checkScrollPosition);
    return () => window.removeEventListener('scroll', checkScrollPosition);
  }, []);

  return (
    showButton && (
      <ScrollToBottomButtonContainer onClick={scrollToBottom}>
        ↓
      </ScrollToBottomButtonContainer>
      
    )
  );
};

export default ScrollToBottomButton;
