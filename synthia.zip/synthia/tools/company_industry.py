import contextlib
import logging
from contextlib import asynccontextmanager

import httpx
from fastapi import FastAPI, APIRouter
from fastapi import Request
from mcp.server.fastmcp import FastMCP, Context

# from . import config
from src.synthia.config.api_config import get_config
from src.synthia.tools.mcp_responses import CIQIndustryDataModel, MCPResponse, MIIndustryDataModel, \
    RDIndustryDataModel
from src.synthia.utils.logging_config import configure_logging
from . import auth
from .mcp_utils import get_mcp_tool_source

# Configure logging
logger = configure_logging(logger_name=__name__, log_file='company_industry.log')

mcp: FastMCP = FastMCP("Company Industry MCP", stateless_http=True)

logger.info("Industry MCP Server starting up...")

router = APIRouter()

# Create a single AsyncClient instance for reuse (performance optimization for Lambda)
async_client: httpx.AsyncClient = None


@mcp.tool()
async def get_company_RD_industry(keyInstn: str) -> MCPResponse:
    """
        Retrieve RD industry classification information for a given KeyInstn.

        Args:
            keyInstn (str): The KeyInstn for which to fetch RD industry data.

        Returns:
            MCPResponse: {
                source (Source): Information about the data source, including title and link.
                data (RDIndustryDataModel| None): 
                    - sector (Optional[str or List[str]]): RD sector(s) or None.
                    - sub_sector (Optional[str or List[str]]): RD sub-sector(s) or None.
                    - industry (Optional[str or List[str]]): RD industry/industries or None.
                    - is_rd_entity (bool): True if 'RDIndustries' is present, else False.
                isError (bool): True if the request resulted in an error, else False.
                message (str): Additional information about the request status.

            }

        Examples:
            Bank of America (Multiple sub-sectors)
                {'sector': ['Financial Institutions'], 'sub-sector': ['Asset Managers', 'Banks', 'Broker-Dealers', 'Finance Companies', 'Others'], 'industry': None, 'is_rd_entity': True}

            UBM Development AG (Non-RD company)
                {'sector': [], 'sub-sector': [], 'industry': [], 'is_rd_entity': False}
    """

    logger.info(f"RD Industry request for keyInstn: {keyInstn}")

    # Get configuration
    cfg = get_config()
    old_ciqpro_url = cfg["old_ciqpro_url"]
    capitaliq_base_url = cfg["capitaliq_base_url"]
    industry_url_infix = "AIReportBuilder/companyIndustry/"

    # Simulate a request to the industry URL
    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    url = f"{capitaliq_base_url}{industry_url_infix}{keyInstn}"
    try:
        global async_client
        response = await async_client.get(url, headers=auth.build_auth_headers(raw_request))
        source = await get_mcp_tool_source(
            mcp_tool_name=get_company_RD_industry.__name__,
            source_url=f"{old_ciqpro_url}#company/profile?id={keyInstn}",
            institution_id=keyInstn,
            headers=auth.build_auth_headers(raw_request),
            default_title="Company RD industry classification"
        )
        if response.status_code == 200:
            industry_data = response.json()
            rd_model = parse_rd_industry(industry_data)

            logger.info(f"Parsed RD industry data for {keyInstn}: {rd_model}")
            return MCPResponse(
                sources=source,
                data=rd_model,
                isError=False,
                message=None
            )

        elif response.status_code == 204:
            logger.info(f"No RD industry data found for {keyInstn}.")
            return MCPResponse(
                sources=source,
                data=None,
                isError=False,
                message="No RD industry data found"
            )

        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return MCPResponse(
                sources=source,
                data=None,
                isError=True,
                message=f"Error: {response.status_code} - {response.text}"
            )

    except httpx.RequestError as e:
        logger.error(f"Request failed: {e}")
        return MCPResponse(
            sources=source,
            data=None,
            isError=True,
            message=f"Request failed: {e}"
        )


@mcp.tool()
async def get_company_MI_industry(keyInstn: str) -> MCPResponse:
    """
        Retrieve MI industry classification information for a given KeyInstn.

        Args:
            keyInstn (str): The KeyInstn for which to fetch MI industry data.

        Returns:
            MCPResponse: 
                source (Source): Information about the data source, including title and link.
                data (MIIndustryDataModel | None): 
                    mi_industry (Optional[str or List[str]]): MI industry/industries or None.
                    is_rd_entity (bool): True if 'RDIndustries' is present, else False.
                isError (bool): True if an error occurred, else False.
                message (str | None): Error message if isError is True, else None.

        Examples:
            Amazon.com, Inc.
                {'mi_industry': ['Broadline Retail'], 'is_rd_entity': True}

            UBM Development AG (Non-RD company)
                {'mi_industry': ['Diversified Real Estate Activities'], 'is_rd_entity': False}
    """

    logger.info(f"MI Industry request for keyInstn: {keyInstn}")

    # Get configuration
    cfg = get_config()
    old_ciqpro_url = cfg["old_ciqpro_url"]
    capitaliq_base_url = cfg["capitaliq_base_url"]
    industry_url_infix = "AIReportBuilder/companyIndustry/"

    # Simulate a request to the industry URL
    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    url = f"{capitaliq_base_url}{industry_url_infix}{keyInstn}"
    try:
        global async_client
        response = await async_client.get(url, headers=auth.build_auth_headers(raw_request))
        source = await get_mcp_tool_source(
            mcp_tool_name=get_company_MI_industry.__name__,
            source_url=f"{old_ciqpro_url}#company/profile?id={keyInstn}",
            institution_id=keyInstn,
            headers=auth.build_auth_headers(raw_request),
            default_title="Company MI industry classification"
        )
        if response.status_code == 200:

            industry_data = response.json()
            mi_model = parse_mi_industry(industry_data)

            logger.info(f"Parsed MI industry data for {keyInstn}: {mi_model}")
            return MCPResponse(
                sources=source,
                data=mi_model,
                isError=False,
                message=None
            )

        elif response.status_code == 204:
            logger.info(f"No MI industry data found for {keyInstn}.")
            return MCPResponse(
                sources=source,
                data=None,
                isError=False,
                message="No MI industry data found for the given company."
            )

        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return MCPResponse(
                sources=source,
                data=None,
                isError=True,
                message=f"Error: {response.status_code} - {response.text}"
            )

    except httpx.RequestError as e:
        logger.error(f"Request failed: {e}")
        return MCPResponse(
            sources=source,
            data=None,
            isError=True,
            message=f"Request failed: {e}"
        )


@mcp.tool()
async def get_company_CIQ_industry(keyInstn: str) -> MCPResponse:
    """
        Retrieve CIQ industry classification information for a given KeyInstn.

        Args:
            keyInstn (str): The KeyInstn for which to fetch CIQ industry data.

        Returns:
            MCPResponse: 
                source (Source): Information about the data source, including title and link.
                data (CIQIndustryDataModel | None): {
                    ciq_industry (Optional[str or List[str]]): CIQ industry/industries or None.
                    is_rd_entity (bool): True if 'RDIndustries' is present, else False.
                    isError (bool): True if an error occurred, else False.
                    message (Optional[str]): A message providing additional information about the response.

        Examples:
            Amazon.com, Inc.
                {'ciq_industry': ['Broadline Retail'], 'is_rd_entity': True}

            UBM Development AG (Non-RD company)
                {'ciq_industry': ['Diversified Real Estate Activities'], 'is_rd_entity': False}
    """

    logger.info(f"CIQ Industry request for keyInstn: {keyInstn}")

    # Get configuration
    cfg = get_config()
    old_ciqpro_url = cfg["old_ciqpro_url"]
    capitaliq_base_url = cfg["capitaliq_base_url"]
    industry_url_infix = "AIReportBuilder/companyIndustry/"

    # Simulate a request to the industry URL
    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    url = f"{capitaliq_base_url}{industry_url_infix}{keyInstn}"
    try:
        global async_client
        response = await async_client.get(url, headers=auth.build_auth_headers(raw_request))
        source = await get_mcp_tool_source(
            mcp_tool_name=get_company_CIQ_industry.__name__,
            source_url=f"{old_ciqpro_url}#company/profile?id={keyInstn}",
            institution_id=keyInstn,
            headers=auth.build_auth_headers(raw_request),
            default_title="Company CIQ industry classification"
        )
        if response.status_code == 200:

            industry_data = response.json()
            ciq_model = parse_ciq_industry(industry_data)

            logger.info(f"Parsed CIQ industry data for {keyInstn}: {ciq_model}")
            return MCPResponse(
                sources=source,
                data=ciq_model,
                isError=False,
                message=None
            )

        elif response.status_code == 204:
            logger.info(f"No CIQ industry data found for {keyInstn}.")
            return MCPResponse(
                sources=source,
                data=None,
                isError=False,
                message="No CIQ industry data found for the given company."
            )

        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return MCPResponse(
                sources=source,
                data=None,
                isError=True,
                message=f"Error: {response.status_code} - {response.text}"
            )

    except httpx.RequestError as e:
        logger.error(f"Request failed: {e}")
        return MCPResponse(
            sources=source,
            data=None,
            isError=True,
            message=f"Request failed: {e}"
        )

@mcp.tool()
async def get_company_all_industries(keyInstn: str) -> MCPResponse:
    """
    Retrieve all industry classification information (RD, MI, CIQ) for a given KeyInstn.

    Args:
        keyInstn (str): The KeyInstn for which to fetch industry data.

    Returns:
        MCPResponse: {
            sources (Source): Information about the data source, including title and link.
            data (dict | None): {
                rd (RDIndustryDataModel | None): Retrieve RD industry classification (Sector, SubSector and Industry) information for a given KeyInstn.
                mi (MIIndustryDataModel | None): Retrieve MI industry classification information for a given KeyInstn.
                ciq (CIQIndustryDataModel | None): Retrieve CIQ industry classification information for a given KeyInstn.
            }
            isError (bool): True if the request resulted in an error, else False.
            message (str): Additional information about the request status.
        }
    """
    logger.info(f"All Industry request for keyInstn: {keyInstn}")

    cfg = get_config()
    old_ciqpro_url = cfg["old_ciqpro_url"]
    capitaliq_base_url = cfg["capitaliq_base_url"]
    industry_url_infix = "AIReportBuilder/companyIndustry/"

    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    url = f"{capitaliq_base_url}{industry_url_infix}{keyInstn}"
    try:
        global async_client
        response = await async_client.get(url, headers=auth.build_auth_headers(raw_request))
        source = await get_mcp_tool_source(
            mcp_tool_name=get_company_all_industries.__name__,
            source_url=f"{old_ciqpro_url}#company/profile?id={keyInstn}",
            institution_id=keyInstn,
            headers=auth.build_auth_headers(raw_request),
            default_title="Company all industry classification"
        )
        if response.status_code == 200:
            industry_data = response.json()

            # RD
            rd_industries = industry_data.get("RDIndustries", [])
            sector = [item["RDIndustryLongName"] for item in rd_industries if item.get("KeyIndustryCategory") == 0]
            sub_sector = [item["RDIndustryLongName"] for item in rd_industries if item.get("KeyIndustryCategory") == 1]
            industry = [item["RDIndustryLongName"] for item in rd_industries if item.get("KeyIndustryCategory") == 2]
            rd_model = RDIndustryDataModel(
                sector=sector or None,
                sub_sector=sub_sector or None,
                industry=industry or None,
                is_rd_entity=bool(rd_industries)
            ) if rd_industries else None

            # MI
            mi_industries = industry_data.get("MIIndustries", [])
            mi_industry = [item.get("MIIndustryLongName") for item in mi_industries if item.get("KeyIndustryRelationshipLevel") == 0]
            mi_model = MIIndustryDataModel(
                mi_industry=mi_industry or None,
                is_rd_entity=bool(industry_data.get("RDIndustries"))
            ) if mi_industries else None

            # CIQ
            ciq_industries = industry_data.get("CIQIndustries", [])
            ciq_industry = [item.get("CIQIndustryLongName") for item in ciq_industries if item.get("KeyIndustryRelationshipLevel") == 0]
            ciq_model = CIQIndustryDataModel(
                ciq_industry=ciq_industry or None,
                is_rd_entity=bool(industry_data.get("RDIndustries"))
            ) if ciq_industries else None

            logger.info(f"Parsed all industry data for {keyInstn}")

            return MCPResponse(
                sources=source,
                data={
                    "rd": rd_model,
                    "mi": mi_model,
                    "ciq": ciq_model
                },
                isError=False,
                message=None
            )

        elif response.status_code == 204:
            logger.info(f"No industry data found for {keyInstn}.")
            return MCPResponse(
                sources=source,
                data=None,
                isError=False,
                message="No industry data found"
            )

        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return MCPResponse(
                sources=source,
                data=None,
                isError=True,
                message=f"Error: {response.status_code} - {response.text}"
            )

    except httpx.RequestError as e:
        logger.error(f"Request failed: {e}")
        return MCPResponse(
            sources=None,
            data=None,
            isError=True,
            message=f"Request failed: {e}"
        )
    
def parse_rd_industry(industry_data):
    rd_industries = industry_data.get("RDIndustries", [])
    sector = [item["RDIndustryLongName"] for item in rd_industries if item.get("KeyIndustryCategory") == 0]
    sub_sector = [item["RDIndustryLongName"] for item in rd_industries if item.get("KeyIndustryCategory") == 1]
    industry = [item["RDIndustryLongName"] for item in rd_industries if item.get("KeyIndustryCategory") == 2]
    return RDIndustryDataModel(
        sector=sector or None,
        sub_sector=sub_sector or None,
        industry=industry or None,
        is_rd_entity=bool(rd_industries)
    ) if rd_industries else None

def parse_mi_industry(industry_data):
    mi_industries = industry_data.get("MIIndustries", [])
    mi_industry = [item.get("MIIndustryLongName") for item in mi_industries if item.get("KeyIndustryRelationshipLevel") == 0]
    return MIIndustryDataModel(
        mi_industry=mi_industry or None,
        is_rd_entity=bool(industry_data.get("RDIndustries"))
    ) if mi_industries else None

def parse_ciq_industry(industry_data):
    ciq_industries = industry_data.get("CIQIndustries", [])
    ciq_industry = [item.get("CIQIndustryLongName") for item in ciq_industries if item.get("KeyIndustryRelationshipLevel") == 0]
    return CIQIndustryDataModel(
        ciq_industry=ciq_industry or None,
        is_rd_entity=bool(industry_data.get("RDIndustries"))
    ) if ciq_industries else None

# Define a custom lifespan for FastAPI with a task to manage MCP
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Initialize MCP server task group
    logger.info("Initializing MCP server task group...")
    global async_client
    async_client = httpx.AsyncClient(timeout=10)
    async with contextlib.AsyncExitStack() as stack:
        await stack.enter_async_context(mcp.session_manager.run())
        yield
    # Shutdown: Close the AsyncClient
    await async_client.aclose()


@router.get("/company-industry/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "ok"}


# Create FastAPI app with lifespan
app = FastAPI(lifespan=lifespan)
app.mount("/company-industry", mcp.streamable_http_app())
app.include_router(router)
