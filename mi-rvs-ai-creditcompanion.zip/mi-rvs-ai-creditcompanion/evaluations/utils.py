import json

import pandas as pd
from datasets import Dataset

mapping = {
    "default": {"docs": "chatrd_source_docs", "gtruth": "pronto_response", "answer": "chatrd_response"},
    "chtrdVsgtruth": {"docs": "chatrd_source_docs", "gtruth": "gtruth_response", "answer": "chatrd_response"},
    "prontoVsgtruth": {"docs": "pronto_fragments", "gtruth": "gtruth_response", "answer": "pronto_response"},
    "only_precision": {"docs": "chatrd_source_docs", "gtruth": "chatrd_response", "answer": "chatrd_response"},
}


def create_dataset_from_predictions(predictions_list, version="default"):
    examples = []
    for pred in predictions_list:
        docs_list = pred[mapping[version]["docs"]]
        new_docs = []
        if version in ["default", "chtrdVsgtruth", "only_precision"]:
            for content in eval(docs_list):
                if content != "":
                    info_text = f"""SOURCE_SECTOR: {content.metadata.get("SOURCE_SECTOR", '')}
                                    ENTITY_LEGAL_NAME: {content.metadata.get("ENTITY_LEGAL_NAME", '')}
                                    PreferredTitle: {content.metadata.get("PreferredTitle", '')}
                                    chunk_title: {content.metadata.get("chunk_title", '')}
                                    ARTICLE_DATE: {content.metadata.get("ARTICLE_DATE", '')}
                                    TEXT: {content.text}"""
                    new_docs.append(info_text)
        else:
            new_docs = docs_list
        new_dic = {
            "question": pred["question"],
            "ground_truths": [pred[mapping[version]["gtruth"]]],
            "answer": pred[mapping[version]["answer"]],
            "contexts": new_docs,
        }
        examples.append(new_dic)
    ex = pd.DataFrame(examples)

    question_list = ex["question"].tolist()
    ground_truth = ex["ground_truths"].tolist()
    answer = ex["answer"].tolist()
    context = ex["contexts"].tolist()
    dataset_dict = {"question": question_list, "answer": answer, "ground_truths": ground_truth, "contexts": context}
    dataset_new = Dataset.from_dict(dataset_dict)
    return dataset_new


def create_dataframe_from_json(file_path):
    f = open(file_path)
    test_cases = json.loads(f.read())
    test_cases_df = pd.DataFrame(test_cases)

    return test_cases_df
