import logging
from abc import ABC, abstractmethod
from typing import Literal, Sequence

from pydantic import BaseModel, Field, field_validator

from chatrd.core.llm.components.message import (
    AIMessage,
    BaseMessage,
    HumanMessage,
    SystemMessage,
)

logger = logging.getLogger(__name__)


class PromptValue(BaseModel, ABC):
    """Base abstract class for inputs to any language model.
    PromptValues can be converted to both LLM (pure text-generation) inputs and ChatModel inputs.
    """

    @abstractmethod
    def to_string(self) -> str:
        """Return prompt value as string."""

    @abstractmethod
    def to_messages(self) -> list[BaseMessage]:
        """Return prompt as a list of Messages."""


class StringPromptValue(PromptValue):
    """String prompt value."""

    type: Literal["StringPromptValue"] = "StringPromptValue"
    text: str = Field(..., description="The text of the prompt.")

    def to_string(self) -> str:
        """Return prompt as string."""
        return self.text

    def to_messages(self) -> list[BaseMessage]:
        """Return prompt as messages."""
        return [HumanMessage(content=self.text)]


class ChatPromptValue(PromptValue):
    """Chat prompt value."""

    type: Literal["ChatPromptValue"] = "ChatPromptValue"

    messages: Sequence[BaseMessage] = Field(..., description="The messages in the chat prompt.")

    @field_validator("messages", mode="before")
    def validate_messages(cls, messages: Sequence[BaseMessage]) -> Sequence[BaseMessage]:
        """Validate that messages are a sequence of BaseMessage."""
        if isinstance(messages, str):
            messages = [HumanMessage(content=messages)]
        if not isinstance(messages, Sequence):
            messages = [messages]
        for idx, message in enumerate(messages):
            if isinstance(message, str):
                messages[idx] = HumanMessage(content=message)
            if not isinstance(message, BaseMessage):
                raise TypeError(f"Each message must be an instance of BaseMessage, but got {type(message)}.")
        return messages

    def to_string(self) -> str:
        """Return prompt as string."""
        return self._get_buffer_string(messages=self.messages)

    def to_messages(self) -> list[BaseMessage]:
        """Return prompt as a list of messages."""
        return list(self.messages)

    @staticmethod
    def _get_buffer_string(messages: Sequence[BaseMessage], human_prefix: str = "Human", ai_prefix: str = "AI") -> str:
        """Convert a sequence of Messages to strings and concatenate them into one string."""
        string_messages = []
        for msg in messages:
            if isinstance(msg, HumanMessage):
                role = human_prefix
            elif isinstance(msg, AIMessage):
                role = ai_prefix
            elif isinstance(msg, SystemMessage):
                role = "System"
            else:
                logger.warning(f"Got unsupported message type: {type(msg)}")
                role = "Anonymous"
            message = f"{role}: {msg.content}"
            string_messages.append(message)

        return "\n".join(string_messages)
