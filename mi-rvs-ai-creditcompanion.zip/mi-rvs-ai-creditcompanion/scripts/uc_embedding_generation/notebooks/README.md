# Prereq

Need to have chatrd package and conda environment with environment.yml to run training notebooks

# Data generation

Routing data is generated through sampling questions from templates. Templates are example queries that have placeholders which can be filled in programatically. For example

What is the rating for {entity}?

Can turn into
What is the rating for Apple?
What is the rating for Microsoft?
etc.

Templates for each use case are found in the evaluation folder of the chatrd package

https://gitlab.ihsmarkit.com/quantitative.research/chatrd/chatrd/-/tree/develop/scripts/uc_embedding_generation?ref_type=heads

Within the template_values folder we have placeholder values. The file name determines the placeholder name in the templates, for example

entity.json has all the possible entities that can be substituted in any placeholder {entity}

The templates folder has the actual templates where the file name is the use case they fall under, for example "What is the rating for Apple?" falls into the ratings.json file.

# Creating/Modifying Use Cases

For the most part all that needs to be done is modfying which templates are in which use case json files and updated placeholders. For example creating the ratings action use case means

1. Creating the ratings_action.json
2. Writing templates that fall into the use case
3. Pruning templates from other classes that are too similar or overlap

For step 2 we must also consider the [conversational rephraser](https://gitlab.ihsmarkit.com/quantitative.research/chatrd/chatrd/-/blob/develop/chatrd/engine/components/query_analyzer/conversational/prompter.py?ref_type=heads). This component of the CC package takes user queries and rephrases them, serving as a powerful text normalization agent. It is helpful to sample questions and run them through the rephraser to get more data for each use case.

# Finetuning Embedding Model

We use a [SetFit](https://huggingface.co/docs/setfit/conceptual_guides/setfit) model with several modifications to perform fewshot text classification.

Firstly, most of the language model training is done on top of the [Sentence Transformers](https://www.sbert.net/docs/sentence_transformer/training_overview.html) library. We don't use constrastive loss but a variation of triplet loss through [Multiple Negatives Ranking Loss](https://www.sbert.net/docs/package_reference/sentence_transformer/losses.html#multiplenegativesrankingloss) in conjunction with [Matroyshka Loss](https://www.sbert.net/docs/package_reference/sentence_transformer/losses.html#matryoshkaloss) to reduce the full size of the output embeddings.

We chose some reasonably well performing bert-based model, like ModernBert/MPNet. We then perform a [Parameter Effecient Finetuning Method](https://huggingface.co/docs/peft/main/en/conceptual_guides/adapter) only training the adapter, (need to do experimentation with this method to determine best hyperparamters).

At the moment we are using a [PEFT bone adapters](https://huggingface.co/docs/peft/main/package_reference/bone) in conjunction with [modernbert base model](https://huggingface.co/nomic-ai/modernbert-embed-base).

For training example look at the **peft_finetuning** notebook

# Creating Classifier

While we have historically used nearest neighbor classifier these are not the only models we can consider. We need to write a wrapper around different models to make them compatible with the sagemaker endpoint. Each wrapper needs to implement a load and a predict function [classifiers.py](https://github.com/market-intelligence/rvs-ds-cc-routing-endpoint/blob/main/code/classifiers.py). 


For training our nearest neighbor model, look at the **eval_peft** notebook, this will produce a 'use_case_embedding.npz' training data which can be used with the 'knn' classifier, an example is provided here [bone_3](https://github.com/market-intelligence/rvs-ds-cc-routing-endpoint/tree/main/s3_bucket/classifiers/bone_3)
