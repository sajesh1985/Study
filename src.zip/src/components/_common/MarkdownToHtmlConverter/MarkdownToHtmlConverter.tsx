import { marked } from 'marked';
import React from 'react';
import { MarkdownToHtmlConverterStyled } from './MarkdownToHtmlConverter.styles';

interface MarkdownToHtmlConverterProps {
  sourceData: string;
}

export const MarkdownToHtmlConverter: React.FC<MarkdownToHtmlConverterProps> = ({ sourceData }) => {
  const convertedSourceData = marked(sourceData);

  return (
    <MarkdownToHtmlConverterStyled>
      <span dangerouslySetInnerHTML={{ __html: convertedSourceData }} />
    </MarkdownToHtmlConverterStyled>
  );
};
