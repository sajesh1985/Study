import logging
from typing import Dict, Type, LiteralString, Optional, Any, Literal, List, Union
from psycopg_pool import AsyncConnectionPool
import psycopg
from psycopg import sql

from src.synthia.persistence.database_manager import get_connection_pool, initialize_connection_pool

logger = logging.getLogger(__name__)


class Query:
    def __init__(self, sql: LiteralString, schema: Dict[str, Type]):
        self.sql = sql
        self.schema = schema
        self.conn: AsyncConnectionPool | None = None

    def _validate_params(self, params: dict) -> dict:
        filtered = {}
        for key, expected_type in self.schema.items():
            if key not in params:
                raise ValueError(f"Missing required parameter: '{key}'")
            value = params[key]
            if not isinstance(value, expected_type):
                raise TypeError(
                    f"Parameter '{key}' must be of type {expected_type.__name__}, got {type(value).__name__}")
            filtered[key] = value
        return filtered

    async def _is_connection_healthy(self) -> bool:
        try:
            async with self.conn.connection() as aconn:
                async with aconn.cursor() as cur:
                    await cur.execute("SELECT 1")
                    logger.info("Database connection is healthy")
                return True
        except Exception as ex:
            logger.debug("Database connection health check failed: %s", ex)
            return False

    def build_params(self, params: dict) -> dict:
        return self._validate_params(params)

    async def execute(
            self,
            params: Union[dict, list[dict]],
            fetch: Optional[Literal["one", "all"]] = None,
            multiple_insert: bool = False
    ) -> Optional[Union[tuple, List[tuple], None]]:
        if multiple_insert and not isinstance(params, list):
            raise TypeError("For multiple_insert, params must be a list of dictionaries.")
        if not multiple_insert and not isinstance(params, dict):
            raise TypeError("For single insert, params must be a dictionary.")

        params = self._validate_params(params[0] if multiple_insert else params)

        self.conn = get_connection_pool()
        if self.conn and not await self._is_connection_healthy():
            logger.warning("Database connection is unhealthy. Reinitializing connection pool.")
            await initialize_connection_pool()
            self.conn = get_connection_pool()

        return await execute_feedback_query(self.conn, self.sql, params, fetch, multiple_insert)


async def save_feedback_record(feedback: dict, keyonlineuser: int) -> bool:
    """Save Feedback record to PostgreSQL database."""

    query = insert_feedback_query()

    # Handle Pydantic models
    if hasattr(feedback, 'model_dump'):
        feedback_dict = feedback.model_dump()
    elif hasattr(feedback, 'dict'):
        feedback_dict = feedback.dict()
    else:
        feedback_dict = feedback

    params = query.build_params({**feedback_dict, "key_online_user": keyonlineuser})
    try:
        await query.execute(params)
        logger.info("Feedback record saved successfully.")
        return True
    except Exception as e:
        logger.error(f"Failed to save feedback record: {e}", exc_info=True)
        raise

async def list_feedback_records(keyonlineuser: int, job_id: str) -> List[Dict[str, Any]]:
    """List Feedbacks records for a specific user."""
    try:
        query = list_feedbacks_query()
        params = query.build_params({
            'key_online_user': keyonlineuser,
            'job_id': job_id
        })

        rows = await query.execute(params, "all")
        feedbacks = []
        for row in rows:
            logger.info(row[0])
            feedbacks.append({
                "id": str(row[0]),
                "job_id": str(row[1]),
                "sentiment": row[2],
                "feedback": row[3],
                "tags": row[4] if row[4] is not None else [],
                "section_title": row[7] if row[7] is not None else None,
                "created_at": row[5].strftime("%b-%d-%Y") if row[5] else None,
                "updated_at": row[6].strftime("%b-%d-%Y") if row[6] else None
            })

        logger.info(f"Listed {len(feedbacks)} feedback records for user {keyonlineuser}")
        return feedbacks
    except Exception as e:
        logger.error(f"Failed to list feedback records: {e}", exc_info=True)
        raise

def insert_feedback_query() -> Query:
    query: LiteralString = """
        INSERT INTO product.feedbacks (
            job_id, key_online_user, sentiment, feedback, tags, section_title
        ) VALUES (
            %(job_id)s, %(key_online_user)s, %(sentiment)s, %(feedback)s,
            %(tags)s, %(section_title)s
        )
    """

    schema = {
        "job_id": str,
        "key_online_user": int,
        "sentiment": str,
        "feedback": (str, type(None)),
        "tags": (list, type(None)),
        "section_title": (str, type(None))
    }
    
    return Query(query, schema)

def list_feedbacks_query() -> Query:
    query: LiteralString = """
        SELECT id, job_id, sentiment, feedback, tags, created_at, updated_at, section_title
        FROM product.feedbacks
        WHERE key_online_user = %(key_online_user)s
        AND job_id = %(job_id)s
        ORDER BY created_at DESC
        LIMIT 100
    """

    schema = {
        "key_online_user": int,
        "job_id": str
    }

    return Query(query, schema)

async def execute_feedback_query(
    conn: Union[AsyncConnectionPool, psycopg.Connection],
    query: Union[LiteralString, sql.Composed],
    params: Union[dict, list[dict]],
    fetch: Optional[Literal["one", "all"]] = None,
    multiple_insert: bool = False,
):
    if isinstance(conn, AsyncConnectionPool):
        async with conn.connection() as aconn:
            async with aconn.cursor() as cur:
                if multiple_insert:
                    await cur.executemany(query, params)
                else:
                    await cur.execute(query, params)

                if fetch == 'one':
                    return await cur.fetchone()
                elif fetch == 'all':
                    return await cur.fetchall()
                return None

    elif isinstance(conn, psycopg.Connection):
        with conn.cursor() as cur:
            if multiple_insert:
                cur.executemany(query, params)
            else:
                cur.execute(query, params)
            if fetch == 'one':
                return cur.fetchone()
            elif fetch == 'all':
                return cur.fetchall()
            return None
    else:
        raise TypeError("Unsupported connection type")