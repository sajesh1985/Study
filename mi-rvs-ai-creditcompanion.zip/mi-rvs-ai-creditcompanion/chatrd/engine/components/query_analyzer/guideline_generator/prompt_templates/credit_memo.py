from chatrd.engine.components.query_analyzer.utils import EntityType

COMPANY_CREDITMEMO_GUIDELINES_EXAMPLES = """
{
    "question": "What is the credit memo for xyz?",
    "guidelines": "1. Start with a paragraph with a title **Company description**. Format Company description in bold.\n2. Add titles **Strengths**, **Risks**, **Risk Analysis**, **Financial Trends** and **Peer Analysis**.\n3. In bullet points highlight the answer to the titles. **Strengths** - Highlight xyz's unique strengths in bullets. **Risks** - Highlight xyz's potential risks in bullets. **Risk Analysis** - Highlight key factors in bullets influencing xyz's business risk, financial risk and xyz's liquidity.**Financial Trends** -  Provide a bullet wise summary of xyz's revenue and profit growth, xyz's Market share and Outlook, xyz's Cash Flow Trends,Leverage and Debt. **Peer Analysis** - Do a peer comparsion of xyz's unique strengths and weaknesses compared to its peers mentioned in the given rating information documents that you pick to answer this question. Benchmarking Against Top Peers: Compare xyz's performance benchmarks directly with its top competitor.\n4. Add a paragraph with a title **Conclusion** and provide a short summary of the selected relevant findings.\n5. For each bullet add short title highlighted in bold.\n6. Follow the example of the formatting strictly. Do not add extra headers or titles.\nExample of the formatting:\n**Strengths**\n- **Highest global market share**: content\n**Risks**\n- **Increased price competition**: content\n**Peer Analysis**\n- **Peer Comparison**(must have this): content\n- **Benchmarking Against Top Peers**(must have this): content.\n7. Documents in the <rating information> section are sorted by recency (i.e., by articleReleaseDate), with the most recent and up-to-date document listed at the top.You MUST first focus on documents which are most recent and relevant. If documents in the <rating information> section contain conflicting or differing facts/information regarding any of the key points, YOU MUST ALWAYS include and cite ONLY the information provided in the document that is more recent, i.e., is placed higher in the <rating information> section. If several documents contain the same information as the most recent one, you can cite each of them."
}
    __________________
{
    "question": "Write a credit research report for xyz",
    "guidelines": "1. Start with a paragraph with a title **Company description**. Format Company description in bold.\n2. Add titles **Strengths**, **Risks**, **Risk Analysis**, **Financial Trends** and **Peer Analysis**.\n3. In bullet points highlight the answer to the titles. **Strengths** - Highlight xyz's unique strengths in bullets. **Risks** - Highlight xyz's potential risks in bullets. **Risk Analysis** - Highlight key factors in bullets influencing xyz's business risk, financial risk and xyz's liquidity.**Financial Trends** -  Provide a bullet wise summary of xyz's revenue and profit growth, xyz's Market share and Outlook, xyz's Cash Flow Trends,Leverage and Debt. **Peer Analysis** - Do a peer comparsion of xyz's unique strengths and weaknesses compared to its peers mentioned in the given rating information documents that you pick to answer this question. Benchmarking Against Top Peers: Compare xyz's performance benchmarks directly with its top competitor.\n4. Add a paragraph with a title **Conclusion** and provide a short summary of the selected relevant findings.\n5. For each bullet add short title highlighted in bold.\n6. Follow the example of the formatting strictly. Do not add extra headers or titles.\nExample of the formatting:\n**Strengths**\n- **Highest global market share**: content\n**Risks**\n- **Increased price competition**: content\n**Peer Analysis**\n- **Peer Comparison**(must have this): content\n- **Benchmarking Against Top Peers**(must have this): content.\n7. Documents in the <rating information> section are sorted by recency (i.e., by articleReleaseDate), with the most recent and up-to-date document listed at the top.You MUST first focus on documents which are most recent and relevant. If documents in the <rating information> section contain conflicting or differing facts/information regarding any of the key points, YOU MUST ALWAYS include and cite ONLY the information provided in the document that is more recent, i.e., is placed higher in the <rating information> section. If several documents contain the same information as the most recent one, you can cite each of them."
}
    __________________
{
    "question": "Do a credit analysis for xyz with financials",
    "guidelines": "1. Start with a paragraph with a title **Company description**. Format Company description in bold.\n2. Add titles **Strengths**, **Risks**, **Risk Analysis**, **Financial Trends** and **Peer Analysis**.\n3. In bullet points highlight the answer to the titles. **Strengths** - Highlight xyz's unique strengths in bullets. **Risks** - Highlight xyz's potential risks in bullets. **Risk Analysis** - Highlight key factors in bullets influencing xyz's business risk, financial risk and xyz's liquidity.**Financial Trends** -  Provide a bullet wise summary of xyz's revenue and profit growth, xyz's Market share and Outlook, xyz's Cash Flow Trends,Leverage and Debt. **Peer Analysis** - Do a peer comparsion of xyz's unique strengths and weaknesses compared to its peers mentioned in the given rating information documents that you pick to answer this question. Benchmarking Against Top Peers: Compare xyz's performance benchmarks directly with its top competitor.\n4. Add a paragraph with a title **Conclusion** and provide a short summary of the selected relevant findings.\n5. For each bullet add short title highlighted in bold.\n6. Follow the example of the formatting strictly. Do not add extra headers or titles.\nExample of the formatting:\n**Strengths**\n- **Highest global market share**: content\n**Risks**\n- **Increased price competition**: content\n**Peer Analysis**\n- **Peer Comparison**(must have this): content\n- **Benchmarking Against Top Peers**(must have this): content.\n7. Documents in the <rating information> section are sorted by recency (i.e., by articleReleaseDate), with the most recent and up-to-date document listed at the top.You MUST first focus on documents which are most recent and relevant. If documents in the <rating information> section contain conflicting or differing facts/information regarding any of the key points, YOU MUST ALWAYS include and cite ONLY the information provided in the document that is more recent, i.e., is placed higher in the <rating information> section. If several documents contain the same information as the most recent one, you can cite each of them."
}
"""

OTHERS_CREDITMEMO_GUIDELINES_EXAMPLES = """
{
    "question": "Do a credit analysis on xyz.",
    "guidelines": "1. Start with 'Highlights on xyz based on the latest S&P Global Rating's research'. Mention in bullets with short bold titles a pointwise summary on the following key points.\n2.Key Points: a. **Business Profile**: Highlight xyz's business profile in bullets. For each bullet add short title highlighted in bold. b. **Rating**: Highlight xyz's ratings information. c. **Outlook**: Highlight xyz's outlook. d. **Conclusion**: Provide a short summary of the selected relevant findings.\n3.Do not use colons on titles.\n4.Documents in the <rating information> section are sorted by recency (i.e., by articleReleaseDate), with the most recent and up-to-date document listed at the top.You MUST first focus on documents which are most recent and relevant. If documents in the <rating information> section contain conflicting or differing facts/information regarding any of the key points, YOU MUST ALWAYS include and cite ONLY the information provided in the document that is more recent, i.e., is placed higher in the <rating information> section. If several documents contain the same information as the most recent one, you can cite each of them."
}
    __________________
{
    "question": "Write me a credit research report on xyz.",
    "guidelines": "1. Start with 'Highlights on xyz based on the latest S&P Global Rating's research'. Mention in bullets with short bold titles a pointwise summary on the following key points.\n2.Key Points: a. **Business Profile**: Highlight xyz's business profile in bullets. For each bullet add short title highlighted in bold. b. **Rating**: Highlight xyz's ratings information. c. **Outlook**: Highlight xyz's outlook. d. **Conclusion**: Provide a short summary of the selected relevant findings.\n3.Do not use colons on titles.\n4.Documents in the <rating information> section are sorted by recency (i.e., by articleReleaseDate), with the most recent and up-to-date document listed at the top.You MUST first focus on documents which are most recent and relevant. If documents in the <rating information> section contain conflicting or differing facts/information regarding any of the key points, YOU MUST ALWAYS include and cite ONLY the information provided in the document that is more recent, i.e., is placed higher in the <rating information> section. If several documents contain the same information as the most recent one, you can cite each of them."
}
    __________________
{
    "question": "Provide me with a credit brief on xyz.",
    "guidelines": "1. Start with 'Highlights on xyz based on the latest S&P Global Rating's research'. Mention in bullets with short bold titles a pointwise summary on the following key points.\n2.Key Points: a. **Business Profile**: Highlight xyz's business profile in bullets. For each bullet add short title highlighted in bold. b. **Rating**: Highlight xyz's ratings information. c. **Outlook**: Highlight xyz's outlook. d. **Conclusion**: Provide a short summary of the selected relevant findings.\n3.Do not use colons on titles.\n4.Documents in the <rating information> section are sorted by recency (i.e., by articleReleaseDate), with the most recent and up-to-date document listed at the top.You MUST first focus on documents which are most recent and relevant. If documents in the <rating information> section contain conflicting or differing facts/information regarding any of the key points, YOU MUST ALWAYS include and cite ONLY the information provided in the document that is more recent, i.e., is placed higher in the <rating information> section. If several documents contain the same information as the most recent one, you can cite each of them."
}
"""


CREDITMEMO_GUIDELINES_PROMPTS = """
You are an excellent financial credit analyst and you will be given a question from the user.
Your task will be to extract information regarding user question:
* Guidelines highlighting relevant factors when answering the question. (key: guidelines)

<Examples pairs of question (key: question) and guidelines (key: guidelines) are given below in JSON format: Do not stick completely to the values for guidelines shown in examples they are only for taking hints>
{examples}

Take a deep breath and understand that these examples should not affect the extractions for any other keys.

Answer JSON object which should contain following properties:
* "guidelines"

<Question>
{question}

Answer with only a valid guidelines JSON object without anything else. Do not return anything except the valid JSON object.
"""

creditmemo_guidelines = {
    "prompt": CREDITMEMO_GUIDELINES_PROMPTS,
    "examples": {
        EntityType.COMPANY: COMPANY_CREDITMEMO_GUIDELINES_EXAMPLES,
        EntityType.USPF: OTHERS_CREDITMEMO_GUIDELINES_EXAMPLES,
        EntityType.REVENUE_SOURCE: OTHERS_CREDITMEMO_GUIDELINES_EXAMPLES,
        EntityType.SOVEREIGN: OTHERS_CREDITMEMO_GUIDELINES_EXAMPLES,
    },
}
