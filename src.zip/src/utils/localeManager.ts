import i18next from 'i18next';
import ja from '../locales/ja/dashboard.json';
const ns: string[] = ['dashboard']; //add your namespace here, could be multiple

const nsForDashboard = ns[0];

export const addLocaleResourceBundle = (): Promise<any> => {
  const promises: Promise<any>[] = [];
  ns.forEach((nsItem: string) => {
    if (i18next.hasResourceBundle && !i18next.hasResourceBundle(i18next.language, nsItem)) {
      const loadNamespacePromise = import(`../locales/${i18next.language}/${nsItem}.json`);
      const addNamespaceBundlePromise = loadNamespacePromise
        .catch(() => {
          return import(`../locales/${i18next.resolvedLanguage}/${nsItem}.json`);
        })
        .then((nsResource) => {
          return i18next.addResourceBundle(i18next.language, nsItem, nsResource, true);
        });
      promises.push(addNamespaceBundlePromise);
    }
  });
  return Promise.all(promises);
};

export const addOtherLangResourceBundle = (): void => {
  if (i18next.addResourceBundle) {
    i18next.addResourceBundle('ja', nsForDashboard, ja, true);
  }
};
