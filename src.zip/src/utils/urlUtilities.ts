import { config } from '@spglobal/spa';
//import { useUserTraits } from '@spglobal/userprofileservice';
import { getDisplayableNumber } from './numberCurrencyLocalization';
import { Cultures } from './localization';
const cndomain = 'spglobal.cn/';


/**
 *   This Method will make sure we are posting data to correct domain and not to cross-site
 *
 *   @method
 *   @param {string} url                 A URL path
 *   @param {boolean} forceNewDomain     Pass true if want to use new on-prem url forcefully.
 *   @returns {string}                   Return new on prem URL if request is coming on new on-prem or forceNewDomain is true
 */
export function getRelevantDomainURL(url?: string, forceNewDomain?: boolean): string {
  let CnHost;
  if (!url) {
    url = config('interactivex');
    if (window.location.href.toLowerCase().indexOf(cndomain) >= 0) {
      url = 'https://' + window.location.hostname + '/InteractiveX';
      return url;
    }
  }

  const onPremOld = config('onPremOldRootPath')?.toLowerCase() || '';
  const onPremNew = config('onPremRootPath')?.toLocaleLowerCase() || '';
  const onMiCloud = config('onCloudRootPath')?.toLocaleLowerCase() || '';
  let lowerURL = url !== undefined ? url.toLowerCase() : '';

  // if request is coming on new domain we have to use that in url instead of config hard coded
  if (
    onPremNew &&
    onPremOld &&
    (forceNewDomain || window.location.toString().toLowerCase().indexOf(onPremNew) >= 0)
  ) {
    lowerURL = lowerURL.replace(onPremOld, onPremNew);
  }

  if (window.location.href.toLowerCase().indexOf(cndomain) >= 0) {
    if (
      lowerURL.indexOf(onPremOld) >= 0 ||
      lowerURL.indexOf(onPremNew) >= 0 ||
      lowerURL.indexOf(onMiCloud) >= 0
    ) {
      CnHost = window.location.hostname;
      lowerURL = lowerURL
        .replace(onPremOld, CnHost)
        .replace(onPremNew, CnHost)
        .replace(onMiCloud, CnHost);
    }
  }
  return lowerURL;
}

export function isStreamingEnabled()
{
    return !(window.location.href.toLowerCase().indexOf('isstreamingenabled') > -1);
}

export function groupBy(list:any, keyGetter:any):Map<any,any> {
  const map = new Map();
  list.forEach((item:any) => {
       const key = keyGetter(item);
       const collection = map.get(key);
       if (!collection) {
           map.set(key, [item]);
       } else {
           collection.push(item);
       }
  });
  return map;
}

export function NumberFormatter(data: any,culture:any) {
  const d=data.value!=null?getDisplayableNumber(((data.value)), culture.culture, {
    formatNegative: false,
    isPercentage: false,
    useParenthesesFormatting: true,
    maxFractionDigits:2,
    minimumFractionDigits:2
}):null;
  return d;
}

export function getlocalizedCurrencyAsString(value: any,culture : any) {
  if (value !== '' && !isNaN(value)) {
    let tempvalue = parseFloat(value);
    const culturesWithParentheses = [
      Cultures.DEFAULT_CULTURE,
      Cultures.CULTURE_CA,
      Cultures.CULTURE_HK,
      Cultures.CULTURE_ID,
      Cultures.CULTURE_PH,
      Cultures.CULTURE_SG,
      Cultures.CULTURE_HI_IN
    ];
    let absValue = Math.abs(tempvalue).toFixed(2);
        var returnString = Number(absValue).toLocaleString(culture.culture, {
        minimumFractionDigits: 2
      });
  
    return tempvalue < 0 ? (culturesWithParentheses.includes(culture.culture) ? '(' + returnString + ')': '-' +returnString): returnString;
  }
  return value;
}