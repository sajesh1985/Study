import asyncio
import logging
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
from typing import Any, List, Optional, Tuple

from opensearchpy import OpenSearch as OpenSearchClient
from opensearchpy import RequestsHttpConnection
from opensearchpy.exceptions import NotFoundError
from opensearchpy.helpers import bulk

from chatrd.core.document import Document
from chatrd.core.embedding import EmbeddingModel
from chatrd.core.vectorstore import VectorStore

logger = logging.getLogger(__name__)


def _get_opensearch_client(host: str, port: int, user_name: str, password: str) -> OpenSearchClient:
    client = OpenSearchClient(
        hosts=[{"host": host, "port": port}],
        http_auth=(user_name, password),
        use_ssl=True,
        verify_certs=True,
        connection_class=RequestsHttpConnection,
        pool_maxsize=20,
        timeout=60,
    )
    return client


def _bulk_ingest_embeddings(
    client: OpenSearchClient,
    index_name: str,
    embeddings: List[List[float]],
    texts: List[str],
    metadatas: List[dict],
    vector_field: str = "vector_field",
    text_field: str = "text",
    max_chunk_bytes: Optional[int] = 1 * 1024 * 1024,
) -> List[str]:
    requests = []
    return_ids = []
    for i, text in enumerate(texts):
        metadata = metadatas[i]
        request = {
            "_op_type": "index",
            "_index": index_name,
            vector_field: embeddings[i],
            text_field: text,
            "metadata": metadata,
            "_id": metadata["id"],
        }
        requests.append(request)
        return_ids.append(metadata["id"])

    bulk(client, requests, max_chunk_bytes=max_chunk_bytes)
    client.indices.refresh(index=index_name)

    return return_ids


def _get_index_config(n_dim: int) -> dict:
    config = {
        "settings": {"index": {"knn": True, "knn.algo_param.ef_search": 512}},
        "mappings": {
            "properties": {
                "vector_field": {
                    "type": "knn_vector",
                    "dimension": n_dim,
                    "method": {
                        "name": "hnsw",
                        "space_type": "l2",
                        "engine": "faiss",
                        "parameters": {"ef_construction": 512, "m": 16},
                    },
                },
            }
        },
    }
    return config


def _default_approximate_search_query(vector: List[float], k: int = 5, vector_field: str = "vector_field") -> dict:
    """For Approximate k-NN Search, this is the default query."""
    return {
        "size": k,
        "query": {"knn": {vector_field: {"vector": vector, "k": k}}},
    }


def _approximate_search_query_with_efficient_filter(
    vector: List[float], efficient_filter: dict, k: int = 5, vector_field: str = "vector_field"
) -> dict:
    """For Approximate k-NN Search, with Efficient Filter for Lucene and Faiss Engines."""
    search_query = _default_approximate_search_query(vector, k=k, vector_field=vector_field)
    search_query["query"]["knn"][vector_field]["filter"] = efficient_filter
    return search_query


def _approximate_search_query_with_boolean_filter(
    query_vector: List[float],
    boolean_filter: dict,
    k: int = 5,
    vector_field: str = "vector_field",
    subquery_clause: str = "must",
) -> dict:
    """For Approximate k-NN Search, with Boolean Filter."""
    return {
        "size": k,
        "query": {
            "bool": {
                "filter": boolean_filter,
                subquery_clause: [{"knn": {vector_field: {"vector": query_vector, "k": k}}}],
            }
        },
    }


def _hybrid_search_query(
    query: str,
    model_id: str,
    chunk_type: str,
    top_k_text_chunks: int = 0,
    top_k_table_chunks: int = 0,
    search_output_size: int = 100,
    efficient_filter: dict = None,
    vector_field: str = "vector_field",
):
    """
    Constructs an OpenSearch hybrid query with an optional chunk_type filter.

    :param query: The user's search query string.
    :param model_id: The ID of the text embedding model deployed in OpenSearch.
    :param chunk_type: (Optional) The specific chunk type to filter for (e.g., "table", "text").
    :param top_k_text_chunks: Number of top text chunks to retrieve.
    :param top_k_table_chunks: Number of top table chunks to retrieve.
    :param search_output_size: Total number of search results to return.
    :param efficient_filter: Pre-computed filters to apply (e.g., date range).
    :param vector_field: The name of the field containing the document vectors.
    :return: A dictionary representing the OpenSearch query.
    """

    efficient_filter = deepcopy(efficient_filter) if efficient_filter else {"bool": {"must": [], "must_not": []}}
    if "bool" not in efficient_filter:
        efficient_filter["bool"] = {}
    if "must" not in efficient_filter["bool"]:
        efficient_filter["bool"]["must"] = []
    if "must_not" not in efficient_filter["bool"]:
        efficient_filter["bool"]["must_not"] = []

    if chunk_type == "table":
        efficient_filter["bool"]["must"].append({"term": {"metadata.chunk_type": "table"}})
        k_neighbors = round(search_output_size * 0.75)
    elif chunk_type == "non_table":
        if top_k_table_chunks:
            efficient_filter["bool"]["must_not"].append({"term": {"metadata.chunk_type": "table"}})
        k_neighbors = top_k_text_chunks

    out_query = {
        "_source": {"exclude": ["vector_field"]},
        "size": search_output_size,
        "query": {
            "hybrid": {
                "queries": [
                    {"bool": {"must": {"match": {"text": {"query": query}}}, "filter": [efficient_filter]}},
                    {
                        "neural": {
                            vector_field: {
                                "query_text": query,
                                "model_id": model_id,
                                "k": k_neighbors,
                                "filter": efficient_filter,
                            }
                        }
                    },
                ]
            }
        },
    }
    logger.info(f"chunk_type: {chunk_type}, top_k_table_chunks: {top_k_table_chunks}, opensearch_query: {out_query}")

    return out_query


def create_index(
    client: OpenSearchClient,
    index_name: str,
    model: EmbeddingModel,
    documents: List[Document],
    bulk_size: int,
) -> None:
    embeddings = model.embed_documents([documents[0]])
    n_dim = len(embeddings[0])
    config = _get_index_config(n_dim)
    try:
        client.indices.get(index=index_name)
    except NotFoundError:
        client.indices.create(index=index_name, body=config)
    logger.info(f"index created with name : {index_name}")
    n_documents = len(documents)
    logger.info(f"indexing {n_documents} documents")

    for i in range(0, n_documents, bulk_size):
        logger.info(f"indexing documents from {i} to {i + bulk_size}")
        subset_documents = documents[i : (i + bulk_size)]  # noqa: E203

        logger.info("computing embedding")
        embed_subset_documents = [doc.content for doc in subset_documents]
        with ThreadPoolExecutor(max_workers=20, thread_name_prefix="BULK_INGEST_") as executor:
            embeddings = list(executor.map(model.embed_query, embed_subset_documents))
        logger.info("embedding computation done")

        texts = [document.content for document in subset_documents]
        metadatas = [document.metadata for document in subset_documents]

        logger.info("bulk ingesting")
        _bulk_ingest_embeddings(client, index_name, embeddings, texts, metadatas)
        logger.info("bulk ingesting done")
    logger.info("indexing done")


async def acreate_index(
    client: OpenSearchClient,
    index_name: str,
    model: EmbeddingModel,
    documents: List[Document],
    bulk_size: int,
) -> None:
    embeddings = model.embed_documents([documents[0]])
    n_dim = len(embeddings[0])
    config = _get_index_config(n_dim)
    try:
        client.indices.get(index=index_name)
    except NotFoundError:
        client.indices.create(index=index_name, body=config)
    logger.info(f"index created with name : {index_name}")

    with ThreadPoolExecutor(max_workers=5, thread_name_prefix="BULK_INGEST_") as executor:
        n_documents = len(documents)
        logger.info(f"indexing {n_documents} documents")
        futures = []
        loop = asyncio.get_event_loop()
        for i in range(0, n_documents, bulk_size):
            future = loop.run_in_executor(executor, async_ingest_fn, client, index_name, model, documents, bulk_size, i)
            futures.append(future)
        await asyncio.gather(*futures)
    logger.info("indexing done")


def async_ingest_fn(
    client: OpenSearchClient,
    index_name: str,
    model: EmbeddingModel,
    documents: List[Document],
    bulk_size: int,
    i: int,
) -> None:
    logger.info(f"indexing documents from {i} to {i + bulk_size}")
    subset_documents = documents[i : (i + bulk_size)]  # noqa: E203

    logger.info("computing embedding")
    embeddings = model.embed_documents(subset_documents)
    logger.info("embedding computation done")

    texts = [document.content for document in subset_documents]
    metadatas = [document.metadata for document in subset_documents]

    logger.info("bulk ingesting")
    _bulk_ingest_embeddings(client, index_name, embeddings, texts, metadatas)
    logger.info("bulk ingesting done")


def approximate_search_with_scores(
    client: OpenSearchClient,
    index_name: str,
    model: EmbeddingModel,
    query: str,
    model_id: str,
    search_pipeline: str,
    mode: str = "hybrid",
    top_k_text_chunks: int = 0,
    top_k_table_chunks: int = 0,
    efficient_filter: Optional[dict] = None,
    boolean_filter: Optional[dict] = None,
) -> tuple[List[Document], List[float]]:

    if mode == "hybrid":
        logger.info(f"Opensearch query using index {index_name} and date filter {efficient_filter}")

        documents, docs_table, docs_text = [], [], []
        scores, scores_table, scores_text = [], [], []
        # take top_k_table_chunks from table results
        if top_k_table_chunks:
            query_table = _hybrid_search_query(
                query=query,
                model_id=model_id,
                efficient_filter=efficient_filter,
                chunk_type="table",
                top_k_text_chunks=top_k_text_chunks,
                top_k_table_chunks=top_k_table_chunks,
            )
            results = client.search(
                index=index_name,
                body=query_table,
                params={"search_pipeline": search_pipeline},
            )
            for result in (
                results["hits"]["hits"][:top_k_table_chunks]
                if len(results["hits"]["hits"]) > top_k_table_chunks
                else results["hits"]["hits"]
            ):
                text = result["_source"]["text"]
                metadata = result["_source"]["metadata"]
                if "chunk_type" in metadata and metadata["chunk_type"] == "table":
                    docs_table.append(Document(content=text, metadata=metadata))
                    scores_table.append(result["_score"])
        # take top_k_text_chunks from text results
        if top_k_text_chunks:
            query_text = _hybrid_search_query(
                query=query,
                model_id=model_id,
                efficient_filter=efficient_filter,
                chunk_type="non_table",
                top_k_text_chunks=top_k_text_chunks,
                top_k_table_chunks=top_k_table_chunks,
            )
            results = client.search(
                index=index_name,
                body=query_text,
                params={"search_pipeline": search_pipeline},
            )
            for result in (
                results["hits"]["hits"][:top_k_text_chunks]
                if len(results["hits"]["hits"]) > top_k_text_chunks
                else results["hits"]["hits"]
            ):
                text = result["_source"]["text"]
                metadata = result["_source"]["metadata"]
                if top_k_table_chunks:
                    if "chunk_type" in metadata and metadata["chunk_type"] != "table":
                        docs_text.append(
                            Document(content=result["_source"]["text"], metadata=result["_source"]["metadata"])
                        )
                        scores_text.append(result["_score"])
                else:
                    docs_text.append(
                        Document(content=result["_source"]["text"], metadata=result["_source"]["metadata"])
                    )
                    scores_text.append(result["_score"])

        logger.info(
            f"VectorDB - Number of retrieved chunks: {len(docs_table) + len(docs_text)} => table chunks: {len(docs_table)} --- text chunks: {len(docs_text)}"
        )
        documents = docs_table + docs_text
        scores = scores_table + scores_text
    else:
        logger.info("computing embedding")
        embedding = model.embed_query(text=query)
        logger.info(f"embedding computation done, n_dim={len(embedding)}")

        logger.info(f"start to search in index {index_name}")
        if efficient_filter is None and boolean_filter is None:
            query = _default_approximate_search_query(embedding, k)
        elif efficient_filter is not None and boolean_filter is None:
            query = _approximate_search_query_with_efficient_filter(embedding, efficient_filter, k)
        elif efficient_filter is None and boolean_filter is not None:
            query = _approximate_search_query_with_boolean_filter(embedding, boolean_filter, k)
        else:
            raise ValueError("efficient_filter and boolean_filter can't be used at the same time")
        results = client.search(index=index_name, body=query)
        documents, scores = [], []
        for result in results["hits"]["hits"]:
            text = result["_source"]["text"]
            metadata = result["_source"]["metadata"]
            documents.append(Document(content=text, metadata=metadata))
            scores.append(result["_score"])
        logger.info(f"Total {len(documents)} documents found")

    return documents, scores


def _delete_documents(client: OpenSearchClient, index_name: str, ids: List[int], bulk_size: int = 32):
    for idx in range(0, len(ids), bulk_size):
        delete_query = {"query": {"terms": {"metadata.ARTICLE_ID": ids[idx : idx + bulk_size]}}}
        response = client.delete_by_query(index=index_name, body=delete_query)
        client.indices.refresh(index=index_name)


class OpenSearch(VectorStore):
    def __init__(
        self, host: str, port: int, user_name: str, password: str, index_name: str, model: EmbeddingModel
    ) -> None:
        self.client = _get_opensearch_client(host, port, user_name, password)
        self.index_name = index_name
        self.model = model

    def add_documents(self, documents: List[Document], bulk_size: Optional[int] = 500) -> None:
        create_index(self.client, self.index_name, self.model, documents, bulk_size)

    async def aadd_documents(self, documents: List[Document], bulk_size: Optional[int] = 500) -> None:
        await acreate_index(self.client, self.index_name, self.model, documents, bulk_size)

    def get_relevant_documents(
        self,
        query: str,
        model_id: str,
        search_pipeline: str,
        top_k_text_chunks: int = 0,
        top_k_table_chunks: int = 0,
        mode="hybrid",
        **kwargs: Any,
    ) -> tuple[List[Document], List[float]]:
        return approximate_search_with_scores(
            client=self.client,
            index_name=self.index_name,
            model=self.model,
            query=query,
            top_k_text_chunks=top_k_text_chunks,
            top_k_table_chunks=top_k_table_chunks,
            model_id=model_id,
            search_pipeline=search_pipeline,
            mode=mode,
            **kwargs,
        )

    def delete_documents(self, ids: List[int], bulk_size: Optional[int] = 500) -> None:
        return _delete_documents(self.client, self.index_name, ids, bulk_size)

    def update_documents(self, documents: List[Document], bulk_size: Optional[int] = 500) -> Tuple[Any, Any]:
        deleted_ids = []
        for doc in documents:
            deleted_ids.append(doc.metadata["ARTICLE_ID"])
        deleted_ids = list(set(deleted_ids))
        deleted_docs = self.delete_documents(deleted_ids, bulk_size)
        added_docs = self.add_documents(documents=documents, bulk_size=bulk_size)
        return deleted_docs, added_docs
