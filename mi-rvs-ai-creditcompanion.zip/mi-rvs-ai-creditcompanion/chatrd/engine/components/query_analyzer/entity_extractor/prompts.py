ENTITY_EXTRACTOR_EXAMPLES = """
__________________
{
    "question" : "What is xyz's strengths/weaknesses relative to its peers/competitors?",
    "answer": {
        "entities": ["xyz"]
    }
}
__________________
{
    "question" : "Who is the credit analyst of xyz?",
    "answer": {
        "entities": ["xyz"]
    }
}
__________________
{
    "question": "What is the outlook for SF company xyz according to S&P Global Ratings?",
    "answer": {
        "entities": ["xyz"]
    }
}
__________________
{
    "question" : "When was the last downgrade of xyz's credit rating?",
    "answer": {
        "entities": ["xyz"]
    }
}
__________________
{
    "question" : "What is the rationale for the latest rating action on xyz",
    "answer": {
        "entities": ["xyz"]
    }
}
__________________
{
    "question" : "List/Show all peers/competitors of xyz and abc?",
    "answer": {
        "entities": ["xyz", "abc"]
    }
}
__________________
{
    "question": "What impact do ESG factors have on the credit rating for/of xyz (XYZ:XYZXYZ) and abc companies?",
    "answer": {
        "entities": ["XYZ:XYZXYZ", "abc"]
    }
}
__________________
{
    "question": "What is the latest research for/regarding company xyz?",
    "answer": {
        "entities": ["xyz"]
    }
}
__________________
{
    "question": "What are the financial trends of xyz and abc according to S&P Global Ratings?",
    "answer": {
        "entities": ["xyz", "abc"]
    }
}
__________________
{
    "question": "What are the ratings for (XYZXYZ:ABC.A) xyz",
    "answer": {
        "entities": ["XYZXYZ:ABC.A"]
    }
}
__________________
{
    "question": "What's the rating of xyz mil sr nts due mm/dd/yyyy",
    "answer": {
        "entities": ["xyz mil sr nts due mm/dd/yyyy"]
    }
}
__________________
{
    "question": "What are the ratings for xyz?",
    "answer": {
        "entities": ["xyz"]
    }
}
_______________
{
    "question": "What are the risks for automobile industry in xyz countries?",
    "answer": {
        "entities": ["xyz"]
    }
}
_______________
{
    "question": "What are the risks for xyz region banking industry in this year?",
    "answer": {
        "entities": ["xyz"]
    }
}
_______________
{
    "question": "What nuclear power plants are being developed by companies in the abc and xyz regions",
    "answer": {
        "entities": ["abc", "xyz"]
    }
}
_______________
{
    "question": "Generate me xyz country issuers that have a rating above sample_rating",
    "answer": {
        "entities": ["xyz"]
    }
}
_______________
{
    "question": "What are the growth risks for xyz countries transportation sector?",
    "answer": {
        "entities": ["xyz"]
    }
}
__________________
{
    "question": "Explain business risk for corporates",
    "answer": {
        "entities": []
    }
}
__________________
{
    "question": "What are the main factors that influence the credit ratings of sovereign entities?",
    "answer": {
        "entities": []
    }
}
__________________
{
    "question": "What are the latest rating actions in autos",
    "answer": {
        "entities": []
    }
}
_______________
{
    "question": "What would be the impact on the banking sector if Donald Trump wins the presidential election?",
    "answer": {
        "entities": []
    }
}
_______________
{
    "question": "What are the active project deals of Bill Gates?",
    "answer": {
        "entities": []
    }
}
____________________
{
    "question": "What's the list of companies working on crypto technologies?",
    "answer": {
        "entities": [],
    }
}
"""

ENTITY_EXTRACTOR_PROMPT_TEMPLATE = """
You are an excellent financial credit analyst and you will be given a question from the user.
Your task will be to extract information regarding user question:
<instructions>
* Directly mentioned specific entity names in the given question which may be written in an informal or abbreviated way as well. Entity name is considered to be one of these:
<examples>
- company name (e.g. xyz inc, xyz corp, xyz llc, xyz trust, etc.)
- geography name (e.g. city, state, county, country, continent name, etc.)
</examples>
* It is essential that extracted entities are in the same format as in input question and not generated randomly or sourced elsewhere.
* There may be multiple entities in a question, including company and geography entities, and it is essential to extract all of them. Combination of company and geography entities may represent a single entity if they are mentioned close together in the question. In other cases, they should be extracted as separate entities.
<examples>
- 'abc-321 company and abc-123 company in xyz region' should be extracted as ['abc-321', 'abc-123', 'xyz']
- 'abc company compared to xyz region' should be extracted as ['abc', 'xyz']
- 'xyz inc/llc, city_name' should be extracted as ['xyz inc/llc, city_name'] 
</examples>
* Particularly if the company name is preceded or followed by a ticker symbol, just the ticker symbol should be extracted as a single entity. Ticker sybmols can be in various formats, including capital/lower case, numbers, with or without spaces, colons and dots.
<ticker_examples>
- XYZ:ABC
- XYZ:ABCABC
- XYZXYZ:ABC.A
- XYZXYZ:ABC A
- ABCDE:01234A
- abc:0123a
</ticker_examples>
* Particularly for geography entities such as 'city/state/county of xyz', it is important to extract the complete geography phrase as it is.
<geography_examples>
- 'City of xyz, xyz' should be extracted as ['City of xyz, xyz']
- 'state of xyz' should be extracted as ['state of xyz']
</geography_examples>
* To help you with entity name extraction here are some examples of complex entities that should be extracted as a single entity. Do not use examples to extract entities, they are only for taking hints.
<complex_examples>
- 'xyz Univ, state_name General Obligation Program'
- 'xyz Cnty, state_name Limited Tax General Operating Pledge'.
- 'xyz, General Obligation and Right of Way Acquisition & Bridge Construction Trust Fund Revenues',
- 'xyz inc/llc, General Obligation and Right of Way Acquisition & Bridge Construction Trust Fund Revenues',
- 'xyz Comnty Sch Dist, state_name School Infrastructure Sales Tax',
- 'xyz Un Sch Dist, state_name Unlimited Tax General Obligation'.
- 'xyz County District School Corp, state_name'
- 'xyz Mortgage Loan Trust 123-ABC'
- 'cuurency_placeholder mil var/fixed rate callable cms linked med-term nts due date_placeholder'
</complex_examples>
* When processing user query, ensure that personal names, natural disaster terms, and rating metrics, are not conflated with entity names.
<personal_names_examples>
- Donald Trump
- Bill Gates
- Tim Cook
</personal_names_examples>
<natural_disaster_examples>
- wildfire
- Hurricane
- earthquake
</natural_disaster_examples>
<rating_metrics>
- A, B, C, AA, BB, CC, AAA, BBB, CCC, D, A-1, A-2, A-3, A+, AA+, BB+, CC-, AA-, A-, B-, etc.
</rating_metrics>
* Output is valid only in a specified JSON format. Do not give any explanations and do not prepend or append any additional terms.
* If the question does not contain any entity names, return an empty list.
* Output: <output_format>(key: entities)</output_format>
</instructions>

Example pairs of question (key: question) and answer (key: answer) are given below in JSON format. Do not stick completely to the answer values shown in examples, they are only for taking hints. xyz, abc, 123, mm/dd/yyyy, and other similar terms in examples are placeholders for entity names.
<examples>
{examples}
</examples>

<output_format>
The output JSON object must contain the following property: "entities"
</output_format>

<question>
{question}
</question>

Just return an output JSON object.
"""
