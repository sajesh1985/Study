import sys
from enum import Enum
from typing import Any, List, Optional, Sequence, Union, cast

from pydantic import BaseModel, ConfigDict, Field
from typing_extensions import Self, override

from chatrd.core.llm.components.utils import merge_dicts, merge_lists

_LC_ID_PREFIX = "run-"
USER_PROMPT_MAPPING = {"user": "User:", "assistant": "Assistant:", "system": "System:"}
HUMAN_PROMPT_MAPPING = {"user": "Human:", "assistant": "Assistant:", "system": "System:"}


class MessageRole(str, Enum):
    """Enum for message roles in a chat conversation."""

    USER = "user"
    # Represent input from the user/human.
    ASSISTANT = "assistant"
    # Represent output from the AI model.
    SYSTEM = "system"
    # Represent instructions or context to the AI model to guide its behavior.

    def get_msg_type_mapping():
        return {
            "human": "user",
            "HumanMessage": "user",
            "HumanMessageChunk": "user",
            "ai": "assistant",
            "AIMessage": "assistant",
            "AIMessageChunk": "assistant",
            "system": "system",
            "SystemMessage": "system",
            "SystemMessageChunk": "system",
            "developer": "system",
        }

    @classmethod
    def parse(cls, message: Union[str, "BaseMessage"]) -> "MessageRole":
        """Parse a BaseMessage subclass or string into its corresponding role."""
        if isinstance(message, BaseMessage):
            msg_type = getattr(message, "type", None) or message.__class__.__name__
        elif isinstance(message, str):
            msg_type = message
        else:
            raise ValueError(f"Invalid message type: {type(message)}. Must be a BaseMessage or a string.")
        if msg_type not in cls.get_msg_type_mapping().keys():
            raise ValueError(f"Invalid message type: {msg_type}. Must be one of {cls.get_msg_type_mapping().keys()}.")

        return cls.get_msg_type_mapping()[msg_type]

    @classmethod
    def from_string(cls, role: str) -> Self:
        """Parse a string into a MessageRole."""
        try:
            return MessageRole(role.lower())
        except ValueError:
            try:
                role_type = cls.get_msg_type_mapping().get(role.lower())
                return MessageRole(role_type)
            except (KeyError, ValueError):
                raise ValueError(f"Invalid message role: {role}. Must be one of {list(MessageRole)}.")


class BaseMessage(BaseModel):
    """Base abstract message class.
    Messages are the inputs and outputs of ChatModels.
    """

    content: Union[str, list[Union[str, dict]]] = Field(
        ...,
        description="The string contents of the message.",
    )

    additional_kwargs: dict = Field(
        default_factory=dict, description="Reserved for additional payload data associated with the message."
    )

    response_metadata: dict = Field(
        default_factory=dict, description="Response metadata. For example: response headers, logprobs, token counts."
    )

    type: str = Field(
        "BaseMessage", description="The type of the message. Must be a string that is unique to the message type."
    )

    name: Optional[str] = Field(
        None,
        description="An optional name for the message. Can be used to provide a human-readable name for the message.",
    )

    id: Optional[str] = Field(
        default=None,
        coerce_numbers_to_str=True,
        description="An optional unique identifier for the message. Ideally provided by the provider/model.",
    )

    model_config = ConfigDict(
        extra="allow",
    )

    def __init__(self, content: Union[str, list[Union[str, dict]]], **kwargs: Any) -> None:
        """Initialize the BaseMessage with content and additional keyword arguments.

        Args:
            content: The content of the message, which can be a string or a list of strings or dicts.
            **kwargs: Additional keyword arguments to set as attributes.
        """
        super().__init__(content=content, **kwargs)

    def text(self) -> str:
        """Get the text content of the message.

        Returns:
            The text content of the message.
        """
        if isinstance(self.content, str):
            return self.content

        result = []
        for block in self.content:
            if isinstance(block, str):
                result.append(block)
            elif isinstance(block, dict) and block.get("type") == "text" and isinstance(block.get("text"), str):
                result.append(block.get("text", ""))
        return "".join(result)

    def pretty_repr(
        self,
        html: bool = False,
    ) -> str:
        """Get a pretty representation of the message.

        Args:
            html: Whether to format the message as HTML with HTML tags. (Default: False)

        Returns:
            A pretty representation of the message.
        """
        title = get_msg_title_repr(self.type.title() + " Message", bold=html)
        if self.name is not None:
            title += f"\nName: {self.name}"
        return f"{title}\n\n{self.content}"

    def pretty_print(self) -> None:
        """Print a pretty representation of the message."""
        print(self.pretty_repr(html=is_interactive_env()))

    def get_role(self) -> MessageRole:
        """Get the role of the message."""
        return MessageRole.parse(self)


MessageLikeRepresentation = Union[BaseMessage, str, list[str], tuple[str, str], dict[str, Any]]


class BaseMessageChunk(BaseMessage):
    """Message chunk, which can be concatenated with other Message chunks."""

    type: str = Field(
        "BaseMessageChunk", description="The type of the message. Must be a string that is unique to the message type."
    )

    def __add__(self, other: Any) -> Self:
        """Message chunks support concatenation with other message chunks.
        It combines message chunks yielded from a streaming model into a complete message.
        """
        if isinstance(other, BaseMessageChunk):
            return self.__class__(
                id=self.id,
                type=self.type,
                content=merge_content(self.content, other.content),
                additional_kwargs=merge_dicts(self.additional_kwargs, other.additional_kwargs),
                response_metadata=merge_dicts(self.response_metadata, other.response_metadata),
            )
        if isinstance(other, list) and all(isinstance(o, BaseMessageChunk) for o in other):
            content = merge_content(self.content, *(o.content for o in other))
            additional_kwargs = merge_dicts(self.additional_kwargs, *(o.additional_kwargs for o in other))
            response_metadata = merge_dicts(self.response_metadata, *(o.response_metadata for o in other))
            return self.__class__(
                id=self.id,
                content=content,
                additional_kwargs=additional_kwargs,
                response_metadata=response_metadata,
            )
        msg = 'unsupported operand type(s) for +: "' f"{self.__class__.__name__}" f'" and "{other.__class__.__name__}"'
        raise TypeError(msg)


class HumanMessage(BaseMessage):
    """Message from a human. Messages that are passed in from a human to the model."""

    type: str = Field("human", description="The type of the message. Represents human/user messages.")

    def __init__(self, content: Union[str, list[Union[str, dict]]], **kwargs: Any) -> None:
        super().__init__(content=content, **kwargs)


class HumanMessageChunk(HumanMessage, BaseMessageChunk):
    """Human Message chunk."""

    type: str = Field("HumanMessageChunk", description="The type of the message. Represents human/user message chunks.")


class AIMessage(BaseMessage):
    """Message from an AI.
    AIMessage is returned from a chat model as a response to a prompt that represents the output of the model.
    """

    type: str = Field("ai", description="The type of the message. Represents AI messages.")

    def __init__(self, content: Union[str, list[Union[str, dict]]], **kwargs: Any) -> None:
        super().__init__(content=content, **kwargs)

    @classmethod
    def from_chunks(cls, chunks: List["AIMessageChunk"]) -> Self:
        """Create an AIMessage from a list of AIMessageChunks."""
        full_content = "".join(chunk.content for chunk in chunks)
        merged_kwargs = merge_dicts(*(chunk.additional_kwargs for chunk in chunks))
        return cls(content=full_content, **merged_kwargs)


class AIMessageChunk(AIMessage, BaseMessageChunk):
    """Message chunk from an AI."""

    type: str = Field("AIMessageChunk", description="The type of the message. Represents AI message chunks.")

    @override
    def __add__(self, other: Any) -> BaseMessageChunk:
        if isinstance(other, AIMessageChunk):
            return self._add_ai_message_chunks(self, other)
        if isinstance(other, (list, tuple)) and all(isinstance(o, AIMessageChunk) for o in other):
            return self._add_ai_message_chunks(self, *other)
        return super().__add__(other)

    def _add_ai_message_chunks(self, *others: Self) -> Self:
        """Add multiple AIMessageChunks together."""
        content = merge_content(self.content, *(o.content for o in others))
        additional_kwargs = merge_dicts(self.additional_kwargs, *(o.additional_kwargs for o in others))
        response_metadata = merge_dicts(self.response_metadata, *(o.response_metadata for o in others))

        chunk_id = non_provider_id = None
        candidates = [self.id] + [o.id for o in others]
        # Check for id that not starts with the _LC_ID_PREFIX, or fallback to the first non-null id.
        for id_ in candidates:
            if id_:
                if not id_.startswith(_LC_ID_PREFIX):
                    chunk_id = id_
                    break
                elif non_provider_id is not None:
                    non_provider_id = id_
        else:
            chunk_id = non_provider_id

        return AIMessageChunk(
            content=content,
            additional_kwargs=additional_kwargs,
            response_metadata=response_metadata,
            id=chunk_id,
        )


class SystemMessage(BaseMessage):
    """Message for priming AI behavior.
    The system message is usually passed in as the first of a sequence of input messages.

    Example:
            messages = [
                SystemMessage(content="You are a helpful assistant..."),
                HumanMessage(content=user_prompt)
            ]
    """

    type: str = Field("system", description="The type of the message. Represents System messages.")


class SystemMessageChunk(SystemMessage, BaseMessageChunk):
    """System Message chunk."""

    type: str = Field("SystemMessageChunk", description="The type of the message. Represents System message chunks.")


def merge_content(
    first_content: Union[str, list[Union[str, dict]]],
    *contents: Union[str, list[Union[str, dict]]],
) -> Union[str, list[Union[str, dict]]]:
    """Merge multiple message contents.

    Args:
        first_content: The first content. Can be a string or a list.
        contents: The other contents. Can be a string or a list.

    Returns:
        The merged content.
    """
    merged = first_content
    for content in contents:
        if isinstance(merged, str):
            if isinstance(content, str):
                merged += content
            else:
                merged = [merged, *content]
        elif isinstance(content, list):
            merged = merge_lists(cast("list", merged), content)
        elif merged and isinstance(merged[-1], str):
            merged[-1] += content
        elif content == "":
            pass
        else:
            merged.append(content)
    return merged


def convert_to_message(message: MessageLikeRepresentation, role: str = "user") -> BaseMessage:
    """Instantiate a message from a variety of message representation formats."""
    if isinstance(message, BaseMessage):
        _message = message
    elif isinstance(message, str):
        _message = _create_message_from_message_type("human", message)
    elif isinstance(message, Sequence) and len(message) == 2:
        message_type_str, template = message
        _message = _create_message_from_message_type(message_type_str, template)
    elif isinstance(message, dict):
        msg_kwargs = message.copy()
        try:
            msg_type = msg_kwargs.pop("role", None)
            if not msg_type:
                msg_type = msg_kwargs.pop("type")
            msg_content = msg_kwargs.pop("content")
        except KeyError as e:
            msg = f"Message dict must contain 'role' or 'type', and also 'content' keys, but got {message}"
            raise ValueError(msg) from e
        _message = _create_message_from_message_type(msg_type, msg_content, **msg_kwargs)
    else:
        msg = f"Unsupported message type: {type(message)}"
        raise NotImplementedError(msg)

    return _message


def _create_message_from_message_type(
    message_type: str,
    content: str,
    name: Optional[str] = None,
    id: Optional[str] = None,
    role_mapping: Optional[dict[str, str]] = None,
    **additional_kwargs: Any,
) -> BaseMessage:
    """Create a message from a message type and content string.

    Args:
        message_type: (str) the type of the message (e.g., "human", "ai", etc.).
        content: (str) the content string.
        name: (str) the name of the message. Default is None.
        id: (str) the id of the message. Default is None.
        additional_kwargs: (dict[str, Any]) additional keyword arguments.
    """
    kwargs: dict[str, Any] = {}
    if name is not None:
        kwargs["name"] = name
    if additional_kwargs:
        if response_metadata := additional_kwargs.pop("response_metadata", None):
            kwargs["response_metadata"] = response_metadata
        kwargs["additional_kwargs"] = additional_kwargs
        additional_kwargs.update(additional_kwargs.pop("additional_kwargs", {}))
    if id is not None:
        kwargs["id"] = id
    if message_type in ("human", "user"):
        if example := kwargs.get("additional_kwargs", {}).pop("example", False):
            kwargs["example"] = example
        message: BaseMessage = HumanMessage(content=content, **kwargs)
    elif message_type in ("ai", "assistant"):
        if example := kwargs.get("additional_kwargs", {}).pop("example", False):
            kwargs["example"] = example
        message = AIMessage(content=content, **kwargs)
    elif message_type in ("system", "developer"):
        if message_type == "developer":
            kwargs["additional_kwargs"] = kwargs.get("additional_kwargs") or {}
            kwargs["additional_kwargs"]["__openai_role__"] = "developer"
        message = SystemMessage(content=content, **kwargs)
    else:
        raise ValueError(
            f"Unexpected message type: '{message_type}'."
            "Use one of: 'human', 'user', 'ai', 'assistant', 'system', or 'developer'."
        )
    return message


def get_bolded_text(text: str) -> str:
    """Get bolded text. Arg `text` is a string text to be bolded using ANSI escape codes."""
    return f"\033[1m{text}\033[0m"


def get_msg_title_repr(title: str, *, bold: bool = False) -> str:
    """Get a title representation for a message.

    Args:
        title: The title.
        bold: Whether to bold the title. Default is False.

    Returns:
        The title representation.
    """
    padded = " " + title + " "
    sep_len = (80 - len(padded)) // 2
    sep = "=" * sep_len
    second_sep = sep + "=" if len(padded) % 2 else sep
    if bold:
        padded = get_bolded_text(padded)
    return f"{sep}{padded}{second_sep}"


def is_interactive_env() -> bool:
    """Determine if running within IPython or Jupyter."""
    return hasattr(sys, "ps2")
