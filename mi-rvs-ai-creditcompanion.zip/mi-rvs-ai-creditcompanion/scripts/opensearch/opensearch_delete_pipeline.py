import time

import boto3
import requests
import yaml
from opensearch_py_ml.ml_commons import MLCommonClient
from opensearchpy import OpenSearch, RequestsHttpConnection
from opensearchpy.client.utils import _make_path
from opensearchpy.exceptions import NotFoundError
from requests_aws4auth import AWS4Auth

from chatrd.core.aws_utils.opensearch import get_secret
from chatrd.engine.configuration import Constants, get_config_machinery

config_machinery = get_config_machinery()

region = config_machinery.get_config_value(Constants.Bedrock.REGION_NAME)
host = config_machinery.get_config_value(Constants.OpenSearch.OPENSEARCH_HOST)
port = config_machinery.get_config_value(Constants.OpenSearch.OPENSEARCH_PORT)
user_name = config_machinery.get_config_value(Constants.OpenSearch.OPENSEARCH_USER_NAME)
password = get_secret(secret_id=config_machinery.get_config_value(Constants.OpenSearch.OPENSEARCH_PASSWORD))

service = "es"
vector_field = "vector_field"
headers = {"Content-Type": "application/json"}
ingestion_pipeline_id = "cohere-multilingual-ingestion-pipeline"
search_pipeline_id = "cohere-multilingual-search-pipeline"
role_arn = "arn:aws:iam::942282385556:role/mi-ds-chatrd-dev"
bedrock_url = "https://bedrock-runtime." + region + ".amazonaws.com/model/cohere.embed-multilingual-v3/invoke"

credentials = boto3.Session().get_credentials()
awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, service, session_token=credentials.token)

aos_client = OpenSearch(
    hosts=[{"host": host, "port": 443}],
    http_auth=(user_name, password),
    use_ssl=True,
    verify_certs=True,
    connection_class=RequestsHttpConnection,
)

# Load the YAML file
with open("chatrd/configuration/configs/pipeline.yaml", "r") as f:
    config = yaml.load(f, Loader=yaml.FullLoader)


# Undeploy model
ml_client = MLCommonClient(aos_client)

load_model_output = ml_client.undeploy_model(config["model_id"])

print(load_model_output)

print("undeployed model")

time.sleep(2)

# Delete Model

path = f"_plugins/_ml/models/{config['model_id']}"
url = "https://" + host + "/" + path

r = requests.delete(url, auth=awsauth, headers=headers)
print(r.text)
print("deleted model")

time.sleep(2)
# Delete Bedrock Connector

path = f"_plugins/_ml/connectors/{config['bedrock_connector_id']}"
url = "https://" + host + "/" + path

r = requests.delete(url, auth=awsauth, headers=headers)
print(r.text)
print("deleted bedrock connector")
time.sleep(2)
# Delete Model Group
path = f"_plugins/_ml/model_groups/{config['model_group_id']}"
url = "https://" + host + "/" + path

r = requests.delete(url, auth=awsauth, headers=headers)
print(r.text)
print("deleted model group")
time.sleep(2)

# Delete Ingestion pipeline
try:
    aos_client.transport.perform_request(
        "DELETE",
        _make_path("_ingest", "pipeline", config["ingestion_pipeline_id"]),
    )
except NotFoundError:
    print("Not Found Error")
    pass
print("deleted index pipeline")


# Delete search pipeline
try:
    aos_client.transport.perform_request(
        "DELETE",
        _make_path("_search", "pipeline", config["search_pipeline_id"]),
    )
except NotFoundError:
    print("Not Found Error")
    pass
print("deleted search pipeline")
