﻿// Copyright Notice! 
// This document is protected under the trade secret and copyright 
// laws as the property of Fidelity National Information Services, Inc. 
// Copying, reproduction or distribution should be limited and only to 
// employees with a “need to know” to do their job. 
// Any disclosure of this document to third parties is strictly prohibited.
// © 2017 Fidelity National Information Services.
// All rights reserved worldwide.

namespace Fis.Epp.Fusion.WebAPI.Controllers
{
    using Fis.Epp.Fusion.WebAPI.Common;
    using LoggerModels;
    using Microsoft.AspNetCore.Cors;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Options;
    using System.Net;
    using System.Net.Http;

    /// <summary>
    /// Resources controller serving RESTful requests for logging.
    /// </summary>

    [ApiController]
    public class LoggerController : BaseController
    {
        #region Public Constructors
        public LoggerController(IOptions<AppSettings> settings) : base(settings)
        {
        }
        #endregion
        #region Private properties
        /// <summary>
        /// Gets or sets the AppSettings configurations.
        /// </summary>
        private AppSettings AppSettings { get; set; }
        #endregion

        [HttpPost]
        [Route("api/Logger/RecordException")]
        public HttpResponseMessage RecordException([Bind("ErrorMessage,ErrorStack,RequestUrl,UserId,MemberId,RequestorId,CorrelationId,BrandId")] AppExceptionLoggerModel errorData)
        {
            AppDiagnostics appDiagnostics = new AppDiagnostics(HttpContext);
            errorData.BrandId = BrandValue;
            appDiagnostics.RecordException(errorData);
            return new HttpResponseMessage(HttpStatusCode.OK);
        }

        [HttpPost]
        [Route("api/Logger/RecordUser")]
        public HttpResponseMessage RecordUser([Bind("BrandId,UserId,MemberId,RequestorId,CorrelationId")] AppUserLoggerModel userData)
        {
            AppDiagnostics appDiagnostics = new AppDiagnostics(HttpContext);
            userData.BrandId = BrandValue;
            appDiagnostics.RecordUser(userData);
            return new HttpResponseMessage(HttpStatusCode.OK);
        }

        [HttpPost]
        [Route("api/Logger/RecordServiceException")]
        public HttpResponseMessage RecordServiceException([Bind("CorrelationId,ServiceUuid,MethodId,ApplicationId,ClientId,BrandId,UserId,MemberId,SyndicateId,RequestorId,Verb,CultureId,HTTP_CODE,MessageSeverity,MessageCode,Message")] ServiceExceptionLoggerModel serviceError)
        {
            AppDiagnostics appDiagnostics = new AppDiagnostics(HttpContext);
            serviceError.BrandId = BrandValue;
            appDiagnostics.RecordServiceException(serviceError);
            return new HttpResponseMessage(HttpStatusCode.OK);
        }

        [HttpPost]
        [Route("api/Logger/RecordServicePerformance")]
        public HttpResponseMessage RecordServicePerformance([Bind("CorrelationId,ServiceUuid,MethodId,ApplicationId,ClientId,BrandId,UserId,MemberId,SyndicateId,RequestorId,Verb,CultureId,HTTP_CODE,MessageCode,Duration")] ServicePerformancLoggerModel serviceData)
        {
            AppDiagnostics appDiagnostics = new AppDiagnostics(HttpContext);
            serviceData.BrandId = BrandValue;
            appDiagnostics.RecordServicePerformance(serviceData);
            return new HttpResponseMessage(HttpStatusCode.OK);
        }

        [HttpPost]
        [Route("api/Logger/RecordBrandingPerformance")]
        public HttpResponseMessage RecordBrandingPerformance([Bind("CorrelationId,ServiceUuid,MethodId,ApplicationId,ClientId,BrandId,UserId,MemberId,SyndicateId,RequestorId,Verb,CultureId,HTTP_CODE,MessageCode,Duration")] ServicePerformancLoggerModel serviceData)
        {
            AppDiagnostics appDiagnostics = new AppDiagnostics(HttpContext);
            serviceData.BrandId = BrandValue;
            appDiagnostics.RecordBrandingPerformance(serviceData);
            return new HttpResponseMessage(HttpStatusCode.OK);
        }

        [HttpPost]
        [Route("api/Logger/RecordServicePayload")]
        public HttpResponseMessage RecordServicePayload([Bind("CorrelationId,ServiceUuid,MethodId,ApplicationId,ClientId,BrandId,UserId,MemberId,SyndicateId,RequestorId,Verb,CultureId,HTTP_CODE,MessageCode,RequestJSON,ResponseJSON")] ServicePayloadLoggerModel serviceData)
        {
            AppDiagnostics appDiagnostics = new AppDiagnostics(HttpContext);
            serviceData.BrandId = BrandValue;
            appDiagnostics.RecordServicePayload(serviceData);
            return new HttpResponseMessage(HttpStatusCode.OK);
        }
    }
}
