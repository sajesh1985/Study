import React from 'react';
import {
  ExampleBox,
  ExampleBoxHead,
  ExampleBoxLists,
  ExampleList,
  Slider,
  SliderDots,
  SliderMain,
  SliderText,
} from './Chat.styles';
import { ANGLE_LEFT, ANGLE_RIGHT } from '@spglobal/koi-icons';
import { Icon, IconSize } from '@spglobal/react-components';
import { Size } from '@spglobal/koi-helpers';

interface ChatHomeSliderProps {
  clicked: (...args: any) => void;
}

export const ChatHomeSlider: React.FC<ChatHomeSliderProps> = ({ clicked}) => {
  const [slide, setSlide] = React.useState<number>(1);

  return (
    <SliderMain>
      <Slider>
        <SliderText>
          {slide == 1 && (
            <div style={{display:'flex'}}>
              <ExampleBox>
          <ExampleBoxHead>
          <svg xmlns="http://www.w3.org/2000/svg" width="37" height="37" viewBox="0 0 37 37" fill="none">
          <circle cx="18.1719" cy="18.1562" r="17.5" stroke="#525252"/>
          <path d="M10.6719 18.9062H16.6719V20.4062H10.6719V18.9062Z" fill="#BFBFBF"/>
          <path d="M8.42188 20.4062C8.83609 20.4062 9.17188 20.0705 9.17188 19.6562C9.17188 19.242 8.83609 18.9062 8.42188 18.9062C8.00766 18.9062 7.67188 19.242 7.67188 19.6562C7.67188 20.0705 8.00766 20.4062 8.42188 20.4062Z" fill="#BFBFBF"/>
          <path d="M15.9219 17.4062C16.3361 17.4062 16.6719 17.0705 16.6719 16.6562C16.6719 16.242 16.3361 15.9062 15.9219 15.9062C15.5077 15.9062 15.1719 16.242 15.1719 16.6562C15.1719 17.0705 15.5077 17.4062 15.9219 17.4062Z" fill="#BFBFBF"/>
          <path d="M7.67188 15.9062H13.6719V17.4062H7.67188V15.9062ZM10.6719 12.9062H16.6719V14.4062H10.6719V12.9062Z" fill="#BFBFBF"/>
          <path d="M8.42188 14.4062C8.83609 14.4062 9.17188 14.0705 9.17188 13.6562C9.17188 13.242 8.83609 12.9062 8.42188 12.9062C8.00766 12.9062 7.67188 13.242 7.67188 13.6562C7.67188 14.0705 8.00766 14.4062 8.42188 14.4062Z" fill="#BFBFBF"/>
          <path d="M28.6719 27.6063L23.1219 22.0563C24.2469 20.5563 24.9219 18.6812 24.9219 16.6562C24.9219 11.7063 20.8719 7.65625 15.9219 7.65625C13.4469 7.65625 11.1219 8.63125 9.39688 10.5063L10.5219 11.5562C11.8719 9.98125 13.8219 9.15625 15.9219 9.15625C20.0469 9.15625 23.4219 12.5312 23.4219 16.6562C23.4219 20.7812 20.0469 24.1562 15.9219 24.1562C13.6719 24.1562 11.5719 23.1812 10.1469 21.4562L9.02188 22.4313C10.6719 24.4563 13.2219 25.6562 15.9219 25.6562C18.3219 25.6562 20.4969 24.6813 22.1469 23.1813L27.6219 28.6562L28.6719 27.6063Z" fill="#BFBFBF"/>
          </svg>
            <span>Credit Ratings Discovery</span>
          </ExampleBoxHead>
          <ExampleBoxLists>
            <ExampleList onClick={() => clicked('What are the Ratings for Volkswagen according to S&P Global Ratings?')}>
              <span>What are the Ratings for Volkswagen according to S&P Global Ratings?</span>
              <Icon icon={ANGLE_RIGHT} size={IconSize.XXXSMALL} />
            </ExampleList>
            <ExampleList onClick={() => clicked('What is the rating of 459200LD1?')}>
              <span>What is the rating of 459200LD1?</span>
              <Icon icon={ANGLE_RIGHT} size={IconSize.XXXSMALL} />
            </ExampleList>
            <ExampleList onClick={() => clicked('What is the current rating and outlook for Boeing?')}>
              <span>What is the current rating and outlook for Boeing?</span>
              <Icon icon={ANGLE_RIGHT} size={IconSize.XXXSMALL} />
            </ExampleList>
          </ExampleBoxLists>
        </ExampleBox>
        <ExampleBox>
          <ExampleBoxHead>
          <svg width="37" height="37" viewBox="0 0 37 37" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="18.1719" cy="18.1562" r="17.5" stroke="#525252"/>
            <path d="M10.5 8V28H25.5V8H10.5ZM24.25 26.75H19.25V23H16.75V26.75H11.75V9.25H24.25V26.75Z" fill="#BFBFBF"/>
            <path d="M13 19.25H15.5V21.75H13V19.25ZM16.75 19.25H19.25V21.75H16.75V19.25ZM20.5 19.25H23V21.75H20.5V19.25ZM13 15.5H15.5V18H13V15.5ZM16.75 15.5H19.25V18H16.75V15.5ZM20.5 15.5H23V18H20.5V15.5ZM13 11.75H15.5V14.25H13V11.75ZM16.75 11.75H19.25V14.25H16.75V11.75ZM20.5 11.75H23V14.25H20.5V11.75Z" fill="#BFBFBF"/>
          </svg>

            <span>Entity Specific</span>
          </ExampleBoxHead>
          <ExampleBoxLists>
            <ExampleList onClick={() => clicked('Provide a SWOT analysis for Tesla')}>
              <span>Provide a SWOT analysis for Tesla</span>
              <Icon icon={ANGLE_RIGHT} size={IconSize.XXXSMALL} />
            </ExampleList>
            <ExampleList onClick={() => clicked('What would cause a downgrade for Chevron?')}>
              <span>What would cause a downgrade for Chevron?</span>
              <Icon icon={ANGLE_RIGHT} size={IconSize.XXXSMALL} />
            </ExampleList>
            <ExampleList onClick={() => clicked('Compare the ESG profile between Micron and AMD')}>
              <span>Compare the ESG profile between Micron and AMD</span>
              <Icon icon={ANGLE_RIGHT} size={IconSize.XXXSMALL} />
            </ExampleList>
          </ExampleBoxLists>
        </ExampleBox>
        <ExampleBox>
          <ExampleBoxHead>
          <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 36 36" fill="none">
          <circle cx="18" cy="18" r="17.5" stroke="#525252"/>
          <path d="M15.9219 9.77916H11.4219C11.1235 9.77916 10.8374 9.89768 10.6264 10.1087C10.4154 10.3196 10.2969 10.6058 10.2969 10.9042V25.9042C10.2969 26.2025 10.4154 26.4887 10.6264 26.6997C10.8374 26.9106 11.1235 27.0292 11.4219 27.0292H15.9219C16.2202 27.0292 16.5064 26.9106 16.7174 26.6997C16.9283 26.4887 17.0469 26.2025 17.0469 25.9042V10.9042C17.0469 10.6058 16.9283 10.3196 16.7174 10.1087C16.5064 9.89768 16.2202 9.77916 15.9219 9.77916ZM11.0469 13.5292H16.2969V23.2792H11.0469V13.5292ZM11.4219 10.5292H15.9219C16.0213 10.5292 16.1167 10.5687 16.187 10.639C16.2574 10.7093 16.2969 10.8047 16.2969 10.9042V12.7792H11.0469V10.9042C11.0469 10.8047 11.0864 10.7093 11.1567 10.639C11.227 10.5687 11.3224 10.5292 11.4219 10.5292ZM15.9219 26.2792H11.4219C11.3224 26.2792 11.227 26.2396 11.1567 26.1693C11.0864 26.099 11.0469 26.0036 11.0469 25.9042V24.0292H16.2969V25.9042C16.2969 26.0036 16.2574 26.099 16.187 26.1693C16.1167 26.2396 16.0213 26.2792 15.9219 26.2792ZM27.5225 24.721L24.4109 9.92634C24.3808 9.78119 24.3223 9.64341 24.2388 9.52093C24.1553 9.39845 24.0484 9.29369 23.9242 9.21267C23.8001 9.13165 23.6611 9.07596 23.5154 9.04881C23.3697 9.02166 23.22 9.02359 23.075 9.05447L18.6866 9.99666C18.3949 10.0611 18.1404 10.2381 17.9784 10.4891C17.8163 10.7401 17.7599 11.0449 17.8213 11.3373L20.9328 26.132C20.9629 26.2771 21.0214 26.4149 21.1049 26.5374C21.1885 26.6599 21.2954 26.7646 21.4195 26.8456C21.5437 26.9267 21.6826 26.9824 21.8283 27.0095C21.9741 27.0367 22.1238 27.0347 22.2688 27.0038L26.6572 26.0607C26.9489 25.9967 27.2036 25.8199 27.3657 25.569C27.5277 25.3181 27.5841 25.0133 27.5225 24.721ZM19.7216 16.727L24.8431 15.6273L26.2494 22.2901L21.1278 23.3907L19.7216 16.727ZM19.0991 13.7682L24.2216 12.6676L24.6903 14.8932L19.5678 15.9929L19.0991 13.7682ZM18.845 10.7307L23.2344 9.78759C23.2603 9.78201 23.2867 9.77918 23.3131 9.77916C23.3844 9.77939 23.4541 9.80022 23.5138 9.83916C23.5561 9.86635 23.5925 9.90177 23.6208 9.94333C23.6492 9.98488 23.6689 10.0317 23.6788 10.081L24.0669 11.9354L18.9444 13.0342L18.5553 11.1854C18.5335 11.0867 18.5518 10.9834 18.6061 10.8981C18.6604 10.8129 18.7463 10.7527 18.845 10.7307ZM26.4997 25.3276L22.1094 26.2707C22.0125 26.2914 21.9114 26.2728 21.8281 26.2192C21.7858 26.192 21.7494 26.1565 21.721 26.115C21.6927 26.0734 21.673 26.0266 21.6631 25.9773L21.2769 24.1229L26.3994 23.0232L26.7884 24.8729C26.8103 24.9715 26.7921 25.0747 26.738 25.1599C26.6839 25.2451 26.5982 25.3054 26.4997 25.3276Z" fill="#BFBFBF"/>
          </svg>
            <span>Criteria & Definitions</span>
          </ExampleBoxHead>
          <ExampleBoxLists>
            <ExampleList onClick={() => clicked('What are the key ratios for the corporate methodology?')}>
              <span>What are the key ratios for the corporate methodology?</span>
              <Icon icon={ANGLE_RIGHT} size={IconSize.XXXSMALL} />
            </ExampleList>
            <ExampleList onClick={() => clicked('Explain National Scale Ratings and why they are useful in a few bullet points')}>
              <span>Explain National Scale Ratings and why they are useful in a few bullet points</span>
              <Icon icon={ANGLE_RIGHT} size={IconSize.XXXSMALL} />
            </ExampleList>
            <ExampleList onClick={() => clicked('What is the difference between short-term and long-term credit ratings?')}>
              <span>What is the difference between short-term and long-term credit ratings?</span>
              <Icon icon={ANGLE_RIGHT} size={IconSize.XXXSMALL} />
            </ExampleList>
          </ExampleBoxLists>
        </ExampleBox>
            </div>
          )}
          {slide == 2 && (
            <div style={{display:'flex'}}>
              <ExampleBox>
          <ExampleBoxHead>
          <svg width="37" height="37" viewBox="0 0 37 37" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="18.1719" cy="18.1562" r="17.5" stroke="#525252"/>
            <path fill-rule="evenodd" clip-rule="evenodd" d="M18.1575 9.99609L27.4646 14.2499L27.0195 15.2238L26.3052 14.8973V24.4101H25.2344V15.9643H22.5066V24.4101H21.4358V15.9643H18.708V24.4101H17.6372V15.9643H14.9094V24.4101H13.8386V15.9643H11.1108V24.4101H10.04V14.8963L9.32619 15.2235L8.87988 14.2502L18.1575 9.99609ZM10.046 14.8935H26.2968L18.1582 11.1737L10.046 14.8935ZM27.1538 26.3147H9.2061V25.2439H27.1538V26.3147Z" fill="#BFBFBF"/>
          </svg>

            <span>Macroeconomic</span>
          </ExampleBoxHead>
          <ExampleBoxLists>
            <ExampleList onClick={() => clicked('What factors could lead to a recession in the US this year?')}>
              <span>What factors could lead to a recession in the US this year?</span>
              <Icon icon={ANGLE_RIGHT} size={IconSize.XXXSMALL} />
            </ExampleList>
            <ExampleList onClick={() => clicked('What sectors experienced increased demand in a higher interest rate environment?')}>
              <span>What sectors experienced increased demand in a higher interest rate environment?</span>
              <Icon icon={ANGLE_RIGHT} size={IconSize.XXXSMALL} />
            </ExampleList>
            <ExampleList onClick={() => clicked("What is the outlook of Japan's economy?")}>
              <span>What is the outlook of Japan's economy?</span>
              <Icon icon={ANGLE_RIGHT} size={IconSize.XXXSMALL} />
            </ExampleList>
          </ExampleBoxLists>
        </ExampleBox>
             <ExampleBox>
          <ExampleBoxHead>
          <svg xmlns="http://www.w3.org/2000/svg" width="37" height="37" viewBox="0 0 37 37" fill="none">
          <circle cx="18.1719" cy="18.4043" r="17.5" stroke="#525252"/>
          <path d="M8.92856 24.7057V19.5343L13.4528 17.5957L17.9771 19.5357V24.7057L13.4528 26.6428L8.92856 24.7057Z" stroke="#BFBFBF" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M8.92856 19.5242L13.4528 21.4628L17.9771 19.5242M13.4528 12.46L17.9757 14.4L22.5 12.4614" stroke="#BFBFBF" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M17.9757 19.5244L22.5 21.463L27.0243 19.5244" stroke="#BFBFBF" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M13.4529 21.4658V26.6443M22.5029 21.4658V26.6443M17.9757 14.4001V19.5772M13.4557 17.5929V12.4215L17.9786 10.4829L22.5029 12.4215V17.5929L17.9786 19.5315L13.4557 17.5929ZM17.9757 24.7058V19.5343L22.5 17.5958L27.0243 19.5358V24.7058L22.5 26.6429L17.9757 24.7058Z" stroke="#BFBFBF" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
            <span>Industry</span>
          </ExampleBoxHead>
          <ExampleBoxLists>
            <ExampleList onClick={() => clicked("What are some trends in the automotive sector that could positively impact credit ratings?")}>
              <span>What are some trends in the automotive sector that could positively impact credit ratings?</span>
              <Icon icon={ANGLE_RIGHT} size={IconSize.XXXSMALL} />
            </ExampleList>
            <ExampleList onClick={() => clicked("What is the expected impact of rising interest rates on telecommunications in 2024?")}>
              <span>What is the expected impact of rising interest rates on telecommunications in 2024?</span>
              <Icon icon={ANGLE_RIGHT} size={IconSize.XXXSMALL} />
            </ExampleList>
            <ExampleList onClick={() => clicked("What is the outlook for the oil and gas industry?")}>
              <span>What is the outlook for the oil and gas industry?</span>
              <Icon icon={ANGLE_RIGHT} size={IconSize.XXXSMALL} />
            </ExampleList>
          </ExampleBoxLists>
        </ExampleBox>
        <ExampleBox>
          <ExampleBoxHead>
          <svg xmlns="http://www.w3.org/2000/svg" width="37" height="37" viewBox="0 0 37 37" fill="none">
          <circle cx="18.1719" cy="18.4043" r="17.5" stroke="#525252"/>
          <path d="M8.17188 25.4043V23.3273H10.2489V25.4043H8.17188ZM13.0179 25.4043V23.3273H26.1719V25.4043H13.0179ZM8.17188 19.4423V17.3663H10.2489V19.4423H8.17188ZM13.0179 19.4423V17.3663H26.1719V19.4423H13.0179ZM8.17188 13.4813V11.4043H10.2489V13.4813H8.17188ZM13.0179 13.4813V11.4043H26.1719V13.4813H13.0179Z" fill="#BFBFBF"/>
          </svg>
            <span>List Generation</span>
          </ExampleBoxHead>
          <ExampleBoxLists> 
          <ExampleList onClick={() => clicked('Show me a list of corporates with investment grade ratings in the United States')}>
              <span>Show me a list of corporates with investment grade ratings in the United States</span>
              <Icon icon={ANGLE_RIGHT} size={IconSize.XXXSMALL} />
            </ExampleList>
            <ExampleList onClick={() => clicked("What are some companies that have been upgraded in the energy sector?")}>
              <span>What are some companies that have been upgraded in the energy sector?</span>
              <Icon icon={ANGLE_RIGHT} size={IconSize.XXXSMALL} />
            </ExampleList>
            <ExampleList onClick={() => clicked("Show me all the banks in North America with a AA rating")}>
              <span>Show me all the banks in North America with a AA rating</span>
              <Icon icon={ANGLE_RIGHT} size={IconSize.XXXSMALL} />
            </ExampleList>
            
          </ExampleBoxLists>
        </ExampleBox>
            </div>
          )}
          
        </SliderText>
      </Slider>
      <SliderDots>
        <Icon
          color="var(--color-text-primary)"
          size={Size.XXSMALL}
          icon={ANGLE_LEFT}
          className={'arrow-back'}
          onClick={() => {
            const prev = slide > 1 ? slide - 1 : 2;
            setSlide(prev);
          }}
        />
        <span className={slide == 1 ? 'active' : ''} onClick={() => setSlide(1)}></span>
        <span className={slide == 2 ? 'active' : ''} onClick={() => setSlide(2)}></span>
        <Icon
          color="var(--color-text-primary)"
          size={Size.XXSMALL}
          icon={ANGLE_RIGHT}
          className={'arrow-next'}
          onClick={() => {
            const next = slide < 2 ? slide + 1 : 1;
            setSlide(next);
          }}
        />
      </SliderDots>
    </SliderMain>
  );
};
