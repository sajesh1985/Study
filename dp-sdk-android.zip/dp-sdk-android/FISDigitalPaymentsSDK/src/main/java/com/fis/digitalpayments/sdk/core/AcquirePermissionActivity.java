// Copyright Notice!
// This document is protected under the trade secret and copyright
// laws as the property of Fidelity National Information Services, Inc.
// Copying, reproduction or distribution should be limited and only to
// employees with a “need to know” to do their job.
// Any disclosure of this document to third parties is strictly prohibited.
// © 2016 Fidelity National Information Services.
// All rights reserved worldwide.

package com.fis.digitalpayments.sdk.core;

import android.Manifest;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.ResultReceiver;
import android.preference.PreferenceManager;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.fis.digitalpayments.sdk.R;

import java.util.Arrays;

/**
 * Activity used to acquire permissions.
 *
 * @author e1035413 on 12/21/2016.
 */

public class AcquirePermissionActivity extends AppCompatActivity {

    public static final String PERMISSION_RESULT_RECEIVER_NAME = "PERMISSION_RESULT_RECEIVER";

    public static final String REQUEST_PARAM_PERMISSION_ID = "permissionId";
    public static final String REQUEST_PARAM_ENABLE_DISCLOSURE = "enableDisclosure";

    public static final int RESULT_PERMISSION_GRANTED = 100;
    public static final int RESULT_PERMISSION_DENIED = 101;
    public static final int RESULT_PERMISSION_PERMANENTLY_DENIED = 102;
    @SuppressWarnings("WeakerAccess")
    public static final int RESULT_NOT_AUTHORIZED = 103;

    private static final String[] AUTHORIZED_PERMISSIONS = {Manifest.permission.READ_CONTACTS, Manifest.permission.CAMERA, Manifest.permission.SEND_SMS,Manifest.permission.READ_EXTERNAL_STORAGE};
    private static boolean contactUsageDisclosureAccepted = false;
    private static boolean storageUsageDisclosureAccepted = false;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());

        if (getResultReceiver() != null) {
            Bundle parameters = getIntent().getExtras();

            String permissionId = null;
            if (parameters != null && parameters.containsKey(REQUEST_PARAM_PERMISSION_ID)) {
                permissionId = parameters.getString(REQUEST_PARAM_PERMISSION_ID);
            }

            if (permissionId == null || !Arrays.asList(AUTHORIZED_PERMISSIONS).contains(permissionId)) {
                sendResult(RESULT_NOT_AUTHORIZED);
            } else {
                boolean enableDisclosure = true;
                if (parameters != null && parameters.containsKey(REQUEST_PARAM_ENABLE_DISCLOSURE)) {
                    // At this point we will know whether disclosure has been disabled
                    enableDisclosure = parameters.getBoolean(REQUEST_PARAM_ENABLE_DISCLOSURE);
                }
                acquirePermission(permissionId, enableDisclosure);
            }
        }
    }

    private void acquirePermission(String permissionId, boolean enableDisclosure) {
        int grantStatus = ContextCompat.checkSelfPermission(this, permissionId);
        if (grantStatus != PackageManager.PERMISSION_GRANTED) {
            if (enableDisclosure && Manifest.permission.READ_CONTACTS.equalsIgnoreCase(permissionId) && !contactUsageDisclosureAccepted() &&
                    (ActivityCompat.shouldShowRequestPermissionRationale(this, permissionId) || isFirstTimeAskingPermission(permissionId))) {
                showContactUsageDisclosure(true);
            }
            else if (enableDisclosure && Manifest.permission.READ_EXTERNAL_STORAGE.equalsIgnoreCase(permissionId) && !deviceUsageDisclosureAccepted() &&
                    (ActivityCompat.shouldShowRequestPermissionRationale(this, permissionId) || isFirstTimeAskingPermission(permissionId))) {
                showDeviceUsageDisclosure(true);
            }
            else {
                if(Manifest.permission.READ_EXTERNAL_STORAGE.equalsIgnoreCase(permissionId)) {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA,permissionId}, 0);
                }
                else
                {
                    ActivityCompat.requestPermissions(this, new String[]{permissionId}, 0);
                }
            }
        } else {
            sendResult(RESULT_PERMISSION_GRANTED);
        }
    }

    private void showContactUsageDisclosure(final boolean enableDisclosure) {
        new AlertDialog.Builder(this)
                .setTitle(R.string.fis_contact_usage_disclosure_title)
                .setMessage(R.string.fis_contact_usage_disclosure_message)
                .setPositiveButton(R.string.fis_contact_usage_disclosure_allow, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        setContactUsageDisclosureAccepted(true);
                        acquirePermission(Manifest.permission.READ_CONTACTS, enableDisclosure);
                        setContactUsageDisclosureAccepted(false);
                    }
                })
                .setNegativeButton(R.string.fis_contact_usage_disclosure_do_not_allow, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        sendResult(RESULT_PERMISSION_DENIED);
                    }
                })
                .setCancelable(false)
                .show();
    }

    private void showDeviceUsageDisclosure(final boolean enableDisclosure) {
        new AlertDialog.Builder(this)
                .setTitle(R.string.fis_device_usage_disclosure_title)
                .setMessage(R.string.fis_device_usage_disclosure_message)
                .setPositiveButton(R.string.fis_device_usage_disclosure_allow, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        setDeviceUsageDisclosureAccepted(true);
                        acquirePermission(Manifest.permission.READ_EXTERNAL_STORAGE, true);
                        setDeviceUsageDisclosureAccepted(false);
                    }
                })
                .setNegativeButton(R.string.fis_device_usage_disclosure_do_not_allow, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        sendResult(RESULT_PERMISSION_DENIED);
                    }
                })
                .setCancelable(false)
                .show();
    }

    public void firstTimeAskingPermission(String permission, boolean isFirstTime) {
        sharedPreferences.edit().putBoolean(permission, isFirstTime).apply();
    }

    public boolean isFirstTimeAskingPermission(String permission) {
        return sharedPreferences.getBoolean(permission, true);
    }

    private boolean contactUsageDisclosureAccepted() {
        return contactUsageDisclosureAccepted;
    }

    private void setContactUsageDisclosureAccepted(boolean disclosureAccepted) {
        contactUsageDisclosureAccepted = disclosureAccepted;
    }

    private boolean deviceUsageDisclosureAccepted() {
        return storageUsageDisclosureAccepted;
    }

    private void setDeviceUsageDisclosureAccepted(boolean disclosureAccepted) {
        storageUsageDisclosureAccepted = disclosureAccepted;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        // If request is cancelled, the result arrays are empty.
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            sendResult(RESULT_PERMISSION_GRANTED);
            firstTimeAskingPermission(permissions[0], false);
        } else {
            // This activity only allows a single permission.
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, permissions[0])) {
                sendResult(RESULT_PERMISSION_DENIED);
                firstTimeAskingPermission(permissions[0], false);
            } else {
                sendResult(RESULT_PERMISSION_PERMANENTLY_DENIED);
            }
        }
    }

    private void sendResult(int resultCode) {
        ResultReceiver resultReceiver = getResultReceiver();
        resultReceiver.send(resultCode, null);
        finish();
        overridePendingTransition(0, 0);
    }

    private ResultReceiver getResultReceiver() {
        return getIntent().getParcelableExtra(PERMISSION_RESULT_RECEIVER_NAME);
    }
}