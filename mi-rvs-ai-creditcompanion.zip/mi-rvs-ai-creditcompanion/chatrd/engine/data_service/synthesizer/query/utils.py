import json
import logging
import re

import pandas as pd

from chatrd.core.llm import LCLLMFactory
from chatrd.engine.data_service.analyzer.utils import convert_tuples_to_string
from chatrd.engine.data_service.kpqi import KPQI
from chatrd.engine.data_service.locator import main_directory
from chatrd.engine.data_service.model_output_parser.variables import (
    GLOBAL_CREDIT_RATING_MAPPING,
)
from chatrd.engine.data_service.synthesizer.query.data.criteria_arguments import (
    INSURANCE_SECTOR_CODES,
)
from chatrd.engine.data_service.synthesizer.query.prompts import (
    PROMPT_LEADING_LINE,
    QUERY_CREDIT_RATING_ACTION_LEADINGLINE_EXAMPLES,
    QUERY_CREDITWATCH_OUTLOOK_LEADINGLINE_EXAMPLES,
    QUERY_FINANCIAL_LEADINGLINE_EXAMPLES,
)

logger = logging.getLogger(__name__)

RATING_TYPE = {True: "Local Currency LT", False: "Foreign Currency LT"}
DEBT_TYPE = {True: "FSR", False: "ICR"}
lookback_keywords = ["recent", "latest", "lately", "recently"]


def time_period_extractor(screener_payload, screener_payload_object=None):
    # Check for screener_payload containing time period and extract the value
    query_lines = screener_payload["functionRequests"][0]["query"]["queryLineGroups"][0]["queryLines"]
    date_value_dict = {}
    for query_line in query_lines:
        field_key = query_line.get("field", {}).get("fieldKey")
        if field_key in (
            KPQI.RD_CREDIT_RATING_GLOBAL.value,
            KPQI.RD_RATING_ACTION_GLOBAL.value,
            KPQI.RD_CWOL_GLOBAL.value,
        ):
            secondary_keys = query_line.get("field", {}).get("secondaryKeys", [])
            if secondary_keys and len(secondary_keys) > 2:
                date_value_dict["Debt Type"] = (
                    secondary_keys[0].get("displayValue", None) if isinstance(secondary_keys[0], dict) else None
                )
                date_value_dict["Rating Type"] = (
                    secondary_keys[1].get("displayValue", None) if isinstance(secondary_keys[1], dict) else None
                )
                date_value = (
                    secondary_keys[2].get("displayValue", None) if isinstance(secondary_keys[2], dict) else None
                )
                logger.info(f"Time frame extracted from payload: {date_value}")
                if field_key == KPQI.RD_CREDIT_RATING_GLOBAL.value:
                    date_value_dict["S&P Credit Rating Date"] = date_value
                elif field_key == KPQI.RD_RATING_ACTION_GLOBAL.value:
                    date_value_dict["S&P Credit Rating Action Date"] = date_value
                elif field_key == KPQI.RD_CWOL_GLOBAL.value:
                    date_value_dict["S&P CreditWatch/Outlook Date"] = date_value

    text_dict = screener_payload_object.text_dict
    # Handle display column S&P CreditWatch/Outlook
    if text_dict and "S&P CreditWatch/Outlook" in text_dict:
        if text_dict["S&P CreditWatch/Outlook"].get("display_column") is True:
            date_value_dict["S&P CreditWatch/Outlook Date"] = "Current"
    return date_value_dict


def leading_line_prompt_builder(date_value, user_input, prompt, retriever_financialMetrics):
    # Initialize the note content
    note_content = ""
    all_examples = []

    # Add date-related information to the note
    if date_value:
        note_content += f"For the user question: '{user_input}', the date period, debt type and rating type are used for the attributes as follows:"
        for key, date in date_value.items():
            if key == "Debt Type":
                note_content += f"\n The Debt Type is '{date}'. "
            elif key == "Rating Type":
                note_content += f"\n The Rating Type is '{date}'. "
            elif key == "S&P CreditWatch/Outlook Date" and date.lower() == "current":
                note_content += f"\n The date values for '{key}' should be interpreted as 'as of Current'."
                note_content += f"\n Do NOT use any year like 2025, 2024, etc. Always respond with 'as of Current'."
                all_examples.extend(QUERY_CREDITWATCH_OUTLOOK_LEADINGLINE_EXAMPLES)
            elif key == "S&P Credit Rating Action Date":
                # "Current" date mentioned as value
                if isinstance(date, str) and date.lower() == "current":
                    note_content += f"\n The date values for '{key}' is shown as 'as of Current'. "

                # Lookback keywords mentioned by user for last 12 months
                elif any(word in user_input.lower() for word in lookback_keywords):
                    # Check if date has a specific period value
                    has_specific_period = bool(
                        re.search(
                            r"\b(19|20)\d{2}\b|\bq[1-4]\b|past \d+ month|last (\d+ month|year)|previous month",
                            user_input.lower(),
                        )
                    )
                    if has_specific_period:
                        note_content += f"\n Use the time period exactly as mentioned in the user question."
                    else:
                        note_content += f"\n The date values for '{key}' is shown 'in the last 12 months period'."
                        note_content += f"\n CRITICAL: When user says '{[word for word in lookback_keywords if word in user_input.lower()][0]}', "
                        note_content += f"ALWAYS include 'in the last 12 months' in your leading line response."
                # Use user's original phrasing from input
                else:
                    note_content += f"\n Use the time period exactly as mentioned in the user question."
                all_examples.extend(QUERY_CREDIT_RATING_ACTION_LEADINGLINE_EXAMPLES)

            else:
                note_content += f"\n The date values for '{key}' is '{date}'. "
        note_content += (
            "\nYou must use the above information as the date period(s), debt type and rating type in your response. "
            "Adjust the date format to resemble the provided samples. "
        )

    # Add financial metrics-related information to the note
    if retriever_financialMetrics:
        financial_metrics = ", ".join(set([name.split(" -- ")[-2] for name in retriever_financialMetrics]))
        note_content += (
            f"\nThe question is asking for the following financial values: {financial_metrics}."
            " Include these financial metrics in your final response without adding extra lines. "
            "Do not use bullet points or tables; use a single line format. "
        )
        all_examples.extend(QUERY_FINANCIAL_LEADINGLINE_EXAMPLES)

    # Append all examples at the end in one block
    if all_examples:
        examples_str = convert_tuples_to_string(all_examples)
        note_content += f"\nExamples:\n{examples_str}\n"

    # Append the note to the prompt if there's any content
    if note_content:
        list_of_prompts = prompt.rsplit("\n", 1)
        additional_point = f"NOTE: {note_content.strip()}"
        updated_prompt = list_of_prompts[0] + "\n\n" + additional_point + "\n\n" + list_of_prompts[1]
        return updated_prompt + "\nUSER QUESTION: " + user_input
    else:
        return prompt + "\nUSER QUESTION: " + user_input


def find_hierarchy_path(value):
    example_fp = "synthesizer/query/data/industry_hierarchy.json"
    with open(main_directory(example_fp), "rt") as f:
        hierarchy = json.load(f)
    example_fp = "synthesizer/query/data/industry_code_to_name.json"
    with open(main_directory(example_fp), "rt") as f:
        code_to_name_dictionary = json.load(f)

    for key in hierarchy:
        if isinstance(hierarchy[key], list):
            if value in hierarchy[key]:
                # Return Industry Subsector Sector
                return f"{code_to_name_dictionary[value]} ({code_to_name_dictionary[key]})"
        elif isinstance(hierarchy[key], dict):
            for subkey in hierarchy[key]:
                if isinstance(hierarchy[key][subkey], list):
                    if value in hierarchy[key][subkey]:
                        # Return Industry Subsector Sector
                        return f"{code_to_name_dictionary[value]} ({code_to_name_dictionary[subkey]}, {code_to_name_dictionary[key]})"
                    elif value in subkey:
                        # Return Subsector Sector
                        return f"{code_to_name_dictionary[value]} ({code_to_name_dictionary[key]})"
        if key == value:
            # Return Sector
            return f"{code_to_name_dictionary[value]}"
    try:
        return f"{code_to_name_dictionary[value]}"
    except Exception as e:
        logger.error(f"Error in finding hierarchy path: {e}")
        return None


def describe_mi_codes(code):
    file_path = "synthesizer/query/data/mi_industry_tree.parquet"
    df = pd.read_parquet(main_directory(file_path))

    index = df.index[df["Codes"] == code].tolist()

    if not index:
        return code

    index = index[0]
    final_string = df.at[index, "EnglishValues"]
    parent_code = df.at[index, "ParentCode"]

    # Traverse the hierarchy
    while parent_code != -1:
        parent_index = parent_code
        parent_value = df.at[parent_index, "EnglishValues"]
        parent_code = df.at[parent_index, "ParentCode"]

        if parent_code != -1:
            if "(" in final_string and ")" in final_string:
                closing_parenthesis_index = final_string.index(")")
                final_string = (
                    final_string[:closing_parenthesis_index]
                    + f", {parent_value}"
                    + final_string[closing_parenthesis_index:]
                )
            else:
                final_string += f" ({parent_value})"

    return final_string


# This function generates a text template for the query criteria to be displayed in the UI
def filter_criteria_template(screener_payload_object, date_value):
    text_dict = screener_payload_object.text_dict
    # Generate a header for the template
    template = "<ul><b>Query Criteria:</b>"
    display_template = "<ul><b>Display Columns:</b>"
    # Check for 'Industry Classification' values and generate a template with the sector hierarchy path
    if "S&P Global Ratings Sector" in text_dict.keys():
        if text_dict["S&P Global Ratings Sector"].get("display_column") == False:
            rd_sector_codes = screener_payload_object.payload_dict[KPQI.RD_SECTOR.value]["value"].split(",")
            sector_names = ", ".join([f"{find_hierarchy_path(sector_code)}" for sector_code in rd_sector_codes])
            template += f"""<li> S&P Global Ratings Sector: {sector_names}</li>"""
            sector_codes = rd_sector_codes.copy()
        else:
            display_template += f"""<li> S&P Global Ratings Sector</li>"""
    if "S&P Market Intelligence" in text_dict.keys():
        if text_dict["S&P Market Intelligence"].get("display_column") == False:
            mi_sector_codes = screener_payload_object.payload_dict[KPQI.IndustryClassification.value]["value"].split(
                ","
            )
            sector_names = ", ".join([f"{describe_mi_codes(sector_code)}" for sector_code in mi_sector_codes])
            template += f"""<li> MI Industry Classification: {sector_names}</li>"""
            if "rd_sector_codes" in locals():
                sector_codes.extend(mi_sector_codes)
            else:
                sector_codes = mi_sector_codes.copy()
        else:
            display_template += f"""<li> MI Industry Classification</li>"""
    # Check for 'S&P Credit Rating' values and generate a template with the credit rating values
    if "S&P Credit Rating" in text_dict.keys():
        if text_dict["S&P Credit Rating"].get("display_column") is False:
            # If the operator is 'not equal', generate a list of credit ratings excluding the value
            if text_dict["S&P Credit Rating"]["operator"] in ["not equal", "not in"]:
                credit_ratings = GLOBAL_CREDIT_RATING_MAPPING.copy()
                values_to_remove = [value.strip() for value in text_dict["S&P Credit Rating"]["value"].split(",")]
                values_to_remove = [value.strip().strip("'\"") for value in values_to_remove]
                for value in values_to_remove:
                    credit_ratings.remove(value)
                credit_ratings = ", ".join(map(str.upper, credit_ratings))
            else:
                credit_ratings = text_dict["S&P Credit Rating"]["value"].upper()
                translation_table = str.maketrans({"'": "", '"': ""})
                credit_ratings = credit_ratings.translate(translation_table)
            template += f"""<li> S&P Credit Rating: {credit_ratings}"""
            # For Insurance sector, Rating Type is 'Local Currency LT'
            # else for other sectors, Rating Type is 'Foreign Currency LT'
            if "sector_codes" in locals():
                rating_type_response = all(num in INSURANCE_SECTOR_CODES for num in sector_codes)
            else:
                rating_type_response = False
            rating_type = RATING_TYPE[rating_type_response]
            debt_type = DEBT_TYPE[rating_type_response]
            template += f"; Debt Type: {debt_type}; Rating Type: {rating_type}</li>"
            # Add rating date in to template
            if date_value["S&P Credit Rating Date"]:
                rating_date = date_value["S&P Credit Rating Date"].title()
            else:
                rating_date = "Current"
            template += f"""<li> S&P Credit Rating Date: {rating_date}</li>"""
        else:
            display_template += f"""<li> S&P Credit Rating</li>"""
            display_template += f"""<li> S&P Credit Rating Date: Current</li>"""
    if "S&P Credit Rating Action" in text_dict.keys():
        if text_dict["S&P Credit Rating Action"].get("display_column") is False:
            rating_action = text_dict["S&P Credit Rating Action"]["value"].title().replace(",", ", ")
            template += f"""<li> S&P Credit Rating Action: {rating_action}"""
            if "sector_codes" in locals():
                sector = all(num in INSURANCE_SECTOR_CODES for num in sector_codes)
            else:
                sector = False
            template += f"; Debt Type: {DEBT_TYPE[sector]}; Rating Type: {RATING_TYPE[sector]}</li>"
            # Add rating date in to template
            if date_value["S&P Credit Rating Action Date"]:
                rating_action_date = date_value["S&P Credit Rating Action Date"].title()
            else:
                rating_action_date = "Current"
            template += f"""<li> S&P Credit Rating Action Date: {rating_action_date}</li>"""
        else:
            display_template += f"""<li> S&P Credit Rating Action</li>"""
            display_template += f"""<li> S&P Credit Rating Action Date: Current</li>"""
    if "S&P CreditWatch/Outlook" in text_dict.keys():
        if text_dict["S&P CreditWatch/Outlook"].get("display_column") is False:
            outlook_value = text_dict["S&P CreditWatch/Outlook"]["value"].title().replace(",", ", ")
            template += f"""<li> S&P CreditWatch/Outlook: {outlook_value}"""
            if "sector_codes" in locals():
                sector = all(num in INSURANCE_SECTOR_CODES for num in sector_codes)
            else:
                sector = False
            template += f"; Debt Type: {DEBT_TYPE[sector]}; Rating Type: {RATING_TYPE[sector]}</li>"
            # template += f"""<ul><li>Debt Type: {DEBT_TYPE[sector]}</li>"""
            # template += f"""<li>Rating Type: {RATING_TYPE[sector]}</li></ul></li>"""
            # Add rating date in to template
            if date_value["S&P CreditWatch/Outlook Date"]:
                cwol_date = date_value["S&P CreditWatch/Outlook Date"].title()
            else:
                cwol_date = "Current"
            template += f"""<li> S&P CreditWatch/Outlook Date: {cwol_date}</li>"""
        else:
            display_template += f"""<li> S&P CreditWatch/Outlook</li>"""
            display_template += f"""<li> S&P CreditWatch/Outlook Date: Current</li>"""
    # Add geography in to template if available
    if "Geography" in text_dict.keys():
        if text_dict["Geography"].get("display_column") == False:
            template += f"""<li> Geography: {text_dict["Geography"]["value"].title()}</li>"""
        else:
            display_template += f"""<li> Geography</li>"""

    # --- Display Columns and Time Frame ---
    # This section is now built separately to ensure correct HTML structure.
    if "CreditStats Direct Sector" in text_dict:
        display_column_template = ["<li>CreditStats Direct ®<ul>"]

        # Group sectors for nested list generation
        grouped_sectors = {}
        for sector_str in text_dict["CreditStats Direct Sector"]:
            parts = sector_str.split(" -- ")
            if len(parts) == 5:
                parent, sub_parent, period, value, kpqi = parts
                grouped_sectors.setdefault(parent, {}).setdefault(sub_parent, []).append(f"{kpqi}: {value} ({period})")

        # Generate sorted, nested list for display columns
        for parent in sorted(grouped_sectors):
            display_column_template.append(f"<li>{parent}:<ul>")
            for sub_parent in sorted(grouped_sectors[parent]):
                display_column_template.append(f"<li>{sub_parent}:<ul>")
                for value in sorted(grouped_sectors[parent][sub_parent]):
                    display_column_template.append(f"<li>{value}</li>")
                display_column_template.append("</ul></li>")
            display_column_template.append("</ul></li>")

        # Time Frame
        display_column_template.append("<li>Time Frame:<ul>")
        for period in text_dict["CreditStats Direct Period"]:
            display_column_template.append(f"<li>{period}</li>")
        display_column_template.append("</ul></li>")

        display_column_template.append("</ul></li>")  # Closes CSD list and item

        logger.info(f"Display Column: {''.join(display_column_template)}")
        display_template += "".join(display_column_template)

    template += "</ul>"
    if len(display_template) > len("<ul><b>Display Columns:</b>"):
        display_template += "</ul>"
        template += display_template
    logger.info(f"Query criteria: {template}")
    return template


def generate_template(date_value, user_input, retriever_financialMetrics):
    """
    Generates a template using the given inputs and an LLM.

    Args:
        date_value: The date value to include in the prompt.
        user_input: The user input to include in the prompt.
        retriever_financialMetrics: Financial metrics retriever to include in the prompt.

    Returns:
        str: The generated template.
    """
    try:
        prompt = leading_line_prompt_builder(
            prompt=PROMPT_LEADING_LINE,
            date_value=date_value,
            user_input=user_input,
            retriever_financialMetrics=retriever_financialMetrics,
        )

        llm = LCLLMFactory().get_llm(deployment_name_or_model_id="claude-3-haiku", temperature=0.0)
        response = llm.invoke(prompt)
        return response.content
    except Exception as e:
        logger.info(f"Error in generating template: {e}")
        return ""
