import React from 'react';
import { Pagination } from '@spglobal/koi-pagination';

interface FeedbackPaginationType {
  onChange: (value: number) => void;
  onChangePageSize: (value: number) => void;
  totalItems?: number;
  defaultPageSize: number;
}

export const FeedbackPagination: React.FC<FeedbackPaginationType> = ({
  onChange,
  totalItems,
  onChangePageSize,
  defaultPageSize,
}) => {
  return (
    <Pagination
      onChange={onChange}
      onChangePageSize={onChangePageSize}
      totalItems={totalItems}
      currentPage={1}
      defaultPageSize={defaultPageSize}
      isQuickJump
      pageSizeOptions={[
        { label: '10', value: '10' },
        { label: '20', value: '20' },
      ]}
    />
  );
};
