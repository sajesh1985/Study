# --------------
# Prompt leading line
# --------------

PROMPT_LEADING_LINE = """You need to provide the leading line in the response to a question.
You must return your answer in a simple format:
- Start with 'Here is the list of...'
- Include requested sector, geography, debt type, rating type, date, and financials only if mentioned in the question. Do not make assumptions or add explanatory comments for missing information.
- Debt types are: "Issuer Credit Rating" and "Financial Strength Rating". Use 'Financial Strength Rating' for insurance sector and 'Issuer Credit Rating' for all other sectors.
- Rating types are: "Foreign Currency LT" and "Local Currency LT". Use 'Local Currency LT' for insurance sector and 'Foreign Currency LT' for all other sectors.
- Simplify the date information extracted from the question
- If the question specifically mentions 'investment grade' or 'speculative grade' as a debt type (not as a sector), explain it in parentheses; otherwise, never use these terms.

Provide a leading line that summarizes the information in the question like the examples below.
Do not add any additional comments in your message.

Here are sample questions and the leading lines. Use these as a reference to create your leading line:

Show me a list of energy companies in the US.
Leading Line: Here is the list of companies in the energy sector in the United States:

Show me a list of utilities companies in Germany.
Leading Line: Here is the list of companies in the utilities sector in Germany:

Show me a list of investment grade companies.
Here is the list of corporates with investment grade ratings:\n(An investment grade rating is an Issuer Credit Rating (Foreign Currency LT) in the range of BBB- or above)

Show me a list of corporates with investment grade ratings in the United States
Here is the list of corporates with investment grade ratings in the United States:\n(An investment grade rating is an Issuer Credit Rating (Foreign Currency LT) in the range of BBB- or above)

Show me a list of corporates with speculative grade ratings in Australia
Here is the list of corporates with speculative grade ratings in Australia:\n(A speculative grade rating is an Issuer Credit Rating (Foreign Currency LT) in the range of BB+ or below)

Show me a list of AA+ rated companies.
Here is the list of companies with an Issuer Credit Rating (Foreign Currency LT) of AA+:

Show me a list of AA+ rated companies in Italy.
Here is the list of companies with an Issuer Credit Rating (Foreign Currency LT) of AA+ in Italy:

Provide me a list of companies rated BBB+ or above
Here is the list of companies with an Issuer Credit Rating (Foreign Currency LT) of BBB+ or above:

Provide me a list of insurance companies rated AA- or below in Italy
Here is the list of insurance companies with a Financial Strength Rating (Local Currency LT) of AA- or below in Italy:

What are companies that have been upgraded in Energy? (note that the upgrade or downgrade questions generally refer to as of Current)
Here is the list of companies with Issuer Credit Rating (Foreign Currency LT) that have been upgraded in the energy sector as of Current:

Show me all the banks in North America with an AA rating
Here is the list of banks with an Issuer Credit Rating (Foreign Currency LT) of AA in North America:

Show me all the utilities in North America with an ICR of B
Here is the list of utilities with an Issuer Credit Rating (Foreign Currency LT) of B in North America:

Show me all the media companies in France with an ICR (LC LT) of A
Here is the list of media companies with an Issuer Credit Rating (Local Currency LT) of A in France:

Show me all the media companies in France with an ICR (LC Long Term) of A
Here is the list of media companies with an Issuer Credit Rating (Local Currency LT) of A in France:

Show me all the media companies in France with an ICR (Foreign Currency Long Term) of A
Here is the list of media companies with an Issuer Credit Rating (Foreign Currency LT) of A in France:

Show me all the media companies in France with an ICR (Foreign Currency LT) of A
Here is the list of media companies with an Issuer Credit Rating (Foreign Currency LT) of A in France:

Show me all the media companies in France with an ICR (FC LT) of A
Here is the list of media companies with an Issuer Credit Rating (Foreign Currency LT) of A in France:

Show me all the media companies in France with an ICR (FC Long Term) of A
Here is the list of media companies with an Issuer Credit Rating (Foreign Currency LT) of A in France:

Give me the list of tech companies B+ or higher credit rating in tabular format
Here is the list of companies in the technology sector with an Issuer Credit Rating (Foreign Currency LT) of B+ or higher:

Give me the list of insurance companies in Spain with a BBB FSR rating
Here is the list of insurance companies with a Financial Strength Rating (Local Currency LT) of BBB in Spain:

Give me a list top rated entities in the automobile sector
Here is the list of companies in the automobiles & components sector with investment grade ratings:\n(An investment grade rating is an Issuer Credit Rating (Foreign Currency LT) in the range of BBB- or above)

list of top rated entities in the energy sector
Here is the list of companies in the energy sector with investment grade ratings:\n(An investment grade rating is an Issuer Credit Rating (Foreign Currency LT) in the range of BBB- or above)

top rated entities in the utilities sector
Here is the list of companies in the utilities sector with investment grade ratings:\n(An investment grade rating is an Issuer Credit Rating (Foreign Currency LT) in the range of BBB- or above)

top rated companies in the utilities sector
Here is the list of companies in the utilities sector with investment grade ratings:\n(An investment grade rating is an Issuer Credit Rating (Foreign Currency LT) in the range of BBB- or above)

What entities have been downgraded in 2024?
Here is the list of entities with Issuer Credit Rating (Foreign Currency LT) that have been downgraded in 2024:

What entities have been upgraded in 2022?
Here is the list of entities with Issuer Credit Rating (Foreign Currency LT) that have been upgraded in 2022:

Which companies are upgraded in 2023?
Here is the list of companies with Issuer Credit Rating (Foreign Currency LT) that have been upgraded in 2023:

Which companies are downgraded in 2021?
Here is the list of companies with Issuer Credit Rating (Foreign Currency LT) that have been downgraded in 2021:

What are companies in X industry that have moved to CreditWatch negative.
Here is the list of companies with Issuer Credit Rating (Foreign Currency LT) in X industry that have been moved to CreditWatch Negative as of Current:

What are companies in X industry that have moved to CreditWatch "Watch Neg".
Here is the list of companies with Issuer Credit Rating (Foreign Currency LT) in X industry that have been moved to "Watch Neg" CreditWatch/Outlook as of Current:

What are companies in X industry that have moved to CreditWatch "Watch Pos".
Here is the list of companies with Issuer Credit Rating (Foreign Currency LT) in X industry that have been moved to "Watch Pos" CreditWatch/Outlook as of Current:

Show me a list of positive credit watch companies.
Here is the list of companies with Issuer Credit Rating (Foreign Currency LT) and a "Watch Pos" CreditWatch/Outlook as of Current:

Negative credit watch companies, please.
Here is the list of companies with Issuer Credit Rating (Foreign Currency LT) and a "Watch Neg" CreditWatch/Outlook as of Current:

Give me tabular format of the negative outlook companies, please.
Here is the list of companies with Issuer Credit Rating (Foreign Currency LT) and a Negative CreditWatch/Outlook as of Current:

Negative cwol companies, please.
Here is the list of companies with Issuer Credit Rating (Foreign Currency LT) and a Negative CreditWatch/Outlook as of Current:

What are companies in insurance sector that have a positive outlook.
Here is the list of companies in the insurance sector with Financial Strength Rating (Local Currency LT) and a Positive CreditWatch/Outlook as of Current:

Now that we are done with the examples, here are some important points to consider:
1. Include time period for queries that may be timebound (any queries related to upgrade or downgrade refers to as of "Current"
   unless it is for a specific year for which mention the year in the response)
2. Remember to prefix with "the" for any sector if original query is in English. Examples: the energy sector, the utilities sector, the transportation sector etc.
3. Remember to capitalize the rating letters (like AA, AAA-, BBB+ etc)
4. "CreditWatch/Outlook" can be one of these: Positive, Developing, Stable, Negative, Watch Pos, Watch Dev, Watch Neg, NM or NR.
   Use capitalizations exactly as given here.
5. The question may have either outlook or credit watch key words. In the response, always use "CreditWatch/Outlook" in the leading line.
6. Give proper sector name in your response, despite whatever abbreviation used in the question.
7. Always refer rating as Issuer Credit Rating (Foreign Currency LT) unless specifically mentioned otherwise. For the insurance sector, always use Financial Strength Rating as the Debt type.
8. For ratings upgrade and downgrade questions (including fallen angels, potential fallen angels and potential rising stars), if the time period
is not mentioned, include "as of Current" in your response.
9. Include country or geography name in your response only if the question has that info.
10. Include sector or industry name in your response only if the question has that info.
11. Explain "investment grade" in your response with this sentence in parentheses: An investment grade rating is an Issuer Credit Rating (Foreign Currency LT) in the range of BBB- or above
12. Explain "speculative grade" in your response with this sentence in parentheses: A speculative grade rating is an Issuer Credit Rating (Foreign Currency LT) in the range of BB+ or below
13. If the question does not contain any of the information about sector, geography, debt type, rating type, date or financials, you must NOT add any comment or explanation in your response.
    Don't add any comment like 'This question does not contain any information about...'.
14. If the question contains a phrase like 'give a table response', ignore it and create an answer similar to the examples above.
15. AVOID REPETITION OF DEBT TYPE AND RATING TYPE: Once you mention the debt type (Issuer Credit Rating or Financial Strength Rating) and rating type (Foreign Currency LT or Local Currency LT) in full, do NOT repeat it in subsequent references within the same leading line.
Btw, there is an important instruction. End your leading sentence with a colon (':'), not with a fullstop.

That's all for the instructions.

Here is the question, use all the context and information above and give your response."""


# --------------
# Financial-Query leading line
# --------------
QUERY_FINANCIAL_LEADINGLINE_EXAMPLES = [
    (
        "Show me a list of utilities companies in Germany with their EBITDA and net income.",
        "Here is the list of companies in the utilities sector in Germany with their EBITDA and Net Income values:",
    ),
    (
        "Show me a list of energy companies in the US and include financial overview.",
        "Here is the list of companies in the energy sector in the United States with their revenue, net income, EBITDA and total assets:",
    ),
    (
        "What are the financial highlights of the healthcare sector in Canada?",
        "Here is the list of companies in the healthcare sector in Canada with their revenue, net income, EBITDA and total assets:",
    ),
    (
        "Provide me with financial overview of downgraded corporates in 2024.",
        "Here is the list of companies that have been downgraded in 2024 with their revenue, net income, EBITDA and total assets:",
    ),
    (
        "Give me a list of upgraded companies in 2023 with their financials.",
        "Here is the list of companies that have been upgraded in 2023 with their revenue, net income, EBITDA and total assets:",
    ),
    (
        "Give me newly rated companies and include their EBITDA and revenue for Q1 and Q2 of 2024?",
        "Here is the list of newly rated companies with their EBITDA and revenue for Q1 and Q2 of 2024:",
    ),
    (
        "Show me financial overview of downgraded companies in the last year.",
        "Here is the list of companies that have been downgraded in the last year with their revenue, net income, EBITDA and total assets:",
    ),
    (
        "What are the financial highlights of the top-rated corporates in 2023?",
        "Here is the list of top-rated corporates in 2023 with their revenue, net income, EBITDA and total assets:",
    ),
    (
        "List all Automobiles & Components in Japan having S&P Rating A+ include key Financial data",
        "Here is the list of key Financial data for Automobiles & Components in Japan having S&P Rating A+:",
    ),
    (
        "List all Automobiles & Components in Japan having S&P Rating A+ include financial overview",
        "Here is the list of financial overview for Automobiles & Components in Japan having S&P Rating A+:",
    ),
    (
        "Show FFO consolidating, Increase in account payable or creditors and working capital taxed for rated corporates and financial institutions for 2024",
        "Here is the list of corporates and financial institutions with financials FFO consolidating, Increase in account payable or creditors and working capital taxed for 2024:",
    ),
    (
        "Show me EBITDA and Revenue for all companies with recent action changes which belong to S&P GLobal chemical sector",
        "Here is the list of all companies with recent action changes which belong to S&P GLobal chemical sector with financials EBITDA and Revenue:",
    ),
]


# --------------
# CREDITWATCH/OUTLOOK-Query leading line
# --------------

QUERY_CREDITWATCH_OUTLOOK_LEADINGLINE_EXAMPLES = [
    (
        "Generate Asian transportation issuers with a stable outlook",
        "Here is the list of companies in the transportation sector in Asia with Issuer Credit Rating (Foreign Currency LT) and a Stable CreditWatch/Outlook as of Current:",
    ),
    (
        "List Argentinian companies rated below BB with a stable outlook",
        "Here is the list of Argentinian companies with an Issuer Credit Rating (Foreign Currency LT) below BB and a Stable CreditWatch/Outlook as of Current:",
    ),
    (
        "Companies that have been placed on CreditWatch Negative in 2025.",
        "Here is the list of companies with Issuer Credit Rating (Foreign Currency LT) that have been placed on CreditWatch Negative as of Current:",
    ),
    (
        "Identify entities with a negative outlook, 2024 Debt/EBITDA, and rated below BB",
        "Here is the list of entities with a Negative CreditWatch/Outlook as of Current, a Debt/EBITDA ratio for 2024, and an Issuer Credit Rating (Foreign Currency LT) below BB:",
    ),
    (
        "Highlight Canadian issuers rated A with a positive outlook and recent equity amount",
        "Here is the list of Canadian issuers with an Issuer Credit Rating (Foreign Currency LT) of A, a Positive CreditWatch/Outlook as of Current, and their recent Equity, Adjusted (REPORTED) amount:",
    ),
    (
        "Are there any negative outlook issuers in Europe that were recently upgraded? What's their latest FFO/Debt ratio?",
        "Here is the list of companies in Europe with Issuer Credit Rating (Foreign Currency LT) and a Negative CreditWatch/Outlook as of Current that have been upgraded in the last 12 months, along with their latest FFO/Debt ratio:",
    ),
    (
        "Are there banks with new rating and stable outlook + developing CreditWatch?",
        "Here is the list of banks with a new Issuer Credit Rating (Foreign Currency LT) with Stable and Developing CreditWatch/Outlook as of Current",
    ),
    (
        "Create a list of US Banks that were downgraded last year and include their outlook",
        "Here is the list of US banks that were downgraded based on their Issuer Credit Rating (Foreign Currency LT) in the last year, and CreditWatch/Outlook as of Current:",
    ),
]

# --------------
# CREDIT RATING ACTION-Query leading line
# --------------

QUERY_CREDIT_RATING_ACTION_LEADINGLINE_EXAMPLES = [
    (
        "Show me all the media companies in France with an ICR (Foreign Currency LT) of A that have been downgraded in 2023",
        "Here is the list of media companies with an Issuer Credit Rating (Foreign Currency LT) of A in France that have been downgraded in 2023:",
    ),
    (
        "What entities have been downgraded in 2024 in the utilities sector?",
        "Here is the list of entities that have been downgraded in 2024 in the utilities sector:",
    ),
    (
        "Can you provide rating actions in the past 1 month for all chemical companies",
        "Here is the list of chemical companies with rating actions in the past 1 month based on their Issuer Credit Rating (Foreign Currency LT):",
    ),
    (
        "Provide me upgrades for companies rated below A as well as their operating income",
        "Here is the list of companies with an Issuer Credit Rating (Foreign Currency LT) below A that have been upgraded as of Current, along with their latest reported operating income:",
    ),
    (
        "Show me companies rated BB with a stable outlook and their latest rating action",
        "Here is the list of companies with an Issuer Credit Rating (Foreign Currency LT) of BB and a Stable CreditWatch/Outlook as of Current, and their latest rating action in the last 12 months:",
    ),
    (
        "Provide me the outlook of corporates that were recently downgraded and include their FFO/Debt",
        "Here is the list of corporates that were recently downgraded in the last 12 months, along with their Issuer Credit Rating (Foreign Currency LT), CreditWatch/Outlook as of Current and latest reported FFO/Debt, Adjusted (%):",
    ),
    (
        "Entities recently upgraded with a positive outlook",
        "Here is the list of entities with Issuer Credit Rating (Foreign Currency LT) that have been upgraded in the last 12 months and have a Positive CreditWatch/Outlook as of Current:",
    ),
    (
        "Highlight construction companies that were recently downgraded with a negative outlook",
        "Here is the list of construction companies with Issuer Credit Rating (Foreign Currency LT) that have been downgraded in the last 12 months and have a Negative CreditWatch/Outlook as of Current:",
    ),
    (
        "Create a list of US Banks that were downgraded last year and include their outlook",
        "Here is the list of US banks that were downgraded based on their Issuer Credit Rating (Foreign Currency LT) in the last year, and CreditWatch/Outlook as of Current:",
    ),
]
