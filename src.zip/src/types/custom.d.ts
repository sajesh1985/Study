declare interface Window {
  startup: any;
  process: any;
  spa: any;
}
