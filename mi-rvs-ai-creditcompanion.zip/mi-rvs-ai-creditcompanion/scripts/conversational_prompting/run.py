import argparse
import json
from typing import List, Optional

from chatrd.core.utils import ChatMessage, MessageRole
from chatrd.engine.components.query_analyzer.conversational import (
    ConversationalPrompter,
)

with open("scripts/conversational_prompting/decision_maker_9887272.json") as f:
    LOAD_TEST_CASES = json.load(f)

PREPRAED_TEST_CASES = []
for item in LOAD_TEST_CASES:
    test_case = []
    new_history = []
    for message in item["history"]:
        new_history.append(ChatMessage(content=message, role=MessageRole.USER))
    PREPRAED_TEST_CASES.append((item["query"], new_history))


def run(
    model_name: Optional[str] = "haiku",
    temperature: Optional[float] = 0.0,
    query: Optional[str] = None,
    chat_history: Optional[List[str]] = [],
):
    cp = ConversationalPrompter(model_name=model_name, temperature=temperature)
    if query:
        history = [ChatMessage(content=message, role=MessageRole.USER) for message in chat_history]
        print(query, history)
        decision, conversational_prompter_output = cp.run(query, history)
        print(
            f"Original Query: {query}\nHistory: {[item.content for item in history]}\n{decision}, {conversational_prompter_output}"
        )
    else:
        for idx, test_case in enumerate(PREPRAED_TEST_CASES):
            query, history = test_case
            decision, conversational_prompter_output = cp.run(query, history)
            print(
                f"Test no.: {idx+1}\nOriginal Query: {query}\nHistory: {[item.content for item in history]}\n{decision}{conversational_prompter_output}"
            )
            print("----------------------")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_name", type=str, default="haiku")
    parser.add_argument("--temperature", type=float, default=0.0)
    parser.add_argument("--query", type=str, help="Input a query", default=None)
    parser.add_argument("--chat_history", nargs="+", help="Input a list of questions", default=[])
    args = parser.parse_args()
    run(args.model_name, args.temperature, args.query, args.chat_history)
