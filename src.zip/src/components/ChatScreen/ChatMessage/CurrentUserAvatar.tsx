import React from 'react';
import { useUserTraits } from '@spglobal/userprofileservice';
import { TextAvatar } from './ChatMessage.styles';

export const CurrentUserAvatar: React.FC = () => {
  const { firstName, lastName } = useUserTraits(['firstName', 'lastName']) || {};

  const initials = React.useMemo(() => {
    if (firstName && lastName) {
      return `${firstName[0]}${lastName[0]}`;
    } else {
      return '';
    }
  }, [firstName, lastName]);

  return <TextAvatar>{initials}</TextAvatar>;
};
