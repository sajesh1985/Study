import json
import logging
from typing import List, Optional, Sequence

from chatrd.core.llm import LCLLMFactory
from chatrd.core.llm.components.message import AIMessage
from chatrd.core.llm.parsers import OutputParserException, PydanticOutputParser
from chatrd.core.llm.prompt.template import SimplePromptTemplate
from chatrd.core.thread_utils import submit_to_shared_thread_pool
from chatrd.core.utils import ChatMessage, MessageRole
from chatrd.engine.components.query_analyzer.conversational.prompts import (
    CLARIFYING_EXAMPLES,
    CLARIFYING_OUTPUT_PROMPT_FORMAT,
    CLARIFYING_PROMPT,
    DECISION_EXAMPLES,
    DECISION_OUTPUT_PROMPT_FORMAT,
    DECISION_PROMPT,
    REPHRASING_EXAMPLES,
    REPHRASING_OUTPUT_PROMPT_FORMAT,
    REPHRASING_PROMPT,
    USE_CASE_DEFINITIONS,
    ClarifyingOutput,
    DecisionOutput,
    RephrasingOutput,
)

logger = logging.getLogger(__name__)


class ConversationalPrompter:
    def __init__(self, model_name: str, temperature: Optional[float] = 0.0):
        self.model = LCLLMFactory().get_llm(
            deployment_name_or_model_id=model_name,
            temperature=temperature,
        )

    def run(self, query: str, history: Sequence[ChatMessage]):
        list_of_questions = [chat_message.content for chat_message in history if chat_message.role == MessageRole.USER][
            -3:
        ]
        list_of_questions = [{"question": question} for question in list_of_questions]
        logger.debug(f"List of questions for input: {list_of_questions}")
        decision_prompt, decision_parser = self.get_decision_making_prompt(
            query, json.dumps(list_of_questions, indent=4)
        )
        rephrasing_prompt, rephrasing_parser = self.get_rephrasing_prompt(
            query, json.dumps(list_of_questions, indent=4)
        )

        future_decision = submit_to_shared_thread_pool(self.invoke_model, prompt=decision_prompt)
        future_rephrasing_response = submit_to_shared_thread_pool(self.invoke_model, prompt=rephrasing_prompt)

        decision_response = future_decision.result()
        rephrasing_response = future_rephrasing_response.result()

        if isinstance(decision_response, AIMessage):
            decision_response = decision_response.content
        try:
            decision_response = decision_parser.parse(decision_response)
            logger.info(f"Conversational prompter decision result: {decision_response}")
        except OutputParserException as e:
            logger.error(f"Validation error at from Decision Prompter' llm extraction {e}.")
            raise e

        if decision_response.flag == "rephrasing":
            if isinstance(rephrasing_response, AIMessage):
                rephrasing_response = rephrasing_response.content
            try:
                rephrasing_response = rephrasing_parser.parse(rephrasing_response)
                rephrasing_response.set_initial_question(query)
                logger.info(f"Generated rephrasing result: {rephrasing_response}")
                return decision_response, rephrasing_response

            except OutputParserException as e:
                logger.error(f"Validation error from Rephrasing Prompter' llm extraction {e}.")
                raise e
        elif decision_response.flag == "clarifying":
            clarifying_prompt, clarifying_parser = self.get_clarifying_prompt(
                query, json.dumps(list_of_questions, indent=4)
            )
            future_clarifying_response = submit_to_shared_thread_pool(self.invoke_model, prompt=clarifying_prompt)
            clarifying_response = future_clarifying_response.result()

            if isinstance(clarifying_response, AIMessage):
                clarifying_response = clarifying_response.content
            try:
                clarifying_response = clarifying_parser.parse(clarifying_response)
                logger.info(f"Generated clarifying result: {clarifying_response}")
                return decision_response, clarifying_response

            except OutputParserException as e:
                logger.error(f"Validation error from Clarification Prompter' llm extraction {e}.")
                raise e

    def invoke_model(self, prompt: str):
        result = self.model.invoke(prompt)
        return result

    def get_decision_making_prompt(self, query: str, list_of_questions: List[str]):

        prompt_template = SimplePromptTemplate(template=DECISION_PROMPT)
        prompt = prompt_template.format(
            **{
                "question": query,
                "list_of_questions": list_of_questions,
                "examples": DECISION_EXAMPLES,
                "output_prompt_format": DECISION_OUTPUT_PROMPT_FORMAT,
            }
        )
        parser = PydanticOutputParser(pydantic_object=DecisionOutput)
        return prompt, parser

    def get_clarifying_prompt(self, query: str, list_of_questions: List[str]):
        prompt_template = SimplePromptTemplate(template=CLARIFYING_PROMPT)
        prompt = prompt_template.format(
            **{
                "question": query,
                "list_of_questions": list_of_questions,
                "examples": CLARIFYING_EXAMPLES,
                "output_prompt_format": CLARIFYING_OUTPUT_PROMPT_FORMAT,
            }
        )
        parser = PydanticOutputParser(pydantic_object=ClarifyingOutput)
        return prompt, parser

    def get_rephrasing_prompt(self, query: str, list_of_questions: List[str]):
        prompt_template = SimplePromptTemplate(template=REPHRASING_PROMPT)
        prompt = prompt_template.format(
            **{
                "question": query,
                "list_of_questions": list_of_questions,
                "use_case_definitions": USE_CASE_DEFINITIONS,
                "examples": REPHRASING_EXAMPLES,
                "output_prompt_format": REPHRASING_OUTPUT_PROMPT_FORMAT,
            }
        )
        parser = PydanticOutputParser(pydantic_object=RephrasingOutput)
        return prompt, parser
