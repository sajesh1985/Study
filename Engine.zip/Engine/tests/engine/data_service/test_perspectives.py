#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Copyright (C) S&P Global. All Rights Reserved.
NOTICE: All information contained herein is, and remains the  property of S&P Global and its suppliers,
if any. The intellectual and technical concepts contained herein are  proprietary to S&P Global and its suppliers and
may be covered by U.S. and Foreign Patents, patents in process,  and are protected by trade secret or copyright law.
Dissemination of this information or reproduction of this  material is strictly forbidden unless prior written
permission is obtained from S&P Global.
"""

import os
from typing import Dict, List, Tuple

from chatrd.engine.data_service.perspectives import Perspective


def test_examples_to_few_shot_format():
    examples = [
        {
            "prompt": "list companies",
            "payload": {"type": "company", "industry": "technology"},
        },
        {
            "prompt": "show transactions",
            "payload": {"type": "transaction", "status": "completed"},
        },
        {"prompt": "sanity check", "payload": {}},
    ]
    expected_result = (
        'list companies -> {"type": "company", "industry": "technology"}\n'
        'show transactions -> {"type": "transaction", "status": "completed"}\n'
        "sanity check -> {}"
    )

    p = Perspective(name="", examples=[])
    p.examples = examples
    result = p.examples_to_few_shot_format()
    assert result == expected_result
