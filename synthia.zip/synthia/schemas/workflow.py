from enum import Enum
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field
from typing_extensions import TypedDict, NotRequired

from src.synthia.schemas.sections import Section


class ReportConfig(TypedDict):
    topic: str  # Keyinstn eg. 100369
    style: NotRequired[str]  # Optional with default "business"
    depth: NotRequired[int]  # Optional with default 3
    report_template: NotRequired[str]  # Optional with default 3
    num_sections: NotRequired[int]  # Optional with default 5
    outline_only: NotRequired[bool]  # Optional with default False
    approved_outline: NotRequired[Optional[List[Section]]]  # Optional
    auth_token: NotRequired[Optional[str]]  # Optional
    job_id: NotRequired[str]  # Unique identifier for the report generation job
    input_section_title: NotRequired[str]  # user input template section


class OutlineSection(TypedDict):
    """
    Represents a single section in the report outline.

    Fields:
        name (str): The title or heading of the outline section.
        description (str): A detailed description of what the section covers.
        tools (Optional[List[str]]): An optional list of tools or methods to use for this section.
    """

    name: str  # The title/name of the section
    description: str  # Detailed description of what the section covers
    tools: Optional[List[str]]  # Optional list of tools/methods to use for this section


class ReportSection(BaseModel):
    """
    Represents a section of a generated report, including its content, sources, images, a list of subsections, and processing metadata.

    Fields:
        name (str): The title or heading of the section.
        content (str): The main textual content of the section.
        sources (Optional[List[str]]): List of unique sources or references used in this section.
        image (Optional[str]): URL or identifier for an image associated with this section.
        usage_metrics (Optional[List[Dict[str, Any]]]): Unrelated to the section content, this field contains a list of usage metrics for this section, such as response metadata and usage metadata.
    """

    name: str
    content: Optional[str] = None
    sources: Optional[List[str]] = None
    image: Optional[str] = None
    section_index: Optional[int] = None
    chart_data: Optional[List[Any]] = None

    # Processing metadata
    # processing_time: Optional[float]  # Time taken to generate this section
    # word_count: Optional[int]  # Word count of the content
    # generation_method: Optional[str]  # Method used (MCP agent, fallback, etc.)
    # errors: Optional[List[str]]  # Any errors encountered during generation
    # status: Optional[str]  # Section status (completed, failed, etc.)
    # llm_logs: Optional[str]  # LLM logs for this section
    # status: Optional[str]  # Section status (completed, failed, etc.)
    # llm_logs: Optional[str]  # LLM logs for this section


class ReportStatus(BaseModel):
    """
    Represents the status of a report generation job.

    Fields:
        job_id (str): Unique identifier for the report generation job.
        keyonlineuser (int): User identifier.
        status (str): Current status of the job (e.g., 'initializing', 'in_progress', 'completed', 'failed').
        progress (Optional[float]): Progress percentage (0.0 to 100.0).
        report_title (Optional[str]): Title of the report.
        report_config (Optional[Dict[str, Any]]): Configuration used for report generation.
        outline (Optional[List[Dict[str, Any]]]): Report outline structure.
        sections (Optional[List[Dict[str, Any]]]): Generated report sections.
        error (Optional[str]): Error message if the job failed.
        completed_at (Optional[str]): Timestamp when the job was completed.
        started_at (Optional[str]): Timestamp when the job was started.
        created_at (str): Timestamp when the job was created.
        updated_at (str): Timestamp when the job was last updated.
    """

    job_id: str
    keyonlineuser: Optional[int] = None
    status: Optional[str] = None
    progress: Optional[float] = None
    report_title: Optional[str] = None
    report_config: Optional[ReportConfig] = None
    outline: Optional[List[Section]] = None
    sections: Optional[List[ReportSection]] = None
    error: Optional[str] = None
    completed_at: Optional[str] = None
    started_at: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None



class ReportStatusEnum(Enum):
    """Enum for report generation job statuses."""
    INITIALIZING = "initializing"
    CREATING_OUTLINE = "creating_outline"
    CREATING_REPORT = "creating_report"
    QUEUED = "queued"
    PROCESSING = "processing"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    AWAITING_APPROVAL = "awaiting_approval"
    OUTLINE_APPROVED = "outline_approved"