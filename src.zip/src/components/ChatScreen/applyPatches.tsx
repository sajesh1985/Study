import { applyPatches as immerApplyPatches, enablePatches, produce, Patch } from 'immer';

// Extends JSONPatch with an 'append' operation
export interface AppendPatch {
  op: 'append';
  path: (string | number)[];
  value?: unknown;
}

export type ExtendedPatch = Patch | AppendPatch;

enablePatches();

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const applyPatches = <T extends { [key: string]: any }>(
  value: T,
  patches: ExtendedPatch[]
): T => {
  const patched = produce(value, (draft) => {
    patches.forEach((patch) => {
      if (patch.op === 'append') {
        let base = draft;
        for (let i = 0; i < patch.path.length - 1; i += 1) {
          const prop = patch.path[i];
          base = base[prop];
        }
        const key = patch.path[patch.path.length - 1];

        //if (typeof base[key] !== 'string') throw new Error('Unable to append to non-string values');

        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-ignore
        base[key] = base[key].concat(String(patch.value));
      } else if(patch.op === 'add'){
        immerApplyPatches(draft, [patch]);
      }
    });
  });
  return patched;
};
