import { 
  Modal,
  ModalContent
} from '@spglobal/react-components';
import { Size } from '@spglobal/koi-helpers';
import React, { useState } from 'react';

import { makeDashboardUserInputAnswerApiRequest } from '../../../services/api';

import { MarkdownToHtmlConverter } from '../MarkdownToHtmlConverter/MarkdownToHtmlConverter';

interface InfoFeedbackWindowProps {
  linkText: string;
  sessionId: string;
  interactionId: string;
}

export const InfoFeedbackWindow: React.FC<InfoFeedbackWindowProps> = ({
  linkText,
  sessionId,
  interactionId,
}) => {

  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(false);
  const [stateResponse, setStateResponse] = useState<string>('');

  const [isOpenModal, setIsOpenModal ] = useState(false)

  const loadData = async () => {
    setIsOpenModal(true)

    setIsLoading(true);
    setError(null)
    try {
      // let response: ServerResponseType[] | null = null;
      let response: any = null;
      if (!response){
        response = await makeDashboardUserInputAnswerApiRequest(`${sessionId}/${interactionId}`);
        setStateResponse(response);
      }
      
    } catch (error) {
      console.error('Fetch answer for user input error', error);
      setError(true)
    } finally {
      setIsLoading(false);
    }
  };

  const handleClick = () => {
    setIsOpenModal(true);
    loadData();
  }

  return (
    <div>
      { linkText && (
        <><div
          onClick={handleClick}
          style={{ color: 'var(--color-text-link)', cursor: 'pointer' }}>
          {linkText}
        </div>
        
        <Modal
          autoFocus
          canEscapeKeyClose
          canOutsideClickClose
          enforceFocus
          hasBackdrop={false}
          transitionDuration={100}
          usePortal
          size={Size.LARGE}
          isOpen={isOpenModal}
          onClose={() => setIsOpenModal(false)}
        >
          <ModalContent>
            {error && <div style={{display:'flex', justifyContent:"center"}}>no data from sever</div>}
            {!error && stateResponse && <MarkdownToHtmlConverter sourceData={stateResponse} />}
            {!error && !stateResponse && isLoading && <div style={{display:'flex', justifyContent:"center"}}>Loading...</div>}
          </ModalContent>
        </Modal>
        </>
      )}  
    </div>
  );
};
