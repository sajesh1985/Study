DEFINITION_GUIDELINES_EXAMPLES = """
{
    "question": "What is meaning of xyz?",
    "guidelines": "1. Write an abstract that will summarize the bullets and call it **Summary**. \n2. Format the **Summary** as a title and paragraph. Summary must contain the conclusions and insights from the keypoints in a paragraph form. \n3. In the summary section do not include sentences like 'The summary of the key points from the provided information is as follows:' \n4. After the summary paragraph, the response must start with the exact phrase that must not be omitted: 'Based on S&P Global Ratings definitions,' followed by the detailed explanation. \n5. If you can not answer the query based on the information provided state that accordingly. Otherwise write a detailed report of the keypoints: answer the specific question and decide which other keypoints are relevant. When answering, prioritize documents that are most relevant but be verbose. \n6. Format must be: **Summary** header <paragraph>at least 3-sentences summary starting with 'S&P Global Ratings' research '</paragraph> and then followed by <paragraph><sentence>'Based on S&P Global Ratings definitions, the meaning of xyz is as follows:'</sentence> followed by keypoints and must not contain any conclusion at the end.</paragraph> \n7. Do not include the user query into the response."
}
__________________
{
    "question": "What does issuer credit rating xyz mean?",
    "guidelines": "1. Write an abstract that will summarize the bullets and call it **Summary**. \n2. Format the **Summary** as a title and paragraph. Summary must contain the conclusions and insights from the keypoints in a paragraph form. \n3. In the summary section do not include sentences like 'The summary of the key points from the provided information is as follows:' \n4. After the summary paragraph, the response must start with the exact phrase that must not be omitted: 'Based on S&P Global Ratings definitions,' followed by the detailed explanation. \n5. If you can not answer the query based on the information provided state that accordingly. Otherwise write a detailed report of the keypoints: answer the specific question and decide which other keypoints are relevant. When answering, prioritize documents that are most relevant but be verbose. \n6. Format must be: **Summary** header <paragraph>at least 3-sentences summary starting with 'S&P Global Ratings' research '</paragraph> followed by <paragraph><sentence>'Based on S&P Global Ratings definitions, issuer credit rating xyz is defined as follows:'</sentence> followed by keypoints and must not contain any conclusion at the end.</paragraph>\n7. Do not include the user query into the response."
}
__________________
{
    "question": "What is the difference between xyz and abc?",
    "guidelines": "1. Write an abstract that will summarize the bullets and call it **Summary**. \n2. Format the **Summary** as a title and paragraph. Summary must contain the conclusions and insights from the keypoints in a paragraph form. \n3. In the summary section do not include sentences like 'The summary of the key points from the provided information is as follows:' \n4. After the summary paragraph, the response must start with the exact phrase that must not be omitted: 'Based on S&P Global Ratings definitions,' followed by the detailed explanation. \n5. If you can not answer the query based on the information provided state that accordingly. Specifically, if there is no information about xyz or abc in the provided documents, make it clear in your response. Otherwise write a detailed report of the keypoints: answer the specific question and decide which other keypoints are relevant. When answering, prioritize documents that are most relevant but be verbose. \n6. Format must be: **Summary header** <paragraph>at least 3-sentences summary starting with 'S&P Global Ratings' research'</paragraph> followed by <paragraph><sentence>'Based on S&P Global Ratings definitions, the main difference between xyz and abc is following:'</sentence> followed by keypoints and must not contain any conclusion at the end.</paragraph> \n7. Do not include the user query into the response."
}
__________________ 
{ 
    "question": "Explain investment grade versus speculative grade", 
    "guidelines": "1. Write an abstract that will summarize the bullets and call it **Summary**. \n2. Format the **Summary** as a title and paragraph. Summary must contain the conclusions and insights from the keypoints in a paragraph form. \n3. In the summary section do not include sentences like 'The summary of the key points from the provided information is as follows:' \n4. After the summary paragraph, the response must start with the exact phrase that must not be omitted: 'Based on S&P Global Ratings definitions,' followed by the detailed explanation. \n5. If you can not answer the query based on the information provided state that accordingly. Otherwise write a detailed report of the keypoints: answer the specific question and decide which other keypoints are relevant. When answering, prioritize documents that are most relevant but be verbose. \n6. Format must be: **Summary** header <paragraph>at least 3-sentences summary starting with 'S&P Global Ratings' research '</paragraph> and then followed by <paragraph><sentence>'Based on S&P Global Ratings definitions, the differences between investment grade and speculative grade are as follows'</sentence> followed by keypoints and must not contain any conclusion at the end.</paragraph> \n7. Do not include the user query into the response." 
} 
__________________ 
{ 
    "question": "How does S&P Global Ratings define CreditWatch?", 
    "guidelines": "1. Write an abstract that will summarize the bullets and call it **Summary**. \n2. Format the **Summary** as a title and paragraph. Summary must contain the conclusions and insights from the keypoints in a paragraph form. \n3. In the summary section do not include sentences like 'The summary of the key points from the provided information is as follows:' \n4. After the summary paragraph, the response must start with the exact phrase that must not be omitted: 'Based on S&P Global Ratings definitions,' followed by the detailed explanation. \n5. If you can not answer the query based on the information provided state that accordingly. Otherwise write a detailed report of the keypoints: answer the specific question and decide which other keypoints are relevant. When answering, prioritize documents that are most relevant but be verbose. \n6. Format must be: **Summary** header <paragraph>at least 3-sentences summary starting with 'S&P Global Ratings' research '</paragraph> and then followed by <paragraph><sentence>'Based on S&P Global Ratings definitions, CreditWatch is defined as follows:'</sentence> followed by keypoints and must not contain any conclusion at the end.</paragraph>\n7. Do not include the user query into the response." 
} 
__________________ 
{ 
    "question": "What do you mean by commercial paper program?", 
    "guidelines": "1. Write an abstract that will summarize the bullets and call it **Summary**. \n2. Format the **Summary** as a title and paragraph. Summary must contain the conclusions and insights from the keypoints in a paragraph form. \n3. In the summary section do not include sentences like 'The summary of the key points from the provided information is as follows:' \n4. After the summary paragraph, the response must start with the exact phrase that must not be omitted: 'Based on S&P Global Ratings definitions,' followed by the detailed explanation. \n5. If you can not answer the query based on the information provided state that accordingly. Otherwise write a detailed report of the keypoints: answer the specific question and decide which other keypoints are relevant. When answering, prioritize documents that are most relevant but be verbose. \n6. Format must be: **Summary** header<paragraph>at least 3-sentences summary starting with 'S&P Global Ratings' research '</paragraph> and then followed by <paragraph><sentence>'Based on S&P Global Ratings definitions, commercial paper program is:'</sentence> followed by keypoints and must not contain any conclusion at the end.</paragraph> \n7. Do not include the user query into the response." 
}

__________________ 
{ 
    "question": "definition for CCC+, CCC, CCC-, and CC", 
    "guidelines": "1. Write an abstract that will summarize the bullets and call it **Summary**. \n2. Format the **Summary** as a title and paragraph. Summary must contain the conclusions and insights from the keypoints in a paragraph form. \n3. In the summary section do not include sentences like 'The summary of the key points from the provided information is as follows:' \n4. After the summary paragraph, the response must start with the exact phrase that must not be omitted: 'Based on S&P Global Ratings definitions,' followed by the detailed explanation \n5. If you can not answer the query based on the information provided state that accordingly. Otherwise write a detailed report of the keypoints: answer the specific question and decide which other keypoints are relevant. When answering, prioritize documents that are most relevant but be verbose. \n6. Format must be: **Summary** header <paragraph>at least 3-sentences summary starting with 'S&P Global Ratings' research '</paragraph> and then followed by <paragraph><sentence>'Based on S&P Global Ratings definitions, definitions for CCC+, CCC, CCC-, and CC are as follows:'</sentence> followed by keypoints and must not contain any conclusion at the end.</paragraph> \n7. Do not include the user query into the response."
}
__________________ 
{
    "question": "What's the difference in issuer rating and corporate rating", 
    "guidelines": "1. Write an abstract that will summarize the bullets and call it **Summary**. \n2. Format the **Summary** as a title and paragraph. Summary must contain the conclusions and insights from the keypoints in a paragraph form. \n3. In the summary section do not include sentences like 'The summary of the key points from the provided information is as follows:' \n4. After the summary paragraph, the response must start with the exact phrase that must not be omitted: 'Based on S&P Global Ratings definitions,' followed by the detailed explanation.  \n5. If you can not answer the query based on the information provided state that accordingly. Specifically, if there is no information about xyz or abc in the provided documents, make it clear in your response. Otherwise write a detailed report of the keypoints: answer the specific question and decide which other keypoints are relevant. When answering, prioritize documents that are most relevant but be verbose. \n6. Format must be: **Summary** header <paragraph>at least 3-sentences summary starting with 'S&P Global Ratings' research '</paragraph> and then followed by <paragraph><sentence>'Based on S&P Global Ratings definitions, the key difference between issuer rating and corporate rating are as follows'</sentence> followed by keypoints and must not contain any conclusion at the end.</paragraph> \n7. Do not include the user query into the response."
}
__________________ 
{
    "question": "How is the local currency rating different from foreign currency rating?", 
    "guidelines": "1. Write an abstract that will summarize the bullets and call it **Summary**. \n2. Format the **Summary** as a title and paragraph. Summary must contain the conclusions and insights from the keypoints in a paragraph form. \n3. In the summary section do not include sentences like 'The summary of the key points from the provided information is as follows:' \n4. After the summary paragraph, the response must start with the exact phrase that must not be omitted: 'Based on S&P Global Ratings definitions,' followed by the detailed explanation.  \n5. If you can not answer the query based on the information provided state that accordingly. Specifically, if there is no information about xyz or abc in the provided documents, make it clear in your response. Otherwise write a detailed report of the keypoints: answer the specific question and decide which other keypoints are relevant. When answering, prioritize documents that are most relevant but be verbose. \n6. Format must be: **Summary** header <paragraph>at least 3-sentences summary starting with 'S&P Global Ratings' research '</paragraph> and then followed by <paragraph><sentence>'Based on S&P Global Ratings definitions, the main differences between local currency rating and foreign currency rating are as follows:'</sentence> followed by keypoints and must not contain any conclusion at the end.</paragraph> \n7. Do not include the user query into the response."
}
"""

DEFINITION_GUIDELINES_PROMPTS = """
You are an excellent financial credit analyst and you will be given a question from the user.
Your task will be to extract information regarding user question:
* Guidelines highlighting relevant factors when answering the question. (key: guidelines)

<Examples pairs of question (key: question) and guidelines (key: guidelines) are given below in JSON format: 
<examples> 

{examples}  

</examples> 

Take a deep breath and understand that these examples should not affect the extractions for any other keys.

NOTE:  You must NOT mention any question in the response. 
       Do not say things like "Based on the provided rating information...". 

Answer JSON object which should contain following properties:
* "guidelines"

<question>
{question}
</question>

You must return the guidelines in the same format as shown in the examples. 
Don't try to answer the questions. 
Just return a guidelines JSON object. Return the json only, do not return anything else. 
"""

definition_guidelines = {"prompt": DEFINITION_GUIDELINES_PROMPTS, "examples": DEFINITION_GUIDELINES_EXAMPLES}
