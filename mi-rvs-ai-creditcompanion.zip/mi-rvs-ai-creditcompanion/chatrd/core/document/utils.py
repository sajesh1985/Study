import copy
import logging
import re
import string
import time
from collections.abc import Sequence
from typing import Optional

import boto3
import lxml
import pandas as pd
from lxml import etree

from chatrd.core.document.schema import Document
from chatrd.core.document.text_splitters import MarkdownHeaderTextSplitter

logger = logging.getLogger(__name__)


MULTIPLE_WHITESPACE_PATTERN = re.compile(r"\s+")
SINGLE_CHUNK_SECTION_NAMES = [
    "outlook",
    "stable outlook",
    "creditwatch",
    "environmental social governance",
    "peer comparison",
]


def _clean_multiple_whitespaces(text: str) -> str:
    return MULTIPLE_WHITESPACE_PATTERN.sub(" ", text).strip(string.whitespace)


def _is_valid_chunk(text: str) -> bool:
    if not text:
        return False
    if text.lower() == "this paragraph has been deleted.":
        return False
    return True


def get_tablerow_text(row: lxml.etree._Element) -> Sequence[str]:
    """Takes a table row element and returns a sequence of text from the table cells

    Args:
        row (lxml.etree._Element) : row element of table

    Returns:
        texts (Sequence[str]) : Texts found in row element cells

    """
    texts = []
    for cell in row:
        for raw_text in cell.itertext():
            text = raw_text.strip()
            if text != "":
                texts.append(text)
    return texts


def parse_definitions_table(table: lxml.etree._Element) -> Optional[str]:
    """Takes a table, checks if it is a Defintions table, and if so converts the table to a markdown list. Otherwise, returns None.

    Args:
        table (lxml.etree._Element) : XML table element

    Returns:
        table_chunk (Optional[str]) : Markdown list made from table or none if the table cannot be parsed

    """
    header_row = etree.XPath("./tablerow[tablecolhead]")(table)
    header = " ".join(get_tablerow_text(header_row)).strip()
    if header == "Category Definition":
        table_chunk = ""
        for tablerow in etree.XPath("./tablerow[tabletext]")(table):
            table_chunk += "- " + ": ".join(get_tablerow_text(tablerow)).strip() + "\n"
        return table_chunk[0:-1]
    return None


def parse_definitions_list(li: lxml.etree._Element) -> str:
    """Converts xml list to markdown list

    Args:
        li (lxml.etree._Element) : xml list element

    Returns:
        chunk (str) : markdown list made from xml list
    """
    bullets = etree.XPath("./listitem")(li)
    chunk = "\n".join(map(lambda x: "- " + x, filter(lambda y: y is not None, map(lambda x: x.text, bullets))))
    return chunk


def _clean_criteria_xml(xml_string: str) -> str:
    root = etree.fromstring(xml_string)
    for element in list(root.iter()):
        is_remove = False

        if element.tag in [
            "EditorsNote",
            "object",
            "Disclaimer",
            "sptable",
            "Boilerplate",
            "chart",
            "page_break",
            "table",
        ]:
            is_remove = True

        if (
            element.tag == "section"
            and element.attrib.get("name") is not None
            and element.attrib.get("name").lower()
            in [
                "related research",
                "related criteria",
                "revisions and updates",
                "related criteria and research",
                "related publications",
                "superseded criteria",
                "recent research",
            ]
        ):
            is_remove = True

        if is_remove:
            element.getparent().remove(element)
    return etree.tostring(root, encoding="utf-8").decode("utf-8")


def _clean_research_xml(xml_string: str) -> str:
    root = etree.fromstring(xml_string)
    for element in list(root.iter()):
        is_remove = False

        if element.tag in [
            "EditorsNote",
            "object",
            "Disclaimer",
            "sptable",
            "Boilerplate",
            "chart",
            "page_break",
            "preformat",
        ]:
            is_remove = True

        if (
            element.tag == "section"
            and element.attrib.get("name") is not None
            and element.attrib.get("name").lower()
            in [
                "related research",
                "related criteria",
                "revisions and updates",
                "related criteria and research",
                "related publications",
                "superseded criteria",
                "recent research",
            ]
        ):
            is_remove = True

        if element.tag == "table":
            if (
                element.getparent() is not None
                and element.getparent().attrib.get("name") is not None
                and element.getparent().attrib.get("name").lower() == "credit highlights"
            ):
                is_remove = False
            elif (
                element.getparent() is not None
                and element.getparent().getparent() is not None
                and element.getparent().getparent().attrib.get("name") is not None
                and element.getparent().getparent().attrib.get("name").lower() == "credit highlights"
            ):
                is_remove = False
            else:
                is_remove = True

        if is_remove:
            element.getparent().remove(element)
    return etree.tostring(root, encoding="utf-8").decode("utf-8")


def _clean_commentary_xml(xml_string: str) -> str:
    root = etree.fromstring(xml_string)
    for element in list(root.iter()):
        is_remove = False

        if element.tag in [
            "EditorsNote",
            "object",
            "Disclaimer",
            "sptable",
            "Boilerplate",
            "chart",
            "page_break",
            "preformat",
        ]:
            is_remove = True

        if (
            element.tag == "section"
            and element.attrib.get("name") is not None
            and element.attrib.get("name").lower()
            in [
                "related research",
                "related criteria",
                "revisions and updates",
                "related criteria and research",
                "related publications",
                "superseded criteria",
                "recent research",
            ]
        ):
            is_remove = True

        if element.tag == "table":
            if (
                element.getparent() is not None
                and element.getparent().attrib.get("name") is not None
                and element.getparent().attrib.get("name").lower() == "credit highlights"
            ):
                is_remove = False
            elif (
                element.getparent() is not None
                and element.getparent().getparent() is not None
                and element.getparent().getparent().attrib.get("name") is not None
                and element.getparent().getparent().attrib.get("name").lower() == "credit highlights"
            ):
                is_remove = False
            else:
                is_remove = True

        if is_remove:
            element.getparent().remove(element)
    return etree.tostring(root, encoding="utf-8").decode("utf-8")


def _clean_definitions_xml(xml_string: str) -> str:
    """Removes irrelevant sections and tags for the definitions xml

    Args:
        xml_string (str) : Definitions document XML String

    Returns:
        cleaned_str (str) : Cleaned definitions document XML String

    """

    root = etree.fromstring(xml_string)
    for element in list(root.iter()):
        is_remove = False

        if element.tag in [
            "EditorsNote",
            "object",
            "Disclaimer",
            "sptable",
            "Boilerplate",
            "chart",
            "page_break",
            "tableenvelope1",
        ]:
            is_remove = True

        if element.tag == "section":
            # removes irrelevant sections
            if element.attrib.get("name") is not None and (
                element.attrib.get("name").lower().strip()
                in {"ix. revisions and updates", "x.  related criteria and research", "xi.  contact information"}
            ):
                is_remove = True

        if is_remove:
            element.getparent().remove(element)
    return etree.tostring(root, encoding="utf-8").decode("utf-8")


def _clean_commentary_xml(xml_string: str) -> str:
    """Removes irrelevant sections and tags for the commentary xml

    Args:
        xml_string (str) : Definitions document XML String

    Returns:
        cleaned_str (str) : Cleaned definitions document XML String

    """
    root = etree.fromstring(xml_string)
    for element in list(root.iter()):
        is_remove = False

        if element.tag in [
            "EditorsNote",
            "object",
            "Disclaimer",
            "sptable",
            "Boilerplate",
            "chart",
            "page_break",
            "preformat",
        ]:
            is_remove = True

        if (
            element.tag == "section"
            and element.attrib.get("name") is not None
            and element.attrib.get("name").lower()
            in [
                "related research",
                "related criteria",
                "revisions and updates",
                "related criteria and research",
                "related publications",
                "superseded criteria",
                "recent research",
            ]
        ):
            is_remove = True

        if element.tag == "table":
            if (
                element.getparent() is not None
                and element.getparent().attrib.get("name") is not None
                and element.getparent().attrib.get("name").lower() == "credit highlights"
            ):
                is_remove = False
            elif (
                element.getparent() is not None
                and element.getparent().getparent() is not None
                and element.getparent().getparent().attrib.get("name") is not None
                and element.getparent().getparent().attrib.get("name").lower() == "credit highlights"
            ):
                is_remove = False
            else:
                is_remove = True

        if is_remove:
            element.getparent().remove(element)
    return etree.tostring(root, encoding="utf-8").decode("utf-8")


def _split_criteria_xml(xml_string: str) -> tuple[Sequence[str], Sequence[dict]]:
    """Splits criteria xml files into chunks.

    Args:
        xml_string : Cleaned criteria document xml string

    Returns:
        (chunks, metadata) : List of chunks and a list of their associated metadata

    """
    root = etree.fromstring(xml_string)
    chunks = []
    metadata = []
    for element in root.iter():
        chunk = ""
        invalid = False

        if element.tag in ["para", "paranum", "subsection"]:
            chunk = "".join(element.itertext())
            chunk = _clean_multiple_whitespaces(chunk)

            if (
                chunk and chunk[-1] == ":" and element.getnext() is not None and element.getnext().tag == "list"
            ):  # leading sentence for items
                invalid = True

        elif element.tag == "list":
            previous_chunk = ""
            if element.getprevious() is not None and element.getprevious().tag in ["para", "paranum", "subsection"]:
                previous_chunk_name = ""
                if element.getprevious().attrib.get("name") is not None:
                    previous_chunk_name = element.getprevious().attrib.get("name")
                previous_chunk_name = _clean_multiple_whitespaces(previous_chunk_name)

                previous_chunk = _clean_multiple_whitespaces("".join(element.getprevious().itertext()))
                if not (previous_chunk and previous_chunk[-1] == ":"):
                    previous_chunk = ""

            chunk = [_clean_multiple_whitespaces(list_item) for list_item in element.itertext()]
            chunk = [list_item for list_item in chunk if list_item]
            chunk = "\n- ".join(chunk)
            chunk = f"- {chunk}"
            is_valid_chunk = _is_valid_chunk(chunk)
            if is_valid_chunk:
                if previous_chunk:  # leading sentence for items
                    if previous_chunk_name:
                        previous_chunk = f"{previous_chunk_name}\n{previous_chunk}"
                    chunk = f"{previous_chunk}\n{chunk}"

        elif element.tag == "section":
            child_tags = {e.tag for e in element.iterchildren()}
            if not child_tags.intersection(["para", "paranum", "section", "subsection", "list", "table"]):
                chunk = "".join(element.itertext())
                chunk = _clean_multiple_whitespaces(chunk)

        if chunk != "" and _is_valid_chunk(chunk) and not invalid:
            chunk_title = ""
            if element.attrib.get("name") is not None:
                chunk_title = element.attrib.get("name")
            else:
                if element.getparent() is not None and element.getparent().attrib.get("name") is not None:
                    chunk_title = element.getparent().attrib.get("name")
            chunks.append(chunk.strip())
            metadata.append({"chunk_title": _clean_multiple_whitespaces(chunk_title)})
    assert len(chunks) == len(metadata)
    return chunks, metadata


def are_all_words_present(string_list, large_text):
    if large_text is None:
        return False
    large_text = large_text.lower()
    for item in string_list:
        if all(word in large_text for word in item.split()):
            return True
    return False


def _split_research_xml(xml_string: str) -> tuple[Sequence[str], Sequence[dict]]:
    root = etree.fromstring(xml_string)
    chunks = []
    metadata = []
    for element in root.iter():
        is_valid_chunk = False
        if element.getparent():
            if are_all_words_present(SINGLE_CHUNK_SECTION_NAMES, element.getparent().attrib.get("name")):
                continue
            elif element.getparent().getparent():
                if are_all_words_present(
                    SINGLE_CHUNK_SECTION_NAMES, element.getparent().getparent().attrib.get("name")
                ):
                    continue

        if element.tag in ["para", "paranum"]:
            chunk = "".join(element.itertext())
            chunk = _clean_multiple_whitespaces(chunk)
            is_valid_chunk = _is_valid_chunk(chunk)

            if (
                chunk and chunk[-1] == ":" and element.getnext() is not None and element.getnext().tag == "list"
            ):  # leading sentence for items
                is_valid_chunk = False

            if is_valid_chunk:
                chunks.append(chunk)

        if element.tag == "list":
            previous_chunk = ""
            if element.getprevious() is not None and element.getprevious().tag in ["para", "paranum", "subsection"]:
                previous_chunk_name = ""
                if element.getprevious().attrib.get("name") is not None:
                    previous_chunk_name = element.getprevious().attrib.get("name")
                previous_chunk_name = _clean_multiple_whitespaces(previous_chunk_name)

                previous_chunk = _clean_multiple_whitespaces("".join(element.getprevious().itertext()))
                if not (previous_chunk and previous_chunk[-1] == ":"):
                    previous_chunk = ""

            chunk = [_clean_multiple_whitespaces(list_item) for list_item in element.itertext()]
            chunk = [list_item for list_item in chunk if list_item]
            chunk = "\n- ".join(chunk)
            chunk = f"- {chunk}"
            is_valid_chunk = _is_valid_chunk(chunk)
            if is_valid_chunk:
                if previous_chunk:  # leading sentence for items
                    if previous_chunk_name:
                        previous_chunk = f"{previous_chunk_name}\n{previous_chunk}"
                    chunk = f"{previous_chunk}\n{chunk}"
                chunks.append(chunk)

        if element.tag in ["section", "subsection"]:
            if are_all_words_present(SINGLE_CHUNK_SECTION_NAMES, element.attrib.get("name")):
                chunk_list = []
                for child in element.iter():
                    if child.text:
                        cleaned_text = _clean_multiple_whitespaces(child.text)
                        if child is element:
                            if cleaned_text:
                                chunk_list.append(cleaned_text)
                            continue
                        if child.attrib.get("name"):
                            if "downside" in child.attrib.get("name").lower():
                                text = child.attrib.get("name") + " or Downgrade Triggers"
                            elif "upside" in child.attrib.get("name").lower():
                                text = child.attrib.get("name") + " or Upgrade Triggers"
                            else:
                                text = child.attrib.get("name")
                            if text:
                                chunk_list.append("\n" + _clean_multiple_whitespaces(text) + ":\n")
                        if child.tag == "listitem":
                            chunk_list.append(f"- {cleaned_text}")
                        else:
                            chunk_list.append(f"{cleaned_text}")

                chunk = "\n".join(chunk_list)
                is_valid_chunk = _is_valid_chunk(chunk)
                if is_valid_chunk:
                    chunks.append(chunk)
            else:
                child_tags = {e.tag for e in element.iterchildren()}
                if not child_tags.intersection(["para", "paranum", "section", "subsection", "list", "table"]):
                    chunk = "".join(element.itertext())
                    chunk = _clean_multiple_whitespaces(chunk)
                    is_valid_chunk = _is_valid_chunk(chunk)

                    if (
                        element.tag == "subsection"
                        and chunk
                        and chunk[-1] == ":"
                        and element.getnext() is not None
                        and element.getnext().tag == "list"
                    ):  # leading sentence for items
                        is_valid_chunk = False

                    if is_valid_chunk:
                        chunks.append(chunk)

        if element.tag == "table":
            rows = []
            for row in element.iter("tablerow"):
                items = [_clean_multiple_whitespaces(item) for item in row.itertext()]
                items = [item for item in items if item]
                rows.append(" | ".join(items))
            chunk = "\n".join(rows)
            is_valid_chunk = _is_valid_chunk(chunk)
            if is_valid_chunk:
                chunks.append(chunk)

        if is_valid_chunk:
            chunk_title = ""
            if element.attrib.get("name") is not None:
                chunk_title = element.attrib.get("name")
            else:
                if (
                    element.getparent() is not None
                    and element.getparent().attrib.get("name") is not None
                    and element.getparent().attrib.get("name") != ""
                ):
                    chunk_title = element.getparent().attrib.get("name")
                else:
                    if (
                        element.getparent() is not None
                        and element.getparent().getparent() is not None
                        and element.getparent().getparent().attrib.get("name") is not None
                    ):
                        chunk_title = element.getparent().getparent().attrib.get("name")
            cleaned_chunk_title = _clean_multiple_whitespaces(chunk_title)
            if are_all_words_present(["environmental social governance"], cleaned_chunk_title):
                cleaned_chunk_title = cleaned_chunk_title + " (ESG)"
            metadata.append({"chunk_title": cleaned_chunk_title})

    assert len(chunks) == len(metadata)
    return chunks, metadata


def _split_definitions_xml(xml_string: str) -> tuple[Sequence[str], Sequence[dict]]:
    """Splits definition xml files into chunks.

    Args:
        xml_string : Cleaned definitions xml string

    Returns:
        (chunks, metadata) : List of chunks and a list of their associated metadata

    """

    root = etree.fromstring(xml_string)

    sections = [section for section in etree.XPath("./section")(etree.XPath("//body")(root)[0])]

    # Get table of contents of document
    toc = list(map(lambda x: x.attrib["name"], sections))

    app_index = toc.index("VIII. APPENDIX")

    app_toc = []
    # Iterate through appendix
    for section in sections[app_index:]:
        for name in map(lambda x: x.attrib.get("name"), etree.XPath("./section")(section)):
            # Check if the first token of the section name is a number
            if name.split(" ")[0][0:-1].isdigit():
                app_toc.append(name)

    toc = set(toc) | set(app_toc)

    # Create list of tuples where first element is a list of leaf texts and second element is a list of encountered subtitles
    leaf_chunks = {section: ([], []) for section in toc}
    # Captures text from before the first section of the document (disclosure)
    leaf_chunks[None] = ([], [])

    metadata = []
    chunks = []
    sub_chunk_title = None

    # Flag tracks when titles should be added to chunks, title is the title that needs to be added
    leading_title_flag = False
    leading_title = ""
    # Determines which chunk the leaf chunks are in
    chunk_group = None

    for element in root.iter():

        chunk = ""

        # Adds current section name to leading title, if in the toc than it becomes a main chunk and if not it becomes a subsection
        if element.tag == "section":
            leading_title_flag = True
            sub_chunk_title = element.attrib.get("name")
            leading_title = "## **" + sub_chunk_title + "**"
            if element.attrib.get("name") in toc:
                chunk_group = element.attrib.get("name")
                leading_title = "# **" + sub_chunk_title + "**"
            continue

        elif element.tag in {"para", "paranum"}:
            para_chunk = element.text
            if para_chunk is None:
                continue
            chunk += para_chunk

        elif element.tag == "table":
            table_chunk = parse_definitions_table(element)
            if table_chunk is not None:
                chunk += table_chunk

        elif element.tag == "list":
            chunk += parse_definitions_list(element)

        if chunk is not None and chunk.strip() != "":
            if leading_title_flag:
                chunk = leading_title + "\n" + chunk
                leading_title_flag = False
            leaf_chunks[chunk_group][0].append(chunk.strip())
            leaf_chunks[chunk_group][1].append(sub_chunk_title)

    # Merges leaf chunks with same chunk_group, keeps track of section names encountered
    for section_name, (leaf_chunks, subsections) in leaf_chunks.items():
        chunk = "\n".join(leaf_chunks)
        if chunk == "":
            continue
        # Transforms dictionary to be a list of chunks and a list of dictionaries of metadata
        chunks.append("\n".join(leaf_chunks))
        metadata.append({"chunk_title": section_name, "subsection_chunk_titles": list(set(subsections))})

    return chunks, metadata


def _split_commentary_xml(xml_string: str) -> tuple[Sequence[str], Sequence[dict]]:
    """Splits commentary xml files into chunks.

    Args:
        xml_string : Cleaned commentary xml string

    Returns:
        (chunks, metadata) : List of chunks and a list of their associated metadata

    """
    root = etree.fromstring(xml_string)
    chunks = []
    metadata = []
    for element in root.iter():
        is_valid_chunk = False
        if element.getparent():
            if are_all_words_present(SINGLE_CHUNK_SECTION_NAMES, element.getparent().attrib.get("name")):
                continue
            elif element.getparent().getparent():
                if are_all_words_present(
                    SINGLE_CHUNK_SECTION_NAMES, element.getparent().getparent().attrib.get("name")
                ):
                    continue

        if element.tag in ["para", "paranum"]:
            chunk = "".join(element.itertext())
            chunk = _clean_multiple_whitespaces(chunk)
            is_valid_chunk = _is_valid_chunk(chunk)

            if (
                chunk and chunk[-1] == ":" and element.getnext() is not None and element.getnext().tag == "list"
            ):  # leading sentence for items
                is_valid_chunk = False

            if is_valid_chunk:
                chunks.append(chunk)

        if element.tag == "list":
            previous_chunk = ""
            if element.getprevious() is not None and element.getprevious().tag in ["para", "paranum", "subsection"]:
                previous_chunk_name = ""
                if element.getprevious().attrib.get("name") is not None:
                    previous_chunk_name = element.getprevious().attrib.get("name")
                previous_chunk_name = _clean_multiple_whitespaces(previous_chunk_name)

                previous_chunk = _clean_multiple_whitespaces("".join(element.getprevious().itertext()))
                if not (previous_chunk and previous_chunk[-1] == ":"):
                    previous_chunk = ""

            chunk = [_clean_multiple_whitespaces(list_item) for list_item in element.itertext()]
            chunk = [list_item for list_item in chunk if list_item]
            chunk = "\n- ".join(chunk)
            chunk = f"- {chunk}"
            is_valid_chunk = _is_valid_chunk(chunk)
            if is_valid_chunk:
                if previous_chunk:  # leading sentence for items
                    if previous_chunk_name:
                        previous_chunk = f"{previous_chunk_name}\n{previous_chunk}"
                    chunk = f"{previous_chunk}\n{chunk}"
                chunks.append(chunk)

        if element.tag in ["section", "subsection"]:
            if are_all_words_present(SINGLE_CHUNK_SECTION_NAMES, element.attrib.get("name")):
                chunk_list = []
                for child in element.iter():
                    if child.text:
                        cleaned_text = _clean_multiple_whitespaces(child.text)
                        if child is element:
                            if cleaned_text:
                                chunk_list.append(cleaned_text)
                            continue
                        if child.attrib.get("name"):
                            if "downside" in child.attrib.get("name").lower():
                                text = child.attrib.get("name") + " or Downgrade Triggers"
                            elif "upside" in child.attrib.get("name").lower():
                                text = child.attrib.get("name") + " or Upgrade Triggers"
                            else:
                                text = child.attrib.get("name")
                            if text:
                                chunk_list.append("\n" + _clean_multiple_whitespaces(text) + ":\n")
                        if child.tag == "listitem":
                            chunk_list.append(f"- {cleaned_text}")
                        else:
                            chunk_list.append(f"{cleaned_text}")

                chunk = "\n".join(chunk_list)
                is_valid_chunk = _is_valid_chunk(chunk)
                if is_valid_chunk:
                    chunks.append(chunk)
            else:
                child_tags = {e.tag for e in element.iterchildren()}
                if not child_tags.intersection(["para", "paranum", "section", "subsection", "list", "table"]):
                    chunk = "".join(element.itertext())
                    chunk = _clean_multiple_whitespaces(chunk)
                    is_valid_chunk = _is_valid_chunk(chunk)

                    if (
                        element.tag == "subsection"
                        and chunk
                        and chunk[-1] == ":"
                        and element.getnext() is not None
                        and element.getnext().tag == "list"
                    ):  # leading sentence for items
                        is_valid_chunk = False

                    if is_valid_chunk:
                        chunks.append(chunk)

        if element.tag == "table":
            rows = []
            for row in element.iter("tablerow"):
                items = [_clean_multiple_whitespaces(item) for item in row.itertext()]
                items = [item for item in items if item]
                rows.append(" | ".join(items))
            chunk = "\n".join(rows)
            is_valid_chunk = _is_valid_chunk(chunk)
            if is_valid_chunk:
                chunks.append(chunk)

        if is_valid_chunk:
            chunk_title = ""
            if element.attrib.get("name") is not None:
                chunk_title = element.attrib.get("name")
            else:
                if (
                    element.getparent() is not None
                    and element.getparent().attrib.get("name") is not None
                    and element.getparent().attrib.get("name") != ""
                ):
                    chunk_title = element.getparent().attrib.get("name")
                else:
                    if (
                        element.getparent() is not None
                        and element.getparent().getparent() is not None
                        and element.getparent().getparent().attrib.get("name") is not None
                    ):
                        chunk_title = element.getparent().getparent().attrib.get("name")
            cleaned_chunk_title = _clean_multiple_whitespaces(chunk_title)
            if are_all_words_present(["environmental social governance"], cleaned_chunk_title):
                cleaned_chunk_title = cleaned_chunk_title + " (ESG)"
            metadata.append({"chunk_title": cleaned_chunk_title})

    assert len(chunks) == len(metadata)
    return chunks, metadata


def documents_as_dataframe(documents: Sequence[Document]) -> pd.DataFrame:
    data = []
    for document in documents:
        row = copy.deepcopy(document.metadata)
        row["text"] = document.content
        data.append(row)
    return pd.DataFrame(data=data)


def _split_commentary_md(document: str, chunk_size: int = 5000) -> list[str]:
    """
    Split a document into chunks based on Markdown sections, with a minimum chunk size.

    This function uses a custom MarkdownHeaderTextSplitter (based on langchain) to initially split the document
    based on Markdown headers (denoted by '#'). It then aggregates these splits into larger chunks
    to meet a minimum chunk size requirement. This approach ensures that the resulting chunks are
    semantically coherent (following Markdown structure) while also being sufficiently large for
    effective processing.

    Args:
        document (str): The full text of the document to be chunked, formatted in Markdown.
        chunk_size (int): optional threshold for the minimum chunk size that is required.

    Returns:
        list of str: A list of chunk strings, where each chunk is a section or combination of
                     sections from the original document.

    Details:
        - Minimum chunk size is set to 5000 characters (default unless provided)
        - Uses MarkdownHeaderTextSplitter with '#' as the header delimiter.
        - Chunks smaller than the minimum size are aggregated with subsequent chunks.
        - Metadata from the Markdown splitter is preserved at the start of each chunk.
        - If the final buffer is too small, it's merged with the previous chunk or added as is
          if it's the only chunk.

    Note:
        This function assumes the document is well-formatted in Markdown (i.e. coming from the Textract markdown pipeline in OCR_Textract). Improperly formatted Markdown may lead to unexpected chunking results.
    """
    min_chunk_size = chunk_size
    md_splitter = MarkdownHeaderTextSplitter(headers_to_split_on=[("#", "Header 1")])
    split_doc = md_splitter.split_text(document)
    chunks = []
    buffer = ""
    for i, doc in enumerate(split_doc):
        if doc.metadata is not None:
            buffer += "\n" + str(doc.metadata) + "\n"
        buffer += doc.page_content
        if len(buffer) < min_chunk_size:
            # chunk is too small, merging with next one
            pass
        else:
            chunks.append(buffer)
            buffer = ""
    if len(buffer) > 0:
        # final chunk is too small, merging with previous one
        if len(chunks) > 0:
            chunks[-1] += buffer
        else:
            chunks.append(buffer)
    return chunks


def pdf_bytes_to_markdown(pdf_bytes: bytes, s3_temp_path: str, profile: str = "default") -> str:
    """
    Using asynchronous textractor API, which creates jobs and results that we can fetch later.

    Args:
        pdf_bytes (bytes): binary data of the pdf that needs to be processed
        s3_temp_path (str): s3 path where pdf binary can be uploaded for textractor to work
        profile (str): optional customer’s profile name

    Returns:
        str: string representation in markdown format of the original pdf
    """
    try:
        from textractor import Textractor
        from textractor.data.constants import TextractFeatures

        logger.debug("Textractor imported successfully.")
    except ImportError as e:
        logger.error("Textractor could not be imported. Please install it.")
        raise ImportError("Failed to import Textractor. Make sure it's installed.") from e

    extractor = Textractor(profile_name=profile)
    document = extractor.start_document_analysis(
        file_source=pdf_bytes,
        s3_upload_path=s3_temp_path,
        features=[
            TextractFeatures.LAYOUT,
            TextractFeatures.TABLES,
            TextractFeatures.FORMS,
            TextractFeatures.SIGNATURES,
        ],
        save_image=False,
    )
    textract = boto3.client("textract")
    status = "IN_PROGRESS"
    while status == "IN_PROGRESS":
        response = textract.get_document_analysis(JobId=document.job_id)
        status = response["JobStatus"]
        time.sleep(1)
    if status == "FAILED":
        logger.error(f"Textract job failed for job id:{document.job_id}")
        return None
    return document.to_markdown()


def __clean_str(text: str):
    if text:
        return re.sub(r"\s+", " ", text.strip())
    else:
        return ""


# TODO add more tags as per commentary xml statistics
def convert_xml_section_to_markdown(xml_document: str, depth: int = 1) -> str:
    element = etree.fromstring(str(xml_document).strip())
    markdown = ""
    if element.tag in ["section", "subsection"]:
        section_name = element.attrib.get("name", "Section")
        markdown += f"{'#' * depth} {section_name}\n\n"
        if element.text:
            markdown += __clean_str(element.text) + "\n\n"
    elif element.tag in ["para", "#text"]:
        markdown += __clean_str(element.text) + "\n\n"
    elif element.tag == "list":
        list_type = element.attrib.get("type", "bullet")
        list_char = "-" if list_type == "bullet" else "1."
        for listitem in element.findall("listitem"):
            markdown += f"{list_char} {__clean_str(listitem.text)}\n"
    for child in element:
        markdown += convert_xml_section_to_markdown(child, depth + 1)

    return markdown
