import React from 'react';
import styled from '@emotion/styled';

export const ShowFeedbackTimeStyled = styled.div`
  display: flex;
  justify-content: right;
  font-size: var(--size-font-3);
`;

interface TimeProps {
  date: Date | null;
}

import { getLocalizedDate } from '../../../utils/dateLocalization';
import { useUserTraits } from '@spglobal/userprofileservice';

const ShowFeedbackTime: React.FC<TimeProps> = ({ date }) => {
  const userInformation = useUserTraits(['culture', 'mSTimeZoneID']);

  return (
    <>
      {date && (
        <ShowFeedbackTimeStyled>
          <span>As of: {getLocalizedDate(
            date,
            true,
            userInformation.culture,
            userInformation.mSTimeZoneID
              )}</span>
        </ShowFeedbackTimeStyled>
      )}
    </>
  );
};

export default ShowFeedbackTime;
