from dataclasses import dataclass, asdict, field
from typing import Any, Dict, List, Protocol
import json
import logging
import httpx
import xml.etree.ElementTree as ET
import uuid
from pydantic import BaseModel
from src.synthia.config.api_config import get_config
from src.synthia.tools.mcp_responses import DenimResponseType

class DenimRequest(Protocol):
    """Protocol for a request to be sent to the Denim API."""
    def to_json_string(self) -> str:
        ...

@dataclass
class CommonDenimRequest(DenimRequest):
    """Represents the data needed for a common denim request to the Denim API."""
    symbol: str
    metrics: List[str]
    period_start: str = None
    period_end: str = None
    filing_mode: str = None
    restatement_type: str = None
    target_currency: str = None
    currency_conversion_mode: str = None

    def to_json_string(self) -> str:
        """Serializes the request data into a JSON string for the CDATA block."""
        metric_requests = []
        for metric in self.metrics:
            request_dict = {
                "Symbol": self.symbol,
                "Metric": metric,
            }
            
            # Only add period if both start and end are provided and not None
            if self.period_start is not None and self.period_end is not None and self.period_start != "" and self.period_end != "":
                request_dict["period"] = {"start": self.period_start, "end": self.period_end}
            
            # Only add fields if they have valid values (not None and not empty string)
            if self.filing_mode is not None and self.filing_mode != "":
                request_dict["Filingmode"] = self.filing_mode
            if self.restatement_type is not None and self.restatement_type != "":
                request_dict["RestatementType"] = self.restatement_type
            if self.target_currency is not None and self.target_currency != "":
                request_dict["TargetCurrency"] = self.target_currency
            if self.currency_conversion_mode is not None and self.currency_conversion_mode != "":
                request_dict["CurrencyConversionMode"] = self.currency_conversion_mode
                
            metric_requests.append(request_dict)
        return json.dumps(metric_requests)

@dataclass
class SegmentDenimRequest(DenimRequest):
    """Represents the data needed for a common denim request to the Denim API."""
    symbol: str
    metrics: List[str]
    period: str
    filing_mode: str
    restatement_type: str
    target_currency: str
    currency_conversion_mode: str
    rank: str = None  # <-- Add this line

    def to_json_string(self) -> str:
        """Serializes the request data into a JSON string for the CDATA block."""
        metric_requests = []
        for metric in self.metrics:
            request_dict = {
                "Symbol": self.symbol,
                "Metric": metric,
                "period": self.period,
                "Filingmode": self.filing_mode,
                "RestatementType": self.restatement_type,
                "TargetCurrency": self.target_currency,
                "CurrencyConversionMode": self.currency_conversion_mode,
                "Rank": self.rank
            }
            metric_requests.append(request_dict)
        return json.dumps(metric_requests)

async def get_ciq_company_id(inst_id: str, auth_headers: dict, async_client: httpx.AsyncClient = None, logger: logging.Logger = None) -> str:
    """
    Retrieve the CIQCompanyId (company ID) for a given Inst ID.
    Args:
        inst_id (str): The Inst ID for which to fetch the company ID.
        auth_headers (dict): The authentication headers for the request.
        async_client (httpx.AsyncClient, optional): Optionally pass an existing AsyncClient for reuse.
        logger (logging.Logger, optional): Optionally pass a logger for logging.
    Returns:
        str: The CIQCompanyId, or None if not found or on error.
    """
    if logger is None:
        logger = logging.getLogger(__name__)
    cfg = get_config()
    capital_iq_base_url = cfg["capitaliq_base_url"]
    ciq_company_id_url_infix = "AIReportBuilder/companyDesc/"
    url = f"{capital_iq_base_url}{ciq_company_id_url_infix}{inst_id}"
    logger.info(f"[get_ciq_company_id] URL for CIQCompanyId: {url}")
    try:
        if async_client is None:
            async_client = httpx.AsyncClient(timeout=10)
        response = await async_client.get(url, headers=auth_headers)
        logger.info(f"[get_ciq_company_id] Response status code: {response.status_code}")
        if response.status_code == 200:
            response_data = response.json()
            ciq_company_id = response_data.get("CIQCompanyId")
            if ciq_company_id:
                return f"IQ{ciq_company_id}"
            else:
                logger.error(f"[get_ciq_company_id] CIQCompanyId not found in response: {response_data}")
                return None
        else:
            logger.error(f"[get_ciq_company_id] Error: {response.status_code} - {response.text}")
            return None
    except httpx.RequestError as e:
        logger.error(f"[get_ciq_company_id] Request failed: {e}")
        return None
    except Exception as e:
        logger.error(f"[get_ciq_company_id] Unexpected error: {e}", exc_info=True)
        return None

async def send_ciq_denim_request(
    token: str,
    email: str,
    request_data: DenimRequest,
    logger: logging.Logger = None
) -> List[DenimResponseType]:
    """
    Sends a request to the CIQ Denim SOAP endpoint and parses the response.
    Args:
        token (str): Bearer token for authorization.
        email (str): Username/email for the SOAP request.
        request_data (DenimRequest): Request object implementing to_json_string().
        logger (logging.Logger, optional): Optionally pass a logger for logging.
    Returns:
        List[DenimResponseType]: Parsed data rows from the SOAP response.
    """
    if logger is None:
        logger = logging.getLogger(__name__)
    cfg = get_config()
    denimURL = cfg["denim_url"]
    headers = {
        'SOAPAction': '"urn:schemas-microsoft-com:xml-analysis:Execute"',
        'Content-Type': 'text/xml;charset=UTF-8',
        'Authorization': f'Bearer {token}'
    }
    try:
        cdata_content = request_data.to_json_string()
        logger.info(f"Generated cdata_content for SOAP request: {cdata_content}")
        call_id = str(uuid.uuid4())
        correlation_id = str(uuid.uuid4())
        soap_body = f'''<SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/">
            <SOAP-ENV:Body>
                <Execute xmlns="urn:schemas-microsoft-com:xml-analysis">
                    <Command>
                        <Statement>
                            <![CDATA[{cdata_content}]]>
                        </Statement>
                    </Command>
                    <Properties>
                        <PropertyList>
                            <CallId>{call_id}</CallId>
                            <CorrelationId>{correlation_id}</CorrelationId>
                            <AppName>Synthia-CreditMemo</AppName>
                        <username>{email}</username>
                        </PropertyList>
                    </Properties>
                </Execute>
            </SOAP-ENV:Body>
        </SOAP-ENV:Envelope>'''
        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.post(denimURL, headers=headers, content=soap_body.encode('utf-8'))
            response.raise_for_status()
            raw_xml = response.text
        ns = {'rowset': 'urn:schemas-microsoft-com:xml-analysis:rowset'}
        root = ET.fromstring(raw_xml)
        
        r_elements = root.findall('.//rowset:r', ns)
        data = []
        for r_element in r_elements:
            row = {}
            for header in DenimResponseType.model_fields.keys():
                child = r_element.find(f'rowset:{header}', ns)
                row[header] = child.text if child is not None else None
            data.append(DenimResponseType(**row))
        return data
    except httpx.RequestError as e:
        logger.error(f"[send_ciq_denim_request] Request failed: {e}")
        return []
    except ET.ParseError as e:
        logger.error(f"[send_ciq_denim_request] XML Parse error: {e}")
        return []
    except Exception as e:
        logger.error(f"[send_ciq_denim_request] Unexpected error: {e}", exc_info=True)
        return []
