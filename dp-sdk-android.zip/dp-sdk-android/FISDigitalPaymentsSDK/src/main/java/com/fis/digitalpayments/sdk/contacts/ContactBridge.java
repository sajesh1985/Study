// Copyright Notice!
// This document is protected under the trade secret and copyright
// laws as the property of Fidelity National Information Services, Inc.
// Copying, reproduction or distribution should be limited and only to
// employees with a “need to know” to do their job.
// Any disclosure of this document to third parties is strictly prohibited.
// © 2016 Fidelity National Information Services.
// All rights reserved worldwide.

package com.fis.digitalpayments.sdk.contacts;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.ResultReceiver;

import com.fis.digitalpayments.sdk.core.Bridge;
import com.fis.digitalpayments.sdk.core.BridgeException;
import com.fis.digitalpayments.sdk.core.BridgeMessage;
import com.fis.digitalpayments.sdk.core.BridgeRequest;
import com.fis.digitalpayments.sdk.core.BridgeRequestCallback;
import com.fis.digitalpayments.sdk.core.BridgeResponse;
import com.fis.digitalpayments.sdk.core.BridgeMessageCode;
import com.fis.digitalpayments.sdk.core.RestrictedOperation;

import org.json.JSONObject;

/**
 * Handles all requests to the contacts API>
 */
public class ContactBridge extends Bridge {

    private ContactProvider mContactProvider;
    private boolean mIsDisclosureEnabled;

    public ContactBridge(boolean isDisclosureEnabled) {
        super();
        mIsDisclosureEnabled = isDisclosureEnabled;
    }

    @Override
    public String getBridgeId() {
        return "deviceContactBridge";
    }

    @Override
    public void handleRequest(final BridgeRequest bridgeRequest, final BridgeRequestCallback bridgeRequestCallback, final Context context) {
        switch (bridgeRequest.getMethod()) {
            case "getContacts":
                RestrictedOperation getContacts = new RestrictedOperation(bridgeRequest, bridgeRequestCallback) {
                    @Override
                    public void onPermissionGranted() {
                        createContactsResponse(bridgeRequest, bridgeRequestCallback, context);
                    }
                };
                executeWithPermission(Manifest.permission.READ_CONTACTS, getContacts, context, mIsDisclosureEnabled);
                break;
            case "pickContact":
                RestrictedOperation pickContact = new RestrictedOperation(bridgeRequest, bridgeRequestCallback) {
                    @Override
                    public void onPermissionGranted() {
                        Intent intent = new Intent(context, PickContactActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

                        intent.putExtra(PickContactActivity.PICK_CONTACT_RESULT_RECEIVER_NAME, new ResultReceiver(new Handler()) {
                            @Override
                            protected void onReceiveResult(int resultCode, final Bundle resultData) {
                                Uri contactUri = PickContactActivity.getContactUriFromBundle(resultData);
                                createContactResponse(bridgeRequest, bridgeRequestCallback, contactUri, context);
                            }
                        });
                        context.startActivity(intent);
                    }
                };
                executeWithPermission(Manifest.permission.READ_CONTACTS, pickContact, context, mIsDisclosureEnabled);
                break;
        }
    }

    private void createContactsResponse(final BridgeRequest bridgeRequest, final BridgeRequestCallback bridgeRequestCallback, final Context context) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                if (mContactProvider == null) {
                    mContactProvider = new ContactProvider();
                }

                BridgeResponse bridgeResponse;
                try {
                    JSONObject contactData = mContactProvider.getContacts(context);
                    bridgeResponse = new BridgeResponse(bridgeRequest.getCallbackMethod(), contactData, bridgeRequest.getCallbackKey());
                } catch (BridgeException e) {
                    BridgeMessage bridgeMessage = BridgeMessage.CreateError(BridgeMessageCode.BRIDGE_EXECUTION_FAILED, e.getMessage());
                    bridgeResponse = new BridgeResponse(bridgeRequest.getCallbackMethod(), null, null, bridgeRequest.getCallbackKey(), false, bridgeMessage);
                }

                bridgeRequestCallback.onRequestComplete(bridgeResponse);
            }
        }).start();
    }

    private void createContactResponse(final BridgeRequest bridgeRequest, final BridgeRequestCallback bridgeRequestCallback, final Uri contactUri, final Context context) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                if (mContactProvider == null) {
                    mContactProvider = new ContactProvider();
                }

                BridgeResponse bridgeResponse;
                try {
                    JSONObject contactData = mContactProvider.getContact(contactUri, context);
                    bridgeResponse = new BridgeResponse(bridgeRequest.getCallbackMethod(), contactData, bridgeRequest.getCallbackKey());
                } catch (BridgeException e) {
                    BridgeMessage bridgeMessage = BridgeMessage.CreateError(BridgeMessageCode.BRIDGE_EXECUTION_FAILED, e.getMessage());
                    bridgeResponse = new BridgeResponse(bridgeRequest.getCallbackMethod(), null, null, bridgeRequest.getCallbackKey(), false, bridgeMessage);
                }

                bridgeRequestCallback.onRequestComplete(bridgeResponse);
            }
        }).start();
    }
}
