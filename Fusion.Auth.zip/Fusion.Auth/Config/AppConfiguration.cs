﻿// Copyright Notice! 
// This document is protected under the trade secret and copyright 
// laws as the property of Fidelity National Information Services, Inc. 
// Copying, reproduction or distribution should be limited and only to 
// employees with a “need to know” to do their job. 
// Any disclosure of this document to third parties is strictly prohibited.
// © 2018 Fidelity National Information Services.
// All rights reserved worldwide.

namespace Fis.Epp.Fusion.Auth
{
    using Fis.Epp.Fusion.Auth.Common;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    public class AppConfiguration : IValidatable
    {
        [Required]
        public int SessionTimeout { get; set; }

        [Required]
        public int HttpClientTimeOut { get; set; }

        [Required]
        public bool EnableDebugAccess { get; set; }

        [Required]
        public string _TokenSigningKey;

        [ValidateField]
        public string TokenSigningKey
        {
            get { return _TokenSigningKey; }
            set
            {
                _TokenSigningKey = EncryptDecryptHelper.DecryptStringFromBytes_Aes(value);
            }
        }

        [Required]
        public string _ContextTokenSecretKey;

        [ValidateField]
        public string ContextTokenSecretKey
        {
            get { return _ContextTokenSecretKey; }
            set
            {
                _ContextTokenSecretKey = EncryptDecryptHelper.DecryptStringFromBytes_Aes(value);
            }
        }

        //[Required]
        //public string CorsAllowedOrigins { get; set; }

        //[Required]
        //public string CorsAllowedMethods { get; set; }

        //[Required]
        //public string CorsAllowedHeaders { get; set; }

        [ValidateObject]
        public CorsPolicy CorsPolicies { get; set; }

        [ValidateObject]
        public CodeConnectApi CodeConnectApis { get; set; }

        [ValidateObject]
        public RestEndpoint RestEndpoints { get; set; }

        [ValidateObject]
        public CodeConnectHeader CodeConnectHeaders { get; set; }

        public void Validate()
        {
            var results = new List<ValidationResult>();
            var isValid = Validator.TryValidateObject(this, new ValidationContext(this), results, true);
            if (!isValid)
            {
                var sb = new System.Text.StringBuilder();
                sb.AppendLine();
                foreach (ValidationResult res in results)
                {
                    sb.AppendLine(res.ErrorMessage.ToString());
                }
                throw new ValidationException(String.Format("Application configuration validation failed. {0}", sb.ToString()));
            }
        }

        #region Nested Class
        public class CorsPolicy
        {
            [Required]
            public bool Enable { get; set; }
            [ValidateField]
            public string CorsAllowedOrigins { get; set; }
            [ValidateField]
            public string CorsAllowedMethods { get; set; }
            [ValidateField]
            public string CorsAllowedHeaders { get; set; }
        }
        public class CodeConnectApi
        {
            [Required]
            public int TokenValidityPeriod { get; set; }

            [Required]
            public string _AuthorizationCode;
            [ValidateField]
            public string AuthorizationCode
            {
                get { return _AuthorizationCode; }
                set
                {
                    _AuthorizationCode = EncryptDecryptHelper.DecryptStringFromBytes_Aes(value);
                }
            }
            [ValidateField]
            public CodeConnectApiEndpoints Endpoints { get; set; }
        }

        public class CodeConnectApiEndpoints
        {
            [Url]
            public string GetToken { get; set; }

            [Url]
            public string RevokeToken { get; set; }
        }

        public class RestEndpoint
        {
            [Url]
            public string AuditSignOn { get; set; }

            [Url]
            public string GetContextToken { get; set; }

            [Url]
            public string RevokeContextToken { get; set; }

            [Url]
            public string RefreshContextToken { get; set; }
        }

        public class CodeConnectHeader
        {
            [ValidateField]
            public Dictionary<string, string> Environment_Id { get; set; }
        }

        public class Environment
        {
            [Required]
            public string SecurityServiceSuite { get; set; }
        }

        #endregion

    }
}
