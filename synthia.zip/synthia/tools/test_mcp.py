#Testing ground for any framework changes for MCPs
from mcp.server.fastmcp import FastMCP
from fastapi import FastAPI, APIRouter
import logging
import httpx
from contextlib import asynccontextmanager
import contextlib

from mangum import Mangum
from src.synthia.utils.logging_config import configure_logging


# Configure logging
logger = configure_logging(logger_name=__name__, log_file='test_mcp.log')
logger.info("test mcp MCP Server starting up...")


mcp: FastMCP = FastMCP("test mcp MCP", stateless_http=True)
router = APIRouter()
cfg = None
async_client: httpx.AsyncClient = None  # Keep the single global declaration
KENSHO_ACCESS_TOKEN = None


def get_config_instance():
    global cfg
    if cfg is None:
        from src.synthia.config.api_config import get_config
        cfg = get_config()
    return cfg

async def get_async_client():
    global async_client
    if async_client is None:
        async_client = httpx.AsyncClient(timeout=10)
    return async_client

cfg = get_config_instance()



# @asynccontextmanager
# async def lifespan(app: FastAPI):
#     logger.info("Initializing Grounding MCP server task group...")
#     global async_client
#     async_client = httpx.AsyncClient(timeout=10)
#     async with contextlib.AsyncExitStack() as stack:
#         await stack.enter_async_context(mcp.session_manager.run())
#         yield
#     await async_client.aclose()

@mcp.tool()
async def get_data(query: str) -> str:
    async_client = await get_async_client()
    return f"ok - {query}"

@router.get("/test-mcp/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "ok"}

# Create FastAPI app factory and Mangum handler (for AWS Lambda)
def create_app() -> FastAPI:
    app = FastAPI()
    app.mount("/test_mcp", mcp.streamable_http_app())
    app.include_router(router)
    return app

app = create_app()

# Enable lifespan handling in Lambda. Optionally respect a base path if needed.
handler = Mangum(app, lifespan="off")
lambda_handler = handler  # Optional alias for some Lambda configurations

logger.info("test mcp MCP Server started successfully.")
# Run locally with Uvicorn using the ASGI app, not the Lambda handler:
# uvicorn src.synthia.tools.test_mcp:app --host 0.0.0.0 --port 8222 --reload