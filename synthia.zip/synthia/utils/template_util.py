import os
from typing import Dict, List
from dotenv import load_dotenv
from pathlib import Path
import yaml
import logging
import asyncio
from src.synthia.schemas.template import Template, TemplateSection
from src.synthia.aws_utils.aws_client import get_aws_client
from src.synthia.config.api_config import get_config
from src.synthia.utils.logging_config import configure_logging
from botocore.exceptions import ClientError

load_dotenv(override=True)

# Configure logging
logger = configure_logging(logger_name=__name__, log_file='template_util.log')
logger.setLevel(logging.INFO)

# Suppress noisy AWS/S3 related logging
logging.getLogger("urllib3").setLevel(logging.WARNING)
logging.getLogger("botocore").setLevel(logging.WARNING)
logging.getLogger("boto3").setLevel(logging.WARNING)

# support Linux & Windows paths
DEFAULT_TEMPLATES_DIR = Path(__file__).parent.parent / "resources" / "templates"
TEMPLATES_DIR = DEFAULT_TEMPLATES_DIR


async def load_all_templates(s3_template_prefix: str = None) -> Dict[str, Template]:
    templates = {}
    config = get_config()
    
    # Check environment variable first, then fall back to config
    use_s3_env = os.getenv("USE_S3_TEMPLATES", "").lower()
    if use_s3_env:
        use_s3 = use_s3_env in {"true", "1", "yes"}
        logger.info(f"Using {'S3' if use_s3 else 'local'} templates (overridden by USE_S3_TEMPLATES environment variable)")
    else:
        use_s3 = config.get("use_s3_templates", False)
    
    if use_s3:
        # Use provided prefix or fall back to default
        s3_templates_prefix = s3_template_prefix if s3_template_prefix is not None else config.get("s3_templates_prefix_default", "system/")
        s3_templates_bucket = config.get("templates_s3_bucket", "creditmemo-templates-dev.us-east-1.cm-tl ")
        
        # Load from S3
        try:
            s3_client = get_aws_client("s3")
            # Run the S3 operations in a thread pool to avoid blocking
            loop = asyncio.get_event_loop()
            
            response = await loop.run_in_executor(
                None, 
                lambda: s3_client.list_objects_v2(
                    Bucket=s3_templates_bucket,
                    Prefix=s3_templates_prefix
                )
            )
            
            for obj in response.get('Contents', []):
                key = obj['Key']
                if key.endswith(('.yaml', '.yml')):
                    filename = key.replace(s3_templates_prefix, '')
                    try:
                        # Load template from S3 asynchronously
                        template_response = await loop.run_in_executor(
                            None,
                            lambda: s3_client.get_object(Bucket=s3_templates_bucket, Key=key)
                        )
                        template_content = template_response['Body'].read().decode('utf-8')
                        template_data = yaml.safe_load(template_content)
                        templates[filename] = Template(**template_data)
                        logger.info(f"Loaded template {filename} from S3 (prefix: {s3_templates_prefix})")
                    except Exception as e:
                        logger.error(f"Error loading template {filename} from S3: {e}")
                        
        except Exception as e:
            logger.error(f"Error accessing S3 templates: {e}")
            # Fall back to local loading
            use_s3 = False
    
    # Load from local filesystem (either as primary or fallback)
    if not use_s3:
        try:
            # Run file system operations in thread pool
            loop = asyncio.get_event_loop()
            filenames = await loop.run_in_executor(None, os.listdir, TEMPLATES_DIR)
            
            for filename in filenames:
                if filename.endswith(".yaml") or filename.endswith(".yml"):
                    path = os.path.join(TEMPLATES_DIR, filename)
                    
                    # Read file asynchronously
                    def read_template_file(file_path):
                        with open(file_path, "r", encoding="utf-8") as f:
                            return yaml.safe_load(f)
                    
                    template_data = await loop.run_in_executor(None, read_template_file, path)
                    templates[filename] = Template(**template_data)
                    logger.info(f"Loaded template {filename} from local")
        except Exception as e:
            logger.error(f"Error loading templates from local filesystem: {e}")
        
    return templates

def _normalize_template_name(template_name: str) -> str:
    """
    Normalize template name to ensure it has .yaml extension.
    Handles cases where template_name might be passed with or without extension.
    """
    if not template_name:
        return ""
    
    # Remove any existing extension and add .yaml
    base_name = template_name
    if template_name.endswith(('.yaml', '.yml', '.json')):
        base_name = template_name.rsplit('.', 1)[0]
    
    return f"{base_name}.yaml"

async def get_sections(template_name: str, s3_template_prefix: str = None) -> List[TemplateSection]:
    """
    Returns a list of logical section objects (top-level sections).
    """
    normalized_name = _normalize_template_name(template_name)
    templates = await load_all_templates(s3_template_prefix)
    template = templates.get(normalized_name)
    if not template:
        return []
    return template.sections

async def get_subsections(template_name: str, section_title: str, s3_template_prefix: str = None) -> List[TemplateSection]:
    """
    Returns a list of child section objects for a given logical section title.
    """
    normalized_name = _normalize_template_name(template_name)
    templates = await load_all_templates(s3_template_prefix)
    template = templates.get(normalized_name)
    if not template:
        return []
    for section in template.sections:
        if section.section_title.strip().lower() == section_title.strip().lower():
            return section.sections
    return []

async def get_subsection_by_title(template_name: str, section_title: str, subsection_title: str, s3_template_prefix: str = None) -> TemplateSection:
    """
    Returns the child section object for a given section title within a logical section.
    """
    normalized_name = _normalize_template_name(template_name)
    subsections = await get_subsections(normalized_name, section_title, s3_template_prefix)
    for subsection in subsections:
        if subsection.section_title.strip().lower() == subsection_title.strip().lower():
            return subsection
    return TemplateSection(section_title="", description="", prompt="", tools=[])

async def get_tools_for_subsection(template_name: str, section_title: str, subsection_title: str, s3_template_prefix: str = None) -> List[str]:
    """
    Returns the tools for a given child section title within a logical section.
    """
    normalized_name = _normalize_template_name(template_name)
    subsection = await get_subsection_by_title(normalized_name, section_title, subsection_title, s3_template_prefix)
    return subsection.tools

async def get_template_prompt(template_name: str, s3_template_prefix: str = None) -> str:
 
    normalized_name = _normalize_template_name(template_name)
    templates = await load_all_templates(s3_template_prefix)
    template = templates.get(normalized_name)
    if template:
        return template.template_prompt
    return ""

async def load_section_options(template: str, s3_template_prefix: str = None) -> List[str]:
    """
    Returns a list of all logical section titles for the given template.
    """
    normalized_name = _normalize_template_name(template)
    sections = await get_sections(normalized_name, s3_template_prefix)
    return [section.section_title for section in sections]

async def get_system_prompt_for_subsection(subsection_title: str, section_title: str, template_filename: str, s3_template_prefix: str = None) -> str:
    """
    Returns the system prompt for a given child section title from the specified logical section in the template YAML file.
    """
    normalized_name = _normalize_template_name(template_filename)
    subsection = await get_subsection_by_title(normalized_name, section_title, subsection_title, s3_template_prefix)
    return subsection.prompt

async def get_system_prompt_for_section(section_title: str, template_name: str = "", s3_template_prefix: str = None) -> str:
    """
    Returns a generic system prompt for a section when no template is specified,
    or searches across all sections in the template for a matching section title.
    """
    if not template_name:
        # Generic fallback prompt when no template is specified
        return f"You are an expert analyst tasked with generating comprehensive content for the '{section_title}' section. Use available tools to gather relevant information and provide detailed analysis."
    
    normalized_name = _normalize_template_name(template_name)
    templates = await load_all_templates(s3_template_prefix)
    template = templates.get(normalized_name)
    if not template:
        return f"You are an expert analyst tasked with generating comprehensive content for the '{section_title}' section. Use available tools to gather relevant information and provide detailed analysis."
    
    # Search through all sections and subsections for matching title
    for section in template.sections:
        # Check if the main section title matches
        if section.section_title.strip().lower() == section_title.strip().lower():
            return section.prompt or f"Generate comprehensive content for the '{section_title}' section."
        
        # Check subsections
        for subsection in section.sections:
            if subsection.section_title.strip().lower() == section_title.strip().lower():
                return subsection.prompt or f"Generate comprehensive content for the '{section_title}' section."
    
    # Fallback if no matching section found
    return f"Generate comprehensive content for the '{section_title}' section using available tools and data."

async def get_tools_for_section(template_name: str, section_title: str, s3_template_prefix: str = None) -> List[str]:
    """
    Returns all tools for a given section, combining tools from the section and all its subsections.
   """
    normalized_name = _normalize_template_name(template_name)
    templates = await load_all_templates(s3_template_prefix)
    template = templates.get(normalized_name)
    if not template:
        return []
    
    all_tools = []
    
    # Search through all sections for matching title
    for section in template.sections:
        if section.section_title.strip().lower() == section_title.strip().lower():
            # Add tools from the main section
            if section.tools:
                all_tools.extend(section.tools)
            
            # Add tools from all subsections
            for subsection in section.sections:
                if subsection.tools:
                    all_tools.extend(subsection.tools)
            break
    
    return list(set(all_tools))  # Remove duplicates

def should_cache_section_llm(section_name: str) -> bool:
    """
    Determines whether to use cached LLM for a given section.
    Add logic here to determine which sections should use caching.
    """
    # Define sections that benefit from caching (e.g., frequently accessed or computationally expensive)
    cache_sections = {
        "executive summary",
        "financial analysis", 
        "market analysis",
        "risk assessment",
        "competitive analysis",
        "company overview"
    }
    
    return section_name.lower().strip() in cache_sections




