from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field


class ArticleTypes(Enum):
    TYPE_FULL = "full"
    TYPE_OTHER = ""


class ArticleTypeValues(BaseModel):
    ArticleType: Optional[ArticleTypes] = Field(
        default="",
        description="What article type is mentioned in the question?",
    )


ARTICLE_TYPE_EXTRACTOR_OUTPUT_PARSER_TEMPLATE = """Your goal is to retrieve information about the article or analysis type the question concerns:
- full analysis
- other (including the case if it's not specified, e.g. "latest research", "research reports", "latest news", "latest article", "ratings research", etc.).

This information is to be output only when mentioned in the question. Format the output following these guidelines:
{format_instructions}

Do not add anything other than the defined JSON schema. Do not explain to me that this is the JSON output I requested. Do not justify your answer. Provide only the JSON.

It needs to be explicitely specified, that the question pertains to full analysis article. If other type is mentioned or it is not specified, set ArticleType to "" (empty string). 

Apply the instructions to this question:
{question}
"""
