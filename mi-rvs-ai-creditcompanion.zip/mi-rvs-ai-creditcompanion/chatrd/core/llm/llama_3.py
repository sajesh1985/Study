from typing import Any

from chatrd.core.llm.components import LanguageModelInput
from chatrd.core.llm.models import Bedrock


def get_llama3_aligned_prompt(prompt: str):
    new_prompt = f"""<|begin_of_text|><|start_header_id|>user<|end_header_id|>\n\n{prompt}<|eot_id|><|start_header_id|>assistant<|end_header_id|>\n\n"""
    return new_prompt


class Llama3Bedrock(Bedrock):
    def invoke(self, inputs: LanguageModelInput, **kwargs: Any) -> str:
        updated_prompt = get_llama3_aligned_prompt(inputs)
        response = super().invoke(updated_prompt, **kwargs)
        return response

    def stream(self, inputs: LanguageModelInput, **kwargs: Any) -> str:
        updated_prompt = get_llama3_aligned_prompt(inputs)
        response = super().stream(updated_prompt, **kwargs)
        return response
