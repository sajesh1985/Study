import logging
from typing import Dict, List, Tuple

from chatrd.engine.configuration import Constants, get_config_machinery

logger = logging.getLogger(__name__)
config_machinery = get_config_machinery()


def rename_columns_only(data):
    """
    Only renames Country/Company columns to column format without any URL processing.

    Args:
        data (list): List of dictionaries containing data

    Returns:
        list: Modified data with renamed columns
    """
    modified_data = []

    for item in data:
        new_item = item.copy()
        column_count = 1
        for key, value in list(new_item.items()):
            if "Country" in key or "Company" in key:
                new_key = f"column{column_count}"
                new_item[new_key] = value
                del new_item[key]
                column_count += 1

        modified_data.append(new_item)

    return modified_data


def process_company_urls(data, sector):
    """
    Process company data with URL transformations.
    Args:
        data (list): List of dictionaries containing company data
        sector (str): Sector code for URL generation
        environment (str): Environment to use for URLs ('dev', 'staging', or 'prod')

    Returns:
        list: Modified data with URLs
    """
    modified_data = []

    sourcing_base_url = config_machinery.get_config_value(Constants.SourceGeneration.BASE_URL)
    footnote_url_slug = config_machinery.get_config_value(Constants.SourceGeneration.FOOTNOTE_URL_SLUG)
    base_url = sourcing_base_url + footnote_url_slug
    sector_urls = {
        "FI": "#company/financialhighlightsFI?id=",
        "INS": "#company/insuranceData?id=",
        "CORP": "#company/csd?Id=",
    }
    url_add = sector_urls.get(sector, "#company/csd?Id=")

    for item in data:
        new_item = item.copy()
        mnemonic = item.get("MnemonicName", "")
        mnemonic = "" if mnemonic is None else mnemonic.upper()

        if mnemonic == "RATINGS & SCORES" or mnemonic == "RATINGS & FACTORS":
            for key, value in item.items():
                if key.startswith("column") and value not in [None, ""]:
                    new_item[key] = (
                        f'<a href="{base_url}?auth=inherit#company/profile?id={value}" target="_blank">viewprofile</a>'
                    )

                elif key.startswith("column"):
                    new_item[key] = ""

        elif mnemonic == "OUTLOOK" and item.get("DataField") == "ArticleId":
            for key, value in item.items():
                if key.startswith("column") and value not in [None, ""]:
                    new_item[key] = (
                        f'<a href="{base_url}?auth=inherit#ratingsdirect/creditResearch?rid={value}" target="_blank">View Article</a>'
                    )

                elif key.startswith("column"):
                    new_item[key] = ""

        elif mnemonic == "FINANCIAL HIGHLIGHTS" or mnemonic == "FINANCIAL HIGHLIGHTS(ADJUSTED)":
            for key, value in item.items():
                if key.startswith("column") and value not in [None, ""]:
                    sourcing_url = f"{base_url}?auth=inherit{url_add}{value}"
                    new_item[key] = f'<a href="{sourcing_url}" target="_blank">View CreditStats Direct®</a>'
                elif key.startswith("column"):
                    new_item[key] = ""

        modified_data.append(new_item)

    return modified_data


def reformat_items(
    processed_data: List[Dict],
    fields: List[str] = [
        "Id",
        "ParentId",
        "MnemonicName",
        "MnemonicClass",
        "ChartFlag",
        "DataField",
        "ProductDefinition",
    ],
):
    for item in processed_data:
        fixed_fields = {key: item[key] for key in fields if key in item}
        columns = {
            f"Column{i+1}": item.get(f"column{i+1}") for i in range(len([key for key in item if "column" in key]))
        }
        reformatted_item = {**fixed_fields, **columns}
        item.clear()
        item.update(reformatted_item)
    return processed_data


def source_description(rd_subsector: str, country_id: str, entity_id: str, entity_name: str) -> List[Tuple[str, str]]:
    """
    Generates a source description URL for an entity based on its subsector.

    Args:
        rd_subsector (str): The subsector code of the entity.
        country_id (str): The country ID (used if rd_subsector == "SOV").
        entity_id (str): The entity ID (used otherwise).
        entity_name (str): The name of the entity.

    Returns:
        List[Tuple[str, str]]: A list containing the source description.
    """
    try:
        query_param = (
            "#ratingsdirect/country/analystpeers?keycountry="
            if rd_subsector == "SOV"
            else "#ratingsDirect/company/analystpeers?id="
        )
        key_value = country_id if rd_subsector == "SOV" else entity_id

        sourcing_base_url = config_machinery.get_config_value(Constants.SourceGeneration.BASE_URL)
        footnote_url_slug = config_machinery.get_config_value(Constants.SourceGeneration.FOOTNOTE_URL_SLUG)
        source_description_url = [
            (
                f"{entity_name} | ANALYST PEERS",
                sourcing_base_url + footnote_url_slug + query_param + key_value,
            )
        ]
        return source_description_url

    except Exception as e:
        logger.error(
            f"Failed to generate source description for entity '{entity_name}' "
            f"(ID: {entity_id}, Subsector: {rd_subsector}). Error: {e}"
        )
        return [(f"{entity_name} | ANALYST PEERS", "")]


def process_response_data_company(response: dict):

    response_sector = response["SubSector"]
    response_data = response["CompanyAnalystRatingsPeerResult"]["CompanyAnalystPeerRatingMnemonicsList"]
    renamed_data = rename_columns_only(response_data)  # renaming field names from company to column
    company_processed_data = process_company_urls(renamed_data, response_sector)  # converting mid_ids to urls
    # Call the refactored function
    reformat_items(company_processed_data)

    return company_processed_data


def process_response_data_country(response: dict):
    response_data = response["CountryAnalystRatingsPeerResult"]["CountryAnalystPeerRatingMnemonicsList"]
    renamed_data = rename_columns_only(response_data)  # renaming field names from country to columns
    country_processed_data = modify_country_url(renamed_data)

    # call the refactored function
    reformat_items(country_processed_data)

    return country_processed_data


def modify_country_url(data):
    base_url = "/web/client?auth=inheritt"

    for item in data:
        new_item = item.copy()
        mnemonic = item.get("MnemonicName", "")
        mnemonic = "" if mnemonic is None else mnemonic.upper()

        if mnemonic == "RATINGS & SCORES" or mnemonic == "RATINGS & FACTORS":
            for key, value in item.items():
                if key.startswith("column") and value not in [None, ""]:
                    new_href = f"href='{base_url}#company/profile?id="
                    country_id = value.split("company/profile?Id=")[-1].split(">")[0]
                    new_item[key] = f"<a target='_blank' {new_href}{country_id}'>View Profile</a>"
                elif key.startswith("column"):
                    new_item[key] = ""

        elif mnemonic == "SOVEREIGN RISK":
            for key, value in item.items():
                if key.startswith("column") and value not in [None, ""]:
                    if key.startswith("column") and value not in [None, ""]:
                        new_href = f"href='{base_url}#ratingsdirect/country/sovereignresearch?countryname="
                        country_code = value.split("countryname=")[-1].split(">")[0]
                        new_item[key] = f"<a target='_blank' {new_href}{country_code}'>View More</a>"
                elif key.startswith("column"):
                    new_item[key] = ""

        elif mnemonic == "ECONOMIC CONDITIONS":
            for key, value in item.items():
                if key.startswith("column") and value not in [None, ""]:
                    country_code = value.split("countryname=")[-1].split(">")[0]
                    new_href = f"href='{base_url}#ratingsdirect/country/sovereignresearch?countryname={country_code}"
                    new_item[key] = f"<a target='_blank' {new_href}'>View More</a>"
                elif key.startswith("column"):
                    new_item[key] = ""
        item.update(new_item)

    return data
