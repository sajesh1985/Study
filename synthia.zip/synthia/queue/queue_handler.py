import logging
from typing import Dict
from src.synthia.persistence.report_monitor import get_monitor
from src.synthia.persistence.prompt_monitor import get_prompt_monitor
from src.synthia.schemas.workflow import PromptStatusEnum
from src.synthia.utils.logging_config import configure_logging
from src.synthia.utils.logging_context import set_job_id_logging_context, set_prompt_id_logging_context
from src.synthia.workflows.workflow_helper import ReportWorkflow
from decimal import Decimal
from datetime import datetime


logger = configure_logging(logger_name=__name__)


async def handle_generate_report(payload: Dict) -> None:
    job_id = payload["job_id"]
    set_job_id_logging_context(job_id)
    logger.info("Starting generate_report handler for job_id=%s", job_id)
    refresh_token = payload["refresh_token"]
    logger.info(f"Obtained refresh token :: {str(refresh_token)[:50]}")
    token = payload["token"]
    logger.info("Handling generate_report job=%s", job_id)

    status_tracker = get_monitor(token)
    report_status = await status_tracker.get_job(job_id)
    if not report_status:
        raise ValueError(f"Job {job_id} not found in database")

    config = dict(report_status.report_config)
    config["outline_only"] = True
    config["auth_token"] = token
    config["refresh_token"] = refresh_token

    workflow = await ReportWorkflow.create_workflow(config, status_tracker=status_tracker)
    await workflow.start_workflow(status_tracker)


async def handle_outline_approval(payload: Dict) -> None:
    job_id = payload["job_id"]
    set_job_id_logging_context(job_id)
    logger.info("Starting outline approval handler for job_id=%s", job_id)
    approved = payload["approved"]
    refresh_token = payload["refresh_token"]
    token = payload["token"]
    logger.info(f"Obtained refresh token :: {str(refresh_token)[:50]}")
    logger.info("Handling outline approval job=%s approved=%s", job_id, approved)

    status_tracker = get_monitor(token)
    report_status = await status_tracker.get_job(job_id)
    if not report_status:
        raise ValueError(f"Job {job_id} not found in database")

    config = dict(report_status.report_config)
    config["job_id"] = job_id
    config["auth_token"] = token
    config["refresh_token"] = refresh_token

    if approved:
        config["approved_outline"] = report_status.outline
        workflow = await ReportWorkflow.create_workflow(config, status_tracker=status_tracker)
        await workflow.resume_workflow(user_input=True, approved=True, status_tracker=status_tracker)
    else:
        if payload.get("revised_sections") is not None:
            config["num_sections"] = int(payload["revised_sections"])
        if payload.get("revised_depth") is not None:
            config["depth"] = int(payload["revised_depth"])
        if payload.get("user_sections") is not None:        # <-- added
            config["user_sections"] = payload["user_sections"]

        workflow = await ReportWorkflow.create_workflow(config, status_tracker=status_tracker)
        await workflow.resume_workflow(user_input=False, approved=False, status_tracker=status_tracker)

async def handle_section_edit_prompt(payload: Dict) -> None:
    job_id = payload["job_id"]
    set_job_id_logging_context(job_id)
    set_prompt_id_logging_context(payload.get("prompt_id"))
    logger.info("Starting section edit prompt handler for job_id=%s", job_id)
    request = payload.get("request", {})
    section_name = request.get("section_name")
    token = payload.get("token")

    logger.info("Handling section edit prompt job=%s section=%s", job_id, section_name)

    status_tracker = get_monitor(token)
    report_status = await status_tracker.get_job(job_id)
    if not report_status:
        raise ValueError(f"Job {job_id} not found in database")

    config = dict(report_status.report_config)
    config["job_id"] = job_id
    config["auth_token"] = token

    prompt_monitor = get_prompt_monitor(token)
    workflow = await ReportWorkflow.create_workflow(config, status_tracker=status_tracker)
    
    # Pass the request dict to section_edit
    await workflow.section_edit(user_input=request, prompt_monitor=prompt_monitor)

async def handle_section_edit_approval(payload: Dict) -> None:
    job_id = payload["job_id"]
    prompt_id = payload["prompt_id"]
    set_job_id_logging_context(job_id)
    set_prompt_id_logging_context(prompt_id)
    status_value = payload["status"]
    token = payload["token"]

    logger.info("Handling section edit approval job=%s prompt=%s status=%s", job_id, prompt_id, status_value)

    status_tracker = get_monitor(token)
    if not await status_tracker.job_exists(job_id):
        raise ValueError(f"Job {job_id} not found in database")

    prompt_monitor = get_prompt_monitor(token)
    prompt_edit = await prompt_monitor.get_prompt_edit(prompt_id, job_id)
    if not prompt_edit:
        raise ValueError(f"Prompt edit {prompt_id} not found for job {job_id}")

    # Validate status is a valid PromptStatusEnum value
    try:
        status_enum = PromptStatusEnum(status_value)
    except ValueError:
        raise ValueError(f"Invalid status value: {status_value}")

    # Get report config and create workflow
    report_status = await status_tracker.get_job(job_id)
    if not report_status:
        raise ValueError(f"Job {job_id} not found in database")

    config = dict(report_status.report_config)
    config["job_id"] = job_id
    config["auth_token"] = token

    workflow = await ReportWorkflow.create_workflow(config, status_tracker=status_tracker)
    
    # Call the section_edit_approval method with prompt_monitor
    result = await workflow.section_edit_approval(
        prompt_id=prompt_id,
        status_enum=status_enum,
        prompt_monitor=prompt_monitor,
        status_tracker=status_tracker
    )
    
    logger.info("Section edit approval handled: %s", result)

ACTION_HANDLERS = {
    "generate_report": handle_generate_report,
    "process_outline_approval": handle_outline_approval,
    "process_section_edit_prompt": handle_section_edit_prompt,
    "process_section_edit_approval": handle_section_edit_approval,
}
