import logging
import re
from datetime import date, datetime

logger = logging.getLogger(__name__)


def contains_a_tag(text: str):
    # Regular expression to match <a> tags
    if bool(re.search(r"<a\s+.*?>.*?</a>", text)):
        return text
    else:
        return text.replace(":", "\:").replace("$", "\$").replace("\n", "  \n")


def convert_date_string(input_date: str) -> str:
    """
    Method courtesy of chat-gpt, convert date in formt 2023-01-01 into January 1st, 2023.
    Args:
        input_date: date in format yyyy-mm-dd

    Returns: date in  format January 1st, 2023

    """
    try:
        # Convert string to datetime object
        if isinstance(input_date, date):
            date_object = input_date
        else:
            date_object = datetime.strptime(input_date, "%Y-%m-%d")
        # Format the datetime object as desired
        formatted_date = date_object.strftime("%B %d, %Y")
        return formatted_date
    except Exception as e:
        print(e)
        logger.info("Got an exception in {convert_date_string} function")
        return input_date
