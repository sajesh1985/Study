﻿// Copyright Notice! 
// This document is protected under the trade secret and copyright 
// laws as the property of Fidelity National Information Services, Inc. 
// Copying, reproduction or distribution should be limited and only to 
// employees with a “need to know” to do their job. 
// Any disclosure of this document to third parties is strictly prohibited.
// © 2018 Fidelity National Information Services.
// All rights reserved worldwide.
namespace Fis.Epp.Fusion.Auth
{
    using Fis.Epp.Fusion.Auth.Models;
    using Newtonsoft.Json;
    using System;
    using System.Net.Http;
    using System.Net.Http.Headers;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>Represents handler class to interact with REST to get context token.</summary>
    public class RESTAccessHandler : AccessHandlerBase
    {
        #region Ctor

        public RESTAccessHandler(AppConfiguration appConfiguration) : base(appConfiguration)
        {
        }

        #endregion

        #region Audit Sign On

        /// <summary>Call for audit signon.</summary>
        /// <param name="model">Audit SignOn model.</param>
        /// <returns>Indicating success or failure.</returns>
        public async Task<bool> AuditSignOn(AuditSignOnRequestModel model)
        {
            string baseUrl = AppConfiguration.RestEndpoints.AuditSignOn;
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, baseUrl);
            request.Headers.Add(RequestHeader.FE_ID.GetEnumDescription(), model.FeId);
            request.Headers.Add(RequestHeader.Correlation_ID.GetEnumDescription(), model.CorrelationId);
            request.Headers.Add(RequestHeader.USER_ID.GetEnumDescription(), model.UserId);
            request.Headers.Add(RequestHeader.UUID.GetEnumDescription(), model.Uuid);
            request.Headers.Add(RequestHeader.ContextToken.GetEnumDescription(), model.ContextToken);
            request.Headers.Add(RequestHeader.Authorization.GetEnumDescription(), model.Authorization);
            request.Headers.Add(RequestHeader.Locale.GetEnumDescription(), "en_US");
            request.Headers.Add(RequestHeader.Source_ID.GetEnumDescription(), "FUSION_AUTH");
            request.Headers.Add(RequestHeader.Application_ID.GetEnumDescription(), "FUSION_SVCS");

            request = ResolveCCHeader(request);

            var data = new { ipAddress = model.IpAddress, userHeaderAgent = model.UserHeaderAgent, sessionID = model.CorrelationId };
            request.Content = new StringContent(JsonConvert.SerializeObject(data), Encoding.UTF8, "application/json");
            request.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

            var response = await InvokeService(request);
            response.EnsureSuccessStatusCode();
            if (response.IsSuccessStatusCode)
            {
                return true;
            }
            return false;
        }

        #endregion

        #region Get Context Token

        /// <summary>Call for get context token.</summary>                
        /// <param name="model">Context token request model.</param>       
        /// <returns>Returns context token.</returns>
        public async Task<ContextTokenModel> GetContextToken(ContextTokenRequestModel model)
        {
            string baseUrl = AppConfiguration.RestEndpoints.GetContextToken;
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, baseUrl);
            request.Headers.Add(RequestHeader.FE_ID.GetEnumDescription(), model.FeId);
            request.Headers.Add(RequestHeader.Locale.GetEnumDescription(), model.Locale);
            request.Headers.Add(RequestHeader.Application_ID.GetEnumDescription(), model.ApplicationId);
            request.Headers.Add(RequestHeader.USER_ID.GetEnumDescription(), model.UserId);
            request.Headers.Add(RequestHeader.UUID.GetEnumDescription(), model.Uuid);
            request.Headers.Add(RequestHeader.Source_ID.GetEnumDescription(), model.SourceId);
            request.Headers.Add(RequestHeader.Authorization.GetEnumDescription(), model.Authorization);

            request = ResolveCCHeader(request);

            var data = new { secretKey = AppConfiguration.ContextTokenSecretKey };
            request.Content = new StringContent(JsonConvert.SerializeObject(data), Encoding.UTF8, "application/json");

            var response = await InvokeService(request);
            response.EnsureSuccessStatusCode();

            var stringResult = await response.Content.ReadAsStringAsync();
            ContextTokenModel contextData = JsonConvert.DeserializeObject<ContextTokenModel>(stringResult);
            return contextData;
        }

        #endregion

        #region Refresh Context Token

        /// <summary>Refresh context token.</summary>
        /// <param name="model"></param>
        /// <returns>New context token.</returns>
        public async Task<ContextTokenModel> RefreshContextToken(ContextTokenRequestModel model)
        {
            string baseUrl = AppConfiguration.RestEndpoints.RefreshContextToken;

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, baseUrl);
            request.Headers.Add(RequestHeader.FE_ID.GetEnumDescription(), model.FeId);
            request.Headers.Add(RequestHeader.USER_ID.GetEnumDescription(), model.UserId);
            request.Headers.Add(RequestHeader.UUID.GetEnumDescription(), model.Uuid);
            request.Headers.Add(RequestHeader.Authorization.GetEnumDescription(), model.Authorization);
            request.Headers.Add(RequestHeader.ContextToken.GetEnumDescription(), model.ContextToken);
            request.Headers.Add(RequestHeader.Correlation_ID.GetEnumDescription(), model.CorrelationId);
            request.Headers.Add(RequestHeader.Locale.GetEnumDescription(), model.Locale);
            request.Headers.Add(RequestHeader.Source_ID.GetEnumDescription(), model.SourceId);
            request.Headers.Add(RequestHeader.Application_ID.GetEnumDescription(), model.ApplicationId);

            request = ResolveCCHeader(request);

            var data = new { secretKey = AppConfiguration.ContextTokenSecretKey };
            request.Content = new StringContent(JsonConvert.SerializeObject(data), Encoding.UTF8, "application/json");

            var response = await InvokeService(request);
            response.EnsureSuccessStatusCode();

            var stringResult = await response.Content.ReadAsStringAsync();
            ContextTokenModel contextData = JsonConvert.DeserializeObject<ContextTokenModel>(stringResult);
            return contextData;
        }

        #endregion

        #region Revoke Context Token

        /// <summary>Revoke context token.</summary>
        /// <param name="model"></param>
        /// <returns>Whether context token successfully revoked or not.</returns>
        public async Task<bool> RevokeContextToken(ContextTokenRequestModel model)
        {
            bool isTokenRevoked = false;
            string baseUrl = AppConfiguration.RestEndpoints.RevokeContextToken;

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, baseUrl);
            request.Headers.Add(RequestHeader.FE_ID.GetEnumDescription(), model.FeId);
            request.Headers.Add(RequestHeader.USER_ID.GetEnumDescription(), model.UserId);
            request.Headers.Add(RequestHeader.UUID.GetEnumDescription(), Guid.NewGuid().ToString());
            request.Headers.Add(RequestHeader.Authorization.GetEnumDescription(), model.Authorization);
            request.Headers.Add(RequestHeader.ContextToken.GetEnumDescription(), model.ContextToken);
            request.Headers.Add(RequestHeader.Correlation_ID.GetEnumDescription(), model.CorrelationId);
            request.Headers.Add(RequestHeader.Locale.GetEnumDescription(), model.Locale);
            request.Headers.Add(RequestHeader.Source_ID.GetEnumDescription(), model.SourceId);
            request.Headers.Add(RequestHeader.Application_ID.GetEnumDescription(), model.ApplicationId);

            request = ResolveCCHeader(request);

            var data = new { secretKey = AppConfiguration.ContextTokenSecretKey };
            request.Content = new StringContent(JsonConvert.SerializeObject(data), Encoding.UTF8, "application/json");

            var response = await InvokeService(request);
            response.EnsureSuccessStatusCode();

            if (response.IsSuccessStatusCode)
                isTokenRevoked = true;

            return isTokenRevoked;
        }

        #endregion

        private HttpRequestMessage ResolveCCHeader(HttpRequestMessage request)
        {
            AppConfiguration.CodeConnectHeaders.Environment_Id.TryGetValue("SecurityServiceSuite", out string codeConnectHeader);
            if (!string.IsNullOrEmpty(codeConnectHeader))
            {
                request.Headers.Add(RequestHeader.environment_id.GetEnumDescription(), codeConnectHeader);
            }
            return request;
        }
    }
}
