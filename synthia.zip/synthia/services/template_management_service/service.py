from asyncio import TaskGroup
from typing import Tuple
from src.synthia.persistence.template_metadata_repository import DatabaseTemplateMetadataRepository
from src.synthia.services.template_management_service.dto import CreateCompanyTemplateRequest, UpdateCompanyTemplateRequest
from src.synthia.services.template_management_service.validation import validate_new, validate_update
from src.synthia.utils.template_util import load_all_templates
from uuid import UUID


class TemplateManagementService:
    def __init__(self, repository: DatabaseTemplateMetadataRepository):
        self.repository = repository
        self.fields = DatabaseTemplateMetadataRepository.Columns

    async def create_company_template_metadata(self, request: CreateCompanyTemplateRequest) -> Tuple[bool, str | None]:
        async with TaskGroup() as tg:
            existing_if_found_task = tg.create_task(self.repository.get_template_metadata_by_template_name(request.company_name, request.tile_name))
            filenames_to_content_task = tg.create_task(load_all_templates())
        success, message = validate_new(request, existing_if_found_task.result(), filenames_to_content_task.result())
        if not success:
            return False, message
        await self.repository.create_template_metadata(request.company_name, request.tile_name, request.tile_description, request.template_config_file_name)
        return True, None

    async def update_company_template_metadata(self, company_name: str, template_id: UUID, request: UpdateCompanyTemplateRequest) -> Tuple[bool, str | None]:
        async with TaskGroup() as tg:
            existing_if_found_task = tg.create_task(self.repository.get_template_metadata_by_id(company_name, template_id))
            non_unique_if_found_task = tg.create_task(self.repository.get_template_metadata_by_template_name(company_name, request.tile_name))
            filenames_to_content_task = tg.create_task(load_all_templates())
        success, message = validate_update(company_name, template_id, request, existing_if_found_task.result(), non_unique_if_found_task.result(), filenames_to_content_task.result())
        if not success:
            return False, message
        await self.repository.update_template_metadata(company_name, template_id, request.tile_name, request.tile_description, request.template_config_file_name)
        return True, None

    async def delete_company_template_metadata(self, company_name: str, template_id: UUID):
        await self.repository.delete_template_metadata(company_name, template_id)