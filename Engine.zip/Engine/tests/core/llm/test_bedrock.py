import json
from unittest.mock import Mock, patch

import pytest
from botocore.config import Config
from botocore.exceptions import ClientError

from chatrd.core.llm.models import Bedrock
from chatrd.core.llm.components.message import AIMessage, AIMessageChunk
from chatrd.core.llm.prompt import StringPromptValue
from chatrd.core.llm.parsers import LLMInputOutputParser

CLAUDE_MODEL = "anthropic.claude-v2"
ANTHROPIC_PROVIDER = "anthropic"


class TestBedrockInitialization:
    """Test cases for Bedrock class initialization."""

    @pytest.fixture(scope="function")
    def mock_boto_session(self):
        """Test BedrockChat initialization with AWS profile."""
        with patch("chatrd.core.llm.models.bedrock.boto3.Session") as mock_boto_session:
            with patch("chatrd.core.llm.models.bedrock.boto3.client") as mock_boto_client:
                mock_session = Mock()
                mock_client = Mock()
                mock_session.available_profiles = ["default", "test-profile"]
                mock_boto_session.return_value = mock_session
                mock_session.client.return_value = mock_client
                mock_boto_client.return_value = mock_client
                return mock_boto_session

    def test_init_with_client(self):
        """Test initialization with pre-configured client."""
        mock_client = Mock()
        bedrock = Bedrock(model_id=CLAUDE_MODEL, client=mock_client, provider=ANTHROPIC_PROVIDER)

        assert bedrock.model_id == CLAUDE_MODEL
        assert bedrock.client == mock_client
        assert bedrock.provider == ANTHROPIC_PROVIDER
        assert bedrock.streaming is False

    @pytest.mark.parametrize(
        "provider, auth_type, is_streaming, inc_kwargs, inc_guardrails",
        [
            (ANTHROPIC_PROVIDER, None, False, False, False),
            (None, None, False, False, False),
            (ANTHROPIC_PROVIDER, None, True, False, False),
            (ANTHROPIC_PROVIDER, None, False, True, False),
            (ANTHROPIC_PROVIDER, None, False, False, True),
            (ANTHROPIC_PROVIDER, None, True, True, False),
            (ANTHROPIC_PROVIDER, None, False, True, True),
            (ANTHROPIC_PROVIDER, None, True, True, True),
            (ANTHROPIC_PROVIDER, "aws_profile", False, False, False),
            (ANTHROPIC_PROVIDER, "aws_keys", True, False, False),
            (ANTHROPIC_PROVIDER, "client_config", False, True, False),
        ],
    )
    def test_init_with_params(self, mock_boto_session, provider, auth_type, is_streaming, inc_kwargs, inc_guardrails):
        """Test initialization with different parameters."""
        model_kwargs = None if not inc_kwargs else {"temperature": 0.7, "max_tokens": 100}
        guardrails = None if not inc_guardrails else {"id": "test-id", "version": "1", "trace": True}
        profile = None if auth_type != "aws_profile" else "test-profile"
        aws_keys = None if auth_type != "aws_keys" else {"aws_access_key_id": "test", "aws_secret_access_key": "test"}
        client_config = None if auth_type != "client_config" else Config(region_name="us-west-2")
        region = None if client_config else "us-east-1"
        expected_region = "us-west-2" if client_config else "us-east-1"

        with patch("boto3.Session", mock_boto_session):
            bedrock_chat = Bedrock(
                model_id=CLAUDE_MODEL,
                provider=provider,
                region_name=region,
                aws_profile_name=profile,
                aws_keys=aws_keys,
                streaming=is_streaming,
                model_kwargs=model_kwargs,
                guardrails=guardrails,
                verbose=True,
                client_config=client_config,
            )

        assert bedrock_chat.model_id == CLAUDE_MODEL
        assert bedrock_chat.get_provider() == ANTHROPIC_PROVIDER
        assert bedrock_chat.region_name == expected_region
        assert bedrock_chat.streaming is is_streaming
        assert bedrock_chat.model_kwargs == model_kwargs
        assert bedrock_chat.guardrails == guardrails
        assert bedrock_chat.verbose is True
        assert bedrock_chat.get_session() is not None
        if not aws_keys:
            assert mock_boto_session.call_count > 1

    def test_init_missing_region_name(self):
        """Test initialization fails without region_name when no client provided."""
        with pytest.raises(ValueError, match="region_name must be a string"):
            Bedrock(model_id=CLAUDE_MODEL)

    def test_init_invalid_aws_keys(self):
        """Test initialization fails with invalid AWS keys."""
        invalid_keys = {"invalid_key": "value"}

        with pytest.raises(ValueError, match="The aws_keys must be a dictionary containing"):
            Bedrock(model_id=CLAUDE_MODEL, region_name="us-east-1", aws_keys=invalid_keys)


class TestBedrockInvoke:
    """Test cases for invoke method."""

    @pytest.fixture(scope="function")
    def mock_client(self):
        """Create a boto3 mocked client."""
        mock_client = Mock()
        mock_client.invoke_model = Mock()
        return mock_client

    @pytest.fixture
    def mock_response_body(self):
        """Create a mock response body."""
        return {"generations": [{"id": "test-id", "text": "Test response text", "output": "Test output"}]}

    @pytest.fixture(scope="function")
    def mock_client_with_mock_response(self, mock_client, mock_response_body):
        """Create a mocked client with a mock response."""
        mock_response = {"body": Mock()}
        mock_response["body"].read.return_value = json.dumps(mock_response_body).encode()
        mock_client.invoke_model.return_value = mock_response
        return mock_client

    @pytest.mark.parametrize(
        "input, expected_call_prompt",
        [
            ("Test string prompt", "User: Test string prompt"),
            (StringPromptValue(text="Test prompt value"), "User: Test prompt value"),
        ],
    )
    def test_invoke_with_prompts(self, mock_client_with_mock_response, input, expected_call_prompt):
        """Test invoke with string input."""
        mock_client = mock_client_with_mock_response
        input_content = input if isinstance(input, str) else input.text

        bedrock = Bedrock(model_id="cohere", client=mock_client)
        with patch.object(bedrock, "_prepare_inputs", wraps=bedrock._prepare_inputs) as mock_prepare:
            result = bedrock.invoke(input)

        mock_prepare.assert_called_once_with(prompt=input_content, system=None, messages=None)
        assert isinstance(result, AIMessage)
        assert result.content == "Test response text"
        assert expected_call_prompt in mock_client.invoke_model.call_args[1]["body"]

    @pytest.mark.parametrize(
        "messages, expected_prompt_text",
        [
            ([{"role": "user", "content": "What day is today?"}], "\n\nUser: What day is today?"),
            (
                [{"role": "user", "content": "What year is today?"}, {"role": "user", "content": "What day is today?"}],
                "\n\nUser: What year is today?\n\n\nUser: What day is today?",
            ),
            (
                [
                    {"role": "system", "content": "You are a helpful assistant."},
                    {"role": "user", "content": "What day is today?"},
                ],
                "\n\nSystem: You are a helpful assistant.\n\n\nUser: What day is today?",
            ),
        ],
    )
    def test_invoke_with_messages(self, mock_client_with_mock_response, messages, expected_prompt_text):
        """Test invoke with list of messages."""
        mock_client = mock_client_with_mock_response
        bedrock = Bedrock(model_id="cohere", client=mock_client)

        with patch.object(bedrock, "_prepare_inputs", wraps=bedrock._prepare_inputs) as mock_prepare:
            result = bedrock.invoke(messages)

        mock_prepare.assert_called_once_with(prompt=expected_prompt_text, system=None, messages=None)
        assert isinstance(result, AIMessage)
        assert result.content == "Test response text"
        assert result.id == "test-id"
        for message in messages:
            content = message["content"]
            assert content in mock_client.invoke_model.call_args[1]["body"]

    def test_invoke_with_guardrails_enabled(self, mock_client_with_mock_response):
        """Test invoke with guardrails enabled."""
        mock_client = mock_client_with_mock_response
        expected_guardrails = {"guardrailId": "test-id", "guardrailVersion": "1"}
        bedrock = Bedrock(
            model_id="cohere",
            client=mock_client,
            guardrails={"id": "test-id", "version": "1", "trace": True},
        )

        with patch.object(mock_client, "invoke_model", wraps=mock_client.invoke_model) as mock_invoke:
            result = bedrock.invoke("Test prompt with guardrails enabled")

        mock_invoke.assert_called_once_with(
            body=json.dumps(
                {
                    "amazon-bedrock-guardrailDetails": expected_guardrails,
                    "max_tokens": 1024,
                    "prompt": "\n\nUser: Test prompt with guardrails enabled\n\nAssistant:",
                }
            ),
            modelId="cohere",
            accept="application/json",
            contentType="application/json",
            guardrail="ENABLED",
            trace="ENABLED",
        )
        assert isinstance(result, AIMessage)
        assert result.content == "Test response text"

    def test_invoke_client_error(self, mock_client):
        """Test invoke with client error."""
        mock_client.invoke_model.side_effect = ClientError(
            {"Error": {"Code": "ValidationException", "Message": "Invalid request"}}, "InvokeModel"
        )

        bedrock = Bedrock(model_id=CLAUDE_MODEL, client=mock_client)
        with patch.object(bedrock, "_prepare_inputs", wraps=bedrock._prepare_inputs) as mock_prepare:
            with pytest.raises(ClientError):
                bedrock.invoke("Test prompt")

        mock_prepare.assert_called_once_with(prompt="Test prompt", system=None, messages=None)

    @pytest.mark.asyncio
    async def test_ainvoke(self, mock_response_body):
        """Test async invoke method."""
        user_input = "Test prompt"
        mock_client = Mock()
        mock_response = {"body": Mock()}
        mock_response["body"].read.return_value = json.dumps(mock_response_body).encode()
        mock_client.invoke_model.return_value = mock_response

        bedrock = Bedrock(model_id="cohere", client=mock_client)
        with patch.object(bedrock, "_prepare_inputs", wraps=bedrock._prepare_inputs) as mock_prepare:
            result = await bedrock.ainvoke(user_input)

        mock_prepare.assert_called_once_with(prompt=user_input, system=None, messages=None)
        assert isinstance(result, AIMessage)
        assert result.content == "Test response text"
        assert result.id == "test-id"
        assert f"User: {user_input}" in mock_client.invoke_model.call_args[1]["body"]


class TestBedrockStreaming:
    """Test cases for streaming methods."""

    @pytest.fixture(scope="function")
    def mock_client_bedrock(self):
        """Create a Bedrock instance with mocked client."""
        mock_client = Mock()
        return Bedrock(model_id=CLAUDE_MODEL, client=mock_client)

    def test_stream_success(self, mock_client_bedrock):
        """Test successful streaming."""
        mock_stream = [
            {"chunk": {"bytes": json.dumps({"completion": "Hello "}).encode()}},
            {"chunk": {"bytes": json.dumps({"completion": "world!"}).encode()}},
        ]
        mock_response = {"body": iter(mock_stream)}
        mock_client_bedrock.client.invoke_model_with_response_stream.return_value = mock_response

        with patch.object(mock_client_bedrock, "_prepare_inputs", return_value={"test": "request"}):
            chunks = list(mock_client_bedrock.stream("Test prompt"))

        assert len(chunks) == 2
        assert all(isinstance(chunk, AIMessageChunk) for chunk in chunks)
        assert chunks[0].content == "Hello "
        assert chunks[1].content == "world!"

    def test_stream_empty_chunk(self, mock_client_bedrock):
        """Test streaming with empty chunks."""
        mock_stream = [
            {"chunk": {"bytes": json.dumps({}).encode()}},
            {"chunk": {"bytes": json.dumps({"completion": "Valid chunk"}).encode()}},
        ]
        mock_response = {"body": iter(mock_stream)}
        mock_client_bedrock.client.invoke_model_with_response_stream.return_value = mock_response

        with patch.object(mock_client_bedrock, "_prepare_inputs", return_value={"test": "request"}):
            chunks = list(mock_client_bedrock.stream("Test prompt"))

        assert len(chunks) == 1
        assert chunks[0].content == "Valid chunk"

    @pytest.mark.asyncio
    async def test_astream(self):
        """Test async streaming."""
        mock_stream = [
            {"chunk": {"bytes": json.dumps({"generations": [{"id": "chunk1", "text": "Hello "}]}).encode()}},
            {"chunk": {"bytes": json.dumps({"generations": [{"id": "chunk2", "text": "world!"}]}).encode()}},
        ]
        mock_response = {"body": iter(mock_stream)}
        mock_client = Mock()
        mock_client.invoke_model_with_response_stream.return_value = mock_response
        bedrock = Bedrock(model_id="cohere", client=mock_client)

        with patch.object(bedrock, "_prepare_inputs", return_value={"test": "request"}):
            stream_result = []
            async for chunk in bedrock.astream("Test prompt"):
                stream_result.append(chunk)

        assert len(stream_result) == 2
        assert all(isinstance(chunk, AIMessageChunk) for chunk in stream_result)
        assert stream_result[0].content == "Hello "
        assert stream_result[1].content == "world!"


class TestBedrockPrepareInputs:
    """Test cases for input preparation."""

    system_msg = {"role": "system", "content": "System message"}
    user_msg = {"role": "user", "content": "User input"}

    @pytest.mark.parametrize(
        "input_prompt, input_system_msg, input_messages, kwargs",
        [
            ("Test prompt", None, None, {}),
            ("Test prompt", "System message", None, {}),
            ("Test prompt", None, {}, {"temperature": 0.2, "max_tokens_to_sample": 100}),
            (None, None, [user_msg], {}),
            (None, None, [system_msg, user_msg], {}),
            (None, None, [system_msg, user_msg, user_msg], {}),
            (None, "System message", [user_msg], {}),
            (None, None, [user_msg], {"temperature": 0.2}),
            (None, None, [user_msg], {"max_tokens_to_sample": 100}),
        ],
    )
    def test_prepare_inputs(self, input_prompt, input_system_msg, input_messages, kwargs):
        """Test basic input preparation."""

        def parse_role(role):
            return "Human" if role == "user" else role.capitalize()

        DEFAULT_MAX_TOKENS = 1024
        if input_prompt:
            expected_prompt = f"Human: {input_prompt}"
        elif input_messages:
            expected_prompt = "\n\n".join(f"{parse_role(msg['role'])}: {msg['content']}" for msg in input_messages)

        max_token = kwargs.get("max_tokens_to_sample", DEFAULT_MAX_TOKENS)

        mock_client = Mock()
        bedrock = Bedrock(model_id=CLAUDE_MODEL, client=mock_client, model_kwargs=kwargs)
        with patch.object(bedrock, "_prepare_inputs", wraps=bedrock._prepare_inputs) as mock_prepare:
            request_options = bedrock._prepare_inputs(
                prompt=input_prompt, system=input_system_msg, messages=input_messages, **kwargs
            )

        assert mock_prepare.call_count == 1
        assert request_options.get("modelId") == CLAUDE_MODEL
        assert request_options.get("accept") == "application/json"
        assert request_options.get("contentType") == "application/json"
        req_body = json.loads(request_options.get("body"))
        assert expected_prompt in req_body.get("prompt")
        assert req_body.get("max_tokens_to_sample") == max_token
        if "temperature" in kwargs:
            assert req_body.get("temperature") == kwargs["temperature"]

    def test_prepare_inputs_additional_kwargs(self):
        """Test input preparation with additional kwargs."""
        mock_client = Mock()
        bedrock = Bedrock(model_id=CLAUDE_MODEL, client=mock_client, model_kwargs={"temperature": 0.7})
        expected_kwargs = {"temperature": 0.9, "max_tokens": 150}
        with patch.object(
            LLMInputOutputParser, "prepare_input", wraps=LLMInputOutputParser.prepare_input
        ) as mock_prepare:
            bedrock._prepare_inputs(prompt="Test prompt", temperature=0.9, max_tokens=150)

        # Verify that additional kwargs were merged
        mock_prepare.assert_called_once()
        call_args = mock_prepare.call_args[1]
        for key, value in expected_kwargs.items():
            assert call_args["model_kwargs"][key] == value

    def test_get_provider_explicit(self):
        """Test getting explicitly set provider."""
        mock_client = Mock()
        bedrock = Bedrock(model_id=CLAUDE_MODEL, client=mock_client, provider="anthropic")
        assert bedrock.get_provider() == "anthropic"

    @pytest.mark.parametrize(
        "model_id, expected_provider",
        [
            ("anthropic.claude-v2", "anthropic"),
            ("amazon.bedrock.llama-2", "amazon"),
            ("cohere.command-r-plus", "cohere"),
            ("ai21.jamba", "ai21"),
            ("meta.llama-3", "meta"),
            ("mistral.mistral-7b", "mistral"),
            ("custom-provider", "custom-provider"),
            ("custom-provider.model", "custom-provider"),
        ],
    )
    def test_get_provider_from_model_id(self, model_id, expected_provider):
        """Test extracting provider from model ID."""
        mock_client = Mock()
        bedrock = Bedrock(model_id=model_id, client=mock_client)
        assert bedrock.get_provider() == expected_provider

    def test_get_provider_arn_without_explicit_provider(self):
        """Test error when using ARN without explicit provider."""
        mock_client = Mock()
        bedrock = Bedrock(
            model_id="arn:aws:bedrock:us-east-1:123456789012:foundation-model/anthropic.claude-v2", client=mock_client
        )

        with pytest.raises(ValueError, match="Model provider should be supplied when passing a model ARN"):
            bedrock.get_provider()


class TestBedrockGuardrails:
    """Test cases for guardrails functionality."""

    def test_guardrails_enabled_valid_config(self):
        """Test guardrails enabled check with valid configuration."""
        mock_client = Mock()
        bedrock = Bedrock(model_id=CLAUDE_MODEL, client=mock_client, guardrails={"id": "test-id", "version": "1"})
        assert bedrock._guardrails_enabled is True

    def test_guardrails_enabled_invalid_config(self):
        """Test guardrails enabled check with invalid configuration."""
        mock_client = Mock()
        bedrock = Bedrock(model_id=CLAUDE_MODEL, client=mock_client, guardrails={"id": "test-id"})  # Missing version
        assert bedrock._guardrails_enabled is False

    def test_guardrails_enabled_none_config(self):
        """Test guardrails enabled check with None configuration."""
        mock_client = Mock()
        bedrock = Bedrock(model_id=CLAUDE_MODEL, client=mock_client, guardrails=None)
        assert bedrock._guardrails_enabled is False

    def test_get_guardrails_canonical(self):
        """Test getting guardrails in canonical format."""
        expected_guardrails_canonical = {
            "amazon-bedrock-guardrailDetails": {"guardrailId": "test-id", "guardrailVersion": "DRAFT"}
        }
        bedrock = Bedrock(
            model_id=CLAUDE_MODEL,
            client=Mock(),
            guardrails={"id": "test-id", "version": "DRAFT", "trace": True},
        )
        result = bedrock._get_guardrails_canonical()

        assert result == expected_guardrails_canonical

    def test_get_guardrails_canonical_empty(self):
        """Test getting guardrails canonical format with empty config."""
        expected = {"amazon-bedrock-guardrailDetails": {"guardrailId": None, "guardrailVersion": None}}
        bedrock = Bedrock(model_id=CLAUDE_MODEL, client=Mock())
        result = bedrock._get_guardrails_canonical()
        assert result == expected


class TestBedrockIntegration:
    """Integration tests for Bedrock class."""

    @patch("boto3.Session")
    def test_full_invoke_workflow(self, mock_session_class):
        """Test complete invoke workflow."""
        # Setup mocks
        mock_session = Mock()
        mock_client = Mock()
        mock_session.client.return_value = mock_client
        mock_session_class.return_value = mock_session

        # Mock response
        response_body = {"generations": [{"id": "test-id", "text": "Generated response"}]}
        mock_response = {"body": Mock()}
        mock_response["body"].read.return_value = json.dumps(response_body).encode()
        mock_client.invoke_model.return_value = mock_response

        # Create Bedrock instance
        with patch.object(Bedrock, "_get_valid_aws_profile", return_value="default"):
            bedrock = Bedrock(
                model_id="cohere",
                region_name="us-east-1",
                aws_profile_name="default",
                model_kwargs={"temperature": 0.7},
            )

        # Test invoke
        with patch.object(
            LLMInputOutputParser, "prepare_input", wraps=LLMInputOutputParser.prepare_input
        ) as mock_prepare:
            result = bedrock.invoke("Test prompt")

        # Verify result
        assert isinstance(result, AIMessage)
        assert result.content == "Generated response"
        assert result.id == "test-id"

        # Verify client was called correctly
        mock_prepare.assert_called_once_with(
            provider="cohere",
            model_kwargs={"temperature": 0.7, "max_tokens": 1024},
            prompt="Test prompt",
            system=None,
            messages=None,
        )
        mock_client.invoke_model.assert_called_once()
        call_args = mock_client.invoke_model.call_args[1]
        assert call_args["modelId"] == "cohere"
        assert call_args["accept"] == "application/json"
        assert call_args["contentType"] == "application/json"

    @patch("boto3.Session")
    def test_full_streaming_workflow(self, mock_session_class):
        """Test complete streaming workflow."""
        # Setup mocks
        mock_session = Mock()
        mock_client = Mock()
        mock_session.client.return_value = mock_client
        mock_session_class.return_value = mock_session

        # Mock streaming response
        stream_data = [
            {"chunk": {"bytes": json.dumps({"completion": "Hello ", "id": "1"}).encode()}},
            {"chunk": {"bytes": json.dumps({"completion": "world!", "id": "2"}).encode()}},
        ]
        mock_client.invoke_model_with_response_stream.return_value = {"body": iter(stream_data)}

        # Create Bedrock instance
        with patch.object(Bedrock, "_get_valid_aws_profile", return_value="default"):
            bedrock = Bedrock(model_id=CLAUDE_MODEL, region_name="us-east-1", streaming=True)

        # Test streaming
        with patch.object(
            LLMInputOutputParser, "prepare_input", wraps=LLMInputOutputParser.prepare_input
        ) as mock_prepare:
            chunks = list(bedrock.stream("Test prompt"))

        # Verify results
        assert len(chunks) == 2
        assert chunks[0].content == "Hello "
        assert chunks[1].content == "world!"
        assert all(isinstance(chunk, AIMessageChunk) for chunk in chunks)

        # Verify client was called correctly
        mock_prepare.assert_called_once_with(
            provider="anthropic",
            model_kwargs={"max_tokens_to_sample": 1024},
            prompt="Test prompt",
            system=None,
            messages=None,
        )


class TestBedrockHelpers:
    """Test cases for provider mapping validation."""

    @pytest.fixture(scope="function")
    def mock_client_bedrock(self):
        """Create a Bedrock instance with mocked client."""
        mock_client = Mock()
        return Bedrock(model_id=CLAUDE_MODEL, client=mock_client)

    @pytest.mark.parametrize(
        "input_provider, expected_provider",
        [
            ("Amazon", "amazon"),
            ("bedrock", "amazon"),
            ("cohere", "cohere"),
            ("Cohere-LLM", "cohere"),
            ("ai21", "ai21"),
            ("AI21-LLM", "ai21"),
            ("claude", "anthropic"),
            ("anthropic", "anthropic"),
            ("llama", "meta"),
            ("meta", "meta"),
            ("mistral", "mistral"),
            ("unknown", None),
            (None, None),
        ],
    )
    def test_provider_mapping(self, input_provider, expected_provider):
        """Test provider name mapping."""
        result = Bedrock.provider_mapping(input_provider)
        assert result == expected_provider

    @pytest.mark.parametrize(
        "available_profiles, input_profile, expected_profile",
        [
            (["default", "test-profile", "dev-profile"], "test-profile", "test-profile"),
            (["default", "test-profile", "dev-profile"], "non-existent-profile", "default"),
            (["other-profile"], "non-existent", None),
        ],
    )
    @patch("boto3.Session")
    def test_getting_aws_profile(self, mock_session_class, available_profiles, input_profile, expected_profile):
        """Test getting valid AWS profile."""
        mock_session = Mock()
        mock_session.available_profiles = available_profiles
        mock_session_class.return_value = mock_session

        bedrock = Bedrock(model_id=CLAUDE_MODEL, client=Mock())

        if expected_profile:
            result = bedrock._get_valid_aws_profile(input_profile)
            assert result == expected_profile
        else:
            with pytest.raises(ValueError, match=f"Profile '{input_profile}' does not exist"):
                bedrock._get_valid_aws_profile(input_profile)

    def test_convert_string_input(self, mock_client_bedrock):
        """Test converting string input."""
        result = mock_client_bedrock._convert_input("Test prompt")

        assert isinstance(result, StringPromptValue)
        assert result.text == "Test prompt"

    def test_convert_prompt_value_input(self, mock_client_bedrock):
        """Test converting PromptValue input."""
        prompt_value = StringPromptValue(text="Test prompt")
        result = mock_client_bedrock._convert_input(prompt_value)

        assert isinstance(result, StringPromptValue)
        assert result.text == "Test prompt"

    def test_convert_messages_input(self, mock_client_bedrock):
        """Test converting messages input."""
        messages = [{"role": "user", "content": "Hello"}]
        result = mock_client_bedrock._convert_input(messages)

        assert isinstance(result, StringPromptValue)
        assert "Hello" in result.text

    def test_convert_invalid_input(self, mock_client_bedrock):
        """Test converting invalid input type."""
        with pytest.raises(ValueError, match="Invalid input type"):
            mock_client_bedrock._convert_input(123)
