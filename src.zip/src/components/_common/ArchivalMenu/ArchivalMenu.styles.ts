import styled from "@emotion/styled";
import { DARK } from '@spglobal/koi-helpers';

export const ArchivalIcon = styled.span`
    [data-testid="icon"]
    {
      left: 150px;
    }
`;

export const ArchivalButton = styled.button`
    background-color: var(--color-bg-hover) !important;
    &.chatactive{
      background-color: #e0e7ef !important;
    }
    .${DARK} &.chatactive {
      background-color: #3f3f3f !important;
    }
    border: none;
    
`;

