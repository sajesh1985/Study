from typing import List, Optional

from pydantic import BaseModel


class SuggestedEntity(BaseModel):
    id: Optional[str] = None
    name: Optional[str] = None
    query: Optional[str] = None


class SuggestedEntities(BaseModel):
    entities: Optional[List[SuggestedEntity]] = None
    query_entity_is_rd: Optional[bool] = None


class SuggestedEntitiesResponse(BaseModel):
    text: Optional[str] = None
    suggestions: Optional[List[SuggestedEntity]] = None


class SuggestedEntitiesContent(BaseModel):
    title: str
    content: List[SuggestedEntitiesResponse]
    behavior: str = "collapse"
