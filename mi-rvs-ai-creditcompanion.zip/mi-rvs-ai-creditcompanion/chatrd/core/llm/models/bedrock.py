"""Bedrock LLM wrapper for Amazon Bedrock models."""

import copy
import json
import logging
from typing import Any, AsyncGenerator, Dict, Iterable, List, Optional, Sequence, Union

import boto3
from botocore.config import Config
from pydantic import ConfigDict, Field, PrivateAttr, field_validator, model_validator
from typing_extensions import override

from chatrd.core.llm.components import BaseLanguageModel, LanguageModelInput
from chatrd.core.llm.components.message import (
    AIMessage,
    AIMessageChunk,
    BaseMessage,
    BaseMessageChunk,
    MessageLikeRepresentation,
    convert_to_message,
)
from chatrd.core.llm.components.providers import ProviderMapping
from chatrd.core.llm.parsers import LLMInputOutputParser
from chatrd.core.llm.prompt import PromptValue, StringPromptValue
from chatrd.core.thread_utils import run_in_executor

AWS_KEYS_REQUIRED = ["aws_access_key_id", "aws_secret_access_key"]

logger = logging.getLogger(__name__)


class Bedrock(BaseLanguageModel):
    """Class for interacting with Amazon Bedrock models.
    This class creates a Bedrock LLM wrapper and provides an interface to
    """

    model_config = ConfigDict(
        extra="forbid",
    )

    # Core fields required to interact with the model
    model_id: str = Field(..., frozen=True, description="The ID of the Bedrock model to use.")
    provider: Optional[str] = Field(
        None,
        description="The model provider, e.g., amazon, cohere, ai21, etc."
        "When not supplied, provider is extracted from the model_id",
    )
    client: Optional[Any] = Field(
        default=None,
        description="A pre-configured botocore client. If not provided, a new client will be created.",
        exclude=True,
    )

    # Authentication related fields, these are used when client is not provided
    region_name: Optional[str] = Field(None, frozen=True, description="The AWS region where the model is hosted.")
    aws_profile_name: Optional[str] = Field(None, description="The name of the AWS credentials profile to use.")
    aws_keys: Optional[Dict[str, str]] = Field(None, description="A dictionary containing AWS access and secret keys.")
    client_config: Optional[Config] = Field(None, description="Configuration for the AWS Bedrock client.", exclude=True)

    # Fields related model configuration for fine-tuning the model behavior
    streaming: bool = Field(False, description="Whether to enable streaming for the model.")
    model_kwargs: Optional[Dict[str, Any]] = Field(
        None, description="Additional keyword arguments for the model such as temperature, max_tokens_to_sample, etc."
    )
    guardrails: Optional[Dict[str, Any]] = Field(
        default_factory=dict,
        exclude=True,
        description="Guardrails configuration for the model, including id, version, trace, and stream processing mode.",
        examples=[
            {
                "id": "your-guardrail-id",  # Required: Guardrail identifier
                "version": "DRAFT",  # Version: "DRAFT" or specific version number
                "trace": True,  # Enable tracing for debugging
            }
        ],
    )
    verbose: bool = Field(
        default_factory=lambda: BaseLanguageModel.get_verbose,
        description="Whether to enable verbose logging for the model.",
    )

    _session: boto3.Session = PrivateAttr(default=None, init=False)

    @field_validator("provider", mode="before")
    @classmethod
    def provider_mapping(cls, provider: Optional[str]) -> Optional[str]:
        """Resolve the provider name to a canonical form."""
        if provider and isinstance(provider, str):
            provider = provider.lower()
            if any([item in provider for item in ["amazon", "bedrock"]]):
                return "amazon"
            elif any([item in provider for item in ["cohere", "cohere-llm"]]):
                return "cohere"
            elif any([item in provider for item in ["ai21", "ai21-llm"]]):
                return "ai21"
            elif any([item in provider for item in ["claude", "anthropic"]]):
                return "anthropic"
            elif any([item in provider for item in ["llama", "meta"]]):
                return "meta"
            elif "mistral" in provider:
                return "mistral"
        return None

    @model_validator(mode="before")
    def set_region_name(cls, values: Dict[str, Any]) -> Dict[str, Any]:
        """Set the region_name to the default region if not provided."""
        region_name = values.get("region_name")
        client_config = values.get("client_config")

        if not region_name:
            if client_config and isinstance(client_config, Config) and client_config.region_name:
                values["region_name"] = client_config.region_name
            else:
                values["region_name"] = "us-east-1"
        return values

    def __init__(
        self,
        model_id: str,
        provider: Optional[str] = None,
        client: Optional[Any] = None,
        region_name: Optional[str] = None,
        aws_profile_name: Optional[str] = None,
        aws_keys: Optional[Dict[str, str]] = None,
        client_config: Optional[Config] = None,
        streaming: bool = False,
        model_kwargs: Optional[Dict[str, Any]] = None,
        guardrails: Optional[Dict[str, Any]] = None,
        verbose: bool = False,
    ) -> None:
        """Initialize the Bedrock LLM with the model ID and other optional parameters.

        Core-args:
            model_id (str): The ID of the Bedrock model to use.
            provider (Optional[str]): The model provider, e.g., amazon, cohere, ai21, etc.
                Required when model ARN is provided as model_id.
            client (Any): A pre-configured Bedrock client. If not provided, a new client will be created.
        Authentication args
            region_name (Optional[str]): The AWS region where the model is hosted.
                Fallback to the default region from Boto3 if not provided.
            aws_profile_name (Optional[str]): The name of the AWS credentials profile to use.
                Fallback to the default profile if not provided.
            aws_keys (Optional[Dict[str, str]]): A dictionary containing AWS access and secret keys.
                Fallback to the desired or default AWS profile if not provided.
            client_config (Optional[Config]): Configuration for creation the Boto3 client.
                For more details, refer to the Boto3 documentation.
                https://boto3.amazonaws.com/v1/documentation/api/latest/guide/configuration.html
        Model-config args
            streaming (bool): Whether to enable streaming for the model. Defaults to False.
            model_kwargs (Optional[Dict[str, Any]]): Additional keyword arguments for the model such as,
                temperature, max_tokens_to_sample, guardrail_identifier, guardrail_version, etc.
            guardrails (Optional[Dict[str, Any]]): Guardrails configuration for the model,
                including id, version, and trace.
            verbose (bool): Whether to enable verbose logging. Defaults to False.
        """
        super().__init__(
            model_id=model_id,
            provider=provider,
            client=client,
            region_name=region_name,
            aws_profile_name=aws_profile_name,
            aws_keys=aws_keys,
            client_config=client_config,
            streaming=streaming,
            model_kwargs=model_kwargs,
            guardrails=guardrails,
            verbose=verbose,
        )
        if client:
            self.client = client
        else:  # Create a new client if not provided
            if not region_name or not isinstance(region_name, str):
                if client_config and client_config.region_name and isinstance(client_config.region_name, str):
                    region_name = client_config.region_name
                else:
                    raise ValueError("region_name must be a string.")
            # Attempt to create session with provided AWS secret keys
            if aws_keys:
                if not isinstance(aws_keys, dict) or not all(key in aws_keys for key in AWS_KEYS_REQUIRED):
                    raise ValueError(f"The aws_keys must be a dictionary containing: {AWS_KEYS_REQUIRED}.")
                self._session = boto3.Session(
                    aws_access_key_id=aws_keys["aws_access_key_id"],
                    aws_secret_access_key=aws_keys["aws_secret_access_key"],
                    region_name=region_name,
                )
            if not self._session:
                # Attempt to create session with provided AWS profile name
                profile = self._get_valid_aws_profile(aws_profile_name)
                if profile is not None:
                    self._session = boto3.Session(profile_name=profile)
                else:
                    # Fallback to creating a session with the default profile
                    self._session = boto3.Session(region_name=region_name)
            if not self._session:
                raise ValueError("Session could not be created. Please provide valid AWS credentials or profile.")

            self.client = self._session.client(
                service_name="bedrock-runtime", region_name=region_name, config=client_config or None
            )

    def _get_valid_aws_profile(self, aws_profile_name: str) -> str:
        "Validate the inputs and find a valid AWS profile name." ""
        profile = None
        if not aws_profile_name or not isinstance(aws_profile_name, str):
            logger.error(f"The provided profile name ({aws_profile_name}) is not a valid.")

        available_profiles = boto3.Session().available_profiles
        if aws_profile_name in available_profiles:
            profile = aws_profile_name
        elif "default" in available_profiles:
            profile = "default"
        else:
            raise ValueError(
                f"Profile '{aws_profile_name}' does not exist in your AWS configuration. "
                "Please provide a valid profile name or ensure the default profile is set."
            )
        return profile

    def get_session(self) -> boto3.Session:
        """Return the current boto3 session."""
        if not self._session:
            raise ValueError("Session has not been initialized. Please provide valid AWS credentials or profile.")
        return self._session

    @override
    def invoke(self, inputs: LanguageModelInput, **kwargs) -> AIMessage:
        """Invoke the model with the provided inputs."""
        context: dict = copy.deepcopy(kwargs)
        prompt = self._convert_input(inputs)
        request_options = self._prepare_inputs(
            prompt=prompt.to_string(),
            system=context.pop("system", None),
            messages=context.pop("messages", None),
            **context,
        )
        logger.debug(f"Invoking Bedrock model with request options: {request_options}")

        try:
            client_response = self.client.invoke_model(**request_options)
        except Exception as e:
            logger.error(f"Error invoking Bedrock model: {e}")
            raise e

        try:
            response = LLMInputOutputParser.prepare_output(self.get_provider(), client_response)
        except ValueError as e:
            logger.error(f"Error preparing output from Bedrock model: {e}")
            raise e

        try:
            return AIMessage(
                id=response.get("id"),
                content=response.get("text"),
                response_metadata={
                    "usage": response.get("usage"),
                    "response_body": response.get("body"),
                },
            )
        except KeyError as e:
            logger.error(f"Unexpected response format from Bedrock model: {response}")
            raise ValueError(f"Invalid response from Bedrock model. Missing expected key: {e}")
        except json.JSONDecodeError as e:
            logger.error(f"Error decoding JSON response from Bedrock model: {e}")
            raise ValueError("Invalid JSON response from Bedrock model.")
        except Exception as e:
            logger.error(f"Unexpected error while processing Bedrock model response: {e}")

    @override
    async def ainvoke(self, inputs: LanguageModelInput, **kwargs) -> AIMessage:
        """Asynchronously invoke the model with the provided inputs."""
        return await run_in_executor(
            executor=None,
            func=self.invoke,
            inputs=inputs,
            **kwargs,
        )

    @override
    def stream(self, inputs: LanguageModelInput, **kwargs) -> Iterable[AIMessageChunk]:
        """Stream the model's response."""
        context: dict = copy.deepcopy(kwargs)
        inputs: PromptValue = self._convert_input(inputs)
        request_options = self._prepare_inputs(
            prompt=inputs.to_string(),
            system=context.pop("system", None),
            messages=context.pop("messages", None),
            **context,
        )
        logger.debug(f"Invoking Bedrock model with request options: {request_options}")

        try:
            streaming_response = self.client.invoke_model_with_response_stream(**request_options)
        except Exception as e:
            logger.error(f"Error invoking Bedrock model: {e}")
            raise e

        try:
            parsed_response = LLMInputOutputParser.prepare_output_stream(self.get_provider(), streaming_response)
        except json.JSONDecodeError as e:
            logger.error(f"Error decoding JSON response from Bedrock model: {e}")
            yield
        except ValueError as e:
            logger.error(f"Error preparing output from Bedrock model: {e}")
            raise e

        for generation in parsed_response:
            info = generation.generation_info or {}
            yield AIMessageChunk(content=generation.text, id=info.pop("id", None), response_metadata=info)

    @override
    async def astream(self, inputs: LanguageModelInput, **kwargs) -> AsyncGenerator[AIMessageChunk, None]:
        """Asynchronously stream the model's response."""
        for chunk in self.stream(inputs, **kwargs):
            if isinstance(chunk, AIMessageChunk):
                yield chunk
            else:
                logger.warning(f"Unexpected chunk type: {type(chunk)}. Expected AIMessageChunk.")

    def get_provider(self) -> str:
        """Return the provided model provider or extract it from the model_id."""
        if self.provider:
            return self.provider
        if self.model_id.startswith("arn"):
            raise ValueError("Model provider should be supplied when passing a model ARN as model_id")

        return self.model_id.split(".")[0]

    def _prepare_inputs(
        self,
        prompt: Optional[str] = None,
        system: Optional[str] = None,
        messages: Optional[List[Dict]] = None,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """Prepare the input body for the Bedrock model invocation.

        Args:
            prompt (Optional[str]): The original prompt to send to the model.
            system (Optional[str]): Optional system message/instructions that guide the model's behavior
                throughout the conversation, such as defining the role, tone of voice of the model, etc.
            messages (Optional[List[Dict]]): supports structured conversation format using a list of dictionaries,
                containing message roles (user, assistant, system) and content, which is essential for multi-turn
                dialogues and chat-based interactions. E.g: [{"role": "user", "content": "Hello!"}]
            **kwargs: Additional keyword arguments for the model invocation.
                These are model-specific parameters that vary between different Bedrock models. Different models
                might use parameters like temperature, top-p sampling, max tokens, or model-specific features.
        """
        _model_kwargs = self.model_kwargs or {}

        provider = self.get_provider()
        params = {**_model_kwargs, **kwargs}
        if self._guardrails_enabled:
            params.update(self._get_guardrails_canonical())
        input_body = LLMInputOutputParser.prepare_input(
            provider=provider,
            model_kwargs=params,
            prompt=prompt,
            system=system,
            messages=messages,
        )

        body = json.dumps(input_body)
        accept = "application/json"
        contentType = "application/json"

        request_options = {
            "body": body,
            "modelId": self.model_id,
            "accept": accept,
            "contentType": contentType,
        }

        if self._guardrails_enabled:
            request_options["guardrail"] = "ENABLED"
            if self.guardrails.get("trace"):
                request_options["trace"] = "ENABLED"
        return request_options

    @property
    def _guardrails_enabled(self) -> bool:
        """Determines if guardrails are enabled and correctly configured."""
        try:
            return bool(
                isinstance(self.guardrails, dict) and bool(self.guardrails["id"]) and bool(self.guardrails["version"])
            )
        except (KeyError, TypeError):
            logger.warning(
                "Guardrails configuration is not valid. Ensure it is a dictionary with 'id' and 'version' keys."
            )
            return False

    def _get_guardrails_canonical(self) -> Dict[str, Any]:
        """Compose the guardrails configuration in the canonical format for Bedrock service."""
        guardrails = self.guardrails or {}
        return {
            "amazon-bedrock-guardrailDetails": {
                "guardrailId": guardrails.get("id"),
                "guardrailVersion": guardrails.get("version"),
            }
        }

    def _convert_input(self, model_input: LanguageModelInput) -> PromptValue:
        """Handle the conversion of different input types to a single PromptValue."""
        get_role_format = ProviderMapping.parse(self.get_provider()).get_role_format
        if isinstance(model_input, str):
            return StringPromptValue(text=model_input)
        elif isinstance(model_input, PromptValue):
            return StringPromptValue(text=model_input.to_string())
        elif isinstance(model_input, BaseMessage):
            return StringPromptValue(text=model_input.content)
        if isinstance(model_input, Sequence):
            items: List[str] = []
            for item in model_input:
                if isinstance(item, str):
                    items.append(item)
                elif isinstance(item, (PromptValue, BaseMessage, BaseMessageChunk)):
                    items.append(item.to_string())
                elif isinstance(item, dict):
                    if "role" in item:
                        role = item.get("role", "user").lower()
                        role = get_role_format(role)
                    if "content" in item:
                        content = item.get("content", "")
                    if role and content:
                        items.append(f"{role} {content}")
                    else:
                        raise ValueError(f"Invalid dictionary format: {item}. Expected keys: 'role' and 'content'.")
                else:
                    raise ValueError(f"Unsupported input type: {type(item)}.")
            return StringPromptValue(text="\n".join(items))

        msg = f"Invalid input type {type(model_input)}."
        raise ValueError(msg)

    @staticmethod
    def _convert_to_messages(messages: Union[Iterable[MessageLikeRepresentation], PromptValue]) -> list[BaseMessage]:
        """Convert a sequence of messages to a list of messages."""
        if isinstance(messages, PromptValue):
            return messages.to_messages()
        return [convert_to_message(m) for m in messages]
