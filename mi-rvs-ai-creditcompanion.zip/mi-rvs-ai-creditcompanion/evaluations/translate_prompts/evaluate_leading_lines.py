#%%
from dotenv import load_dotenv
load_dotenv()
from nltk.translate.bleu_score import sentence_bleu
from chatrd.engine.components.query_analyzer.translator.translator import InputModerationTranslator
from tqdm import tqdm 
import mlflow
import numpy as np
import mlflow
from chatrd.core.embedding import embedding_factory
import json 
import nltk



with open('evaluations/data/translation_data/leading_lines.txt', 'r') as file :
    sentences = file.read().split('\n')
languages = [ "French", "Japanese", "Korean", "Mandarin", "Spanish"]
import pandas as pd 
dataset = pd.DataFrame()
dataset['English'] = sentences

for language  in languages:

    my_model = InputModerationTranslator()
    responses,scores,rev_translate = [],[],[]
    for sentence in sentences:
        res = my_model.translator(sentence,language)
        responses.append(res)
    for translation, eng_sentence in zip(responses, sentences):
        res= my_model.translator(translation, "English")
        rev_translate.append(res)
        score = sentence_bleu([eng_sentence.split(),], res.split())
        scores.append(score)
    dataset[language]  = scores
    dataset[language+'_tr']  = rev_translate

dataset.to_excel('result.xlsx')
