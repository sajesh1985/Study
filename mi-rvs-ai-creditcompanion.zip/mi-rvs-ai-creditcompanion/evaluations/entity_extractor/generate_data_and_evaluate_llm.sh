# !/bin/bash
set -e


/home/sagemaker-user/.conda/envs/chatrd/bin/python evaluations/entity_extractor/generate_data.py \
    --entity-data-dir evaluations/data/entity_extraction/template_entities/ \
    --question-template-dir evaluations/data/entity_extraction/template_questions/ \
    --output-path evaluations/data/entity_extraction/generated_data/ \
    --num-combinations 1 \
    --seed 42 \
    --train-eval eval


/home/sagemaker-user/.conda/envs/chatrd/bin/python evaluations/entity_extractor/run_evaluation_llm.py \
    --input-template-questions-path evaluations/data/entity_extraction/generated_data/evaluation/generated_questions.json \
    --n-repeats 1 \
    --samples-count 2 \
    --seed 12 \
    --output-path evaluations/entity_extractor/evaluation_results/llm/ \
    --prompt-id v8_test \
    --models-list haiku
