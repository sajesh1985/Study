package com.fis.digitalpayments.sdk;

import android.content.Context;
import androidx.annotation.NonNull;
import android.view.KeyEvent;
import android.webkit.WebSettings;
import android.webkit.WebView;

import com.fis.digitalpayments.sdk.core.BridgeException;
import com.fis.digitalpayments.sdk.core.BridgeJavascriptInterface;
import com.fis.digitalpayments.sdk.core.BridgeMessage;
import com.fis.digitalpayments.sdk.core.BridgeMessageCode;
import com.fis.digitalpayments.sdk.core.SemVer;
import com.fis.digitalpayments.sdk.messaging.WebEventListener;

/**
 * Convenience class for integrating the SDKManager.
 */
public class SDKManager {

    private BridgeJavascriptInterface mBridgeJavascriptInterface;
    private WebView mWebView;

    public static SDKManager create(@NonNull Context context, @NonNull WebView webView, @NonNull String[] domainWhitelist) {
        return SDKManager.create(context, webView, domainWhitelist, null);
    }

    public static SDKManager create(@NonNull Context context, @NonNull WebView webView, @NonNull String[] domainWhitelist, WebEventListener webEventListener)
    {
        return new SDKManager(context, webView, domainWhitelist, webEventListener, true);
    }

    public static SDKManager create(@NonNull Context context, @NonNull WebView webView, @NonNull String[] domainWhitelist, WebEventListener webEventListener, boolean isDisclosureEnabled)
    {
        return new SDKManager(context, webView, domainWhitelist, webEventListener, isDisclosureEnabled);
    }

    public void dispose() {
        mWebView.removeJavascriptInterface(BridgeJavascriptInterface.name);
        mWebView = null;
        mBridgeJavascriptInterface = null;
    }

    private SDKManager(@NonNull Context context, @NonNull WebView webView, @NonNull String[] domainWhitelist, WebEventListener webEventListener, boolean isDisclosureEnabled) {
        if (!webView.getSettings().getJavaScriptEnabled()) {
            throw new RuntimeException(new BridgeException("WebView must be javascript enabled."));
        }

        mWebView = webView;
        mBridgeJavascriptInterface = new BridgeJavascriptInterface(context, webView, domainWhitelist, webEventListener, isDisclosureEnabled);
        webView.addJavascriptInterface(mBridgeJavascriptInterface, BridgeJavascriptInterface.name);
    }

    @SuppressWarnings("UnusedReturnValue")
    public boolean checkNavigateBack(int keyCode, KeyEvent event) {
        boolean didNavigate = false;
        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            if (keyCode == KeyEvent.KEYCODE_BACK) {
                navigateBack();
                didNavigate = true;
            }
        }
        return didNavigate;
    }

    private void navigateBack() {
        if (mWebView != null && mBridgeJavascriptInterface != null) {
            mWebView.loadUrl(mBridgeJavascriptInterface.getWebEventBridge().getClientMessageJavascript(BridgeMessage.CreateActionRequest(BridgeMessageCode.NAVIGATE_BACK)));
        }
    }

    public static SemVer getVersion(Context context) {
        int versionMajor = Integer.parseInt(context.getString(R.string.fis_meta_app_version_major));
        int versionMinor = Integer.parseInt(context.getString(R.string.fis_meta_app_version_minor));
        int versionPatch = Integer.parseInt(context.getString(R.string.fis_meta_app_version_patch));
        String prerelease = context.getString(R.string.fis_meta_app_version_name_suffix);

        return new SemVer(versionMajor, versionMinor, versionPatch, prerelease);
    }
}
