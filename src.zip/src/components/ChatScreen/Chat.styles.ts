import styled from '@emotion/styled';
import { DARK } from '@spglobal/koi-helpers';
import { Breakpoints } from '@spglobal/tokens';

export const Timeline = styled.ul`
  padding: 0;
  margin: 0;
`;

export const Navbar = styled.div`
  display: flex;
  gap: var(--size-space-sm);
`;

export const ScrollBottomLi = styled.li`
  display: block;
`;

export const Example = styled.div`
  background: var(--color-bg-secondary);
  border: 1px solid var(--color-border-primary);
  justify-content: space-between;
  display: flex;
  align-items: center;
  cursor: pointer;
  min-width: 200px;
  color: var(--color-text-link);
  padding: var(--size-space-sm);
  gap: var(--size-space-sm);
  flex: 1;

  &:hover {
    background-color: var(--color-bg-hover);
  }

  & > span {
    text-align: left;
    font: var(--font-body-sm);
  }

  & > [data-icon] {
    color: var(--color-text-link);
  }
  .${DARK} & {
    border-color: var(--color-base-gray-80);
  }
`;

export const InlineExample = styled.div`
  display: flex;
  margin-top: var(--size-space-sm);
  gap: var(--size-space-sm);
  flex: 1;
  flex-wrap: wrap;
`;

export const ExampleBoxWrapper = styled.div`
  display: flex;
  gap: var(--size-space-lg);
  width: 100%;
  flex-wrap: wrap;
  padding-bottom: var(--size-space-xl);
  @media (max-width: ${Breakpoints.LG}) {
    padding: var(--size-space-lg);
  }
`;
export const ExampleBox = styled.div`
  flex: 1;
  border-radius: 12px;
  overflow: hidden;
  margin-right:6px;
  height:241px;
  background: var(--color-base-white);
  box-shadow: 0px 4px 8px 0px rgba(0, 0, 0, 0.07);
  .${DARK} & {
    background: #2d2d2d;
    box-shadow: 0px 4px 8px 0px rgba(0, 0, 0, 0.15);
  }
`;
export const ExampleBoxHead = styled.div`
  padding: var(--size-space-sm);
  display: flex;
  gap: 10px;
  align-items: center;
  align-content: center;
  background: var(--color-base-gray-1);
  > svg > circle {
    stroke: var(--color-base-gray-20);
  }
  > span {
    font-family: "Akkurat";
    font-size: 15px;
    font-style: normal;
    font-weight: 700;
    line-height: normal;
    color: var(--color-base-black);
  }
  .${DARK} & {
    background: var(--color-dark-gray-75);
    > svg > circle {
      stroke: var(--color-base-gray-65);
    }
    > span {
      color: var(--color-base-gray-11);
    }
  }
`;
export const ExampleBoxLists = styled.div`
  padding: var(--size-space-xs) var(--size-space-lg);
`;
export const ExampleList = styled.div`
  padding-bottom: var(--size-space-md);
  padding-top: var(--size-space-sm);
  border-bottom: 1px solid var(--color-base-gray-11);
  display: flex;
  justify-content: space-between;
  font-size: var(--size-font-3);
  color: var(--color-text-link);
  cursor: pointer;
  gap: 5px;
  align-items: center;
  > span {
    text-align: left;
    font-family: "Akkurat";
    font-size: 14px;
    font-style: normal;
    font-weight: 400;
    line-height: 17px;
  }
  & > [data-icon] {
    color: var(--color-text-link);
  }
  &:last-child {
    border: none;
  }
  .${DARK} & {
    border-color: #3b3b3b;
  }
`;

export const SliderMain = styled.div`
  .red {
    color: #d6002a;
    font-weight: 700;
  }

  .animation {
    -webkit-transition: 0.35s ease-in-out;
    -moz-transition: 0.35s ease-in-out;
    -o-transition: 0.35s ease-in-out;
    transition: 0.35s ease-in-out;
  }
`;

export const Slider = styled.div`
  position: relative;
  display: flex;
  flex-wrap: wrap;
  gap: 80px;
  align-items: center;
  justify-content: space-between;
`;

export const SliderText = styled.div`
  font-size: 20px;
  line-height: 160%;
  flex: 1;
  min-width: 200px;
`;

export const SliderImgWrapCircle = styled.div`
  position: absolute;
  top: calc(50% - 181px);
  width: 362px;
  height: 362px;
  left: calc(50% - 181px);
  background: #e9e9e9;
  border-radius: 50%;
  .${DARK} & {
    background: #1b1b1b;
  }
`;
export const SliderDots = styled.div`
  display: flex;
  justify-content: center;
  gap: 10px;
  align-items: center;
  padding-top:20px;
  span {
    cursor: pointer;
    display: inline-block;
  }
  span:not([data-icon]) {
    width: 10px;
    height: 10px;
    border-radius: 50%;
    border: 1px solid #737676;
    &.active {
      background: #347bb7;
      border-color: #347bb7;
    }
  }
`;

