CSV_DELIMITER = "\x1f"

DEFAULT_LLM = "claude-3-haiku"

MAIN_LLMS = [
    "claude-3-haiku",
    "claude-3-sonnet",
    "llama3-8b",
    "llama3-70b",
]

DATA_SERVICE_LLMS = ["claude-3-haiku"]
