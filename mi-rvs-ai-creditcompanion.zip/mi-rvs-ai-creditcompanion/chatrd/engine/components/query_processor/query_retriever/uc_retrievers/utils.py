import calendar
from datetime import datetime
from enum import Enum
from typing import Union

from pydantic import BaseModel


class UCRetrieverType(Enum):
    CRITERIA = "criteria"
    RESEARCH = "research"
    ESG = "esg"
    RATINGS = "ratings"
    OUTLOOK = "outlook"
    PEERS = "peers"
    DEFINITION = "definition"
    FINANCIALS = "financials"
    SWOT = "sNw"
    QUERY = "query"
    CREDIT_MEMO = "credit_memo"
    GENERAL = "general"
    MACRO = "macro"
    DEALS_TRANCHE = "deals_tranche"
    RATING_ACTION = "rating_action"
    SCORES_MODIFIER = "scores&modifiers"
    SECURITIES = "securities"
    INFO_COVERAGE = "info_coverage"
    SELECTED_ARTICLE = "selected_article"


class OutlookRetrieverModel(BaseModel):
    require_data_service: bool
    require_documents: bool


class RetrieverModel(BaseModel):
    summary: bool
    forecast: bool


class GeneralRetrieverModel(BaseModel):
    question: str
    is_micro: bool
    is_macro: bool


class ProcessedRetrieverDates(BaseModel):
    start_date: Union[str, None]
    end_date: Union[str, None]


def get_date_values():
    # Get current date
    today = datetime.now()

    # Format current date as "Month Day, Year"
    current_date = today.strftime("%B %d, %Y")

    # Calculate current quarter
    quarter = (today.month - 1) // 3 + 1
    current_quarter = f"Q{quarter} {today.year}"

    # Calculate quarter date range
    quarter_start_month = (quarter - 1) * 3 + 1
    quarter_end_month = quarter * 3
    quarter_start_name = calendar.month_name[quarter_start_month]
    quarter_end_name = calendar.month_name[quarter_end_month]
    current_quarter_range = f"{quarter_start_name}-{quarter_end_name} {today.year}"

    return {
        "current_date": current_date,
        "current_quarter": current_quarter,
        "current_quarter_range": current_quarter_range,
    }
