from enum import Enum
from src.synthia.prompts.section_guideline_prompts import (
    company_description,
    key_financials,
    sector_and_risk_analysis,
    sp_current_rating,
    sp_ratings_history,
    credit_outlook,
    analyst_peers,
    news_key_developments,
    swot_analysis,
    moody_fitch_analysis,
)


class SectionTitle(str, Enum):
    COMPANY_DESCRIPTION = "Company Description"
    KEY_FINANCIALS = "Key Financials (Sources & Uses of Liquidity)"
    SECTOR_RISK_ANALYSIS = "Sector & Industry Risk Analysis + CICRA"
    SP_CURRENT_RATINGS = "S&P Current Ratings"
    SP_RATINGS_HISTORY = "S&P Ratings History"
    CREDIT_OUTLOOK = "Credit Outlook"
    ANALYST_PEERS = "Analyst Peers / Peer Comps structured data"
    NEWS_KEY_DEVELOPMENTS = "News & Key Developments"
    SWOT_ANALYSIS = "SWOT Analysis"
    MOODY_FITCH_ANALYSIS = "Moody's & Fitch Ratings & History"
    GEOGRAPHIC_MIX = "Geographic Mix"
    SEGMENT_MIX = "Segment Mix"
    SHAREPRICE = "Share Price"
    SUMMARY_ANALYSIS = "Summary Analysis"


def map_string_to_enum(section_title: str) -> SectionTitle:
    """Maps a string title to the corresponding SectionTitle enum."""
    # Normalize the string for comparison
    normalized_title = section_title.strip()
    for title in SectionTitle:
        if title.value == normalized_title:
            return title
    return None  # or handle the error as needed


def get_system_prompt_for_section(section_title: str) -> str:
    """
    Returns the system prompt for a given section title.
    :param section_title: The title of the section as a string.
    :return: The system prompt for the section.
    """
    enum_title = map_string_to_enum(section_title)
    if enum_title is None:
        return ""  # Handle unknown section titles

    prompts = {
        SectionTitle.COMPANY_DESCRIPTION: company_description,
        SectionTitle.KEY_FINANCIALS: key_financials,
        SectionTitle.SECTOR_RISK_ANALYSIS: sector_and_risk_analysis,
        SectionTitle.SP_CURRENT_RATINGS: sp_current_rating,
        SectionTitle.SP_RATINGS_HISTORY: sp_ratings_history,
        SectionTitle.CREDIT_OUTLOOK: credit_outlook,
        SectionTitle.ANALYST_PEERS: analyst_peers,
        SectionTitle.NEWS_KEY_DEVELOPMENTS: news_key_developments,
        SectionTitle.SWOT_ANALYSIS: swot_analysis,
        SectionTitle.MOODY_FITCH_ANALYSIS: moody_fitch_analysis,
    }
    return prompts.get(enum_title, "")
