import copy
from dataclasses import dataclass
from typing import Dict, List, Optional

from .base import KPQI
from .variables import (
    FUNC_SECONDARY,
    FUNC_SECONDARY_DEFAULT_VALUE,
    FUNC_TERTIARY,
    FUNC_TERTIARY_DEFAULT_VALUE,
    KPQI_CUSTOM_VALUES,
    NUM_FUNC_SECONDARY,
    NUM_FUNC_SECONDARY_DEFAULT_VALUE,
    NUM_FUNC_TERTIARY,
    NUM_FUNC_TERTIARY_DEFAULT_VALUE,
    NUM_SECONDARY_KEYS,
    NUM_SECONDARY_KEYS_DEFAULT_VALUE,
    SECONDARY_KEYS,
    SECONDARY_KEYS_DEFAULT_VALUE,
)


@dataclass
class KPQIPayload:
    """
    This class helps to build default func and query fields for a given KPQI. In a
    SQL metaphor, you can consider func field as select statement and query field as
    where statement.
    """

    kpqi: KPQI

    def __init__(self, kpqi: KPQI):
        self.kpqi = kpqi
        self._defaults = copy.deepcopy(KPQI_CUSTOM_VALUES.get(kpqi, dict()))

    def default_num_func_field(self) -> Dict:
        """
        Build the default func field for numerical KPQI.
        Returns: A dictionary of func field values.

        """
        return self._default_func_field(
            secondary=self._defaults.get(NUM_FUNC_SECONDARY, NUM_FUNC_SECONDARY_DEFAULT_VALUE),
            tertiary=self._defaults.get(NUM_FUNC_TERTIARY, NUM_FUNC_TERTIARY_DEFAULT_VALUE),
        )

    def default_func_field(self) -> Dict:
        """
        Build the default func field for general use case.
        Returns: A dictionary of func field values.

        """
        return self._default_func_field(
            secondary=self._defaults.get(FUNC_SECONDARY, FUNC_SECONDARY_DEFAULT_VALUE),
            tertiary=self._defaults.get(FUNC_TERTIARY, FUNC_TERTIARY_DEFAULT_VALUE),
        )

    def default_query_field(self) -> Dict:
        """
        Build the default query field for general use case.
        Returns: A dictionary of query field values.

        """
        return self._default_query_field(
            secondary_keys=self._defaults.get(SECONDARY_KEYS, SECONDARY_KEYS_DEFAULT_VALUE),
        )

    def default_num_query_field(self) -> Dict:
        """
        Build the default query field for KPQI with numerical values.
        Returns: A dictionary of query field values.

        """
        return self._default_query_field(
            secondary_keys=self._defaults.get(NUM_SECONDARY_KEYS, NUM_SECONDARY_KEYS_DEFAULT_VALUE)
        )

    def _default_func_field(self, secondary: Optional[str] = None, tertiary: Optional[str] = None) -> Dict:
        """
        Helper function to build default func field.

        Most of the KPQIs have None as the default value for secondary and tertiary
        keys.
        Args:
            secondary (str): secondary key.
            tertiary (str): tertiary key.

        Returns: A dictionary with default values for the func field.

        """
        return {
            "primary": self.kpqi.value,
            "exportPrimary": self.kpqi.name,
            "secondary": secondary,
            "tertiary": tertiary,
            "contextJson": None,
            "originalSecondary": None,
            "originalTertiary": None,
            "context": None,
        }

    def _default_query_field(self, secondary_keys: Optional[List[Dict]]) -> Dict:
        """
        Helper function to build default query field.
        Args:
            secondary_keys (List[Dict]): Secondary filters for the query field.

        Returns: A dictionary that contains query field.

        """

        return {
            "field": {
                "fieldKey": self.kpqi.value,
                "exportFieldKey": self.kpqi.value,
                "secondaryKeys": secondary_keys,
            },
            "value": None,
            "displayText": "",
            "operator": 7,
            "connector": 0,
            "beginGroup": False,
            "endGroup": False,
            "relativeOperation": False,
            "queryItemId": "a1d9201e-7512-4b3c-9f29-180ebe44a75b",
            "supressSelect": False,
            "valueField": None,
            "mathOperator": 0,
            "mathValue": None,
            "sortStyle": None,
            "sortOrder": None,
            "functionName": None,
        }
