from typing import List

from pydantic import BaseModel


class EntityRephraseOutput(BaseModel):
    rephrased_questions: List[str] = []


REPHRASE_WITH_ENTITY_EXAMPLES = """
----------------------
{
    "question": "What is the latest research for xyz?",
    "extracted_entity": "xyz",
    "rephrase_entities": ["abc"]
    "output": {
        "rephrased_questions": [
            "What is the latest research for abc?",
        ]
    }
}
----------------------
{
    "question": "What is abc's strengths/weaknesses relative to its peers/competitors?",
    "extracted_entity": "abc",
    "rephrase_entities": ["xyz", "uvw"]
    "output": {
        "rephrased_questions": [
            "What is xyz's strengths/weaknesses relative to its peers/competitors?",
            "What is uvw's strengths/weaknesses relative to its peers/competitors?",
        ]
    }
}
----------------------
{
    "question": "What is the outlook for uvw according to S&P Global Ratings?",
    "extracted_entity": "uvw",
    "rephrase_entities": ["abc"]
    "output": {
        "rephrased_questions": [
            "What is the outlook for abc according to S&P Global Ratings?",
        ]
    }
}
----------------------
{
    "question": "When was the last downgrade of xyz's credit rating?",
    "extracted_entity": "xyz",
    "rephrase_entities": ["uvw", "qwe", "abc"]
    "output": {
        "rephrased_questions": [
            "When was the last downgrade of uvw's credit rating?",
            "When was the last downgrade of qwe's credit rating?",
            "When was the last downgrade of abc's credit rating?",
        ]
    }
}
----------------------
{
    "question": "What are the financial trends of xyz according to S&P Global Ratings?",
    "extracted_entity": "xyz",
    "rephrase_entities": ["uvw", "abc", "qwe", "asd"]
    "output": {
        "rephrased_questions": [
            "What are the financial trends of uvw according to S&P Global Ratings?",
            "What are the financial trends of abc according to S&P Global Ratings?",
            "What are the financial trends of qwe according to S&P Global Ratings?",
            "What are the financial trends of asd according to S&P Global Ratings?",
        ]
    }
}

"""


REPHRASE_WITH_ENTITY_PROMPTER_PROMPT = """
You are a helpful assistant that rephrases questions to include specific entities.

<instructions>
* Based on the question given in <question>, rephrase it to include the entities from <rephrase_entities> instead of <extracted_entity>.
* The rephrased question should be clear and contextually relevant, maintaining the original meaning and intent of the input question.
* Do NOT answer; only rephrase question to include the <extracted_entity>.
* Do NOT modify or abbreviate any entity names.
* <rephrase_entities> can be a list of entities to be included in the rephrased question. For each entity in the list, create a separate rephrased question and keep the order intact. 
* Output is valid only in a specified JSON format. Do not give any explanations and do not prepend or append any additional terms.

</instructions>

<formatting>
The output JSON object must contain the following property:
* "rephrased_questions"
</formatting>

<examples>
These examples are only used for understanding the task and the expected output format. Placeholder values are used in the examples to represent the actual values. Do not include these examples in your output.
{examples}
</examples>

<question>
{question}
</question>

<extracted_entity>
{extracted_entity}
</extracted_entity>

<rephrase_entities>
{rephrase_entities}
</rephrase_entities>

Return valid JSON output.
"""
