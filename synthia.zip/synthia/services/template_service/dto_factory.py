from src.synthia.persistence.template_metadata_repository import DatabaseTemplateMetadataRepository
from src.synthia.services.template_service.service import CompanyTemplate


columns = DatabaseTemplateMetadataRepository.Columns


def to_dto(metadata: dict) -> CompanyTemplate:
    company_id = metadata[columns.CompanyName]
    template_name = metadata[columns.TemplateName]

    return CompanyTemplate(
        company_id=company_id,
        template_id=metadata[columns.Id],
        tile_name=template_name,
        tile_description=metadata[columns.TemplateDescription],
        template_file_name=metadata[columns.TemplateConfigFileName]
    )
