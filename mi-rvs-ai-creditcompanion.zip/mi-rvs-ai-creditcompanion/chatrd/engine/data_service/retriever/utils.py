import json
import logging
from datetime import date, datetime
from decimal import ROUND_CEILING, ROUND_HALF_UP, Decimal, InvalidOperation
from importlib.resources import files
from typing import Dict, List, Optional

import numpy as np
import pandas as pd
import regex as re
from dateutil.relativedelta import relativedelta

from chatrd.engine.components.query_analyzer.filter_retrievers.base import FiltersInput
from chatrd.engine.components.query_analyzer.filter_retrievers.prompts import (
    TIME_THRESHOLD_PROMPT_DATE_OUTPUT,
    output_parser_time_threshold_dates,
)
from chatrd.engine.components.query_analyzer.filter_retrievers.time_threshold import (
    TimeThresholdFilter,
)
from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.data_service.kpqi import KPQI
from chatrd.engine.data_service.model_output_parser import company_parser
from chatrd.engine.data_service.model_output_parser.base_parser import CREDIT_ACTIONS
from chatrd.engine.data_service.model_output_parser.variables import (
    CONNECTOR_MAPPING,
    GLOBAL_CREDIT_RATING_MAPPING,
    OPERATOR_MAPPING,
)
from chatrd.engine.data_service.perspectives import Perspective, default_perspectives
from chatrd.engine.data_service.schema import Retriever, ScreenerPayload
from chatrd.engine.ratings_api import RatingsAPI

logger = logging.getLogger(__name__)

config_machinery = get_config_machinery()

FINANCIAL_METRICS_LIST = config_machinery.get_config_value(Constants.DataService.FINANCIAL_METRICS)
FINANCIAL_METRIC_DICT = {
    "FH": "Financial Highlights",
    "IS": "Income Statement",
    "BS": "Balance Sheet",
    "CF": "Cash Flow",
    "CA": "Capital Analysis",
    "CS": "Capital Structure",
    "SUPPL": "Supplemental",
}
FINANCIAL_METRICSECTOR_DICT = {
    "CORP": "Corporates",
    "FI": "Financial Institutions",
    "INS": "Insurance",
}
# Load the financial metrics list from the Financials_metrics_mapping file
metrics_list_path = files("chatrd.engine.data.data_service").joinpath(FINANCIAL_METRICS_LIST).resolve()
with open(metrics_list_path, "r") as f:
    all_metrics_list = json.load(f)
KPQI_LIST_FOR_FINANCIAL = []
for item in all_metrics_list:
    KPQI_LIST_FOR_FINANCIAL.append(item["MetricKPQI"])

PERSPECTIVE_MAPPING = {
    "company": 266637,
    "securities": 321247,
    "revenue_sources": 359303,
}

DEFAULT_POST_PROCESS_RETURN = (
    pd.DataFrame(),  # Empty DataFrame as a placeholder
    0,  # Default total_count
    {},  # Empty payload
    "",  # Empty URL
)


def get_payload_path(payload_file: str):
    config_machinery = get_config_machinery()
    payload_path = str(
        files("chatrd.engine.data.data_service").joinpath(config_machinery.get_config_value(payload_file)).resolve()
    )
    return payload_path


def get_payload(payload_file: str):
    payload_path = str(
        files("chatrd.engine.data.data_service").joinpath(config_machinery.get_config_value(payload_file)).resolve()
    )

    with open(payload_path) as fp:
        payload = json.load(fp)
    return payload


def change_to_supported(key_value_pairs: Dict) -> Dict:
    """
    Change values and operators of the payload to support business logic.
    Specific mostly for ChatRD.
    Args:
        key_value_pairs (Dict): A dictionary that contains users' input, processed
        outcome from LLMs.

    Returns: a modified key_value_pairs dict with custom values of fields.
    """
    # TODO: replace this logic once there will be a fuzzy matching of user's values and operators to valid values in the DB.
    for k, v in key_value_pairs.items():
        if k == 365227:
            default_value = (
                "'Strong','Above Average','Average','Sufficient','Below Average','Insufficient','Weak','Suspended','NR'"
            )
            if v["value"] not in default_value:
                logger.debug(f"Payload for 365227 KPQI value will be changed from '{v['value']}' to {default_value}")
                v["value"] = default_value
            if v["operator"] not in [7, 8]:
                logger.debug(f"Payload for 365227 KPQI operator will be changed from {v['operator']} to 7")
                v["operator"] = 7  # KPQI 365227 supports only in and not in operators
        if k == 365228:
            default_value = "'Positive','Developing','Stable','Negative','Watch Pos','Watch Dev','Watch Neg','NM','NR'"
            if v["value"] not in default_value:
                logger.debug(f"Payload for 365228 KPQI values will be changed from '{v['value']}' to {default_value}")
                v["value"] = default_value
            if v["operator"] not in [7, 8]:
                logger.debug(f"Payload for 365228 KPQI operator will be changed operator from {v['operator']} to 7")
                v["operator"] = 7  # KPQI 365228 supports only in and not in operators

    return key_value_pairs


def update_query_field(input_dict: Dict, query_field: Dict) -> Dict:
    """
    Dynamically update the query field based on users input.
    Args:
        input_dict (Dict): A dictionary that contains users input data.
        query_field (Dict): A query field with default values.

    Returns: A dictionary of updated query field.

    """
    value, connector, operator = (
        input_dict["value"],
        input_dict["connector"],
        input_dict["operator"],
    )

    query_field["value"] = value
    query_field["connector"] = connector
    query_field["operator"] = operator

    return query_field


def process_date_str(input_str: str) -> str:
    """
    Convert timestamp to the time format %Y-%m-%d.
    Args:
        input_str (str): the original date data from the Data Service API.

    Returns: A new date in the right format.

    """
    try:
        if not input_str:
            return None
        else:
            pattern = r"\(.*-"
            date_str = re.findall(pattern, input_str)[0][1:-1]
            dt = datetime.fromtimestamp(int(date_str) / 1000.0).strftime("%Y-%m-%d")
            return dt
    except ValueError:
        try:
            input_str = input_str[0]
            pattern = r"\(.*-"
            date_str = re.findall(pattern, input_str)[0][1:-1]
            dt = datetime.fromtimestamp(int(date_str) / 1000.0).strftime("%Y-%m-%d")
            return dt
        except IndexError:
            return None
    except IndexError:
        # New regex pattern to extract 'YYYY-MM-DD' from ISO-like strings
        try:
            iso_pattern = r"(\d{4}-\d{2}-\d{2})"
            match = re.search(iso_pattern, input_str)
            if match:
                return match.group(1)
            return None
        except:
            return None

    except:
        return None


def safe_round_to_two_decimals(value: str) -> str:
    """
    Rounds a given value to two decimal places using the ROUND_HALF_UP rounding method.

    This function attempts to convert the input value to a Decimal type and rounds it
    to two decimal places. If the conversion fails (e.g., the value is not numeric),
    the original value is returned unchanged.

    Args:
        value (str, int, float): The input value to be rounded. It can be a string,
                                 integer, or float.

    Returns:
        Decimal: The numeric value rounded to two decimal places if the conversion
                 is successful.
        Original value: If the conversion fails, the original input value is returned.

    Example:
        >>> safe_round_to_two_decimals('5.555') --> 5.56
        >>> safe_round_to_two_decimals('59.855')--> 59.86
        >>> safe_round_to_two_decimals('NA')    --> NA
        >>> safe_round_to_two_decimals('492')   --> 492.00
    """
    try:
        # Define the precision we want to round to (two decimal places)
        two_places = Decimal("0.01")

        # Convert the input string to a Decimal object and then use the quantize()
        # method to round it according to our specified rounding rule.
        rounded_value = Decimal(str(value)).quantize(two_places, rounding=ROUND_HALF_UP)
        return rounded_value
    except InvalidOperation:
        return value


def extract_dates(df, column_name: str = "S&P CREDIT RATING ACTION"):
    # Define a function to extract date from a string
    def get_date(text):
        if isinstance(text, str):
            # Use regex to find date patterns
            match = re.search(r"(\d{1,2}/\d{1,2}/\d{4})", text)
            if match:
                return match.group(1)
        return np.nan

    # Apply the function to both relevant columns and create a new column
    cols = [col for col in df.columns if column_name in col]
    col_names = []
    for i, col in enumerate(cols):
        col_name = f"{column_name}_{i}"
        df[col_name] = df[col].apply(get_date)
        df[col_name] = pd.to_datetime(df[col_name], format="%m/%d/%Y", errors="coerce")
        col_names.append(col_name)
    return df, col_names


def post_process_data(
    screener_payload_object, df: pd.DataFrame, analyzer_response: Dict = {}, numeric_columns: List = []
) -> pd.DataFrame:
    """
    Do a host or additional post-processing before returning final dataframe from chatrd.engine.data_service
    1. Update column names with magnitudes before displaying to user.
    2. If its a company perspective, filter to fewer fields based on
    whether a single or multiple rating types are requested. The default
    payload returns all fields to support the most broad query settings.

    Args:
        screener_payload_object (ScreenerPayload): Screener Payload object from screener call
        df (pd.DataFrame): df from screener call
        user_input (str): user input or query

    Returns:
        df (pd.DataFrame): dataframe with updated columns names
    """

    # UPDATE COLUMNS NAMES
    new_column_names = {}

    if screener_payload_object.magnitude_dict:
        logger.debug(f"Updating column names {screener_payload_object.magnitude_dict}")
        for k, v in screener_payload_object.magnitude_dict.items():
            if k.upper() in df.columns:
                new_column_names[k.upper()] = f"{k.upper()} ({v})"
        logger.debug(f"The new column names are {new_column_names}")

    if new_column_names:
        df = df.rename(columns=new_column_names)

    columns_all = df.columns.tolist()
    # process numeric fields to allow 2 decimal points
    for num_col in numeric_columns:
        if num_col in columns_all:
            df[num_col] = df[num_col].apply(safe_round_to_two_decimals)
    # process date fields
    columns_date = [e for e in columns_all if "DATE" in e and "ACTION DATE" not in e]
    for date_col in columns_date:
        mask = df[date_col] != "#OUTSIDE SUBSCRIPTION"
        df.loc[mask, date_col] = df.loc[mask, date_col].apply(process_date_str)
    # Limit and sort values by date
    if analyzer_response:
        if "order" in analyzer_response and analyzer_response["order"] is not None:
            credit_rating_columns = [
                col for col in df.columns if "S&P CREDIT RATING" in col and ("DATE" not in col and "ACTION" not in col)
            ]
            df, additional_columns = extract_dates(df)

            list_of_date_columns = additional_columns + [col for col in df.columns if "S&P CREDIT RATING DATE" in col]

            rating_order = [x.upper() for x in GLOBAL_CREDIT_RATING_MAPPING]
            for rating_col in credit_rating_columns:
                df[rating_col] = pd.Categorical(df[rating_col], categories=rating_order, ordered=True)

            if analyzer_response["order"] == "descending":
                df = df.sort_values(
                    by=credit_rating_columns + list_of_date_columns,
                    ascending=[True] * len(credit_rating_columns) + [False] * len(list_of_date_columns),
                )
            elif analyzer_response["order"] == "ascending":
                df = df.sort_values(
                    by=credit_rating_columns + list_of_date_columns,
                    ascending=True,
                )
            df[credit_rating_columns] = df[credit_rating_columns].astype(str).replace("nan", None)
        if "limit" in analyzer_response and analyzer_response["limit"] is not None:
            df = df.head(analyzer_response["limit"])
        else:
            n = config_machinery.get_config_value(Constants.GeneralConstants.NUM_ROWS_TO_DISPLAY)
            df = df.head(n)
    return df[columns_all]


def create_dynamic_column_header(
    screener_results: Dict,
    key_perspective: int,
    uc_type: str,
    financial_metrics_list: Optional[Dict] = None,
) -> List:
    """
    Extract column header information from the results returned from the Data Service API.
    This extractions is dependent on the key perspective, since the returned json
    is structured differentely based on the key perspective.
    Args:
        screener_results (Dict): The results from the Data Service API.
        key_perspective (int): The key perspective.

    Returns:

    """
    columns = []
    column_key = {}
    if key_perspective == 266637:
        # for company perspective
        for item in screener_results["functionResponses"][0]["headerInformation"]:
            col_name = item["displayCaption"].upper()
            if item.get("secondary", "") == "Financial Strength Rating" and uc_type == "ratings":
                col_name = f"{col_name} (FSR)"

            # Conditional block for CreditStats Direct KPQI
            if item["keyProductQueryItem"] in KPQI_LIST_FOR_FINANCIAL:
                magnitude = "(REPORTED)" if "$M" in item["magnitude"] else item["magnitude"]
                metric = get_financial_by_kpqi(item["keyProductQueryItem"], financial_metrics_list)
                metric_sector = metric.get("MetricSector", "")
                metric_type = metric.get("MetricType", "")
                metric_sub_type = metric.get("MetricSubType", "")
                col_name = f"{FINANCIAL_METRICSECTOR_DICT.get(metric_sector, '')} {FINANCIAL_METRIC_DICT.get(metric_type, '')} {metric_sub_type} {col_name} ({get_period_description(item['secondary'])}) {magnitude}"
                column_key[item["keyProductQueryItem"]] = [col_name, item["dataType"].lower()]
                columns.append(col_name)
            elif item["tertiary"]:
                if "|" in item["tertiary"]:
                    tertiary_date = item["tertiary"].split("|")[1]
                    if tertiary_date == "0" or tertiary_date.lower() == "current":
                        tertiary_date = "CURRENT"
                    if tertiary_date == "1" or tertiary_date.lower() == "prior":
                        tertiary_date = "PRIOR"
                    if tertiary_date.lower() == "prior" and uc_type == "ratings":
                        columns.append(f"{col_name} {(str(item['tertiary']).split('|')[0]).upper()} (PRIOR)")
                        continue
                else:
                    tertiary_date = "CURRENT"

                if ("S&P CREDIT RATING ACTION" in col_name and uc_type == "query") and ("DATE" not in col_name):
                    columns.append(
                        f"{col_name} (ACTION DATE) ({str(item['secondary']).upper()} / {(str(item['tertiary']).split('|')[0]).upper()}) ({tertiary_date}) (MM/DD/YYYY)"
                    )

                elif "S&P CREDIT RATING" in col_name and uc_type == "query":
                    if "DATE" not in col_name:
                        columns.append(
                            f"{col_name} ({str(item['secondary']).upper()} / {(str(item['tertiary']).split('|')[0]).upper()}) ({tertiary_date})"
                        )
                    else:
                        columns.append(
                            f"{col_name} ({str(item['secondary']).upper()} / {(str(item['tertiary']).split('|')[0]).upper()}) ({tertiary_date}) (MM/DD/YYYY)"
                        )
                elif "S&P CREDITWATCH/OUTLOOK" in col_name and uc_type == "query":
                    if "DATE" not in col_name:
                        columns.append(
                            f"{col_name} ({str(item['secondary']).upper()} / {(str(item['tertiary']).split('|')[0]).upper()}) ({tertiary_date})"
                        )
                    else:
                        columns.append(
                            f"{col_name} ({str(item['secondary']).upper()} / {(str(item['tertiary']).split('|')[0]).upper()}) ({tertiary_date}) (MM/DD/YYYY)"
                        )

                elif (
                    "foreign currency" in item["tertiary"].lower()
                    and "last review date" not in item["displayCaption"].lower()
                    and uc_type == "query"
                ):
                    if ("S&P CREDIT RATING ACTION" in col_name or "S&P CREDIT RATING" in col_name) and (
                        "DATE" not in col_name
                    ):
                        columns.append(
                            f"{col_name} ({str(item['secondary']).upper()} / {(str(item['tertiary']).split('|')[0]).upper()}) (CURRENT)"
                        )
                    else:
                        columns.append(
                            f"{col_name} ({str(item['secondary']).upper()} / {(str(item['tertiary']).split('|')[0]).upper()})"
                        )
                else:
                    columns.append(f"{col_name} {(str(item['tertiary']).split('|')[0]).upper()}")
            else:
                if col_name == "INDUSTRY CLASSIFICATION":
                    col_name = "MI INDUSTRY CLASSIFICATION"
                columns.append(col_name)
    elif key_perspective == 321247:
        # for securities perspective
        for item in screener_results["functionResponses"][0]["headerInformation"]:
            col_name = item["displayCaption"].upper()
            if item["secondary"] and (item["tertiary"] == "1" or item["tertiary"] == "Prior"):
                columns.append(f"{col_name} {item['secondary'].upper()} (PRIOR)")
            elif item["secondary"]:
                columns.append(f"{col_name} {item['secondary'].upper()}")
            else:
                columns.append(col_name)
    elif key_perspective == 359303:
        # for revenue sources perspective
        for item in screener_results["functionResponses"][0]["headerInformation"]:
            col_name = item["displayCaption"].upper()
            if item["secondary"] and (item["tertiary"] == "1" or item["tertiary"] == "Prior"):
                columns.append(f"{col_name} {item['secondary'].upper()} (PRIOR)")
            elif item["secondary"]:
                columns.append(f"{col_name} {item['secondary'].upper()}")
            else:
                columns.append(col_name)
    else:
        # legacy support that was used for all perspectives
        for item in screener_results["functionResponses"][0]["headerInformation"]:
            col_name = item["displayCaption"].upper()
            if item["tertiary"] and ("LT|1" in item["tertiary"] or item["tertiary"] == "1"):
                columns.append(f"{col_name} (PRIOR)")
            else:
                columns.append(col_name)

    return columns, column_key


def get_keyinstn_id(entities: dict):
    keyinstn_id = entities["companies"][0]["mi_id"]
    return keyinstn_id


def get_multiple_keyinstn_id(entities: dict):
    mi_ids = [company["mi_id"] for company in entities.get("companies", []) if "mi_id" in company]
    return ",".join(map(str, mi_ids))


def get_security_info(entities: dict):
    url = entities["securities"][0]["url"][0]
    keyinstn_id, instrument_id, security_symbol_value = re.findall(r"\d+", url)
    return (keyinstn_id, instrument_id, security_symbol_value)


def get_key_item_ids(metrics_mapping: dict, metric_names: List[str]):
    """
    Extract key item IDs from metrics mapping dictionary based on metric names.

    Parameters:
    metrics_mapping: Dictionary where keys are Item Names and values are Long Captions
    metric_names (list): List of metric names to search for in the 'Long Caption' column

    Returns:
    str: A comma-separated string of unique item IDs corresponding to the specified metric names.
    For example: 'CIQ045221,CIQ045223,CIQ044019'
    """
    metric_name_set = set(metric_names)
    normalized_metric_names = {metric.replace(" ", "").lower() for metric in metric_name_set}

    key_item_ids_mapping = {
        item["MetricCode"]: item["MetricName"]
        for item in metrics_mapping
        if isinstance(item["MetricName"], str)
        and item["MetricName"].replace(" ", "").lower() in normalized_metric_names
    }

    metricFields = ",".join(key_item_ids_mapping.keys())
    return metricFields, key_item_ids_mapping


def _retrieve(
    endpoint_path,
    parameter: Optional[str] = "",
    data_ids=(),
    api_method: Optional[str] = "GET",
    data: Optional[Dict] = None,
):
    endpoint = config_machinery.get_config_value(endpoint_path)
    response, url, api_type = RatingsAPI().get_response(endpoint, parameter, api_method, data=data)
    screener_payload = {"data": data, "parameters": {}}

    if response is None or len(response) == 0:
        logger.info(f"No data found from the endpoint: {endpoint} with the parameter {parameter}")
        return Retriever()

    return Retriever(
        api_data=response,
        screener_payload=screener_payload,
        url=url,
        total_count=len(response),
        api_method=api_method,
        api_type=api_type,
    )


def field_search(
    response_dict: dict,
    entities: dict,
    key_perspective: Optional[int],
    key_perspective_str: Optional[str],
    user_input: Optional[str] = None,
    vector_database_path: Optional[str] = None,
    perspective_parser: Optional[company_parser.CompanyItemParser] = None,
    filters_input: Optional[FiltersInput] = None,
):

    perspectives = default_perspectives(vectors_path=vector_database_path)
    perspectives_dict: Dict[str, Perspective] = {p.name: p for p in perspectives}

    payload_dict = {}
    text_dict = {}
    magnitude_dict = {}

    # Create a new dictionary excluding keys that contain 'financial'
    response_dict = {k: v for k, v in response_dict.items() if "financial" not in k}

    for key, value in response_dict.items():
        if key in ["type", "order", "limit"]:
            continue
        elif key in str(KPQI.RD_CREDIT_RATING_GLOBAL.value):  # S&P Credit Rating
            text_dict["S&P Credit Rating"] = value.copy()
            connector_value = CONNECTOR_MAPPING["and"]
            operator_value = OPERATOR_MAPPING["in"]
            value.update({"connector": connector_value, "operator": operator_value, "data_type": "string"})
            payload_dict[int(key)] = value
        elif key in str(KPQI.RD_CWOL_GLOBAL.value):  # S&P CreditWatch/Outlook
            text_dict["S&P CreditWatch/Outlook"] = value.copy()
            connector_value = CONNECTOR_MAPPING["and"]
            operator_value = OPERATOR_MAPPING["in"]
            value.update({"connector": connector_value, "operator": operator_value, "data_type": "string"})
            payload_dict[int(key)] = value
        elif key in str(KPQI.RD_RATING_ACTION_GLOBAL.value):  # S&P Credit Rating Action
            text_dict["S&P Credit Rating Action"] = value.copy()
            connector_value = CONNECTOR_MAPPING["and"]
            operator_value = OPERATOR_MAPPING["equal"]
            if isinstance(value.get("value", None), str):
                action_values = [v.strip() for v in value["value"].split(",")]
                updated_values = [CREDIT_ACTIONS.get(av.upper(), av.upper()) for av in action_values]
                value["value"] = ",".join(updated_values)
            value.update({"connector": connector_value, "operator": operator_value, "data_type": "nstring"})
            payload_dict[int(key)] = value
        elif key == "industry" and value.get("display_column", False):  # Industry
            payload_dict[KPQI.RD_SECTOR.value] = {
                "value": None,
                "connector": CONNECTOR_MAPPING["and"],
                "operator": OPERATOR_MAPPING["in"],
                "display_column": True,
                "data_type": "string",
            }
            text_dict["S&P Global Ratings Sector"] = {
                "value": None,
                "connector": "and",
                "operator": "in",
                "display_column": True,
            }
            # payload for MI Industry
            payload_dict[KPQI.IndustryClassification.value] = {
                "value": None,
                "connector": CONNECTOR_MAPPING["and"],
                "operator": OPERATOR_MAPPING["in"],
                "display_column": True,
                "data_type": "string",
            }
            text_dict["S&P Market Intelligence"] = {
                "value": None,
                "connector": "and",
                "operator": "in",
                "display_column": True,
            }
        elif key == "geography" and value.get("display_column", False):  # Geography
            payload_dict[KPQI.Geography.value] = {
                "value": None,
                "connector": CONNECTOR_MAPPING["and"],
                "operator": OPERATOR_MAPPING["in"],
                "display_column": True,
                "data_type": "string",
            }
            text_dict["Geography"] = {"value": None, "connector": "and", "operator": "in", "display_column": True}
        else:
            (
                tmp_payload_dict,
                tmp_text_dict,
                tmp_magnitude_dict,
            ) = perspective_parser.parse(
                key=key,
                value=value,
                perspectives_dict=perspectives_dict,
                key_perspective_str=key_perspective_str,
                entities=entities,
            )
            if isinstance(tmp_payload_dict, list) and isinstance(tmp_text_dict, list):
                # If the payload is a list, it means multiple KPQIs were returned.
                for i, item in enumerate(tmp_payload_dict):
                    kpqi = item["key"]
                    if KPQI.RD_SECTOR.value == kpqi:
                        text_kpqi = "S&P Global Ratings Sector"
                    elif KPQI.IndustryClassification.value == kpqi:
                        text_kpqi = "S&P Market Intelligence"
                    else:
                        text_kpqi = tmp_text_dict[i]["key"]
                    if kpqi not in payload_dict:
                        payload_dict[kpqi] = item["value"]
                        text_dict[text_kpqi] = tmp_text_dict[i]["value"]
                    else:
                        # update existing values.
                        payload_dict[kpqi][
                            "value"
                        ] = f"""'{payload_dict[kpqi]["value"]}',
                        '{item['value']['value']}'"""
                        text_dict[text_kpqi][
                            "value"
                        ] = f"""'{text_dict[text_kpqi]["value"]}',
                        '{item['value']['value']}'"""
                if tmp_magnitude_dict:
                    magnitude_dict.update(tmp_magnitude_dict)
            elif tmp_payload_dict:
                kpqi = tmp_payload_dict["key"]
                if KPQI.RD_SECTOR.value == kpqi:
                    text_kpqi = "S&P Global Ratings Sector"
                elif KPQI.IndustryClassification.value == kpqi:
                    text_kpqi = "S&P Market Intelligence"
                else:
                    text_kpqi = tmp_text_dict["key"]

                if kpqi not in payload_dict:
                    payload_dict[kpqi] = tmp_payload_dict["value"]
                    text_dict[text_kpqi] = tmp_text_dict["value"]
                else:
                    # update existing values.
                    payload_dict[kpqi][
                        "value"
                    ] = f"""'{payload_dict[kpqi]["value"]}',
                    '{tmp_payload_dict['value']['value']}'"""
                    text_dict[text_kpqi][
                        "value"
                    ] = f"""'{text_dict[text_kpqi]["value"]}',
                    '{tmp_text_dict['value']['value']}'"""
                if tmp_magnitude_dict:
                    magnitude_dict.update(tmp_magnitude_dict)
            else:
                # Empty result, move to the next KPQI.
                continue

    # Update the payload_dict with the correct KPQI codes
    payload_dict = kpqi_update(payload_dict)

    logger.info(f"The payload_dict is {payload_dict}, text_dict is {text_dict}")
    return ScreenerPayload(
        key_perspective=key_perspective,
        key_perspective_str=key_perspective_str,
        payload_dict=payload_dict,
        text_dict=text_dict,
        magnitude_dict=magnitude_dict,
        model_response_text=str(response_dict),
    )


def kpqi_update(payload_dict):
    # Fix wrong KPQI codes
    kqpi_mapping = {
        333814: 334045,  # S&P Credit Rating
        334017: 333832,  # S&P Credit Rating Action
        336044: 336004,  # S&P Credit Rating Date
        333845: 334235,  # S&P CreditWatch/Outlook
        336042: 336003,  # S&P CreditWatch/Outlook Date
        334018: 333833,  # S&P Last Review Date
    }

    # Create a new dictionary to hold updated values
    updated_payload = {}
    for current_key in payload_dict:
        # Update KPQI codes if necessary
        if int(current_key) in kqpi_mapping:
            new_key = kqpi_mapping[int(current_key)]
            updated_payload[new_key] = payload_dict[current_key]
        else:
            updated_payload[current_key] = payload_dict[current_key]
    return updated_payload


def get_financial_by_kpqi(kpqi, financial_metrics_list):
    """
    Retrieve an metric from the financial metrics list by MetricKPQI.

    Args:
        kpqi (str): The MetricKPQI value to search for.
        financial_metrics_list (list): A list of dictionaries containing financial metrics.

    Returns:
        dict or None: The matching dictionary if found, otherwise None.
    """
    for item in financial_metrics_list:
        if item.get("MetricKPQI") == kpqi:
            return item
    return None


def get_period_description(secondary: str) -> str:
    """
    Checks the value of 'secondary' and returns the corresponding period description.
    If no match is found, returns the input value as it is.

    Args:
        secondary (str): The value to check (e.g., 'FY0', 'FQ0', 'LTM', 'FH0').

    Returns:
        str: The corresponding period description, or the input value if no match is found.
    """
    period_mapping = {
        "FY0": "Latest Fiscal Year",
        "FQ0": "Latest Fiscal Quarter",
        "LTM": "Last Twelve Months",
        "FH0": "Latest Half-Year",
    }

    return period_mapping.get(secondary, secondary)
