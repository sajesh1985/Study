from enum import Enum

DEFAULT_GLOBAL_RATING_FAMILY = [334045, 334235, 333832, 333833, 336004, 336003]
DEFAULT_CREDIT_RATING_FAMILY = [334045, 336004]
DEFAULT_CREDIT_RATING_ACTION_FAMILY = [333832, 334045, 334235]  # 334311
DEFAULT_CREDIT_WATCH_OUTLOOK_FAMILY = [334235, 336003]
DEFAULT_NATIONAL_RATING_FAMILY = set()  # TODO: add values later.
DEFAULT_SECURITY_FAMILY = {
    337537,
    337538,
    338482,
    338483,
    337539,
    337540,
    321280,
    321281,
    364983,
    359323,
}

ALL_RD_SECTORS = "3605366"

DEFAULT_TRANSACTION_FUNCTION_FIELDS = {
    320342,  # Transaction Entity Type
    300085,  # KeyInstnTargetIssuer
    300095,  # Deal status
    300057,  # Transaction Value ($M)
    324281,  # Institution Name/buyer
    324283,  # Institution Name/seller
    300056,  # Transaction Announcement Date
    # 300054,  # MI Transaction ID
}


class KPQI(Enum):
    @staticmethod
    def values():
        return {k.value for k in KPQI}

    @staticmethod
    def names():
        return {k.name for k in KPQI}

    @staticmethod
    def rating_values():
        return set(DEFAULT_GLOBAL_RATING_FAMILY) | set(DEFAULT_NATIONAL_RATING_FAMILY)

    @staticmethod
    def global_rating_values():
        return set(DEFAULT_GLOBAL_RATING_FAMILY)

    @staticmethod
    def national_rating_values():
        return set(DEFAULT_NATIONAL_RATING_FAMILY)

    @staticmethod
    def securities_values():
        return set(DEFAULT_SECURITY_FAMILY)

    IndustryClassification = 321213
    RD_SECTOR = 342649
    Geography = 321214
    Global_Region = 275915
    Global_Subregion = 275914
    # Country_Region_Name = 275913
    State = 275805
    Company_Status = 275891
    Company_Type = 322992
    Total_Revenue = 329251
    Primary_Industry = 275904
    SIC_Code = 275893
    Regulatory_Filer_Type = 311177
    Total_Amount_Raised = 327741
    Postal_Code = 275919
    Exchange = 271669
    Business_Description = 275889
    Company_Name = 275884
    Entity_ID = 267961
    Membership_Description = 313475
    ISIN = 275895
    Market_Cap = 329249
    Year_Established = 275902
    SPCIQ_ID = 312198
    MI_KEY = 267964
    # Transactions KPQIs
    KPQI_320342 = 320342
    KPQI_300056 = 300056
    KPQI_300095 = 300095
    KPQI_300092 = 300092
    KPQI_300057 = 300057
    KPQI_326143 = 326143
    KPQI_300093 = 300093
    KPQI_326144 = 326144
    KPQI_325191 = 325191
    KPQI_312191 = 312191
    KPQI_300202 = 300202
    KPQI_300097 = 300097
    KPQI_329776 = 329776
    KPQI_300054 = 300054
    KPQI_300194 = 300194
    KPQI_300085 = 300085
    KPQI_330046 = 330046
    KPQI_300091 = 300091
    KPQI_330184 = 330184
    KPQI_300132 = 300132
    KPQI_325192 = 325192
    KPQI_338711 = 338711
    KPQI_312192 = 312192
    KPQI_300055 = 300055
    KPQI_328477 = 328477
    KPQI_326140 = 326140
    KPQI_324281 = 324281
    KPQI_367810 = 367810

    # The following are ChatRD fields.
    RD_CREDIT_RATING_GLOBAL = 334045
    RD_CWOL_GLOBAL = 334235
    RD_RATING_ACTION_GLOBAL = 333832
    RD_LAST_REVIEW_DATE_GLOBAL = 333833
    RD_CREDIT_RATING_DATE_GLOBAL = 336004
    RD_CREDIT_WATCH_OUTLOOK_DATE_GLOBAL = 336003
    RD_KEY_REVENUE_SOURCE = 360954
    RD_RATING_ACTION_DATE_GLOBAL = 334311  # RD_RATING_ACTION_GLOBAL (date)
    # KPQI_333814 = 333814 # removing nationl scale ratings
    KPQI_333845 = 333845
    # KPQI_334017 = 334017 # removing S&P Credit Rating Action, 333832 should be used instead
    KPQI_334018 = 334018
    KPQI_336044 = 336044
    KPQI_336042 = 336042
    KPQI_365227 = 365227  # RD_SERVICER_EVALUATIONS_RANKING
    KPQI_365228 = 365228  # RD_SERVICER_EVALUATIONS_RANKING_WOL or Servicer Evaluations Ranking Watch/Outlook
    # KPQI_267964 = 267964  # SP_COMPANY_ID

    # security summary KPQIs
    KPQI_322513 = 322513
    RD_SEC_CWOL_GLOBAL = 337538
    KPQI_364983 = 364983
    KPQI_338483 = 338483
    KPQI_322519 = 322519
    KPQI_321280 = 321280
    RD_SEC_CREDIT_RATING_DATE_GLOBAL = 337539
    KPQI_322517 = 322517  # MI_KEY under securities
    RD_SEC_CREDIT_RATING_GLOBAL = 337537
    KPQI_359323 = 359323
    RD_SEC_CREDIT_WATCH_OUTLOOK_DATE_GLOBAL = 337540
    KPQI_338482 = 338482
    KPQI_321281 = 321281
    KPQI_322518 = 322518
    KPQI_321274 = 321274  # Description
    # RD_SEC_DEBT_TYPE = 363193
    # RD_SEC_DEBT_TYPE = 363191

    # revenue sources KPQIs
    RD_REVENUE_SOURCE_CREDIT_RATING = 362237
    RD_REVENUE_SOURCE_CWOL = 362238
    RD_REVENUE_SOURCE_CREDIT_RATING_ACTION = 362240
    RD_REVENUE_SOURCE_CREDIT_RATING_LAST_REVIEW_DATE = 363012
    RD_REVENUE_SOURCE_CREDIT_RATING_DATE = 362776
    RD_REVENUE_SOURCE_CREDIT_WATCH_OUTLOOK_DATE = 362775
    KPQI_361589 = 361589

    TransactionEntityType = 320342
    KeyInstnTargetIssuer = 300085
    DealStatus = 300095
    TransactionValue = 300057  # ($M)
    InstitutioName_buyer = 324281
    InstitutionName_seller = 324283
    TransactionAnnouncementDate = 300056
