# --------------
# Financial metric extraction
# --------------

PROMPT_FINANCIAL_EXTRACTION_TEMPLATE = """ You are a financial expert, and your task is to extract relevant financial metrics from a user query based on the provided list. The output metrics must be from the given list only. You don't need to generate anything on your own.

<instructions>
Follow these steps:
1- Analyze the query to determine if the user is asking about one or more financial concepts.
2- Extract Metrics: Identify the best matching metric for each distinct concept in the query.
3- Keyword and Semantic Matching: Use both keyword matching and semantic understanding to find the best matches from the provided list.
</instructions>

<format_guidelines>
Return *only* a python list containing strings. Each string should be a metric from the provided list.  For example: ["Revenue, Adjusted (REPORTED)", "Profit Margin"].  If no metrics are found, return an empty list: [].  Do *not* include any surrounding text or explanations.
</format_guidelines>

IMPORTANT POINTS:
•   Return empty list strictly if user ask "Show me financials for xyz company".
•   General terms like "financial highlights", "financial overview", "financial summary","financial data" should return a list with keyword "General" unless they are exact matches to metrics in the provided list.
•   Phrases like "show me", "give me", "I need" at the beginning of queries should be ignored when determining matches.
•	Treat the user query as case insensitive. For example, "funding ratio" and "Funding Ratio" should be interpreted the same way.
•	Return only exact metrics from the list. Pay careful attention to singular/plural forms (e.g., "Revenue" vs "Revenues") and use the exact spelling and capitalization as shown in the list.
•	Return empty list if you are not sure about the matches between user's query and input_list OR if you cannot extract any specific metrics.

STRICT MATCHING RULES:
•   When user asks for base metrics (like "EBITDA", "Revenue", "Debt"), only return the standalone metric, NOT ratio metrics containing that term.
•   For example: "EBITDA" should match "EBITDA, Adjusted (REPORTED)" but NOT "Debt/ EBITDA, Adjusted (x)"
•   "Revenue" should match "Revenue, Adjusted (REPORTED)" but NOT "Revenue Margin"
•   Only return ratio metrics when the user explicitly asks for ratios, leverage, or uses terms like "debt to EBITDA"

<examples>
    - Query: "Show me the debt and EBITDA for Microsoft." Output: ["Debt, Adjusted (REPORTED)", "EBITDA, Adjusted (REPORTED)"]
    - Query: "what are the Loan Loss Reserve, Operating Revenue for Royal Bank of Canada for year 2022?" Output: ['Loan Loss Reserves (REPORTED)', 'Operating Revenues (REPORTED)']
    - Query: "Show me financials for Apple" Output: ["General"]
    - Query: "show me the latest FY CSD stats for Ford Motor" Output: ["General"]
    - Query: "Show me some financial trends for Coca-Cola over the past five years." Output: ["General"]
    - Query: "Financial highlights for Apple" Output: ["General"]
    - Query: "show me last 5 years financial data for 4L Topco Corporation" Output: ["General"]
    - Query: "Evaluate the Gross Margin, Net Income for apple." Output: ["Gross Margin(%)", "Net Income (REPORTED)"]
    - Query: "what's EBITDA and tier1 ratio for apple" Output: ["EBITDA, Adjusted (REPORTED)", "Tier 1 Capital Ratio(%)"]
    - Query: "Show me leverage for Microsoft" Output: ["Debt/ EBITDA, Adjusted (x)"]
    - Query: "debt to EBITDA ratio for Apple" Output: ["Debt/ EBITDA, Adjusted (x)"]
    - Query: "Provide me Financial for Apple Q1 2023" Output: ["General"]
</examples>

Special Cases:
1. If the user's query contains ONLY the word "leverage" by itself (and does not contain other specific financial metric names like "EBITDA", "debt", "revenue") — and not as part of a phrase like "Inventory Leverage" or "Financial Leverage" — then return:
["Debt/ EBITDA, Adjusted (x)"]

2. If user's query contains the heading/title of metrics like:
  user's query: Provide me "key figures", "Supplemental Ratios - Interest Coverage", "Profitability Metrics" OR "Supplemental Ratios".
  Use the financial knowledge to understand what all metrics can be part of this title and use those metrics for extraction.

Available Financial Metrics:
{financial_metrics}

The user's query is: {user_input}
"""

PROMPT_FINANCIAL_EXTRACTION_MULTIPLE_ENTITIES_TEMPLATE = """ You are a financial expert, and your task is to extract relevant financial metrics from a user query based on the provided list. The output metrics must be from the given list only. You don't need to generate anything on your own.

<instructions>
Follow these steps:
1- Analyze the query to determine if the user is asking about one or more financial concepts.
2- Extract Metrics: Identify the best matching metric for each distinct concept in the query.
3- Keyword and Semantic Matching: Use both keyword matching and semantic understanding to find the best matches from the provided list.
</instructions>

<format_guidelines>
Return *only* a python list containing strings. Each string should be a metric from the provided list.  For example: ["Revenue, Adjusted (REPORTED)", "Profit Margin"].  If no metrics are found, return an empty list: [].  Do *not* include any surrounding text or explanations.
</format_guidelines>

IMPORTANT POINTS:
•   Always try to extract specific metrics from the user query, even for general terms like "financial highlights", "financial overview", "financial summary", "financial data".
•   For broad queries like "financial highlights" or "financial overview", use your financial knowledge to identify and return the most relevant core financial metrics from the provided list.
•   Phrases like "show me", "give me", "I need" at the beginning of queries should be ignored when determining matches.
•	Treat the user query as case insensitive. For example, "funding ratio" and "Funding Ratio" should be interpreted the same way.
•	Return only exact metrics from the list. Pay careful attention to singular/plural forms (e.g., "Revenue" vs "Revenues") and use the exact spelling and capitalization as shown in the list.
•	Return empty list if you are not sure about the matches between user's query and input_list OR if you cannot extract any specific metrics.

STRICT MATCHING RULES:
•   When user asks for base metrics (like "EBITDA", "Revenue", "Debt"), only return the standalone metric, NOT ratio metrics containing that term.
•   For example: "EBITDA" should match "EBITDA, Adjusted (REPORTED)" but NOT "Debt/ EBITDA, Adjusted (x)"
•   "Revenue" should match "Revenue, Adjusted (REPORTED)" but NOT "Revenue Margin"
•   Only return ratio metrics when the user explicitly asks for ratios, leverage, or uses terms like "debt to EBITDA"

<examples>
    - Query: "Show me the debt and EBITDA for Microsoft." Output: ["Debt, Adjusted (REPORTED)", "EBITDA, Adjusted (REPORTED)"]
    - Query: "what are the Loan Loss Reserve, Operating Revenue for Royal Bank of Canada for year 2022?" Output: ['Loan Loss Reserves (REPORTED)', 'Operating Revenues (REPORTED)']
    - Query: "Financial highlights for Apple" Output: ["Revenue, Adjusted (REPORTED)", "Net Income", "EBITDA, Adjusted (REPORTED)", "Gross Margin(%)"]
    - Query: "Show me financial overview for Microsoft" Output: ["Revenue, Adjusted (REPORTED)", "Net Income (REPORTED)", "EBITDA, Adjusted (REPORTED)", "Total Assets (REPORTED)"]
    - Query: "Evaluate the Gross Margin, Net Income for apple." Output: ["Gross Margin(%)", "Net Income (REPORTED)"]
    - Query: "what's EBITDA and tier1 ratio for apple" Output: ["EBITDA, Adjusted (REPORTED)", "Tier 1 Capital Ratio(%)"]
    - Query: "Show me leverage for Microsoft" Output: ["Debt/ EBITDA, Adjusted (x)"]
    - Query: "debt to EBITDA ratio for Apple" Output: ["Debt/ EBITDA, Adjusted (x)"]
</examples>

Special Cases:
1. If the user's query contains ONLY the word "leverage" by itself (and does not contain other specific financial metric names like "EBITDA", "debt", "revenue") — and not as part of a phrase like "Inventory Leverage" or "Financial Leverage" — then return:
["Debt/EBITDA,Adjusted"]

2. If user's query contains the heading/title of metrics like:
  user's query: Provide me "key figures", "Supplemental Ratios - Interest Coverage", "Profitability Metrics" OR "Supplemental Ratios".
  Use the financial knowledge to understand what all metrics can be part of this title and use those metrics for extraction.

Available Financial Metrics:
{financial_metrics}

The user's query is: {user_input}
"""

# --------------
# Financial metric extraction for Query
# --------------

QUERY_FINANCIAL_EXTRACTION_PROMPT_TEMPLATE = """You receive a 'USER QUESTION' that may ask about financial metric.
Your task is to analyze the 'USER QUESTION' and determine if it asks any financial metrics in 'FINANCIAL METRICS' list.
You must return a python list only. Do not provide any surrounding text or explanations.

Pay attention to the following points:
- If the 'USER QUESTION' mentions any financial metrics from the 'FINANCIAL METRICS' list, extract the best matching metrics based on keyword and semantic matching.
- If the 'USER QUESTION' does not mention any specific financial metrics provided in FINANCIAL METRICS or any special terms explained below, you MUST return an empty list (e.g., []).
- If the 'USER QUESTION' contains the word 'financial overview' or 'key financial' or 'financial highlight', return: ['Revenue, Adjusted (REPORTED)', 'Net Income (REPORTED)', 'EBITDA, Adjusted (REPORTED)', 'Total Assets (REPORTED)'].
- If the 'USER QUESTION' contains the word "leverage" then return: ['Debt/ EBITDA, Adjusted (x)']
- If the 'USER QUESTION' asks for base metrics (like "EBITDA", "Revenue", "Debt"), only return the standalone metric, NOT ratio metrics containing that term (For example: "EBITDA" should match "EBITDA, Adjusted (REPORTED)" but NOT "Debt/ EBITDA, Adjusted (x)").
- If the 'USER QUESTION' mentions other attributes such as 'Industry', 'Geography', 'Credit Rating', 'Credit Action', 'Order' etc. you should ignore these attributes and FOCUS ONLY THE FINANCIAL METRICS.

Here are the full list of 'FINANCIAL METRICS'. If financial metrics are mentioned in the 'USER QUESTION', use only the exact metric names from the list.
{financial_metrics}

Here are some examples of how to extract financial metrics from the question:
{query_financial_examples}

USER QUESTION: {user_input}
"""

QUERY_FINANCIAL_EXAMPLES = [
    (
        "Show me the debt and EBITDA of newly rated companies in the last 6 months.",
        """['Debt Fixed Charge Coverage (%)', 'Debt and Equity, Adjusted (REPORTED)', 'Debt, Adjusted (REPORTED)', 'Debt, Hybrid Payment Reported as Dividends (REPORTED)', 'Debt, Pre-Adjusted (REPORTED)', 
        'Debt-like Hybrid Payment Reported as Dividends (REPORTED)', 'Debt/ Debt and Equity Underpreciated Basis (%)', 'Debt/ Debt and Equity, Adjusted (%)', 'Debt/ EBITDA, Adjusted (x)', 
        'Debt: Amortized Cost (Additions) (REPORTED)', 'Debt: Consolidating (Additions) (REPORTED)', 'Debt: Contingent Considerations (Additions) (REPORTED)', 'Debt: Derivatives (Additions) (REPORTED)', 
        'Debt: Fair Value Adjustment (Additions) (REPORTED)', 'Debt: Foreign Currency Hedges (Additions) (REPORTED)', 'Debt: Government Cost Recovery (Addition) (REPORTED)', 'Debt: Guarantees (Additions) (REPORTED)', 
        'Debt: Lease Liab not Included in Rep Debt (Add) (REPORTED)', 'Debt: Litigation and Other Contingent Claims (Add) (REPORTED)', 'Debt: Non-Common Equity or Shareholder Loans (Add) (REPORTED)', 
        'Debt: Other Principle Based Adjustment (Additions) (REPORTED)', 'Debt: Other Situational Adjustment (Additions) (REPORTED)', 'Debt: Red Com Stk or Put Opt Held by MI (Add) (REPORTED)', 
        'Debt: Streaming Transactions (Situational) (Add) (REPORTED)', 'Debt: Tax Liabilities (Additions) (REPORTED)', 'Debt: Volumetric Prod Payments (Situational) (Add) (REPORTED)', 
        'Debt: Workers Compensation or Self Insurance (Add) (REPORTED)', 'EBITDA Fixed Charge Coverage (%)', 'EBITDA Fixed-Charge Coverage (%)', 'EBITDA Interest Coverage, Adjusted (x)',
        'EBITDA Margin, Adjusted (%)', 'EBITDA, Adjusted (REPORTED)', 'EBITDA: Accounting Distortions (Additions) (REPORTED)', 'EBITDA: Business Divestments (Additions) (REPORTED)',
        'EBITDA: Derivatives (Additions) (REPORTED)', 'EBITDA: Div Received from Eq Investments (Add) (REPORTED)', 'EBITDA: Div Received from Eq Investments (Reduc) (REPORTED)',
        'EBITDA: Exploration Expense (Additions) (REPORTED)', 'EBITDA: Exploration Expense (Reductions) (REPORTED)', 'EBITDA: FV Change of Contin Consideration (Add) (REPORTED)',
        'EBITDA: Foreign Exchange Gains (Additions) (REPORTED)', 'EBITDA: Gains on Disposals of PP&E (Additions) (REPORTED)', 'EBITDA: Inventory (Additions) (REPORTED)',
        'EBITDA: LIFO Liquidation Gains (Additions) (REPORTED)', 'EBITDA: Other Income Principle Based Adj (Add) (REPORTED)', 'EBITDA: Other Situational Adjustment (Additions) (REPORTED)',
        'EBITDA: Restructuring or Acquisition Costs (Add) (REPORTED)', 'EBITDA: Share Based Compensation Exp (Reduct) (REPORTED)', 'EBITDA: Share Based Compensation Expense (Add) (REPORTED)',
        'EBITDA: Streaming Transactions (Situational) (Add) (REPORTED)', 'EBITDA: Valuation Gains (Additions) (REPORTED)']""",
        "The response is too extensive. The question asks for debt and EBITDA without any specifics. Thus the desired metrics should be 'Debt, Adjusted (REPORTED)' and 'EBITDA, Adjusted (REPORTED)' only.",
        "['Debt, Adjusted (REPORTED)', 'EBITDA, Adjusted (REPORTED)']",
    ),
    (
        "what are the Loan Loss Reserve, Operating Revenue for entities in banking sector that located in Canada for year 2022?",
        "['Loan Loss Reserves (REPORTED)', 'Operating Revenues (REPORTED)']",
    ),
    (
        "Financial highlights for downgraded tech companies in 2024",
        "[]",
        """The question contains 'financial highligths'. This is an interchangable term for following metrics: 'Revenue, Adjusted (REPORTED)', 'Net Income', 'EBITDA, Adjusted (REPORTED)', 'Total Assets (REPORTED)'.
        Therefore, the response should contain these metrics.""",
        "['Revenue, Adjusted (REPORTED)', 'Net Income (REPORTED)', 'EBITDA, Adjusted (REPORTED)', 'Total Assets (REPORTED)']",
    ),
    (
        "Show me financial overview for corporates has BB+ or higher score",
        "[]",
        """The question contains 'financial overview'. This is an interchangable term for following metrics: 'Revenue, Adjusted (REPORTED)', 'Net Income', 'EBITDA, Adjusted (REPORTED)', 'Total Assets (REPORTED)'.
        Therefore, the response should contain these metrics.""",
        "['Revenue, Adjusted (REPORTED)', 'Net Income (REPORTED)', 'EBITDA, Adjusted (REPORTED)', 'Total Assets (REPORTED)']",
    ),
    (
        "Evaluate the Gross Margin, Net Income for entertainment entities in Japan.",
        "['gross margin', 'net income']",
        """The question mentions 'Gross Margin' and 'Net Income'. The most similar metrics from the financial metric list are 'Gross Margin (%)' and 'Net Income (REPORTED)'.
        Extracted metrics should be in the same format as in the financial metrics list.""",
        "['Gross Margin (%)', 'Net Income (REPORTED)']",
    ),
    (
        "what's EBITDA and tier1 ratio for recently downgraded companies",
        "['EBITDA, Adjusted', 'Tier 1 Capital Ratio']",
        """The excact metrics from the financial metric list are 'EBITDA, Adjusted (REPORTED)' and 'Tier 1 Capital Ratio (%)'.
        The answer should use these exact metrics. You must not alter the metric names.""",
        "['EBITDA, Adjusted (REPORTED)', 'Tier 1 Capital Ratio (%)']",
    ),
    (
        "Show me leverage for the list of AA rated US companies that have been downgraded in last year:",
        "[]",
        "The question contains the word 'leverage' by itself, which is a jargon term for 'Debt/ EBITDA, Adjusted (x)'.",
        "['Debt/ EBITDA, Adjusted (x)']",
    ),
    ("debt to EBITDA ratio for top rated corporates for 2024", "['Debt/ EBITDA, Adjusted (x)']"),
    (
        "Give me downgraded tech companies in 2024",
        "['Revenue, Adjusted (REPORTED)', 'Net Income (REPORTED)', 'EBITDA, Adjusted (REPORTED)', 'Total Assets']",
        "The question does not mention 'financial overview' or any financial metrics from 'FINANCIAL METRICS'. Therefore, the response should be empty list.",
        "[]",
    ),
    (
        "Provide a list of insurance entities that have a AA- or above rating",
        "['Revenue, Adjusted (REPORTED)', 'Net Income (REPORTED)', 'EBITDA, Adjusted (REPORTED)', 'Total Assets (REPORTED)']",
        """The question does not mention 'financial highlight' or any other financial metrics from 'FINANCIAL METRICS'.
        Therefore, the response should be empty list.""",
        "[]",
    ),
    (
        "Give me recently upgraded banking companies in US",
        "['Revenue, Adjusted (REPORTED)']",
        """The question does not mention 'revenue' or any other financial metrics from 'FINANCIAL METRICS'. Therefore, the response should be empty list.""",
        "[]",
    ),
    (
        "Generate a report of all downgraded Entities",
        "[]",
    ),
    (
        "Give me a list of newly rated companies in the last year",
        "['Net Income (REPORTED)']",
        """The question does not mention 'Net Income' or any financial metrics from 'FINANCIAL METRICS'. The response should be empty list.""",
        "[]",
    ),
    (
        "Provide me top 10 energy companies that have BBB+ or above rating",
        "['Revenue, Adjusted (REPORTED)', 'Net Income (REPORTED)', 'EBITDA, Adjusted (REPORTED)', 'Total Assets']",
        """The question does not mention 'financial overview' or any other financial metrics. 
        The response should be empty list.""",
        "[]",
    ),
    (
        "What are the top 20 upgraded IT companies in the US?",
        "['EBITDA, Adjusted (x)']",
        """The question does not mention 'EBITDA' or any other financial metrics from 'FINANCIAL METRICS'.
        The response should be empty list.""",
        "[]",
    ),
    (
        "List of upgraded companies in 2024",
        "[]",
    ),
    (
        "Give me recently downgraded education companies",
        "['Revenue, Adjusted (REPORTED)', 'Net Income (REPORTED)', 'EBITDA, Adjusted (REPORTED)', 'Total Assets (REPORTED)']",
        """The question does not mention 'financial highlight' or any financial metrics. You must return above list only if the question contains 'financial highlight'.
        The response should be empty list.""",
        "[]",
    ),
    (
        "What are the top 20 entertainment companies in the US that has BB rating",
        "['Debt/ EBITDA, Adjusted (x)']",
        """The question does not mention 'Debt/ EBITDA', 'Leverage' or any other financial metrics from 'FINANCIAL METRICS'. The response should be empty list.""",
        "[]",
    ),
    (
        "Generate a report of all newly rated corporates in Norway",
        "['EBITDA, Adjusted (REPORTED)']",
        """The question does not mention 'EBITDA' or any other financial metrics from 'FINANCIAL METRICS'. Therefore, the response should be empty list.""",
        "[]",
    ),
]
