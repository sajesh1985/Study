from threading import Lock


class RDSingleton(type):
    _type_instances = {}
    _lock = Lock()

    def __call__(cls, *args, **kwargs):
        cls._lock.acquire(blocking=True)
        if cls not in cls._type_instances:
            instance = super().__call__(*args, **kwargs)
            cls._type_instances[cls] = instance
        cls._lock.release()

        return cls._type_instances[cls]
