from chatrd.core.retriever_utils.fuzzy_search import fuzzy_substring_match


def test_fuzzy_substring_match():
    assert (
        fuzzy_substring_match(
            "Various Ratings On 13 Local Governments Removed From CreditWatch Negative, Outlooks Are Stable",
            "Westchester Village",
        )
        == False
    )
    assert (
        fuzzy_substring_match(
            "Greater Texoma Utility Authority, TX Revenue Bond Rating Raised To 'AA+' From 'AA' On Sound Management And Planning",
            "Princeton",
        )
        == False
    )
    assert fuzzy_substring_match("North Carolina", "State of North Carolina") == True
    assert fuzzy_substring_match("North Carolina", "North Carolina") == True
    assert (
        fuzzy_substring_match(
            "Nevada Outlook Revised To Stable From Negative On Steady Economic And Revenue Trends; ‘AA+’ GO Debt Rating Affirmed",
            "State of Nevada",
        )
        == True
    )
    assert fuzzy_substring_match("City University, NV", "City University") == True
