// Copyright Notice!
// This document is protected under the trade secret and copyright
// laws as the property of Fidelity National Information Services, Inc.
// Copying, reproduction or distribution should be limited and only to
// employees with a “need to know” to do their job.
// Any disclosure of this document to third parties is strictly prohibited.
// © 2016 Fidelity National Information Services.
// All rights reserved worldwide.

package com.fis.digitalpayments.sdk.core;

import android.content.Context;
import android.net.Uri;
import androidx.annotation.NonNull;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import com.fis.digitalpayments.sdk.contacts.ContactBridge;
import com.fis.digitalpayments.sdk.imaging.ImageBridge;
import com.fis.digitalpayments.sdk.messaging.WebEventListener;
import com.fis.digitalpayments.sdk.messaging.WebEventLogger;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

/**
 * Represents the connection point between javascript and native functionality. All bridge requests are routed through this class.
 */
public class BridgeJavascriptInterface {

    public final static String name = "FISDigitalPaymentsDeviceBridge";
    private final String[] mDomainWhitelist;
    private final Map<String, Bridge> mBridgeMapping;
    private final WebEventBridge mWebEventBridge;
    private final WebView mWebView;
    private final WebViewBridgeRequestCallback mWebViewBridgeRequestCallback;
    private final Context mContext;
    private WebEventListener mWebEventListener;

    public BridgeJavascriptInterface(@NonNull Context context, @NonNull WebView webView, @NonNull String[] domainWhitelist, WebEventListener webEventListener, boolean isDisclosureEnabled) {
        mWebEventListener = webEventListener;
        mContext = context.getApplicationContext();

        mWebView = webView;

        if (mWebEventListener == null) {
            mWebEventListener = new WebEventLogger();
        }

        mWebViewBridgeRequestCallback = new WebViewBridgeRequestCallback(webView, mWebEventListener);

        mBridgeMapping = new HashMap<>();

        mWebEventBridge = new WebEventBridge(mWebEventListener);
        mBridgeMapping.put(mWebEventBridge.getBridgeId(), mWebEventBridge);

        ContactBridge contactBridge = new ContactBridge(isDisclosureEnabled);
        mBridgeMapping.put(contactBridge.getBridgeId(), contactBridge);

        ImageBridge imageBridge = new ImageBridge();
        mBridgeMapping.put((imageBridge.getBridgeId()), imageBridge);

        MetadataBridge metadataBridge = new MetadataBridge();
        mBridgeMapping.put(metadataBridge.getBridgeId(), metadataBridge);

        mDomainWhitelist = cleanupDomainWhitelist(domainWhitelist);
    }

    @SuppressWarnings("unused")
    public BridgeJavascriptInterface(@NonNull Context context, @NonNull WebView webView, @NonNull String SSO, WebEventListener webEventListener, boolean isDisclosureEnabled) {
        this(context, webView, new String[] { getHostFromSSO(SSO) }, webEventListener, isDisclosureEnabled);
    }

    public WebEventBridge getWebEventBridge(){
        return mWebEventBridge;
    }

    /**
     * Inspects an incoming message and delegates to the appropriate bridge.
     * @param jsonRequest Request as a JSON string.
     */
    @JavascriptInterface
    public void postMessage(final String jsonRequest) {

        mWebView.post(new Runnable(){
            @Override
            public void run()
            {
                if(verifyWhiteList(mWebView.getUrl(), mDomainWhitelist)) {

                    BridgeRequest bridgeRequest = new BridgeRequest(jsonRequest);
                    if (mBridgeMapping.containsKey(bridgeRequest.getBridgeId())) {
                        Bridge bridge = mBridgeMapping.get(bridgeRequest.getBridgeId());
                        if (bridge != null) {
                            try {
                                bridge.handleRequest(bridgeRequest, mWebViewBridgeRequestCallback, mContext);
                            } catch (BridgeException e) {
                                returnRoutingErrorResponse(bridgeRequest);
                            }
                        }
                        else {
                            returnRoutingErrorResponse(bridgeRequest);
                        }
                    }
                    else {
                        returnRoutingErrorResponse(bridgeRequest);
                    }
                }
            }
        });
    }

    private static boolean verifyWhiteList(String url, String[] domainWhitelist)
    {
        String urlHost = Uri.parse(url).getHost();

        for (String domain: domainWhitelist) {
            if (urlHost != null) {
                if (urlHost.equals(domain)) {
                    return true;
                }
            }
        }
        return false;
    }

    @SuppressWarnings("WeakerAccess")
    public static String getHostFromSSO(@NonNull String SSO)
    {
        String urlHost = null;
        Pattern REGEX = Pattern.compile("(?i)\\b(?:(?:https?)://)(?:\\S+(?::\\S*)?@)?(?:(?!(?:10|127)(?:\\.\\d{1,3}){3})(?!(?:169\\.254|192\\.168)(?:\\.\\d{1,3}){2})(?!172\\.(?:1[6-9]|2\\d|3[0-1])(?:\\.\\d{1,3}){2})(?:[1-9]\\d?|1\\d\\d|2[01]\\d|22[0-3])(?:\\.(?:1?\\d{1,2}|2[0-4]\\d|25[0-5])){2}(?:\\.(?:[1-9]\\d?|1\\d\\d|2[0-4]\\d|25[0-4]))|(?:(?:[a-z\\u00a1-\\uffff0-9]-*)*[a-z\\u00a1-\\uffff0-9]+)(?:\\.(?:[a-z\\u00a1-\\uffff0-9]-*)*[a-z\\u00a1-\\uffff0-9]+)*(?:\\.(?:[a-z\\u00a1-\\uffff]{2,}))\\.?)(?::\\d{2,5})?(?:[/?#]\\S*)?\\b");

        Matcher matcher = REGEX.matcher(SSO);
        if (matcher.find()) {
            urlHost = Uri.parse(matcher.group()).getHost();
        }
        return urlHost;
    }

    public static String[] cleanupDomainWhitelist(@NonNull String[] domainWhitelist)
    {
        for (int i = 0; i < domainWhitelist.length; i++)
        {
            String curHost = domainWhitelist[i].toLowerCase();
            if (curHost.startsWith("http") || curHost.startsWith("https"))
                domainWhitelist[i] = Uri.parse(curHost).getHost();
            else
                domainWhitelist[i] = curHost;
        }
        return domainWhitelist;
    }

    private void returnRoutingErrorResponse(BridgeRequest bridgeRequest) {
        BridgeMessage bridgeMessage = BridgeMessage.CreateError(BridgeMessageCode.BRIDGE_REQUEST_PROCESSING_FAILED, BridgeMessageCode.BRIDGE_REQUEST_PROCESSING_FAILED.toString());
        BridgeResponse bridgeResponse = new BridgeResponse(bridgeRequest.getCallbackMethod(), null, null, bridgeRequest.getCallbackKey(), false, bridgeMessage);
        mWebViewBridgeRequestCallback.onRequestComplete(bridgeResponse);
    }
}
