#!/bin/bash

# Remove the log files from previous runs
rm -f ./log_file.out

# The name of the output file will be suffixed with "_structured" when run with --structured_only flag 
python regression_script.py --in_file "./list_questioner.txt" --out_file "./responses" --log_file "./log_file.out" --structured_only

# Run this in case full output is needed 
# python regression_script.py --in_file "./list_questioner.txt" --out_file "./responses" --log_file "./log_file.out"
