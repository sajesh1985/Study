import logging
from datetime import date
from typing import Optional

from chatrd.core.llm import LCLLMFactory
from chatrd.engine.components.query_analyzer.filter_retrievers.base import FiltersInput
from chatrd.engine.components.query_analyzer.filter_retrievers.prompts import (
    TIME_THRESHOLD_PROMPT_STRING_OUTPUT,
    output_parser_time_threshold_symbol,
    task_specific_examples_string,
    task_specific_instructions_string,
)
from chatrd.engine.components.query_analyzer.filter_retrievers.time_threshold import (
    TimeThresholdFilter,
)
from chatrd.engine.data_service.analyzer.base import BaseAnalyzer
from chatrd.engine.data_service.analyzer.prompts.financial_prompts import (
    PROMPT_FINANCIAL_EXTRACTION_MULTIPLE_ENTITIES_TEMPLATE,
    PROMPT_FINANCIAL_EXTRACTION_TEMPLATE,
)
from chatrd.engine.data_service.analyzer.utils import (
    append_fiscal_years,
    filter_llm_response_financial_metrics,
    get_financial_metrics_by_sectors,
    get_sector_short,
)
from chatrd.engine.data_service.schema import Analyzer, ProcessorInput

logger = logging.getLogger(__name__)


class FinancialMetricsAnalyzer(BaseAnalyzer):
    """
    Extracts relevant financial metrics from a user query using an LLM.
    """

    def __init__(self, vector_database_path: Optional[str] = None):
        self.vector_database_path = vector_database_path

    def analyze(self, processor: ProcessorInput) -> Analyzer:
        model_for_data_service = LCLLMFactory().get_llm(
            deployment_name_or_model_id=processor.llm,
            temperature=processor.temperature,
        )
        companies = processor.entities["companies"]
        use_single_template = len(companies) == 1

        valid_companies = []
        sectors = set()
        mi_ids = ""

        for company in companies:
            company_name = company.get("name")
            mi_id = company.get("mi_id")
            rd_sector = company.get("rd_sector", [])[0] if company.get("rd_sector") else None
            sector = get_sector_short(rd_sector)
            sectors.add(sector) if sector else None
            if mi_id and rd_sector is not None:
                mi_ids += f",{str(mi_id)}" if mi_ids else str(mi_id)

            if not rd_sector:
                logger.info(f"Skipping company '{company_name}' due to missing or empty rd_sector.")
                continue

            valid_companies.append({"company": company_name, "rd_sector": rd_sector, "keyInstn": str(mi_id)})

        modified_user_input = (
            processor.user_input if processor.user_input.strip().endswith("?") else processor.user_input + "?"
        )

        metrics_list, metric_names = get_financial_metrics_by_sectors(sectors)
        unique_metric_names = list(set(metric_names))
        unique_metric_names.sort()

        if use_single_template:
            prompt = PROMPT_FINANCIAL_EXTRACTION_TEMPLATE.format(
                financial_metrics=unique_metric_names, user_input=modified_user_input
            )
        else:
            prompt = PROMPT_FINANCIAL_EXTRACTION_MULTIPLE_ENTITIES_TEMPLATE.format(
                financial_metrics=unique_metric_names, user_input=modified_user_input
            )

        try:
            output = model_for_data_service.invoke(prompt)
            logger.info(f"LLM Metrics OUTPUT: {output}")
            extracted_metric_names, extracted_metric_list = filter_llm_response_financial_metrics(
                output, metric_names, metrics_list
            )
            logger.info(f"Filtered Extracted Metrics: {extracted_metric_names}")

            date_retriever_string_output = TimeThresholdFilter(
                uc_specific_prompt=TIME_THRESHOLD_PROMPT_STRING_OUTPUT,
                output_parser=output_parser_time_threshold_symbol,
                specific_instructions_fn=task_specific_instructions_string,
                examples_fn=task_specific_examples_string,
                filters_input=FiltersInput(llm=processor.llm, temperature=processor.temperature),
            )
            extracted_time = date_retriever_string_output.invoke(processor.user_input, today_date=date.today())
            extracted_periods_dict = extracted_time.model_dump(exclude="ChainOfThought")
            logger.info(f"Financial Metrics Time Retriever - output: {extracted_periods_dict}")
            extracted_periods = extracted_periods_dict.get("PeriodsList", ["LFY"])
            # there are no LTM questions in the financial metrics, so we replace LTM with LFY
            if not extracted_periods:
                extracted_periods = ["LFY"]
            if extracted_periods == ["LTM"]:
                extracted_periods = ["LFY"]
            if any("Q" in period or "H" in period for period in extracted_periods):
                extracted_periods = append_fiscal_years(extracted_periods)
                logger.info(f"Updated Periods after appending fiscal years: {extracted_periods}")

        except Exception as e:
            logger.error(f"Error filtering metrics using LLM: {str(e)}")
            extracted_metric_names = []

        return Analyzer(
            user_input=processor.user_input,
            response={
                "result": valid_companies,
                "keyInstns": mi_ids,
                "metrics": extracted_metric_names,
                "time": extracted_periods,
                "metricsList": extracted_metric_list,
            },
        )
