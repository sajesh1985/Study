import logging
from datetime import date, datetime, time, timedelta
from typing import Dict, List, Optional, Union

import pandas as pd

from chatrd.core.document import Document
from chatrd.core.retriever_utils.fuzzy_search import fuzzy_substring_match
from chatrd.core.vectorstore import OpenSearch
from chatrd.engine.components.query_analyzer.entity_extractor.utils import (
    Companies,
    RevenueSource,
)
from chatrd.engine.components.query_analyzer.filter_retrievers.prompts import (
    QuestionIntentClass,
    TimeOutputDates,
)
from chatrd.engine.components.query_processor.query_retriever.uc_retrievers.utils import (
    ProcessedRetrieverDates,
)

logger = logging.getLogger(__name__)


def get_date_range_filter(year: int, date: str = None, processed_dates: ProcessedRetrieverDates = None):
    """
    Gets start and end date of either:
    1. A specified date's start (00:00:00) and end (23:59:59)
    2. A date range going back a specified number of years from today.

    Args:
        year: Amount of years back to generate date range.
        date: Specific date in 'MM/DD/YYYY' format to calculate start and end.

    Returns:
        start_date: starting date of date range
        end_date: ending date of date range
    """
    if processed_dates:
        start_date, end_date = processed_dates.start_date, processed_dates.end_date
    elif date:
        specified_date = datetime.strptime(date, "%m/%d/%Y")
        start_date = specified_date.replace(hour=0, minute=0, second=0)
        end_date = (start_date + timedelta(days=7)).replace(hour=23, minute=59, second=59)
    else:
        end_date = datetime.now()
        start_date = end_date - timedelta(days=year * 365)
        start_date = start_date.strftime("%Y-%m-%d %H:%M:%S")
        end_date = end_date.strftime("%Y-%m-%d %H:%M:%S")

    return start_date, end_date


def get_filters_for_research(
    vector_stores_dict: Dict[str, OpenSearch],
    entity: Union[Companies, RevenueSource],
    year: int = 1,
    date: str = None,
    uc_type: str = None,
    article_type: Optional[str] = None,
    processed_dates: Optional[ProcessedRetrieverDates] = None,
):
    """Retrieves filters and article ids relevant to entity from research vector store.

    Args:
        vector_stores_dict: Vector Store Dictionary with research vector store
        entities: entities to obtain relevant research articles

    Returns:
        filters: filters to be applied later in pipeline
        relevant_article_ids: list of article ids corrosponding to entities
    """
    filters, relevant_article_ids = None, None
    sf_year_threshold, uspf_year_threshold, company_year_threshold, rs_year_threshold = (3, 3, 3, 3)
    if isinstance(entity, Companies):
        if entity.rd_sector and entity.rd_sector[0] == "Structured Finance":
            relevant_article_ids = fetch_relevant_article_ids(
                vector_stores_dict["research"],
                entity.mi_id,
                type="sf",
                year=sf_year_threshold,
                date=date,
                article_type=article_type,
                uc_type=uc_type,
                processed_dates=processed_dates,
            )
        elif entity.subsector_code == "PUBFIN":
            relevant_article_ids = fetch_relevant_article_ids(
                vector_stores_dict["research"],
                entity.mi_id,
                type="uspf",
                year=uspf_year_threshold,
                date=date,
                article_type=article_type,
                uc_type=uc_type,
                processed_dates=processed_dates,
            )
        else:
            relevant_article_ids = fetch_relevant_article_ids(
                vector_stores_dict["research"],
                entity.mi_id,
                type="company",
                year=company_year_threshold,
                date=date,
                article_type=article_type,
                uc_type=uc_type,
                processed_dates=processed_dates,
            )
    elif isinstance(entity, RevenueSource):
        relevant_article_ids = fetch_relevant_article_ids(
            vector_stores_dict["research"],
            None,
            type="revenue_source",
            year=rs_year_threshold,
            asid=entity.asid,
            date=date,
            article_type=article_type,
            uc_type=uc_type,
            processed_dates=processed_dates,
        )
    else:
        logger.error(f"No documents in vector db for given entity {entity}.")

    filters = get_custom_logic_filters_for_entities(relevant_article_ids, uc_type=uc_type)

    return filters, relevant_article_ids


def get_custom_logic_filters_for_entities(list_of_ids: List[int], uc_type: Optional[str] = None) -> Dict:
    # if uc_type in []:
    return {
        "bool": {
            "must": [
                {"terms": {"metadata.articleID": list_of_ids}},
            ],
        }
    }

    # return {
    #     "bool": {
    #         "must": [{"terms": {"metadata.articleID": list_of_ids}}, {"terms": {"metadata.chunk_type": ["text"]}}],
    #     }
    # }


def get_custom_logic_filters_for_date_range(processed_dates: ProcessedRetrieverDates) -> Dict:
    start_date, end_date = processed_dates.start_date, processed_dates.end_date
    if start_date and end_date:
        return {
            "bool": {
                "must": [
                    {"range": {"metadata.articleReleaseDate": {"gte": start_date, "lte": end_date}}},
                ],
            }
        }
    else:
        return None


def get_custom_logic_filters_for_peer_comparison(list_of_ids: List[int]) -> Dict:
    return {
        "bool": {
            "must": [
                {"terms": {"metadata.articleID": list_of_ids}},
                {"match": {"metadata.chunk_title": "Peer Comparison"}},
            ],
        }
    }


def fetch_relevant_article_ids(
    retriever: OpenSearch,
    keyinstn: Optional[int],
    type: str = "company",
    year: int = 3,
    asid: Optional[int] = None,
    date: str = None,
    article_type: Optional[str] = None,
    uc_type: str = None,
    processed_dates: Optional[ProcessedRetrieverDates] = None,
) -> List[int]:
    """Retrieves article ids relevant to entity from research vector store.

    Args:
        retriever: Vector store to query article ids
        keyinstn: aggPrimaryKeyInstn for uspf and company entities
        type: type of entity either company, uspf, or revenue_source
        year: year to query for articles
        asid: aggRevenueSourceId for revenue sources

    Returns:
        filters: filters to be applied later in pipeline
        relevant_article_ids: list of article ids corrosponding to entities
    """

    df = None
    start_date, end_date = get_date_range_filter(
        year=year,
        date=date,
        processed_dates=processed_dates,
    )  # needs to be changed with the datetime info from rating action API
    eid = None
    eid_type = ""

    query_error_msg = ""
    if type == "company" or type == "uspf" or type == "sf":
        if keyinstn is None:
            logger.error(f"{type} passed without aggPrimarykeyInstn")
        query_error_msg = f"{type} aggPrimarkyKeyInstn (keyinstn): {str(keyinstn)}"
        eid = keyinstn
        eid_type = "aggPrimarykeyInstn"
        seid_type = "aggsecondaryKeyInstn"
        query = {
            "size": 0,
            "query": {
                "bool": {
                    "should": [
                        {"match": {f"metadata.{eid_type}": f"{eid}"}},
                        {"match": {f"metadata.{seid_type}": f"{eid}"}},
                        {"wildcard": {f"metadata.{eid_type}": {"value": f"{eid};*"}}},
                        {"wildcard": {f"metadata.{eid_type}": {"value": f"*;{eid};*"}}},
                        {"wildcard": {f"metadata.{eid_type}": {"value": f"*;{eid}"}}},
                        {"wildcard": {f"metadata.{seid_type}": {"value": f"{eid};*"}}},
                        {"wildcard": {f"metadata.{seid_type}": {"value": f"*;{eid};*"}}},
                        {"wildcard": {f"metadata.{seid_type}": {"value": f"*;{eid}"}}},
                    ]
                }
            },
            "aggs": {
                "results": {
                    "composite": {
                        "size": 10000,
                        "sources": [
                            {"metadata.articleID": {"terms": {"field": "metadata.articleID"}}},
                            {"metadata.articleType": {"terms": {"field": "metadata.articleType.keyword"}}},
                            {"metadata.articleSubType": {"terms": {"field": "metadata.articleSubType.keyword"}}},
                            {"metadata.articleReleaseDate": {"terms": {"field": "metadata.articleReleaseDate"}}},
                            {"metadata.slug": {"terms": {"field": "metadata.slug.keyword"}}},
                            {
                                "metadata.aggLegalEntityName": {
                                    "terms": {"field": "metadata.aggLegalEntityName.keyword", "missing_bucket": True}
                                }
                            },
                            {"metadata.SourceTitle": {"terms": {"field": "metadata.SourceTitle.keyword"}}},
                            {f"metadata.{eid_type}": {"terms": {"field": f"metadata.{eid_type}.keyword"}}},
                            {f"metadata.{seid_type}": {"terms": {"field": f"metadata.{seid_type}.keyword"}}},
                        ],
                    }
                }
            },
        }
    elif type == "revenue_source":
        if asid is None:
            logger.error(f"{type} passed without aggRevenueSourceId")
            return
        query_error_msg = f"{type} aggRevenueSourceId (asid): {str(asid)}"
        eid = asid
        eid_type = "aggRevenueSourceId"
        query = {
            "size": 0,
            "query": {
                "bool": {
                    "should": [
                        {"match": {f"metadata.{eid_type}": f"{eid}"}},
                        {"wildcard": {f"metadata.{eid_type}": {"value": f"{eid};*"}}},
                        {"wildcard": {f"metadata.{eid_type}": {"value": f"*;{eid};*"}}},
                        {"wildcard": {f"metadata.{eid_type}": {"value": f"*;{eid}"}}},
                    ]
                }
            },
            "aggs": {
                "results": {
                    "composite": {
                        "size": 10000,
                        "sources": [
                            {"metadata.articleID": {"terms": {"field": "metadata.articleID"}}},
                            {"metadata.articleType": {"terms": {"field": "metadata.articleType.keyword"}}},
                            {"metadata.articleSubType": {"terms": {"field": "metadata.articleSubType.keyword"}}},
                            {"metadata.articleReleaseDate": {"terms": {"field": "metadata.articleReleaseDate"}}},
                            {"metadata.slug": {"terms": {"field": "metadata.slug.keyword"}}},
                            {
                                "metadata.aggLegalEntityName": {
                                    "terms": {"field": "metadata.aggLegalEntityName.keyword"}
                                }
                            },
                            {"metadata.SourceTitle": {"terms": {"field": "metadata.SourceTitle.keyword"}}},
                            {f"metadata.{eid_type}": {"terms": {"field": f"metadata.{eid_type}.keyword"}}},
                        ],
                    }
                }
            },
        }

    response = retriever.client.transport.perform_request(
        "POST",
        f"/{retriever.index_name}/_search",
        body=query,
    )
    if response["timed_out"] is False:
        if len((response["aggregations"]["results"]["buckets"])) != 0:
            df = pd.DataFrame(
                data=[list(bucket["key"].values()) for bucket in response["aggregations"]["results"]["buckets"]],
                columns=list(response["aggregations"]["results"]["buckets"][0]["key"].keys()),
            )
            df["metadata.articleReleaseDate"] = df["metadata.articleReleaseDate"].apply(
                lambda x: datetime.fromtimestamp(x / 1000).strftime("%Y-%m-%dT%H:%M:%S")
            )
        else:
            df = pd.DataFrame()
        if len(df) == 0:
            logger.error("No documents in vector db for given entity: " + query_error_msg)
            return []
        logger.info(f"Number of articles in opensearch database for given entity: {len(df)}")
        if len(df) == 0:
            logger.error("No documents in vector db for given entity: " + query_error_msg)
            return []
    else:
        logger.error(f"Some error occured with status code : {response['status']} while fetching relevant article ids.")
        return []

    if type == "revenue_source" or type == "uspf":
        primary_entity_name = ""
        singular_eid = ~df[f"metadata.{eid_type}"].str.contains(";")
        if singular_eid.any():
            primary_entity_name = df[singular_eid]["metadata.aggLegalEntityName"].unique()[0]
        else:
            primary_entity_name = df["metadata.aggLegalEntityName"].replace("", None).dropna().value_counts().idxmax()
        if primary_entity_name == "":
            logger.error("No primary entity name found for given entity: " + query_error_msg)
            return []

        titles = df["metadata.SourceTitle"].to_list()
        if len(titles) != 0:
            relevant_articles = [fuzzy_substring_match(title, primary_entity_name, threshold=0.5) for title in titles]
            df = df[relevant_articles]
        if len(df) == 0:
            logger.info("No documents in vector db for given entity after fuzzy matching: " + query_error_msg)
            return []

        logger.info(
            f"Number of articles in opensearch database for given entity {query_error_msg} after fuzzy matching: {len(df)}"
        )

    df["metadata.articleReleaseDate"] = pd.to_datetime(df["metadata.articleReleaseDate"])
    df = df.sort_values(by="metadata.articleReleaseDate", ascending=False)

    logger.info(f"Date range applied to filter the documents - start_date: {start_date}, end_date: {end_date}")

    unrestricted_subtypes = ["PRESALE", "NEW ISSUE"]
    unrestricted_df = df[df["metadata.articleSubType"].isin(unrestricted_subtypes)]
    restricted_df = df[~df["metadata.articleSubType"].isin(unrestricted_subtypes)]

    if start_date and end_date:
        restricted_df = restricted_df.loc[
            (restricted_df["metadata.articleReleaseDate"] >= start_date)
            & (restricted_df["metadata.articleReleaseDate"] <= end_date)
        ]

    df = pd.concat([restricted_df, unrestricted_df], ignore_index=True)

    top_n = 6
    if uc_type == "research" and not article_type:
        selected_ids = df["metadata.articleID"].unique()[:top_n].tolist()
    elif uc_type == "research" and article_type == "full":
        full_articles = df[df["metadata.articleType"] == "FULL"]
        selected_ids = full_articles["metadata.articleID"].unique()[:top_n].tolist()
    else:
        if type in ["company", "uspf", "revenue_source", "sf"] or uc_type == "rating_action":
            # we need these article types: Research Update, Rating Action News, Full Analysis, Summary Analysis. Presale reports, New Issue reports
            full_articles = df[df["metadata.articleType"] == "FULL"]
            (
                selected_full_article,
                selected_tear_sheet_article,
                selected_rating_action_news_article,
                selected_research_update_article,
                selected_bulletin_article,
                selected_summary_article,
            ) = ([], [], [], [], [], [])
            if len(full_articles):
                for idx, row in full_articles.iterrows():
                    if (
                        ("Tear Sheet" == row["metadata.slug"])
                        and (len(selected_tear_sheet_article) == 0)
                        and (type == "company")
                    ):
                        selected_tear_sheet_article.append(row)
                    else:
                        selected_full_article.append(row)
                        break

            rating_action_news_articles = df[
                (df["metadata.articleType"] == "NEWS") & (df["metadata.articleSubType"] == "RATING_ACTION")
            ]
            if len(rating_action_news_articles):
                selected_rating_action_news_article.append(rating_action_news_articles.iloc[0])

        if type == "sf" or uc_type == "rating_action":
            presale_reports = df[df["metadata.articleSubType"] == "PRESALE"]
            if len(presale_reports):
                selected_full_article.append(presale_reports.iloc[0])

        if type == "company" or type == "uspf" or uc_type == "rating_action":
            research_update_articles = df[df["metadata.articleType"] == "RESUPD"]
            if len(research_update_articles):
                selected_research_update_article.append(research_update_articles.iloc[0])

            bulletin_news_articles = df[
                (df["metadata.articleType"] == "NEWS") & (df["metadata.articleSubType"] == "BULLETIN")
            ]
            if len(bulletin_news_articles):
                selected_bulletin_article.append(bulletin_news_articles.iloc[0])

        if type == "uspf" or type == "revenue_source" or uc_type == "rating_action":
            summary_articles = df[df["metadata.articleType"] == "SUMMARY"]
            if len(summary_articles):
                selected_summary_article.append(summary_articles.iloc[0])

        selected_all_article = (
            selected_full_article
            + selected_tear_sheet_article
            + selected_rating_action_news_article
            + selected_research_update_article
            + selected_bulletin_article
            + selected_summary_article
        )

        selected_df = pd.DataFrame(selected_all_article)
        selected_ids = selected_df["metadata.articleID"].unique().tolist() if not selected_df.empty else []

    if len(selected_ids) == 0:
        logger.error("No documents in vector db for given entity after time filtering: " + query_error_msg)
        return []

    return selected_ids


def post_process_retrieved_docs(retrieved_documents: List[Document]) -> List[Document]:
    """Removes the Downgrade Triggers and Upgrade Triggers from the content of the retrieved documents.

    Args:
        retrieved_documents: List of retrieved documents

    Returns:
        retrieved_documents: List of retrieved documents after removing Downgrade Triggers and Upgrade Triggers
    """
    for doc in retrieved_documents:
        doc.content = doc.content.replace(" or Downgrade Triggers", "").replace(" or Upgrade Triggers", "")
    return retrieved_documents


def post_process_analyzer_output_dates(extracted_dates: TimeOutputDates) -> ProcessedRetrieverDates:
    today = date.today()
    if extracted_dates is None:
        end_date = today
        start_date = today - timedelta(days=3 * 365)
        start_date = datetime.combine(start_date, time.min).strftime("%Y-%m-%dT%H:%M:%S")
        end_date = datetime.combine(end_date, time.max).strftime("%Y-%m-%dT%H:%M:%S")
        dates = ProcessedRetrieverDates(start_date=start_date, end_date=end_date)
        return dates
    start_date, end_date = extracted_dates.PeriodStart, extracted_dates.PeriodEnd
    if (
        (extracted_dates.Question_Intent == QuestionIntentClass.UNSPECIFIED)
        or (not start_date and not end_date)
        or (not start_date and end_date >= today)
        or ((start_date is not None) and start_date >= today and (end_date > today or not end_date))
        or ((end_date is not None) and end_date > today)
    ):
        return ProcessedRetrieverDates(start_date=None, end_date=None)
    else:
        end_date = end_date or today
        start_date = start_date or today - timedelta(days=3 * 365)
        if end_date < start_date:
            print("Unexpected date range, searching whole corpus.")
            return ProcessedRetrieverDates(start_date=None, end_date=None)
        start_date = datetime.combine(start_date, time.min).strftime("%Y-%m-%dT%H:%M:%S")
        end_date = datetime.combine(end_date, time.max).strftime("%Y-%m-%dT%H:%M:%S")
        dates = ProcessedRetrieverDates(start_date=start_date, end_date=end_date)
        return dates


def get_sorted_docs_by_date(documents: List[Document], final_top_k: int) -> List[Document]:
    sorted_docs = sorted(
        documents,
        key=lambda x: datetime.strptime(x.metadata["articleReleaseDate"], "%Y-%m-%dT%H:%M:%S"),
        reverse=True,
    )
    max_k = final_top_k if len(sorted_docs) >= final_top_k else len(sorted_docs)
    sorted_docs = sorted_docs[:max_k]
    return sorted_docs


def add_unstructured_source(documents: list) -> list:
    """
    Add 'unstructured' source to each document in the list.
    """
    for doc in documents:
        doc.source = "unstructured"
    return documents


def add_structured_source(documents: list) -> list:
    """
    Add 'structured' source to each document in the list.
    """
    for doc in documents:
        doc.source = "structured"
    return documents
