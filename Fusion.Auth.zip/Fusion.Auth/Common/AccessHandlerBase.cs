// Copyright Notice! 
// This document is protected under the trade secret and copyright 
// laws as the property of Fidelity National Information Services, Inc. 
// Copying, reproduction or distribution should be limited and only to 
// employees with a “need to know” to do their job. 
// Any disclosure of this document to third parties is strictly prohibited.
// © 2018 Fidelity National Information Services.
// All rights reserved worldwide.

namespace Fis.Epp.Fusion.Auth
{
    using Fis.Epp.Fusion.Auth.Models;
    using System;
    using System.Net.Http;
    using System.Threading.Tasks;

    /// <summary>Represents base class to access the external services.</summary>
    public abstract class AccessHandlerBase
    {
        private readonly AppConfiguration _appConfiguration;

        protected AccessHandlerBase(AppConfiguration appConfiguration)
        {
            _appConfiguration = appConfiguration;
        }

        protected AppConfiguration AppConfiguration
        {
            get
            {
                return _appConfiguration;
            }
        }

        protected async Task<HttpResponseMessage> InvokeService(HttpRequestMessage request)
        {
            if (request == null)
            {
                throw new ArgumentNullException(ExceptionEnum.request.GetEnumDescription());
            }

            using (var client = new HttpClient())
            {
                client.Timeout = TimeSpan.FromSeconds(Convert.ToDouble(_appConfiguration.HttpClientTimeOut));
                return await client.SendAsync(request);
            }
        }
    }
}
