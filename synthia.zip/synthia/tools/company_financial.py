import contextlib
import logging
import urllib.parse
from contextlib import asynccontextmanager
from datetime import datetime

import httpx
from fastapi import FastAPI, APIRouter
from fastapi import Request
from mcp.server.fastmcp import FastMCP, Context

from src.synthia.config.api_config import get_config
from src.synthia.tools.denim_request import CommonDenimRequest, SegmentDenimRequest, send_ciq_denim_request, \
    get_ciq_company_id
from src.synthia.tools.mappings import CASH_FLOW, BALANCE_SHEET, SEGMENT_ANALYSIS, INCOME_STATEMENT, \
    PERFORMANCE_ANALYSIS
from src.synthia.tools.mcp_responses import MCPResponse, ReducedDenimResponse, CompanyEstimatesConsensusRecord
from src.synthia.user_profile.user_profile_provider import fetch_user_profile_data
from src.synthia.utils.finiancial_templates_reader import FinancialTemplatesLoader
from src.synthia.utils.logging_config import configure_logging
from . import auth
from .mcp_utils import get_mcp_tool_source

# Define the mapping dictionary
metric_caption_map = {
    "CIQ000028": "Total Revenue",
    "CIQ004194": "Total Revenues, 1 Year Growth",
    "CIQ000010": "Gross Profit",
    "CIQ004074": "Gross Profit Margin",
    "CIQ004051": "EBITDA",
    "CIQ004047": "EBITDA Margin",
    "CIQ000400": "EBIT",
    "CIQ004053": "EBIT Margin",
    "CIQ000007": "Earnings from Cont. Ops.",
    "CIQ004181": "Earnings from Cont Ops Margin",
    "CIQ000015": "Net Income",
    "CIQ004094": "Net Income Margin",
    "CIQ000142": "Diluted EPS Excl. Extra Items",
    "CIQ004200": "Diluted EPS Before Extra, 1 Year Growth",
    "CIQ003195": "Owned/Operated Same Store Sales Growth",
    "CIQ000004": "EBT Excl Unusual Items",
    "CIQ004117": "EBT Excluding Non-Recurring Items Margin",
    "CIQ001007": "Total Assets",
    "CIQ004203": "Total Assets, 1 Year Growth",
    "CIQ003074": "Funds From Operations"
}


# Transform keystats_data by replacing metric code keys with captions
def translate_metric_keys(obj):
    if isinstance(obj, dict):
        return {metric_caption_map.get(k, k): translate_metric_keys(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [translate_metric_keys(item) for item in obj]
    else:
        return obj


# Configure logging
logger = configure_logging(logger_name=__name__, log_file='company_financial.log')

mcp: FastMCP = FastMCP("Company Financial MCP", stateless_http=True)

logger.info("Financial MCP Server starting up...")

router = APIRouter()

# Create a single AsyncClient instance for reuse (performance optimization for Lambda)
async_client: httpx.AsyncClient = None


# @mcp.tool()
async def get_company_CSD_financials(keyInstn: str, metric_field: str = "", period: str = "LFY") -> dict:
    """
    Fetch company financials Highlight sourced from CreditStats Direct for the given company.

    Args:
        keyInstn (str): The Instn id/ MI Key/ KeyInstn to get financials for
        metric_field (str, optional): By Default field is optional empty string ("") return all data.
            DO NOT USE S&P CapitalIQ field here, Comma-separated list of metric fields for CreditStats Direct. 
            Each value must be a valid 'MetricName' as returned in this API response only.
            To discover available metric fields, first call this endpoint without specifying metric_field, 
            then use the 'MetricName' values from the response.
        period (str): Comma-separated list of periods. Each period should follow these patterns:
            - YEAR + 'Y' for annual (e.g., 2023Y)
            - YEAR + 'Q1', 'Q2', 'Q3', 'Q4' for quarters (e.g., 2024Q1)
            - YEAR + 'H1', 'H2' for semi-annual (e.g., 2023H1)
            - 'LTM' for Last Twelve Months
            - 'LFY' for Latest Fiscal Year
            - 'LYQ' for Latest Fiscal Quarter
            Example: "2023Y,2024Q1,2023H2,LFY,LYQ"
            This field is optional and can be left blank to use the default ("LFY").

    Returns:
        dict: A dictionary containing the financials Highlight sourced from CreditStats Direct for the given company
        example response:
         {
            "KeyInstn": "4000193",
            "MetricValue": "38943.53",
            "MetricName": "CIQ045233",
            "ProductCaption": "Debt, Adjusted",
            "Period": "2023Y ",
            "Magnitude": "$M",
            "KeyCurrency": "USD"
        }
        Field meanings:
        - KeyInstn: The Instn id/ MI Key/ KeyInstn for the company.
        - MetricValue: The value of the financial metric.
        - MetricName: The name of the financial metric. This is a unique identifier for the metric, such as "CIQ045233". Can be used to discover available metric fields.
        - ProductCaption: The caption of the financial Metric.
        - Period: The period for which the financial metric is reported.
        - Magnitude: The magnitude of the financial metric (e.g., $M for millions).
        - KeyCurrency: The currency code for the financial metric (e.g., USD).
    Note:
        Source for this data is CreditStats Direct.
        Only 'MetricName' values present in the API response are supported for 'metric_field'. DO not mix S&P CapitalIQ fields with CreditStats Direct fields.
    """
    logger.info(
        f"get_company_CSD_financials called for: {keyInstn}, metric_field: {metric_field}, period: {period}")

    # Get configuration
    cfg = get_config()
    capitaliq_base_url = cfg["capitaliq_base_url"]
    financial_url_infix = "AIReportBuilder/csdFinancials"

    payload = {
        "KeyInstn": str(keyInstn),
        "MetricField": metric_field,
        "Period": period
    }
    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    headers = raw_request.headers
    logger.info(f"Headers received: {headers}")
    logger.info(f"get_company_CSD_financials called for: {payload}")
    url = f"{capitaliq_base_url}{financial_url_infix}"
    try:
        global async_client
        response = await async_client.post(url,
                                           headers=auth.build_auth_headers(raw_request), json=payload)
        source = await get_mcp_tool_source(
            mcp_tool_name=get_company_CSD_financials.__name__,
            source_url=url,
            institution_id=keyInstn,
            headers=auth.build_auth_headers(raw_request),
            default_title="Company CSD financials"
        )

        if response.status_code == 200:
            financial_data = response.json()
            logger.info(f"Financial data returned: {len(financial_data)} records")
            return {"sources": source, "data": financial_data}
        elif response.status_code == 204:
            logger.info(f"No financial data found for the given company: {keyInstn}")
            return {"sources": source, "data": [{"message": "No financial data found for the given company."}]}
        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return {"error": f"{response.status_code} - {response.text}"}
    except httpx.RequestError as e:
        logger.error(f"Request failed: {e}")
        return {"error": f"Request failed: {e}"}


# @mcp.tool()
async def get_company_CIQ_financials(
        keyInstn: str,
        FiscalPeriodGAAP: str = "Years",
        DataSourcePeriod: str = "",
        SortOrder: int = 0
) -> dict:
    """
    Fetch company financials KeyStats sourced from S&P CapitalIQ KeyStats Data for the given company.

    Args:
        keyInstn (str): The Instn id/ MI Key to get financials for (KeyInstn).
        FiscalPeriodGAAP (str): One of 'Years', 'Quarters', 'LTM', or 'Interim'. Default is 'Years'.
        DataSourcePeriod (str, optional): Comma-separated list of periods.
            - For 'Years': e.g., '2022Y,2023Y,2024Y'
            - For 'Quarters': e.g., '2024Q1,2024Q2,2024Q3,2024Q4'
            - For 'Interim': e.g., '2024H1,2024H2'
            - For 'LTM': e.g., '2024L1,2024L2,2024L3,2024L4'
            If not provided, defaults to last 3 years for 'Years'.
        SortOrder (int, optional): Sort order for the results. Default is 0.

    Returns:
        dict: A dictionary containing the KeyStats financials for the given company. Do not pass these field to CreditStats Direct source.
        Field meanings:
        - CIQ000028:	Total revenue of the company
        - CIQ004194:    Total Revenues, 1 Year Growth - Simple growth in total revenues over one year
        - CIQ000010:    Gross Profit - Total revenue excluding the cost of goods 
        - CIQ004074:    Gross Profit Margin - Gross profit as a percentage of total revenue
        - CIQ004051:    EBITDA - Earnings before interest, taxes, depreciation, and amortization
        - CIQ004047:    EBITDA Margin - EBITDA as a percentage of total revenue
        - CIQ000400:    EBIT - Earnings before interest and taxes
        - CIQ004053:    EBIT Margin - Percent of earnings before interest and taxes to total revenues
        - CIQ000007:    Earnings from Cont. Ops. - Earnings from continuing operations including all items of non-recurring nature before provision for income tax
        - CIQ004181:    Earnings from Cont Ops Margin - Percent of earnings from continuing operations to total revenues
        - CIQ000015:    Net Income - Net income before preferred dividends after adjusting for extraordinary items and accounting changes
        - CIQ004094:    Net Income Margin - Net income as a percent of operating revenue
        - CIQ000142:    Diluted EPS Excl. Extra Items - Diluted earnings per share before adjusting for preferred stock dividends and other adjustments.
        - CIQ004200:    Diluted EPS Before Extra, 1 Year Growth - Simple growth in diluted earnings per share (EPS) before extraordinary items over one year
        - CIQ003195:    Owned/Operated Same Store Sales Growth - Percent growth in sales per owned comparable store over previous year
        - CIQ000004:    EBT Excl Unusual Items - Earnings of the company excluding all items of non-recurring nature before provision for income tax
        - CIQ004117:    EBT Excluding Non-Recurring Items Margin - Profit before taxes but after non-recurring Items divided by total revenues
        - CIQ001007:    Total Assets - All assets (current and long-term) as of the date indicated, as carried on the balance sheet
        - CIQ004203:    Total Assets, 1 Year Growth - Simple growth in total assets over one year
        - CIQ003074:    Funds From Operations - Funds from operations for real estate investment trust (REIT) companies.
        - FiscalPeriodGAAP: Fiscal Period - Together with the KeyInstn and the restatement basis, completes the unique key used to identify a financial period on a fiscal basis. Concatenation of the FiscalYear and FiscalQuarter values.
        - KeyCurrency: Currency Code - Alphabetic code used to identify currencies pursuant to ISO-4217
    
    Note:
        Source for this data is S&P CapitalIQ KeyStats Data.
    """
    logger.info(
        f"get_company_CIQ_financials called for: {keyInstn}, FiscalPeriodGAAP: {FiscalPeriodGAAP}, DataSourcePeriod: {DataSourcePeriod}, SortOrder: {SortOrder}"
    )

    # Get configuration
    cfg = get_config()
    dataapi_url = cfg["dataapi_url"]

    # Set default DataSourcePeriod if not provided or empty
    if not DataSourcePeriod:
        if FiscalPeriodGAAP == "Years":
            # Default: last 3 years
            this_year = datetime.now().year
            DataSourcePeriod = ",".join([f"{this_year - i}Y" for i in range(2, -1, -1)])
        elif FiscalPeriodGAAP == "Quarters":
            # Default: current year, all quarters
            this_year = datetime.now().year
            DataSourcePeriod = ",".join([f"{this_year}Q{q}" for q in range(1, 5)])
        elif FiscalPeriodGAAP == "Interim":
            # Default: current year, both halves
            this_year = datetime.now().year
            DataSourcePeriod = f"{this_year}H1,{this_year}H2"
        elif FiscalPeriodGAAP == "LTM":
            # Default: current year, 4 LTM periods
            this_year = datetime.now().year
            DataSourcePeriod = ",".join([f"{this_year}L{i}" for i in range(1, 5)])
        else:
            DataSourcePeriod = ""

    # Prepare URL
    base_url = url = f"{dataapi_url}v2/Hydrobs/GetKeyStatsData"
    params = {
        "KeyInstn": keyInstn,
        "FiscalPeriodGAAP": f"'{FiscalPeriodGAAP}'",
        "DataSourcePeriod": DataSourcePeriod,
        "SortOrder": SortOrder
    }
    url = f"{base_url}?{urllib.parse.urlencode(params)}"

    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    headers = raw_request.headers
    logger.info(f"Headers received: {headers}")
    logger.info(f"get_company_CIQ_financials GET url: {url}")

    try:
        global async_client
        response = await async_client.get(url, headers=auth.build_auth_headers(raw_request))
        if response.status_code == 200:
            keystats_data = response.json()

            logger.info(
                f"KeyStats data returned: {len(keystats_data) if hasattr(keystats_data, '__len__') else 'unknown'} records")
            translated_data = translate_metric_keys(keystats_data)
            source = await get_mcp_tool_source(
                mcp_tool_name=get_company_CIQ_financials.__name__,
                source_url=url,
                institution_id=keyInstn,
                headers=auth.build_auth_headers(raw_request),
                default_title="Company CIQ financials"
            )

            return {"sources": source, "data": translated_data}
        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return {"error": f"{response.status_code} - {response.text}"}
    except httpx.RequestError as e:
        logger.error(f"Request failed: {e}")
        return {"error": f"Request failed: {e}"}


@mcp.tool()
async def get_Company_Audit_Information(
        keyinstn: str,
        audit_fields: str = "auditor_name,auditor_opinion,accounting_standard",
        period_start: str = "FY(now)-5",
        period_end: str = "FY(now)",
        filing_mode: str = "P",
        restatement_type: str = "LA",
        target_currency: str = "USD",
        currency_conversion_mode: str = "SpotRate"
) -> MCPResponse:
    """
    Fetches company audit information from CIQ Denim based on a list of requested fields and parameters.
    Args:
        keyinstn (str): The Instn id/MI Key/KeyInstn for the company.
        audit_fields (str, optional): A comma-separated string of fields to retrieve. Defaults to "auditor_name,auditor_opinion,accounting_standard".
            Available fields and their mappings:
            - 'auditor_name': Maps to 'IQ_AUDITOR_NAME' (The name of the auditing firm).
            - 'auditor_opinion': Maps to 'IQ_AUDITOR_OPINION' (The opinion expressed by the auditor).
            - 'accounting_standard': Maps to 'IQ_GAAP_IS' (The accounting standard, e.g., U.S. GAAP, IFRS).
        period_start (str, optional): The start of the reporting period. Defaults to "FY(now)-5". Example: "FY(now)-2".
        period_end (str, optional): The end of the reporting period. Defaults to "FY(now)".
        filing_mode (str, optional): The filing mode. Defaults to "P" (Period).
            P: Period, Used when we want to get the latestvalue for a given period
            F: Filing, needed when user wants to get the value for a specific date for a given period
        restatement_type (str, optional): The restatement type. Defaults to "LA".
            Available options:
            - L: Latest instance; but depends on your prop financials setting.
            - O: Only original instances.
            - P: Only press release instance.
            - LFR: Excludes press release instances.
            - LRI: Excludes instances without any data, but stays in the same period as Latest.
            - LRP: Excludes instances without any data, but can go back periods compared to Latest.
            - LC: Latest instance, but excludes prop financials.
            - LP: Latest instance, but excludes CIQ financials.
            - LA: Latest instance, including both CIQ and prop financials.
            - LPC: Latest instance, but if there are prop financials for that period, use that only.
            - CHP: CHP Chain built with Press Release, Original and Encore instances.
        target_currency (str, optional): The target currency for financial data. Defaults to "USD".
        currency_conversion_mode (str, optional): The currency conversion mode. Defaults to "SpotRate".
    Returns:
        MCPResponse: MCPResponse with sources, data, isError, and message fields.
    """
    cfg = get_config()
    old_ciqpro_url = cfg["old_ciqpro_url"]
    logger.info(f"get_Company_Audit_Information called for: {keyinstn} with fields: {audit_fields}")

    field_to_metric_map = {
        "auditor_name": "IQ_AUDITOR_NAME",
        "auditor_opinion": "IQ_AUDITOR_OPINION",
        "accounting_standard": "IQ_GAAP_IS"
    }

    requested_fields = [field.strip() for field in audit_fields.split(",")]
    metrics_to_fetch = [field_to_metric_map[field] for field in requested_fields if field in field_to_metric_map]

    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    headers = raw_request.headers
    source = await get_mcp_tool_source(
        mcp_tool_name=get_Company_Audit_Information.__name__,
        source_url=f"{old_ciqpro_url}#company/keyStats?Id={keyinstn}",
        institution_id=keyinstn,
        headers=auth.build_auth_headers(raw_request),
        default_title="Company Audit Information"
    )
    if not metrics_to_fetch:
        logger.error("No valid audit metrics requested.")
        return MCPResponse(
            sources=source,
            data=None,
            isError=True,
            message="No valid audit metrics requested."
        )

    try:
        auth_headers = auth.build_auth_headers(raw_request)
        company_id = await get_ciq_company_id(keyinstn, auth_headers, async_client=async_client, logger=logger)
        logger.info(f"[DenimAudit] CIQ company id resolved: {company_id}")
        token = auth_headers.get("Authorization")

        # Fetch user profile data to get the user's email
        user_profile = await fetch_user_profile_data(token)
        email = user_profile.get("Email")

        if not company_id:
            logger.error(f"[DenimAudit] Failed to resolve company_id for keyinstn: {keyinstn}")
            return MCPResponse(
                sources=source,
                data=None,
                isError=True,
                message=f"Failed to resolve company_id for keyinstn: {keyinstn}"
            )

        audit_request = CommonDenimRequest(
            symbol=company_id,
            metrics=metrics_to_fetch,
            period_start=period_start,
            period_end=period_end,
            filing_mode=filing_mode,
            restatement_type=restatement_type,
            target_currency=target_currency,
            currency_conversion_mode=currency_conversion_mode
        )

        logger.info(f"[DenimAudit] Sending SOAP request to CIQ Denim for metrics: {metrics_to_fetch}")
        data = await send_ciq_denim_request(
            token=token,
            email=email,
            request_data=audit_request,
            logger=logger
        )
        logger.info(f"[DenimAudit] SOAP request complete. Records received: {len(data) if data else 0}")
        try:
            # If DenimResponseType is a list, wrap it in the MCPResponse data field
            return MCPResponse(
                sources=source,
                data=data,
                isError=False,
                message=None
            )
        except Exception as e:
            logger.error(f"Error parsing Denim audit response: {e}")
            return MCPResponse(
                sources=source,
                data=None,
                isError=True,
                message=f"Error parsing Denim audit response: {e}"
            )
    except Exception as e:
        logger.error(f"[DenimAudit] Exception occurred: {e}", exc_info=True)
        return MCPResponse(
            sources=source,
            data=None,
            isError=True,
            message=str(e)
        )


@mcp.tool()
async def get_company_financial_highlights(
        keyInstn: str,
        period_start: str = "FY(now)-5",
        period_end: str = "FY(now)",
        filing_mode: str = "P",
        restatement_type: str = "LA",
        target_currency: str = "USD",
        currency_conversion_mode: str = "SpotRate"
) -> MCPResponse:
    """
    Fetches company Finacial Highlights from CIQ Denim based on a list of requested fields and parameters.
    Args:
        keyinstn (str): The Instn id/MI Key/KeyInstn for the company.
        period_start (str, optional): The start of the reporting period. Defaults to "FY(now)-5". Example: "FY(now)-2".
        period_end (str, optional): The end of the reporting period. Defaults to "FY(now)".
        filing_mode (str, optional): The filing mode. Defaults to "P" (Period).
            P: Period, Used when we want to get the latestvalue for a given period
            F: Filing, needed when user wants to get the value for a specific date for a given period
        restatement_type (str, optional): The restatement type. Defaults to "LA".
            Available options:
            - L: Latest instance; but depends on your prop financials setting.
            - O: Only original instances.
            - P: Only press release instance.
            - LFR: Excludes press release instances.
            - LRI: Excludes instances without any data, but stays in the same period as Latest.
            - LRP: Excludes instances without any data, but can go back periods compared to Latest.
            - LC: Latest instance, but excludes prop financials.
            - LP: Latest instance, but excludes CIQ financials.
            - LA: Latest instance, including both CIQ and prop financials.
            - LPC: Latest instance, but if there are prop financials for that period, use that only.
            - CHP: CHP Chain built with Press Release, Original and Encore instances.
        target_currency (str, optional): The target currency for financial data. Defaults to "USD".
        currency_conversion_mode (str, optional): The currency conversion mode. Defaults to "SpotRate".
    Returns:
        MCPResponse: MCPResponse with sources, data, isError, and message fields.
    """
    cfg = get_config()
    old_ciqpro_url = cfg["old_ciqpro_url"]
    logger.info(f"get_company_financial_highlights called for: {keyInstn} ")

    loader = FinancialTemplatesLoader()
    income_metrics = loader.get_all_financial_highlights_metrics()

    loader = FinancialTemplatesLoader()
    income_metrics = loader.get_metrics_for_section("FinancialHighlights")
    metrics_to_fetch = income_metrics

    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    headers = raw_request.headers
    source = await get_mcp_tool_source(
        mcp_tool_name=get_company_financial_highlights.__name__,
        source_url=f"{old_ciqpro_url}#company/keyStats?Id={keyInstn}",
        institution_id=keyInstn,
        headers=auth.build_auth_headers(raw_request),
        default_title="Company Financial Highlights"
    )
    if not metrics_to_fetch:
        logger.error("No valid Financial Highlights metrics requested.")
        return MCPResponse(
            sources=source,
            data=None,
            isError=True,
            message="No valid Financial Highlights requested."
        )

    try:
        auth_headers = auth.build_auth_headers(raw_request)
        company_id = await get_ciq_company_id(keyInstn, auth_headers, async_client=async_client, logger=logger)
        logger.info(f"[DenimFinHighlights] CIQ company id resolved: {company_id}")
        token = auth_headers.get("Authorization")

        # Fetch user profile data to get the user's email
        user_profile = await fetch_user_profile_data(token)
        email = user_profile.get("Email")

        if not company_id:
            logger.error(f"[DenimFinHighlights] Failed to resolve company_id for keyinstn: {keyInstn}")
            return MCPResponse(
                sources=source,
                data=None,
                isError=True,
                message=f"Failed to resolve company_id for keyinstn: {keyInstn}"
            )

        financial_highlight_request = CommonDenimRequest(
            symbol=company_id,
            metrics=metrics_to_fetch,
            period_start=period_start,
            period_end=period_end,
            filing_mode=filing_mode,
            restatement_type=restatement_type,
            target_currency=target_currency,
            currency_conversion_mode=currency_conversion_mode
        )

        logger.info(f"[DenimFinHighlights] Sending SOAP request to CIQ Denim for metrics: {metrics_to_fetch}")
        data = await send_ciq_denim_request(
            token=token,
            email=email,
            request_data=financial_highlight_request,
            logger=logger
        )
        logger.info(f"[DenimFinHighlights] SOAP request complete. Records received: {len(data) if data else 0}")
        try:
            # If DenimResponseType is a list, wrap it in the MCPResponse data field
            return MCPResponse(
                sources=source,
                data=data,
                isError=False,
                message=None
            )
        except Exception as e:
            logger.error(f"Error parsing Denim Financial Highlights response: {e}")
            return MCPResponse(
                sources=source,
                data=None,
                isError=True,
                message=f"Error parsing Denim Financial Highlights response: {e}"
            )
    except Exception as e:
        logger.error(f"[DenimFinHighlights] Exception occurred: {e}", exc_info=True)
        return MCPResponse(
            sources=source,
            data=None,
            isError=True,
            message=str(e)
        )


@mcp.tool()
async def get_company_income_statement(
        keyInstn: str,
        period_start: str = "FY(now)-5",
        period_end: str = "FY(now)",
        filing_mode: str = "P",
        restatement_type: str = "LA",
        target_currency: str = "USD",
        currency_conversion_mode: str = "SpotRate",
        metric_field: str = ""
) -> MCPResponse:
    """
    Fetches company Income Statement from CIQ Denim based on a list of requested fields and parameters.
    Args:
        keyinstn (str): The Instn id/MI Key/KeyInstn for the company.
        period_start (str, optional): The start of the reporting period. Defaults to "FY(now)-5". Example: "FY(now)-2".
        period_end (str, optional): The end of the reporting period. Defaults to "FY(now)".
        filing_mode (str, optional): The filing mode. Defaults to "P" (Period).
            P: Period, Used when we want to get the latestvalue for a given period
            F: Filing, needed when user wants to get the value for a specific date for a given period
        restatement_type (str, optional): The restatement type. Defaults to "LA".
            Available options:
            - L: Latest instance; but depends on your prop financials setting.
            - O: Only original instances.
            - P: Only press release instance.
            - LFR: Excludes press release instances.
            - LRI: Excludes instances without any data, but stays in the same period as Latest.
            - LRP: Excludes instances without any data, but can go back periods compared to Latest.
            - LC: Latest instance, but excludes prop financials.
            - LP: Latest instance, but excludes CIQ financials.
            - LA: Latest instance, including both CIQ and prop financials.
            - LPC: Latest instance, but if there are prop financials for that period, use that only.
            - CHP: CHP Chain built with Press Release, Original and Encore instances.
        target_currency (str, optional): The target currency for financial data. Defaults to "USD".
        currency_conversion_mode (str, optional): The currency conversion mode. Defaults to "SpotRate".
    Returns:
        MCPResponse: MCPResponse with sources, data, isError, and message fields.
    """
    cfg = get_config()
    old_ciqpro_url = cfg["old_ciqpro_url"]
    logger.info(f"get_company_income_statement called for: {keyInstn} ")

    metrics = [key.strip() for key in metric_field.split(',')] if metric_field.strip() else list(
        INCOME_STATEMENT.keys())

    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    headers = raw_request.headers
    source = await get_mcp_tool_source(
        mcp_tool_name=get_company_income_statement.__name__,
        source_url=f"{old_ciqpro_url}#company/keyStats?Id={keyInstn}",
        institution_id=keyInstn,
        headers=auth.build_auth_headers(raw_request),
        default_title="Company Income Statement"
    )

    try:
        auth_headers = auth.build_auth_headers(raw_request)
        company_id = await get_ciq_company_id(keyInstn, auth_headers, async_client=async_client, logger=logger)
        logger.info(f"[DenimIncomeStatement] CIQ company id resolved: {company_id}")
        token = auth_headers.get("Authorization")

        # Fetch user profile data to get the user's email
        user_profile = await fetch_user_profile_data(token)
        email = user_profile.get("Email")

        if not company_id:
            logger.error(f"[DenimIncomeStatement] Failed to resolve company_id for keyinstn: {keyInstn}")
            return MCPResponse(
                sources=source,
                data=None,
                isError=True,
                message=f"Failed to resolve company_id for keyinstn: {keyInstn}"
            )

        income_statement_request = CommonDenimRequest(
            symbol=company_id,
            metrics=metrics,
            period_start=period_start,
            period_end=period_end,
            filing_mode=filing_mode,
            restatement_type=restatement_type,
            target_currency=target_currency,
            currency_conversion_mode=currency_conversion_mode
        )

        data = await send_ciq_denim_request(
            token=token,
            email=email,
            request_data=income_statement_request,
            logger=logger
        )

        reduced_data: list[ReducedDenimResponse] = []
        for entry in data:
            if entry.value is not None and entry.value != "":
                reduced_data.append(ReducedDenimResponse(
                    date=entry.date,
                    value=entry.value,
                    CurrencyId=entry.CurrencyId,
                    display_name=INCOME_STATEMENT[entry.Metric]
                ))
        logger.info(f"[DenimIncomeStatement] SOAP request complete. Records received: {len(data) if data else 0}")
        try:
            # If DenimResponseType is a list, wrap it in the MCPResponse data field
            return MCPResponse(
                sources=source,
                data=reduced_data,
                isError=False,
                message=None
            )
        except Exception as e:
            logger.error(f"Error parsing Denim income statement response: {e}")
            return MCPResponse(
                sources=source,
                data=None,
                isError=True,
                message=f"Error parsing Denim income statement response: {e}"
            )
    except Exception as e:
        logger.error(f"[DenimIncomeStatement] Exception occurred: {e}", exc_info=True)
        return MCPResponse(
            sources=source,
            data=None,
            isError=True,
            message=str(e)
        )


@mcp.tool()
async def get_company_balance_sheet(
        keyInstn: str,
        period_start: str = "FY(now)-5",
        period_end: str = "FY(now)",
        filing_mode: str = "P",
        restatement_type: str = "LA",
        target_currency: str = "USD",
        currency_conversion_mode: str = "SpotRate",
        metric_field: str = ""
) -> MCPResponse:
    """
        Fetches Company Balance Sheet from CIQ Denim based on a list of requested fields and parameters.
        Args:
            keyinstn (str): The Instn id/MI Key/KeyInstn for the company.
            period_start (str, optional): The start of the reporting period. Defaults to "FY(now)-5". Example: "FY(now)-2".
            period_end (str, optional): The end of the reporting period. Defaults to "FY(now)".
            filing_mode (str, optional): The filing mode. Defaults to "P" (Period).
                P: Period, Used when we want to get the latestvalue for a given period
                F: Filing, needed when user wants to get the value for a specific date for a given period
            restatement_type (str, optional): The restatement type. Defaults to "LA".
                Available options:
                - L: Latest instance; but depends on your prop financials setting.
                - O: Only original instances.
                - P: Only press release instance.
                - LFR: Excludes press release instances.
                - LRI: Excludes instances without any data, but stays in the same period as Latest.
                - LRP: Excludes instances without any data, but can go back periods compared to Latest.
                - LC: Latest instance, but excludes prop financials.
                - LP: Latest instance, but excludes CIQ financials.
                - LA: Latest instance, including both CIQ and prop financials.
                - LPC: Latest instance, but if there are prop financials for that period, use that only.
                - CHP: CHP Chain built with Press Release, Original and Encore instances.
            target_currency (str, optional): The target currency for financial data. Defaults to "USD".
            currency_conversion_mode (str, optional): The currency conversion mode. Defaults to "SpotRate".
            metric_field (str, optional): By Default field is optional empty string ("") return all data.
                DO NOT USE S&P CapitalIQ field here, Comma-separated list of metric fields for CreditStats Direct.
                Each value must be a valid 'MetricName' as returned in this API response only.
                To discover available metric fields, first call this endpoint without specifying metric_field,
                then use the 'MetricName' values from the response.
        Returns:
            MCPResponse: MCPResponse with sources, data, isError, and message fields.
            The data is a JSON array of objects containing the following fields:
                - date: Date assigned to metric value
                - value: Value of metric
                - type: Data type of metric value. For example "double"
                - display_name: Human-Readable name of metric
                - CurrencyId: ID of Currency associated with metric
            Each object in the array is denoted by index starting from "0"
            Example data in MCPResponse:
            [ "0": {'display_name': 'Cash And Equivalents', 'date': '2024-12-31', 'value': '637959', 'CurrencyId': 'USD'}]
        """
    cfg = get_config()
    old_ciqpro_url = cfg["old_ciqpro_url"]
    logger.info(f"get_company_balance_sheet called for: {keyInstn} ")

    metrics = [key.strip() for key in metric_field.split(',')] if metric_field.strip() else list(BALANCE_SHEET.keys())

    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    source = await get_mcp_tool_source(
        mcp_tool_name=get_company_balance_sheet.__name__,
        source_url=f"{old_ciqpro_url}#company/keyStats?Id={keyInstn}",
        institution_id=keyInstn,
        headers=auth.build_auth_headers(raw_request),
        default_title="Company Balance Sheet"
    )
    try:
        auth_headers = auth.build_auth_headers(raw_request)
        company_id = await get_ciq_company_id(keyInstn, auth_headers, async_client=async_client, logger=logger)
        logger.info(f"[DenimBalanceSheet] CIQ company id resolved: {company_id}")
        token = auth_headers.get("Authorization")

        # Fetch user profile data to get the user's email
        user_profile = await fetch_user_profile_data(token)
        email = user_profile.get("Email")

        if not company_id:
            logger.error(f"[DenimBalanceSheet] Failed to resolve company_id for keyinstn: {keyInstn}")
            return MCPResponse(
                sources=source,
                data=None,
                isError=True,
                message=f"Failed to resolve company_id for keyinstn: {keyInstn}"
            )

        denim_request = CommonDenimRequest(
            symbol=company_id,
            metrics=metrics,
            period_start=period_start,
            period_end=period_end,
            filing_mode=filing_mode,
            restatement_type=restatement_type,
            target_currency=target_currency,
            currency_conversion_mode=currency_conversion_mode
        )

        logger.info(f"[DenimBalanceSheet] Sending SOAP request to CIQ Denim for metrics: {metrics}")
        data = await send_ciq_denim_request(
            token=token,
            email=email,
            request_data=denim_request,
            logger=logger
        )

        reduced_data: list[ReducedDenimResponse] = []
        for entry in data:
            if entry.value is not None and entry.value != "":
                reduced_data.append(ReducedDenimResponse(
                    date=entry.date,
                    value=entry.value,
                    CurrencyId=entry.CurrencyId,
                    display_name=BALANCE_SHEET[entry.Metric]
                ))

        logger.info(f"[DenimBalanceSheet] SOAP request complete. Records received: {len(data) if data else 0}")
        try:
            return MCPResponse(
                sources=source,
                data=reduced_data,
                isError=False,
                message=None
            )
        except Exception as e:
            logger.error(f"Error parsing Denim income statement response: {e}")
            return MCPResponse(
                sources=source,
                data=None,
                isError=True,
                message=f"Error parsing Denim income statement response: {e}"
            )
    except Exception as e:
        logger.error(f"[DenimBalanceSheet] Exception occurred: {e}", exc_info=True)
        return MCPResponse(
            sources=source,
            data=None,
            isError=True,
            message=str(e)
        )


@mcp.tool()
async def get_company_cash_flow(
        keyInstn: str,
        period_start: str = "FY(now)-5",
        period_end: str = "FY(now)",
        filing_mode: str = "P",
        restatement_type: str = "LA",
        target_currency: str = "USD",
        currency_conversion_mode: str = "SpotRate",
        metric_field: str = ""
) -> MCPResponse:
    """
        Fetches Company Cash Flow from CIQ Denim based on a list of requested fields and parameters.
        Args:
            keyinstn (str): The Instn id/MI Key/KeyInstn for the company.
            period_start (str, optional): The start of the reporting period. Defaults to "FY(now)-5". Example: "FY(now)-2".
            period_end (str, optional): The end of the reporting period. Defaults to "FY(now)".
            filing_mode (str, optional): The filing mode. Defaults to "P" (Period).
                P: Period, Used when we want to get the latestvalue for a given period
                F: Filing, needed when user wants to get the value for a specific date for a given period
            restatement_type (str, optional): The restatement type. Defaults to "LA".
                Available options:
                - L: Latest instance; but depends on your prop financials setting.
                - O: Only original instances.
                - P: Only press release instance.
                - LFR: Excludes press release instances.
                - LRI: Excludes instances without any data, but stays in the same period as Latest.
                - LRP: Excludes instances without any data, but can go back periods compared to Latest.
                - LC: Latest instance, but excludes prop financials.
                - LP: Latest instance, but excludes CIQ financials.
                - LA: Latest instance, including both CIQ and prop financials.
                - LPC: Latest instance, but if there are prop financials for that period, use that only.
                - CHP: CHP Chain built with Press Release, Original and Encore instances.
            target_currency (str, optional): The target currency for financial data. Defaults to "USD".
            currency_conversion_mode (str, optional): The currency conversion mode. Defaults to "SpotRate".
            metric_field (str, optional): By Default field is optional empty string ("") return all data.
                DO NOT USE S&P CapitalIQ field here, Comma-separated list of metric fields for CreditStats Direct.
                Each value must be a valid 'MetricName' as returned in this API response only.
                To discover available metric fields, first call this endpoint without specifying metric_field,
                then use the 'MetricName' values from the response.
        Returns:
            MCPResponse: MCPResponse with sources, data, isError, and message fields.
            The data is a JSON array of objects containing the following fields:
                - date: Date assigned to metric value
                - value: Value of metric
                - type: Data type of metric value. For example "double"
                - display_name: Human-Readable name of metric
                - CurrencyId: ID of Currency associated with metric
            Each object in the array is denoted by index starting from "0"
            Example data in MCPResponse:
            [ "0": {'display_name': 'Net Income', 'date': '2024-12-31', 'value': '637959', 'CurrencyId': 'USD'}]
        """
    cfg = get_config()
    old_ciqpro_url = cfg["old_ciqpro_url"]
    logger.info(f"get_company_cash_flow called for: {keyInstn} ")

    metrics = [key.strip() for key in metric_field.split(',')] if metric_field.strip() else list(CASH_FLOW.keys())

    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    source = await get_mcp_tool_source(
        mcp_tool_name=get_company_cash_flow.__name__,
        source_url=f"{old_ciqpro_url}#company/keyStats?Id={keyInstn}",
        institution_id=keyInstn,
        headers=auth.build_auth_headers(raw_request),
        default_title="Company Cash Flow"
    )
    try:
        auth_headers = auth.build_auth_headers(raw_request)
        company_id = await get_ciq_company_id(keyInstn, auth_headers, async_client=async_client, logger=logger)
        logger.info(f"[DenimCashFlow] CIQ company id resolved: {company_id}")
        token = auth_headers.get("Authorization")

        # Fetch user profile data to get the user's email
        user_profile = await fetch_user_profile_data(token)
        email = user_profile.get("Email")

        if not company_id:
            logger.error(f"[DenimCashFlow] Failed to resolve company_id for keyinstn: {keyInstn}")
            return MCPResponse(
                sources=source,
                data=None,
                isError=True,
                message=f"Failed to resolve company_id for keyinstn: {keyInstn}"
            )

        denim_request = CommonDenimRequest(
            symbol=company_id,
            metrics=metrics,
            period_start=period_start,
            period_end=period_end,
            filing_mode=filing_mode,
            restatement_type=restatement_type,
            target_currency=target_currency,
            currency_conversion_mode=currency_conversion_mode
        )

        logger.info(f"[DenimCashFlow] Sending SOAP request to CIQ Denim for metrics: {metrics}")
        data = await send_ciq_denim_request(
            token=token,
            email=email,
            request_data=denim_request,
            logger=logger
        )

        reduced_data: list[ReducedDenimResponse] = []
        for entry in data:
            if entry.value is not None and entry.value != "":
                reduced_data.append(ReducedDenimResponse(
                    date=entry.date,
                    value=entry.value,
                    CurrencyId=entry.CurrencyId,
                    display_name=CASH_FLOW[entry.Metric]
                ))

        logger.info(f"[DenimCashFlow] SOAP request complete. Records received: {len(data) if data else 0}")
        try:
            return MCPResponse(
                sources=source,
                data=reduced_data,
                isError=False,
                message=None
            )
        except Exception as e:
            logger.error(f"Error parsing Denim income statement response: {e}")
            return MCPResponse(
                sources=source,
                data=None,
                isError=True,
                message=f"Error parsing Denim income statement response: {e}"
            )
    except Exception as e:
        logger.error(f"[DenimCashFlow] Exception occurred: {e}", exc_info=True)
        return MCPResponse(
            sources=source,
            data=None,
            isError=True,
            message=str(e)
        )

@mcp.tool()
async def get_segment_analysis(
        keyInstn: str,
        period: str = "FY(now)",
        filing_mode: str = "P",
        restatement_type: str = "LA",
        target_currency: str = "USD",
        currency_conversion_mode: str = "SpotRate",
        rank: str = "1"
) -> MCPResponse:
    """
    Fetches segment analysis from CIQ Denim based on a list of requested fields and parameters.
    Args:
        keyinstn (str): The Instn id/MI Key/KeyInstn for the company.
        period_start (str, optional): The start of the reporting period. Defaults to "FY(now)-1". Example: "FY(now)-2".
        period_end (str, optional): The end of the reporting period. Defaults to "FY(now)".
        filing_mode (str, optional): The filing mode. Defaults to "P" (Period).
        restatement_type (str, optional): The restatement type. Defaults to "LA".
        Available options:
            - L: Latest instance; but depends on your prop financials setting.
            - O: Only original instances.
            - P: Only press release instance.
            - LFR: Excludes press release instances.
            - LRI: Excludes instances without any data, but stays in the same period as Latest.
            - LRP: Excludes instances without any data, but can go back periods compared to Latest.
            - LC: Latest instance, but excludes prop financials.
            - LP: Latest instance, but excludes CIQ financials.
            - LA: Latest instance, including both CIQ and prop financials.
            - LPC: Latest instance, but if there are prop financials for that period, use that only.
            - CHP: CHP Chain built with Press Release, Original and Encore instances.

        target_currency (str, optional): The target currency for financial data. Defaults to "USD".
        currency_conversion_mode (str, optional): The currency conversion mode. Defaults to "SpotRate".
    Returns:
         MCPResponse: MCPResponse with sources, data, isError, and message fields.
            The data is a JSON array of objects containing the following fields:
                - date: Date assigned to metric value
                - value: Value of metric
                - type: Data type of metric value. For example "double"
                - display_name: Human-Readable name of metric
                - CurrencyId: ID of Currency associated with metric
            Each object in the array is denoted by index starting from "0"
            Example data in MCPResponse:
            [ "0": {'display_name': 'Cash And Equivalents', 'date': '2024-12-31', 'value': '637959', 'CurrencyId': 'USD'}]
    """
    cfg = get_config()
    old_ciqpro_url = cfg["old_ciqpro_url"]
    logger.info(f"get_segment_analysis called for: {keyInstn} ")

    loader = FinancialTemplatesLoader()
    segment_metrics = list(SEGMENT_ANALYSIS.keys())
    metrics_to_fetch = segment_metrics

    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    headers = raw_request.headers
    try:
        source = await get_mcp_tool_source(
            mcp_tool_name=get_segment_analysis.__name__,
            source_url=f"{old_ciqpro_url}#company/keyStats?Id={keyInstn}",
            institution_id=keyInstn,
            headers=auth.build_auth_headers(raw_request),
            default_title="Segment Analysis"
        )
        if not metrics_to_fetch:
            logger.error("No valid segment analysis metrics requested.")
            return MCPResponse(
                sources=source,
                data=None,
                isError=True,
                message="No valid segment analysis metrics requested."
            )

        auth_headers = auth.build_auth_headers(raw_request)
        company_id = await get_ciq_company_id(keyInstn, auth_headers, async_client=async_client, logger=logger)
        logger.info(f"[DenimSegmentAnalysis] CIQ company id resolved: {company_id}")
        token = auth_headers.get("Authorization")

        # Fetch user profile data to get the user's email
        user_profile = await fetch_user_profile_data(token)
        email = user_profile.get("Email")

        if not company_id:
            logger.error(f"[DenimSegmentAnalysis] Failed to resolve company_id for keyinstn: {keyInstn}")
            return MCPResponse(
                sources=source,
                data=None,
                isError=True,
                message=f"Failed to resolve company_id for keyinstn: {keyInstn}"
            )

        segment_analysis_request = SegmentDenimRequest(
            symbol=company_id,
            metrics=metrics_to_fetch,
            period=period,
            filing_mode=filing_mode,
            restatement_type=restatement_type,
            target_currency=target_currency,
            currency_conversion_mode=currency_conversion_mode,
            rank=rank
        )

        logger.info(
            f"[DenimSegmentAnalysis] Sending SOAP request to CIQ Denim for parameters: {segment_analysis_request.to_json_string()}")
        logger.info(f"[DenimSegmentAnalysis] Sending SOAP request to CIQ Denim for metrics: {metrics_to_fetch}")
        logger.info(f"[DenimSegmentAnalysis] Sending SOAP request to CIQ Denim for token: {token}")
        data = await send_ciq_denim_request(
            token=token,
            email=email,
            request_data=segment_analysis_request,
            logger=logger
        )

        reduced_data: list[ReducedDenimResponse] = []
        for entry in data:
            if entry.value is not None and entry.value != "":
                reduced_data.append(ReducedDenimResponse(
                    date=entry.date,
                    value=entry.value,
                    CurrencyId=entry.CurrencyId,
                    display_name=SEGMENT_ANALYSIS[entry.Metric]
                ))

        logger.info(f"[DenimSegmentAnalysis] SOAP request complete. Records received: {len(data) if data else 0}")
        try:
            return MCPResponse(
                sources=source,
                data=reduced_data,
                isError=False,
                message=None
            )
        except Exception as e:
            logger.error(f"Error parsing Denim segment analysis response: {e}")
            return MCPResponse(
                sources=source,
                data=None,
                isError=True,
                message=f"Error parsing Denim segment analysis response: {e}"
            )
    except Exception as e:
        logger.error(f"[DenimSegmentAnalysis] Exception occurred: {e}", exc_info=True)
        return MCPResponse(
            sources=source,
            data=None,
            isError=True,
            message=str(e)
        )


@mcp.tool()
async def get_estimates_consensus_data(
        keyInstn: str,
        period_start: int = 2015,
        period_end: int = 2025,
) -> MCPResponse:
    """
    Company Estimate Consensus

    Fetches annual company-level consensus estimates for a specified period. This tool
    provides future and historical estimates for key financial metrics. The data is returned
    in a long format, with each record representing a single metric for a single year.

    Flow:
    1. Constructs a URL using the company's keyInstn and the specified period range.
    2. Fetches annual consensus data from the Capital IQ 'companyEstimatesConsensus' endpoint.
    3. Returns a list of estimate records, one for each metric and year combination.

    Args:
        keyInstn (str): The company's unique S&P institution identifier.
        period_start (int, optional): The starting year for the estimate period. Defaults to 2016.
        period_end (int, optional): The ending year for the estimate period. Defaults to 2025.

    Returns:
        MCPResponse with:
            data: List[CompanyEstimatesConsensusRecord] - A list of estimate data records in long format.
            sources: Source with title and a dynamic URL to the Capital IQ platform.
            message: A summary of the operation.
            isError: Boolean indicating success or failure.

    Example Request:
        await get_estimates_consensus_data(keyInstn="4121840", period_start=2022, period_end=2023)

    Example Response (data portion):
        [
            CompanyEstimatesConsensusRecord(
                EstimatePeriod='FY 2022 - Jun 2022',
                EstimateOf='REV ',
                ProductCaption='Actuals/Estimates',
                EstimateConsensusMedian=6722450000.0,
                EstimatesActual=6509800000.0,
                EstimateOfDescription='Revenue',
                Year=2022
            ),
            CompanyEstimatesConsensusRecord(
                EstimatePeriod='FY 2023 - Jun 2023',
                EstimateOf='REV ',
                ProductCaption='Actuals/Estimates',
                EstimateConsensusMedian=6328600000.0,
                EstimatesActual=None,
                EstimateOfDescription='Revenue',
                Year=2023
            )
        ]
    """
    global async_client
    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    auth_headers = auth.build_auth_headers(raw_request)

    logger.info("[EstConsensus] ENTER get_estimates_consensus_data keyInstn=%s period=%s-%s", keyInstn, period_start,
                period_end)

    cfg = get_config()
    base_url = cfg.get("capitaliq_base_url")
    old_ciqpro_url = cfg["old_ciqpro_url"]

    client = async_client or httpx.AsyncClient(timeout=30.0)

    url = f"{base_url}AIReportBuilder/companyEstimatesConsensus/{keyInstn}/Y/{period_start}/{period_end}"

    source_obj = await get_mcp_tool_source(
        mcp_tool_name=get_estimates_consensus_data.__name__,
        source_url=f"{old_ciqpro_url}#company/consensusEstimates?ID={keyInstn}",
        institution_id=keyInstn,
        headers=auth.build_auth_headers(raw_request),
        default_title="Company Estimate Consensus"
    )
    headers = {**auth_headers, "Accept": "application/json"}

    logger.info("[Estimate Consensus] Requesting URL: %s", url)

    try:
        resp = await client.get(url, headers=headers)
        resp.raise_for_status()
        payload = resp.json()
    except Exception as e:
        logger.error("[EstConsensus] HTTP request failed for keyInstn=%s: %s", keyInstn, e)
        if async_client is None: await client.aclose()
        return MCPResponse(sources=source_obj, data=None, isError=True, message=f"Request failed: {e}")

    if not isinstance(payload, list):
        if async_client is None: await client.aclose()
        return MCPResponse(sources=source_obj, data=None, isError=True, message="Unexpected payload structure")

    records = [CompanyEstimatesConsensusRecord(**row) for row in payload]

    logger.info("[EstConsensus] DONE keyInstn=%s, retrieved %d records.", keyInstn, len(records))

    if async_client is None:
        await client.aclose()

    return MCPResponse(
        sources=source_obj,
        data=records,
        isError=False,
        message=f"Retrieved {len(records)} estimate records."
    )


# Define a custom lifespan for FastAPI with a task to manage MCP@mcp.tool()
@mcp.tool()
async def get_company_performance_analysis(
        keyInstn: str,
        period_start: str = "FY(now)-5",
        period_end: str = "FY(now)",
        filing_mode: str = "P",
        restatement_type: str = "LA",
        target_currency: str = "USD",
        currency_conversion_mode: str = "SpotRate",
        metric_field: str = ""
) -> MCPResponse:
    """
    Fetches Company Performance Analysis from CIQ Denim based on a list of requested fields and parameters.
    Args:
        keyInstn (str): The Instn id/MI Key/KeyInstn for the company.
        period_start (str, optional): The start of the reporting period. Defaults to "FY(now)-5". Example: "FY(now)-2".
        period_end (str, optional): The end of the reporting period. Defaults to "FY(now)".
        filing_mode (str, optional): The filing mode. Defaults to "P" (Period).
            P: Period, Used when we want to get the latest value for a given period.
            F: Filing, needed when user wants to get the value for a specific date for a given period.
        restatement_type (str, optional): The restatement type. Defaults to "LA".
            Available options:
            - L: Latest instance; but depends on your prop financials setting.
            - O: Only original instances.
            - P: Only press release instance.
            - LFR: Excludes press release instances.
            - LRI: Excludes instances without any data, but stays in the same period as Latest.
            - LRP: Excludes instances without any data, but can go back periods compared to Latest.
            - LC: Latest instance, but excludes prop financials.
            - LP: Latest instance, but excludes CIQ financials.
            - LA: Latest instance, including both CIQ and prop financials.
            - LPC: Latest instance, but if there are prop financials for that period, use that only.
            - CHP: CHP Chain built with Press Release, Original and Encore instances.
        target_currency (str, optional): The target currency for financial data. Defaults to "USD".
        currency_conversion_mode (str, optional): The currency conversion mode. Defaults to "SpotRate".
        metric_field (str, optional): By default, field is optional empty string ("") to return all data.
            Comma-separated list of metric fields for Performance Analysis.
            Each value must be a valid 'MetricName' as defined in PERFORMANCE_ANALYSIS mapping.
            To discover available metric fields, first call this endpoint without specifying metric_field,
            then use the 'MetricName' values from the response.
    Returns:
        MCPResponse: MCPResponse with sources, data, isError, and message fields.
        The data is a JSON array of objects containing the following fields:
            - date: Date assigned to metric value
            - value: Value of metric
            - type: Data type of metric value. For example "double"
            - display_name: Human-Readable name of metric
            - CurrencyId: ID of Currency associated with metric
        Each object in the array is denoted by index starting from "0"
        Example data in MCPResponse:
        [ "0": {'display_name': 'AR Turns', 'date': '2024-12-31', 'value': '637959', 'CurrencyId': 'USD'}]
    """
    cfg = get_config()
    old_ciqpro_url = cfg["old_ciqpro_url"]
    logger.info(f"get_company_performance_analysis called for: {keyInstn}")

    metrics = [key.strip() for key in metric_field.split(',')] if metric_field.strip() else list(
        PERFORMANCE_ANALYSIS.keys())

    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    source = await get_mcp_tool_source(
        mcp_tool_name=get_company_performance_analysis.__name__,
        source_url=f"{old_ciqpro_url}#company/keyStats?Id={keyInstn}",
        institution_id=keyInstn,
        headers=auth.build_auth_headers(raw_request),
        default_title="Company Performance Analysis"
    )
    try:
        auth_headers = auth.build_auth_headers(raw_request)
        company_id = await get_ciq_company_id(keyInstn, auth_headers, async_client=async_client, logger=logger)
        logger.info(f"[DenimPerformanceAnalysis] CIQ company id resolved: {company_id}")
        token = auth_headers.get("Authorization")

        user_profile = await fetch_user_profile_data(token)
        email = user_profile.get("Email")

        if not company_id:
            logger.error(f"[DenimPerformanceAnalysis] Failed to resolve company_id for keyInstn: {keyInstn}")
            return MCPResponse(
                sources=source,
                data=None,
                isError=True,
                message=f"Failed to resolve company_id for keyInstn: {keyInstn}"
            )

        denim_request = CommonDenimRequest(
            symbol=company_id,
            metrics=metrics,
            period_start=period_start,
            period_end=period_end,
            filing_mode=filing_mode,
            restatement_type=restatement_type,
            target_currency=target_currency,
            currency_conversion_mode=currency_conversion_mode
        )

        logger.info(f"[DenimPerformanceAnalysis] Sending SOAP request to CIQ Denim for metrics: {metrics}")
        data = await send_ciq_denim_request(
            token=token,
            email=email,
            request_data=denim_request,
            logger=logger
        )

        reduced_data: list[ReducedDenimResponse] = []
        for entry in data:
            if entry.value is not None and entry.value != "":
                reduced_data.append(ReducedDenimResponse(
                    date=entry.date,
                    value=entry.value,
                    CurrencyId=entry.CurrencyId,
                    display_name=PERFORMANCE_ANALYSIS.get(entry.Metric, entry.Metric)
                ))

        logger.info(f"[DenimPerformanceAnalysis] SOAP request complete. Records received: {len(data) if data else 0}")
        try:
            return MCPResponse(
                sources=source,
                data=reduced_data,
                isError=False,
                message=None
            )
        except Exception as e:
            logger.error(f"Error parsing Denim performance analysis response: {e}")
            return MCPResponse(
                sources=source,
                data=None,
                isError=True,
                message=f"Error parsing Denim performance analysis response: {e}"
            )
    except Exception as e:
        logger.error(f"[DenimPerformanceAnalysis] Exception occurred: {e}", exc_info=True)
        return MCPResponse(
            sources=source,
            data=None,
            isError=True,
            message=str(e)
        )


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Initializing MCP server task group...")
    global async_client
    async_client = httpx.AsyncClient(timeout=10)
    async with contextlib.AsyncExitStack() as stack:
        await stack.enter_async_context(mcp.session_manager.run())
        yield
    await async_client.aclose()


@router.get("/financials/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "ok"}


# Create FastAPI app with lifespan
app = FastAPI(lifespan=lifespan)
app.mount("/financials", mcp.streamable_http_app())
app.include_router(router)
logger.info("Financial MCP Server started successfully.")
