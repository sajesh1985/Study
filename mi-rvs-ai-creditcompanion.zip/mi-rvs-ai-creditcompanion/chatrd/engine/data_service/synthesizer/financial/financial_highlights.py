import logging
from typing import Optional

from chatrd.core.thread_utils import submit_to_shared_thread_pool
from chatrd.engine.components.query_analyzer.translator.utils import (
    Get_translation_result,
)
from chatrd.engine.data_service.schema import (
    Analyzer,
    ProcessorInput,
    Retriever,
    Synthesizer,
)
from chatrd.engine.data_service.synthesizer.base import BaseSynthesizer
from chatrd.engine.data_service.synthesizer.financial.utils import (
    _merge_definitions_data,
    clean_and_transform_dataframe,
    source_description,
    template_leading_line,
)
from chatrd.engine.data_service.synthesizer.utils import (
    full_response,
    get_api_info,
    text_response,
)

logger = logging.getLogger(__name__)


class FinancialHighlightsSynthesizer(BaseSynthesizer):
    def synthesize(
        self,
        processor: Optional[ProcessorInput] = None,
        analyzer: Optional[Analyzer] = None,
        retriever: Retriever = None,
        multi_uc_type: Optional[bool] = False,
    ) -> Synthesizer:
        """
        Synthesizes a response based on the provided processor, analyzer, and retriever.

        Args:
            processor (Optional[ProcessorInput]): An object containing entity data.
            analyzer (Optional[Analyzer]): An optional analyzer object.
            retriever (Retriever): An object to retrieve API data.

        Returns:
            Synthesizer: An instance of Synthesizer containing the response and source description.
        """
        company_list = processor.entities.get("companies", [{}])
        company_name_list = [company["name"] for company in company_list]
        company = company_list[0]
        entity_id = str(company.get("mi_id", ""))
        rd_sector = company.get("rd_sector", [""])[0]

        metrics_status = "general" if analyzer.response.get("metrics") == ["General"] else "empty"
        if not processor.error_flag:
            template = template_leading_line(company_name_list, metrics_status, rd_sector, entity_id)
        else:
            template = processor.template

        template = Get_translation_result(template, processor.original_language)
        template = template.result()

        if len(company_list) < 2:
            if multi_uc_type:
                value_data = retriever.api_data.get("value")
                response_data = clean_and_transform_dataframe(value_data)
                response = full_response(template, response_data, "table")
            else:
                response_data = _merge_definitions_data(retriever.api_data)
                response = full_response(template, response_data, "csd_table")
            response = full_response(template, response_data, "csd_table")
            company_name = company_name_list[0] if company_name_list else ""
            source_url = source_description(company_name, entity_id, rd_sector, None, response_data)
        else:
            response = [text_response(template)]
            source_url = []

        api_info = get_api_info(api_method=retriever.api_method, api_type=retriever.api_type, url=retriever.url)
        return Synthesizer(data_service_response=response, source_description=source_url, api_info=api_info)
