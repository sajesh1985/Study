CREDITACTION_EXTRACTION_PROMPT = """You are an expert S&P credit analyst tasked with extracting credit rating actions, timeframes, and display preferences from user queries.

**OBJECTIVE:**
Extract S&P credit rating action(s) and time frame preferences from the USER QUESTION below.

**INSTRUCTIONS:**
1. Extract ONLY S&P credit rating actions, and time frame from the USER QUESTION
2. Return ONLY a Python dictionary with keys "value" and "time_frame"
3. Do NOT provide explanations, comments, or additional text
4. ALWAYS return both keys ("value", "time_frame") in the response
5. Keywords like "recent", "latest", "lately", "last", etc. should be interpreted as a 1-year lookback period (last 12 months) unless otherwise specified, and are used for timeframe extraction

**OUTPUT FORMAT REQUIREMENTS:**
- "value": Return as string when available, None when not available
- "time_frame": Return as string when available, None when not available  
- Both value and time_frame must be strings (when present) or None (when absent)
- Output must be a valid Python dictionary format

**SUPPORTED CREDIT ACTIONS:**
- "upgrade": Improvement in creditworthiness (synonyms: upgraded, rating upgrade, positive rating action)
- "downgrade": Deterioration in creditworthiness (synonyms: downgraded, rating downgrade, negative rating action)  
- "new rating": Initial rating assignment (synonyms: newly rated, first-time rating, initial rating)

**CREDIT ACTION EXTRACTION RULES:**
- Single action: Return as string (e.g., "upgrade", "downgrade", "new rating")
- Multiple actions: Return as comma-separated string (e.g., "upgrade, downgrade")
- Use exact action names from the supported list above
- For general "rating actions, rating activity, rating changes" queries: Return "upgrade, downgrade, new rating" (all three actions)
- If no credit rating action mentioned: Return None

**TIME FRAME EXTRACTION RULES:**
- Format: "[MM/DD/YYYY]-[MM/DD/YYYY]" (start date to end date with brackets)
- Current date: {current_date}
- If no timeframe specified for actions: Return None
- Common timeframes:
  * "last quarter" = previous calendar quarter (e.g., if today is May 15, 2024, last quarter is 01/01/2024-03/31/2024)
  * "last 6 months" = last 6 months
  * "recent", "latest", "lately" = last 12 months
  * "this year"/"2024" = January 1 to December 31 of specified year
  * "last year" = previous calendar year
  * "since [month/year]" = from start of specified month/year to current date


**EXAMPLES:**
{creditaction_extraction_examples}

**EXPECTED OUTPUT FORMAT (PYTHON DICTIONARY):**
- When no credit action found: {{"value": None, "time_frame": None}}
- When only credit action found: {{"value": "upgrade", "time_frame": None}}
- When action with timeframe: {{"value": "downgrade", "time_frame": "[01/01/2024]-[12/31/2024]"}}

USER QUESTION: {user_question}"""

CREDITACTION_EXTRACTION_EXAMPLES = [
    # Clear downgrade with specific year
    (
        "Give me downgraded companies in 2024.",
        {"value": "downgrade", "time_frame": "[01/01/2024]-[12/31/2024]"},
    ),
    # Upgrade with relative timeframe
    (
        "Provide me list of upgraded companies in the last 3 months",
        {
            "value": "upgrade",
            "time_frame": "[{TODAY_DATE + relativedelta(months=-3):%m/%d/%Y}]-[{TODAY_DATE:%m/%d/%Y}]",
        },
    ),
    # General rating actions without timeframe
    (
        "What are the rating actions for the companies",
        {"value": "upgrade, downgrade, new rating", "time_frame": None},
    ),
    # Not a credit action query - asking for rated companies without action type
    (
        "Give me rated companies in {TODAY_DATE.year}.",
        {"value": None, "time_frame": None},
    ),
    # New ratings with specific year
    (
        "Show me newly rated entities in 2024",
        {"value": "new rating", "time_frame": "[01/01/2024]-[12/31/2024]"},
    ),
    # Action without timeframe
    (
        "Give me 20 corporations that have been upgraded",
        {"value": "upgrade", "time_frame": None},
    ),
    # New ratings with relative timeframe (last quarter = 3 months)
    (
        "Give list of corporates that upgraded in the previous quarter.",
        {
            "value": "upgrade",
            "time_frame": "[{TODAY_DATE + relativedelta(months=-3):%m/%d/%Y}]-[{TODAY_DATE:%m/%d/%Y}]",
            "display_column": False,
        },
        "The time frame for the rating must cover the start and end of previous quarter. It should not be last 3 months.",
        {
            "value": "upgrade",
            "time_frame": "[{PREVIOUS_QUARTER_START}]-[{PREVIOUS_QUARTER_END}]",
            "display_column": False,
        },
    ),
    (
        "Provide me a list of newly rated US firms in the last quarter",
        {
            "value": "new rating",
            "time_frame": "[{PREVIOUS_QUARTER_START}]-[{PREVIOUS_QUARTER_END}]",
        },
    ),
    # Timeframe for financials, not actions - important distinction
    (
        "Give me rating actions for the entities with their financials in the last 6 months.",
        {"value": "upgrade, downgrade, new rating", "time_frame": None},
    ),
    # Multiple specific actions
    (
        "Give me upgrades and downgrades from last month",
        {
            "value": "upgrade, downgrade",
            "time_frame": "[{TODAY_DATE + relativedelta(months=-1):%m/%d/%Y}]-[{TODAY_DATE:%m/%d/%Y}]",
        },
    ),
    # "Display column" type prompt does not supported in credit action extraction. Should return all actions without timeframe.
    (
        "Give me companies and include their credit actions.",
        {"value": "upgrade, downgrade, new rating", "time_frame": None},
    ),
    (
        "List companies and display their rating changes.",
        {"value": "upgrade, downgrade, new rating", "time_frame": None},
    ),
    # No credit actions mentioned
    (
        "What are the financial metrics for technology companies?",
        {"value": None, "time_frame": None},
    ),
    # Action with past year timeframe
    (
        "List companies with negative rating changes in the past year",
        {
            "value": "downgrade",
            "time_frame": "[01/01/{TODAY_DATE.year - 1}]-[12/31/{TODAY_DATE.year - 1}]",
        },
    ),
    # Positive rating actions this year
    (
        "Show me positive rating actions this year",
        {
            "value": "upgrade",
            "time_frame": "[01/01/{TODAY_DATE.year}]-[12/31/{TODAY_DATE.year}]",
        },
    ),
    # Question with timeframe but no actions
    (
        "Show me companies with high revenue in Q1 2024.",
        {"value": None, "time_frame": None},
    ),
    (
        "list me companies and include latest rating action",
        {
            "value": "upgrade, downgrade, new rating",
            "time_frame": "[{TODAY_DATE + relativedelta(years=-1):%m/%d/%Y}]-[{TODAY_DATE:%m/%d/%Y}]",
        },
    ),
]
