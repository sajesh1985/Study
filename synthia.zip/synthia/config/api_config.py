import json
import os
import time
import logging
from typing import Any, Optional, Dict
from functools import lru_cache

from src.synthia.aws_utils.aws_client import get_aws_client, get_parameter, get_env_specific_params_key, get_region
from src.synthia.utils.logging_config import configure_logging


logger = configure_logging(logger_name=__name__, module_levels={"boto3": logging.WARNING, "botocore": logging.WARNING})


class Config:
    """
    Singleton configuration loader from AWS Parameter Store.
    Access values via .get() or [].
    One instance per parameter name.
    """
    _instances: Dict[str, "Config"] = {}

    def __new__(cls, parameter_name: str, cache_ttl: int = 10 * 60) -> "Config":
        if parameter_name in cls._instances:
            logger.info(f"Using existing Config instance for {parameter_name}")
            return cls._instances[parameter_name]
        instance = super().__new__(cls)
        logger.info(f"Creating new Config instance for {parameter_name}")
        cls._instances[parameter_name] = instance
        return instance

    def __init__(self, parameter_name: str, cache_ttl: int = 10 * 60) -> None:
        if hasattr(self, "_initialized") and self._initialized:
            return
        self.__parameter_name: str = parameter_name
        self.__config: Dict[str, Any] = {}
        self.__last_fetched: float = 0
        self.__config_cache_ttl: int = cache_ttl
        self._fetch_config()
        self._initialized = True

    def set_config_cache_ttl(self, ttl: int) -> None:
        """
        Set the cache time-to-live (TTL) in seconds.
        """
        if not isinstance(ttl, (int, float)) or ttl < 0:
            logger.error("TTL must be a non-negative number")
            raise ValueError("TTL must be a non-negative number")
        self.__config_cache_ttl = ttl
        logger.info(f"Config cache TTL set to {ttl} seconds")


    def __getitem__(self, key: str) -> Any:
        """
        Get a config value by key, raises KeyError if not found.
        """
        self._refresh_if_needed()
        if key in self.__config:
            return self.__config[key]
        logger.error(f"Key '{key}' not found in config")
        raise KeyError(f"Key '{key}' not found in config")

    def clean_env_flag(self, name: str, default: Any = False) -> str:
        """
        Clean and standardize environment variable flags.
        """
        raw = os.getenv(name)
        if raw is None:
            return default
        cleaned = raw.strip().strip('"').strip("'").lower()
        return cleaned

    def _get_config_dict(self) -> Dict[str, Any]:
        """
        Fetch and parse config from AWS Parameter Store.
        """
        # For local testing, load from local file if LOCAL_URLS is set
        if self.clean_env_flag("LOCAL_URLS", "false").lower() in ("true", "1", "yes"):
            logger.info(f"Loading config from local file for testing, {self.__parameter_name}")
            local_path = None
            base_path = os.path.dirname(__file__)

            if self.__parameter_name.endswith("llm-config"):
                local_path = "local_config/llm_config.json"
                local_path = os.path.join(base_path, local_path)
                logger.info(f"Loading local config from {local_path}")
            elif self.__parameter_name.endswith("config"):
                local_path = "local_config/api_config.json"
                local_path = os.path.join(base_path, local_path)
                logger.info(f"Loading local config from {local_path}")
            if not local_path or not os.path.exists(local_path):

                logger.error(f"Local config file {local_path} not found")
                raise FileNotFoundError(f"Local config file {local_path} not found")
            return json.load(open(local_path, "r"))

        # Fetch from AWS Parameter Store
        logger.info(f"Fetching config from AWS Parameter Store: {self.__parameter_name}")
        parameter_store_client = get_aws_client("ssm", region=get_region())
        config_dict = get_parameter(parameter_store_client, self.__parameter_name)
        logger.info(f"Fetched config from parameter store: {self.__parameter_name}")
        return json.loads(config_dict)

    def _fetch_config(self) -> None:
        """
        Fetch and cache the config from AWS.
        """
        try:
            self.__config = self._get_config_dict()
            self.__last_fetched = time.time()
            logger.info("Configuration fetched and loaded successfully")
        except Exception as e:
            logger.exception("Failed to fetch config")
            raise RuntimeError(f"Failed to fetch config: {e}")

    def _refresh_if_needed(self) -> None:
        """
        Refresh config if cache expired.
        """
        if not self.__config or (time.time() - self.__last_fetched) > self.__config_cache_ttl:
            logger.debug("Refreshing configuration cache")
            self._fetch_config()

    def get(self, key: str, default: Any = None) -> Any:
        """
        Get a config value by key, return default if not found.
        """
        self._refresh_if_needed()
        value = self.__config.get(key, default)
        return value

    def as_dict(self) -> Dict[str, Any]:
        """
        Return the config as a dictionary.
        """
        self._refresh_if_needed()
        return self.__config


def get_config(
    parameter_name: str = "config",
    ttl: Optional[int] = None,
    refresh: bool = False
) -> Config:
    """
    Get the Config singleton per parameter name.
    """
    param_key = get_env_specific_params_key(parameter_name)
    logger.info(f"Fetch param key :: {param_key}")
    config = Config(parameter_name=param_key)

    if ttl is not None:
        config.set_config_cache_ttl(ttl)
        logger.info(f"Config cache TTL updated to {ttl} seconds")

    if refresh:
        config._fetch_config()
        logger.info("Config refreshed on request")

    return config

def update_config_cache_ttl(config: Config, ttl: int) -> None:
    """
    Update the config cache TTL.
    """
    if config is None:
        logger.error("Config not initialized. Call initialize_config() first.")
        raise RuntimeError("Config not initialized. Call initialize_config() first.")
    config.set_config_cache_ttl(ttl)
