import json
import logging
from typing import List, Union

import boto3

from chatrd.core.code_generation.prompts import (
    get_prompt_for_multiple_tables,
    get_prompt_for_single_table,
)
from chatrd.core.code_generation.schema import DataFrame
from chatrd.core.llm import LCLLMFactory
from chatrd.engine.configuration import Constants, get_config_machinery

logger = logging.getLogger(__name__)

config_machinery = get_config_machinery()


class PromptProcessor:
    def __init__(
        self,
    ):
        self.llm = LCLLMFactory().get_llm(
            deployment_name_or_model_id=config_machinery.get_config_value(
                Constants.GeneralConstants.MODEL_NAME_FOR_CODE_GENERATION
            ),
            temperature=config_machinery.get_config_value(Constants.GeneralConstants.TEMPERATURE_FOR_CODE_GENERATION),
            max_tokens_to_sample=4096,
        )

    def process_prompt(
        self,
        prompt: str,
        dfs: Union[DataFrame, List[DataFrame]],
        examples_text: str = "",
        error_message: str = "",
        last_generated_code: str = "",
    ) -> str:
        if isinstance(dfs, DataFrame) or len(dfs) == 1:
            if not isinstance(dfs, DataFrame):
                # uc_types: rating and rating action combined, data reduced to a single use case
                dfs = dfs[0]
                dfs.name = "df"
            data_frame_schema = dfs.get_schema()
            table_description = data_frame_schema["Table Description"]
            column_description = data_frame_schema["Columns"]
            sample_data = data_frame_schema["Sample Data"]
            special_instructions = data_frame_schema["Special Instructions"]
            full_prompt = get_prompt_for_single_table(
                prompt, table_description, sample_data, column_description, special_instructions
            )
        else:
            full_prompt = get_prompt_for_multiple_tables(prompt, dfs, examples_text)
        logger.info(full_prompt)
        if error_message:
            full_prompt += f"\n\nPreviously Generated Code:\n\n{last_generated_code}\n\nPrevious error encountered:\n\n{error_message}\n\nPlease correct the code accordingly.\n"

        full_prompt += "\nProvide only the Python code without explanations."

        response = self.llm.invoke(full_prompt)
        return response.content
