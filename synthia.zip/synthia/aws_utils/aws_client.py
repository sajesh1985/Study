from botocore.config import Config
from boto3 import Session
from botocore.client import BaseClient
import json
from botocore.exceptions import ClientError


def get_aws_client(service: str, region: str = "us-east-1", max_attempts: int = 10, pool_connections: int = 50
                   , read_timeout: int = 420, connect_timeout: int = 10,
    ):
    session = Session()

    retry_config = Config(
        region_name=region,
        retries={
            "max_attempts": max_attempts,
            "mode": "standard"
        },
        max_pool_connections=pool_connections,
        read_timeout=read_timeout,
        connect_timeout=connect_timeout
    )

    client = session.client(
        service_name=service, config=retry_config, region_name=region,
    )

    return client


def get_secret(secrets_manager_client: BaseClient, secret_name: str):
    response = secrets_manager_client.get_secret_value(SecretId=secret_name)
    secret = json.loads(response.get("SecretString"))
    return secret

