import asyncio
import logging
from typing import Dict, List, Optional, Any
from datetime import datetime
from dataclasses import dataclass, field
from enum import Enum
import json

from src.synthia.utils.logging_config import configure_logging

logger = configure_logging(
    log_file="synthia.log",
    module_levels={__name__: logging.DEBUG},  # Set this module to DEBUG
)
class MessageStatus(Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"

@dataclass
class QueueMessage:
    id: str
    queue_name: str
    payload: Dict[str, Any]
    status: MessageStatus = MessageStatus.PENDING
    created_at: datetime = field(default_factory=datetime.now)
    processing_started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    error: Optional[str] = None
    retry_count: int = 0
    max_retries: int = 3
    visibility_timeout: int = 300  # 5 minutes default

class InMemoryQueue:
    def __init__(self):
        self._queues: Dict[str, List[QueueMessage]] = {}
        self._processing: Dict[str, QueueMessage] = {}
        self._lock = asyncio.Lock()
        self._message_counter = 0

    async def create_queue(self, queue_name: str) -> None:
        """Create a new queue if it doesn't exist."""
        async with self._lock:
            if queue_name not in self._queues:
                self._queues[queue_name] = []
                logger.info(f"Created queue: {queue_name}")

    async def send_message(
        self, 
        queue_name: str, 
        payload: Dict[str, Any],
        max_retries: int = 3
    ) -> str:
        """Send a message to the queue."""
        await self.create_queue(queue_name)
        
        async with self._lock:
            self._message_counter += 1
            message_id = f"msg_{self._message_counter}_{datetime.now().timestamp()}"
            
            message = QueueMessage(
                id=message_id,
                queue_name=queue_name,
                payload=payload,
                max_retries=max_retries
            )
            
            self._queues[queue_name].append(message)
            logger.info(f"Message {message_id} added to queue {queue_name}")
            
            return message_id

    async def receive_message(
        self, 
        queue_name: str, 
        visibility_timeout: int = 300
    ) -> Optional[QueueMessage]:
        """Receive a message from the queue (polling)."""
        await self.create_queue(queue_name)
        
        async with self._lock:
            queue = self._queues[queue_name]
            
            # Find first pending message
            for i, message in enumerate(queue):
                if message.status == MessageStatus.PENDING:
                    # Mark as processing
                    message.status = MessageStatus.PROCESSING
                    message.processing_started_at = datetime.now()
                    message.visibility_timeout = visibility_timeout
                    
                    # Move to processing dict for tracking
                    self._processing[message.id] = message
                    
                    # Remove from queue
                    queue.pop(i)
                    
                    logger.info(f"Message {message.id} received from queue {queue_name}")
                    return message
            
            return None

    async def delete_message(self, message_id: str) -> bool:
        """Delete a message after successful processing."""
        async with self._lock:
            if message_id in self._processing:
                message = self._processing[message_id]
                message.status = MessageStatus.COMPLETED
                message.completed_at = datetime.now()
                del self._processing[message_id]
                logger.info(f"Message {message_id} deleted successfully")
                return True
            return False

    async def return_message_to_queue(self, message_id: str, error: Optional[str] = None) -> bool:
        """Return a message to the queue for retry or mark as failed."""
        async with self._lock:
            if message_id not in self._processing:
                return False
                
            message = self._processing[message_id]
            message.retry_count += 1
            
            if error:
                message.error = error
            
            if message.retry_count >= message.max_retries:
                message.status = MessageStatus.FAILED
                logger.error(f"Message {message_id} failed after {message.retry_count} retries")
                del self._processing[message_id]
            else:
                message.status = MessageStatus.PENDING
                message.processing_started_at = None
                self._queues[message.queue_name].append(message)
                del self._processing[message_id]
                logger.info(f"Message {message_id} returned to queue for retry {message.retry_count}")
            
            return True

    async def get_queue_stats(self, queue_name: str) -> Dict[str, Any]:
        """Get statistics for a queue."""
        await self.create_queue(queue_name)
        
        async with self._lock:
            pending_count = len([m for m in self._queues[queue_name] if m.status == MessageStatus.PENDING])
            processing_count = len([m for m in self._processing.values() if m.queue_name == queue_name])
            
            return {
                "queue_name": queue_name,
                "pending_messages": pending_count,
                "processing_messages": processing_count,
                "total_messages": pending_count + processing_count
            }

    async def list_queues(self) -> List[str]:
        """List all queue names."""
        return list(self._queues.keys())

    async def purge_queue(self, queue_name: str) -> int:
        """Remove all messages from a queue."""
        async with self._lock:
            if queue_name not in self._queues:
                return 0
            
            count = len(self._queues[queue_name])
            self._queues[queue_name].clear()
            
            # Also remove from processing if they belong to this queue
            processing_to_remove = [
                msg_id for msg_id, msg in self._processing.items() 
                if msg.queue_name == queue_name
            ]
            for msg_id in processing_to_remove:
                del self._processing[msg_id]
            
            logger.info(f"Purged {count} messages from queue {queue_name}")
            return count

# Global queue manager instance
_queue_manager = InMemoryQueue()

def get_queue_manager() -> InMemoryQueue:
    """Get the global queue manager instance."""
    return _queue_manager