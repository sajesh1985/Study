"""Configuration settings for Synthia application."""

from pydantic_settings import BaseSettings
from pydantic import Field
from typing import Optional
from functools import lru_cache


class Settings(BaseSettings):
    """Application settings loaded from environment variables or .env file."""

    # API settings
    api_url: str = Field(
        default="http://localhost:8000", description="URL for the API service"
    )

    # LLM settings
    # openai_api_key: Optional[str] = Field(default=None, description="OpenAI API key")
    openai_api_base: Optional[str] = Field(
        default=None, description="Custom OpenAI API base URL"
    )
    openai_api_model: str = Field(default="gpt-4o", description="OpenAI model to use")

    # Application settings
    log_level: str = Field(default="INFO", description="Logging level")
    debug: bool = Field(default=False, description="Debug mode")

    # Report generation settings
    default_style: str = Field(default="business", description="Default writing style")
    default_depth: int = Field(default=3, description="Default depth level (1-5)")
    default_sections: int = Field(default=5, description="Default number of sections")

    # Python path settings for development
    pythonpath: Optional[str] = Field(
        default=None, description="Python path for development"
    )

    class Config:
        """Configuration for Settings."""
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False
        extra = "ignore"  # Allow extra fields that aren't in the model

        # Model configs that can be used to override
        bedrock_claude_3_5_max_tokens = 8192
        bedrock_claude_3_7_max_tokens = 64000
        bedrock_claude_4_max_tokens = 64000
        bedrock_inference_profile_claude_3_5 = "arn:aws:bedrock:us-east-1:339712941790:application-inference-profile/vv3cah7ksg6d"
        bedrock_inference_profile_claude_3_7 = "arn:aws:bedrock:us-east-1:339712941790:application-inference-profile/vycnnsky1evy"
        bedrock_inference_profile_claude_4 = "arn:aws:bedrock:us-east-1:339712941790:application-inference-profile/z22t2kzsi1jh"


@lru_cache()
def get_settings() -> Settings:
    """Return cached settings instance."""
    return Settings()
