import contextvars

correlation_id_ctx = contextvars.ContextVar("correlation_id", default=None)
job_id_ctx = contextvars.ContextVar("job_id", default=None)
api_path_ctx = contextvars.ContextVar("api_path", default=None)
prompt_id_ctx = contextvars.ContextVar("prompt_id", default=None)
action_handler_ctx = contextvars.ContextVar("action_handler", default=None)
file_id_ctx = contextvars.ContextVar("file_id", default=None)


def set_job_id_logging_context(job_id):
    job_id_ctx.set(job_id)


def set_prompt_id_logging_context(prompt_id):
    prompt_id_ctx.set(prompt_id)


def set_api_path_logging_context(api_path):
    api_path_ctx.set(api_path)


def set_correlation_id_logging_context(correlation_id):
    correlation_id_ctx.set(correlation_id)


def set_action_handler_logging_context(action_handler):
    action_handler_ctx.set(action_handler)


def set_file_id_logging_context(file_id):
    file_id_ctx.set(file_id)


def get_correlation_id_logging_context():
    return correlation_id_ctx.get()


def clear_logging_context():
    correlation_id_ctx.set(None)
    job_id_ctx.set(None)
    api_path_ctx.set(None)
    prompt_id_ctx.set(None)
    action_handler_ctx.set(None)
    file_id_ctx.set(None)


def get_logging_context():
    return {
        "correlation_id": correlation_id_ctx.get(),
        "job_id": job_id_ctx.get(),
        "api_path": api_path_ctx.get(),
        "prompt_id": prompt_id_ctx.get(),
        "action_handler": action_handler_ctx.get(),
        "file_id": file_id_ctx.get(),
    }
