from copy import deepcopy
from typing import Optional, Union

from pydantic import BaseModel
from typing_extensions import Self

from chatrd.core.llm.components.generation import (
    ChatGeneration,
    ChatGenerationChunk,
    Generation,
    GenerationChunk,
)


class LLMResult(BaseModel):
    """A container for results of an LLM call.

    Both chat models and LLMs generate an LLMResult object. This object contains the generated outputs
    and any additional information that the model provider wants to return.
    """

    generations: list[list[Union[Generation, ChatGeneration, GenerationChunk, ChatGenerationChunk]]]
    """Generated outputs.

    The first dimension represents completions for different input prompts.
    The second dimension represents different candidate generations for a given prompt.
    When returned from an LLM the type is list[list[Generation]].
    When returned from a chat model the type is list[list[ChatGeneration]].
    """
    llm_output: Optional[dict] = None
    """For arbitrary LLM provider specific output.
    This dictionary is a free-form dictionary that can contain any information that the provider wants to return.
    It is not standardized and is provider-specific.

    Users should generally avoid relying on this field and instead use standardized fields present in AIMessage.
    """

    def flatten(self) -> list[Self]:
        """Flatten generations into a single list.

        Unpack list[list[Generation]] -> list[LLMResult] where each LLMResult contains only a single Generation.

        Returns:
            List of LLMResults where each returned LLMResult contains a single
                Generation.
        """
        llm_results = []
        for i, gen_list in enumerate(self.generations):
            if i == 0:
                llm_results.append(LLMResult(generations=[gen_list], llm_output=self.llm_output))
            else:
                if self.llm_output is not None:
                    llm_output = deepcopy(self.llm_output)
                    llm_output["token_usage"] = {}
                else:
                    llm_output = None
                llm_results.append(LLMResult(generations=[gen_list], llm_output=llm_output))
        return llm_results

    def __eq__(self, other: object) -> bool:
        """Check for LLMResult equality by ignoring any metadata related to runs."""
        if not isinstance(other, LLMResult):
            return NotImplemented
        return self.generations == other.generations and self.llm_output == other.llm_output
