import logging
import re
from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

PLACEHOLDERS_PATTERN = r"\{[\w\-]+\}"


class BasePromptTemplate(ABC):
    """Abstract base class for prompt templates.

    Parameters:
        template (str): The prompt template string containing placeholders for variables.
        partial_variables (Optional[Dict[str, str]]): A dictionary of variables with string keys and values
            to be used for pre-populating the prompt template.
        optional_variables (Optional[List[str]]): List of input variables that are not mandatory provide.
        enforce_full_replacement (bool): Indicates whether to enforce that all placeholders in the template
            must be replaced with values. A ValueError will be raised if any placeholders are left unfilled.
        enforce_unique_variables (bool): Indicates whether to enforce that all variables in the template
            must be unique. A ValueError will be raised if any variable is repeated in the template.

    Raises:
        TypeError:
            - If the template is not a string
            - If the partial_variables is not a dictionary
        KeyError:
            - If the partial_variables contain keys that are not present in the template.
            - If the arguments provided to format do not match the template placeholders.
        ValueError:
            - If the template does not contain valid placeholders
            - If any template variable is not provided until formatting. (except optional_variables)
    """

    def __init__(
        self,
        template: str,
        partial_variables: Optional[Dict[str, str]] = None,
        optional_variables: Optional[List[str]] = None,
        enforce_full_replacement: bool = False,
        enforce_unique_variables: bool = False,
    ):
        """Initialize the prompt template with a string template and optional partial variables."""
        self.template_variables = {}
        self.optional_variables = optional_variables or []
        self._input_variables: List[str] = []
        self._enforce_full_replacement = enforce_full_replacement
        self._enforce_unique_variables = enforce_unique_variables
        if not self._validate_prompt_template(template):
            raise ValueError(
                "Invalid prompt template provided with no valid placeholders. "
                "Ensure there are at least one placeholder in the template and they are unique."
            )
        self.template = template

        if optional_variables:
            if not isinstance(optional_variables, list):
                raise TypeError("Optional variables must be provided as a list of strings.")
            if any(not isinstance(var, str) for var in optional_variables):
                raise TypeError("All optional variables must be strings.")

            self.optional_variables = optional_variables

        if partial_variables is not None:
            if not self._validate_variables(partial_variables):
                raise ValueError(
                    "Invalid partial variables provided."
                    "Ensure they are a dictionary with valid string keys and values."
                )
            self.template_variables = partial_variables

    @property
    def input_variables(self) -> List[str]:
        """List of variable names extracted from the template."""
        if not hasattr(self, "_input_variables"):
            self._input_variables = self._extract_variables(self.template)
        return self._input_variables

    @abstractmethod
    def format(self, **kwargs: str) -> str:
        """Format the template with the provided variables."""
        pass

    def _validate_prompt_template(self, template: str) -> bool:
        """Validate the prompt template to ensure it contains valid placeholders."""
        if template is None or not isinstance(template, str):
            raise TypeError(
                f"No valid template provided. Template must be a non-empty string, "
                f"but received: [{type(template)}] '{template}'"
            )

        placeholders = self._extract_variables(template)

        if self._enforce_unique_variables:
            if len(placeholders) != len(set(placeholders)):
                logger.error("Template variables must be unique.")
                return False

        self._input_variables = placeholders
        return True

    def _extract_variables(self, template: str) -> List[str]:
        """Extract variable names from the template."""
        placeholders = re.findall(PLACEHOLDERS_PATTERN, template)
        return [placeholder.strip("{}") for placeholder in placeholders]

    def _validate_variables(self, variables: dict) -> bool:
        """Validate variables to ensure they are unique, valid and are included in a dictionary."""
        if variables is None:
            return False
        elif not isinstance(variables, dict):
            raise TypeError("Variables must be in a dictionary.")

        for key in variables.keys():
            if not isinstance(key, str):
                raise TypeError("All keys must be strings.")
            if key not in self._input_variables:
                if key not in self.optional_variables:
                    raise KeyError(
                        f"Invalid variable, the template does not contain any variable with the key: '{key}'."
                    )

        return True

    def _partial_format(self, **kwargs: str) -> str:
        """Replace only the provided variables in the template, leaving others intact."""
        # Use regular expressions to find all placeholders in the template
        re_pattern = re.compile(PLACEHOLDERS_PATTERN)  # Matches placeholders in the format {variable}

        def replace(match):
            key = match.group(0).strip("{}")
            return str(kwargs[key]) if key in kwargs else match.group(0)

        return re_pattern.sub(replace, self.template)

    def _validate_variable_replacement(self, formatted_prompt: str) -> Tuple[bool, List[str]]:
        """Validate that all placeholders in the formatted prompt have been replaced."""
        if self._enforce_full_replacement:
            unfilled_vars = self._extract_variables(formatted_prompt)
            required_vars = [var for var in unfilled_vars if var not in self.optional_variables]

            if required_vars:
                logger.warning(f"Missing values for placeholders: {', '.join(unfilled_vars)}")
                return False, required_vars

        return True, []


class SimplePromptTemplate(BasePromptTemplate):
    """A simple prompt template that validate the template and provided partial_variables (optional),
    and also pre-populating the prompt template preparing it to format with additional variables later.

    Parameters:
        template (str): The prompt template string containing placeholders for variables.
        partial_variables (Optional[Dict[str, str]]): A dictionary of variables with string keys and values
            to be used for pre-populating the prompt template.
        optional_variables (Optional[List[str]]): List of input variables that are not mandatory provide.
        enforce_full_replacement (bool): Indicates whether to enforce that all placeholders in the template
            must be replaced with values. A ValueError will be raised if any placeholders are left unfilled.
        enforce_unique_variables (bool): Indicates whether to enforce that all variables in the template
            must be unique. A ValueError will be raised if any variable is repeated in the template.

    Raises:
        TypeError:
            - If the template is not a string
            - If the partial_variables is not a dictionary
        KeyError:
            - If the partial_variables contain keys that are not present in the template.
            - If the arguments provided to format do not match the template placeholders.
        ValueError:
            - If the template does not contain valid placeholders
            - If any template variable is not provided until formatting. (except optional_variables)
    """

    def __init__(
        self,
        template: str,
        partial_variables: Optional[Dict[str, str]] = None,
        optional_variables: Optional[List[str]] = None,
        enforce_full_replacement: bool = False,
        enforce_unique_variables: bool = False,
    ):
        """Initialize the simple prompt template with a string template and optional partial variables."""
        super().__init__(
            template=template,
            partial_variables=partial_variables,
            optional_variables=optional_variables,
            enforce_full_replacement=enforce_full_replacement,
            enforce_unique_variables=enforce_unique_variables,
        )
        if self.template_variables:
            self.template = self._partial_format(**self.template_variables)
            self._input_variables = self._extract_variables(self.template)
            # Clear the template variables after pre-populating the template
            self.template_variables = {}

    def format(self, **kwargs: str) -> str:
        """Format the template with the provided variables."""
        try:
            if not self._validate_variables(kwargs):
                raise ValueError("Invalid partial variables provided.")

            formatted_prompt = self._partial_format(**kwargs)
            is_valid_prompt, missing_vars = self._validate_variable_replacement(formatted_prompt)
            if not is_valid_prompt:
                raise ValueError(f"Missing values for placeholders: {', '.join(missing_vars)}")
        except TypeError as e:
            raise TypeError(f"Invalid type error: {e}") from e
        except KeyError as e:
            raise KeyError(f"Missing key in variables: {e}") from e

        return formatted_prompt


class LazyPromptTemplate(BasePromptTemplate):
    """A lazy prompt template that stores the template and variables but does not format them immediately.
    Partial variables can be specified or updated later, and all the variables are only replaced
    when formatting is done by calling the `format` method.

    Parameters:
        template (str): The prompt template string containing placeholders for variables.
        partial_variables (Optional[Dict[str, str]]): A dictionary of variables with string keys and values
            to be used for pre-populating the prompt template.
        optional_variables (Optional[List[str]]): List of input variables that are not mandatory provide.
        enforce_full_replacement (bool): Indicates whether to enforce that all placeholders in the template
            must be replaced with values. A ValueError will be raised if any placeholders are left unfilled.
        enforce_unique_variables (bool): Indicates whether to enforce that all variables in the template
            must be unique. A ValueError will be raised if any variable is repeated in the template.

    Raises:
        TypeError:
            - If the template is not a string
            - If the partial_variables is not a dictionary
        KeyError:
            - If the partial_variables contain keys that are not present in the template.
            - If the arguments provided to format do not match the template placeholders.
        ValueError:
            - If the template does not contain valid placeholders
            - If any template variable is not provided until formatting. (except optional_variables)
    """

    def reset_variables(self) -> None:
        """Reset all existing stored variables."""
        self.template_variables = {}

    def update_variables(self, *, clean_update: bool = False, **kwargs) -> None:
        """Update the stored partial variables with new ones.
        With `clean_update` set to True, all the existing variables will be cleared before update.
        """
        if not kwargs:
            self.template_variables = {}
            return
        if not self._validate_variables(kwargs):
            raise ValueError(
                "Invalid partial variables provided." "Ensure they are a dictionary with valid string keys and values."
            )
        if clean_update:
            self.template_variables = kwargs
        else:
            self.template_variables.update(kwargs)

    def format(self, **kwargs: str) -> str:
        """Format the template with the stored variables and any additional ones provided."""
        try:
            if not self._validate_variables(kwargs):
                raise ValueError("Invalid partial variables provided.")

            if any(key in self.template_variables for key in kwargs):
                raise ValueError(
                    "Cannot update existing template variables with new values. "
                    "Use update_variables() method to update them."
                )
            variables = {**self.template_variables, **kwargs} if self.template_variables else kwargs

            formatted_prompt = self._partial_format(**variables)
            is_valid_prompt, missing_vars = self._validate_variable_replacement(formatted_prompt)
            if not is_valid_prompt:
                raise ValueError(f"Missing values for placeholders: {', '.join(missing_vars)}")
        except TypeError as e:
            raise TypeError(f"Invalid type error: {e}") from e
        except KeyError as e:
            raise KeyError(f"Missing key in variables: {e}") from e

        return formatted_prompt
