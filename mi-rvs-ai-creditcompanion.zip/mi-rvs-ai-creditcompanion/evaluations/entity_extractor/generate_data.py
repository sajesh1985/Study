import argparse
import json
import pathlib
import random
import pandas as pd
import os

from evaluations.entity_extractor.utils import question_generator, setup_logging


def init_parser():
    parser = argparse.ArgumentParser(
        description="""
    This script generates questions based on the question template and entity data provided.

    question_template (Dict): A dictionary of question templates.
    entity_name_list (List[Dict]): list of dictionaries where each dictionary
    contains the entity details like below (coming from a csv file)

    entity,type,entity_id,entity_group
    "City of Lanesboro, Minnesota",issuer,8980482,Government Institution.
    """
    )
    parser.add_argument(
        "--train-eval",
        type=str,
        help="train or eval",
        default="eval"
    )
    parser.add_argument(
        "--seed",
        type=int,
        help="seed for reproducibility",
        default=12
    )
    parser.add_argument(
        "--num-combinations", 
        type=int, 
        help="number of combinations of entities per question to generate", 
        default=1 # 1 2 3 4 8 16
    )
    parser.add_argument(
        "--entity-data-dir",
        type=str,
        help="entity data csv filepath",
        default="evaluations/data/entity_extraction/template_entities/"
    )
    parser.add_argument(
        "--question-template-dir",
        type=str,
        help="question templates directory path",
        default="evaluations/data/entity_extraction/template_questions/"
    )
    parser.add_argument(
        "--output-path",
        type=str,
        help="filename to save the generated questions for train/evaluation",
        default="evaluations/data/entity_extraction/generated_data/"
    )
    return parser


def read_and_concatenate_csv(entity_dir):
    data_frames, ind = [], 0
    for file_name in os.listdir(entity_dir):
        if file_name.endswith('.csv'):
            file_path = os.path.join(entity_dir, file_name)
            data_frames.append(pd.read_csv(file_path))
            ind = 1
    return pd.concat(data_frames, ignore_index=True, axis=0)


if __name__ == "__main__":

    parser = init_parser()
    logger = setup_logging()
    args = parser.parse_args()

    if args.train_eval == "train":
        iteration = "train/"
    elif args.train_eval == "eval":
        iteration = "evaluation/"

    print(f"\nGenerating questions for {iteration}")

    entity_data_dir = args.entity_data_dir + iteration
    question_template_dir = args.question_template_dir + iteration
    output_path = args.output_path + iteration

    entity_dir = pathlib.Path(entity_data_dir).resolve()
    entity_name_list = read_and_concatenate_csv(entity_dir)

    question_template = {}
    try:
        question_template_dir_path = pathlib.Path(question_template_dir).resolve()
        question_templates = []
        for template_path in question_template_dir_path.glob("*.json"):
            question_templates.append(json.load(template_path.open()))
        question_template = {key: value for template in question_templates for key, value in template.items()}
    except Exception as e:
        logger.error(f"error {e} in loading file {question_template_dir_path}")

    questions = question_generator(
        question_template=question_template, entityset=entity_name_list, num_combinations=args.num_combinations, seed=args.seed
    )

    try:
        # filepath = pathlib.Path(output_path + f"generated_questions_{len(questions)}.json").resolve()
        # # if file exists then change the name of the new file to avoid overwriting
        # if filepath.exists():
        #     filepath = pathlib.Path(output_path + f"generated_questions_{len(questions)}_{random.randint(0, 1000)}.json").resolve()
        filepath = pathlib.Path(output_path + f"generated_questions.json").resolve()
        with filepath.open("wt") as file:
            json.dump(questions, file, indent=4)
            logger.info(f"Generated {len(questions)} questions saved to {filepath}")
    except Exception as e:
        logger.error(f"error {e} in saving file {output_path}")
