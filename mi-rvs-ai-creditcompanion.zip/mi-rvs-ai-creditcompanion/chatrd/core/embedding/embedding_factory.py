import json
import logging
from typing import Any, Dict, List, Sequence, Union

from chatrd.core.aws_utils.bedrock import get_assumed_bedrock_llm_client
from chatrd.core.aws_utils.sagemaker import get_assumed_sagemaker_llm_client
from chatrd.core.embedding import EmbeddingModel
from chatrd.engine.configuration import Constants, get_config_machinery

logger = logging.getLogger(__name__)
config_machinery = get_config_machinery()


class CohereEmbedding(EmbeddingModel):
    model_name_map = {
        "cohere": "cohere.embed-english-v3",
        "cohere-multi": "cohere.embed-multilingual-v3",
    }

    def __init__(self, model_name: str, max_length: int = 2048, *args, **kwargs):
        super().__init__(max_length=max_length)
        self.model_name = self.model_name_map[model_name]
        if model_name == "cohere-multi" and config_machinery.get_config_value(
            Constants.Bedrock.COHERE_EMBED_MULTILINGUAL_V3_INFERENCE_PROFILE_ARN
        ):
            self.model_name = config_machinery.get_config_value(
                Constants.Bedrock.COHERE_EMBED_MULTILINGUAL_V3_INFERENCE_PROFILE_ARN
            )
        self.client = get_assumed_bedrock_llm_client(
            role_arn=config_machinery.get_config_value(Constants.Bedrock.BEDROCK_ROLE_ARN),
            region_name=config_machinery.get_config_value(Constants.Bedrock.BEDROCK_REGION_NAME),
        )["bedrock-runtime"]
        self.input_type = kwargs.get("input_type", "classification")

    def embed_query(self, text: str) -> Sequence[float]:
        if self.max_length is not None:
            text = text[: self.max_length]
        body = self.create_request_body(text)
        response = self.client.invoke_model(
            body=json.dumps(body), modelId=self.model_name, contentType="application/json"
        )
        response_body = json.loads(response["body"].read())
        return response_body["embeddings"][0]

    def embed_list(self, text_list: Sequence[str]) -> Sequence[Sequence[float]]:
        if isinstance(text_list, str):
            text_list = [text_list]

        body = {"texts": text_list, "input_type": self.input_type}
        response = self.client.invoke_model(
            body=json.dumps(body), modelId=self.model_name, contentType="application/json"
        )
        response_body = json.loads(response["body"].read())
        return response_body["embeddings"]

    def create_request_body(self, text: str, **kwargs) -> Dict[str, Any]:
        return {"texts": [text], "input_type": self.input_type}


class TitanEmbedding(EmbeddingModel):
    model_name_map = {
        "titan-v1": "amazon.titan-embed-text-v1",
        "titan-v2": "amazon.titan-embed-text-v2:0",
    }

    def __init__(self, model_name: str, max_length: int = 50000, *args, **kwargs):
        super().__init__(max_length=max_length)
        self.model_name = self.model_name_map[model_name]
        self.client = get_assumed_bedrock_llm_client(
            role_arn=config_machinery.get_config_value(Constants.Bedrock.BEDROCK_ROLE_ARN),
            region_name=config_machinery.get_config_value(Constants.Bedrock.BEDROCK_REGION_NAME),
        )["bedrock-runtime"]
        self.dimensions = kwargs.get("dimensions", 1024)
        self.normalize = kwargs.get("normalize", True)

    def embed_query(self, text: str) -> Sequence[float]:
        if self.max_length is not None:
            text = text[: self.max_length]
        body = self.create_request_body(text)
        response = self.client.invoke_model(
            body=json.dumps(body), modelId=self.model_name, contentType="application/json"
        )
        response_body = json.loads(response["body"].read())
        return response_body["embedding"]

    def create_request_body(self, text: str, **kwargs) -> Dict[str, Any]:
        request_body = {"inputText": text}
        if self.model_name.endswith("v2:0"):
            request_body.update({"dimensions": self.dimensions, "normalize": self.normalize})
        return request_body


class FinetunedEmbedding(EmbeddingModel):
    def __init__(self, model_name: str, *args, **kwargs):
        super().__init__()
        self.client = get_assumed_sagemaker_llm_client(
            role_arn=config_machinery.get_config_value(Constants.SageMaker.SAGEMAKER_ROLE_ARN),
            region_name=config_machinery.get_config_value(Constants.SageMaker.SAGEMAKER_REGION_NAME),
        )["sagemaker-runtime"]

    def embed_query(self, text: str) -> Sequence[float]:
        resp = self.client.invoke_endpoint(
            EndpointName=config_machinery.get_config_value(
                Constants.SageMaker.SAGEMAKER_ROUTER_EMBEDDING_ENDPOINT_NAME
            ),
            Body=json.dumps({"inputs": text}),
            ContentType="application/json",
        )
        return json.loads(resp["Body"].read().decode("utf-8"))["vectors"]


class EndpointEmbedding(EmbeddingModel):
    def __init__(self, model_name: str, *args, **kwargs):
        super().__init__()
        self.client = get_assumed_sagemaker_llm_client(
            role_arn=config_machinery.get_config_value(Constants.SageMaker.SAGEMAKER_ROLE_ARN),
            region_name=config_machinery.get_config_value(Constants.SageMaker.SAGEMAKER_REGION_NAME),
        )["sagemaker-runtime"]

        # Test with one for now
        self.adapter_name = config_machinery.get_config_value(Constants.GeneralConstants.ROUTING_LORA)
        self.classifier_name = config_machinery.get_config_value(Constants.GeneralConstants.ROUTING_CLASSIFIER)

    def embed_query(self, text: str) -> Sequence[float]:
        resp = self.client.invoke_endpoint(
            EndpointName=config_machinery.get_config_value(
                Constants.SageMaker.SAGEMAKER_ROUTER_EMBEDDING_ENDPOINT_NAME
            ),
            Body=json.dumps(
                {
                    "inputs": text,
                    "adapters": [self.adapter_name],
                    "classifier_name": self.classifier_name,
                    "task": "embed",
                }
            ),
            ContentType="application/json",
        )
        return json.loads(resp["Body"].read().decode("utf-8"))["vectors"]

    def classify_query(self, text: Union[List[str], str]) -> Sequence[str]:
        resp = self.client.invoke_endpoint(
            EndpointName=config_machinery.get_config_value(
                Constants.SageMaker.SAGEMAKER_ROUTER_EMBEDDING_ENDPOINT_NAME
            ),
            Body=json.dumps(
                {
                    "inputs": text,
                    "adapters": [self.adapter_name],
                    "classifier_name": self.classifier_name,
                    "task": "intent_detection",
                }
            ),
            ContentType="application/json",
        )
        content = json.loads(resp["Body"].read().decode("utf-8"))
        logger.info(f"Response from endpoint: {content}")
        return content


def embedding_factory(model_name: str, *args, **kwargs) -> EmbeddingModel:
    embedding_models = {
        "cohere": CohereEmbedding,
        "cohere-multi": CohereEmbedding,
        "titan-v1": TitanEmbedding,
        "titan-v2": TitanEmbedding,
        "finetuned": FinetunedEmbedding,
        "endpoint_embedder": EndpointEmbedding,
    }
    return embedding_models[model_name](model_name=model_name, *args, **kwargs)
