import asyncio
import boto3
from mcp.server.fastmcp import FastMCP, Context
from fastapi import FastAPI, APIRouter
from fastapi import Request
from fastapi import Depends
from contextlib import asynccontextmanager
import json
import httpx
import logging
from datetime import datetime
import contextlib
from . import auth
from src.synthia.utils.logging_config import configure_logging 
from src.synthia.utils.source import Source
from src.synthia.aws_utils.aws_client import get_aws_client, get_secret, get_env_specific_secret_key
from src.synthia.config.api_config import get_config
import os
from dotenv import load_dotenv

load_dotenv(override=True)

# Configure logging
logger = configure_logging(logger_name=__name__, log_file='knowledge_base.log',)

logger.info("Knowledge Base MCP Server starting up...")
mcp: FastMCP = FastMCP("Knowledge Base MCP Server", stateless_http=True)

router = APIRouter()

# Create a single AsyncClient instance for reuse (performance optimization for Lambda)
async_client: httpx.AsyncClient = None

async def get_secrets():
    secrets_manager_client = get_aws_client("secretsmanager")
    cfg = get_config()
    synthia_secret = await asyncio.to_thread(get_secret, secrets_manager_client, cfg.get("secrets_name"))
    return synthia_secret

async def get_user_id_from_snl_bearer_token(token: str) -> str:
    """
    Extracts userId from the SNL bearer token.
    """
    # Get configuration
    cfg = get_config()
    
    # TODO: Implement the logic to extract userId from the token
    try:
        global async_client
        headers = {"Authorization": token}
        response = await async_client.get(cfg["capitaliq_kou_url"], headers=headers)
        if response.status_code == 200:
            data = response.json()
            logger.debug(f"User info fetched from SNL: {data}")
            # The user id is in KeyOnlineUser field of response
            return data.get("KeyOnlineUser")
        else:
            logger.error(f"Failed to fetch userId from SNL bearer token: {response.status_code}")
    except Exception as e:
        logger.error(f"Error extracting userId from SNL bearer token: {str(e)}")
    return ""


@mcp.tool()
async def bedrock_retrieve_and_generate(
    user_query: str,
    section_title: str,
    job_id: str,
    top_k: int = 5
):
    """
    Retrieve and generate an answer from Amazon Bedrock Knowledge Base using the RetrieveAndGenerate API.

    Args:
        user_query (str): The user's question or query to be answered using the knowledge base.
        section_title (str): The section of the report for which to query the knowledge base.
        job_id (str): The report job id, used to filter documents uploaded for this specific report.
        top_k (int, optional): The number of top relevant documents to retrieve from the knowledge base. Defaults to 5.

    Returns:
        dict: {
            "output": <generated answer text>,
            "sources": [
                {
                    <str list of source URIs>
                },
                ...
            ]
        }
    """
    # Get configuration
    cfg = get_config()
    bedrock_kb_id_key = cfg["bedrock_kb_id_key"]

    llm_cfg = get_config(parameter_name="llm-config")
    model_id = llm_cfg['bedrock_inference_profile_claude_3_7']


    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    snl_bearer_token = raw_request.headers.get("Authorization")

    logger.info(f"Received bearer token: {snl_bearer_token}")

    bedrock_client = get_aws_client("bedrock-agent-runtime")
    
    synthia_secret = await get_secrets()

    bedrock_kb_id = synthia_secret[get_env_specific_secret_key(bedrock_kb_id_key)]
    # bedrock_kb_datasource_id = synthia_secret[bedrock_kb_datasource_id_key]
    # propdata_s3_bucket = synthia_secret[propdata_s3_bucket_key]

    # Use SNL bearer token to get a uniquely identifiable userId that will serve as filter for user uploaded documents

    user_id = await get_user_id_from_snl_bearer_token(snl_bearer_token)
    # userId = str(userId).strip().lower()  # Ensure string and remove any whitespace
    logger.info(f"Extracted userId: {user_id}")
    if not user_id:
        logger.error("Failed to extract userId from SNL bearer token. Using default test userId.")
        # Defaulting to a test userId if extraction fails
        user_id = ""
    #logger.info(f"Headers received: {raw_request.headers}")
    logger.info(f"UserId being used userId: {user_id}")

    logger.info(f"Using user_query: {user_query}")
    logger.info(f"Using section_title: {section_title}")
    logger.info(f"Using job_id: {job_id}")

    section_title = section_title.strip()

    data = {
            'knowledgeBaseConfiguration': {
                'knowledgeBaseId': bedrock_kb_id,
                'modelArn': model_id,
                'retrievalConfiguration': {
                'vectorSearchConfiguration': {
                    'filter': {
                        'orAll':[
                            {
                                'andAll': [
                                    {
                                        'equals': {
                                            'key': 'userId',
                                            'value': user_id
                                        }
                                    },
                                    {
                                        'equals': {
                                            'key': 'jobId',
                                            'value': job_id
                                        }
                                    },
                                    {
                                        'listContains': {
                                            'key': 'sectionTitle',
                                            'value': section_title
                                        }
                                    }
                                ]
                           },
                           {
                               'andAll': [
                                    {
                                        'equals': {
                                            'key': 'userId',
                                            'value': user_id
                                        }
                                    },
                                    {
                                        'equals': {
                                            'key': 'jobId',
                                            'value': job_id
                                        }
                                    },
                                    {
                                        'listContains': {
                                            'key': 'sectionTitle',
                                            'value': 'all'
                                        }
                                    }
                                ]
                            }
                        ]
                    },
                    'overrideSearchType': 'HYBRID'
                }
            }},
            'type': 'KNOWLEDGE_BASE',
        }

    logger.debug(f"RetrieveAndGenerate configuration: {json.dumps(data)}")

    response = bedrock_client.retrieve_and_generate(
        input={'text': user_query},
        retrieveAndGenerateConfiguration=data
    )

    output_text = response.get("output", {}).get("text", "")
    logger.info(f"Generated output text: {output_text}")

    sources = []
    citations = response.get("citations", [])
    for citation in citations:
        for ref in citation.get("retrievedReferences", []):
            uri = ref.get("location", {}).get("s3Location", {}).get("uri", "")
            page = ref.get("metadata", {}).get("x-amz-bedrock-kb-document-page-number", "")
            # Build a label for the source
            filename = uri.split("/")[-1]
            filename = filename.split("_", 1)[-1]
            label = f"{filename}#page={page}" if page and page != 1 else filename
            source = Source(title=label, url="#")
            # For UI: link to a page that shows the full reference (could be a modal or a new page)
            sources.append(source)

    return {
        "output": output_text,
        "sources": sources
    }

# Define a custom lifespan for FastAPI with a task to manage MCP
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Initialize MCP server task group
    logger.info("Initializing MCP server task group...")

    global async_client
    async_client = httpx.AsyncClient(timeout=10)

    async with contextlib.AsyncExitStack() as stack:
        await stack.enter_async_context(mcp.session_manager.run())
        yield

    # Shutdown: Close the AsyncClient
    await async_client.aclose()


@router.get("/knowledge-base/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "ok"}


app = FastAPI(lifespan=lifespan)
app.mount("/knowledge-base", mcp.streamable_http_app())
app.include_router(router)
logger.info("Knowledge Base MCP Server started successfully.")