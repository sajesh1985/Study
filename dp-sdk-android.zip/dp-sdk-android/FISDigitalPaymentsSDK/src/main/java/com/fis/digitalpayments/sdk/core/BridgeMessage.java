// Copyright Notice!
// This document is protected under the trade secret and copyright
// laws as the property of Fidelity National Information Services, Inc.
// Copying, reproduction or distribution should be limited and only to
// employees with a “need to know” to do their job.
// Any disclosure of this document to third parties is strictly prohibited.
// © 2017 Fidelity National Information Services.
// All rights reserved worldwide.

package com.fis.digitalpayments.sdk.core;

/**
 * @author e1035413 on 2/13/2017.
 */

@SuppressWarnings("SameParameterValue")
public class BridgeMessage {
    private final BridgeMessageType mType;
    private final BridgeMessageCode mCode;
    private final String mText;

    private BridgeMessage(BridgeMessageType type, BridgeMessageCode code, String text) {
        mType = type;
        mCode = code;
        mText = text;
    }

    static BridgeMessage CreateInformation(@SuppressWarnings("SameParameterValue") BridgeMessageCode code, String text) {
        return new BridgeMessage(BridgeMessageType.INFORMATION, code, text);
    }

    static BridgeMessage CreateWarning(BridgeMessageCode code, String text) {
        return new BridgeMessage(BridgeMessageType.WARNING, code, text);
    }

    public static BridgeMessage CreateError(BridgeMessageCode code, String text) {
        return new BridgeMessage(BridgeMessageType.ERROR, code, text);
    }

    public static BridgeMessage CreateActionRequest(BridgeMessageCode code) {
        return new BridgeMessage(BridgeMessageType.ACTION_REQUEST, code, null);
    }

    BridgeMessageType getMessageType() {
        return mType;
    }

    BridgeMessageCode getMessageCode() {
        return  mCode;
    }

    String getMessageText() {
        return mText;
    }

}
