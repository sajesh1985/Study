﻿// Copyright Notice! 
// This document is protected under the trade secret and copyright 
// laws as the property of Fidelity National Information Services, Inc. 
// Copying, reproduction or distribution should be limited and only to 
// employees with a “need to know” to do their job. 
// Any disclosure of this document to third parties is strictly prohibited.
// © 2018 Fidelity National Information Services.
// All rights reserved worldwide.

namespace Fis.Epp.Fusion.Auth.Models
{
    using System;

    /// <summary>Represents user data mapped to view.</summary>
    [Serializable]
    public class UserDataModel
    {
        [ValidateField]
        public string AccessToken { get; set; }
        [ValidateField]
        public string ContextToken { get; set; }
        [ValidateField]
        public string WwwRootPath { get; set; }
        [ValidateField]
        public string CorrelationId { get; set; }
        [ValidateField]
        public int SessionTimeout { get; set; }
        [ValidateField]
        public string SessionToken { get; set; }
        [ValidateField]
        public string UserId { get; set; }
        [ValidateField]
        public string FeId { get; set; }
        [ValidateField]
        public string KeepAliveURL { get; set; }
        [ValidateField]
        public string ReturnURL { get; set; }
        [ValidateField]
        public string BalanceList { get; set; }
        [ValidateField]
        public string ApplicationId { get; set; }
        [ValidateField]
        public string Locale { get; set; }
        [ValidateField]
        public string SourceId { get; set; }
        [ValidateField]
        public bool PageRefresh { get; set; }
    }
}
