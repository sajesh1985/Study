import logging
import re
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.data_service.retriever.utils import process_date_str

logger = logging.getLogger(__name__)

config_machinery = get_config_machinery()


CWOL_MAPPING = config_machinery.get_config_value(Constants.DataService.CWOL_MAPPING)
COLUMN_RENAMER = config_machinery.get_config_value(Constants.DataService.COLUMN_RENAMER)
USPF_COLUMNS_MAPPING = config_machinery.get_config_value(Constants.DataService.USPF_COLUMNS_MAPPING)
GIS_COLUMNS_MAPPING = config_machinery.get_config_value(Constants.DataService.GIS_COLUMNS_MAPPING)
DEFAULTRATING_COLUMNS_MAPPING = config_machinery.get_config_value(Constants.DataService.DEFAULTRATING_COLUMNS_MAPPING)
NUM_ROWS_TO_DISPLAY = config_machinery.get_config_value(Constants.GeneralConstants.NUM_ROWS_TO_DISPLAY)
ENV = config_machinery.get_config_value(Constants.DataService.DATASERVICE_SCREENER_ENV)
FINANCIAL_METRICS_INS_COMING_SOON_MSG = "Financial metrics for insurance companies will be available soon."
LIST_RESPONSE_DISCLAIMER_MSG = "<b>Note:</b> Data Queries include entities covered by S&P Global Ratings in the Corporates, Financial Institutions, Insurance, and Governments Sectors. Type '#' + Data Query to initiate. <i>Coming soon: U.S. Public Finance, and Securities Coverage.</i>"


def get_api_info(api_method: str = "GET", api_type: str = "ratings", url: str = "", screener_payload={}) -> dict:
    """
    Constructs a dictionary containing information about an API request.

    Parameters:
    ----------
    api_method : str
        The HTTP method to be used for the API request (default is "GET").
    api_type : str
        The type of API being accessed (default is "ratings").
    url : str
        The endpoint URL for the API request (default is an empty string).

    Returns:
    -------
    dict
        A dictionary containing the API method, type, URL, payload, and extra information.
    """
    api_info = {
        "method": api_method,
        "type": api_type,
        "url": url,
        "payload": {"data": screener_payload, "parameters": {}},
        "extra": {"additional_info": ""},
    }
    return api_info


def company_profile_url(entity_id: str) -> str:
    """
    Generates a company profile URL for a given entity.

    Args:
        entity_id (str): The unique identifier for the entity.

    Returns:
        str: The complete company profile URL.
    """
    base_url = get_sourcing_footnote_base_url()
    query_param = "#company/profile?id="
    return f"{base_url}{query_param}{entity_id}"


def rating_history_url(entity_id: str) -> str:
    """
    Generates a Rating History URL for a given entity

    Args:
        entity_id (str): The unique identifier for the entity.

    Returns:
        str: Rating History URL.
    """
    base_url = get_sourcing_footnote_base_url()
    query_param = "#company/ratingsHistory?Id="
    return f"{base_url}{query_param}{entity_id}"


def make_source_description(entity_name: str, entity_id: str, sep: str, info: str, url_maker) -> list:
    """
    Generates a source description for a given entity.

    Parameters:
    ----------
    entity_name : str
        The name of the entity for which the description is being created.
    entity_id : str
        The unique identifier of the entity.
    sep : str
        The separator to be used between the entity name and additional information.
    info : str
        Additional information to be included in the source description.
    url_maker : callable
        A function that takes an entity ID and returns a corresponding URL.

    Returns:
    -------
    list
        A list containing a tuple with the formatted source description and the generated URL.
        If an error occurs during the process, a default description with an empty URL is returned.
    """
    try:
        source_description = [(entity_name + sep + info, url_maker(entity_id))]
    except Exception as e:
        logger.error(
            f"Failed to generate source description for entity '{entity_name}' " f"(ID: {entity_id}). Error: {e}"
        )
        return [(f"{entity_name} | {info}", "")]

    return source_description


def source_description(entities) -> List[Tuple[str, str]]:
    response = []
    for company in entities.get("companies", []):
        source_url = company_profile_url(company["mi_id"])
        response.append((f"{company['name']}", source_url))
    response = sorted(response, key=lambda x: x[0])
    return response


def text_response(template: str, error=False) -> Dict[str, Any]:
    """
    Generates a text response dictionary.

    Args:
        template (str): The text content for the response.

    Returns:
        Dict[str, Any]: A dictionary representing the text response.
    """
    return {"type": "text", "content": template, "synthesize": False, "count": None, "error": error}


def table_response(
    data: Any = "",
    data_type: str = "table",
    count: int = 0,
    count_distribution: Dict[str, int] = None,
) -> Dict[str, Any]:
    """
    Generates a structured table response dictionary.

    Args:
        data (Any): The data to be included in the response.
        data_type (str): The type of data (e.g., "table", "chart", etc.).
        count (int): The number of rows in the data

    Returns:
        Dict[str, Any]: A dictionary representing the structured response.
    """
    if data_type == "table":
        # Process for any empty strings in the table.
        data = data.replace("", None)

        # Capitalize each word in the column
        EXCEPTIONS = {"LLP", "LLC", "CUSIP", "ISIN", "LT", "ST", "LT)", "ST)", "FC", "LC"}

        def smart_title(col_name: str) -> str:
            return " ".join(word if word.upper() in EXCEPTIONS else word.title() for word in col_name.split())

        data.columns = [smart_title(col) for col in data.columns]
        data.columns = [col.replace("Creditwatch", "CreditWatch") for col in data.columns]

    return {
        "type": data_type,
        "content": data,
        "synthesize": False,
        "count": count,
        "count_distribution": count_distribution,
    }


def full_response(
    template: str = "",
    data: Any = "",
    data_type: str = "table",
    count: int = 0,
    count_distribution: Dict[str, int] = None,
    footnote: str = "",
    isFinancialMetrics: bool = False,
    error=False,
) -> List[Dict[str, Any]]:
    """
    Generates a complete response consisting of a text template, structured data, and a footnote.

    Args:
        template (str): The main text content.
        data (Any): The structured data.
        data_type (str): The type of the data.
        count (int): The number of rows in the data
        footnote (str): Additional text content.

    Returns:
        List[Dict[str, Any]]: A list containing the full response structure.
    """
    response = [
        text_response(template, error=error),
        table_response(data, data_type, count, count_distribution),
    ]
    if isFinancialMetrics:
        response.append(text_response(FINANCIAL_METRICS_INS_COMING_SOON_MSG))

    if footnote:
        response.append(text_response(footnote))
        response.append(text_response(LIST_RESPONSE_DISCLAIMER_MSG))
    return response


def parse_timestamp(input_str: str, output_format: str) -> str:
    """
    Parses a timestamp string in the format 'Date(<timestamp><offset>)' or '/Date(<timestamp><offset>)/',
    and returns the date-time as a formatted string using the specified format.

    Args:
        input_str (str): The input string, e.g., "Date(1729821881000-0400)" or "/Date(1729821881000-0400)/".
        output_format (str): The strftime-compatible format string to format the resulting datetime.

    Returns:
        str: The formatted date-time string if parsing is successful; otherwise, an empty string.
    """
    match = re.match(r"\/?Date\((\d+)([+-]\d{4})\)\/?", input_str)
    if match:
        timestamp_ms = int(match.group(1))
        offset_str = match.group(2)

        # Convert milliseconds to seconds
        timestamp_s = timestamp_ms / 1000

        # Parse timezone offset
        sign = 1 if offset_str[0] == "+" else -1
        offset_hours = int(offset_str[1:3])
        offset_minutes = int(offset_str[3:5])
        tz_offset = timezone(sign * timedelta(hours=offset_hours, minutes=offset_minutes))

        # Create datetime object
        dt = datetime.fromtimestamp(timestamp_s, tz=tz_offset)
        return dt.strftime(output_format)

    return ""


def parse_date(input_str: str, output_format: str) -> str:
    """
    Parses a date string and returns it in the specified format.

    Parameters:
    input_str (str): The date string.
    output_format (str): The desired output format.

    Returns:
    str: The formatted date or en empty string if parsing fails.
    """
    if not input_str:
        return ""

    date_formats: List[str] = [
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%d",
        "%m/%d/%Y",
    ]

    for fmt in date_formats:
        try:
            dt = datetime.strptime(input_str, fmt).date()
            return dt.strftime(output_format)
        except ValueError:
            continue  # Try next format

    try:
        return parse_timestamp(input_str, output_format)
    except ValueError:
        logger.error(f"Failed to parse date: '{input_str}' with pre-set formats.")

    return ""


def date_synthesizer(input_str: str) -> str:
    return parse_date(input_str, "%B %d, %Y")


def date_format(input_str: str) -> str:
    return parse_date(input_str, "%m/%d/%Y")


def modify_date_in_place(df, date_identifier, date_format_fn):
    date_cols = [col for col in df.columns.tolist() if date_identifier in col]
    for col in date_cols:
        df[col] = df[col].apply(date_format_fn)
    # No return for this function, the data frame is modified in place


def create_securities_table(df):
    # Rename the columns
    rename_dict = dict(
        {
            "RT_INSTRUMENT_NAME": "DESCRIPTION",
            "RT_MATURITY_DATE": "MATURITY DATE",
            "RT_CUSIP9": "CUSIP",
            "RT_ISINS": "ISIN",
            "RT_CURRENT_RATING_SYMBOL": "RATING",
            "RT_RATING_DATE": "RATING DATE",
            "RT_LAST_CREDIT_RATING_DATE": "LAST REVIEW DATE",
            "RT_CURRENT_CW_OL": "CREDITWATCH/OUTLOOK",
            "RT_CURRENT_CW_OL_DATE": "CREDITWATCH/OUTLOOK DATE",
            "RT_INSTRUMENT_TYPE_CODE": "INSTRUMENT TYPE",
            "RT_CURRENT_COUPON_RATE": "COUPON RATE",
        }
    )
    df = df.rename(columns=rename_dict)

    # Create new column
    debt_rating_col = "DEBT TYPE (RATING TYPE) / SECURITY COUNT"
    df[debt_rating_col] = df["RT_DEBT_TYPE_CODE"].astype("str") + " (" + df["RT_RATING_TYPE_CODE"].astype("str") + ")"

    modify_date_in_place(df, "DATE", date_format)

    df = df.sort_values([debt_rating_col, "DESCRIPTION"])
    # Group by 'DEBT TYPE / RATING TYPE (SECURITY COUNT)' and limit the number of records
    df = df.groupby(debt_rating_col).head(NUM_ROWS_TO_DISPLAY)

    # Desired columns
    columns = [
        debt_rating_col,
        "DESCRIPTION",
        "MATURITY DATE",
        "RATING",
        "RATING DATE",
        "LAST REVIEW DATE",
        "CREDITWATCH/OUTLOOK",
        "CREDITWATCH/OUTLOOK DATE",
        "CUSIP",
        "ISIN",
        "INSTRUMENT TYPE",
        "COUPON RATE",
    ]

    # Select only the columns that exist in df
    matching_columns = [col for col in columns if col in df.columns]

    # Subset the DataFrame using only the matching columns
    final_df = df[matching_columns]

    return final_df


def create_ratings_table(df, rating_cols_all, icr_fsr) -> pd.DataFrame:
    if df.shape[0] == 0:
        return df, False

    # rating columns
    rating_cols = [col for col in rating_cols_all if col in df.columns.tolist()]
    ratings = [df[col].iloc[0] for col in rating_cols]

    rating = "RATING" if icr_fsr == "ICR" else "RATING (FSR)"
    rating_date = "RATING DATE" if icr_fsr == "ICR" else "RATING DATE (FSR)"
    last_review_date = "S&P LAST REVIEW DATE " if icr_fsr == "ICR" else "S&P LAST REVIEW DATE (FSR) "
    credit_watch_outlook = "S&P CREDITWATCH/OUTLOOK " if icr_fsr == "ICR" else "S&P CREDITWATCH/OUTLOOK (FSR) "
    outlook = "OUTLOOK" if icr_fsr == "ICR" else "OUTLOOK (FSR)"

    # rating type
    rating_types = [rating_col.split(rating)[1].strip() for rating_col in rating_cols]
    rating_type_splits = [rating_type.split() for rating_type in rating_types]
    rating_type_displays = [e[0].title() + " " + e[1].title() + " " + e[2] for e in rating_type_splits]

    # rating date
    rating_date_cols = [col.split(rating)[0] + rating_date + col.split(rating)[1] for col in rating_cols]
    rating_dates = [df[col].iloc[0] for col in rating_date_cols]

    # last review date
    last_review_date_cols = [last_review_date + rating_type for rating_type in rating_types]
    last_review_dates = [df[col].iloc[0] for col in last_review_date_cols]

    # Creditwatch/outlook
    cwol_cols = [credit_watch_outlook + rating_type for rating_type in rating_types]
    cwol = [df[cwol_col].iloc[0] for cwol_col in cwol_cols]

    # creditwatch/outlook date
    cwol_date_cols = [x.replace("OUTLOOK", "OUTLOOK DATE") for x in cwol_cols]
    cwol_dates = [df[col].iloc[0] for col in cwol_date_cols]

    # prior rating
    rating_cols_prior = [rating_col + " (PRIOR)" for rating_col in rating_cols]
    ratings_prior = [df[col].iloc[0] for col in rating_cols_prior]

    # prior creditwatch/outlook
    cwol_cols_prior = [credit_watch_outlook + rating_type + " (PRIOR)" for rating_type in rating_types]
    cwol_prior = [df[col].iloc[0] for col in cwol_cols_prior]

    df_tabular = pd.DataFrame(
        {
            "Rating Type": rating_type_displays,
            "Rating": ratings,
            "Rating Date": rating_dates,
            "Last Review Date": last_review_dates,
            "CreditWatch/Outlook": cwol,
            "CreditWatch/Outlook Date": cwol_dates,
            "Prior Rating": ratings_prior,
            "Prior CreditWatch/Outlook": cwol_prior,
        }
    )

    modify_date_in_place(df_tabular, "Date", date_format)

    invalid_rows = df_tabular.Rating.isna().all() or (df_tabular.Rating == "").all()
    has_valid_rows = not invalid_rows
    return df_tabular, has_valid_rows


def create_security_history_table(df: pd.DataFrame) -> Tuple[pd.DataFrame, bool]:
    """
    Creates a tabular representation of the security history data from the input DataFrame.

    Args:
        df (pd.DataFrame): The input DataFrame containing the security history data.

    Returns:
        Tuple[pd.DataFrame, bool]: A tuple containing the transformed DataFrame and a boolean indicating whether the DataFrame has valid rows.
    """
    if df.shape[0] == 0:
        return df, False

    df_tabular = df.rename(columns=COLUMN_RENAMER)
    df_tabular = df_tabular[
        [
            "RATING TYPE",
            "ACTION",
            "RATING",
            "RATING DATE",
            "LAST REVIEW DATE",
            "CREDITWATCH/OUTLOOK",
            "CREDITWATCH/OUTLOOK DATE",
        ]
    ]

    # Check if there are any valid rows
    invalid_rows = df_tabular["RATING"].isna().all() or (df_tabular["RATING"] == "").all() or df_tabular.empty
    has_valid_rows = not invalid_rows

    if has_valid_rows:
        # Convert date columns to specified format
        modify_date_in_place(df_tabular, "DATE", date_format)

    return df_tabular, has_valid_rows


def create_tranche_table(df: pd.DataFrame) -> Tuple[pd.DataFrame, bool]:
    """
    Creates a tabular representation of the tranche data from the input DataFrame.

    Args:
        df (pd.DataFrame): The input DataFrame containing the tranche data.

    Returns:
        Tuple[pd.DataFrame, bool]: A tuple containing the transformed DataFrame and a boolean indicating whether the DataFrame has valid rows.
    """
    if df.empty:
        return df, False

    df_tabular = df.rename(
        columns={
            "Tranche": "TRANCHE",
            "MaturityDate": "MATURITY DATE",
            "Cusip": "CUSIP",
            "Isins": "ISIN",
            "Cins": "CINS",
            "SaleAmount": "SALE AMT(M)",
            "CouponRate": "COUPON RATE %",
            "RT_RATING_TYPE_CODE": "RATING TYPE",
            "RT_CURRENT_RATING_SYMBOL": "CURRENT RATING",
            "RT_RATING_DATE": "CURRENT RATING DATE",
            "RT_CURRENT_CW_VALUE": "CREDIT WATCH/OUTLOOK",
            "RT_CURRENT_CW_OL_DATE": "CREDIT WATCH/OUTLOOK DATE",
            "RT_LAST_CREDIT_RATING_DATE": "LAST REVIEW DATE",
        }
    )
    df_tabular = df_tabular[
        [
            "TRANCHE",
            "MATURITY DATE",
            "CUSIP",
            "ISIN",
            "CINS",
            "SALE AMT(M)",
            "COUPON RATE %",
            "RATING TYPE",
            "CURRENT RATING",
            "CURRENT RATING DATE",
            "CREDIT WATCH/OUTLOOK",
            "CREDIT WATCH/OUTLOOK DATE",
            "LAST REVIEW DATE",
        ]
    ]

    # Convert date columns to specified format
    modify_date_in_place(df_tabular, "DATE", date_format)

    # Check if there are any valid rows
    invalid_rows = (
        df_tabular["CURRENT RATING"].isna().all() or (df_tabular["CURRENT RATING"] == "").all() or df_tabular.empty
    )
    has_valid_rows = not invalid_rows

    return df_tabular, has_valid_rows


def create_uspf_ratings_table(df) -> pd.DataFrame:
    if df.shape[0] == 0:
        return df, False

    rating_cols = [
        "Local Currency LT",
        "Local Currency ST",
    ]

    # Renaming columns
    df_tabular = df.rename(columns=USPF_COLUMNS_MAPPING)

    # Filter only the renamed columns
    renamed_columns = [
        "RATING TYPE",
        "RATING",
        "RATING DATE",
        "LAST REVIEW DATE",
        "CREDITWATCH/OUTLOOK",
        "CREDITWATCH/OUTLOOK DATE",
        "PRIOR RATING",
        "Prior RATING DATE",
        "PRIOR CREDITWATCH/OUTLOOK",
        "Prior CREDITWATCH/ OUTLOOK DATE",
    ]

    df_tabular = df_tabular[renamed_columns]

    modify_date_in_place(df_tabular, "DATE", date_format)

    rating_map = {"STDLONG": "Local Currency LT", "STDSHORT": "Local Currency ST"}
    df_tabular["RATING TYPE"] = df_tabular["RATING TYPE"].replace(rating_map)
    # Check for presence of rating types
    present_types = df_tabular["RATING TYPE"].unique()
    result_uspf = []

    for rt in rating_cols:
        if rt in present_types:
            # If the rating type is present, add it to the result
            result_uspf.append(df_tabular[df_tabular["RATING TYPE"] == rt])
        else:
            # If it's not present, add an empty row with the rating type
            empty_row = pd.DataFrame({col: [None] for col in df_tabular.columns})
            empty_row["RATING TYPE"] = rt
            result_uspf.append(empty_row)

        # Concatenate results
    df_tabular = pd.concat(result_uspf, ignore_index=True)

    # If both types are present, ensure "LT" comes first, then "ST"
    if len(set(rating_cols) & set(present_types)) == 2:
        df_tabular = df_tabular.sort_values(
            by="RATING TYPE", key=lambda x: x.map({rating_cols[0]: 0, rating_cols[1]: 1})
        )

    invalid_rows = df_tabular.RATING.isna().all() or (df_tabular.RATING == "").all()
    has_valid_rows = not invalid_rows

    return df_tabular, has_valid_rows


def create_entity_defaultrating_table(df: pd.DataFrame, entities: list) -> pd.DataFrame:
    if df.shape[0] == 0:
        return df, False

    entities_df = pd.DataFrame(entities)

    merged_df = df.merge(entities_df, left_on="KeyInstn", right_on="mi_id", how="inner")

    # df["RATING TYPE"] = (
    #    df["RT_DEBT_TYPE_CODE"].astype(str).str.cat(df["RT_RATING_TYPE_CODE"].astype(str), sep=" (") + ")"
    # )
    # Renaming columns
    df_tabular = merged_df.rename(columns=DEFAULTRATING_COLUMNS_MAPPING)

    sourcing_footnote_url = get_sourcing_footnote_base_url()
    df_tabular["Citation"] = sourcing_footnote_url + "#" + df_tabular["Citation"]

    renamed_columns = [
        "Entity",
        "DEBT TYPE (RATING TYPE)",
        "RATING",
        "RATING DATE",
        "LAST REVIEW DATE",
        "CREDITWATCH/OUTLOOK",
        "CREDITWATCH/OUTLOOK DATE",
    ]

    missing_columns = [col for col in renamed_columns if col not in df_tabular.columns]
    if missing_columns:
        raise ValueError(f"Missing columns: {missing_columns}")

    df_tabular = df_tabular[renamed_columns]
    modify_date_in_place(df_tabular, "DATE", date_format)

    df_tabular = df_tabular.head(NUM_ROWS_TO_DISPLAY)

    # Check for invalid rows (if any row has an invalid 'RATING')
    invalid_rows = df_tabular.RATING.isna().all() or (df_tabular.RATING == "").all()
    has_valid_rows = not invalid_rows.any()

    return df_tabular, has_valid_rows


def create_company_history_table(df: pd.DataFrame) -> pd.DataFrame:
    if df.shape[0] == 0:
        return df, False

    df["RATING TYPE"] = (
        df["RT_DEBT_TYPE_CODE"].astype(str).str.cat(df["RT_RATING_TYPE_CODE"].astype(str), sep=" (") + ")"
    )
    # Renaming columns
    df_tabular = df.rename(columns=GIS_COLUMNS_MAPPING)

    renamed_columns = [
        "RATING TYPE",
        "RATING",
        "RATING DATE",
        "ACTION",
        "CREDITWATCH/OUTLOOK",
        "CREDITWATCH/OUTLOOK DATE",
    ]

    missing_columns = [col for col in renamed_columns if col not in df_tabular.columns]
    if missing_columns:
        raise ValueError(f"Missing columns: {missing_columns}")

    df_tabular = df_tabular[renamed_columns]
    modify_date_in_place(df_tabular, "DATE", date_format)

    df_tabular = df_tabular.head(NUM_ROWS_TO_DISPLAY)

    # Check for invalid rows (if any row has an invalid 'RATING')
    invalid_rows = df_tabular.RATING.isna().all() or (df_tabular.RATING == "").all()
    has_valid_rows = not invalid_rows.any()

    return df_tabular, has_valid_rows


class GenericTemplate:
    def template_single_icr_second(self, df, rating_col: str) -> Optional[str]:
        # current rating
        credit_rating = df[rating_col].iloc[0]

        # prior rating
        rating_col_prior = rating_col + " (PRIOR)"
        credit_rating_prior = df[rating_col_prior].iloc[0]

        # rating date
        rating_date_col = rating_col.split("RATING")[0] + "RATING DATE" + rating_col.split("RATING")[1]
        rating_date = df[rating_date_col].iloc[0]
        # convert the date to requested format
        rating_date = date_synthesizer(rating_date)

        # rating type
        rating_type = rating_col.split("RATING")[1].strip()

        # current cwol
        cwol_col = "S&P CREDITWATCH/OUTLOOK " + rating_type
        cwol = df[cwol_col].iloc[0]
        cwol_col_prior = "S&P CREDITWATCH/OUTLOOK " + rating_type + " (PRIOR)"
        cwol_prior = df[cwol_col_prior].iloc[0]

        # last review date
        last_review_date_col = "S&P LAST REVIEW DATE " + rating_type
        last_review_date = df[last_review_date_col].iloc[0]
        # convert the date to requested format
        last_review_date = date_synthesizer(last_review_date)

        # rating action
        rating_action_col = rating_col.split("RATING")[0] + "RATING ACTION" + rating_col.split("RATING")[1]

        # if rating action exists
        if df[rating_action_col].iloc[0]:
            # rating action
            try:
                rating_action_split = df[rating_action_col].iloc[0][0][1].split("|")
                if len(rating_action_split) > 1:
                    rating_action = rating_action_split[0].strip()
                else:
                    rating_action = ""
            except Exception as e:
                logger.error(f"Error parsing Rating Action field: {e}")
                rating_action = ""
            # rating action date
            try:
                rating_action_date = df[rating_action_col].iloc[0][0][2]
                rating_action_date = date_synthesizer(process_date_str(rating_action_date))
            except Exception as e:
                logger.error(f"Error parsing Rating Action date: {e}")
                rating_action_date = ""
        else:
            rating_action = ""
            rating_action_date = ""

        # new rating
        if not credit_rating_prior:
            if (
                (not cwol and not cwol_prior)
                or (cwol == "NM" and cwol_prior == "NM")
                or (not cwol and cwol_prior == "NM")
                or (cwol == "NM" and not cwol_prior)
            ):
                template = f"""The rating has not been updated since the initial rating on {rating_date}."""
            elif cwol and CWOL_MAPPING[cwol.lower()] == "outlook":
                template = (
                    f"""The rating and outlook have not been updated since the initial rating on {rating_date}."""
                )
            elif cwol and CWOL_MAPPING[cwol.lower()] == "creditwatch":
                template = (
                    f"""The rating and creditwatch have not been updated since the initial rating on {rating_date}"""
                )
        # rating change
        elif credit_rating != credit_rating_prior:
            if (
                (not cwol and not cwol_prior)
                or (cwol == "NM" and cwol_prior == "NM")
                or (not cwol and cwol_prior == "NM")
                or (cwol == "NM" and not cwol_prior)
            ):
                template = f"""The latest action was a rating {rating_action} to {credit_rating} from {credit_rating_prior} on {rating_action_date}."""

            # same OL, or CW, or CWOL;
            # i.e., prior and current same outlook/creditwatch
            # or same creditwatch/ outlook for NM scenario
            elif cwol == cwol_prior:
                # no NR
                template_1 = f"""The latest action was a rating {rating_action} to {credit_rating} from {credit_rating_prior} with the {CWOL_MAPPING[cwol.lower()]} remaining {cwol} on {rating_action_date}."""
                # scenario of NR
                template_2 = f"""The latest action was a rating {rating_action} to {credit_rating} from {credit_rating_prior} with the creditwatch/ outlook remaining {cwol} on {rating_action_date}."""
                template = template_1 if CWOL_MAPPING[cwol.lower()] else template_2

            # OL change, or CW change
            # but the mapping remains same
            elif (CWOL_MAPPING[cwol.lower()] == CWOL_MAPPING[cwol_prior.lower()]) and cwol != cwol_prior:
                # in this logic, we will not encounter NR as an option, not even NM
                mapping = CWOL_MAPPING[cwol.lower()]
                prep = "an" if mapping[0] == "o" else "a"
                template = f"""The latest action was a rating {rating_action} to {credit_rating} from {credit_rating_prior} with {prep} {mapping} change to {cwol} from {cwol_prior} on {rating_action_date}."""
            # new OL, or new CW, or new CWOL
            elif cwol and not cwol_prior:
                mapping = CWOL_MAPPING[cwol.lower()]
                # catch NR scenario
                mapping = mapping or "creditwatch/ outlook"
                prep = "an" if mapping[0] == "o" else "a"
                template = f"""The latest action was a rating {rating_action} to {credit_rating} from {credit_rating_prior} with {prep} {mapping} change to {cwol} on {rating_action_date}."""

            # OL changed from CW
            # CW changed from OL
            # other CWOL change to capture NM scenario
            elif CWOL_MAPPING[cwol.lower()] != CWOL_MAPPING[cwol_prior.lower()]:
                mapping = CWOL_MAPPING[cwol.lower()]
                mapping_prior = CWOL_MAPPING[cwol_prior.lower()]
                # catch NR scenario
                # scenario when current NR but prior not NR
                mapping = mapping or mapping_prior
                # scenario when prior NR bur current not NR
                # do nothing
                # scenario when both NR
                mapping = mapping or "creditwatch/ outlook"
                prep = "an" if mapping[0] == "o" else "a"
                if mapping_prior:
                    template = f"""The latest action was a rating {rating_action} to {credit_rating} from {credit_rating_prior} with {prep} {mapping} change to {cwol} from a {cwol_prior} {mapping_prior} on {rating_action_date}."""
                else:
                    # if prior NR
                    template = f"""The latest action was a rating {rating_action} to {credit_rating} from {credit_rating_prior} with {prep} {mapping} change to {cwol} from a {cwol_prior} on {rating_action_date}."""
        # rating remains same
        elif credit_rating == credit_rating_prior:
            # OL, or CW, or CWOL change
            # but previous and current has same mapping, i.e., both OL, or CW, or CWOL (for NM)
            if (CWOL_MAPPING[cwol.lower()] == CWOL_MAPPING[cwol_prior.lower()]) and cwol != cwol_prior:
                # in this logic, we will not encounter NR as an option, not even NM
                mapping = CWOL_MAPPING[cwol.lower()]
                prep = "an" if mapping[0] == "o" else "a"
                template = f"""The latest action was {prep} {mapping} update to {cwol} from {cwol_prior} on {rating_action_date}. The rating has not changed since {rating_date}."""

            # new OL, or new CW, or new CWOL
            elif cwol and not cwol_prior:
                mapping = CWOL_MAPPING[cwol.lower()]
                # catch NR scenario
                mapping = mapping or "creditwatch/ outlook"
                prep = "an" if mapping[0] == "o" else "a"
                template = f"""The latest action was {prep} {mapping} update to {cwol} on {rating_action_date}. The rating has not changed since {rating_date}."""

            # OL changed from CW
            # CW changed from OL
            # other CWOL change to capture NM scenario
            elif CWOL_MAPPING[cwol.lower()] != CWOL_MAPPING[cwol_prior.lower()]:
                mapping = CWOL_MAPPING[cwol.lower()]
                mapping_prior = CWOL_MAPPING[cwol_prior.lower()]
                # catch NR scenario
                # scenario when current NR but prior not NR
                mapping = mapping or mapping_prior
                # scenario when prior NR but current not NR
                # do nothing
                # scenario when both NR
                mapping = mapping or "creditwatch/ outlook"
                prep = "an" if mapping[0] == "o" else "a"
                if mapping_prior:
                    template = f"""The latest action was {prep} {mapping} update to {cwol} from a {cwol_prior} {mapping_prior} on {rating_action_date}. The rating has not changed since {rating_date}."""
                else:
                    # for prior NR scenario
                    template = f"""The latest action was {prep} {mapping} update to {cwol} from a {cwol_prior} on {rating_action_date}. The rating has not changed since {rating_date}."""

        return template


rating_debt_type_list = [
    "Issuer Credit Rating (Foreign Currency LT)",
    "Issuer Credit Rating (Foreign Currency ST)",
    "Issuer Credit Rating (Local Currency LT)",
    "Issuer Credit Rating (Local Currency ST)",
    "Financial Strength Rating (Local Currency LT)",
    "Financial Strength Rating (Local Currency ST)",
    "Financial Strength Rating (Argentina National Scale LT)",
]


def extract_debt_type(df, rating_debt_type_list):
    standardized_rating_debt_type_list = [item.replace(" ", "") for item in rating_debt_type_list if item is not None]
    for name in df:
        mnemonic_name = name.get("MnemonicName")
        if mnemonic_name is None:
            continue
        standardized_name = mnemonic_name.replace(" ", "")
        if standardized_name in standardized_rating_debt_type_list:
            return mnemonic_name
    return []


def get_data_size(data):
    """
    Get size information for either DataFrame or list of dictionaries.

    Args:
        data: Either pandas DataFrame or list of dictionaries

    Returns:
        str: Formatted size information
    """
    if isinstance(data, pd.DataFrame):
        return f"{data.shape}"
    elif isinstance(data, list):
        return f"({len(data)}, {len(data[0].keys()) if data else 0})"
    else:
        return "(0, 0)"


def entity_identifier(entities, variable) -> str:
    detected_entity = ""
    for key, value in entities.items():
        if isinstance(value, list) and len(value) > 0:
            detected_entity = key
            return entities[detected_entity][0][variable]
        else:
            return ""


def calculate_group_count(df, debt_type_col: str = None, rating_type_col: str = None) -> Tuple[int, Dict[str, int]]:
    # Check if both keys are provided
    if debt_type_col in df.columns and rating_type_col in df.columns:
        count_distribution = {
            f"{row[debt_type_col]} ({row[rating_type_col]})": row["Count"]
            for index, row in df.groupby([debt_type_col, rating_type_col]).size().reset_index(name="Count").iterrows()
        }
    # Check if only one key is provided
    elif debt_type_col in df.columns:
        count_distribution = {
            row[debt_type_col]: row["Count"]
            for index, row in df.groupby(debt_type_col).size().reset_index(name="Count").iterrows()
        }
    elif rating_type_col in df.columns:
        count_distribution = {
            row[rating_type_col]: row["Count"]
            for index, row in df.groupby(rating_type_col).size().reset_index(name="Count").iterrows()
        }
    # If neither key is provided
    else:
        count_distribution = None

    return (df.shape[0], count_distribution)


def analyst_sector_data_formatter(data: List[Dict[str, Any]]) -> pd.DataFrame:
    """
    Create a DataFrame from the API data and rename its columns.

    Args:
        api_data (Any): The raw data retrieved from the API, expected to be convertible to a DataFrame.

    Returns:
        pd.DataFrame: A DataFrame with renamed columns reflecting entity information.
    """
    df = pd.DataFrame(data)

    if df.empty:
        return df

    rename_dict = {
        "InstnName": "ENTITY NAME",
        "RT_EMPLOYEE_NAME": "FULL NAME",
        "RT_EA_DEPT_ROLE_NAME": "TITLE",
        "RT_LOCATION_CODE": "GEOGRAPHY",
        "RT_TELEPHONE_NUM": "CONTACT NUMBER",
        "RT_EMAIL_ADDRESS": "EMAIL",
    }

    df = df.rename(columns=rename_dict)
    df = df[list(rename_dict.values())]
    df = df.sort_values("ENTITY NAME")

    # Apply the hyperlink function to the email column
    def create_hyperlink(email):
        return f'<a href="mailto:{email}">{email}</a>'

    df["EMAIL"] = df["EMAIL"].apply(create_hyperlink)

    return df


def convert_json_to_df(json_data):
    """
    Convert complex nested JSON structure to a flattened pandas DataFrame

    Args:
        json_data (list): List of dictionaries containing complex JSON structure

    Returns:
        pd.DataFrame: Flattened pandas DataFrame
    """
    # Prepare lists to store flattened data
    flattened_data = []

    # Iterate through each record in the JSON data
    for record in json_data:
        # Base record information
        base_info = {
            "KeyInstn": record["KeyInstn"],
            "EntityId": record["EntityId"],
            "EntityName": record["EntityName"],
            "LegalEntityID": record["LegalEntityID"],
            "SwiftBICCode": record["SwiftBICCode"],
            "PrimaryIndustry": record["PrimaryIndustry"],
            "DateIncorporated": record["DateIncorporated"],
            "SIC": record["SIC"],
            "Status": record["Status"],
        }

        # Handle EntityIndustryInfo
        for entity_industry in record["EntityIndustryInfo"]:
            entity_industry_info = base_info.copy()
            entity_industry_info.update(
                {
                    "EntityIndustryInfo_Category": entity_industry["Category"],
                    "EntityIndustryInfo_KeyTreeId": entity_industry["KeyTreeId"],
                    "EntityIndustryInfo_IndustrylongName": entity_industry["IndustrylongName"],
                }
            )

            nace_industries = record.get("NaceIndustries", [])
            if nace_industries:
                # Handle NaceIndustries
                for nace_industry in nace_industries:
                    nace_info = entity_industry_info.copy()
                    nace_info.update(
                        {
                            "NaceIndustries_KeyNaceIndustryTree": nace_industry["KeyNaceIndustryTree"],
                            "NaceIndustries_NaceCode": nace_industry["NaceCode"],
                            "NaceIndustries_NaceIndustry": nace_industry["NaceIndustry"],
                        }
                    )

                    naics_industries = record.get("NaicsIndustries", [])
                    if naics_industries:
                        # Handle NaicsIndustries
                        for naics_industry in naics_industries:
                            naics_info = nace_info.copy()
                            naics_info.update(
                                {
                                    "NaicsIndustries_Naics": naics_industry["Naics"],
                                    "NaicsIndustries_NaicsIndustry": naics_industry["NaicsIndustry"],
                                }
                            )

                            flattened_data.append(naics_info)
                    else:
                        nace_info.update(
                            {
                                "NaicsIndustries_Naics": "",
                                "NaicsIndustries_NaicsIndustry": "",
                            }
                        )
                        flattened_data.append(nace_info)
            else:
                entity_industry_info.update(
                    {
                        "NaceIndustries_KeyNaceIndustryTree": "",
                        "NaceIndustries_NaceCode": "",
                        "NaceIndustries_NaceIndustry": "",
                        "NaicsIndustries_Naics": "",
                        "NaicsIndustries_NaicsIndustry": "",
                    }
                )
                flattened_data.append(entity_industry_info)

    # Create DataFrame
    df = pd.DataFrame(flattened_data)

    return df


def sector_information_data_formatter(data: List[Dict[str, Any]]) -> pd.DataFrame:
    """
    Converts a list of entity data into a pandas DataFrame with specific S&P Ratings fields.

    Args:
        data (List[Dict[str, Any]]): A list of dictionaries containing entity information.

    Returns:
        pd.DataFrame: A DataFrame containing the formatted entity information.
    """

    df_entity = convert_json_to_df(data)

    sector_info = df_entity[
        [
            "EntityId",
            "EntityIndustryInfo_Category",
            "EntityIndustryInfo_KeyTreeId",
            "EntityIndustryInfo_IndustrylongName",
        ]
    ].drop_duplicates()
    category_map = {0: "Sector", 1: "SubSector", 2: "Industry", 3: "Country"}
    sector_info["Category"] = sector_info["EntityIndustryInfo_Category"].map(category_map)
    sector_info = sector_info.pivot_table(
        index="EntityId",
        columns="Category",
        values="EntityIndustryInfo_IndustrylongName",
        aggfunc=lambda x: ", ".join(x),
    ).reset_index()
    df_entity = df_entity.drop(
        ["EntityIndustryInfo_Category", "EntityIndustryInfo_KeyTreeId", "EntityIndustryInfo_IndustrylongName"], axis=1
    ).drop_duplicates()
    df_entity = df_entity.merge(sector_info, on="EntityId")

    df_info = df_entity[["EntityName", "KeyInstn", "EntityId"]].drop_duplicates()
    entity_names = df_info.EntityName.to_list()
    key_instns = df_info.KeyInstn.to_list()
    entity_ids = df_info.EntityId.to_list()

    sectors, sub_sectors, industries, countries = [], [], [], []
    nace_codes, naics_codes = [], []

    categories = [sectors, sub_sectors, industries, countries]
    col_categories = ["Sector", "SubSector", "Industry", "Country"]
    groupby_cols = [x for x in col_categories if x in df_entity.columns]
    df_sec_info = df_entity.groupby(["EntityName", "KeyInstn", "EntityId"])[groupby_cols].first().reset_index()
    df_nn_info = df_entity[
        [
            "EntityId",
            "NaceIndustries_NaceCode",
            "NaceIndustries_NaceIndustry",
            "NaicsIndustries_Naics",
            "NaicsIndustries_NaicsIndustry",
        ]
    ].drop_duplicates()
    for entity_id in entity_ids:
        df_sec = df_sec_info[df_sec_info["EntityId"] == entity_id]

        for col, target_list in zip(col_categories, categories):
            value = df_sec[col].unique()[0] if col in df_sec.columns else ""
            target_list.append(value)

        df_nn = df_nn_info[df_nn_info["EntityId"] == entity_id]
        nace_naics = df_nn[
            [
                "NaceIndustries_NaceCode",
                "NaceIndustries_NaceIndustry",
                "NaicsIndustries_Naics",
                "NaicsIndustries_NaicsIndustry",
            ]
        ].drop_duplicates()
        nace_naics["nace"] = nace_naics["NaceIndustries_NaceCode"] + " - " + nace_naics["NaceIndustries_NaceIndustry"]
        nace_naics["naics"] = nace_naics["NaicsIndustries_Naics"] + " - " + nace_naics["NaicsIndustries_NaicsIndustry"]
        nace_codes.append(", ".join([s for s in nace_naics.nace.unique() if s.strip()]))
        naics_codes.append(", ".join([s for s in nace_naics.naics.unique() if s.strip()]))

    # Create DataFrame
    df = pd.DataFrame(
        {
            "S&P RATINGS ENTITY NAME": entity_names,
            "MI Key": key_instns,
            "S&P RATINGS ENTITY ID": entity_ids,
            "S&P RATINGS SECTOR": sectors,
            "S&P RATINGS SUB-SECTOR": sub_sectors,
            "S&P RATINGS INDUSTRY": industries,
            "S&P RATINGS COUNTRY/REGION": countries,
            "NACE CODE": nace_codes,
            "NAICS CODE": naics_codes,
        }
    )

    df = df.drop_duplicates().transpose().reset_index()
    df.columns = df.iloc[0]
    df = df[1:]

    return df


def join_list_of_names(names: List[str]) -> str:
    match len(names):
        case 1:
            return names[0]
        case 2:
            return " and ".join(names)
        case _:
            return ", ".join(names[:-1]) + " and " + names[-1]


def get_sourcing_footnote_base_url() -> str:
    source_base_url = config_machinery.get_config_value(Constants.SourceGeneration.BASE_URL)
    footnote_url_slug = config_machinery.get_config_value(Constants.SourceGeneration.FOOTNOTE_URL_SLUG)
    return source_base_url + footnote_url_slug
