import React from 'react';
import { CodeResponseNode, ContentType, CSDTableResponseNode, KnowledgeDiscoveryResponseNode, TableResponseNode, TextResponseNode} from './api';

export enum Sentiment {
  Positive = 'positive',
  Negative = 'negative',
  None = '',
}

export enum Tag {
  Accuracy = 'accuracy',
  Completeness = 'completeness',
}

export interface Feedback {
  sentiment: Sentiment;
  text?: string;
  tags?: Tag[];
}

export interface Interaction {
  id: string;
  sessionId?:string;
  type?:string;
  date?:string;
  req?: React.ReactNode;
  res?: React.ReactNode | React.ReactElement;
  feedback?: Feedback;
  loading: boolean;
  feedbackEnabled?: boolean;
  input?: string;
  interactionId?: string;
  responseBody?: Node[];
  response?:Node[];
  csdTable?:Node[];
  responseContext?: Node[];
  responseTimestamp?:string;
}
export type Node =
  | TextResponseNode
  | TableResponseNode
  | CSDTableResponseNode
  | KnowledgeDiscoveryResponseNode
  | TextResponseNodeWithElement
  | CodeResponseNode;

export type TextResponseNodeWithElement = {
  type: ContentType.Text;
  content: string | JSX.Element;
};
export interface GridModel {
  interactionId: string;
  gridData?: any;
}
