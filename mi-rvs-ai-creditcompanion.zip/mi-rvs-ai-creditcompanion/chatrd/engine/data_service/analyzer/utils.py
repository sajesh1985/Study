import ast
import json
import logging
import re
from datetime import date
from difflib import get_close_matches
from importlib.resources import files

from dateutil.relativedelta import relativedelta

from chatrd.core.llm import LCLLMFactory
from chatrd.core.llm.components.message import AIMessage
from chatrd.engine.configuration import Constants, get_config_machinery
from chatrd.engine.data_service.utils import convert_response_to_dict_for_screener

logger = logging.getLogger(__name__)
config_machinery = get_config_machinery()
FINANCIAL_METRICS_LIST = config_machinery.get_config_value(Constants.DataService.FINANCIAL_METRICS)


def format_response(filter_name, example_response) -> str:
    """
    Formats provided examples for few-shot learning
    """
    response = f"""{filter_name} = {example_response}"""
    return str(response)


def clean_dict(dict_in: dict) -> dict:
    """
    Filters out out unnecessary fields from filters extracted from query. Keeps only non-empty conditions
    """
    dict_out = {field: dict_in[field].value for field in dict_in if dict_in[field]}
    return dict_out


def filter_llm_response_financial_metrics(response, financial_metrics, metricList):

    # Extract JSON array using rege
    match = re.search(r"\[.*?\]", response.content, re.DOTALL)
    if match:
        json_string = match.group()
        try:
            extracted_metrics = ast.literal_eval(json_string)
            if not isinstance(extracted_metrics, list):
                logger.info(f"LLM returned invalid JSON: Expected a list, got {type(extracted_metrics)}")
                extracted_metrics = []
        except json.JSONDecodeError as e:
            logger.error(f"Error decoding JSON from LLM response: {str(e)}. JSON string: {json_string}")
            extracted_metrics = []
    else:
        logger.info("No JSON array found in LLM response.")
        extracted_metrics = []

    if "General" in extracted_metrics:
        return extracted_metrics, []

    # Create a dictionary for case-insensitive fuzzy matching
    metrics_map = {metric.lower(): metric for metric in financial_metrics}

    # Validate and normalize extracted metrics
    validated_metrics = []
    for metric in extracted_metrics:
        if metric in financial_metrics:
            validated_metrics.append(metric)
            continue

        # Try case-insensitive match
        if metric.lower() in metrics_map:
            validated_metrics.append(metrics_map[metric.lower()])
            continue

        # Try fuzzy matching
        matches = get_close_matches(metric.lower(), list(metrics_map.keys()), n=1, cutoff=0.70)
        if matches:
            closest_match = metrics_map[matches[0]]
            logger.info(f"Fuzzy matched '{metric}' to '{closest_match}'")
            validated_metrics.append(closest_match)
        else:
            logger.info(f"Metric not found: '{metric}'. No close matches found.")

    # Log for any metrics not present during validation
    if len(extracted_metrics) != len(validated_metrics):
        logger.info(
            f"LLM returned metrics not all matched. Original: {extracted_metrics}, Validated: {validated_metrics}"
        )

    if not validated_metrics:
        logger.warning("No valid financial metrics found in the LLM response.")
        extracted_metric_list = []
    else:
        extracted_metric_list = [metric for metric in metricList if metric.get("MetricName") in validated_metrics]

    return validated_metrics, extracted_metric_list


def append_fiscal_years(financial_periods):
    """
    Append fiscal years to a list for all years that have quarters and half years.

    Args:
        financial_periods (list): List of financial period codes

    Returns:
        list: Updated list with fiscal years added for all relevant years
    """
    years_found = set()

    # Find all years that have quarters
    for period in financial_periods:
        if "Q" in period and len(period) >= 5:
            year_index = period.find("Q")
            year = period[:year_index]
            years_found.add(year)
        elif "H" in period and len(period) >= 5:
            year_index = period.find("H")
            year = period[:year_index]
            years_found.add(year)
    result = financial_periods.copy()
    for year in years_found:
        fiscal_year = f"{year}Y"
        if fiscal_year not in result:
            result.append(fiscal_year)

    return result


def sorting_extractor(llm: LCLLMFactory, user_input: str):
    from chatrd.engine.data_service.analyzer.prompts.prompts import ORDER_PROMPT

    prompt = ORDER_PROMPT + " " + user_input
    response = llm.invoke(prompt)

    if isinstance(response, AIMessage):
        response = response.content
        response_dict = convert_response_to_dict_for_screener(response)
    else:
        response_dict = dict()
    return response_dict


def get_financial_metrics_by_sectors(sectors):
    """
    Accepts a list of sectors and a file name, and returns the filtered metrics list and metric names.

    Args:
        sectors (list): List of sectors to filter metrics.

    Returns:
        tuple: A tuple containing:
            - metrics_list (list): Filtered list of metrics.
            - metric_names (list): List of metric names from the filtered metrics.
    """
    file_name = FINANCIAL_METRICS_LIST
    try:
        metrics_list_path = files("chatrd.engine.data.data_service").joinpath(file_name).resolve()
        with open(metrics_list_path, "r") as f:
            all_metrics_list = json.load(f)

        if not sectors or all(str(sector).strip() == "" for sector in sectors):
            metrics_list = all_metrics_list
        else:
            metrics_list = [metric for metric in all_metrics_list if metric.get("MetricSector") in sectors]
        metric_names = [metric["MetricName"] for metric in metrics_list if "MetricName" in metric]
        sorted_metric_names = sorted(metric_names)
        return metrics_list, sorted_metric_names
    except (FileNotFoundError, json.JSONDecodeError) as e:
        logger.error(f"Error loading metrics file {file_name}: {str(e)}")
        return [], []


def get_sector_short(rd_sector):
    """
    Returns the short form of a sector based on the given rd_sector.

    Args:
        rd_sector (str): The sector name.

    Returns:
        str: The short form of the sector, or None if the sector is not recognized.
    """
    sector_mapping = {"Corporates": "CORP", "Financial Institutions": "FI", "Insurance": "INS"}
    return sector_mapping.get(rd_sector)


def process_date_string(input_data):
    TODAY_DATE = date.today()

    # Compute previous quarter start and end dates
    def get_previous_quarter_dates(ref_date):
        # Determine the current quarter
        current_quarter = (ref_date.month - 1) // 3 + 1
        # Previous quarter
        prev_quarter = current_quarter - 1
        prev_year = ref_date.year
        if prev_quarter == 0:
            prev_quarter = 4
            prev_year -= 1
        # Start month of previous quarter
        start_month = 3 * (prev_quarter - 1) + 1
        start_date = date(prev_year, start_month, 1)
        # End date is last day of the third month in the quarter
        # Add 3 months to start_date and subtract 1 day
        end_date = start_date + relativedelta(months=3) - relativedelta(days=1)
        return start_date, end_date

    PREVIOUS_QUARTER_START, PREVIOUS_QUARTER_END = get_previous_quarter_dates(TODAY_DATE)

    def safe_eval_expr(expr):
        """
        Safely evaluate expressions involving TODAY_DATE attributes and simple arithmetic.
        Allowed operators: +, -, parentheses, integers.
        Allowed names: TODAY_DATE, date parts like year, month, day.
        """
        expr = expr.strip()
        # Replace TODAY_DATE.year etc. with actual values
        expr = re.sub(r"TODAY_DATE\.year", str(TODAY_DATE.year), expr)
        expr = re.sub(r"TODAY_DATE\.month", str(TODAY_DATE.month), expr)
        expr = re.sub(r"TODAY_DATE\.day", str(TODAY_DATE.day), expr)

        # Only allow digits, arithmetic operators, and spaces now
        if not re.fullmatch(r"[\d\s\+\-$$$$]+", expr):
            # Unsafe expression, return None
            return None
        try:
            return str(eval(expr))
        except Exception:
            return None

    def replace_today_date_expr(match):
        expr = match.group(1).strip()

        # Handle PREVIOUS_QUARTER_START and PREVIOUS_QUARTER_END
        if expr == "PREVIOUS_QUARTER_START":
            return PREVIOUS_QUARTER_START.strftime("%m/%d/%Y")
        if expr == "PREVIOUS_QUARTER_END":
            return PREVIOUS_QUARTER_END.strftime("%m/%d/%Y")

        # Handle simple TODAY_DATE.year or arithmetic on it
        if re.fullmatch(r"TODAY_DATE\.year(\s*[\+\-]\s*\d+)?", expr):
            val = safe_eval_expr(expr)
            if val is not None:
                return val
            else:
                return match.group(0)

        # Handle TODAY_DATE with optional relativedelta and format: e.g.
        # TODAY_DATE + relativedelta(months=-3):%m/%d/%Y
        # or just TODAY_DATE:%m/%d/%Y
        # or just TODAY_DATE
        # Split by ':'
        if ":" in expr:
            left, fmt = expr.split(":", 1)
            left = left.strip()
            fmt = fmt.strip()
        else:
            left = expr
            fmt = None

        if left.startswith("TODAY_DATE"):
            # Check if there is a relativedelta
            if "+" in left:
                parts = left.split("+", 1)
                base = parts[0].strip()
                delta_expr = parts[1].strip()
                if base != "TODAY_DATE":
                    return match.group(0)

                # Evaluate delta_expr safely (only allow relativedelta with months/days/years)
                if delta_expr.startswith("relativedelta"):
                    # Extract arguments inside parentheses
                    arg_str = delta_expr[len("relativedelta") :].strip()
                    try:
                        delta = eval(f"relativedelta{arg_str}", {"relativedelta": relativedelta})
                        new_date = TODAY_DATE + delta
                    except Exception:
                        return match.group(0)
                else:
                    return match.group(0)

                if fmt:
                    return new_date.strftime(fmt)
                else:
                    return new_date.isoformat()
            else:
                # Just TODAY_DATE possibly with format
                if left != "TODAY_DATE":
                    return match.group(0)
                if fmt:
                    return TODAY_DATE.strftime(fmt)
                else:
                    return TODAY_DATE.isoformat()

        return match.group(0)

    def process_string(s):
        # Recursively process nested braces by repeatedly applying substitution until no change
        pattern = re.compile(r"\{([^{}]+)\}")
        prev_s = None
        while prev_s != s:
            prev_s = s
            s = pattern.sub(replace_today_date_expr, s)
        return s

    if isinstance(input_data, dict):
        if "time_frame" in input_data and isinstance(input_data["time_frame"], str):
            processed_time_frame = process_string(input_data["time_frame"])
            # After processing TODAY_DATE expressions, try to replace any remaining { ... } with evaluated expressions
            processed_time_frame = re.sub(r"\{([^{}]+)\}", r"\1", processed_time_frame)

            new_dict = dict(input_data)
            new_dict["time_frame"] = processed_time_frame
            return new_dict
        else:
            return input_data
    elif isinstance(input_data, str):
        return process_string(input_data)
    else:
        return input_data


def convert_tuples_to_string(tuples_list):
    result = []

    for index, item in enumerate(tuples_list):
        if len(item) == 2:
            question, answer = item
            result.append(
                f"""
Question [{index + 1}]: {process_date_string(question)}
Answer [{index + 1}]: {process_date_string(answer)}
"""
            )
        elif len(item) == 4:
            question, wrong_answer, explanation, corrected_answer = item
            result.append(
                f"""
Question [{index + 1}]: {process_date_string(question)}
Wrong Answer [{index + 1}]: {process_date_string(wrong_answer)}
Explanation [{index + 1}]: {process_date_string(explanation)}
Corrected Answer [{index + 1}]: {process_date_string(corrected_answer)}
"""
            )

    return "".join(result)
