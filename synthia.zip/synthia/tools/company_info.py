from mcp.server.fastmcp import FastMCP, Context
from fastapi import FastAPI, APIRouter
from fastapi import Request
from fastapi import Depends
from contextlib import asynccontextmanager
import httpx
import json
import logging
from datetime import datetime
import contextlib
from src.synthia.config.api_config import get_config
from . import auth
from src.synthia.utils.logging_config import configure_logging
from src.synthia.utils.source import Source

# Configure logging
configure_logging(log_file='company_info.log',)
logger = logging.getLogger(__name__)

logger.info("Company Info MCP Server starting up...")
mcp: FastMCP = FastMCP("Company Info MCP Server", stateless_http=True)

cfg = get_config()


omni_suggest_base_url = cfg["omni_suggest_base_url"]
capitaliq_base_url = cfg["capitaliq_base_url"]
company_description_url_infix = "AIReportBuilder/companyDesc/"
GRAPH_URL = cfg["capitaliq_graphql_url"]
base_core_url = cfg["core_url"]
old_ciqpro_url = cfg["old_ciqpro_url"]


omni_suggest_body = {
    "query": "<COMP_NAME>",
    "typeahead_context":
    {
        "currentKeyPageId": 1,
        "keyCannedReportsParent": 0
    },
    "max_results": 15
}

router = APIRouter()


# Create a single AsyncClient instance for reuse (performance optimization for Lambda)
async_client: httpx.AsyncClient = None


async def get_company_description_data(inst_id: str, auth_headers: dict) -> dict:
    logger.info(f"Fetching Company Description")
    url = f"{capitaliq_base_url}{company_description_url_infix}{inst_id}"
    logger.info(f"URL for company description: {url}")
    try:
        global async_client
        response = await async_client.get(url, headers=auth_headers)
        source = Source(title="Corporate Profile", url=f"{old_ciqpro_url}#company/profile?id={inst_id}")
        if response.status_code == 200:
            logger.info(f"response from company description tool is {response}")
            return {"source": source, "description":response.text}
        elif response.status_code == 204:
            logger.info(f"No content found for the given Inst ID: {inst_id}")
            return {"source": source, "description": "No content found for the given company."}
        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return f"Error: {response.status_code} - {response.text}"
    except httpx.RequestError as e:
        logger.error(f"Request failed: {e}")
        return f"Request failed: {e}"


def get_company_ids(suggest_result) -> dict:
    logger.info(f"Fetching Company Inst ID for response of {len(suggest_result)} records")
    try:
        destinations = suggest_result['destinations']

        max_score = None
        selected_inst_id = None

        for data in destinations:
            inst_id = None
            calculated_score = None
            company_id = None
            core_id = None

            for field in data.get('additionalFields', []):
                name = field.get('fieldName')
                if name == 'id':
                    inst_id = field.get('fieldValue')
                elif name == 'calculated_score':
                    calculated_score = field.get('fieldValue')

            if calculated_score is not None and (max_score is None or calculated_score > max_score):
                max_score = calculated_score
                selected_inst_id = inst_id

    except Exception as e:
        logger.error(f"Error processing company data: {e}")
        selected_inst_id = "No Inst ID available"
    return {"instId" : selected_inst_id}


@mcp.tool()
async def get_company_description(company_name: str) -> dict:
    """
    Retrieve company description, such as company background, operating segments
    and Inst ID obtained from S&Ps Capital IQ API
    Args:
        company_name (str): The name of the company to search for
    Returns:
        str: A string containing the company description including company background, operating segments and Inst ID.
        Note:
           Inst ID/KeyInstn/MI Key - S&P's unique key to identify institutions. Institutions are corporations, partnerships, proprietorships, not-for-profit organizations, government agencies, and any other chartered organization.
    """
    #Company ID/CIQCompanyId - S&P Cap IQ unique identifier for companies. Used for mapping between SNL KeyInstn and CapIQ CompanyID
    # request = Depends(Request)
    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    headers = raw_request.headers
    logger.info(f"Headers received: {headers}")
    auth_headers = auth.build_auth_headers(raw_request)
    logger.info(f"get_company_description called for : {company_name}")
    url = f"{omni_suggest_base_url}"
    omni_suggest_body["query"] = company_name
    try:
        logger.info(f"Request URL: {url}")
        logger.info(f"Request headers: {auth_headers}")
        global async_client
        response = await async_client.post(url, headers=auth_headers, json=omni_suggest_body)
        logger.info(f"Response status: {response.status_code}")
        if response.status_code == 200:
            response_json = response.json()
            logger.info(f"Response JSON: {response_json}")
            company_ids = get_company_ids(response_json)
            description = await get_company_description_data(company_ids['instId'], auth_headers)
            output = {**description, **company_ids}
            logger.info(f"Company Description Output: {output}")
            return output
        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return f"Error: {response.status_code} - {response.text}"
    except httpx.RequestError as e:
        logger.error(f"Request failed: {e}")
        return f"Request failed: {e}"




@mcp.tool()
async def get_company_officers(instId: int, roleCategory: str = 'EXECUTIVES') -> dict:
    """
    Fetch officers for a given Inst ID/KeyInstn/MI Key (instId) and roles within the company.

    Args:
        instId (int): The Inst ID to get officers for company also called as Instn ID, MI Key, KeyInstn.
        roleCategory (str): Specifies a category of roles within a company, only below are the possible value for this
        - EXECUTIVES
        - BOARD_OF_DIRECTORS
        - PROFESSIONALS
        - OTHER_BOARD_MEMBER
        Here is definition of these role category
            Executives: "All executives, excluding professionals"
            Professionals: "All executives, excluding executives"
            BoardOfDirectors: "All board of director members"
            OtherBoardMember: "All other board members"

    Returns:
        dict: A dictionary containing key officers information for given company and role category.
        Here is the details of the fields returned:
        - title: The title of the officer
        - biography: The biography of the officer
        - name: The name of the officer
        - keyPersonUrl: The URL to the officer's profile on the CIQPro site
    """
    logger.info(f"get_company_officers called for: {instId}, roleCategory: {roleCategory}")

    payload = {
        "extensions": {
            "persistedQuery": {
                "version":1,
                "sha256Hash":"305147546b69b1670ca49c1eea67f2f487a206101cb7022f672e04480c46502e"
            }
        },
        "variables": {
            "keyInstn": instId, 
            "roleCategory":roleCategory,
            "current":True
        }
    }

    ctx: Context = mcp.get_context()
    raw_request: Request = ctx.request_context.request
    headers = {
        "Content-Type": "application/json",
        **auth.build_auth_headers(raw_request)
    }
    logger.info(f"Headers received: {headers}")
    logger.info(f"get_company_officers payload: {payload}")

    try:
        global async_client
        response = await async_client.post(GRAPH_URL, headers=headers, json=payload)
        source = Source(title="Company Officers", url=f"{old_ciqpro_url}#company/officers?ID={instId}")
        if response.status_code == 200:
            officers_data = response.json()
            logger.info(f"Officers data: {officers_data}")
            officers = (
                officers_data.get("data", {})
                .get("employeesByKeyInstn", [])
            )
            processed_officers = []
            for officer in officers:
                key_person_id = officer.get("person", {}).get("keyPerson")
                processed_officer = {
                    "title": officer.get("roles", [{}])[0].get("title") if officer.get("roles") else None,
                    "biography": officer.get("person", {}).get("biography", {}).get("text"),
                    "name": officer.get("person", {}).get("name"),
                    "keyPersonUrl": (
                        f"{old_ciqpro_url}#company/officerBio?ID={instId}&KP={key_person_id}"
                        if key_person_id else None
                    ),
                }
                processed_officers.append(processed_officer)
            
            logger.info(f"Final officers data: {processed_officers}")
            
            return {"sources": source, "data": processed_officers}
        elif response.status_code == 204:
            logger.info(f"No officers data found for the given company : {instId} for role {roleCategory}")
            return {"sources": source, "data": [{"message":"No officers data found for the given company."}]}
        else:
            logger.error(f"Error: {response.status_code} - {response.text}")
            return {"error": f"{response.status_code} - {response.text}"}
    except httpx.RequestError as e:
        logger.error(f"Request failed: {e}")
        return {"error": f"Request failed: {e}"}


# Define a custom lifespan for FastAPI with a task to manage MCP
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Initialize MCP server task group
    logger.info("Initializing MCP server task group...")

    global async_client
    async_client = httpx.AsyncClient(timeout=10)

    async with contextlib.AsyncExitStack() as stack:
        await stack.enter_async_context(mcp.session_manager.run())
        yield

    # Shutdown: Close the AsyncClient
    await async_client.aclose()


@router.get("/company-overview/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "ok"}


app = FastAPI(lifespan=lifespan)
app.mount("/company-overview", mcp.streamable_http_app())
app.include_router(router)
logger.info("Company Info MCP Server started successfully.")
