import logging
from abc import ABC, abstractmethod
from functools import wraps
from typing import Callable, List, Union

from chatrd.core.document import Document
from chatrd.engine.components.query_analyzer.entity_extractor.utils import (
    Companies,
    RevenueSource,
)

logger = logging.getLogger(__name__)


class UCRetriever(ABC):
    @abstractmethod
    def retrieve(
        self,
    ):
        pass

    @abstractmethod
    def vector_db_retrieval(
        self,
    ):
        pass

    def rephrased_query(self, query: str, entity: Union[Companies, RevenueSource]):
        if isinstance(entity, RevenueSource):
            updated_query = query
            updated_query = updated_query.replace(entity.extracted_name, "")
            for word in entity.name.split():
                updated_query = updated_query.replace(word, "")
            updated_query = " ".join(updated_query.split())
            logger.info(f"Rephrasing question from {query} to {updated_query}")
            return updated_query
        return query

    def add_additional_metadata_to_documents(
        self, uc_type: str, user_query: str, entity: str, documents: List[Document]
    ):
        for doc in documents:
            doc.uc_type = uc_type if uc_type else doc.uc_type
            doc.user_query = user_query if user_query else doc.user_query
            doc.entity = entity.name if entity else doc.entity
        return documents
