import React from 'react';
import { Button } from '@spglobal/react-components';
import { Purpose, Size } from '@spglobal/koi-helpers';
import { useChatRD } from '../../../context/chatrd';
import { StyledGenerateInfoBlock, StyledInfoLink } from './GenerateInfoBlock.styles';

export const GenerateInfoBlock: React.FC = () => {
  const { newInteraction } = useChatRD();
  return (
    <StyledGenerateInfoBlock className="StyledGenerateInfoBlock">
      Credit<span className="red">Companion</span><sup style={{fontSize:'7px'}}>TM</sup> is powered by generative AI technology, which may produce inaccurate responses. Please
      review the
      <StyledInfoLink>
        <Button
          size={Size.SMALL}
          purpose={Purpose.LINK}
          onClick={() => newInteraction('CreditCompanion<sup>TM</sup> Legal Disclaimer')}
        >
          Legal Disclaimer
        </Button>
      </StyledInfoLink>
      for more information.
    </StyledGenerateInfoBlock>
  );
};
