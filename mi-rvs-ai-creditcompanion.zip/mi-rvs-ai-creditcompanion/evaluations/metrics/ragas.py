import logging

import nest_asyncio
from dotenv import load_dotenv
from ragas import evaluate
from ragas.llms import LangchainLLMWrapper
from ragas.metrics import context_precision, context_recall, faithfulness

from chatrd.core.embedding import embedding_factory
from chatrd.core.llm import LCLLMFactory
from chatrd.engine.app.engine_initiator import get_chat_engine
from evaluations.metrics.prompts.langchain import anthropic_prompts

load_dotenv()
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)
metrics = [faithfulness, context_precision, context_recall]
CHAT = get_chat_engine()
llm = LCLLMFactory().get_llm(
    deployment_name_or_model_id="gpt-35-turbo-v0613",
    temperature=0,
)


class RagasMetrics:
    def __init__(self, metrics=metrics, embed_model_name="openai", llm=llm):
        self.ragas_azure_model = LangchainLLMWrapper(llm)
        embedding_model = embedding_factory(embed_model_name)
        self.ragas_azure_embeddings = embedding_model
        self.init_metrics()

    def init_metrics(self, batch_size=10):
        for m in metrics:
            m.__setattr__("llm", self.ragas_azure_model)
            m.__setattr__("embeddings", self.ragas_azure_embeddings)
            m.__setattr__("batch_size", batch_size)

            if m == "context_recall":
                m.human_template = anthropic_prompts.CONTEXT_RECALL_HUMAN
                m.ai_template = anthropic_prompts.CONTEXT_RECALL_AI

            elif m == "context_precision":  # Context Average Precision
                m.human_template = anthropic_prompts.CONTEXT_PRECISION_HUMAN
                m.ai_template = anthropic_prompts.CONTEXT_PRECISION_AI

            elif m == "answer_relevancy":
                m.human_template = anthropic_prompts.ANSWER_RELEVANCY_HUMAN
                m.ai_template = anthropic_prompts.ANSWER_RELEVANCY_AI
                m.strictness = 3

            elif m == "faithfulness":  # Answer Faithfulness
                m.statements_human_template = anthropic_prompts.FAITHFULNESS_STATEMENTS_HUMAN
                m.statements_ai_template = anthropic_prompts.FAITHFULNESS_STATEMENTS_AI
                m.verdict_human_template = anthropic_prompts.FAITHFULNESS_VERDICTS_HUMAN
                m.verdict_ai_template = anthropic_prompts.FAITHFULNESS_VERDICTS_AI

    def evaluate_metrics(self, dataset, metrics=metrics):
        nest_asyncio.apply()
        df_result = None
        for i in range(2):  # safer execution if any Exception arise
            try:
                result = evaluate(
                    dataset,
                    metrics=metrics,
                )
            except Exception as e:
                logging.info(e)
                continue
            break
        df_result = result.to_pandas()
        return df_result
