import json
import os
import asyncio
from src.synthia.guardrails.blocked_topics.templates import MODERATION_PROMPT_TEMPLATE
from src.synthia.config.llm_config import LLMType, get_llm

class Guardrails:

    def __init__(self, blocked_topics_path=None, blocked_msgs_path=None):
        base_dir = os.path.dirname(os.path.abspath(__file__))
        if blocked_topics_path is None:                 # Retrieve default paths for the blocked topics and messages
            blocked_topics_path = os.path.join(base_dir, "blocked_topics", "blocked_topics.json")
        if blocked_msgs_path is None:
            blocked_msgs_path = os.path.join(base_dir, "blocked_topics", "blocked_topic_message_map.json")

        with open(blocked_topics_path, "r") as f:         # Load blocked topics
            self.blocked_topics = json.load(f)

        with open(blocked_msgs_path, "r") as f:        # Load blocked messages mapping
            self.blocked_topic_msgs = json.load(f)
        
        self.callbacks = None
        self.llm = get_llm(
            temperature=0.2,
            streaming=False,
            callbacks=self.callbacks,
            llm_type=LLMType.CLAUDE_HAIKU_4_5,
        )

    async def input_guardrail(self, user_question: str):
        """Run the input_guardrail moderation check on user input."""
        # Build the prompt
        prompt = MODERATION_PROMPT_TEMPLATE.replace("[[blocked_topics]]", json.dumps(self.blocked_topics, indent=2))
        prompt = prompt.replace("[[user_question]]", user_question)

        try: # converting prompt format into raw json output for validation
            response = await self.llm.ainvoke(prompt)
            raw_output = response.content.strip()

            if raw_output.startswith("```"):
                raw_output = raw_output.strip("`").replace("json", "").strip()

            result = json.loads(raw_output)
            # validation (if-blocks categories, else-throws message)
            if result.get("question_blocked", False):
                categories = result.get("blocked_categories", [])
                category = categories[0] if categories else "default"
                message = self.blocked_topic_msgs.get(category, "Your question is blocked due to policy.")

                return {
                    "question": result.get("question", user_question),
                    "blocked": True,
                    "blocked_categories": categories,
                    "message": message
                }
            else:
                return {
                    "question": result.get("question", user_question),
                    "blocked": False,
                    "blocked_categories": [],
                    "message": "prompt is not blocked."
                }

        except Exception as e:
            # Fallback if parsing fails
            return {
                "question": user_question,
                "blocked": False,
                "blocked_categories": [],
                "message": f"Moderation failed: {str(e)}"
            }

    async def output_guardrail(self, llm_response: str):
        pass


