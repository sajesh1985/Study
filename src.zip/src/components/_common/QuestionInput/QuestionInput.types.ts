export interface QuestionInputType {
  onSearch: (searchValue: string, taggedEntities:any) => void;
  domUpdateValue?: string;
  onSearchValueUpdate?: (searchValue: string) => void;
  isButtonDisabled?: boolean;
}

export enum CurrentTabEnum {
  all = 'All',
  companies = 'Companies',
  fixed_income = 'Fixed_income',
  none = 'none',
}

export interface ResponseType {
  name?:string;
  destinations?: Array<{
    name?: string;
    comments?: any;
  }>;
  additionalFields?: Array<{
    fieldName?: string;
    fieldValue?: any;
  }>;
}

export interface AtInputType {
  value: string;
  currentTab: CurrentTabEnum;
}

export enum Direction {
  next = 'next',
  prev = 'prev',
}

export interface CustomModalListItemType {
  item: any;
  handleSearchItemClick: (name: ResponseType) => void;
  highlightText: string;
}

export interface CustomModalItemType {
  name?: string;
  comments?: any;
}

export interface CustomModalListType {
  isLoading: boolean;
  listData: Array<CustomModalItemType>;
  handleItemClick: (name: ResponseType) => void;
  highlightText: string;
}
