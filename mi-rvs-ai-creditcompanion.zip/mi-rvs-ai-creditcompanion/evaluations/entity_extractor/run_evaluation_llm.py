import argparse
import json
import logging
import pathlib
import importlib
import sys
import pandas as pd

from evaluations.entity_extractor.utils import evaluate, setup_logging, print_results, load_data, load_model


def init_parser():
    parser = argparse.ArgumentParser(
        description="""
    This script is used to evaluate the NER pipeline using the generated questions.
    It uses the question_generator.py to generate the questions and then evaluates the NER pipeline
    """
    )
    parser.add_argument(
        "--input-template-questions-path",
        type=str,
        help="filename to load the generated questions for evaluation",
        default="evaluations/data/entity_extraction/generated_data/evaluation/generated_questions_1066.json",
    )
    parser.add_argument(
        "--n-repeats",
        type=int,
        help="number of evaluations per input sample to run",
        default=1,
    )
    parser.add_argument(
        "--samples-count",
        type=int,
        help="number of random samples to evaluate for testing purposes",
        default=-1,
    )
    parser.add_argument(
        "--seed",
        type=int,
        help="seed for reproducibility of random sampling in samples-count",
        default=12,
    )
    parser.add_argument(
        "--output-path",
        type=str,
        help="path to save the results",
        default="evaluations/entity_extractor/evaluation_results/llm/",
    )
    parser.add_argument(
        "--prompt-id",
        type=str,
        help="prompt version used for evaluation",
        default="v8",
    )
    parser.add_argument(
        "--temperature", 
        type=float, 
        help="temperature value for the entity extractor llm",
        default=0.0001, 
    )
    parser.add_argument(
        "--models-list",
        type=lambda s: [str(item).strip() for item in s.split(",")],
        help="comma separated model_id list input",
        default="haiku,sonnet",
    )

    return parser


if __name__ == "__main__":

    logger = setup_logging()
    parser = init_parser()
    args = parser.parse_args()

    question_set = load_data(data_path=pathlib.Path(args.input_template_questions_path).resolve(), samples_count=args.samples_count, seed=args.seed)

    for model_id in args.models_list:
        results_df, results_detailed_df = pd.DataFrame(), pd.DataFrame()
        result_stats, n_results = evaluate(
            question_set=question_set,
            number_of_experiments=args.n_repeats,
            model_name_for_analyzer=model_id,
            temperature_value_for_analyzer=args.temperature,
        )

        results_df = pd.concat([results_df, pd.DataFrame(result_stats)], ignore_index=True)
        results_detailed_df = pd.concat([results_detailed_df, pd.DataFrame(n_results)], ignore_index=True)
        
        pathlib.Path(f"{args.output_path}/{model_id}").mkdir(parents=True, exist_ok=True)
        print_results(results_df, results_detailed_df, model_id, args.prompt_id, args.n_repeats, args.output_path)
