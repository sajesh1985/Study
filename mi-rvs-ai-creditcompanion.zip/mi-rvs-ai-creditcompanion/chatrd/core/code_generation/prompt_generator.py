import json
import logging
from typing import List

import boto3

from chatrd.core.code_generation.agent import (  # MERGE_INSTRUCTIONS,
    CAPABILITY_DEFINITIONS,
    AgentCapability,
    OutputConfig,
    OutputType,
)
from chatrd.core.llm import LCLLMFactory
from chatrd.engine.configuration import Constants, get_config_machinery

logger = logging.getLogger(__name__)

config_machinery = get_config_machinery()

AGENTCAPABILITY_OUTPUT_MAP_TYPE = {
    AgentCapability.ANSWER_GENERATION: OutputType.STRING,
    AgentCapability.CHART_BUILDER: OutputType.CHART,
    AgentCapability.MANIPULATION: OutputType.DATAFRAME,
}


OUTPUT_INSTRUCTIONS = {
    OutputType.CHART: """**Chart Output instructions**:
- Return the Plotly figure object as 'result'
- Ensure proper titles, labels, and styling
- Make charts interactive and professional
- If no information is available based on user query, return empty chart
- Example: `result = fig`""",
    OutputType.DATAFRAME: """**DataFrame Output instructions**:
- Return the processed output in a variable called 'result'.
- Ensure clean column names and proper data types.
- Handle missing values appropriately.
- In some instances, merging the resulting dataframes may not be practical. To prevent numerous empty cells, it is advisable to create separate dataframes, each containing relevant data, and return them as a list of dataframes in 'result'.
- Ensure that each dataframe in the output list is accompanied by a descriptive leading sentence to help the user comprehend what each dataframes signifies. Make sure that the leading sentence is concise and precise, starts with an entity name, and ends with a colon. Examples:
    `entity_placeholder_1 has the following Issuer Credit Ratings:`
    `entity_placeholder_2 has the following Financials Highlights:`
    `entity_placeholder_3 has the following Current CreditWatch/Outlook:`
- `entity_placeholder` should be replaced with the actual entity name. Do not use placeholder text in the output.
- If no information is available based on user query, return an empty list.
- Output examples:
    - `result = [{"leading_sentence": df_processed}]`
    - `result = [{"leading_sentence_1": df1}, {"leading_sentence_2": df2}]`
    - `result = []`
- Justify your code in comments.""",
    OutputType.STRING: """**Textual Analysis Output instructions**:
- Return textual analysis output in a variable called 'result'.
- Use markdown formatting and organize the data in bullet points for clarity.
- Keep an eye on handling special characters (backslash, quotes, etc.) in the text.
- In some instances, merging the result may not be practical. In that case it is advisable to create separate output strings, each containing relevant data, and return them as a list of strings in 'result'.
- Ensure that each output item is accompanied by a descriptive leading sentence to help the user comprehend what each string signifies. Make sure that the leading sentence is concise and precise, starts with an entity name, and ends with a colon. Examples:
    `entity_placeholder_1 has the following EBITDA:`
    `entity_placeholder_2 has the following Key Financial Figures:`
- Do not duplicate leading sentence in the output content.
- `entity_placeholder` should be replaced with the actual entity name. Do not use placeholder text in the output.
- If no information is available based on user query, return an empty string.
- Do NOT generate CHART to explain the user query.
- Output examples:
    - `result = [{"leading_sentence": text_analysis}]`
    - `result = [{"leading_sentence_1": text_analysis_1}, {"leading_sentence_2": text_analysis_2}]`
    - `result = []`
""",
    OutputType.DATAFRAME_AND_STRING: """**Mixed Dataframe and Textual output instructions**
<instructions>
- You have to combine DataFrame and textual analysis outputs in a single list variable called 'result'. Reference <output_formatting_cases> to determine whether to use DataFrame or textual output format.
- Ensure that you generate distinct output tables or strings for each use case asked in the query, utilizing the appropriate data and returning them as a list.
- For each output item, you must include a descriptive leading sentence that helps users understand what the item represents. The leading sentence must be concise and precise. start with an entity name, and end with a colon. Follow the patterns shown in <leading_sentence_examples>.
- If no information is available for the user query, return an empty list: `result = []`
- If no data is available, for any part of the user query, just disregard any explanatory text and return an empty string for that part.
- Do not add introductory descriptive sentences in the output content itself.
- Add comments to justify your code logic.
</instructions>

<output_formatting_cases>
- Utilize textual output to enhance readability when the query pertains to a single or specific metric, or a straightforward analysis that yields a single value, single row, or brief summary. <example>What is the financial_metric for Company XYZ in year_1 and year_2?</example>
- Utilize DataFrame output when the question pertains to multiple metrics or demands complex data manipulation, leading to a structured table format, several rows, or a more detailed analysis that requires a tabular representation. <example>Show me ratings and rating actions for Company XYZ in the previous two years.</example>
- You may combine textual and DataFrame outputs when appropriate for comprehensive responses. <example>Show me all ratings in the previous years and the latest EBIDTA for Company XYZ.</example>
</output_formatting_cases>

<textual_output_instructions>
- Format textual outputs using markdown and organize data in bullet points for clarity.
- When in need to use to_string() replace it with to_markdown().
- Properly escape special characters (backslash, quotes, etc.) in text content.
</textual_output_instructions>

<table_output_instructions>
- Create DataFrames with clean column names and appropriate data types.
- Handle missing values appropriately using standard pandas methods.
</table_output_instructions>

<leading_sentence_examples>
- `Company A has the following EBITDA:`
- `Company B has the following Key Financial Figures:`
- `Company C shows the following Revenue Growth:`
</leading_sentence_examples>

<output_examples>
Your result variable must follow these patterns:
- `result = [{"XYZ has the following EBITDA:": text_analysis_1}, {"ABC has the following Key Metrics:": dataframe_1}]`
- `result = [{"Company A Revenue:": text_analysis_1}, {"Company B Revenue:": text_analysis_2}]`
- `result = [{"Q1 Results:": dataframe_1}, {"Q2 Results:": ""}, {"Annual Summary:": text_analysis_1}]`
- `result = []` (when no data available)
</output_examples>
""",
}


class PromptGenerator:
    def __init__(self):
        self.capabilities = CAPABILITY_DEFINITIONS
        # self.merge_instructions = MERGE_INSTRUCTIONS
        self.llm = LCLLMFactory().get_llm(
            deployment_name_or_model_id="haiku",
            temperature=0.0,
            max_tokens_to_sample=4096,
        )

    def _generate_capability_section(self, capability: AgentCapability) -> str:
        """Generate comprehensive capability section"""
        cap_def = self.capabilities[capability]

        guidelines_text = ""
        if cap_def.guidelines:
            guidelines_text = f"""**Guidelines**:
{cap_def.guidelines}"""

        # Build examples section
        examples_text = ""
        if cap_def.examples:
            examples_text = "\n**Examples**:\n"
            for i, example in enumerate(cap_def.examples, 1):
                examples_text += f"""### Example {i}: {example['scenario']}
    ```python
    {example['code']}
    ```\n
    """

        # Build imports section
        imports_text = ""
        imports_text = "\n".join(cap_def.required_imports)
        if cap_def.required_imports:
            imports_text = f"""**Required Imports**:
```python
{imports_text}
```"""

        # Build best practices section
        practices_text = ""
        practices_text = "\n".join([f"- {practice}" for practice in cap_def.best_practices])
        if cap_def.best_practices:
            practices_text = f"""**Best Practices**:
{practices_text}
"""

        # Build comman patterns
        common_patterns = ""
        if cap_def.common_patterns:
            common_patterns = (
                f"""**Common Patterns**: {', '.join([f"`{pattern}`" for pattern in cap_def.common_patterns])}"""
            )

        return f"""## {cap_def.name}

**Description**: {cap_def.description}

{guidelines_text}
{imports_text}
{examples_text}
{practices_text}
{common_patterns}
"""

    def select_capabilty(self, capabilities: List[AgentCapability], user_query: str):
        if len(capabilities) == 0:
            return None
        elif len(capabilities) == 1:
            return capabilities[0]
        else:
            selection_prompt = f"""You must intelligently select ONLY ONE capability based on the user's request. Analyze the user's intent:

User Query: {user_query}

### Selection Criteria:"""
            output_type_text = ""
            for capability in capabilities:
                output_type_text += self.capabilities[capability].id + ", "
                trigger_text = "\n".join(
                    [f"- {indicator}" for indicator in self.capabilities[capability].trigger_indicators]
                )
                selection_prompt += f"""\n**Choose {self.capabilities[capability].id} when:**
{trigger_text}
"""
            selection_prompt += f"""\nReturn output string as either one of following capability {output_type_text} based on user query with no preamble, no explanation."""

        logger.info("Calling selection prompt for code generation:\n " + selection_prompt)
        response = self.llm.invoke(selection_prompt)

        response = response.content
        if AgentCapability.MANIPULATION.value == response:
            return AgentCapability.MANIPULATION
        elif AgentCapability.CHART_BUILDER.value == response:
            return AgentCapability.CHART_BUILDER
        elif AgentCapability.ANSWER_GENERATION.value == response:
            return AgentCapability.ANSWER_GENERATION
        else:
            raise Exception("Wrong Selection")

    def _get_output_instructions(self, *args, **kwargs) -> str:
        """Generate concise output instructions for Python code only"""
        global OUTPUT_INSTRUCTIONS
        output_types = kwargs.get("output_types", None)
        resulting_output_instructions = ""
        for output_type in output_types:
            """Generate output-specific instructions"""
            resulting_output_instructions += OUTPUT_INSTRUCTIONS.get(output_type) + "\n\n"

        if resulting_output_instructions:
            return (
                """## OUTPUT INSTRUCTIONS

    **CRITICAL**: Return ONLY Python code within ```python``` code blocks. No explanations, no preamble, no text outside the code block.\n\n"""
                + resulting_output_instructions
                + """\n\n**Rules**:
    - Always assign final output to variable `result`
    - Include only necessary imports
    - No comments except for clarity
    - No explanatory text outside code block
    - If partial information is available, generate result from what's available
    - If multiple tables have column with the same name, do not assume that the contents are the same. For example, column Debt Type (Rating Type) for ratings and rating action might take different values. That means, that different rating and debt types are covered.
    - You MUST NOT join multiple tables of different sort into a single dataframe. Do not use pd.concat and pd.merge. For example, for financials and ratings input you MUST output two separate tables."""
            )
        else:
            return ""

    def generate_prompt_for_single_table(
        self,
        prompt: str,
        table_description: str,
        sample_data: str,
        column_description: str,
        special_instructions: str,
        capabilities: List[AgentCapability],
        output_config: OutputConfig,
    ):
        """Generate a single prompt that includes intelligent capability selection"""

        # Generate all capability sections
        if len(capabilities) > 1:
            selected_capibility = self.select_capabilty(capabilities, prompt)
        else:
            selected_capibility = capabilities[0]
        capabilities_text = ""
        capabilities_text += self._generate_capability_section(selected_capibility)

        # Generate output instructions

        output_instructions = self._get_output_instructions(
            output_types=self.capabilities[selected_capibility].output_types
        )

        return f"""You are an expert Python data analyst with very specialized capability. You are already provided with pandas dataframe named 'df'.

**User Request**: {prompt}

# GIVEN CAPABILITY

{capabilities_text}

## 📊 DATA CONTEXT

**DataFrame Description**: {table_description}

**Sample Data**:
```
{sample_data}
```

**Column Details**:

{column_description}

**Special Requirements**:
{special_instructions}

{output_instructions}

**Remember**: Your success depends on correctly identifying what the user wants and executing it perfectly using the provided capability and the code should be production-ready and handle edge cases. Do NOT create pandas dataframe if information is not available, please use the provided dataframe.
"""

    def generate_prompt_for_multiple_tables(
        self,
        prompt: str,
        names: List[str],
        table_descriptions: List[str],
        sample_datas: List[str],
        column_descriptions: List[str],
        table_key_texts: List[str],
        # table_key_values: List[str],
        special_instructions: List[str],
        examples_text: str,
        capabilities: List[AgentCapability],
        output_config: OutputConfig,
    ):
        """Generate a single prompt that includes intelligent capability selection"""

        # Generate all capability sections
        if len(capabilities) > 1:
            selected_capibility = self.select_capabilty(capabilities, prompt)
        else:
            selected_capibility = capabilities[0]
        capabilities_text = ""
        capabilities_text += self._generate_capability_section(selected_capibility)

        # Generate output instructions

        output_instructions = self._get_output_instructions(
            output_types=self.capabilities[selected_capibility].output_types
        )

        merge_instructions = ""  # applicable only for at least two tables with table key provided
        if sum([text != "" for text in table_key_texts]) > 2:
            merge_instructions = """
**Table Merging Instructions**:
    - Merge tables only if they share common key columns.
    - Avoid merging tables if no common keys are available.
    - When using `pandas.concat`:
        - Set the index to the key columns of the tables before concatenation.
        - Perform concatenation with `axis=1` and reset the index afterward.
    - When using `pandas.merge`:
        - Choose an appropriate join type (inner, outer, left, right).
        - Use the `on=` parameter to specify the common key columns.
            """

        dataframe_infos = ""
        # for name, desc, sd, col_desc, table_key_value, spec_desc in zip(
        #     names, table_descriptions, sample_datas, column_descriptions, table_key_values, special_instructions
        # ):
        for name, desc, sd, col_desc, spec_desc, table_key_text in zip(
            names, table_descriptions, sample_datas, column_descriptions, special_instructions, table_key_texts
        ):
            dataframe_infos += f"""\nDataFrame Name: {name}

**DataFrame Description**: {desc}

**Sample Data**:
```
{sd}
```
{table_key_text}
**Column Details**:

{col_desc}


**Special Requirements**:
{spec_desc}"""

        return f"""You are an expert Python data analyst with very specialized capability. I need you to generate clean, efficient Python code using pandas to analyze multiple DataFrames.

**User Request**: {prompt}

# GIVEN CAPABILITY

{capabilities_text}

## 📊 DATA CONTEXT

{dataframe_infos}

{merge_instructions}
{output_instructions}


**Examples**:
Follow these examples to generate your code:

{examples_text}

**Remember**: Your success depends on correctly identifying what the user wants and executing it perfectly using the provided capability and the code should be production-ready and handle edge cases. Do NOT create pandas dataframe if information is not available, please use the provided dataframe.
"""


# ** Table Merging Instructions **:
# {self.merge_instructions}

# **Table Key Values**:
#
# {table_key_value}
