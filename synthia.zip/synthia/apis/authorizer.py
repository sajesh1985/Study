"""
AWS Lambda Function Authorizer for Synthia Service API Gateway.

This Lambda function validates Bearer JWT tokens and generates IAM 
policies for API Gateway function-based authorization.
"""

import json
import os
import httpx
import logging
import traceback
import hashlib
from typing import Dict, Any, Optional
from functools import lru_cache

from src.synthia.config.api_config import get_config, Config

# Configure logging for authorizer
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

# Create console handler if not exists
if not logger.handlers:
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter(
        '%(asctime)s - AUTHORIZER - %(name)s - %(levelname)s - %(message)s'
    )
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

config: Config | None = None

DEFAULT_TIMEOUT = float(os.getenv("AUTH_TIMEOUT", "10"))

_http_client: Optional[httpx.Client] = None  # Reused between invocations


def get_excluded_paths() -> set:
    synthia_service_api_prefix = config['SYNTHIA_SERVICE_API_PREFIX']
    auth_excluded_paths = [
        "/",
        f"{synthia_service_api_prefix}/health",
        f"{synthia_service_api_prefix}/docs",
        f"{synthia_service_api_prefix}/openapi.json",
        f"{synthia_service_api_prefix}/redoc"
    ]
    return {p.rstrip("/") or "/" for p in auth_excluded_paths}


def _get_http_client() -> httpx.Client:
    global _http_client
    if _http_client is None:
        _http_client = httpx.Client(timeout=DEFAULT_TIMEOUT)
    return _http_client


@lru_cache(maxsize=1)
def _get_auth_service_url_from_config() -> Optional[str]:
    try:
        return config['auth_service_url']
    except Exception as e:  # config errors should not crash authorizer
        logger.error(f"AUTHORIZER: Failed to load config: {e}")
        return None


def get_auth_service_url() -> Optional[str]:
    return _get_auth_service_url_from_config()


def extract_path(event: Dict[str, Any]) -> str:
    path = event.get("path")
    if not path:
        path = event.get("requestContext", {}).get("http", {}).get("path", "/")
    return path or "/"


def is_excluded_path(path: str) -> bool:
    p = (path or "/").rstrip("/") or "/"
    excluded_paths = get_excluded_paths()
    if p in excluded_paths:
        return True
    return any(p.endswith(ex.rstrip("/") or "/") for ex in excluded_paths)


def extract_bearer_token(event: Dict[str, Any]) -> Optional[str]:
    token = None
    raw = event.get("authorizationToken")
    if not raw:
        headers = event.get("headers") or {}
        auth_header = next((v for k, v in headers.items() if k.lower() == "authorization"), None)
        raw = auth_header
    if not raw:
        return None
    raw = raw.strip()
    # Return the full authorization header value (including "Bearer " prefix)
    return raw or None


def derive_resource_arn(method_arn: str) -> str:
    """
    Optionally broaden resource scope to improve APIGW authorizer cache hit rate.
    methodArn format: arn:aws:execute-api:region:acct:apiId/stage/VERB/path
    """
    if not method_arn:
        return method_arn
    try:
        parts = method_arn.split(":")
        if len(parts) < 6:
            return method_arn
        last = parts[5]  # apiId/stage/VERB/...
        segs = last.split("/")
        if len(segs) < 2:
            return method_arn
        api_stage = "/".join(segs[:2])  # apiId/stage
        # wildcard both method & path
        parts[5] = f"{api_stage}/*/*"
        return ":".join(parts)
    except Exception:
        return method_arn


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    logger.info("AUTHORIZER: Invocation")
    logger.debug(f"AUTHORIZER: Event type: {event.get('type', 'unknown')}")
    logger.debug(f"AUTHORIZER: Method ARN: {event.get('methodArn', 'unknown')}")
    logger.debug(f"AUTHORIZER: HTTP Method: {event.get('httpMethod', 'unknown')}")
    logger.debug(f"AUTHORIZER: Request ID: {getattr(context, 'aws_request_id', 'unknown') if context else 'unknown'}")
    global config
    config = get_config()
    # Log headers (sanitized and truncated)
    headers = event.get("headers", {})
    sanitized_headers = {
        k: '[REDACTED]' if k.lower() == 'authorization' else (v[:50] + '...' if len(str(v)) > 50 else v)
        for k, v in headers.items()
    }
    logger.debug(f"AUTHORIZER: Headers: {sanitized_headers}")
    
    # Log query parameters if present
    query_params = event.get("queryStringParameters")
    if query_params:
        logger.debug(f"AUTHORIZER: Query parameters: {query_params}")
    
    method_arn = event.get("methodArn", "*")
    resource_arn = derive_resource_arn(method_arn)
    try:
        auth_service_url = get_auth_service_url()
        if not auth_service_url:
            logger.error("AUTHORIZER: Missing auth service URL")
            return generate_policy("anonymous", "Deny", resource_arn, "Auth service URL not configured")

        path = extract_path(event)
        if is_excluded_path(path):
            return generate_policy("anonymous", "Allow", resource_arn, "Excluded path")

        token = extract_bearer_token(event)
        if not token:
            return generate_policy("anonymous", "Deny", resource_arn, "Missing or invalid Authorization header")

        if validate_token(token, auth_service_url):
            return generate_policy("user", "Allow", resource_arn, "Valid token", token=token)
        return generate_policy("user", "Deny", resource_arn, "Invalid or expired token")
    except httpx.TimeoutException:
        return generate_policy("user", "Deny", resource_arn, "Auth service timeout")
    except httpx.ConnectError:
        return generate_policy("user", "Deny", resource_arn, "Auth service unavailable")
    except httpx.RequestError:
        return generate_policy("user", "Deny", resource_arn, "Auth service error")
    except Exception as e:
        import traceback
        logger.error(f"AUTHORIZER: Unhandled error: {e}")
        logger.debug(f"AUTHORIZER: Traceback:\n{traceback.format_exc()}")
        return generate_policy("user", "Deny", resource_arn, "Internal error")


def validate_token(token: str, auth_service_url: str) -> bool:
    """
    Validate token against authentication service.
    """
    logger.debug(f"AUTHORIZER: Starting token validation with service: {auth_service_url}")
    client = _get_http_client()
    try:
        
        response = client.get(
            auth_service_url,
            headers={
                "Authorization": token,
                "Accept": "application/json",
                "Content-Type": "application/json"
            }
        )
        status = response.status_code
        logger.debug(f"AUTHORIZER: Auth service response status: {status}")
        logger.debug(f"AUTHORIZER: Auth service response headers: {dict(response.headers)}")
        
        try:
            response_text = response.text
            if response_text:
                truncated_text = response_text[:500] + "..." if len(response_text) > 500 else response_text
                logger.debug(f"AUTHORIZER: Auth service response body: {truncated_text}")
            else:
                logger.debug("AUTHORIZER: Auth service response body: <empty>")
        except Exception as e:
            logger.debug(f"AUTHORIZER: Failed to read response body: {e}")
        
        if status == 200:
            try:
                data = response.json()
                logger.debug("AUTHORIZER: Successfully parsed JSON response")
                # If we get data back, token is valid
                return True
            except ValueError as e:
                logger.warning(f"AUTHORIZER: 200 with invalid JSON: {e}")
                return False
        if status == 204:
            logger.debug("AUTHORIZER: 204 No Content - token valid")
            return True
        if status in (401, 403):
            logger.debug(f"AUTHORIZER: Authentication failed with status {status}")
            return False
        if status >= 500:
            logger.error(f"AUTHORIZER: Upstream 5xx ({status})")
            raise httpx.RequestError(f"Upstream {status}")
        logger.debug(f"AUTHORIZER: Unexpected status {status}: {response.text[:200]}")
        return False
    except Exception as e:
        logger.error(f"AUTHORIZER: Token validation error: {e}")
        raise


def generate_policy(principal_id: str, effect: str, resource: str, message: str, token: Optional[str] = None) -> Dict[str, Any]:
    """
    Generate IAM policy for API Gateway authorization.
    """
    logger.info(f"AUTHORIZER: Generating IAM policy - Effect: {effect}, Principal: {principal_id}")
    logger.debug(f"AUTHORIZER: Policy resource: {resource}")
    logger.debug(f"AUTHORIZER: Policy message: {message}")
    
    ctx = {
        "message": str(message),
        "tokenValidated": "true" if effect == "Allow" else "false",
        "authProvider": "synthia-auth-service",
    }
    if token:
        # short stable hash for cache discrimination (kept small)
        ctx["tokenHash"] = hashlib.sha256(token.encode()).hexdigest()[:16]

    policy = {
        "principalId": principal_id,
        "policyDocument": {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Action": "execute-api:Invoke",
                    "Effect": effect,
                    "Resource": resource,
                }
            ],
        },
        "context": ctx,
    }
    
    logger.debug(f"AUTHORIZER: Generated policy: {json.dumps(policy, indent=2)}")
    logger.info(f"AUTHORIZER: Policy generation complete - returning {effect} policy")
    
    return policy