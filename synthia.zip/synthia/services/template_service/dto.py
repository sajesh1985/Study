from pydantic import BaseModel
from uuid import UUID


class CompanyTemplate(BaseModel):
    company_id: str
    template_id: UUID
    tile_name: str
    tile_description: str
    template_file_name: str
