import asyncio
import logging
import os
from typing import Any, List, Optional, Set, Dict

from langchain.agents import create_agent

from src.synthia.config.llm_config import LLMType, get_llm
from src.synthia.mcp_client.mcp_client_async import create_mcp_client
from src.synthia.prompts.system_prompts import (
    section_system_prompt,
    synthesizer_system_prompt,
)
from src.synthia.utils.logging_config import configure_logging
from src.synthia.schemas.workflow import SectionGenerationModeEnum


class AgentFactory:
    """Factory for creating different types of agents."""

    def __init__(
        self,
        auth_token: str,
        callbacks: Optional[List[Any]] = None,
        mlflow_enabled: bool = False
    ):
        self.callbacks: List[Any] = callbacks or []
        # self.llm = get_llm(temperature=0.2, streaming=False, callbacks=callbacks)
        # self.llm_claude3_5 = get_llm(
        #     temperature=0.2,
        #     streaming=False,
        #     callbacks=callbacks,
        #     llm_type=LLMType.CLAUDE_3_5,
        # )
        self.llm_claude3_7 = get_llm(
            temperature=0.2,
            streaming=False,
            callbacks=self.callbacks,
            llm_type=LLMType.CLAUDE_HAIKU_4_5,
        )
        # self.llm_claude4 = get_llm(
        #     temperature=0.2,
        #     streaming=False,
        #     callbacks=self.callbacks,
        #     llm_type=LLMType.CLAUDE_SONNET_4,
        # )
        # self.llm_claude3_5_cached = get_llm(
        #     temperature=0.2,
        #     streaming=False,
        #     callbacks=self.callbacks,
        #     llm_type=LLMType.CLAUDE_3_5,
        #     use_llm_cache=True,
        # )
        # self.llm_claude3_7_cached = get_llm(
        #     temperature=0.2,
        #     streaming=False,
        #     callbacks=self.callbacks,
        #     llm_type=LLMType.CLAUDE_3_7,
        #     use_llm_cache=True,
        # )
        # self.llm_claude4_cached = get_llm(
        #     temperature=0.2,
        #     streaming=False,
        #     callbacks=self.callbacks,
        #     llm_type=LLMType.CLAUDE_4,
        #     use_llm_cache=True,
        # )
        self.auth_token: str = auth_token
        self._all_tools: Optional[List[Any]] = None
        self.debug: bool = False
        self._tools_lock: asyncio.Lock = asyncio.Lock()
        self.mlflow_enabled: bool = mlflow_enabled
        self.logger = configure_logging(
            logger_name=__name__,
            log_file="synthia.log",
            module_levels={__name__: logging.DEBUG}
        )
        
        if self.mlflow_enabled:
            try:
                import mlflow
                import mlflow.langchain

                mlflow.langchain.autolog()
                mlflow.set_tracking_uri("http://localhost:5000")
                mlflow.set_experiment("Synthia")
            except ImportError:
                print(
                    "Warning: MLflow is not installed. Proceeding without MLflow logging."
                )
            except Exception as e:
                print(f"Warning: MLflow setup failed: {e}")

    async def _get_tools(self) -> List[Any]:
        if self._all_tools is None:
            async with self._tools_lock:
                if self._all_tools is None:
                    client = await create_mcp_client(self.auth_token)
                    self._all_tools = await client.get_tools() or []
        return self._all_tools

    async def _create_agent(self, name: str = "report_agent") -> Any:
        tools = await self._get_tools()
        agent = create_agent(
            self.llm,
            tools,
            name=name,
            debug=self.debug,
        )
        return agent

    async def _get_report_synthesizer_agent(self, name: str = "synthesizer_agent") -> Any:
        # wrap (previously unwrapped)
        agent = create_agent(
            self.llm_claude3_7,
            tools=[],
            name=name,
            debug=self.debug,
            system_prompt=synthesizer_system_prompt,
        )
        return agent

    async def _get_section_agent(self, report_template: str, section_name: str, tool_names: Optional[Set[str]], mode: SectionGenerationModeEnum) -> Optional[Any]:
        import re

        from src.synthia.utils.template_util import get_tools_for_section, should_cache_section_llm

        def sanitize(name: str) -> str:
            return re.sub(r"[^a-zA-Z0-9_-]", "_", name)

        final_tool_names: Set[str]
        if not tool_names:
            final_tool_names = set(
                await get_tools_for_section(report_template, section_name)
            )
        else:
            final_tool_names = tool_names
            
        all_tools = await self._get_tools()
        agent_name = f"{sanitize(report_template)[:4]}_{sanitize(section_name)}"[:30]
        if not final_tool_names:
            self.logger.warning(
                f"No tools declared for section '{section_name}' (template '{report_template}'). "
                "Creating tool-less agent."
            )
        filtered_tools = [tool for tool in all_tools if tool.name in final_tool_names] if final_tool_names else []
        if not filtered_tools:
            self.logger.warning(
                f"Tools not selected for section '{section_name}': {final_tool_names}. skipping agent creation."
            )
            return None
        
        llm = self.llm_claude3_7
        if mode is SectionGenerationModeEnum.Edit:
            llm = self.llm_claude3_7

        # Use should_cache_section_llm to decide which LLM to use
        # if os.getenv("ENABLE_CACHE", "false").lower() in ("false", "0", "no"):
        #     self.logger.info("LLM caching is disabled. Using uncached LLM.")
        #     llm = llm
        # elif should_cache_section_llm(section_name):
        #     self.logger.info(f"Using cached LLM for section: {section_name}")
        #     llm = self.llm_claude3_7_cached
        # else:
        #     self.logger.info(f"Using uncached LLM for section: {section_name}")
        #     llm = llm

        # Use ReportSection schema for response_format
        agent = create_agent(
            llm,
            filtered_tools,
            name=f"{agent_name}_agent",
            debug=self.debug,
            system_prompt=section_system_prompt,
        )
        return agent

    # async def _get_outline_agent(self):
    #     tools = await self._get_tools()
    #     from src.synthia.schemas.workflow import OutlineSection  # ensure correct import

    #     return create_react_agent(
    #         self.llm,
    #         tools,
    #         response_format=OutlineSection,  # Use Section, not List[Section]
    #         name="outline_agent",
    #         debug=self.debug,
    #         prompt=section_system_prompt,
    #     )

    async def get_agent(
        self,
        agent_type: str = "default",
        report_template: Optional[str] = None,
        section_name: Optional[str] = None,
        tool_names: Optional[Set[str]] = None,
        section_mode: SectionGenerationModeEnum = SectionGenerationModeEnum.Generate,
    ) -> Optional[Any]:
        if agent_type == "report" or agent_type == "default" or agent_type == "custom":
            return await self._create_agent(name="agent")
        elif agent_type == "outline":
            # Outline agent is not implemented, fall back to default agent
            return await self._create_agent(name="agent")
        elif agent_type == "synthesizer":
            return await self._get_report_synthesizer_agent(name="synthesizer_agent")
        elif agent_type == "section":
            if not report_template or not section_name:
                return await self._create_agent(name="agent")
            return await self._get_section_agent(report_template, section_name, tool_names, section_mode)
        else:
            raise ValueError(f"Unknown agent_type: {agent_type}")
